import {redirect} from 'next/navigation';
import {getPageProfile} from '@/lib/auth/render-context';
import {DashboardHeader} from '@/app/components/dashboard-header';
import {asSettingsRecord,readProfileSettings} from '@/lib/settings/settings-core';
import {readThemePreference} from '@/lib/theme/theme-core';
import {FinancialBackup} from './financial-backup';
export const dynamic='force-dynamic';
export default async function BackupsPage(){
 const {current,documents}=await getPageProfile(true);
 if(current.status==='unauthenticated')redirect('/login');
 if(current.status!=='active')redirect('/');
 const theme=readThemePreference(asSettingsRecord(documents.interface_preferences));
 const showManual=process.env.XLSX_FINANCIAL_MANUAL_ENABLED==='true'
  && current.profile.auth_user_id===process.env.XLSX_FINANCIAL_OWNER_ID;
 return <div data-theme={theme} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]"><DashboardHeader nickname={current.profile.nickname} displayName={readProfileSettings(documents).displayName} theme={theme}/>{showManual&&<main className="mx-auto max-w-5xl p-4"><FinancialBackup/></main>}</div>;
}
