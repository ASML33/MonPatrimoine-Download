"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { parisBusinessDate } from "@/lib/dates/business-date";

type Archive = { reference: string; name: string; date: string; capturedAt?: string; contractId?: string; contractLabel?: string; year?: number; archive?: boolean; kind?: "xlsx" | "json" };
type Destination = { account: string; active: { name: string } | null; archives: Archive[] | null; today: string; batchReference?: { date: string; capturedAt: string } | null };
const endpoint = "/api/backups/xlsx-financial-destination";
const operationKey = "mp-financial-xlsx-operation";

export function FinancialBackup({ forPrompt = false, selectedContracts = [] }: { forPrompt?: boolean; selectedContracts?: {id:string;label:string}[] } = {}) {
  const [destination, setDestination] = useState<Destination | null>(null);
  const [loading, setLoading] = useState(true);
  const [checkAttempt, setCheckAttempt] = useState(0);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");
  const [verificationError, setVerificationError] = useState("");
  const running = useRef(false);

  useEffect(() => {
    const controller = new AbortController();
    void fetch(endpoint, { signal: controller.signal, cache: "no-store", redirect: "error" }).then(async response => {
      const result = await response.json();
      if (controller.signal.aborted) return;
      setDestination(response.ok ? result : null);
      setVerificationError(response.ok ? "" : result.message ?? "Connexion Google Drive indisponible.");
    }).catch(() => {
      if (controller.signal.aborted) return;
      setDestination(null);
      setVerificationError("Vérification de la destination indisponible.");
    }).finally(() => {
      if (!controller.signal.aborted) setLoading(false);
    });
    return () => controller.abort();
  }, [checkAttempt]);

  const recheckDestination = useCallback(() => {
    setVerificationError("");
    setLoading(true);
    setCheckAttempt(attempt => attempt + 1);
  }, []);

  useEffect(() => {
    let day = parisBusinessDate();
    const interval = window.setInterval(() => {
      const currentDay = parisBusinessDate();
      if (running.current || day === currentDay) return;
      day = currentDay;
      recheckDestination();
    }, 30_000);
    return () => window.clearInterval(interval);
  }, [recheckDestination]);

  async function run(work: () => Promise<void>, onFailure = "Opération interrompue. Réessayez pour reprendre.") {
    if (running.current) return;
    running.current = true;
    setBusy(true);
    setMessage("");
    try { await work(); }
    catch { setMessage(onFailure); }
    finally {
      running.current = false;
      setBusy(false);
    }
  }

  async function save() {
    if (loading || !destination?.active || !destination.archives) return;
    await run(async () => {
      setMessage("Préparation et vérification du classeur XLSX…");
      const operation = localStorage.getItem(operationKey) ?? crypto.randomUUID();
      localStorage.setItem(operationKey, operation);
      let imported = 0;
      for (;;) {
        const response = await fetch("/api/backups/xlsx-financial", {
          method: "POST", headers: { "Idempotency-Key": operation },
        });
        const result = await response.json();
        if (response.status === 202 && result.status === "initializing"
          && Number.isSafeInteger(result.imported) && result.imported > 0 && result.imported <= 20) {
          imported += result.imported;
          setMessage(`Préparation de l’historique financier · ${imported} journées traitées.`);
          continue;
        }
        if (result.status === "cancelled") {
          if (localStorage.getItem(operationKey) === operation) localStorage.removeItem(operationKey);
          recheckDestination();
          setMessage("La destination a changé. Cliquez à nouveau pour sauvegarder dans le nouveau dossier.");
          return;
        }
        if (!response.ok || !["published", "already_published"].includes(result.status)) {
          if (["auth", "permission", "destination", "cleanup_pending"].includes(result.code)) recheckDestination();
          setMessage(result.message ?? "Sauvegarde indisponible. Réessayez pour reprendre.");
          return;
        }
        if (localStorage.getItem(operationKey) === operation) localStorage.removeItem(operationKey);
        recheckDestination();
        const outcome = result.status === "published" ? "Lot XLSX et JSON publié et vérifié" : "Lot XLSX et JSON déjà vérifié";
        const today = parisBusinessDate();
        setMessage(outcome + " pour le " + result.date.split("-").reverse().join("/") + "."
          + (Array.isArray(result.warnings) && result.warnings.length ? " " + result.warnings.join(" ") : "")
          + (result.partial ? " Certaines données sont signalées par « ? »." : "")
          + (result.date !== today || (result.operation && result.operation !== operation)
            ? " Cliquez à nouveau pour effectuer une nouvelle sauvegarde." : ""));
        return;
      }
    });
  }

  async function download(file: Archive) {
    await run(async () => {
      try {
        const response = await fetch(`${endpoint}?download=${encodeURIComponent(file.reference)}`, {
          cache: "no-store", redirect: "error",
        });
        if (!response.ok) {
          const result = await response.json();
          setMessage(result.message ?? "Téléchargement XLSX indisponible.");
          recheckDestination();
          return;
        }
        const url = URL.createObjectURL(await response.blob());
        const link = document.createElement("a");
        link.href = url;
        link.download = file.name;
        link.click();
        window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      } catch (error) {
        recheckDestination();
        throw error;
      }
    }, "Téléchargement XLSX interrompu. Réessayez.");
  }

  const archives = loading ? null : destination?.archives;
  const selectedIds = new Set(selectedContracts.map(c=>c.id));
  const files = !forPrompt ? archives : archives ? [
    ...archives.filter(f=>!f.archive && (f.kind==="xlsx" || !f.kind)).sort((a,b)=>b.date.localeCompare(a.date)).slice(0,1),
    ...archives.filter(f=>f.kind==="json" && !f.archive && f.contractId && selectedIds.has(f.contractId))
      .sort((a,b)=>a.contractId!.localeCompare(b.contractId!)),
    ...archives.filter(f=>f.kind==="json" && f.archive && f.contractId && selectedIds.has(f.contractId))
      .sort((a,b)=>a.contractId!.localeCompare(b.contractId!) || (b.year??0)-(a.year??0)),
  ] : null;
  const missing = forPrompt && archives ? selectedContracts.filter(c=>!archives.some(f=>!f.archive && f.kind==="json" && f.contractId===c.id)) : [];
  const relaunch = forPrompt && archives?.some(file => file.date === destination?.today);
  const saveLabel = !forPrompt ? "Sauvegarder sur Google Drive"
    : !archives ? "Sauvegarde du jour"
    : relaunch ? "Relancer la sauvegarde du jour"
    : "Créer la sauvegarde du jour";

  return <section className={forPrompt ? "mt-5 min-w-0 space-y-3 border-t border-[var(--app-border)] pt-5" : "space-y-3 rounded border border-[var(--app-border)] p-4"}>
    {forPrompt ? <>
      <h3 className="font-semibold">Fichiers à joindre au prompt (facultatif)</h3>
      <p className="text-xs text-[var(--app-muted)]">Ces fichiers contiennent vos données financières. Vérifiez leur contenu avant de les transmettre à une IA externe.</p>
    </> : <>
      <h2 className="font-semibold">Sauvegarde financière XLSX</h2>
      <p>Historique consultable dans Excel et Google Sheets.</p>
      {destination && <p>Compte Google connecté : {destination.account}</p>}
      {destination?.active && <p>Destination : Mon Drive / {destination.active.name}</p>}
    </>}
    {!loading && verificationError && <p role="alert" className="text-sm">{verificationError}</p>}
    {!loading && !destination?.active && <>
      <div className="space-y-3 rounded border border-red-400/40 bg-red-950/40 p-3 text-sm text-red-200 [[data-theme=light]_&]:border-red-300 [[data-theme=light]_&]:bg-red-50 [[data-theme=light]_&]:text-red-800">
        <div role="alert" className="flex items-start gap-2">
          <svg aria-hidden="true" className="mt-0.5 size-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M10.3 4.5 2.6 18a2 2 0 0 0 1.7 3h15.4a2 2 0 0 0 1.7-3L13.7 4.5a2 2 0 0 0-3.4 0ZM12 9v4m0 4h.01" />
          </svg>
          <div>
            <p className="font-semibold">Dossier de sauvegarde à vérifier</p>
            <p>Vérifiez que le dossier “MonPatrimoine — Sauvegardes” existe bien à la racine de votre Google Drive. S&apos;il n&apos;existe pas, créez-le manuellement, puis relancez la vérification.</p>
          </div>
        </div>
        <button type="button" className="rounded font-semibold underline underline-offset-4 focus-visible:outline-2 focus-visible:outline-offset-2" onClick={recheckDestination}>Vérifier à nouveau</button>
      </div>
      <a className="underline" href="/settings#google-drive">Gérer la connexion Google dans Paramètres</a>
    </>}
    <div className={forPrompt ? "grid gap-4 md:grid-cols-2" : "grid gap-4"}>
      <div className="min-w-0 space-y-2">
        {!forPrompt && destination?.active && <h3 className="font-semibold">Fichiers XLSX dans Google Drive</h3>}
        {forPrompt && destination?.batchReference && <p className="text-xs text-[var(--app-muted)]">Référence du lot : {new Date(destination.batchReference.capturedAt).toLocaleString("fr-FR",{timeZone:"Europe/Paris"})} (Paris)</p>}
        {missing.map(contract=><p key={contract.id} className="text-sm">JSON courant indisponible pour {contract.label}.</p>)}
        {loading && <p role="status">Vérification de la destination…</p>}
        {files?.length === 0 && <p>Aucun fichier XLSX de MonPatrimoine trouvé dans ce dossier.</p>}
        {!!files?.length && <ul className="space-y-2">{files.map(file => <li key={file.reference}>
          <button type="button" className="max-w-full break-all text-left underline underline-offset-4 disabled:opacity-50"
            aria-label={`Télécharger ${file.name}`} disabled={busy} onClick={() => void download(file)}>{file.name}</button>
          {forPrompt && <p className="text-xs text-[var(--app-muted)]">{file.kind==="json" ? (file.archive ? `Archive ${file.year} — ${file.contractLabel}` : file.contractLabel) : "Tous les comptes"}</p>}
        </li>)}</ul>}
      </div>
      <div className="min-w-0 space-y-2">
        <button type="button" className={`${relaunch ? "settings-edit-action" : "settings-primary-button"} max-w-full whitespace-normal`} onClick={() => void save()} disabled={busy || !archives}>
          {busy ? "Opération en cours…" : saveLabel}
        </button>
        <p role="status" className="text-sm">{message}</p>
      </div>
    </div>
  </section>;
}
