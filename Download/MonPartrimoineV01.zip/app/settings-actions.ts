"use server";

import { headers } from "next/headers";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

import { getCurrentProfile } from "@/lib/auth/profile";
import type { CurrentProfile } from "@/lib/auth/profile-core";
import {
  deleteCurrentPriceProviderConfiguration,
  getCurrentPriceProviderConfigurations,
  getPriceProviderRuntimeCredential,
  saveCurrentPriceProviderConfiguration,
  setPriceProviderValidationStatus,
} from "@/lib/assets/price-provider-configurations";
import { validatePriceProviderConfiguration } from "@/lib/assets/price-provider-configuration-core";
import { validateEodhdCredential } from "@/lib/assets/eodhd-provider";
import { validateTwelveDataCredential } from "@/lib/assets/twelve-data-provider";
import {
  changeEmail,
  changeIdentifier,
  changePassword,
  SETTINGS_SERVICE_ERROR,
  type SettingsActionState,
  validateUserInformation,
} from "@/lib/settings/settings-core";
import { updateCurrentSettingsNamespace } from "@/lib/settings/profile-settings";
import { createClient } from "@/lib/supabase/server";

async function getActiveProfile(): Promise<CurrentProfile | null> {
  const current = await getCurrentProfile().catch(() => null);
  if (!current) return null;
  if (current.status === "unauthenticated") redirect("/login");
  if (current.status !== "active") return null;
  return current.profile;
}

function getRequestOrigin(requestHeaders: Headers) {
  const configured = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  if (configured) return new URL(configured).origin;

  if (process.env.NODE_ENV === "production") return null;
  const host = requestHeaders.get("x-forwarded-host") ?? requestHeaders.get("host");
  if (!host || !/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host)) return null;
  const protocol = requestHeaders.get("x-forwarded-proto") ?? "http";
  return `${protocol}://${host}`;
}

export async function updateIdentifierAction(
  _state: SettingsActionState,
  formData: FormData,
): Promise<SettingsActionState> {
  const profile = await getActiveProfile();
  if (!profile) return { status: "error", message: SETTINGS_SERVICE_ERROR };

  return changeIdentifier(String(formData.get("identifier") ?? ""), async (identifier) => {
    const supabase = await createClient();
    const { error } = await supabase
      .from("profiles")
      .update({ nickname: identifier })
      .eq("auth_user_id", profile.auth_user_id)
      .select("nickname")
      .single();

    if (!error) {
      revalidatePath("/");
      revalidatePath("/settings");
      return "updated";
    }
    return error.code === "23505" ? "conflict" : "error";
  });
}

export async function updateEmailAction(
  _state: SettingsActionState,
  formData: FormData,
): Promise<SettingsActionState> {
  const profile = await getActiveProfile();
  if (!profile) return { status: "error", message: SETTINGS_SERVICE_ERROR };

  return changeEmail(
    String(formData.get("email") ?? ""),
    profile.email,
    async (email) => {
      const origin = getRequestOrigin(await headers());
      if (!origin) return "error";

      const supabase = await createClient();
      const { data, error } = await supabase.auth.updateUser(
        { email },
        { emailRedirectTo: `${origin}/auth/callback?next=/settings` },
      );
      if (error) return "error";

      revalidatePath("/settings");
      return data.user.email?.toLowerCase() === email
        ? "updated"
        : "confirmation_required";
    },
  );
}

export async function updatePasswordAction(
  _state: SettingsActionState,
  formData: FormData,
): Promise<SettingsActionState> {
  const profile = await getActiveProfile();
  if (!profile) return { status: "error", message: SETTINGS_SERVICE_ERROR };

  return changePassword(
    String(formData.get("password") ?? ""),
    String(formData.get("confirmation") ?? ""),
    async (password) => {
      const supabase = await createClient();
      const { error } = await supabase.auth.updateUser({ password });
      return !error;
    },
  );
}

export async function updateUserInformationAction(
  _state: SettingsActionState,
  formData: FormData,
): Promise<SettingsActionState> {
  const profile = await getActiveProfile();
  if (!profile) return { status: "error", message: SETTINGS_SERVICE_ERROR };

  const validation = validateUserInformation(
    String(formData.get("displayName") ?? ""),
  );
  if (!validation.ok) return { status: "error", message: validation.message };

  try {
    await updateCurrentSettingsNamespace(
      "preferences",
      "user_information",
      validation.value,
    );
    revalidatePath("/settings");
    return { status: "success", message: "Informations utilisateur mises à jour." };
  } catch {
    return { status: "error", message: SETTINGS_SERVICE_ERROR };
  }
}

export async function savePriceProviderConfigurationAction(
  _state: SettingsActionState,
  formData: FormData,
): Promise<SettingsActionState> {
  const profile = await getActiveProfile();
  if (!profile) return { status: "error", message: SETTINGS_SERVICE_ERROR };

  const validation = validatePriceProviderConfiguration(formData);
  if (!validation.ok) return { status: "error", message: validation.message };

  try {
    const existing = (await getCurrentPriceProviderConfigurations())
      .find((configuration) => configuration.slot === validation.value.slot);
    if (!validation.value.apiKey && !existing) {
      return { status: "error", message: "La clé API est obligatoire." };
    }
    if (!validation.value.apiKey && existing?.adapter !== validation.value.adapter) {
      return { status: "error", message: "Saisissez une nouvelle clé lorsque vous changez de fournisseur." };
    }
    await saveCurrentPriceProviderConfiguration(validation.value);
    let keyIsValid: boolean | null = null;
    // Marketstack remains untested: key acceptance is not instrument or usage qualification.
    if (validation.value.active && validation.value.adapter && validation.value.adapter !== "marketstack") {
      const credential = await getPriceProviderRuntimeCredential(validation.value.slot);
      if (!credential || credential.adapter !== validation.value.adapter) {
        throw new Error("PRICE_PROVIDER_CREDENTIAL_UNAVAILABLE");
      }
      keyIsValid = credential.adapter === "twelve_data"
        ? await validateTwelveDataCredential(credential.apiKey)
        : await validateEodhdCredential(credential.apiKey);
      await setPriceProviderValidationStatus(
        validation.value.slot,
        keyIsValid ? "validated" : "invalid",
        new Date().toISOString(),
      );
    }
    revalidatePath("/settings");
    if (validation.value.adapter === "marketstack") {
      return { status: "success", message: "Configuration Marketstack conservée. Préparation désactivée : couverture et droits d’usage non établis." };
    }
    if (keyIsValid === false) {
      return { status: "error", message: "La clé API est invalide." };
    }
    return {
      status: "success",
      message: validation.value.apiKey && existing
        ? "Fournisseur et clé API remplacés de manière sécurisée."
        : validation.value.apiKey
          ? "Fournisseur et clé API enregistrés de manière sécurisée."
          : "Configuration du fournisseur enregistrée.",
    };
  } catch {
    return { status: "error", message: "La configuration du fournisseur n’a pas pu être enregistrée." };
  }
}

export async function deletePriceProviderConfigurationAction(
  _state: SettingsActionState,
  formData: FormData,
): Promise<SettingsActionState> {
  const profile = await getActiveProfile();
  if (!profile) return { status: "error", message: SETTINGS_SERVICE_ERROR };
  const slot = Number(formData.get("slot"));
  if (!Number.isInteger(slot) || slot < 1 || slot > 10) {
    return { status: "error", message: "L’emplacement fournisseur est invalide." };
  }
  try {
    await deleteCurrentPriceProviderConfiguration(slot);
    revalidatePath("/settings");
    return { status: "success", message: "Configuration et clé du fournisseur supprimées." };
  } catch {
    return { status: "error", message: "La configuration du fournisseur n’a pas pu être supprimée." };
  }
}
