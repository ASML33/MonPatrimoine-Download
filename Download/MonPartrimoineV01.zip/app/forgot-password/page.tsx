import { forgotPasswordAction } from "@/app/auth-actions";
import { AuthForm } from "@/app/components/auth-form";
import { AuthShell } from "@/app/components/auth-shell";

export default function ForgotPasswordPage() {
  return (
    <AuthShell
      title="Mot de passe oublié"
      description="Saisissez votre identifiant ou votre adresse e-mail."
    >
      <AuthForm
        action={forgotPasswordAction}
        fields={[
          {
            name: "identifier",
            label: "Identifiant / Email",
            type: "text",
            autoComplete: "username",
          },
        ]}
        submitLabel="Envoyer le lien"
        footer={{ href: "/login", label: "Retour à la connexion" }}
      />
    </AuthShell>
  );
}
