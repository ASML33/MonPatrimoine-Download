export default function HistoryLoading() {
  return <p role="status" className="p-6">Chargement de l’historique…</p>;
}
