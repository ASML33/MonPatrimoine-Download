import { redirect } from "next/navigation";
import Link from "next/link";
import { DashboardHeader } from "@/app/components/dashboard-header";
import { getPageProfile } from "@/lib/auth/render-context";
import { asSettingsRecord, readProfileSettings } from "@/lib/settings/settings-core";
import { readThemePreference } from "@/lib/theme/theme-core";
import { readDailyHistory, readLegacyHistory, readLiquidSavingsHistoryInputs, HISTORY_PAGE_SIZE, historyPageNumber, historyAnchor } from "@/lib/patrimony/daily-history";
import { historicalDate, historicalNet, historicalSourceFor, selectHistoricalObservations, type HistoricalObservation } from "@/lib/patrimony/historical-observations";
import { formatMoney } from "@/lib/cash/money";
import { correctedHistoricalObservation } from "@/lib/patrimony/approved-contract-corrections";
import { projectLiquidSavingsObservation } from "@/lib/patrimony/liquid-savings-history";
export const dynamic = "force-dynamic";

function Observation({ row }: { row: HistoricalObservation }) {
  return <>
    <p className="mt-3 text-sm">{row.result.engineVersion === "patrimony-legacy-import-v1" ? "Import historique" : "Capture native"} · {historicalDate(row.business_date)} · révision {row.revision}</p>
    {row.result.report.contracts.map((contract) => <div key={contract.id} className="mt-3 border-t border-[var(--app-border)] pt-3 text-sm">
      <p>{contract.name} · brut {formatMoney(contract.grossEur, "EUR")} · net source {historicalNet(contract) === null ? "Indisponible" : formatMoney(historicalNet(contract)!, "EUR") + (contract.legacyNetEur !== undefined && contract.netEstimatedEur === null ? " (estimation legacy)" : "")}</p>
      <p>{contract.fiscalWarnings.join(" ")}</p>
    </div>)}
    {row.result.legacy ? <p className="mt-3 text-sm">Total source conservé : {row.result.legacy.sourceTotalEur == null ? "Inconnu" : formatMoney(row.result.legacy.sourceTotalEur, "EUR")} · indicateur source, pas un brut/net global homogène. Aucun recalcul fiscal historique implicite.</p> : null}
  </>;
}

export default async function HistoryPage({ searchParams }: { searchParams: Promise<{ page?: string; until?: string }> }) {
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (current.status !== "active") redirect("/");
  const theme = readThemePreference(asSettingsRecord(documents.interface_preferences));
  const settings = readProfileSettings(documents);
  const params = await searchParams;
  const page = historyPageNumber(params.page);
  const until = historyAnchor(params.until);
  const pageHref = (number: number) => "/reports/history?page=" + number + "&until=" + encodeURIComponent(until);
  // Group by civil date before pagination: revisions remain secondary traces.
  // Readers fetch in API-sized batches; errors never become successful empty lists.
  const loaded = await Promise.all([readDailyHistory(), readLegacyHistory(), readLiquidSavingsHistoryInputs()]).then(([daily, legacy, liquid]) => {
    const sources = legacy.filter(source => Date.parse(source.imported_at ?? "") <= Date.parse(until));
    const groups = selectHistoricalObservations(daily.filter((row) => Date.parse(row.captured_at) <= Date.parse(until))).reverse().map(group => {
      const corrected = correctedHistoricalObservation(group.selected, sources);
      const projected=projectLiquidSavingsObservation(corrected,liquid.contracts,liquid.balances);
      if(projected===group.selected)return group;
      return { ...group, selected: projected, traces: [group.selected, ...(corrected!==group.selected && projected!==corrected ? [corrected] : []), ...group.traces], authority: `${group.authority}${corrected!==group.selected?' · Correction manuelle approuvée':''}${projected!==corrected?' · Solde total daté':''}` };
    });
    for (const group of groups) historicalSourceFor(group.selected, sources);
    return { groups, sources };
  }).catch(() => null);
  const groups = loaded?.groups.slice((page - 1) * HISTORY_PAGE_SIZE, page * HISTORY_PAGE_SIZE);
  return <div data-theme={theme} className="min-h-screen bg-[var(--app-background)]">
    <DashboardHeader nickname={current.profile.nickname} displayName={settings.displayName} theme={theme} />
    <main className="mx-auto max-w-7xl p-6 text-[var(--app-foreground)]">
      <Link href="/" className="text-[var(--app-gold)]">Retour au tableau de bord</Link>
      <h1 className="mt-5 text-3xl font-bold">Historique quotidien</h1>
      <p className="mt-3 text-sm">Une observation par date civile Europe/Paris. Sources et révisions conservées dans les traces secondaires. Une journée absente reste inconnue. Les totaux d’épargne liquide corrigés sont projetés à partir de leur date d’effet ; les captures sources restent accessibles dans les traces.</p>
      <nav aria-label="Pagination de l’historique" className="mt-4 flex flex-wrap gap-4 text-sm">
        {page > 1 ? <Link href={pageHref(page - 1)}>Page précédente</Link> : null}
        <span>Page {page} · {HISTORY_PAGE_SIZE} dates maximum</span>
        {loaded && loaded.groups.length > page * HISTORY_PAGE_SIZE ? <Link href={pageHref(page + 1)}>Page suivante</Link> : null}
      </nav>
      {groups === undefined ? <p role="status" className="mt-6">Historique indisponible. Les sources et leurs autorités doivent pouvoir être vérifiées.</p> : !groups.length ? <p className="mt-6">Aucune journée capturée.</p> : groups.map((group) => {
        const source = historicalSourceFor(group.selected, loaded!.sources);
        return <details key={group.date} className="settings-card mt-4">
          <summary className="cursor-pointer">{historicalDate(group.date)} · brut {group.selected.result.report.summary.grossEur === null ? "Indisponible" : formatMoney(group.selected.result.report.summary.grossEur, "EUR")}{group.selected.result.grossKind === "partial" ? " (partiel)" : ""} · {group.authority}</summary>
          <Observation row={group.selected} />
          <details className="mt-4 border-t border-[var(--app-border)] pt-3 text-sm">
            <summary className="cursor-pointer">Traces et sources d’origine</summary>
            {group.traces.map((row,index) => <div key={`${row.id}:${index}`} className="mt-3"><p className="font-semibold">Observation secondaire — hors total affiché</p><Observation row={row} /></div>)}
            {source ? <dl className="mt-3 grid gap-2 sm:grid-cols-2">{Object.entries(source.payload.sourceValues ?? {}).filter(([key]) => !key.endsWith(" Parts") && !key.endsWith(" Obj")).map(([key, value]) => <div key={key}><dt className="text-[var(--app-muted)]">Source originale : {key}</dt><dd>{value === null ? /^(PEA|CTO) .+ Valo$/.test(key) ? "Absent" : "Inconnu" : formatMoney(Number(value), "EUR")}</dd></div>)}</dl> : null}
          </details>
        </details>;
      })}
    </main>
  </div>;
}
