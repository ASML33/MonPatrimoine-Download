import { redirect } from "next/navigation";

import { resetPasswordAction } from "@/app/auth-actions";
import { AuthForm } from "@/app/components/auth-form";
import { AuthShell } from "@/app/components/auth-shell";
import { getCurrentUser } from "@/lib/auth/user";

export const dynamic = "force-dynamic";

export default async function ResetPasswordPage() {
  if (!(await getCurrentUser())) redirect("/login?recovery=invalid");

  return (
    <AuthShell
      title="Nouveau mot de passe"
      description="Choisissez un nouveau mot de passe pour votre compte."
    >
      <AuthForm
        action={resetPasswordAction}
        fields={[
          {
            name: "password",
            label: "Nouveau mot de passe",
            type: "password",
            autoComplete: "new-password",
          },
          {
            name: "confirmation",
            label: "Confirmer le mot de passe",
            type: "password",
            autoComplete: "new-password",
          },
        ]}
        submitLabel="Enregistrer"
      />
    </AuthShell>
  );
}
