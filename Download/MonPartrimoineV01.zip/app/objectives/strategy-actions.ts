"use server";
import type { SettingsActionState } from "@/lib/settings/settings-core";
export async function updateStrategyAction(): Promise<SettingsActionState> {
  return {status:"error",message:"Rechargez la page pour utiliser l’objectif général partagé. (OBJ-OBSOLETE-WRITER)"};
}
