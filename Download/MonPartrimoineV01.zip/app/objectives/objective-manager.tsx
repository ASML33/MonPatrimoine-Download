"use client";
import { formatMoney } from "@/lib/cash/money";

import { useActionState, useCallback, useEffect, useMemo, useState } from "react";
import { FieldHelp } from "@/app/settings/field-help";
import type { AssetObjectiveScope, ObjectiveActionState, ObjectiveDimension, ObjectiveKind } from "@/lib/objectives/objective-core";
import { objectiveStatus, objectiveFormMessage, assetObjectiveScopeNotice, assetObjectiveReason } from "@/lib/objectives/objective-core";
import { saveObjectivesAction } from "./actions";

export function DimensionForm({ dimension, revision, onRevision, scope }: { dimension: ObjectiveDimension; revision: number; onRevision: (revision: number) => void; scope?: AssetObjectiveScope }) {
  const [state, action, pending] = useActionState(saveObjectivesAction, { status: "idle" } as ObjectiveActionState);
  const current = useMemo(() => new Map(dimension.values.map((value) => [value.targetId, value.targetPercent])),[dimension.values]);
  const [draft, setDraft] = useState<Record<string, string>>(() => Object.fromEntries(dimension.options.map((option) => [option.id, String(current.get(option.id) ?? "")])));
  const hidden = dimension.values.filter(value=>!dimension.options.some(option=>option.id===value.targetId));
  const hiddenTotal = hidden.reduce((sum,value)=>sum+Math.max(0,value.targetPercent),0);
  const total = useMemo(() => dimension.options.reduce((sum, option) => {
    const raw = draft[option.id] ?? String(current.get(option.id) ?? '');
    const value = Number(raw.replace(",", "."));
    return sum + (Number.isFinite(value) && value > 0 ? value : 0);
  }, hiddenTotal), [draft, dimension.options, current, hiddenTotal]);
  useEffect(() => { if (state.revision !== undefined) onRevision(state.revision); }, [state.revision, onRevision]);
  return <form action={action} className="settings-card settings-form mt-6">
    {scope && <input type="hidden" name="scope_contract_id" value={scope.contractId} />}
    <input type="hidden" name="kind" value={dimension.kind} />
    <input type="hidden" name="revision" value={Math.max(state.revision ?? 0, revision)} />
    <header className="settings-card-header justify-between">
      <div><h2 className="settings-card-title">Objectifs par {dimension.label.toLowerCase()}</h2>
        <p className="settings-card-description">Cette dimension est indépendante des deux autres.</p></div>
      <div className="text-right"><strong>{total.toLocaleString("fr-FR", { maximumFractionDigits: 2 })} %</strong>
        <p className={`text-xs ${total > 100 ? "text-red-500" : "text-[var(--app-muted)]"}`}>{total > 100 ? "Total supérieur à 100 %" : objectiveStatus(total)}</p></div>
    </header>
    {scope && hidden.length>0 && <p className="text-sm text-[var(--app-muted)]">{hidden.length} cible(s) masquée(s) conservée(s), dont {hiddenTotal.toLocaleString('fr-FR',{maximumFractionDigits:2})} % inclus dans le total du contrat. Le masquage ne les supprime pas.</p>}
    <fieldset disabled={pending} className="grid gap-3">
      {dimension.options.map((option) => <label key={option.id} className="grid grid-cols-[minmax(0,1fr)_6rem] items-center gap-3 text-sm">
        <span className="min-w-0 break-words">{option.label}{scope && <small className="mt-1 block text-[var(--app-muted)]">{comparisonLabel(scope.comparisons[option.id])}</small>}</span>
        <span className="flex items-center gap-2"><input className="settings-input text-right" type="number" inputMode="decimal" name={`target_${option.id}`} min={dimension.kind === "asset" ? -1 : 0.01} max="100" step="0.01" value={draft[option.id] ?? String(current.get(option.id) ?? '')} onChange={(event) => setDraft((values) => ({ ...values, [option.id]: event.target.value }))} aria-label={`Cible ${option.label}`} /><span>%</span></span>
      </label>)}
      {!dimension.options.length && <p className="text-sm text-[var(--app-muted)]">{scope ? 'Aucun actif actif rattaché à ce contrat.' : 'Aucun élément disponible.'}</p>}
      {dimension.kind === "asset" && <div className="flex items-center gap-2 text-xs text-[var(--app-muted)]"><span>Valeur spéciale -1</span><FieldHelp id={`asset-objective-exclusion-${scope?.contractId ?? 'legacy'}`} label="Exclusion du pilotage">Un actif à -1 reste détenu, valorisé et visible, mais il est exclu du pilotage fondé sur les objectifs.</FieldHelp></div>}
      <button className="settings-primary-button" type="submit" disabled={total > 100}>{pending ? "Enregistrement…" : "Enregistrer"}</button>
    </fieldset>
    {state.message && <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{objectiveFormMessage(state, dimension)}</p>}
  </form>;
}

export function ObjectiveManager({ dimensions, revision, assetScopes = [] }: { dimensions: ObjectiveDimension[]; revision: number; assetScopes?: AssetObjectiveScope[] }) {
  const [selected, setSelected] = useState<ObjectiveKind>("envelope_type");
  const [currentRevision, setCurrentRevision] = useState(revision);
  const [saved,setSaved]=useState(false);
  const acceptRevision=useCallback((next:number)=>{setCurrentRevision(current=>Math.max(current,next));setSaved(true);},[]);
  const selectedDimension = dimensions.find((dimension) => dimension.kind === selected)!;
  return <section className="mt-8">
    <div role="tablist" aria-label="Dimensions des objectifs" className="grid gap-2 sm:grid-cols-3">
      {dimensions.map((dimension) => <button key={dimension.kind} type="button" role="tab" aria-selected={selected === dimension.kind} onClick={() => setSelected(dimension.kind)} className="border border-[var(--app-border)] px-4 py-3 text-sm font-semibold focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)] data-[selected=true]:border-[var(--app-gold)] data-[selected=true]:text-[var(--app-gold)]" data-selected={selected === dimension.kind}>{dimension.label}</button>)}
    </div>
    {saved&&<p role="status" className="mt-3 text-sm">Objectifs enregistrés. Les comparaisons portent sur les cibles enregistrées.</p>}
    <div role="tabpanel">{selected==='asset' ? <AssetTargets scopes={assetScopes} legacy={selectedDimension} revision={currentRevision} onRevision={acceptRevision}/> : <DimensionForm key={selected} dimension={selectedDimension} revision={currentRevision} onRevision={acceptRevision} />}</div>
  </section>;
}

function comparisonLabel(value: AssetObjectiveScope['comparisons'][string] | undefined) {
  const number=(n:number|null|undefined)=>n==null?'indisponible':n.toLocaleString('fr-FR',{maximumFractionDigits:2});
  return `Poids actuel : ${number(value?.currentPercent)} % · base BRUT espèces incluses : ${formatMoney(value?.denominatorEur,"EUR")} · écart enregistré : ${number(value?.deltaPoints)} points. ${assetObjectiveReason(value?.reason)}`;
}
function LegacyTarget({value,label,scope,revision,onRevision}:{value:ObjectiveDimension['values'][number];label:string;scope:AssetObjectiveScope;revision:number;onRevision:(revision:number)=>void}) {
  const [state,action,pending]=useActionState(saveObjectivesAction,{status:'idle'} as ObjectiveActionState);
  useEffect(()=>{if(state.revision!==undefined)onRevision(state.revision);},[state.revision,onRevision]);
  return <form action={action} className="mt-3 grid gap-2 rounded border border-[var(--app-border)] p-3 text-sm">
    <p>{label} · {value.targetPercent===-1?'Exclusion globale -1':`${value.targetPercent} % sans contrat`} → {scope.label}</p>
    <input type="hidden" name="kind" value="asset"/><input type="hidden" name="revision" value={Math.max(state.revision??0,revision)}/><input type="hidden" name="scope_contract_id" value={scope.contractId}/><input type="hidden" name="legacy_asset" value={value.targetId}/>
    <div className="flex flex-wrap gap-3">{value.targetPercent!==-1&&<button disabled={pending} name="operation" value="assign" className="settings-secondary-button">Affecter au contrat en conservant {value.targetPercent} %</button>}<button disabled={pending} name="operation" value="remove" className="settings-secondary-button">Retirer explicitement {value.targetPercent===-1?'l’exclusion globale':'la cible héritée'}</button></div>
    {state.message&&<p role="status">{objectiveFormMessage(state, scope.dimension)}</p>}
  </form>;
}
export function AssetTargets({scopes,legacy,revision,onRevision}:{scopes:AssetObjectiveScope[];legacy:ObjectiveDimension;revision:number;onRevision:(revision:number)=>void}) {
  const [id,setId]=useState(scopes[0]?.contractId??'');const scope=scopes.find(s=>s.contractId===id);
  return <div className="mt-6"><p className="text-sm">{assetObjectiveScopeNotice}</p><label className="mt-4 block">Contrat de référence<select className="settings-input mt-2" value={id} onChange={e=>setId(e.target.value)}>{scopes.map(s=><option key={s.contractId} value={s.contractId}>{s.label}</option>)}</select></label>
    {scopes.map(item=>{const inherited=legacy.values.filter(v=>item.dimension.options.some(o=>o.id===v.targetId));return <div key={item.contractId} hidden={item.contractId!==id}>
      <DimensionForm dimension={item.dimension} scope={item} revision={revision} onRevision={onRevision}/>
      <section className="mt-6"><h3 className="font-semibold">Anciennes cibles non affectées et exclusions globales</h3><p className="text-sm">Aucune affectation automatique. Seuls les actifs actifs rattachés au contrat choisi sont proposés ; les autres cibles héritées restent conservées. Un conflit refuse l’opération sans écrasement. Un retrait d’exclusion globale concerne tous les contrats.</p>{inherited.map(v=><LegacyTarget key={v.targetId} value={v} label={legacy.options.find(o=>o.id===v.targetId)?.label??'Titre indisponible'} scope={item} revision={revision} onRevision={onRevision}/>)}{!inherited.length&&<p className="text-sm">Aucune cible héritée applicable aux actifs affichés.</p>}</section>
    </div>;})}
    {!scope&&<p>Aucun contrat accessible.</p>}
  </div>;
}
