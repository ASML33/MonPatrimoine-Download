"use server";

import { isContractInUserScope } from "@/lib/contracts/contract-scope";
import { revalidatePath } from "next/cache";
import { getCurrentProfile } from "@/lib/auth/profile";
import { createClient } from "@/lib/supabase/server";
import { contractObjectiveOptions, isObjectiveId, isObjectiveKind, ObjectiveFormError, objectiveError, parseObjectiveForm, type ObjectiveActionState } from "@/lib/objectives/objective-core";

export async function saveObjectivesAction(_state: ObjectiveActionState, form: FormData): Promise<ObjectiveActionState> {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active") return { status: "error", message: "Connectez-vous avec le compte autorisé." };
  const kind = String(form.get("kind") ?? "");
  const revision = Number(form.get("revision"));
  if (!isObjectiveKind(kind) || !Number.isSafeInteger(revision) || revision < 0) return { status: "error", message: "Demande invalide." };
  let targets;
  try { targets = parseObjectiveForm(form, kind); }
  catch (error) {
    if (error instanceof ObjectiveFormError) return { status: "error", message: error.message, targetId: error.targetId, row: error.row };
    return { status: "error", message: error instanceof Error ? error.message : "Objectifs invalides." };
  }
  if (kind === "contract" && targets.some(({ targetId }) => !isContractInUserScope(targetId))) return { status: "error", message: "Contrat indisponible." };
  const supabase = await createClient();
  const scopeContract = String(form.get("scope_contract_id") ?? "");
  const legacyAsset = String(form.get("legacy_asset") ?? "");
  const operation = String(form.get("operation") ?? "save");
  if (scopeContract && (kind !== 'asset' || !isContractInUserScope(scopeContract) || !isObjectiveId(scopeContract))) return {status:'error',message:'Contrat indisponible.'};
  if (legacyAsset && (!isObjectiveId(legacyAsset) || !['assign','remove'].includes(operation))) return {status:'error',message:'Action invalide.'};
  if (scopeContract) {
    // The RPC replaces the entire contract partition. Merge only explicitly
    // submitted visible controls, preserving hidden and omitted stored targets.
    // The RPC's expected revision makes the read/merge safe against concurrent
    // objective writes: a changed partition/revision refuses the whole save.
    const owner = current.profile.auth_user_id;
    const [holdings, assets, stored] = await Promise.all([
      supabase.from('positions').select('contract_id,asset_id,is_active').eq('user_id',owner).eq('contract_id',scopeContract).eq('is_active',true),
      supabase.from('assets').select('id,is_active').eq('owner_user_id',owner),
      supabase.from('target_allocations').select('target_asset_id,target_percent').eq('user_id',owner).eq('target_kind','asset').eq('scope_contract_id',scopeContract),
    ]);
    if (holdings.error || assets.error || stored.error) return {status:'error',message:'Les cibles existantes ne peuvent pas être vérifiées. Vos saisies sont conservées ; aucun enregistrement effectué.'};
    const visible = new Set(contractObjectiveOptions((assets.data??[]).map(a=>({id:a.id,label:'',isActive:a.is_active})),holdings.data??[],scopeContract).map(a=>a.id));
    const edited = new Set([...form.keys()].filter(name=>name.startsWith('target_')).map(name=>name.slice(7)));
    if ([...edited].some(id=>!visible.has(id)) || legacyAsset && !visible.has(legacyAsset)) return {status:'error',message:'Un titre saisi n’est plus actif ou rattaché à ce contrat. Rechargez la page ; aucune cible n’a été remplacée.'};
    targets = [...(stored.data??[]).filter(t=>!edited.has(t.target_asset_id)).map(t=>({targetId:t.target_asset_id,targetPercent:Number(t.target_percent)})),...targets];
  }
  const payload = targets.map(({targetId,targetPercent})=>({target_id:targetId,target_percent:targetPercent}));
  const result = scopeContract ? await supabase.rpc('save_asset_contract_targets', {
    requested_contract:scopeContract, requested_targets:payload, expected_revision:revision,
    assign_legacy_asset:operation==='assign'?legacyAsset:null, remove_legacy_asset:operation==='remove'?legacyAsset:null,
  }).single() : await supabase.rpc("save_target_allocations", {
    requested_kind: kind,
    requested_targets: targets.map(({ targetId, targetPercent }) => ({ target_id: targetId, target_percent: targetPercent })),
    expected_revision: revision,
  }).single();
  if (result.error) return { status: "error", message: objectiveError(result.error.code) };
  revalidatePath("/objectives");
  revalidatePath("/reports");
  revalidatePath("/ai");
  const saved = result.data as { revision: number | string };
  return { status: "success", message: "Objectifs enregistrés.", revision: Number(saved.revision) };
}
