import { redirect } from "next/navigation";
import { DashboardHeader } from "@/app/components/dashboard-header";
import { getPageProfile } from "@/lib/auth/render-context";
import { getObjectives } from "@/lib/objectives/objectives";
import { asSettingsRecord, readProfileSettings } from "@/lib/settings/settings-core";
import { readThemePreference } from "@/lib/theme/theme-core";
import { readSharedObjective } from "@/lib/ai/input-history";
import { StrategyForm } from "./strategy-form";
import { ObjectiveManager } from "./objective-manager";

export const dynamic = "force-dynamic";

export default async function ObjectivesPage() {
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (current.status !== "active") redirect("/");
  const theme = readThemePreference(asSettingsRecord(documents.interface_preferences));
  const settings = readProfileSettings(documents);
  const data = await getObjectives(current.profile.auth_user_id).catch(() => null);
  return <div data-theme={theme} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]">
    <DashboardHeader nickname={current.profile.nickname} displayName={settings.displayName} theme={theme} />
    <main className="mx-auto max-w-5xl px-4 py-10 sm:px-6 sm:py-14">
      <header className="max-w-3xl"><h1 className="text-3xl font-bold sm:text-4xl">Stratégie</h1>
        <p className="mt-3 text-sm leading-6 text-[var(--app-muted)] sm:text-base">Définissez séparément vos cibles par type d’enveloppe, contrat et actif. Un total inférieur à 100 % reste un brouillon.</p></header>
      <StrategyForm objective={readSharedObjective(documents.preferences)} />
      <section className="settings-card mt-6 min-w-0"><h2 className="settings-card-title">Répartition</h2>
      {data ? <ObjectiveManager {...data} /> : <p role="alert" className="mt-8 text-red-500">Les objectifs sont indisponibles. Réessayez ultérieurement.</p>}
      </section>
    </main>
  </div>;
}
