"use client";

import { useState } from "react";
import { AnalysisInputEditor } from "@/app/ai/analysis-input-editor";
import type { SharedObjective } from "@/lib/ai/input-history";

export function StrategyForm({ objective }: { objective: SharedObjective }) {
  const [value,setValue]=useState(objective.value);
  return <section className="settings-card mt-8 min-w-0">
    <AnalysisInputEditor field="additionalInformation" value={value} onChange={setValue} initialEntries={objective.entries} initialRevision={objective.revision} heading />
  </section>;
}
