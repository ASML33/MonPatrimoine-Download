import { redirect } from "next/navigation";

import { loginAction } from "@/app/auth-actions";
import { AuthForm } from "@/app/components/auth-form";
import { AuthShell } from "@/app/components/auth-shell";
import { getCurrentUser } from "@/lib/auth/user";

export const dynamic = "force-dynamic";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ password?: string; recovery?: string }>;
}) {
  if (await getCurrentUser()) redirect("/");
  const params = await searchParams;

  return (
    <AuthShell
      title="Connexion"
      description={
        params.password === "updated"
          ? "Votre mot de passe a été mis à jour. Vous pouvez vous connecter."
          : params.recovery === "invalid"
            ? "Ce lien de récupération est invalide ou a expiré."
            : "Accédez à votre espace personnel."
      }
    >
      <AuthForm
        action={loginAction}
        fields={[
          {
            name: "identifier",
            label: "Identifiant / Email",
            type: "text",
            autoComplete: "username",
          },
          {
            name: "password",
            label: "Mot de passe",
            type: "password",
            autoComplete: "current-password",
          },
        ]}
        submitLabel="Connexion"
        footer={{
          href: "/forgot-password",
          label: "Mot de passe oublié",
        }}
      />
    </AuthShell>
  );
}
