import Link from 'next/link';
import { envelopeCapabilities } from '@/lib/fiscal/fiscal-catalog-core';
import { describeFiscalModel } from '@/lib/fiscal/fiscal-model';
import { referenceModelSupported, type ReferenceUsage } from '@/lib/fiscal/reference-usage-core';
import type { ReferenceView } from '@/lib/fiscal/reference-reader';

const summary = 'min-h-11 cursor-pointer py-3 font-semibold';
function Usages({ id, usage }: { id: string; usage: ReferenceUsage }) {
  const reasons = usage.reasons[id] ?? [];
  return <details className="mt-4 border-t border-[var(--app-border)]">
    <summary className={summary}>Usages et références</summary>
    <p className="text-sm text-[var(--app-muted)]">Comptages par motif, non additionnables : une même preuve peut figurer dans plusieurs catégories. Aucune permission de suppression n’en découle.</p>
    {reasons.length ? ['configuration', 'business', 'history'].map(category => {
      const rows = reasons.filter(r => r.category === category);
      return rows.length ? <section key={category} className="mt-4"><h3 className="font-semibold">{{ configuration: 'Dépendances de configuration', business: 'Usages métier', history: 'Historique et provenance' }[category]}</h3><ul className="mt-2 grid gap-2 text-sm">{rows.map(r => <li key={r.reason}><strong>{r.count}</strong> · {r.reason}</li>)}</ul></section> : null;
    }) : <p className="mt-3 text-sm">Aucune référence identifiée dans les lectures disponibles. La couverture reste limitée ; l’absence de référence n’est pas établie.</p>}
  </details>;
}

export function ReferenceContent({ view, section }: { view: ReferenceView; section: 'types' | 'rules' }) {
  if (view.catalog.status !== 'available') return <p role="status" className="settings-card mt-6">Référentiels indisponibles. Le catalogue et ses usages n’ont pas pu être établis. Réessayez ultérieurement.{view.diagnostic ? ` Référence ${view.diagnostic}.` : ''}</p>;
  const catalog = view.catalog.data;
  return <>
    <h2 className="mt-8 text-xl font-semibold">Consultation et usages</h2>
    <p className="mt-4 text-sm text-[var(--app-muted)]">Modèles et usages conservés pour la consultation. Aucun contrat ni historique n’adopte automatiquement une modification. Les autres préférences restent dans <Link className="underline" href="/settings">Paramètres</Link>.</p>
    <details className="mt-5 rounded-lg border border-[var(--app-border)] px-4" open={view.usage.limits.some(l => /partielle|inconnu|indisponible/.test(l))}>
      <summary className={summary}>Couverture des usages et limites</summary>
      <ul className="mb-4 grid list-disc gap-2 pl-5 text-sm">{view.usage.limits.map(l => <li key={l}>{l}</li>)}</ul>
    </details>
    <div className="mt-6 grid min-w-0 gap-5">
      {section === 'types' ? <>
        {!catalog.types.length ? <p className="settings-card">Aucun type d’enveloppe dans le catalogue disponible.</p> : null}
        {catalog.types.map(t => <article key={t.id} className="settings-card min-w-0 break-words [overflow-wrap:anywhere]">
          <h2 className="text-xl font-semibold">{t.label}</h2>
          <p className="mt-1 text-sm text-[var(--app-muted)]">{t.is_standard ? 'Standard' : 'Personnalisé'} · {t.is_active ? 'Actif' : 'Inactif'}</p>
          <p className="mt-4 text-sm">{envelopeCapabilities(t.code)}</p>
          {!t.is_standard ? <p className="mt-2 text-sm">Parcours générique : le libellé ne confère aucune capacité spécialisée de PEA, d’immobilier ou d’épargne salariale. Les présentations spécifiques aux contrats à titres ne sont pas automatiquement activées.</p> : null}
          <details className="mt-4"><summary className={summary}>Compatibilités et défaut de création</summary>
            <ul className="grid gap-2 text-sm">{catalog.allowed.filter(a => a.envelope_type_id === t.id).map(a => <li key={a.fiscal_regime_id}>{catalog.regimes.find(r => r.id === a.fiscal_regime_id)?.label ?? 'Régime non disponible'} · compatibilité {a.is_active ? 'active' : 'inactive'}</li>)}</ul>
            {!catalog.allowed.some(a => a.envelope_type_id === t.id) ? <p className="text-sm">Aucune compatibilité configurée.</p> : null}
            <p className="mt-3 text-sm">Régime proposé : {t.default_fiscal_regime_id ? catalog.regimes.find(r => r.id === t.default_fiscal_regime_id)?.label ?? 'Référence indisponible' : 'Aucun'}. Version : {t.default_fiscal_rule_id ? catalog.rules.find(r => r.id === t.default_fiscal_rule_id)?.name ?? 'Référence indisponible' : 'Aucune'}.</p>
            <p className="mt-2 text-sm text-[var(--app-muted)]">Le défaut est seulement proposé aux nouveaux contrats ; aucune adoption automatique par les contrats existants.</p>
          </details>
          <Usages id={t.id} usage={view.usage}/>
          <details className="mt-3 text-sm"><summary className={summary}>Identité technique</summary><p>Code : {t.code} · Révision : {t.configuration_revision}</p></details>
        </article>)}
      </> : <>
        <p className="text-sm">Un paramètre personnel ne certifie pas une règle légale. Ajouter un taux ne rend pas une fiscalité quelconque calculable.</p>
        {!catalog.regimes.length ? <p className="settings-card">Aucun régime dans le catalogue disponible.</p> : null}
        {catalog.regimes.map(r => <article key={r.id} className="settings-card min-w-0 break-words [overflow-wrap:anywhere]">
          <h2 className="text-xl font-semibold">{r.label}</h2>
          <p className="mt-1 text-sm text-[var(--app-muted)]">{r.is_active ? 'Actif' : 'Inactif'} · {r.owner_user_id ? 'Paramétrage personnel' : 'Référence commune'} · {r.calculation_kind === 'unsupported' ? 'Calcul non pris en charge' : r.calculation_kind === 'manual' ? 'Valeurs déclarées' : 'Modèle de calcul limité'}</p>
          <p className="mt-3 text-sm">{r.description}</p>
          <Usages id={r.id} usage={view.usage}/>
          {!catalog.rules.some(f => f.fiscalRegimeId === r.id) ? <p className="mt-4 text-sm">Aucune version exécutable disponible : NET fiscal indisponible, sauf valeur fournie par une source explicitement qualifiée.</p> : null}
          {catalog.rules.filter(f => f.fiscalRegimeId === r.id).map(f => {
            const supported = referenceModelSupported(f) && ['exempt', 'pea_liquidation', 'cto_liquidation', 'interest_gain', 'manual'].includes(r.calculation_kind);
            const model = supported ? describeFiscalModel(f, r.calculation_kind) : null;
            return <details key={f.id} className="mt-4 rounded-lg border border-[var(--app-border)] px-4">
              <summary className={summary}>{f.name ?? `Version ${f.versionNumber}`}<span className="mt-1 block text-sm font-normal text-[var(--app-muted)]">v{f.versionNumber} · Effet {f.effectiveFrom} · {f.status === 'verified' ? 'Référence vérifiée ou paramétrage confirmé' : f.status === 'retired' ? 'Ancienne référence retirée' : 'Brouillon'}</span></summary>
              {model ? <div className="grid gap-3 pb-4 text-sm"><p className="font-semibold">{model.mode}</p><p>{model.missing}</p><p>{model.limits}</p>
                {[f.irBaseType, f.psBaseType].includes('positive_interest_gain') ? <p>Les intérêts documentés sont une opération du moteur, mais le Rapport et les graphiques ne fournissent actuellement pas cette assiette. Un calcul fondé sur les intérêts reste indisponible dans ces parcours.</p> : null}
                <details><summary className={summary}>Modèle, paramètres et données requises</summary><p>{model.formula}</p><ul className="mt-3 grid list-disc gap-2 pl-5">{[...model.requirements, ...model.conditions].map(v => <li key={v}>{v}</li>)}</ul><p className="mt-3">{model.rounding}</p><p className="mt-3">Provenance : {f.source.startsWith('https://') ? <a className="underline" href={f.source} target="_blank" rel="noreferrer">{f.sourceTitle}</a> : f.sourceTitle} · référence du {f.verifiedOn}. {f.description}</p></details>
              </div> : <p className="pb-4 text-sm">Modèle inconnu ou non pris en charge : aucun calcul fiable ne peut être présenté.</p>}
              <Usages id={f.id} usage={view.usage}/>
            </details>;
          })}
        </article>)}
        <details className="settings-card"><summary className={summary}>Anciennes références non structurées</summary><p className="text-sm">Conservées pour consultation ; elles ne sont pas présentées comme des versions exécutables du moteur actuel.</p>{view.legacy.length ? <ul className="mt-3 grid gap-3 text-sm">{view.legacy.map(r => <li key={r.id}>{r.rule_name} · Effet {r.valid_from}<Usages id={r.id} usage={view.usage}/></li>)}</ul> : <p className="mt-3 text-sm">Aucune référence ancienne identifiée dans les lectures disponibles.</p>}</details>
      </>}
    </div>
  </>;
}
