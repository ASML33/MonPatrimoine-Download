import {redirect} from 'next/navigation';export async function ReferencePage(){redirect('/envelopes');}
