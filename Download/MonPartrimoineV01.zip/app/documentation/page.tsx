import type { Metadata } from "next";
import { redirect } from "next/navigation";

import { DashboardHeader } from "@/app/components/dashboard-header";
import { getPageProfile } from "@/lib/auth/render-context";
import { asSettingsRecord, readProfileSettings } from "@/lib/settings/settings-core";
import { readThemePreference } from "@/lib/theme/theme-core";
import { DocumentationLibrary } from "./documentation-library";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Documentation | MonPatrimoine" };

export default async function DocumentationPage() {
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (current.status !== "active") redirect("/");

  const theme = readThemePreference(asSettingsRecord(documents.interface_preferences));
  return (
    <div data-theme={theme} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]">
      <DashboardHeader
        nickname={current.profile.nickname}
        displayName={readProfileSettings(documents).displayName}
        theme={theme}
      />
      <main className="mx-auto grid max-w-5xl gap-5 px-4 py-6 sm:px-6 sm:py-8">
        <h1 className="text-2xl font-semibold sm:text-3xl">Documentation</h1>
        <DocumentationLibrary />
      </main>
    </div>
  );
}
