"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";
import {
  DOCUMENTS_ENDPOINT, DOCUMENT_ACCEPT, DOCUMENT_FORMAT_LABELS, DOCUMENT_MAX_BYTES, DOCUMENT_MIME_TYPES,
  documentExtension, type LibraryDocument,
} from "@/lib/documentation/contracts";

const panel = "min-w-0 rounded-lg border border-[var(--app-border)] bg-[var(--app-surface)] p-4 sm:p-5";
const action = "min-h-11 rounded border border-[var(--app-border)] px-3 py-2 text-sm font-medium hover:bg-[var(--app-hover)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)] disabled:opacity-50";
const muted = "text-sm text-[var(--app-muted)]";
const size = new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 1 });
const date = new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeZone: "Europe/Paris" });

type Feedback = { error: boolean; message: string };
type Operation = "upload" | "download" | "delete" | "refresh";
type ActiveOperation = { kind: Operation; key?: string };

function formatSize(bytes: number) {
  if (bytes >= 1024 * 1024) return `${size.format(bytes / (1024 * 1024))} Mio`;
  if (bytes >= 1024) return `${size.format(bytes / 1024)} Kio`;
  return `${size.format(bytes)} o`;
}

function documentUrl(key: string) {
  return `${DOCUMENTS_ENDPOINT}?document=${encodeURIComponent(key)}`;
}

async function checkResponse(response: Response) {
  if (response.redirected || response.status === 401) {
    throw new Error("Connectez-vous à nouveau pour reprendre cette opération.");
  }
  if (response.ok) return;
  const body = await response.json().catch(() => null);
  throw new Error(typeof body?.error === "string" ? body.error :
    "L’opération a échoué. Réessayez.");
}

async function loadDocuments(signal?: AbortSignal): Promise<LibraryDocument[]> {
  const response = await fetch(DOCUMENTS_ENDPOINT, { cache: "no-store", signal });
  await checkResponse(response);
  const { documents } = await response.json();
  return documents;
}

function errorMessage(error: unknown) {
  return error instanceof Error && !(error instanceof TypeError)
    ? error.message
    : "L’opération a échoué. Réessayez.";
}

export function DocumentationLibrary() {
  const [documents, setDocuments] = useState<LibraryDocument[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [listError, setListError] = useState("");
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState<ActiveOperation | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<LibraryDocument | null>(null);
  const [deleteError, setDeleteError] = useState("");

  const input = useRef<HTMLInputElement>(null);
  const dialog = useRef<HTMLDialogElement>(null);
  const cancel = useRef<HTMLButtonElement>(null);
  const uploadId = useRef<string | null>(null);
  const operation = useRef<ActiveOperation | null>(null);

  useEffect(() => {
    const controller = new AbortController();
    loadDocuments(controller.signal).then(setDocuments).catch((error: unknown) => {
      if (!controller.signal.aborted) setListError(errorMessage(error));
    }).finally(() => {
      if (!controller.signal.aborted) setLoading(false);
    });
    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (deleteTarget && dialog.current && !dialog.current.open) {
      dialog.current.showModal();
      cancel.current?.focus();
    }
  }, [deleteTarget]);

  function begin(current: ActiveOperation) {
    if (operation.current || loading) return false;
    operation.current = current;
    setBusy(current);
    setFeedback(null);
    return true;
  }

  function end() {
    operation.current = null;
    setBusy(null);
  }

  async function refresh() {
    setListError("");
    try {
      setDocuments(await loadDocuments());
    } catch (error) {
      setListError(errorMessage(error));
    }
  }

  async function retryList() {
    if (!begin({ kind: "refresh" })) return;
    try {
      await refresh();
    } finally {
      end();
    }
  }

  async function upload(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!file || !begin({ kind: "upload" })) return;
    try {
      const extension = documentExtension(file.name.trim());
      if (!extension) throw new Error(`Formats acceptés : ${DOCUMENT_FORMAT_LABELS}.`);
      if (file.size > DOCUMENT_MAX_BYTES) throw new Error("La taille maximale est de 4 Mio par fichier.");
      uploadId.current ??= crypto.randomUUID();
      const response = await fetch(DOCUMENTS_ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": DOCUMENT_MIME_TYPES[extension],
          "X-Document-Name": encodeURIComponent(file.name),
          "X-Upload-Id": uploadId.current,
        },
        body: file,
      });
      await checkResponse(response);
      if (input.current) input.current.value = "";
      setFile(null);
      uploadId.current = null;
      setFeedback({ error: false, message: "Document ajouté." });
      await refresh();
    } catch (error) {
      setFeedback({ error: true, message: errorMessage(error) });
    } finally {
      end();
    }
  }

  async function download(document: LibraryDocument) {
    if (!begin({ kind: "download", key: document.key })) return;
    try {
      const response = await fetch(documentUrl(document.key), { cache: "no-store" });
      await checkResponse(response);
      const extension = documentExtension(document.name);
      if (!extension || response.headers.get("content-type") !== DOCUMENT_MIME_TYPES[extension]) {
        throw new Error("Le téléchargement a échoué. Réessayez.");
      }
      const url = URL.createObjectURL(await response.blob());
      const link = window.document.createElement("a");
      link.href = url;
      link.download = document.name;
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
      setFeedback({ error: false, message: "Téléchargement lancé." });
    } catch (error) {
      setFeedback({ error: true, message: errorMessage(error) });
    } finally {
      end();
    }
  }

  async function remove() {
    if (!deleteTarget || !begin({ kind: "delete", key: deleteTarget.key })) return;
    setDeleteError("");
    try {
      const response = await fetch(documentUrl(deleteTarget.key), { method: "DELETE" });
      await checkResponse(response);
      setDocuments((existing) => existing?.filter(({ key }) => key !== deleteTarget.key) ?? null);
      dialog.current?.close();
      setFeedback({ error: false, message: "Document supprimé." });
      await refresh();
    } catch (error) {
      setDeleteError(errorMessage(error));
    } finally {
      end();
    }
  }

  const unavailable = loading || busy !== null;
  return (
    <>
      <section className={panel} aria-labelledby="add-document">
        <h2 id="add-document" className="mb-3 font-semibold">Ajouter un document</h2>
        <form onSubmit={upload} className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end">
          <div className="min-w-0 space-y-2">
            <label htmlFor="documentation-file" className="block text-sm font-medium">Fichier</label>
            <input
              ref={input}
              id="documentation-file"
              type="file"
              accept={DOCUMENT_ACCEPT}
              aria-describedby="documentation-limit"
              disabled={unavailable}
              className="block min-h-11 w-full min-w-0 cursor-pointer rounded border border-[var(--app-border)] bg-[var(--app-field)] text-sm file:mr-3 file:min-h-11 file:cursor-pointer file:border-0 file:bg-[var(--app-hover)] file:px-3"
              onChange={(event) => {
                setFile(event.currentTarget.files?.[0] ?? null);
                uploadId.current = null;
                setFeedback(null);
              }}
            />
          </div>
          <button className="settings-primary-button" type="submit" disabled={!file || unavailable}>
            {busy?.kind === "upload" ? "Ajout en cours…" : "Ajouter"}
          </button>
          <p id="documentation-limit" className={muted}>{DOCUMENT_FORMAT_LABELS} · 4 Mio maximum par fichier.</p>
        </form>
      </section>

      {feedback && (
        <p role={feedback.error ? "alert" : "status"} className="break-words text-sm font-medium">
          {feedback.message}
        </p>
      )}

      <section className={panel} aria-labelledby="documents-list" aria-busy={loading || busy?.kind === "refresh"}>
        <h2 id="documents-list" className="mb-3 font-semibold">Documents enregistrés</h2>
        {loading && <p role="status" className={muted}>Chargement des documents…</p>}
        {listError && (
          <div className="flex flex-wrap items-center gap-3">
            <p role="alert" className="text-sm">{listError}</p>
            <button type="button" className={action} onClick={retryList} disabled={unavailable}>Réessayer</button>
          </div>
        )}
        {documents?.length === 0 && !listError && <p className={muted}>Aucun document enregistré.</p>}
        {documents && documents.length > 0 && (
          <ul className="divide-y divide-[var(--app-border)]">
            {documents.map((document) => (
              <li key={document.key} className="grid min-w-0 gap-3 py-3 first:pt-0 last:pb-0 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center">
                <div className="min-w-0">
                  <p className="text-sm font-medium [overflow-wrap:anywhere]">{document.name}</p>
                  <p className={muted}>
                    {formatSize(document.size)} · <time dateTime={document.createdAt}>{date.format(new Date(document.createdAt))}</time>
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button" className="settings-edit-action" disabled={unavailable}
                    aria-label={`Télécharger ${document.name}`} onClick={() => download(document)}
                  >
                    {busy?.kind === "download" && busy.key === document.key ? "Téléchargement…" : "Télécharger"}
                  </button>
                  <button
                    type="button" className="settings-edit-action" disabled={unavailable}
                    aria-label={`Supprimer ${document.name}`} onClick={() => {
                      setDeleteTarget(document);
                      setDeleteError("");
                    }}
                  >
                    Supprimer
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <dialog
        ref={dialog}
        aria-labelledby="documentation-confirm-title"
        aria-describedby="documentation-confirm-description"
        className="fixed inset-0 m-auto w-[calc(100%-2rem)] max-w-md rounded-lg border border-[var(--app-border)] bg-[var(--app-surface)] p-5 text-[var(--app-foreground)] shadow-xl backdrop:bg-black/60"
        onClose={() => setDeleteTarget(null)}
        onCancel={(event) => {
          if (operation.current?.kind === "delete") event.preventDefault();
        }}
      >
        <h2 id="documentation-confirm-title" className="font-semibold">Supprimer ce document ?</h2>
        <p id="documentation-confirm-description" className="my-3 text-sm [overflow-wrap:anywhere]">
          {deleteTarget?.name} sera supprimé définitivement.
        </p>
        {deleteError && <p className="mb-3 text-sm" role="alert">{deleteError}</p>}
        <div className="flex flex-wrap justify-end gap-2">
          <button type="button" ref={cancel} className={action} disabled={busy?.kind === "delete"} onClick={() => dialog.current?.close()}>Annuler</button>
          <button type="button" className={action} disabled={busy?.kind === "delete"} onClick={remove}>
            {busy?.kind === "delete" ? "Suppression…" : "Confirmer la suppression"}
          </button>
        </div>
      </dialog>
    </>
  );
}
