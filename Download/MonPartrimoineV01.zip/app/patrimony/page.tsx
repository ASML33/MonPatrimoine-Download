import { redirect } from "next/navigation";
import { DashboardHeader } from "@/app/components/dashboard-header";
import { SessionPatrimonyCharts } from "@/app/components/navigation-session";
import { getPageProfile } from "@/lib/auth/render-context";
import { getPageNavigationStamp } from "@/lib/navigation/stamp";
import { randomUUID } from "node:crypto";
import { asSettingsRecord, readProfileSettings } from "@/lib/settings/settings-core";
import { readThemePreference } from "@/lib/theme/theme-core";

export const dynamic = "force-dynamic";

export default async function PatrimonyPage({ searchParams }: { searchParams: Promise<{ scope?: string }> }) {
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (current.status !== "active") redirect("/");
  const query = await searchParams;
  const initialScope = query.scope === "outside-real-estate" ? "outside-real-estate" : "total";
  const stamp = await getPageNavigationStamp(current.profile.auth_user_id).catch(()=>null);
  const settings = readProfileSettings(documents);
  const theme = readThemePreference(asSettingsRecord(documents.interface_preferences));
  return <div data-theme={theme} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]">
    <DashboardHeader nickname={current.profile.nickname} displayName={settings.displayName} theme={theme} />
    <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-12">
      <header><h1 className="text-3xl font-bold sm:text-4xl">Analyse patrimoniale</h1><p className="mt-2 text-sm text-[var(--app-muted)]">Historique quotidien, composition et expositions selon un périmètre commun. Les données manquantes restent explicitement indisponibles.</p></header>
      <SessionPatrimonyCharts owner={current.profile.auth_user_id} expectedRevision={stamp?[stamp.session,stamp.revision].join(':'):'unavailable'} validationId={randomUUID()} initialScope={initialScope}/>
    </main>
  </div>;
}
