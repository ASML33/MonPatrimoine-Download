import Link from "next/link";

export const metadata = { title: "Connexion Google Drive — MonPatrimoine" };

export default function GoogleDrivePrivacyPage() {
  return (
    <main className="mx-auto max-w-3xl space-y-6 px-6 py-12 text-[var(--app-foreground)]">
      <h1 className="text-3xl font-bold">MonPatrimoine et Google Drive</h1>
      <p>MonPatrimoine est une application personnelle de suivi du patrimoine. Lorsque la fonction est activée, sa connexion Google Drive permet de conserver des sauvegardes privées et chiffrées. Les sauvegardes manuelles restent disponibles ; une automatisation quotidienne peut être activée séparément côté serveur. Une restauration exige une confirmation explicite et une sauvegarde préalable vérifiée.</p>
      <p><a className="underline" href="#confidentialite">Informations sur la confidentialité</a></p>
      <section id="confidentialite" className="space-y-4">
        <h2 className="text-xl font-semibold">Confidentialité de la connexion</h2>
        <p>La seule permission demandée est drive.file : créer et utiliser les fichiers créés par l’application ou que vous lui autorisez explicitement. Cette permission ne donne pas un accès général à vos fichiers personnels. Elle n’est pas une restriction technique à un dossier unique.</p>
        <p>La connexion conserve des identifiants OAuth chiffrés dans un stockage privé côté serveur, pour renouveler l’accès sans intervention périodique. Les clés restent côté serveur. Aucun mot de passe Google n’est demandé à MonPatrimoine ; vous choisissez votre compte et donnez votre consentement sur Google.</p>
        <p>MonPatrimoine utilise cet accès pour sa connexion et ses fonctions Drive. Il ne publie pas les fichiers et ne les partage pas avec d’autres utilisateurs. Les données de connexion ne sont pas utilisées pour la publicité ni transmises aux fournisseurs d’IA. Google traite les données reçues par son API ; l’hébergement applicatif et de la base fait intervenir Vercel et Supabase.</p>
        <p>Vous pouvez révoquer la connexion depuis les connexions tierces de votre compte Google. Cela empêche de nouveaux accès autorisés, mais ne supprime pas automatiquement les fichiers Drive ni les identifiants chiffrés enregistrés. La suppression technique de ces identifiants reste une opération séparée du titulaire de cette application personnelle.</p>
        <p>Les sauvegardes sont conservées dans un dossier dédié créé par l’application. Si l’automatisation est activée, la conservation couvre les 12 dernières quotidiennes réussies et une archive pour chacun des 12 derniers mois ayant une réussite, sans duplication du fichier. Les manuelles et pré-restauration sont exclues de cette rotation. Après une sauvegarde automatique vérifiée, les seules archives automatiques expirées de cette application peuvent être mises en corbeille, sans purge définitive. La corbeille occupe encore de l’espace jusqu’à son effacement selon les règles de Google Drive.</p>
      </section>
      <p><Link className="underline" href="/settings#google-drive">Ouvrir les paramètres de connexion</Link></p>
      <p className="text-sm">Informations mises à jour le 20 octobre 2026.</p>
    </main>
  );
}
