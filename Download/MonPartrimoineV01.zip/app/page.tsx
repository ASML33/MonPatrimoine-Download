import { formatMoney as formatEurMoney } from "@/lib/cash/money";
import { redirect } from "next/navigation";
import Link from "next/link";

import { logoutAction } from "@/app/auth-actions";
import { DashboardHeader } from "@/app/components/dashboard-header";
import { getPageProfile } from "@/lib/auth/render-context";
import { getCurrentDashboard } from "@/lib/dashboard/dashboard";
import type { CurrencyValue } from "@/lib/dashboard/dashboard-core";
import {
  asSettingsRecord,
  readProfileSettings,
} from "@/lib/settings/settings-core";
import { readThemePreference } from "@/lib/theme/theme-core";

export const dynamic = "force-dynamic";

function formatMoney({ amount, currency }: CurrencyValue) {
  return currency === "EUR" ? formatEurMoney(amount, "EUR") : "Conversion EUR indisponible";
}

function ValueList({
  values,
  large = false,
}: {
  values: CurrencyValue[];
  large?: boolean;
}) {
  return (
    <div className={`mt-3 grid gap-1 font-bold ${large ? "text-3xl" : "text-2xl"}`}>
      {values.map((value) => (
        <p key={value.currency}>{formatMoney(value)}</p>
      ))}
    </div>
  );
}

export default async function Home() {
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");

  if (current.status === "profile_missing") {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[var(--app-background)] p-6 text-[var(--app-foreground)]">
        <section className="w-full max-w-lg border border-[var(--app-border)] bg-[var(--app-surface)] p-8 text-center shadow-sm">
          <h1 className="text-xl font-bold">Profil indisponible</h1>
          <p className="mt-3 text-sm text-[var(--app-muted)]">
            Votre compte est authentifié, mais son profil MonPatrimoine n’est pas
            encore configuré.
          </p>
          <form action={logoutAction} className="mt-6">
            <button className="h-11 bg-[var(--app-foreground)] px-5 font-medium text-[var(--app-background)]">
              Se déconnecter
            </button>
          </form>
        </section>
      </main>
    );
  }

  const interfacePreferences = asSettingsRecord(documents.interface_preferences);

  const dashboard = await getCurrentDashboard();
  const theme = readThemePreference(interfacePreferences);
  const settings = readProfileSettings(documents);

  return (
    <div
      data-theme={theme}
      className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]"
    >
      <DashboardHeader
        nickname={current.profile.nickname}
        displayName={settings.displayName}
        theme={theme}

        lastUpdated={dashboard.lastUpdated}
      />

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {dashboard.activeContractCount === 0 ? (
          <section className="mt-8 flex min-h-72 items-center justify-center border border-[var(--app-border)] bg-[var(--app-surface)] p-8 text-center">
            <h2 className="text-xl font-semibold">Portefeuille vide</h2>
          </section>
        ) : (
          <>
            <section
              className={`grid gap-4 ${dashboard.hasRealEstate ? "md:grid-cols-2" : ""}`}
            >
              <Link href="/patrimony?scope=total" className="block border border-[var(--app-border)] bg-[var(--app-surface)] p-5 transition hover:border-[var(--app-gold)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--app-gold)] sm:p-6">
                <h2 className="font-semibold">
                  Patrimoine total
                </h2>
                <ValueList values={dashboard.total} large />
                {dashboard.incompletePositions ? <p className="mt-3 text-xs text-amber-500">Valorisation incomplète : {dashboard.incompletePositions} position(s) sans cours utilisable.</p> : null}
                {dashboard.incompleteCashBalances ? <p className="mt-3 text-xs text-amber-500">Valorisation incomplète : {dashboard.incompleteCashBalances} solde(s) sans conversion EUR utilisable.</p> : null}
              </Link>

              {dashboard.hasRealEstate ? (
                <Link href="/patrimony?scope=outside-real-estate" className="block border border-[var(--app-border)] bg-[var(--app-surface)] p-5 transition hover:border-[var(--app-gold)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--app-gold)] sm:p-6">
                  <h2 className="font-semibold">
                    Patrimoine hors immobilier
                  </h2>
                  <ValueList values={dashboard.outsideRealEstate} large />
                </Link>
              ) : null}
            </section>

            <section className="mt-8">
              <h2 className="text-lg font-semibold">Contrats</h2>
              <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {dashboard.groups.map((group) => (
                  <article key={group.key} className="border border-[var(--app-border)] bg-[var(--app-surface)] p-5">
                    <h3 className="font-semibold">{group.label}</h3>
                    <ValueList values={group.values} />
                    <ul className="mt-4 grid gap-2 border-t border-[var(--app-border)] pt-3 text-sm">
                      {group.contracts.map((contract) => contract.envelopeTypeCode==="immobilier" ? <li key={contract.id} className="min-w-0">
                        {group.contracts.length>1?<div className="mb-2 flex flex-wrap justify-between gap-2"><Link href={`/contracts/${contract.id}`} prefetch={false} className="font-semibold text-[var(--app-gold)] hover:underline">{contract.name}</Link><span>{contract.values[0]?formatMoney(contract.values[0]):"Indisponible"}</span></div>:null}
                        {contract.properties?.length?<ul className="grid gap-2">{contract.properties.map(property=><li key={property.positionId} className="flex flex-wrap items-start justify-between gap-x-3 gap-y-1"><Link href={`/contracts/${contract.id}`} prefetch={false} className="min-w-0 break-words font-semibold text-[var(--app-gold)] hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--app-gold)]">{property.name}</Link><span>{property.valueEur===null?"Indisponible":formatMoney({currency:"EUR",amount:property.valueEur})}</span></li>)}</ul>:<p className="text-[var(--app-muted)]">Aucun bien documenté.</p>}
                      </li> : <li key={contract.id} className="flex items-start justify-between gap-3">
                        <Link href={`/contracts/${contract.id}`} prefetch={false} className="font-semibold text-[var(--app-gold)] hover:underline">{contract.name}</Link>
                        <span className="shrink-0 text-right">{contract.values[0] ? formatMoney(contract.values[0]) : "Indisponible"}{contract.valueDate&&!['peg','per_col'].includes(contract.envelopeTypeCode)?<span className="block text-xs text-[var(--app-muted)]">Valeur du {new Intl.DateTimeFormat("fr-FR",{timeZone:"Europe/Paris"}).format(new Date(contract.valueDate))}</span>:null}</span>
                      </li>)}
                    </ul>
                  </article>
                ))}
                {!dashboard.groups.length ? <p className="text-sm text-[var(--app-muted)]">Aucun contrat n’est affiché sur le Dashboard.</p> : null}
              </div>
            </section>
          </>
        )}
      </main>
    </div>
  );
}
