"use client";

import { useState } from "react";

export function ColorField({ initial, id }: { initial: string | null; id: string }) {
  const [color, setColor] = useState(initial ?? "");
  const [changed, setChanged] = useState(false);
  const choose = (value: string) => { setChanged(true); setColor(value.toUpperCase()); };
  const valid = /^#[0-9a-f]{6}$/i.test(color);
  const isReservedRed = color.toUpperCase() === "#EF4444";
  return <div className="grid min-w-0 gap-2 text-sm font-medium">
    <label htmlFor={`color-${id}`}>Couleur</label>
    <input type="hidden" name="color_changed" value={String(changed)} />
    <div className="flex min-w-0 items-center gap-3">
      <input type="color" aria-label="Choisir la couleur" className="settings-input !w-14 shrink-0 !p-1" value={valid ? color : "#000000"} onChange={(event) => choose(event.target.value)} />
      <input id={`color-${id}`} name="color" className="settings-input min-w-0" value={color} onChange={(event) => choose(event.target.value)} pattern="#[0-9A-Fa-f]{6}" maxLength={7} placeholder="#RRGGBB" />
    </div>
    <p className={`text-xs ${isReservedRed ? "text-amber-500" : "text-[var(--app-muted)]"}`}>{isReservedRed ? "Le rouge est réservé aux espèces et versements dans les graphiques ; ce choix peut prêter à confusion." : "Videz le champ pour retirer la couleur."}</p>
  </div>;
}
