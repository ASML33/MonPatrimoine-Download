"use client";

import { useId, useState, type ReactNode } from "react";

export function DisclosureCard({
  title,
  description,
  icon,
  open,
  onToggle,
  children,
}: {
  title: string;
  description?: ReactNode;
  icon?: ReactNode;
  open: boolean;
  onToggle: () => void;
  children: ReactNode;
}) {
  const panelId = useId();
  return <section className="settings-card min-w-0" data-disclosure-card>
    <header className="settings-card-header">
      {icon ? <span className="settings-card-icon" aria-hidden="true">{icon}</span> : null}
      <div className="min-w-0 flex-1">
        <h2 className="settings-card-title w-full">
          <button
            type="button"
            className="flex w-full cursor-pointer items-center justify-between gap-4 bg-transparent text-left focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[var(--app-gold-light)]"
            aria-expanded={open}
            aria-controls={panelId}
            onClick={onToggle}
          >
            <span>{title}</span>
            <span aria-hidden="true" className={`shrink-0 text-xl font-normal leading-none text-[var(--app-gold)] transition-transform ${open ? "rotate-45" : ""}`}>+</span>
          </button>
        </h2>
        {description ? <div className="settings-card-description mt-1">{description}</div> : null}
      </div>
    </header>
    <div id={panelId} hidden={!open} className="mt-7">{children}</div>
  </section>;
}

export function CreationDisclosure({
  title,
  description,
  children,
}: {
  title: string;
  description?: ReactNode;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  return <div data-creation-disclosure>
    <DisclosureCard title={title} description={description} open={open} onToggle={() => setOpen((current) => !current)}>
      {children}
    </DisclosureCard>
  </div>;
}
