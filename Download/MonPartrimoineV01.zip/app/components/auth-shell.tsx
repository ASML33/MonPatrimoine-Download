import Image from "next/image";

export function AuthShell({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children: React.ReactNode;
}) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-black px-4 py-8 text-white sm:px-6">
      <section className="w-full max-w-md border border-zinc-800 bg-zinc-950 p-5 shadow-sm sm:p-8">
        <Image
          className="mx-auto h-auto w-full max-w-72"
          src="/pics/MonPatrimoine.png"
          alt="MonPatrimoine"
          width={1536}
          height={1024}
          priority
        />
        <div className="mb-7 mt-6 text-center">
          <h1 className="text-2xl font-bold">{title}</h1>
          <p className="mt-2 text-sm leading-6 text-zinc-400">{description}</p>
        </div>
        {children}
      </section>
    </main>
  );
}
