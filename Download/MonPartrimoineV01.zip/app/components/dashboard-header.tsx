import Image from "next/image";
import Link from "next/link";

import { logoutAction } from "@/app/auth-actions";
import { getDisplayedUserName } from "@/lib/settings/settings-core";
import type { ThemePreference } from "@/lib/theme/theme-core";
import { getPageProfile } from "@/lib/auth/render-context";
import { getPageNavigationStamp } from "@/lib/navigation/stamp";
import { NavigationSessionIdentity } from "./navigation-session";

function formatLastUpdated(value: string | null) {
  if (!value) return "Aucune mise à jour";
  return new Intl.DateTimeFormat("fr-FR", {
    timeZone: "Europe/Paris",
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(value));
}

export async function DashboardHeader({
  nickname,
  displayName,
  theme,
  lastUpdated,
}: {
  nickname: string;
  displayName?: string;
  theme: ThemePreference;
  lastUpdated?: string | null;
}) {
  const displayedUserName = getDisplayedUserName(displayName, nickname);
  const {current}=await getPageProfile();
  const identity=current.status==='active'?await getPageNavigationStamp(current.profile.auth_user_id).catch(()=>null):null;
  return (
    <header className="bg-[var(--app-surface)]">
      <NavigationSessionIdentity identity={identity}/>
      <div className="mx-auto grid min-h-16 max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-x-3 gap-y-3 px-4 py-2 sm:min-h-24 sm:grid-cols-[minmax(0,1fr)_auto_minmax(0,1fr)] sm:px-6 sm:py-3">
        <Link href="/" aria-label="Retour au tableau de bord" className="flex min-w-0 flex-col items-start focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)]">
          <Image
            src={
              theme === "dark"
                ? "/pics/BandeauThemeSombre.png"
                : "/pics/BandeauThemeClair.png"
            }
            alt="MonPatrimoine"
            width={1500}
            height={250}
            preload
            className="h-auto w-full max-w-[130px] sm:max-w-[300px]"
          />
        </Link>
        <Link href="/" aria-label="Retour au tableau de bord" className="hidden shrink-0 justify-center focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)] sm:flex">
          <Image
            src="/pics/logo.png"
            alt=""
            width={320}
            height={320}
            className="size-16 object-contain sm:size-20"
          />
        </Link>
        <div className="flex min-w-0 items-center justify-end gap-2 sm:gap-3">
          <strong className="max-w-24 truncate text-sm sm:max-w-64">{displayedUserName}</strong>

          <details className="group relative">
            <summary
              className="flex size-11 cursor-pointer list-none items-center justify-center border border-[var(--app-border)] bg-[var(--app-surface)] [&::-webkit-details-marker]:hidden"
              aria-label="Ouvrir le menu"
            >
              <span className="grid w-5 gap-1" aria-hidden="true">
                <span className="h-[1.5px] w-full bg-[var(--app-gold)]" />
                <span className="h-[1.5px] w-full bg-[var(--app-gold)]" />
                <span className="h-[1.5px] w-full bg-[var(--app-gold)]" />
              </span>
            </summary>

            <div className="absolute right-0 z-20 mt-2 w-[min(18rem,calc(100vw-2rem))] border border-[var(--app-border)] bg-[var(--app-surface)] p-4 shadow-xl">
              <nav className="grid gap-1 text-sm font-medium">
                <Link className="px-2 py-2 hover:bg-[var(--app-hover)]" href="/">Tableau de bord</Link>
                <div className="my-3 border-t border-[var(--app-border)]" role="separator" />
                <Link className="px-2 py-2 hover:bg-[var(--app-hover)]" href="/envelopes">Enveloppes</Link>
                <Link className="px-2 py-2 hover:bg-[var(--app-hover)]" href="/contracts">Contrats</Link>
                <Link className="px-2 py-2 hover:bg-[var(--app-hover)]" href="/assets">Actifs</Link>
                <div className="my-3 border-t border-[var(--app-border)]" role="separator" />
                <Link className="px-2 py-2 hover:bg-[var(--app-hover)]" href="/ai">Intelligence Artificielle</Link>
                <Link className="px-2 py-2 hover:bg-[var(--app-hover)]" href="/objectives">Stratégie</Link>
                <div className="my-3 border-t border-[var(--app-border)]" role="separator" />
                <Link className="px-2 py-2 hover:bg-[var(--app-hover)]" href="/backups">Sauvegardes</Link>
                <Link className="px-2 py-2 hover:bg-[var(--app-hover)]" href="/documentation">Documentation</Link>
                <Link className="px-2 py-2 hover:bg-[var(--app-hover)]" href="/settings">Paramètres</Link>
                <div className="my-3 border-t border-[var(--app-border)]" role="separator" />
                <Link className="px-2 py-2 font-semibold text-emerald-500 hover:bg-[var(--app-hover)]" href="/assets/refresh">Actualiser les cours</Link>
                <form action={logoutAction} className="mt-4"><button className="settings-primary-button">Déconnexion</button></form>
              </nav>

              {lastUpdated !== undefined ? (
                <p className="mt-4 border-t border-[var(--app-border)] pt-4 text-xs text-[var(--app-muted)]">
                  Dernière mise à jour : {formatLastUpdated(lastUpdated)}
                </p>
              ) : null}
            </div>
          </details>
        </div>
      </div>
      <div className="app-header-divider" aria-hidden="true" />
    </header>
  );
}
