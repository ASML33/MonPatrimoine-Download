"use client";

import { useEffect, useRef } from "react";

export function collapseSuccessfulEdit(form: HTMLFormElement | null, status: string, pending: boolean) {
  if (!form || pending || status !== "success") return;
  const details = form.closest<HTMLDetailsElement>("details[data-edit-form]");
  if (!details?.open) return;
  const restoreFocus = form.contains(form.ownerDocument.activeElement);
  details.open = false;
  if (restoreFocus) details.querySelector<HTMLElement>(":scope > summary")?.focus();
}

export function scheduleSuccessfulCollapse(form: HTMLFormElement, close?: () => void, clock = {
  setTimeout: (callback: () => void, delay: number) => globalThis.setTimeout(callback, delay),
  clearTimeout: (timer: ReturnType<typeof setTimeout>) => globalThis.clearTimeout(timer),
}) {
  const details = form.closest<HTMLDetailsElement>("details[data-edit-form]");
  let timer: ReturnType<typeof setTimeout> | undefined;
  const cancel = () => { if (timer !== undefined) clock.clearTimeout(timer); timer = undefined; };
  const onToggle = (event: Event) => { if (event.target === details && !details?.open) cancel(); };
  const dispose = () => {
    cancel();
    for (const type of ["input", "change", "submit"]) form.removeEventListener(type, cancel);
    details?.removeEventListener("toggle", onToggle);
  };
  for (const type of ["input", "change", "submit"]) form.addEventListener(type, cancel);
  details?.addEventListener("toggle", onToggle);
  timer = clock.setTimeout(() => {
    const restoreFocus = form.contains(form.ownerDocument.activeElement);
    dispose();
    if (close) {
      const trigger = form.getAttribute("data-edit-trigger");
      close();
      if (restoreFocus && trigger) requestAnimationFrame(() => form.ownerDocument.getElementById(trigger)?.focus());
    } else collapseSuccessfulEdit(form, "success", false);
  }, 1000);
  return dispose;
}

// Only a new successful action result schedules a close. Reopening a form
// does not replay its old result; edits and newer submissions cancel the timer.
export function useCollapseOnSuccess(state: { status?: string }, pending: boolean, enabled: boolean, close?: () => void) {
  const formRef = useRef<HTMLFormElement>(null);
  useEffect(() => {
    if (enabled && !pending && state.status === "success" && formRef.current) {
      return scheduleSuccessfulCollapse(formRef.current, close);
    }
  }, [state, pending, enabled, close]);
  return formRef;
}
