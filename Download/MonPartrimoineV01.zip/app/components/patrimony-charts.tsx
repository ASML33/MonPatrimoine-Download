"use client";
import { historicalSeriesGain } from "@/lib/patrimony/history-series-gain";
import { formatMoney } from "@/lib/cash/money";
import { lifeInsuranceSupportIds, lifeInsuranceSupportRows } from "@/lib/patrimony/life-insurance-support-history";
import { ctoNetHistoryContract, ctoNetHistoryRows, ctoNetPlotRows, ctoNetHistoryCoverage } from "@/lib/patrimony/cto-net-history";
import { canonicalHistorySeries, presentedHistoryLegend, unavailableHistoryEntry, historyExportLegend } from "@/lib/patrimony/history-series-presentation";
import { ValuationLines, type ValuationLine } from "./valuation-lines";
import {chartGeography} from "@/lib/geography/chart-geography";
import {MIXED_GEOGRAPHY_HELP} from "@/lib/geography/mixed-geography";

import { historicalRows,historyDisplayTotal,stackedHistoryPaths,historyPresentationIds } from "@/lib/patrimony/history-geometry";
import { historyTimeScopeIds, historyTimeDomain, historyTimeScale, historyIntervalsAtZoom, historyTimeX, historyTimeAnchor, historyTimeScroll, historyVisiblePeriod, historyAxisDates, type HistoryTimeDomain, type HistoryTimeAnchor, type HistoryViewportRef } from "@/lib/patrimony/history-time-scale";
import { graphHistoryPointsForSelection, PATRIMONY_HISTORY_START } from "@/lib/patrimony/history-policy";
import { restoreChartSelection, selectedHistoryPoint as selectedPoint, type ChartViewState } from "@/lib/patrimony/chart-view-state";
import { historyDetailVisibility } from "@/lib/patrimony/history-detail-state";
import { historyCsvFile } from "@/lib/patrimony/history-csv";
import { downloadPrivate } from "@/lib/exports/download";
import { downloadHistoryPng } from "@/lib/patrimony/history-export";
import { useCallback, useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from "react";
import type { Dispatch, SetStateAction, ReactNode } from "react";
import type { DistributionExplanation } from "@/lib/patrimony/distribution-core";
import { chartColors, historicalPatrimonyComposition, historicalCompositionSlices, exposureSlices, type ChartSlice } from "@/lib/patrimony/chart-distributions";
import { donutArcs, distributionState, historyPercentages, knownNetHistoryPercentages, roundedPercentages, groupUnspecifiedSlices, distributionPercentageLabel, distributionAmountLabel } from "@/lib/patrimony/distribution-core";
import { hasContractDistributions, historicalContractGain, historicalHoldingState, historicalSeriesIds, historyGesture, historyKeyboardScroll, initialContractChartMode, isDetailed, isSecuritiesEnvelopeType, resolveSelection, selectionForContract, selectionForScope, showsHistoricalContributions, stableColor, tooltipPlacement, verticalDomain, visibleHistoricalLegend, visibleHistoricalSeries, type ChartMode, type ChartPoint, type PatrimonyChartData } from "@/lib/patrimony/chart-core";

const money = (value: number) => formatMoney(value, "EUR");
const percent = (value: number) => new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 2 }).format(value) + " %";
// A civil date is presented at UTC noon, safely within that same Paris day in
// winter and summer; no fixed Paris offset is used to interpret an instant.
const date = (value: string) => new Intl.DateTimeFormat("fr-FR", { timeZone: "Europe/Paris", dateStyle: "short" }).format(new Date(`${value}T12:00:00Z`));

type Selection = Record<string, "global" | string[]>;
type Slice = ChartSlice;

const expandedTileClass = "fixed inset-0 z-50 flex h-dvh w-screen flex-col overflow-auto bg-[var(--app-surface)] shadow-2xl";

function useExpandedTile(expanded: boolean, setExpanded: Dispatch<SetStateAction<boolean>>) {
  useEffect(() => {
    if (!expanded) return;
    const previousOverflow = document.body.style.overflow;
    const onKeyDown = (event: KeyboardEvent) => { if (event.key === "Escape") setExpanded(false); };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [expanded, setExpanded]);
}

function ExpandIcon({ expanded }: { expanded: boolean }) {
  return expanded
    ? <svg viewBox="0 0 20 20" aria-hidden="true" className="h-4 w-4"><path d="M3 8V3h5M12 3h5v5M17 12v5h-5M8 17H3v-5" fill="none" stroke="currentColor" strokeWidth="1.6"/><path d="m8 8-5-5m9 5 5-5m-5 9 5 5m-9-5-5 5" fill="none" stroke="currentColor" strokeWidth="1.6"/></svg>
    : <svg viewBox="0 0 20 20" aria-hidden="true" className="h-4 w-4"><path d="M8 3H3v5M12 3h5v5M17 12v5h-5M3 12v5h5" fill="none" stroke="currentColor" strokeWidth="1.6"/><path d="m3 8 5-5m4 0 5 5m0 4-5 5m-4 0-5-5" fill="none" stroke="currentColor" strokeWidth="1.6"/></svg>;
}

function Donut({ title, slices, note, dateNote, unavailable, details = [], remarks = [], controls }: { title: string; slices: Slice[]; note: string; dateNote: string; unavailable?: string | null; details?:DistributionExplanation[]; remarks?:string[]; controls?:ReactNode }) {
  const [selected, setSelected] = useState<string | null>(slices[0]?.id ?? null);
  const [expanded, setExpanded] = useState(false);
  useExpandedTile(expanded, setExpanded);
  const cashOutsideSecurities = slices.filter((slice) => slice.cashOutsideSecurities);
  const participatingSlices = groupUnspecifiedSlices(slices.filter((slice) => !slice.cashOutsideSecurities));
  const error = unavailable ?? distributionState(participatingSlices);
  const percentages = roundedPercentages(participatingSlices);
  const positiveSlices = error ? [] : participatingSlices.filter((slice) => slice.amount! > 0);
  const selectedSlice = positiveSlices.find((item) => item.id === selected) ?? positiveSlices[0];
  const arcs = donutArcs(positiveSlices);
  const unallocated=positiveSlices.find(slice=>slice.unspecified);
  const explanations=[...new Map(details.map(item=>[`${item.id}:${item.reason}`,item])).values()];
  const notes=[...new Set([note,...remarks].map(text=>text.trim()).filter(Boolean))];
  const unavailableDetails=explanations.filter(item=>!item.inDonut);
  const contributionDetails=explanations.filter(item=>item.inDonut);
  return <section aria-label={title} className={`${expanded ? expandedTileClass : "relative grid min-w-0 grid-rows-[auto_auto_auto_auto] gap-3 lg:row-span-4 lg:grid-rows-subgrid"} border border-[var(--app-border)] bg-[var(--app-surface)] p-4 sm:p-5`}>
    <header className="flex items-start justify-between gap-3"><h3 className="min-w-0 self-center font-semibold">{title}</h3><button type="button" className="flex min-h-11 min-w-11 shrink-0 items-center justify-center border border-[var(--app-border)] p-1.5 text-[var(--app-muted)] hover:text-[var(--app-foreground)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)]" aria-label={expanded ? `Réduire ${title}` : `Agrandir ${title}`} aria-expanded={expanded} onClick={() => setExpanded((value) => !value)}><ExpandIcon expanded={expanded}/></button></header>
    <div className={expanded?"flex min-h-0 flex-1 flex-col justify-center":"flex flex-col justify-start"}>
    {error ? <p role="status" className="text-sm text-[var(--app-muted)]">{error}</p> : <div>
      <div className={`relative mx-auto aspect-square w-full ${expanded ? "max-w-[min(78vw,78dvh)]" : "max-w-56"}`}>
        <svg viewBox="-4 -4 108 108" role="img" aria-label={title} className="h-full w-full -rotate-0">
          <defs>{arcs.map((slice, index) => <radialGradient key={slice.id} id={`donut-${title.replace(/\W/g, "")}-${index}`} cx="50%" cy="50%" r="50%"><stop offset="46%" stopColor={slice.color} stopOpacity=".15"/><stop offset="100%" stopColor={slice.color} stopOpacity=".6"/></radialGradient>)}</defs>
          {arcs.map((slice,index) => <path key={slice.id} d={slice.path} transform={selectedSlice?.id===slice.id?`translate(${slice.dx} ${slice.dy})`:undefined} fill={`url(#donut-${title.replace(/\W/g, "")}-${index})`} stroke={slice.color} strokeOpacity="1" strokeWidth="1" className="cursor-pointer transition-transform focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)]" tabIndex={0} role="button" aria-pressed={selectedSlice?.id===slice.id} aria-label={`${slice.name}, ${distributionPercentageLabel(percentages?.get(slice.id) ?? null,slice.amount!>0)}`} onFocus={() => setSelected(slice.id)} onClick={() => setSelected(slice.id)} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") { event.preventDefault(); setSelected(slice.id); } }} />)}
          <circle cx="50" cy="50" r="23" fill="var(--app-surface)" />
        </svg>
        {selectedSlice ? <div className="pointer-events-none absolute inset-[28%] flex flex-col items-center justify-center text-center text-[10px] sm:text-xs"><strong>{selectedSlice.name}</strong><span>{distributionPercentageLabel(percentages?.get(selectedSlice.id) ?? null,selectedSlice.amount!>0)}</span></div> : null}
      </div>
    </div>}
    {cashOutsideSecurities.map((slice) => <p key={slice.id} className="mt-3 text-xs" style={{ color: slice.color }}>{slice.name} : {slice.amount === null ? "Indisponible" : money(slice.amount)} · hors répartition des titres</p>)}
    </div>
    <div className="grid min-w-0 content-start gap-3 text-xs text-[var(--app-muted)]">
      <p>{dateNote}</p>
      {unallocated?<details><summary className="cursor-pointer py-2 font-semibold focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)]">Non spécifié</summary><p className="mt-2">Cette part regroupe les catégories Non spécifié publiées et les montants documentés sans ventilation qualifiée. Leurs motifs et sources restent distincts. Un montant individuel inconnu n’est pas ajouté au donut.</p><p className="mt-2">Contribution : {distributionAmountLabel(unallocated.amount!)} · {distributionPercentageLabel(percentages?.get(unallocated.id) ?? null,true)}</p>{contributionDetails.length?<ul className="mt-2 grid gap-2">{contributionDetails.map(item=><li className="min-w-0 [overflow-wrap:anywhere]" key={`${item.id}:${item.reason}`}><strong>{item.name}</strong> : {item.reason}</li>)}</ul>:<p className="mt-2">Aucun détail individuel supplémentaire disponible dans la source.</p>}</details>:null}
      {notes.length||unavailableDetails.length?<details><summary className="cursor-pointer py-2 font-semibold focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)]">Remarques</summary><div className="mt-2 grid min-w-0 gap-2 [overflow-wrap:anywhere]">{notes.map(text=><p key={text}>{text}</p>)}{unavailableDetails.map(item=><p key={`${item.id}:${item.reason}`}><strong>{item.name}</strong> : {item.reason}</p>)}</div></details>:null}
    </div>
    <div className="flex flex-wrap items-end gap-2 self-end">{controls}</div>
  </section>;
}

function HistoryChart({ supportContract, orderByEnvelope = false, data, ids, timeDomain, viewportRef, mode, showContributions, historicalGainContractId, onSelectDate, csvContract, selectedDate, legendClosed = false, onCloseLegend }: { supportContract?: import("@/lib/patrimony/chart-core").ChartContract; orderByEnvelope?: boolean; data: PatrimonyChartData; ids: string[]; timeDomain: HistoryTimeDomain; viewportRef?: HistoryViewportRef; mode: ChartMode; showContributions: boolean; historicalGainContractId?: string; csvContract?:{data:PatrimonyChartData;id:string}; onSelectDate?: (point: ChartPoint | null) => void; selectedDate?:string|null; legendClosed?:boolean; onCloseLegend:()=>void }) {
  const points = useMemo(() => graphHistoryPointsForSelection(data.points,ids,data.contracts),[data.points,ids,data.contracts]);
  const hasContinuity=points.some(point=>Object.keys(point.continuityEvidence??{}).some(id=>ids.some(key=>key.split(':')[1]===id)));
  // The detail follows the date explicitly selected by a click/tap, not pointer
  // hover. Its owner survives financial refreshes in the session wrapper.
  const hoverIndex = selectedDate ? points.findIndex(point=>point.date===selectedDate) : -1;
  const hover = hoverIndex < 0 ? null : hoverIndex;
  const [visibleIntervals, setVisibleIntervals] = useState<number | null>(null);
  const zoomId = useId();
  const [expanded, setExpanded] = useState(false);
  const [viewportHeight, setViewportHeight] = useState(0);
  const [viewportWidth, setViewportWidth] = useState(900);
  const [scrollLeft, setScrollLeft] = useState(0);
  const [tooltipWidth, setTooltipWidth] = useState(420);
  const [mobile, setMobile] = useState(false);
  const gesture = useRef<{ pointerId: number; x: number; y: number; scrollLeft: number; direction: "tap" | "horizontal" | "vertical" } | null>(null);
  const [tableOpen, setTableOpen] = useState(false);
  const [exporting,setExporting]=useState(false);
  const [exportError,setExportError]=useState("");
  const scroller = useRef<HTMLDivElement>(null);
  const tooltip = useRef<HTMLDivElement>(null);
  const scrollAnchor = useRef<HistoryTimeAnchor>({ centerTime:0, atEnd:true });
  const restoredViewport = useRef(false);
  const hasSelection = ids.length > 0;
  useExpandedTile(expanded, setExpanded);
  useEffect(() => {
    if (!expanded) return;
    const update = () => setViewportHeight(window.innerHeight);
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, [expanded]);
  useLayoutEffect(() => {
    const element = scroller.current;
    if (!element) return;
    const measure = () => setViewportWidth(Math.max(1,element.clientWidth));
    const observer = new ResizeObserver(measure);
    measure();
    observer.observe(element);
    return () => observer.disconnect();
  }, [hasSelection]);
  useEffect(() => {
    const query = window.matchMedia("(max-width: 639px)");
    const update = () => setMobile(query.matches);
    update(); query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);
  const timeScale = useMemo(()=>historyTimeScale(timeDomain,viewportWidth,visibleIntervals,2),[timeDomain,viewportWidth,visibleIntervals]);
  const width = timeScale.width;
  // Keep SVG units equal to CSS pixels: text is never stretched to fit a narrow tile.
  const mobileHeight = Math.round(Math.min(260, Math.max(190, viewportWidth * .62 + 40)));
  const height = mobile ? mobileHeight : expanded && viewportHeight ? Math.max(240, viewportHeight - 140) : 330;
  const pad = 2;
  const plotTop = mobile ? 24 : 36;
  const plotBottom = mobile ? 30 : 36;
  useLayoutEffect(() => {
    const element=scroller.current;
    if(!element)return;
    // ResizeObserver's measured width must match the DOM before saving an
    // anchor; otherwise the first mount can mistake the latest edge for a
    // manually centered view after the browser clamps scrollLeft.
    if(Math.abs(element.clientWidth-timeScale.viewportWidth)>.5)return;
    if(!restoredViewport.current){
      restoredViewport.current=true;
      const saved=viewportRef?.current;
      if(saved){scrollAnchor.current=saved.anchor;if(saved.intervals!==visibleIntervals){setVisibleIntervals(saved.intervals);return;}}
    }
    element.scrollLeft=historyTimeScroll(timeScale,scrollAnchor.current);
    const left=element.scrollLeft;
    scrollAnchor.current=historyTimeAnchor(timeScale,left);
    if(viewportRef)viewportRef.current={intervals:visibleIntervals,anchor:scrollAnchor.current};
    setScrollLeft(left);
  }, [timeScale,visibleIntervals,viewportRef,hasSelection]);
  const visiblePeriod=historyVisiblePeriod(timeScale,scrollLeft);
  const detailVisibility=historyDetailVisibility(selectedDate,legendClosed,hover!==null,visiblePeriod);
  useEffect(() => {
    const element = tooltip.current;
    if (!element) return;
    const measure = () => setTooltipWidth(Math.ceil(element.getBoundingClientRect().width));
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    return () => observer.disconnect();
  }, [detailVisibility,hover,viewportWidth,mode,mobile]);
  const changeZoom=(value:number)=>{
    const element=scroller.current;
    if(element)scrollAnchor.current=historyTimeAnchor(timeScale,element.scrollLeft);
    const intervals=historyIntervalsAtZoom(timeDomain,value);
    if(viewportRef)viewportRef.current={intervals,anchor:scrollAnchor.current};
    setVisibleIntervals(intervals);
  };
  const [hiddenSupportIds, setHiddenSupportIds] = useState<string[]>([]);
  const ctoContract = ctoNetHistoryContract(data.contracts, ids, mode);
  const effectiveIds = useMemo(() => historicalSeriesIds(points, ids, data.contracts), [points, ids, data.contracts]);
  const colors = useMemo(() => chartColors(data.contracts), [data.contracts]);
  const series = useMemo(() => {
    const items = visibleHistoricalSeries(effectiveIds, points, data.contracts).map((id) => { const found = data.contracts.flatMap((c) => [{ id: `contract:${c.id}`, label: c.name, color: c.color }, ...c.children]).find((item) => item.id === id); return { id, color: colors.get(id) ?? stableColor(id), label: id === "employee-savings-combined" ? "PEG + PER COL — historique non ventilé" : found?.label ?? id }; });
    if (ctoContract) items.push({ id: `contract:${ctoContract.id}`, label: "NET historique global non ventilé", color: ctoContract.color });
    const labelled = supportContract ? items.map(item => item.id === `contract:${supportContract.id}` ? {...item,label:"Total historique non ventilé"} : item) : items;
    return canonicalHistorySeries(labelled, data.contracts, orderByEnvelope);
  }, [colors, data.contracts, effectiveIds, points, orderByEnvelope, supportContract, ctoContract]);
  const legendSeries = series.map((serie, index) => ({ serie, index })).reverse();
  const rows = useMemo(() => supportContract ? lifeInsuranceSupportRows(points,series,data.contracts,supportContract,hiddenSupportIds) : ctoContract ? ctoNetHistoryRows(points,series,data.contracts,ctoContract) : historicalRows(points,series,data.contracts,mode,effectiveIds),[points,series,data.contracts,mode,effectiveIds,supportContract,hiddenSupportIds,ctoContract]);
  const max = Math.max(1, ...rows.map(row => mode === "net" ? row.values.reduce<number>((sum,value)=>value === null ? sum : sum+value,0) : row.total));
  const visibleDomain = verticalDomain(max, 1, 0);
  const x = useCallback((index: number) => historyTimeX(timeScale,rows[index].point.date), [timeScale,rows]);
  const y = useCallback((value: number) => height - plotBottom - (value - visibleDomain.min) / visibleDomain.span * (height - plotTop - plotBottom), [height, plotTop, plotBottom, visibleDomain.min, visibleDomain.span]);
  const areas = useMemo(() => stackedHistoryPaths(ctoContract ? ctoNetPlotRows(rows) : rows,series,data.contracts,x,y,mode),[mode,rows,series,data.contracts,x,y,ctoContract]);
  const contributionCaption=data.contracts.some(c=>isSecuritiesEnvelopeType(c.envelopeTypeCode)&&ids.some(id=>id.split(":")[1]===c.id))?"Cumul des versements":"Versements cumulés";
  const contributionRows = useMemo(() => rows.map((row) => {
    // Individual contributions are not a comparable baseline for a common,
    // unallocated PEG/PER total. Keep them on individual dates only.
    if (row.activeIds.includes("employee-savings-combined")) return null;
    const contractIds = new Set(ids.map((id) => id.split(":")[1]).filter(Boolean));
    const allowed = [...contractIds].filter((contractId) => ids.includes(`contract:${contractId}`) || data.contracts.find((c) => c.id === contractId)?.children.every((child) => ids.includes(child.id)));
    const values = allowed.map((id) => (Object.hasOwn(row.point.displayedContributions??{},id)?row.point.displayedContributions![id]:row.point.contributions[id])).filter((value): value is number => typeof value === "number");
    return values.length ? values.reduce((a,b)=>a+b,0) : null;
  }), [data.contracts, ids, rows]);
  const contributionPath = useMemo(() => contributionRows.map((value, index) => value === null ? null : `${x(index)} ${y(value)}`).reduce<string[]>((parts, item, index, all) => { const gap=index>0&&new Date(`${rows[index].point.date}T12:00:00Z`).getTime()-new Date(`${rows[index-1].point.date}T12:00:00Z`).getTime()>86400000*1.5; if (item && (index === 0 || all[index-1] === null || gap)) parts.push(`M ${item}`); else if (item) parts.push(`L ${item}`); return parts; }, []).join(" "), [contributionRows, rows, x, y]);
  const hoverRow = hover === null ? null : rows[hover] ?? null;
  const hoverLegend = hoverRow ? visibleHistoricalLegend(legendSeries, hoverRow.point, data.contracts,mode).filter(({serie}) => hoverRow.activeIds.includes(serie.id)) : [];
  const contextRow = selectedDate ? rows.find(row=>row.point.date===selectedDate) : rows.at(-1);
  const contextLegend = contextRow ? visibleHistoricalLegend(legendSeries,contextRow.point,data.contracts,mode).filter(({serie})=>contextRow.activeIds.includes(serie.id)) : [];
  const unavailableAtDate = contextRow ? legendSeries.filter(entry=>unavailableHistoryEntry(entry,contextRow,data.contracts,mode)||(contextRow.activeIds.includes(entry.serie.id)&&contextRow.values[entry.index]===null&&historicalHoldingState(contextRow.point,entry.serie.id,data.contracts)!=="absent")) : [];
  const unknownHoldings = contextRow ? contextRow.activeIds.filter((id) => historicalHoldingState(contextRow.point, id, data.contracts) === "unknown") : [];
  // Presentation only: sum the displayed cent amounts, never a declared total
  // or a business aggregate that can differ from its detailed components.
  const popupTotal = hoverRow ? historyDisplayTotal(hoverRow,hoverLegend.reduce((cents,{index})=>cents+Math.round(Number(new Intl.NumberFormat('en-US',{useGrouping:false,minimumFractionDigits:2,maximumFractionDigits:2}).format(hoverRow.values[index]!))*100),0)/100) : null;
  const netPortfolioPercentages = mode==="net"&&orderByEnvelope;
  // Unknown positions are retained only in presentation, outside numerical aggregates.
  const displayedLegend = hoverRow ? presentedHistoryLegend(legendSeries, hoverRow, data.contracts, mode) : [];
  const hoverPercentages = netPortfolioPercentages&&hoverRow
    ? knownNetHistoryPercentages(hoverLegend.map(({serie,index})=>({id:serie.id,amount:hoverRow.values[index]})))
    : hoverRow?.valid ? historyPercentages(series, hoverRow.values) : null;
  const gain = contextRow && historicalGainContractId ? historicalContractGain(
    contextRow.point.values[`contract:${historicalGainContractId}:gross`],
    contextRow.point.netCashFlows?.[historicalGainContractId],
    contextRow.point.contributions[historicalGainContractId],
  ) : null;
  const placement = hover === null || !hoverRow ? null : tooltipPlacement(x(hover), scrollLeft, scrollLeft + viewportWidth, Math.min(tooltipWidth, viewportWidth - 16));
  const coveredRows = series.length ? rows.filter((row) => row.valid).length : 0;
  const missingLabels = series.filter((_, index) => rows.every((row) => row.values[index] === null)).map((item) => item.label);
  const rowProvenance = (point: ChartPoint) => {
    const selectedContractIds = new Set(effectiveIds.map((id) => id.split(":")[1]).filter(Boolean));
    const additions = Object.entries(point.provenanceByContract ?? {}).filter(([contractId]) => selectedContractIds.has(contractId)).map(([, value]) => value);
    const corrections=Object.entries(point.contributionCorrectionEvidence??{}).filter(([id])=>selectedContractIds.has(id)).map(([,e])=>`Cumul corrigé à compter du ${date(e.date)} · gains et fiscalité fondés sur les flux natifs`);
    return [point.provenance, ...new Set([...additions,...corrections])].join(" · ");
  };
  async function exportChart(){
    const container=scroller.current,svg=container?.querySelector("svg");if(!container||!svg)return;
    setExporting(true);setExportError("");
    try{
      const clone=svg.cloneNode(true) as SVGSVGElement;
      clone.querySelectorAll('text,title,line[stroke-dasharray="3 3"]').forEach(node=>node.remove());
      const style=getComputedStyle(svg);
      const markup=clone.innerHTML.replace(/var\((--[a-z-]+)\)/g,(_,name)=>style.getPropertyValue(name).trim());
      const left=container.scrollLeft,visibleWidth=container.clientWidth;
      const visible=rows.filter((_,i)=>x(i)>=left+pad-1&&x(i)<=left+visibleWidth-pad+1);
      const declared=visible.filter(row=>row.valid&&Math.abs(row.total-row.values.reduce<number>((sum,v)=>sum+(v??0),0))>.000001);
      const limits=[...new Set(visible.flatMap(row=>row.netReasons))];
      if(mode==="gross"&&declared.length){limits.push("Points dorés : total déclaré distinct des composants ; aucun ajustement des espèces.");for(const row of declared)limits.push(`${row.point.date} : total déclaré ${money(row.total)} ; composants ${money(row.values.reduce<number>((sum,v)=>sum+(v??0),0))}.`);}
      if(mode==="net")limits.push(`Qualité NET visible : ${[...new Set(visible.map(row=>row.quality))].join(" ; ")}.`);
      if(mode==="gross"&&visible.some(row=>!row.valid))limits.push("Données partielles : repères sans hauteur monétaire, aucun empilement complet tracé ; sous-totaux connus au détail. Inconnus non remplacés par zéro.");
      limits.push("Journées absentes et ruptures de détention conservées. Export de la photographie affichée, sans nouvelle lecture.");
      await downloadHistoryPng({verticalLegend:true,scope:data.contracts.filter(c=>ids.some(id=>id.split(":")[1]===c.id)).map(c=>c.name).join(" · "),markup,left,visibleWidth,chartHeight:height,plotTop,plotBottom,mode,dates:historyAxisDates(timeScale,left),series:[...historyExportLegend(legendSeries,visible,data.contracts,mode).map(serie=>({label:serie.label,color:serie.color})),...(showContributions&&contributionPath?[{label:contributionCaption+" (hors total)",color:"#ef4444",dashed:true}]:[])],coverage:`Couverture de la fenêtre : ${visible.filter(row=>row.valid).length}/${visible.length} dates complètes.`,limits,background:style.getPropertyValue("--app-surface").trim(),foreground:style.getPropertyValue("--app-foreground").trim(),muted:style.getPropertyValue("--app-muted").trim(),maximum:visibleDomain.min+visibleDomain.span});
    }catch{setExportError("Export PNG indisponible. Aucun historique n’a été modifié.");}finally{setExporting(false);}
  }
  const belowDetail = mobile || placement?.mode === "panel";
  const unavailableGainReason = gain?.missing === "contract_value" ? "valorisation historique du contrat absente" : "flux nets historiques absents";
  const unavailableGainPercentage = gain?.missing === "total_contributions" ? "versements historiques absents" : "base de versements nulle";
  const sourceContribution = contextRow && historicalGainContractId ? contextRow.point.sourceContributions?.[historicalGainContractId] : undefined;
  const sourceNetCashFlow = contextRow && historicalGainContractId ? contextRow.point.sourceNetCashFlows?.[historicalGainContractId] : undefined;
  const sourceFlowEvidence = sourceContribution !== undefined || sourceNetCashFlow !== undefined;
  const missingNetReasons = contextRow?.netReasons ?? [];
  const cashNetEvidence = contextRow && mode === "net" ? Object.entries(contextRow.point.cashNetProjection ?? {}).filter(([id]) => effectiveIds.some(key => key.split(":")[1] === id)) : [];
  const sourceNetEvidence = contextRow && mode === "net" ? series.flatMap((serie) => serie.id.startsWith("contract:") && typeof contextRow.point.sourceNets?.[serie.id.slice(9)] === "number"
    ? [`${serie.label} : ${money(contextRow.point.sourceNets![serie.id.slice(9)]!)}${contextRow.point.sourceNetDates?.[serie.id.slice(9)]?' · source du '+date(contextRow.point.sourceNetDates[serie.id.slice(9)]!):''}`] : []) : [];
  const legendContract = data.contracts.find(contract => contract.id === historicalGainContractId && (isSecuritiesEnvelopeType(contract.envelopeTypeCode) || contract.envelopeTypeCode === "assurance_vie"));
  const completeContractSelection = Boolean(legendContract && (ids.includes(`contract:${legendContract.id}`) || (legendContract.children.length > 0 && legendContract.children.every(child => ids.includes(child.id)))));
  const hoverGain = hoverRow && legendContract && completeContractSelection ? historicalContractGain(
    hoverRow.point.values[`contract:${legendContract.id}:gross`],
    hoverRow.point.netCashFlows?.[legendContract.id],
    hoverRow.point.contributions[legendContract.id],
  ) : null;
  const hoverContribution = legendContract && showContributions && hover !== null ? contributionRows[hover] : null;
  const cashColor = legendContract ? colors.get(`cash:${legendContract.id}`) ?? "#ef4444" : "#ef4444";
  const curveLabel = (label: string, dashed = false) => <span className="inline-flex items-center gap-1"><svg aria-hidden="true" width="16" height="8" viewBox="0 0 16 8" className="shrink-0"><path d="M0 4H16" fill="none" stroke="currentColor" strokeWidth="2" strokeDasharray={dashed ? "3 2" : undefined}/></svg>{label}</span>;
  const detailLines: ValuationLine[] = hoverRow ? displayedLegend.map((entry) => { const {serie,index}=entry; const unavailable=unavailableHistoryEntry(entry,hoverRow,data.contracts,mode); const quantity = hoverRow.point.quantities[serie.id]; const child = data.contracts.flatMap(contract => contract.children).find(item => item.id === serie.id); const latent = historicalSeriesGain(hoverRow.point, serie.id, child); return { latent, id: serie.id, label: legendContract && serie.id.startsWith("cash:") ? curveLabel(serie.label) : <>● {serie.label}</>, color: serie.color, quantityApplicable: !hoverRow.point.amountTrackedIds?.includes(serie.id) && (quantity != null || child?.quantified === true), quantityLabel: quantity == null ? null : String(quantity).replace(".", ","), percentageApplicable: !unavailable && hoverRow.values[index] !== null && (netPortfolioPercentages || !serie.id.startsWith("cash:")), percentageLabel: hoverPercentages?.has(serie.id) ? percent(hoverPercentages.get(serie.id)!) : netPortfolioPercentages ? "—" : null, valueLabel: unavailable || hoverRow.values[index] === null ? "Indisponible" : money(hoverRow.values[index]!) }; }) : [];
  if (typeof hoverContribution === "number" && Number.isFinite(hoverContribution)) {
    detailLines.push({ id: "contributions", label: curveLabel(isSecuritiesEnvelopeType(legendContract?.envelopeTypeCode)?"Cumul des versements":"Versements", true), color: cashColor, quantityApplicable: false, quantityLabel: null, percentageApplicable: false, percentageLabel: null, valueLabel: money(hoverContribution), valueColor: cashColor });
  }
  const gainColor = (value: number) => value < 0 ? "text-red-500" : value > 0 ? "text-emerald-500" : "text-[var(--app-foreground)]";
  const gainRow = hoverGain?.amount != null ? <li data-testid="history-contract-gain" className="col-span-full grid grid-cols-subgrid items-baseline gap-y-1 border-t border-[var(--app-border)] pt-2 tabular-nums">
    <span className="col-span-full min-w-0 break-words sm:col-span-1">Gain / Perte</span>
    {detailLines.some(line=>line.quantityApplicable) ? <span className="col-start-2" aria-hidden="true"/> : null}
    <span data-metric="gain-percentage" className={`${detailLines.some(line=>line.quantityApplicable) ? "col-start-3" : "col-start-2"} whitespace-nowrap text-right ${hoverGain.percentage == null ? "" : gainColor(hoverGain.percentage)}`}>{hoverGain.percentage == null ? null : <><span className="sr-only">Pourcentage du gain du contrat : </span>{hoverGain.percentage > 0 ? "+" : ""}{percent(hoverGain.percentage === 0 ? 0 : hoverGain.percentage)}</>}</span>
    <span data-metric="gain-amount" className={`whitespace-nowrap text-right ${gainColor(hoverGain.amount)}`}><span className="sr-only">Montant du gain du contrat : </span>{hoverGain.amount > 0 ? "+" : ""}{money(hoverGain.amount === 0 ? 0 : hoverGain.amount)}</span>
  </li> : null;
  const detailPanel = detailVisibility === "visible" && hoverRow && placement ? <div ref={tooltip} role="button" tabIndex={0} aria-label="Fermer le détail de la date sélectionnée" onClick={(event) => { event.stopPropagation(); onCloseLegend(); }} onKeyDown={(event) => { if(["Escape","Enter"," "].includes(event.key)) { event.preventDefault(); event.stopPropagation(); onCloseLegend(); } }} data-testid="history-detail" className={`${belowDetail ? "mt-3 w-full min-w-0 break-words" : "pointer-events-auto absolute top-3 w-max max-w-[min(34rem,calc(100vw-1.5rem))]"} border border-[var(--app-border)] bg-[var(--app-background)]/95 p-3 text-xs shadow-lg`} style={belowDetail ? undefined : { left: placement.left }}><strong>{date(hoverRow.point.date)}</strong><div className="mt-2"><ValuationLines hideUnknownMetrics lines={detailLines} footer={gainRow}/></div>{netPortfolioPercentages&&!hoverPercentages?<p className="mt-2 text-[var(--app-muted)]">Pourcentages indisponibles : somme connue nulle ou inexploitable.</p>:null}<div className={gainRow ? "mt-2" : "mt-2 border-t border-[var(--app-border)] pt-2"}><p className="flex justify-between gap-5 tabular-nums"><span>{(netPortfolioPercentages||Boolean(ctoContract))&&!hoverRow.valid&&hoverRow.hasKnownValues?"Total connu (partiel)":popupTotal?.label}</span><span>{popupTotal?.value == null ? "Indisponible" : money(popupTotal.value)}</span></p></div></div> : null;
  const contextNotes = contextRow ? <details className="mt-3 text-xs text-[var(--app-muted)]"><summary className="cursor-pointer py-2 font-semibold focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)]">Remarques</summary><p className="mt-2">Date des remarques : {date(contextRow.point.date)}</p>{mode==='net' && legendContract?.envelopeTypeCode==='cto' && !effectiveIds.includes('contract:'+legendContract.id)?<p className="mt-2">NET par titre aux dates qualifiées ; sinon, NET historique global non ventilé lorsqu’il est documenté. Une seule représentation par date, jamais additionnée. « Afficher le NET global du contrat » conserve la vue globale sur toute la période. [REF-NET-SCOPE]</p>:null}{legendContract ? <p className="mt-2">+ / - value : gain du contrat entier sur la valorisation brute et les flux nets datés, distinct de la plus-value latente des titres et du total des seules séries visibles. Non affiché si la sélection du contrat ou les données nécessaires sont incomplètes.</p> : null}{unavailableAtDate.length?<p className="mt-2 text-amber-500">Valeurs indisponibles à cette date : {unavailableAtDate.map(({serie})=>serie.label).join(" · ")}. Couverture partielle conservée.</p>:null}{contextRow?Object.entries(contextRow.point.employeeSavingsEvidence??{}).filter(([id])=>contextLegend.some(({serie})=>serie.id==='contract:'+id)).map(([id,e])=><p key={id} className="mt-2 text-[var(--app-muted)]">{data.contracts.find(c=>c.id===id)?.name} : valeur source du {date(e.date)}{e.date!==contextRow.point.date?' · situation maintenue, aucune nouvelle observation':''}.</p>):null}{sourceFlowEvidence ? <p className="mt-2 text-[var(--app-muted)]">Preuve source archivée :{sourceContribution !== undefined ? ` versements ${money(sourceContribution!)}` : ""}{sourceContribution !== undefined && sourceNetCashFlow !== undefined ? " ·" : ""}{sourceNetCashFlow !== undefined ? ` flux net ${money(sourceNetCashFlow!)}` : ""}. Le calcul affiché utilise le registre daté.</p> : null}{cashNetEvidence.map(([id,value]) => <p key={`cash-net-${id}`} className="mt-2 text-xs">NET source avant correction des espèces : {money(value.sourceNetEur)} · BRUT source : {money(value.sourceGrossEur)} · espèces source : {money(value.sourceCashEur)}. Delta espèces : {money(value.deltaEur)} · NET effectif dérivé : {money(value.effectiveNetEur)}. Assiette des titres inchangée ; {value.historicalCostsKnown ? "coûts archivés inchangés" : "coûts historiques inconnus"}.</p>)}{sourceNetEvidence.length ? <p className="mt-2 text-[var(--app-muted)]">Net source conservé : {sourceNetEvidence.join(" · ")}.</p> : null}{missingNetReasons.map((reason) => <p key={reason} className="mt-2 text-amber-500">Net indisponible : {reason}</p>)}{unknownHoldings.length ? <p className="mt-2 text-amber-500">Quantité inconnue pour {unknownHoldings.length} titre(s) : détention non déduite.</p> : null}{gain ? <p className={`mt-2 border-t border-[var(--app-border)] pt-2 ${gain.amount === null ? "text-[var(--app-muted)]" : gain.amount > 0 ? "text-emerald-500" : gain.amount < 0 ? "text-red-500" : ""}`}>{gain.status === "unavailable" ? `Gain du contrat : Indisponible — ${unavailableGainReason}` : `Gain du contrat : ${gain.amount! >= 0 ? "+" : ""}${money(gain.amount!)}${gain.percentage === null ? ` (pourcentage indisponible — ${unavailableGainPercentage})` : ` (${gain.percentage >= 0 ? "+" : ""}${percent(gain.percentage)})`}`}</p> : null}{showContributions && contributionRows[rows.indexOf(contextRow)] != null ? <p className="mt-2 text-red-400">{contributionCaption} (hors total des valeurs) : {money(contributionRows[rows.indexOf(contextRow)]!)}</p> : null}{mode==='net'?<p className="mt-2">Qualité : {contextRow.quality}</p>:null}<p className="mt-2">{rowProvenance(contextRow.point)}</p>{mode==='net'&&Object.keys(contextRow.point.sourcePropertyNets??{}).some(id=>effectiveIds.includes(`contract:${id}`))?<p className="mt-2">Immobilier : convention net = brut ; net source conservé dans l’historique des preuves.</p>:null}{Object.entries(contextRow.point.declaredContractTotals??{}).filter(([id])=>effectiveIds.some(key=>key.split(':')[1]===id)).map(([id,value])=><p key={id} className="mt-2">Total BRUT déclaré : {money(value.grossEur)} · somme des composants : {money(value.componentSumEur)}. Écart d&apos;arrondi conservé, sans ajustement des espèces.</p>)}</details> : null;
  return <section className={`${expanded ? expandedTileClass : "relative"} min-w-0 border border-[var(--app-border)] bg-[var(--app-surface)] p-3 sm:p-5`}>
    <div className="pr-10"><h3 className="font-semibold">Historique patrimonial</h3><p className="text-xs text-[var(--app-muted)]">Aires empilées · granularité quotidienne · Europe/Paris · depuis le {date(PATRIMONY_HISTORY_START)} · légende du sommet vers la base</p></div>
    <button type="button" className="absolute right-3 top-3 border border-[var(--app-border)] p-1.5 text-[var(--app-muted)] hover:text-[var(--app-foreground)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)]" aria-label={expanded ? "Réduire l’historique patrimonial" : "Agrandir l’historique patrimonial"} aria-expanded={expanded} onClick={() => setExpanded((value) => !value)}><ExpandIcon expanded={expanded}/></button>
    <div className="mt-3 flex flex-wrap gap-3"><button type="button" className="settings-edit-action" disabled={exporting||!ids.length||!points.length} onClick={exportChart}>{exporting?"Export…":"Export graphe"}</button>{csvContract?<button type="button" className="settings-edit-action" onClick={()=>{try{const file=historyCsvFile(csvContract.data,csvContract.id);downloadPrivate(file.bytes,file.name,"text/csv;charset=utf-8");setExportError("");}catch{setExportError("Historique CSV indisponible ; aucun fichier incomplet téléchargé.");}}}>Export CSV</button>:null}</div>{csvContract?<p className="mt-2 text-xs text-[var(--app-muted)]">PNG : fenêtre visible et séries choisies. CSV : tout l’historique disponible du contrat et de ses actifs, quelle que soit la fenêtre.</p>:null}{exportError?<p role="alert" className="mt-2 text-sm text-red-500">{exportError}</p>:null}
    {!points.length ? <p role="status" className="mt-4 text-sm text-[var(--app-muted)]">{mode==='net' && csvContract && data.contracts.some(c=>c.id===csvContract.id&&c.envelopeTypeCode==='cto') ? 'Aucun détail NET qualifié dans cette sélection. Le NET global documenté reste accessible avec « Afficher le NET global du contrat ». [REF-NET-DETAIL]' : 'Aucune observation historique disponible pour ce contrat. Son statut actuel ne crée ni ne supprime d’historique.'}</p> : null}
    {supportContract ? <details className="mb-3 text-sm"><summary className="cursor-pointer py-2">Supports affichés</summary><div className="flex flex-wrap gap-3">{legendSeries.map(({serie})=><label key={serie.id} className="flex items-center gap-2"><input type="checkbox" checked={!hiddenSupportIds.includes(serie.id)} onChange={event=>setHiddenSupportIds(current=>event.target.checked?current.filter(id=>id!==serie.id):[...current,serie.id])}/><span style={{color:serie.color}}>{serie.label}</span></label>)}</div><p className="mt-2 text-xs text-[var(--app-muted)]">Le total historique non ventilé remplace les supports aux dates sans composition complète et concordante, sans répartition inventée.</p></details> : null}{hasContinuity?<p role="status" className="mt-3 text-xs text-[var(--app-muted)]">Du {date(points[0].date)} au {date(points.at(-1)!.date)} : dernières données connues prolongées. Dates sources dans Remarques ; aucune nouvelle observation enregistrée.</p>:null}
    {points.length===1&&rows.some(row=>row.hasKnownValues)?<p role="status" className="mt-3 text-sm text-[var(--app-muted)]">Une seule date documentée{rows[0].valid?` : ${money(rows[0].total)} au ${date(rows[0].point.date)}.`:' : couverture partielle.'} Aucune évolution n’est déduite.</p>:null}
    {!ids.length ? <p className="mt-6 text-sm text-[var(--app-muted)]">Sélectionnez au moins un élément.</p> : <div ref={scroller} onScroll={(event) => { const left=event.currentTarget.scrollLeft; setScrollLeft(left); if(Math.abs(event.currentTarget.clientWidth-timeScale.viewportWidth)<.5){scrollAnchor.current=historyTimeAnchor(timeScale,left); if(viewportRef)viewportRef.current={intervals:visibleIntervals,anchor:scrollAnchor.current};} }} onScrollEnd={(event)=>{if(timeScale.atMaximum&&!gesture.current){const element=event.currentTarget; const left=historyTimeScroll(timeScale,historyTimeAnchor(timeScale,element.scrollLeft)); if(Math.abs(left-element.scrollLeft)>.25)element.scrollLeft=left;}}} className={`relative mt-2 sm:mt-4 min-w-0 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden ${expanded ? mobile ? "shrink-0" : "min-h-0 flex-1" : ""}`} tabIndex={0} role="region" aria-label="Historique défilable horizontalement : glisser ou utiliser les flèches, Page précédente/suivante, Début et Fin" onKeyDown={(event) => { const element=event.currentTarget; const next=historyKeyboardScroll(event.key,element.scrollLeft,element.clientWidth,element.scrollWidth-element.clientWidth); if(next!==null){event.preventDefault();element.scrollLeft=next;} if(event.key==="Escape")onCloseLegend(); }}>
      <svg viewBox={`0 0 ${width} ${height}`} style={{ width, minWidth: width, height }} className="max-w-none cursor-grab select-none touch-pan-y active:cursor-grabbing" role="img" aria-label="Historique des valorisations sélectionnées" data-rendering="stacked"
        onPointerDown={(event) => { if(event.button!==0)return; gesture.current={pointerId:event.pointerId,x:event.clientX,y:event.clientY,scrollLeft:scroller.current?.scrollLeft??0,direction:"tap"}; if(event.pointerType==="mouse")event.preventDefault(); }}
        onPointerMove={(event) => { const start=gesture.current,element=scroller.current; if(!start||!element||start.pointerId!==event.pointerId)return; if(start.direction==="tap")start.direction=historyGesture(event.clientX-start.x,event.clientY-start.y); if(start.direction==="horizontal"){event.preventDefault();event.currentTarget.setPointerCapture(event.pointerId);element.scrollLeft=start.scrollLeft-(event.clientX-start.x);} }}
        onPointerUp={(event) => { const start=gesture.current; gesture.current=null; if(event.currentTarget.hasPointerCapture(event.pointerId))event.currentTarget.releasePointerCapture(event.pointerId); if(!start||start.pointerId!==event.pointerId||start.direction!=="tap"||historyGesture(event.clientX-start.x,event.clientY-start.y)!=="tap"||!rows.length)return; const rect=event.currentTarget.getBoundingClientRect(); const target=(event.clientX-rect.left)/rect.width*width; const selected=rows.reduce((best,_,index)=>Math.abs(x(index)-target)<Math.abs(x(best)-target)?index:best,0); onSelectDate?.(rows[selected].point); }}
        onPointerCancel={() => {gesture.current=null;}}>
        <defs>{areas.map((area,index)=><linearGradient key={area.id} id={`area-${index}`} x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor={area.color} stopOpacity=".25"/><stop offset="100%" stopColor={area.color} stopOpacity=".05"/></linearGradient>)}<clipPath id="history-plot"><rect x={scrollLeft+pad-1} y={plotTop-(rows.length===1?6:0)} width={Math.max(1,viewportWidth-pad*2)+2} height={height-plotTop-plotBottom+(rows.length===1?12:0)}/></clipPath></defs>
        {[0,.25,.5,.75,1].map((tick) => { const value=visibleDomain.min+visibleDomain.span*tick; return <g key={tick}><line x1={pad} x2={width-pad} y1={y(value)} y2={y(value)} stroke="var(--app-border)" /><text x={scrollLeft+pad+2} y={y(value)-4} fill="var(--app-muted)" fontSize={mobile ? 11 : 13} stroke="var(--app-surface)" strokeWidth={3} paintOrder="stroke">{Math.abs(value) >= 1000 ? formatMoney(value / 1000, "EUR").replace(/\u20ac/u, "k\u20ac") : money(value)}</text></g>; })}
        <g clipPath="url(#history-plot)">{areas.map((area,index) => <g key={area.id} data-series-id={area.id}><path d={area.path} fill={`url(#area-${index})`} stroke="none" /><path d={area.upperPath} fill="none" stroke={area.color} strokeOpacity="1" strokeWidth="2" />{area.isolatedPoints.map(([cx,cy],i)=><circle key={i} cx={cx} cy={cy} r={rows.length===1?5:3} fill={area.color} />)}</g>)}
        {showContributions && contributionPath ? <path d={contributionPath} fill="none" stroke="#ef4444" strokeWidth="2" strokeDasharray="7 5" /> : null}</g>
        {hoverRow ? <line x1={x(hover!)} x2={x(hover!)} y1={plotTop} y2={height-plotBottom} stroke="var(--app-foreground)" strokeDasharray="3 3" /> : null}
        {mode === "gross" ? rows.map((row,index) => row.valid && Math.abs(row.total - row.values.reduce<number>((sum,value) => sum + (value ?? 0),0)) > 0.000001 ? <circle key={row.point.date} cx={x(index)} cy={y(row.total)} r="3" fill="var(--app-gold)"><title>{`Total déclaré : ${money(row.total)}`}</title></circle> : null) : null}
        {mode==="gross" ? rows.map((row,index) => !row.valid ? <circle key={`partial-${row.point.date}`} cx={x(index)} cy={plotTop+8} r="3" fill="var(--app-muted)" data-coverage={row.hasKnownValues ? "partial" : "unavailable"}><title>{row.hasKnownValues ? "Couverture partielle : sous-total connu, aucun total complet tracé" : "Valorisation indisponible : aucun zéro supposé"}</title></circle> : null) : null}
        {visiblePeriod ? visiblePeriod.first===visiblePeriod.last ? <text x={scrollLeft+viewportWidth/2} y={height-8} textAnchor="middle" fill="var(--app-muted)" fontSize={mobile ? 11 : 13}>{date(visiblePeriod.first)}</text> : <><text x={scrollLeft+pad} y={height-8} fill="var(--app-muted)" fontSize={mobile ? 11 : 13}>{date(visiblePeriod.first)}</text><text x={scrollLeft+viewportWidth-pad} y={height-8} textAnchor="end" fill="var(--app-muted)" fontSize={mobile ? 11 : 13}>{date(visiblePeriod.last)}</text></> : null}
      </svg>
      {!belowDetail ? detailPanel : null}
    </div>}
    {ids.length>0&&timeDomain.first?<div className="mt-3 grid gap-1" data-testid="history-time-zoom">
      <div className="flex flex-wrap items-baseline justify-between gap-2 text-sm"><label htmlFor={zoomId} className="font-semibold">Zoom temporel</label><output htmlFor={zoomId} className="text-xs text-[var(--app-muted)]">{timeScale.disabled?`${timeDomain.spanDays+1} date${timeDomain.spanDays?'s':''}`:timeScale.zoom<.01?"Tout l’historique":`${Math.round(timeScale.intervals)+1} dates quotidiennes`}</output></div>
      <input id={zoomId} type="range" min="0" max="100" step="0.1" value={timeScale.zoom} disabled={timeScale.disabled} onChange={event=>changeZoom(Number(event.target.value))} aria-valuetext={timeScale.disabled?"Tout l’historique affichable":timeScale.zoom<.01?"Tout l’historique affichable":`${Math.round(timeScale.intervals)+1} dates quotidiennes visibles`} className="min-h-11 w-full cursor-pointer accent-[var(--app-gold)] disabled:cursor-default disabled:opacity-50"/>
      <div className="flex justify-between gap-3 text-xs text-[var(--app-muted)]"><span>Tout l’historique</span><span>{Math.min(5,timeDomain.spanDays+1)} dates</span></div>
      {visiblePeriod?<p className="text-xs text-[var(--app-muted)]" data-testid="history-visible-period">Période visible : {date(visiblePeriod.first)}{visiblePeriod.last!==visiblePeriod.first?` — ${date(visiblePeriod.last)}`:""}</p>:null}
    </div>:null}
    {belowDetail ? detailPanel : null}
    {detailVisibility === "unavailable" && selectedDate?<div role="status" data-testid="history-detail" className="mt-3 border border-[var(--app-border)] bg-[var(--app-background)]/95 p-3 text-xs"><strong>{date(selectedDate)}</strong><p className="mt-2">Date sélectionnée indisponible dans les données actualisées. Aucune autre date n’a été sélectionnée.</p><button type="button" className="mt-2 underline" onClick={onCloseLegend}>Fermer le détail de la date sélectionnée</button></div>:null}
    {contextNotes}
    {ctoContract ? <p data-testid="cto-net-coverage" className="mt-3 text-xs text-[var(--app-muted)]">{ctoNetHistoryCoverage(rows,ctoContract).map(group => `${group.kind === "global" ? "NET historique global non ventilé" : group.kind === "detail" ? "NET par titre" : "NET indisponible"} : ${date(group.first)}${group.last !== group.first ? ` au ${date(group.last)}` : ""} (${group.count} dates)`).join(" · ")}. Sources alternatives, jamais additionnées. Une couverture incomplète sans NET global n’est pas représentée par les seules espèces.</p> : null}
    <div className="mt-3 text-xs"><button type="button" className="font-semibold focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)]" aria-expanded={tableOpen} onClick={()=>setTableOpen((value)=>!value)}>{tableOpen?"Cacher le tableau":"Afficher le tableau"}</button>{tableOpen?<div className="mt-2 max-h-72 overflow-auto"><table className="w-full border-collapse text-left"><thead><tr><th className="p-2">Date</th>{legendSeries.map(({serie})=><th key={serie.id} className="p-2" style={{color:serie.color}}>{serie.label}</th>)}{showContributions?<th className="p-2 text-red-400">{contributionCaption}</th>:null}<th className="p-2">Total</th><th className="p-2">Qualité</th><th className="p-2">Provenance</th></tr></thead><tbody>{rows.map((row,rowIndex)=><tr key={row.point.date} className="border-t border-[var(--app-border)]"><th className="p-2 font-normal">{date(row.point.date)}</th>{legendSeries.map(({serie,index})=><td key={serie.id} className="p-2">{!row.activeIds.includes(serie.id) || historicalHoldingState(row.point,serie.id,data.contracts)==="absent"?"—":row.values[index]===null?"Indisponible":money(row.values[index]!)}</td>)}{showContributions?<td className="p-2">{contributionRows[rowIndex]===null?"Indisponible":money(contributionRows[rowIndex]!)}</td>:null}<td className="p-2">{row.hasKnownValues ? `${row.valid ? "" : "Sous-total connu (partiel) : "}${money(row.total)}` : "Indisponible"}</td><td className="p-2">{mode==="gross"?"Brut":[row.quality,...row.netReasons].join(" · ")}</td><td className="p-2">{rowProvenance(row.point)}</td></tr>)}</tbody></table></div>:null}</div>
    <p className="mt-2 text-xs text-[var(--app-muted)]">Couverture de la fenêtre : {coveredRows}/{rows.length} dates complètes.{missingLabels.length ? ` Séries sans valeur documentée : ${missingLabels.join(", ")}.` : ""}</p>
    {mode==="gross"&&rows.some(row=>!row.valid)?<p className="mt-2 text-xs text-[var(--app-muted)]">Repères gris : couverture partielle ou valeur indisponible, sans hauteur monétaire ni total complet tracé. Le détail conserve les montants connus.</p>:null}
    {points.some(point=>Object.keys(point.employeeSavingsEvidence??{}).length>0)?<p className="mt-2 text-xs text-[var(--app-muted)]">Situations salariées maintenues en paliers depuis leur date source ; les reconductions ne sont pas de nouvelles observations.</p>:null}
    {points.some((point,index) => index>0 && new Date(`${point.date}T12:00:00Z`).getTime()-new Date(`${points[index-1].date}T12:00:00Z`).getTime()>86400000*1.5) ? <p className="mt-2 text-xs text-amber-500">Les journées absentes restent visibles comme ruptures de série.</p> : null}
  </section>;
}

export function PatrimonyCharts({ data, fixedContractId = null, historyViewport, initialView, onViewChange }: { data: PatrimonyChartData; fixedContractId?: string | null; historyViewport?: HistoryViewportRef; initialView?: ChartViewState|null; onViewChange?: (view:ChartViewState)=>void }) {
  const fixed = fixedContractId ? data.contracts.find((contract) => contract.id === fixedContractId) ?? null : null;
  const temporalIds=useMemo(()=>historyTimeScopeIds(data.contracts,fixedContractId,data.navigationExcludedContractIds),[data.contracts,fixedContractId,data.navigationExcludedContractIds]);
  const temporalDomain=useMemo(()=>historyTimeDomain(graphHistoryPointsForSelection(data.points,temporalIds,data.contracts)),[data.points,temporalIds,data.contracts]);
  const showDistributions = hasContractDistributions(fixed);
  const [selectedHistoryDate, setSelectedHistoryDate] = useState<string | null>(()=>initialView?.selectedDate??null);
  const [historyLegendClosed, setHistoryLegendClosed] = useState(()=>initialView?.historyLegendClosed??false);
  const [selection, setSelection] = useState<Selection>(() => restoreChartSelection(initialView?.selection ?? (fixedContractId ? (fixed ? selectionForContract(fixed, data.points) : {}) : selectionForScope(data.contracts, data.initialScope)),data.contracts));
  const detailed = fixed?.envelopeTypeCode === "assurance_vie" ? false : isDetailed(selection);
  const [requestedMode, setRequestedMode] = useState<ChartMode>(() => initialView?.requestedMode ?? (fixed ? fixed.envelopeTypeCode !== "assurance_vie" && isDetailed(selectionForContract(fixed, data.points)) ? "gross" : initialContractChartMode(fixed, data.points) : "net"));
  const sharedEmployeeHistory = Boolean(fixed && (fixed.sourceKey === "peg" || fixed.sourceKey === "per_col"));
  const sharedPoints = sharedEmployeeHistory ? data.points.filter((point) => point.employeeSavingsCombined !== null) : [];
  const ownPoints = sharedEmployeeHistory ? data.points.filter((point) => point.values[`contract:${fixed!.id}:gross`] !== undefined) : data.points;
  const combinedOnly = sharedPoints.length > 0 && ownPoints.length === 0;
  const perGrossOnly=fixed?.envelopeTypeCode==='per_col';
  const mode: ChartMode = detailed || combinedOnly || perGrossOnly ? "gross" : requestedMode;
  const titleNet = fixed?.envelopeTypeCode==='cto';
  const [globalCtoNet,setGlobalCtoNet]=useState(()=>initialView?.globalCtoNet??false);
  const allowsContractNet = Boolean(fixed && (['pea','pea_pme','cto'].includes(fixed.envelopeTypeCode??'') || data.points.some(point => point.declaredContractTotals?.[fixed.id])));
  const contractNet = Boolean(allowsContractNet && (!titleNet || globalCtoNet) && (detailed || titleNet) && requestedMode === "net" && !combinedOnly);
  const historyMode: ChartMode = (contractNet || (titleNet && requestedMode==="net")) ? "net" : mode;
  const ids = resolveSelection(data.contracts, selection);
  const presentationIds = historyPresentationIds(fixed,fixed?.envelopeTypeCode === "assurance_vie" && historyMode === "net" ? [`contract:${fixed.id}`] : contractNet ? [`contract:${fixed!.id}`] : titleNet && historyMode==="net" ? fixed!.children.map(child=>child.id) : ids);
  const avSupportContract = fixed?.envelopeTypeCode === "assurance_vie" && historyMode === "gross" ? fixed : undefined;
  const historyIds = sharedPoints.length ? [...presentationIds, "employee-savings-combined"] : presentationIds;
  const availablePoints = graphHistoryPointsForSelection(data.points,historyIds,data.contracts);
  const selectedHistoryPoint = selectedPoint(availablePoints,selectedHistoryDate);
  const missingSelectedDate=Boolean(selectedHistoryDate&&!selectedHistoryPoint);
  const unavailableExposure: ReturnType<typeof exposureSlices>={slices:[],unavailable:"Date sélectionnée indisponible dans les données actualisées."};
  const sectors = missingSelectedDate?unavailableExposure:exposureSlices(data, selection, "sector", "gross", selectedHistoryPoint);
  const [geographyRegions,setGeographyRegions]=useState(()=>initialView?.geographyRegions??false);
  const geography = missingSelectedDate?unavailableExposure:data.geographyReferences?chartGeography(data,selection,selectedHistoryPoint,geographyRegions):exposureSlices(data, selection, "geography", "gross", selectedHistoryPoint);
  useLayoutEffect(()=>{onViewChange?.({selectedDate:selectedHistoryDate,historyLegendClosed,selection,requestedMode,globalCtoNet,geographyRegions});},[onViewChange,selectedHistoryDate,historyLegendClosed,selection,requestedMode,globalCtoNet,geographyRegions]);
  const pointDateNote = (point:ChartPoint|null) => point ? `${Object.keys(point.continuityEvidence??{}).some(id=>historyIds.some(key=>key.split(':')[1]===id))?'Dernières données connues projetées au':'Date des valeurs :'} ${date(point.date)}` : selectedHistoryDate?`Date sélectionnée : ${date(selectedHistoryDate)} · indisponible.`:'Date des valeurs : Non disponible';
  const exposureDateNote = () => pointDateNote(selectedHistoryPoint);
  const compositionDateNote = pointDateNote(selectedHistoryPoint);
  const composition = selectedHistoryPoint ? historicalPatrimonyComposition(data.contracts, selection, mode, selectedHistoryPoint) : {slices:[],missing:[],coverageNote:"Aucune situation historique disponible."};
  const fixedCompositionPoint = fixed && isSecuritiesEnvelopeType(fixed.envelopeTypeCode) ? selectedHistoryPoint : null;
  const fixedComposition = fixed && fixedCompositionPoint ? historicalCompositionSlices(data.contracts, fixed, fixedCompositionPoint) : null;
  return <div className="mt-7 grid min-w-0 gap-5">
    {!fixedContractId ? <details className="border border-[var(--app-border)] bg-[var(--app-surface)] p-4"><summary className="cursor-pointer font-semibold">Filtres du périmètre patrimonial</summary><div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">{[...data.contracts].sort((a,b)=>a.name.localeCompare(b.name,"fr-FR",{sensitivity:"base",numeric:true})||a.id.localeCompare(b.id,"en")).map((contract)=>{const selected=selection[contract.id];return <fieldset key={contract.id} className="border border-[var(--app-border)] p-3"><legend className="px-1 font-semibold">{contract.name}</legend><label className="flex gap-2"><input type="checkbox" checked={!!selected} onChange={(event)=>setSelection((current)=>{const next={...current};if(event.target.checked)next[contract.id]="global";else delete next[contract.id];return next;})}/> Inclure</label>{selected?<><label className="mt-2 flex gap-2"><input type="radio" name={`scope-${contract.id}`} checked={selected==="global"} onChange={()=>setSelection((current)=>({...current,[contract.id]:"global"}))}/> Contrat global</label><label className="mt-1 flex gap-2"><input type="radio" name={`scope-${contract.id}`} disabled={!contract.children.length} checked={Array.isArray(selected)} onChange={()=>setSelection((current)=>({...current,[contract.id]:contract.children.map((child)=>child.id)}))}/> Détail</label>{Array.isArray(selected)?<div className="ml-5 mt-2 grid gap-1 text-xs">{contract.children.map((child)=><label key={child.id} className="flex gap-2"><input type="checkbox" checked={selected.includes(child.id)} onChange={(event)=>setSelection((current)=>({...current,[contract.id]:event.target.checked?[...selected,child.id]:selected.filter((id)=>id!==child.id)}))}/>{child.label}</label>)}</div>:null}</>:null}</fieldset>})}</div></details> : <details className="border border-[var(--app-border)] bg-[var(--app-surface)] p-4"><summary className="cursor-pointer font-semibold">Périmètre verrouillé sur {fixed?.name ?? "contrat indisponible"}</summary><div className="mt-3 grid gap-2 text-sm sm:grid-cols-2 lg:grid-cols-3">{data.contracts.map((contract)=><label key={contract.id} className={`flex gap-2 ${contract.id===fixedContractId?"":"opacity-45"}`}><input type="checkbox" checked={contract.id===fixedContractId} disabled readOnly/>{contract.name}{!contract.isActive?" · inactif":""}</label>)}</div>{!fixed?<p className="mt-3 text-amber-500">Ce contrat est introuvable ou inaccessible. Aucun autre périmètre n’est chargé.</p>:null}</details>}
    <div className="flex flex-wrap items-center gap-3"><span className="text-sm font-semibold">Mode</span><button type="button" aria-pressed={historyMode==="gross"} className={`border px-3 py-1 text-sm ${historyMode==="gross"?"border-[var(--app-gold)]":"border-[var(--app-border)]"}`} onClick={()=>setRequestedMode("gross")}>Brut</button>{!perGrossOnly?<button type="button" aria-pressed={historyMode==="net"} disabled={(detailed && !allowsContractNet) || combinedOnly} className={`border px-3 py-1 text-sm disabled:opacity-40 ${historyMode==="net"?"border-[var(--app-gold)]":"border-[var(--app-border)]"}`} onClick={()=>setRequestedMode("net")}>Net</button>:null}{detailed?<span className="text-xs text-[var(--app-muted)]">{historyMode==="net" ? contractNet ? "NET global du contrat entier, indépendant des sélections de titres." : "NET par titre quand il est prouvé ; sinon, NET historique global non ventilé." : "BRUT détaillé par titre."}</span>:null}</div>
    {titleNet && historyMode==='net'?<label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={globalCtoNet} onChange={event=>setGlobalCtoNet(event.target.checked)}/>Afficher le NET global du contrat (sources et calculs documentés)</label>:null}
    {!fixedContractId ? <button type="button" className="justify-self-start text-sm font-semibold text-[var(--app-gold)]" onClick={() => { setSelection(selectionForScope(data.contracts, data.initialScope)); setRequestedMode("net"); }}>Réinitialiser les filtres</button> : null}
    {fixed && !perGrossOnly && ownPoints.length > 0 && initialContractChartMode(fixed, ownPoints) === "gross" && !detailed ? <p role="status" className="text-sm text-[var(--app-muted)]">{fixed.envelopeTypeCode==='assurance_vie'?'Estimation NET indisponible aux dates documentées. Le mode Net conserve les motifs et les éventuelles sources dans Remarques ; Brut présente les valorisations.':'Aucun net historique documenté pour ce contrat. Le mode Brut présente les valeurs sources sans en déduire un net.'}</p> : null}
    {sharedPoints.length ? <p role="status" className="text-sm text-[var(--app-muted)]">Historique commun PEG + PER COL — non ventilé. Ces {sharedPoints.length} observations sont présentées sous une série distincte dans le même graphique ; elles ne représentent pas ce contrat seul et ne s’ajoutent pas à ses situations individuelles. Le NET commun et les montants individuels de ces dates restent indisponibles ; le mode Brut permet de consulter le total commun.</p> : null}
    <HistoryChart supportContract={avSupportContract} orderByEnvelope={!fixedContractId} data={data} ids={avSupportContract ? [...lifeInsuranceSupportIds(avSupportContract), `contract:${avSupportContract.id}`] : historyIds} timeDomain={temporalDomain} viewportRef={historyViewport} mode={historyMode} showContributions={showsHistoricalContributions(fixed)} historicalGainContractId={fixed && !["immobilier","epargne_liquide"].includes(fixed.envelopeTypeCode??"") ? fixed.id : undefined} csvContract={fixed?{data,id:fixed.id}:undefined} selectedDate={selectedHistoryDate} legendClosed={historyLegendClosed} onCloseLegend={()=>setHistoryLegendClosed(true)} onSelectDate={(point) => { setSelectedHistoryDate(point?.date??null); setHistoryLegendClosed(false); }}/>
    {showDistributions ? <div className="grid gap-5 lg:grid-cols-3">
      <Donut title="Répartition sectorielle détaillée" slices={sectors.slices} unavailable={sectors.unavailable} dateNote={exposureDateNote()} details={sectors.details} remarks={sectors.trace} note={`Base BRUT, indépendante du mode principal. Même périmètre sélectionné. Les espèces sont exclues. ${sectors.coverageNote ?? ""}`}/>
      <Donut title="Répartition géographique" slices={geography.slices} unavailable={geography.unavailable} dateNote={exposureDateNote()} details={geography.details} remarks={geography.trace} note={`Base BRUT, indépendante du mode principal. ${MIXED_GEOGRAPHY_HELP}. Aucune attribution déduite du ticker ou du siège. ${geography.coverageNote ?? ""}`} controls={<div className="flex flex-wrap gap-2" aria-label="Niveau géographique"><button type="button" aria-pressed={!geographyRegions} className="settings-edit-action" onClick={()=>setGeographyRegions(false)}>Pays</button><button type="button" aria-pressed={geographyRegions} className="settings-edit-action" onClick={()=>setGeographyRegions(true)}>Régions</button></div>}/>
      {fixedComposition && fixedCompositionPoint ? <Donut title="Composition par titres" slices={fixedComposition.slices} unavailable={fixedComposition.unavailable} dateNote={pointDateNote(fixedCompositionPoint)} note="Détentions et valorisations documentées à cette date. Pourcentages des titres hors espèces ; les espèces restent affichées en montant."/> : null}
      {!fixed?<Donut title="Composition du patrimoine" slices={composition.slices} dateNote={compositionDateNote} details={(composition.missing??[]).map(name=>({id:name,name,reason:"Valorisation ou détention indisponible à cette date ; aucun montant individuel ajouté.",inDonut:false}))} note={`Composition ${mode === "gross" ? "brute" : "nette"} du périmètre exact sélectionné. ${composition.coverageNote}`}/>:null}
    </div> : null}
    <details className="text-xs text-[var(--app-muted)]"><summary className="cursor-pointer">Provenance et couverture</summary><p className="mt-2">Historique : {availablePoints.length} dates disponibles, dernière date {availablePoints.at(-1) ? date(availablePoints.at(-1)!.date) : "indisponible"}.{showDistributions ? " Expositions : base BRUT de la date sélectionnée, capture prioritaire puis continuité/reprise autorisée traçable ; aucune rétroprojection financière." : ""}</p></details>
  </div>;
}
