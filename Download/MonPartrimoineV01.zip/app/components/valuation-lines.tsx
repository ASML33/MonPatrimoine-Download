import type { ReactNode } from 'react';

// Presentation only: callers retain their values, percentages and precision.
export type ValuationLine = {
  id: string;
  label: ReactNode;
  color?: string;
  quantityApplicable?: boolean;
  quantityLabel?: string | null;
  latent?: { percentage: number | null } | null;
  percentageLabel: string | null;
  percentageApplicable?: boolean;
  valueLabel: string;
  valueColor?: string;
  detail?: ReactNode;
};

export function ValuationLines({ lines, hideUnknownMetrics = false, footer }: { lines: ValuationLine[]; hideUnknownMetrics?: boolean; footer?: ReactNode }) {
  const quantities = lines.some(line => line.quantityApplicable);
  return <ul className={`grid min-w-0 gap-x-3 gap-y-2 tabular-nums ${quantities ? 'grid-cols-[minmax(0,1fr)_auto_auto_auto]' : 'grid-cols-[minmax(0,1fr)_auto_auto]'}`}>
    {lines.map(line => <li key={line.id} className="col-span-full grid grid-cols-subgrid items-baseline gap-y-1">
      <span className="col-span-full min-w-0 break-words sm:col-span-1" style={{ color: line.color }}>{line.label}</span>
      {quantities ? <span data-metric="quantity" className="col-start-2 whitespace-nowrap text-right">{line.quantityApplicable && !(hideUnknownMetrics && line.quantityLabel == null) ? <><span className="sr-only">Nombre de parts : </span>{line.quantityLabel == null ? 'Indisponible' : <>{line.quantityLabel}<span> part(s)</span></>}</> : null}</span> : null}
      {line.latent ? <span data-metric="unrealized-gain" className={`${quantities ? 'col-start-3' : 'col-start-2'} whitespace-nowrap text-right ${line.latent.percentage === null ? 'text-[var(--app-muted)]' : line.latent.percentage > 0 ? 'text-emerald-500' : line.latent.percentage < 0 ? 'text-red-500' : 'text-[var(--app-foreground)]'}`}><span className="sr-only">Plus-value ou moins-value latente en pourcentage : </span>{line.latent.percentage === null ? 'Indisponible' : <>{line.latent.percentage > 0 ? '+' : line.latent.percentage < 0 ? '−' : ''}{new Intl.NumberFormat('fr-FR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Math.abs(line.latent.percentage))} %</>}</span> : <span data-metric="allocation" className={`${quantities ? 'col-start-3' : 'col-start-2'} whitespace-nowrap text-right`}>{line.percentageApplicable === false || (hideUnknownMetrics && line.percentageLabel == null) ? null : <><span className="sr-only">Répartition : </span>{line.percentageLabel ?? 'Indisponible'}</>}</span>}
      <span data-metric="valuation" className="whitespace-nowrap text-right" style={{ color: line.valueColor }}><span className="sr-only">Valorisation : </span>{line.valueLabel}</span>
      {line.detail ? <div className="col-span-full">{line.detail}</div> : null}
    </li>)}
    {footer}
  </ul>;
}
