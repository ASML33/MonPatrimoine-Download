import Link from 'next/link';export function ReferenceLinks(){return <Link href="/envelopes">Enveloppes</Link>}
