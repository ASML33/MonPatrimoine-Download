"use client";

import { useActionState } from "react";
import { refreshAutomaticPricesAction, type AutomaticPriceRefreshState } from "@/app/dashboard-actions";

function formatTimestamp(value: string | null) {
  return value ? new Intl.DateTimeFormat("fr-FR", { dateStyle: "short", timeStyle: "short", timeZone: "Europe/Paris" }).format(new Date(value)) : "—";
}

const attemptLabels = {
  success: "Cours retenu",
  provider_unavailable: "Fournisseur indisponible",
  asset_unavailable: "Instrument introuvable",
  quota_exceeded: "Quota atteint",
  access_denied: "Accès refusé",
  timeout: "Délai dépassé",
  network_error: "Erreur réseau",
  provider_failed: "Erreur fournisseur",
  authentication_failed: "Authentification refusée",
  price_unavailable: "Prix indisponible",
  invalid_quote: "Réponse invalide",
  stale_quote: "Cours plus ancien ignoré",
  all_providers_failed: "Tous les fournisseurs ont échoué",
  qualification_pending: "Exclu : qualification non acquise",
  incompatible_region: "Exclu : région non configurée",
  incompatible_capability: "Exclu : capacité non configurée",
  incompatible_instrument: "Exclu : instrument non résolu",
} as const;

export function AutomaticPriceRefresh() {
  const [state, action, pending] = useActionState(refreshAutomaticPricesAction, { status: "idle" } as AutomaticPriceRefreshState);
  return <section className="mt-6 grid gap-4 rounded-md border border-[var(--app-border)] bg-[var(--app-surface)] p-4 sm:p-6">
    <div>
      <h2 className="text-sm font-semibold">Cours automatiques</h2>
      <p className="mt-1 text-xs text-[var(--app-muted)]">Actualise uniquement les actifs en mode cours de marché.</p>
    </div>
    <form action={action} className="grid gap-2 sm:justify-items-end">
      <button type="submit" className="settings-primary-button" disabled={pending}>{pending ? "Actualisation…" : "Actualiser les cours"}</button>
      {state.summary && <details className="w-full max-w-2xl text-xs sm:text-right">
        <summary className="cursor-pointer font-semibold text-[var(--app-gold)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)]">
          {state.summary.successes} réussite(s) · {state.summary.failures} échec(s) · {state.summary.ignored} ignoré(s)
        </summary>
        <ul className="mt-3 grid gap-3 text-left">
          {state.summary.details.map((detail) => <li key={detail.assetId} className="rounded-md border border-[var(--app-border)] p-3">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <strong>{detail.assetName}{detail.symbol ? ` · ${detail.symbol}` : ""}</strong>
              <span className={detail.status === "success" ? "text-emerald-500" : detail.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}>
                {detail.status === "success" ? "Succès" : detail.status === "error" ? "Échec" : "Ignoré"}
              </span>
            </div>
            <dl className="mt-2 grid gap-1 text-[var(--app-muted)] sm:grid-cols-2">
              <div><dt className="inline font-medium">Fournisseur principal : </dt><dd className="inline">{detail.primaryProvider ?? "Aucun compatible"}</dd></div>
              <div><dt className="inline font-medium">Fournisseurs appelés : </dt><dd className="inline">{detail.providers.join(" → ") || "Aucun"}</dd></div>
              <div><dt className="inline font-medium">Source retenue : </dt><dd className="inline">{detail.sourceName ?? "—"}</dd></div>
              <div><dt className="inline font-medium">Fallback : </dt><dd className="inline">{detail.fallbackUsed ? "Oui" : "Non"}</dd></div>
              <div><dt className="inline font-medium">Prix : </dt><dd className="inline">{detail.price && detail.currencyCode ? `${detail.price} ${detail.currencyCode}` : "—"}</dd></div>
              <div><dt className="inline font-medium">Date du cours : </dt><dd className="inline">{formatTimestamp(detail.observedAt)}</dd></div>
              <div><dt className="inline font-medium">Récupération : </dt><dd className="inline">{formatTimestamp(detail.retrievedAt)}</dd></div>
              {detail.status === "success" ? <div><dt className="inline font-medium">Persistance : </dt><dd className="inline">{detail.persisted ? "Nouveau cours enregistré" : "Cours identique déjà présent"}</dd></div> : null}
            </dl>
            {detail.attempts.length ? <div className="mt-3">
              <p className="font-medium">Tentatives</p>
              <ol className="mt-1 grid gap-1 text-[var(--app-muted)]">
                {detail.attempts.map((attempt, index) => <li key={`${attempt.slot ?? "direct"}-${attempt.provider}-${index}`}>
                  {index + 1}. {attempt.provider}{attempt.providerSymbol ? ` · ${attempt.providerSymbol}` : ""} — {attempt.code ? attemptLabels[attempt.code] : attemptLabels.success}
                  {attempt.retryAfter ? ` · reprise possible ${formatTimestamp(attempt.retryAfter)}` : ""}
                </li>)}
              </ol>
            </div> : null}
            {detail.error ? <p className="mt-2 text-red-500">{detail.error}</p> : null}
          </li>)}
        </ul>
      </details>}
      {state.message && <p role="status" aria-live="polite" className={`max-w-xl text-xs ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p>}
    </form>
  </section>;
}
