'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, useSyncExternalStore, type ReactNode } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { NavigationSessionStore, ExpiredNavigation, ChangedNavigationIdentity, SupersededNavigation, type NavigationStamp, type NavigationReply } from '@/lib/navigation/session-store';
import { navigationChartSelection } from '@/lib/navigation/chart-selection';
import { PatrimonyCharts } from './patrimony-charts';
import type { HistoryViewportState } from '@/lib/patrimony/history-time-scale';
import type { ChartViewState } from '@/lib/patrimony/chart-view-state';
import { bindNavigationFreshness } from '@/lib/navigation/freshness-events';

const Context=createContext<NavigationSessionStore|null>(null);
const serverSnapshot={epoch:0,status:'empty' as const,data:null,stamp:null,error:null};

export function NavigationSessionProvider({children}:{children:ReactNode}) {
  const [store]=useState(()=>new NavigationSessionStore(async(known,check,signal)=>{
    const query=new URLSearchParams();
    if(known){query.set('revision',known.revision);query.set('session',known.session);query.set('day',known.day);}
    if(check)query.set('check','1');
    const response=await fetch('/api/patrimony/navigation?'+query,{cache:'no-store',credentials:'same-origin',redirect:'error',signal});
    if(response.status===401)throw new ExpiredNavigation();
    if(!response.ok)throw Error('Historique indisponible');
    return await response.json() as NavigationReply;
  }));
  const path=usePathname();
  useEffect(()=>{
    if(path==='/login'||path.startsWith('/auth/'))store.clear(true);
  },[path,store]);
  useEffect(()=>{
    let channel:BroadcastChannel|null=null;
    if(typeof BroadcastChannel!=='undefined'){
      channel=new BroadcastChannel('monpatrimoine-navigation-v1');
      channel.onmessage=event=>{if(event.data?.type==='invalidate')store.invalidate(false);else if(event.data?.type==='session-ended'&&typeof event.data.session==='string'&&/^[a-f0-9]{64}$/.test(event.data.session))store.endSession(false,event.data.session);};
      store.setBroadcaster((type,session)=>channel?.postMessage({type:type??'invalidate',...(session?{session}:{})}));
    }
    const unbindFreshness=bindNavigationFreshness(store,window,document);
    return()=>{unbindFreshness();channel?.close();store.setBroadcaster(()=>{});};
  },[store]);
  return <Context value={store}>{children}</Context>;
}

// Included by the authenticated header on all private pages, including pages
// without graphs. A switch of account/session cannot retain the previous model.
export function NavigationSessionIdentity({identity}:{identity:NavigationStamp|null}) {
  const store=useContext(Context);
  const router=useRouter(),path=usePathname();
  const state=useSyncExternalStore(store?.subscribe??(()=>()=>{}),store?.getSnapshot??(()=>serverSnapshot),()=>serverSnapshot);
  const seen=useRef(state.epoch);
  useEffect(()=>{store?.bindIdentity(identity);},[store,identity]);
  useEffect(()=>{
    if(seen.current!==state.epoch){seen.current=state.epoch;if(path==='/'||path==='/contracts')router.refresh();}
  },[state.epoch,path,router]);
  return state.status==='error'&&(path==='/'||path==='/contracts')?<p role="status" className="px-4 py-2 text-sm text-[var(--app-muted)]">Vérification des données indisponible. <button type="button" className="settings-edit-action" onClick={()=>{store?.invalidate();router.refresh();}}>Réessayer</button></p>:null;
}

export function SessionPatrimonyCharts({owner,expectedRevision,validationId,fixedContractId=null,initialScope='total'}:{owner:string;expectedRevision:string;validationId:string;fixedContractId?:string|null;initialScope?:'total'|'outside-real-estate'}) {
  const store=useContext(Context);
  if(!store)throw Error('Navigation session unavailable');
  const snapshot=useSyncExternalStore(store.subscribe,store.getSnapshot,()=>serverSnapshot);
  // Display choices survive the existing freshness gate/remount, within this
  // same owner/session/scope only. No financial model or persistent storage.
  const historyViewport=useRef<HistoryViewportState|null>(null);
  const [savedView,setSavedView]=useState<{identity:string;view:ChartViewState}|null>(null);
  const viewIdentity=owner+':'+(snapshot.stamp?.session??'unvalidated')+':'+(fixedContractId??initialScope);
  const saveView=useCallback((view:ChartViewState)=>setSavedView({identity:viewIdentity,view}),[viewIdentity]);
  const initialView=savedView?.identity===viewIdentity?savedView.view:null;
  const viewportIdentity=useRef<string|null>(null);
  useEffect(()=>{
    if(!snapshot.stamp)return;
    const identity=owner+':'+snapshot.stamp.session+':'+(fixedContractId??initialScope);
    if(viewportIdentity.current!==null&&viewportIdentity.current!==identity)historyViewport.current=null;
    viewportIdentity.current=identity;
  },[owner,snapshot.stamp,fixedContractId,initialScope]);
  const router=useRouter();
  const [validated,setValidated]=useState<string|null>(null);
  const [waitingForPage,setWaitingForPage]=useState(false);
  const previousValidation=useRef<string|null>(null);
  const validationKey=owner+':'+validationId+':'+snapshot.epoch;
  useEffect(()=>{
    // A new render of this same graph after a Server Action is a freshness
    // boundary. A new route mount may still join an identical in-flight load.
    if(previousValidation.current!==null&&previousValidation.current!==validationId){
      previousValidation.current=validationId;store.invalidate(true);return;
    }
    previousValidation.current=validationId;
    let active=true;
    void store.read(owner,expectedRevision).then(()=>{
      if(!active)return;
      const stamp=store.getSnapshot().stamp;
      if(stamp&&stamp.session+':'+stamp.revision!==expectedRevision){setWaitingForPage(true);router.refresh();return;}
      setWaitingForPage(false);
      setValidated(validationKey);
    }).catch(error=>{
      if(active&&error instanceof ChangedNavigationIdentity)router.refresh();
      if(active&&!(error instanceof SupersededNavigation))setValidated(null);
    });
    return()=>{active=false;};
  },[store,owner,expectedRevision,validationId,validationKey,router]);
  // The store's ready notification precedes the promise continuation. Identity
  // plus a successful validation of this mount are checked before any display.
  const ready=validated===validationKey&&snapshot.status==='ready'&&snapshot.stamp?.owner===owner&&snapshot.data;
  const data=useMemo(()=>ready?navigationChartSelection(snapshot.data!,fixedContractId,initialScope):null,[ready,snapshot.data,fixedContractId,initialScope]);
  if(!ready)return <section className="mt-7 border border-[var(--app-border)] bg-[var(--app-surface)] p-4" role="status" aria-busy={snapshot.status!=='error'}>
    <h2 className="font-semibold">Historique patrimonial</h2>
    <p className="mt-2 text-sm text-[var(--app-muted)]">{snapshot.error??(waitingForPage?'Les données ont changé. Actualisation de la page…':'Chargement des valorisations, de l’historique et des répartitions…')}</p>
    {snapshot.status==='error'||waitingForPage?<button type="button" className="settings-edit-action mt-3" onClick={()=>{store.invalidate();router.refresh();}}>Réessayer</button>:null}
  </section>;
  return <PatrimonyCharts key={(fixedContractId??initialScope)+':'+snapshot.stamp!.revision} data={data!} fixedContractId={fixedContractId??undefined} historyViewport={historyViewport} initialView={initialView} onViewChange={saveView}/>;
}
