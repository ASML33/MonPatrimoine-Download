"use client";
import { useActionState } from "react";

// A callback belongs to the submission that produced this result, never to a
// retained success state or a later render. Parents guard their opening session.
export function useSavedPanelAction<S extends { status: string }>(save: (state: S, form: FormData) => Promise<S>, initial: S, onSaved?: () => void) {
  return useActionState(async (previous: Awaited<S>, form: FormData) => {
    const result = await save(previous, form);
    if (result.status === "success") onSaved?.();
    return result;
  }, initial as Awaited<S>);
}
