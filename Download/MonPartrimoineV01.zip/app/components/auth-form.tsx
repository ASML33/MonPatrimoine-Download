"use client";

import Link from "next/link";
import { useActionState } from "react";

import type { AuthActionState } from "@/lib/auth/flow-core";

type Field = {
  name: string;
  label: string;
  type: "text" | "password";
  autoComplete: string;
};

type Props = {
  action: (
    state: AuthActionState,
    formData: FormData,
  ) => Promise<AuthActionState>;
  fields: Field[];
  submitLabel: string;
  footer?: { href: string; label: string };
};

const initialState: AuthActionState = { status: "idle" };

export function AuthForm({ action, fields, submitLabel, footer }: Props) {
  const [state, formAction, pending] = useActionState(action, initialState);

  return (
    <form action={formAction} className="grid gap-5">
      {fields.map((field) => (
        <label key={field.name} className="grid gap-2 text-sm font-medium">
          {field.label}
          <input
            className="h-12 w-full border border-zinc-700 bg-zinc-900 px-3 text-base text-white outline-none transition focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20"
            name={field.name}
            type={field.type}
            autoComplete={field.autoComplete}
            required
          />
        </label>
      ))}

      {state.message ? (
        <p
          className={
            state.status === "success"
              ? "text-sm text-emerald-400"
              : "text-sm text-red-400"
          }
          role="status"
        >
          {state.message}
        </p>
      ) : null}

      <button
        className="h-12 bg-emerald-800 px-4 font-semibold text-white transition hover:bg-emerald-900 disabled:cursor-wait disabled:opacity-60"
        disabled={pending}
        type="submit"
      >
        {pending ? "Veuillez patienter…" : submitLabel}
      </button>

      {footer ? (
        <Link
          className="text-center text-sm font-medium text-emerald-400 underline-offset-4 hover:underline"
          href={footer.href}
        >
          {footer.label}
        </Link>
      ) : null}
    </form>
  );
}
