"use client";

import { useActionState, useMemo, useState } from "react";
import { CreationDisclosure } from "@/app/components/creation-disclosure";
import { useCollapseOnSuccess } from "@/app/components/use-collapse-on-success";
import type {
  AnalysisReferenceCatalogs,
  ReferenceCatalog,
  ReferenceCatalogActionState,
  ReferenceCatalogEntry,
} from "@/lib/assets/reference-catalog-core";
import { saveReferenceCatalogAction } from "./actions";

type MainCatalog = Exclude<ReferenceCatalog, "region">;
const initialState: ReferenceCatalogActionState = { status: "idle" };
const inputClass = "settings-input min-w-0";
const labelClass = "grid min-w-0 gap-2 text-sm font-medium";

const tabs: Array<[MainCatalog, string]> = [
  ["sector", "Secteurs"],
  ["activity", "Activités détaillées"],
  ["geography", "Géographie / Pays"],
  ["theme", "Thématiques"],
];

function Status({ state }: { state: ReferenceCatalogActionState }) {
  return state.message
    ? <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p>
    : null;
}

function ParentSelect({ name, entries, initial }: { name: string; entries: ReferenceCatalogEntry[]; initial?: string }) {
  const choices = entries.filter((entry) => entry.isActive || entry.id === initial);
  return <label className={labelClass}>{name} *
    <select name="parent_id" required defaultValue={initial ?? ""} className={inputClass}>
      <option value="" disabled>Choisir</option>
      {choices.map((entry) => <option key={entry.id} value={entry.id}>{entry.name}{entry.isActive ? "" : " — inactif"}</option>)}
    </select>
  </label>;
}

function ActionFields({ catalog, entry, parents }: { catalog: ReferenceCatalog; entry: ReferenceCatalogEntry; parents: ReferenceCatalogEntry[] }) {
  return <>
    <label className={labelClass}>Nom *<input name="name" required maxLength={catalog === "sector" ? 120 : 160} defaultValue={entry.name} className={inputClass} /></label>
    {catalog === "geography" && <ParentSelect name="Région" entries={parents} initial={entry.parentId} />}
  </>;
}

function CatalogRow({ catalog, entry, parents }: { catalog: ReferenceCatalog; entry: ReferenceCatalogEntry; parents: ReferenceCatalogEntry[] }) {
  const [state, action, pending] = useActionState(saveReferenceCatalogAction, initialState);
  const hidden = <><input type="hidden" name="catalog" value={catalog} /><input type="hidden" name="reference_id" value={entry.id} /></>;
  return <article className="rounded-md border border-[var(--app-border)] p-4">
    <div className="flex min-w-0 flex-wrap items-start justify-between gap-3">
      <div className="min-w-0">
        <h3 className="break-words font-semibold">{entry.name}</h3>
        <p className="mt-1 break-words text-xs text-[var(--app-muted)]">{entry.code}{entry.detail ? ` · ${entry.detail}` : ""}</p>
        <p className="mt-1 text-xs text-[var(--app-muted)]">{entry.isActive ? "Actif" : "Inactif"}{entry.isReferenced ? " · utilisé" : " · jamais utilisé"}{entry.isProtected ? " · référentiel commun" : " · secteur personnel"}</p>
      </div>
      {!entry.isProtected && <form action={action}>
        {hidden}<input type="hidden" name="operation" value={entry.isActive ? "deactivate" : "activate"} />
        <button type="submit" disabled={pending} className="min-h-11 rounded-md border border-[var(--app-border)] px-4 text-sm font-semibold">{entry.isActive ? "Désactiver" : "Réactiver"}</button>
      </form>}
    </div>
    {(!entry.isProtected || entry.canRename) ? <details data-edit-form className="mt-3">
      <summary className="cursor-pointer py-2 text-sm font-semibold text-[var(--app-gold)]">Gérer</summary>
      <RenameForm catalog={catalog} entry={entry} parents={parents} />
      {!entry.isReferenced && !entry.isProtected && <form action={action} className="mt-4 grid gap-3 border-t border-[var(--app-border)] pt-4">
        {hidden}<input type="hidden" name="operation" value="delete" />
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" name="confirm" required className="mt-1" />Je confirme la suppression définitive.</label>
        <button type="submit" disabled={pending} className="min-h-11 rounded-md border border-[var(--app-border)] px-4 text-sm font-semibold text-red-500">Supprimer</button>
      </form>}
      {entry.isReferenced && !entry.isProtected && <p className="mt-4 text-xs text-[var(--app-muted)]">Suppression impossible : cette référence est utilisée. Vous pouvez la désactiver.</p>}
      {entry.isProtected && <p className="mt-4 text-xs text-[var(--app-muted)]">Le libellé saisi est une personnalisation personnelle ; l’identifiant et le libellé commun restent inchangés.</p>}
      <div className="mt-3"><Status state={state} /></div>
    </details> : <p className="mt-4 text-xs text-[var(--app-muted)]">Cette référence commune est protégée.</p>}
  </article>;
}

function RenameForm({ catalog, entry, parents }: { catalog: ReferenceCatalog; entry: ReferenceCatalogEntry; parents: ReferenceCatalogEntry[] }) {
  const [state, action, pending] = useActionState(saveReferenceCatalogAction, initialState);
  const formRef = useCollapseOnSuccess(state, pending, true);
  return <form ref={formRef} action={action} className="mt-3 grid gap-4 sm:grid-cols-2">
    <input type="hidden" name="catalog" value={catalog} /><input type="hidden" name="reference_id" value={entry.id} /><input type="hidden" name="operation" value="rename" />
    <ActionFields catalog={catalog} entry={entry} parents={parents} />
    <button type="submit" disabled={pending} className="settings-primary-button sm:col-span-2">Enregistrer</button>
    <Status state={state} />
  </form>;
}

function CreateForm({ catalog, parents }: { catalog: ReferenceCatalog; parents: ReferenceCatalogEntry[] }) {
  const [state, action, pending] = useActionState(saveReferenceCatalogAction, initialState);
  const noun = catalog === "sector" ? "secteur" : catalog === "activity" ? "activité" : catalog === "region" ? "région" : catalog === "geography" ? "pays" : "thématique";
  return <CreationDisclosure title={`Ajouter ${catalog === "activity" || catalog === "region" || catalog === "theme" ? "une" : "un"} ${noun}`}>
    <form action={action} className="settings-form">
      <input type="hidden" name="catalog" value={catalog} /><input type="hidden" name="operation" value="create" />
      <fieldset disabled={pending} className="grid min-w-0 gap-4">
        {catalog === "geography" && <label className={labelClass}>Code ISO alpha-2 *<input name="code" required pattern="[A-Za-z]{2}" maxLength={2} className={inputClass} /></label>}
        <label className={labelClass}>Nom *<input name="name" required maxLength={catalog === "sector" ? 120 : 160} className={inputClass} /></label>
        {catalog === "activity" && <ParentSelect name="Secteur" entries={parents} />}
        {catalog === "geography" && <ParentSelect name="Région" entries={parents} />}
        <button type="submit" className="settings-primary-button">{pending ? "Création…" : "Ajouter"}</button>
      </fieldset>
      <Status state={state} />
    </form>
  </CreationDisclosure>;
}

function CatalogPanel({ catalog, title, description, entries, parents = [] }: {
  catalog: ReferenceCatalog;
  title: string;
  description: string;
  entries: ReferenceCatalogEntry[];
  parents?: ReferenceCatalogEntry[];
}) {
  const [query, setQuery] = useState("");
  const visible = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase("fr-FR");
    return needle ? entries.filter((entry) => `${entry.name} ${entry.code} ${entry.detail ?? ""}`.toLocaleLowerCase("fr-FR").includes(needle)) : entries;
  }, [entries, query]);
  return <div className="grid gap-6">
    <section className="settings-card min-w-0">
      <h2 className="settings-card-title">{title} ({entries.length})</h2>
      <p className="settings-card-description mt-2">{description}</p>
      <label className={`${labelClass} mt-5`}>Rechercher<input type="search" value={query} onChange={(event) => setQuery(event.target.value)} className={inputClass} /></label>
      {!visible.length ? <p className="mt-5 text-sm text-[var(--app-muted)]">Aucun résultat.</p>
        : <div className="mt-5 grid gap-4">{visible.map((entry) => <CatalogRow key={entry.id} catalog={catalog} entry={entry} parents={parents} />)}</div>}
    </section>
    <CreateForm catalog={catalog} parents={parents} />
  </div>;
}

export function ReferenceCatalogManager({ catalogs, initialCatalog = "sector" }: { catalogs: AnalysisReferenceCatalogs; initialCatalog?: MainCatalog }) {
  const [active, setActive] = useState<MainCatalog>(initialCatalog);
  return <div className="mt-8">
    <div role="tablist" aria-label="Référentiels d’analyse" className="grid grid-cols-1 gap-2 rounded-md border border-[var(--app-border)] bg-[var(--app-field)] p-2 sm:grid-cols-2 lg:grid-cols-4">
      {tabs.map(([catalog, label]) => <button key={catalog} type="button" role="tab" aria-selected={active === catalog} aria-controls={`catalog-panel-${catalog}`} onClick={() => setActive(catalog)} className={`min-h-11 rounded px-3 text-sm font-semibold focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold-light)] ${active === catalog ? "bg-[var(--app-gold)] text-[var(--app-on-gold)]" : "text-[var(--app-foreground)]"}`}>{label}</button>)}
    </div>
    <div role="tabpanel" id="catalog-panel-sector" hidden={active !== "sector"} className="mt-6"><CatalogPanel catalog="sector" title="Secteurs" description="Le socle GICS reste en base et peut être complété sans modification du code." entries={catalogs.sectors} /></div>
    <div role="tabpanel" id="catalog-panel-activity" hidden={active !== "activity"} className="mt-6"><CatalogPanel catalog="activity" title="Activités détaillées" description="Chaque activité conserve un secteur parent stable." entries={catalogs.activities} parents={catalogs.sectors} /></div>
    <div role="tabpanel" id="catalog-panel-geography" hidden={active !== "geography"} className="mt-6 grid gap-6">
      <CatalogPanel catalog="geography" title="Pays" description="Chaque pays possède un code ISO et une région dérivée par son rattachement." entries={catalogs.countries} parents={catalogs.regions} />
      <CatalogPanel catalog="region" title="Régions" description="Les régions structurent le regroupement des pays et ne sont pas saisies dans une répartition." entries={catalogs.regions} />
    </div>
    <div role="tabpanel" id="catalog-panel-theme" hidden={active !== "theme"} className="mt-6"><CatalogPanel catalog="theme" title="Thématiques / tendances" description="Les thématiques restent indépendantes des activités détaillées et peuvent se chevaucher." entries={catalogs.themes} /></div>
  </div>;
}
