import Link from "next/link";
import { redirect } from "next/navigation";
import { DashboardHeader } from "@/app/components/dashboard-header";
import { getPageProfile } from "@/lib/auth/render-context";
import { getAnalysisReferenceCatalogs } from "@/lib/assets/reference-catalogs";
import { asSettingsRecord, readProfileSettings } from "@/lib/settings/settings-core";
import { readThemePreference } from "@/lib/theme/theme-core";
import { ReferenceCatalogManager } from "./reference-catalog-manager";

export const dynamic = "force-dynamic";

export default async function AnalysisReferencesPage({ searchParams }: { searchParams: Promise<{ catalog?: string }> }) {
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (current.status !== "active") redirect("/");
  const theme = readThemePreference(asSettingsRecord(documents.interface_preferences));
  const settings = readProfileSettings(documents);
  const catalogs = await getAnalysisReferenceCatalogs(current.profile.auth_user_id).catch(() => null);
  const requested = (await searchParams).catalog;
  const initialCatalog = requested === "activity" || requested === "geography" || requested === "theme" ? requested : "sector";
  return <div data-theme={theme} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]">
    <DashboardHeader nickname={current.profile.nickname} displayName={settings.displayName} theme={theme} />
    <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
      <Link href="/assets" className="text-sm font-semibold text-[var(--app-gold)] underline underline-offset-4">← Retour aux actifs</Link>
      <h1 className="mt-5 text-3xl font-bold sm:text-4xl">Référentiels d’analyse</h1>
      <p className="mt-3 max-w-3xl text-sm leading-6 text-[var(--app-muted)] sm:text-base">Gérez les secteurs, activités, pays, régions et thématiques proposés dans les répartitions de vos actifs.</p>
      {catalogs ? <ReferenceCatalogManager catalogs={catalogs} initialCatalog={initialCatalog} /> : <p role="alert" className="mt-8 text-red-500">Les référentiels sont indisponibles. Réessayez ultérieurement.</p>}
    </main>
  </div>;
}
