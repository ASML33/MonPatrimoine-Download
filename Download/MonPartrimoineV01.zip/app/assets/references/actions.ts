"use server";

import { revalidatePath } from "next/cache";
import { getCurrentProfile } from "@/lib/auth/profile";
import { createClient } from "@/lib/supabase/server";
import {
  isReferenceCatalog,
  referenceCatalogError,
  validateCatalogIdentifier,
  validateCountryCode,
  validateReferenceName,
  type ReferenceCatalogActionState,
} from "@/lib/assets/reference-catalog-core";
import { isUuid } from "@/lib/assets/asset-core";

function text(form: FormData, key: string) {
  return String(form.get(key) ?? "").trim();
}

export async function saveReferenceCatalogAction(
  _state: ReferenceCatalogActionState,
  form: FormData,
): Promise<ReferenceCatalogActionState> {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active") return { status: "error", message: "Connectez-vous avec le compte autorisé." };
  const catalogValue = text(form, "catalog");
  const operation = text(form, "operation");
  const referenceId = text(form, "reference_id");
  if (!isReferenceCatalog(catalogValue)) return { status: "error", message: "Référentiel invalide." };
  if (operation !== "create" && !validateCatalogIdentifier(catalogValue, referenceId)) {
    return { status: "error", message: "Référence invalide." };
  }

  const supabase = await createClient();
  let result: { error: { code?: string; message?: string } | null };
  try {
    if (operation === "create") {
      const name = validateReferenceName(form, catalogValue === "sector" ? 120 : 160);
      if (catalogValue === "sector") result = await supabase.rpc("create_sector", { sector_name: name });
      else if (catalogValue === "activity") {
        const sectorId = text(form, "parent_id");
        if (!isUuid(sectorId)) throw new Error("Choisissez un secteur valide.");
        result = await supabase.rpc("create_sector_activity", { requested_sector: sectorId, activity_name: name });
      } else if (catalogValue === "region") result = await supabase.rpc("create_geographic_region", { region_name: name });
      else if (catalogValue === "geography") {
        const region = text(form, "parent_id");
        if (!/^[a-z0-9_]{1,50}$/.test(region)) throw new Error("Choisissez une région valide.");
        result = await supabase.rpc("create_exposure_country", { country_code: validateCountryCode(form), country_name: name, requested_region: region });
      } else result = await supabase.rpc("create_theme", { theme_name: name });
    } else if (operation === "rename") {
      const name = validateReferenceName(form, catalogValue === "sector" ? 120 : 160);
      if (catalogValue === "sector") result = await supabase.rpc("rename_sector", { requested_id: referenceId, sector_name: name });
      else if (catalogValue === "activity") result = await supabase.rpc("rename_sector_activity", { requested_id: referenceId, activity_name: name });
      else if (catalogValue === "region") result = await supabase.rpc("rename_geographic_region", { requested_code: referenceId, region_name: name });
      else if (catalogValue === "geography") {
        const region = text(form, "parent_id");
        if (!/^[a-z0-9_]{1,50}$/.test(region)) throw new Error("Choisissez une région valide.");
        result = await supabase.rpc("update_exposure_country", { requested_id: referenceId, country_name: name, requested_region: region });
      } else result = await supabase.rpc("rename_theme", { theme_id: referenceId, theme_name: name });
    } else if (operation === "activate" || operation === "deactivate") {
      const active = operation === "activate";
      if (catalogValue === "sector") result = await supabase.rpc("set_sector_active", { requested_id: referenceId, active });
      else if (catalogValue === "activity") result = await supabase.rpc("set_sector_activity_active", { requested_id: referenceId, active });
      else if (catalogValue === "region") result = await supabase.rpc("set_geographic_region_active", { requested_code: referenceId, active });
      else if (catalogValue === "geography") result = await supabase.rpc("set_exposure_country_active", { requested_id: referenceId, active });
      else result = await supabase.rpc("set_theme_active", { theme_id: referenceId, active });
    } else if (operation === "delete") {
      if (form.get("confirm") !== "on") return { status: "error", message: "Confirmez la suppression." };
      if (catalogValue === "sector") result = await supabase.rpc("delete_sector", { requested_id: referenceId });
      else if (catalogValue === "activity") result = await supabase.rpc("delete_sector_activity", { requested_id: referenceId });
      else if (catalogValue === "region") result = await supabase.rpc("delete_geographic_region", { requested_code: referenceId });
      else if (catalogValue === "geography") result = await supabase.rpc("delete_exposure_country", { requested_id: referenceId });
      else result = await supabase.rpc("delete_theme", { theme_id: referenceId });
    } else return { status: "error", message: "Opération invalide." };
  } catch (error) {
    return { status: "error", message: error instanceof Error ? error.message : "Référentiel invalide." };
  }

  if (result.error) return { status: "error", message: referenceCatalogError(result.error.code, result.error.message) };
  for (const path of ["/assets/references", "/assets/themes", "/assets"]) revalidatePath(path);
  return { status: "success", message: "Modification enregistrée." };
}
