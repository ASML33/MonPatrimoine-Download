"use server";

import { revalidatePath } from "next/cache";
import { after } from "next/server";
import { getCurrentProfile } from "@/lib/auth/profile";
import { createClient } from "@/lib/supabase/server";
import { assetError, isContextualAutomaticPriceCandidate, isUuid, validateAssetForm, type AssetActionState } from "@/lib/assets/asset-core";
import { refreshAutomaticAssetPrices } from "@/lib/assets/automatic-prices";
import { isMissingThemeSchemaError } from "@/lib/assets/theme-schema";
import { colorWrite } from "@/lib/ui/color-provenance";
import { parisDateFromIso } from "@/lib/cash/cash-core";
import { captureDailyPatrimony } from "@/lib/patrimony/daily-history";

function revalidateAutomaticPriceViews() {
  for (const path of ["/", "/assets", "/assets/refresh", "/contracts", "/reports", "/reports/history", "/patrimony"]) revalidatePath(path);
  revalidatePath("/assets/[id]/prices", "page");
  revalidatePath("/contracts/[id]", "page");
}

export async function saveAssetAction(_state: AssetActionState, form: FormData): Promise<AssetActionState> {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active") return { status: "error", message: "Connectez-vous avec le compte autorisé." };
  const operation = String(form.get("operation") ?? "");
  const id = String(form.get("id") ?? "");
  if (operation !== "create" && !isUuid(id)) return { status: "error", message: "Actif invalide." };
  const supabase = await createClient();
  const owner = current.profile.auth_user_id;
  let error: { code?: string } | null;
  let refreshedAssetId: string | null = null;
  if (operation === "create" || operation === "update") {
    let values;
    try { values = validateAssetForm(form); }
    catch (e) { return { status: "error", message: e instanceof Error ? e.message : "Valeurs invalides." }; }
    const { color, ...fields } = values;
    const writeValues = { ...fields, ...colorWrite(color, form.get("color_changed") === "true", operation === "create") };
    // SQL lifecycle guards also enforce structural identity under concurrent use.
    const query = operation === "create"
      ? supabase.from("assets").insert({ ...writeValues, owner_user_id: owner, is_active: true })
      : supabase.from("assets").update(writeValues).eq("id", id).eq("owner_user_id", owner);
    const saved = await query.select("id,valuation_mode,asset_type_code").single();
    error = saved.error;
    if (!error && saved.data && isContextualAutomaticPriceCandidate(saved.data.asset_type_code, saved.data.valuation_mode)) refreshedAssetId = saved.data.id;
  } else if (["activate", "deactivate", "delete"].includes(operation)) {
    if (operation === "delete" && form.get("confirm") !== "on") return { status: "error", message: "Confirmez la suppression." };
    if (operation === "delete") {
      // These analytical children use cascading FKs; never discard them silently.
      for (const table of ["asset_prices", "asset_sector_exposures", "asset_activity_exposures", "asset_geography_exposures", "asset_theme_exposure_sets"]) {
        const dependencies = await supabase.from(table).select("asset_id").eq("asset_id", id).limit(1);
        if (dependencies.error && !(table === "asset_theme_exposure_sets" && isMissingThemeSchemaError(dependencies.error))) {
          return { status: "error", message: "Impossible de vérifier les dépendances. Réessayez ultérieurement." };
        }
        if (dependencies.data?.length) return { status: "error", message: "Cet actif possède des expositions liées. Vous pouvez le désactiver." };
      }
    }
    const query = operation === "delete" ? supabase.from("assets").delete()
      : supabase.from("assets").update({ is_active: operation === "activate" });
    const saved = await query.eq("id", id).eq("owner_user_id", owner).select("id,valuation_mode,asset_type_code").single();
    error = saved.error;
    if (!error && operation === "activate" && saved.data && isContextualAutomaticPriceCandidate(saved.data.asset_type_code, saved.data.valuation_mode)) refreshedAssetId = saved.data.id;
  } else return { status: "error", message: "Opération invalide." };
  if (error) return { status: "error", message: assetError(error.code) };
  if (refreshedAssetId) {
    const requestedAsset = refreshedAssetId;
    after(async () => {
      const summary = await refreshAutomaticAssetPrices({ ownerId: owner, assetIds: [requestedAsset], mode: "contextual" }).catch(() => null);
      if (summary?.persistedPrices) await captureDailyPatrimony(parisDateFromIso(new Date().toISOString()), { requestedRevision: true }).catch(() => undefined);
      if (summary) revalidateAutomaticPriceViews();
    });
  }
  revalidatePath("/assets");
  revalidatePath("/");
  return { status: "success", message: "Modification enregistrée." };
}
