import { redirect } from "next/navigation";

export default async function ThemesPage() {
  redirect("/assets/references?catalog=theme");
}
