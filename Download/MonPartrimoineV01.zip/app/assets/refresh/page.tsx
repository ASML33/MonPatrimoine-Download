import Link from "next/link";
import { redirect } from "next/navigation";

import { AutomaticPriceRefresh } from "@/app/components/automatic-price-refresh";
import { DashboardHeader } from "@/app/components/dashboard-header";
import { getPageProfile } from "@/lib/auth/render-context";
import { asSettingsRecord, readProfileSettings } from "@/lib/settings/settings-core";
import { createClient } from "@/lib/supabase/server";
import { readThemePreference } from "@/lib/theme/theme-core";

export const dynamic = "force-dynamic";

function timestamp(value: string | null) {
  return value ? new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Paris" }).format(new Date(value)) : "Jamais";
}

function errorLabel(code: string | null) {
  if (code === "quota_exceeded") return "Quota fournisseur atteint";
  if (code === "not_found" || code === "symbol_not_found" || code === "asset_unavailable") return "Actif non couvert";
  if (code === "authentication_failed") return "Configuration fournisseur invalide";
  if (code === "access_denied") return "Accès fournisseur non autorisé";
  if (code === "timeout") return "Délai fournisseur dépassé";
  if (code === "network_error") return "Erreur réseau fournisseur";
  if (code === "invalid_quote") return "Réponse fournisseur inexploitable";
  if (code === "price_unavailable") return "Prix fournisseur indisponible";
  return code ? "Échec de récupération" : "—";
}

function sourceLabel(source: string | null) {
  if (source === "unconfigured") return "Aucun fournisseur";
  return source ?? "—";
}

export default async function AssetPriceRefreshPage() {
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (current.status !== "active") redirect("/");
  const theme = readThemePreference(asSettingsRecord(documents.interface_preferences));
  const settings = readProfileSettings(documents);
  const supabase = await createClient();
  const [assetsResult, providersResult] = await Promise.all([
    supabase.from("assets").select("id,name,symbol,asset_price_refresh_status(status,last_attempted_at,last_succeeded_at,error_code,source_name)").eq("owner_user_id", current.profile.auth_user_id).eq("is_active", true).eq("valuation_mode", "market_price").order("name"),
    supabase.from("price_provider_configurations").select("slot", { count: "exact", head: true }).eq("active", true).eq("status", "validated"),
  ]);
  const statusAvailable = !assetsResult.error && !providersResult.error;
  const assets = statusAvailable ? (assetsResult.data ?? []) : [];

  return <div data-theme={theme} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]">
    <DashboardHeader nickname={current.profile.nickname} displayName={settings.displayName} theme={theme} />
    <main className="mx-auto max-w-4xl px-4 py-8 sm:px-6 sm:py-12">
      <Link href="/assets" className="text-sm font-semibold text-[var(--app-gold)]">← Retour aux actifs</Link>
      <h1 className="mt-4 text-3xl font-bold">Actualiser les cours</h1>
      <p className="mt-2 text-sm text-[var(--app-muted)]">L’actualisation traite les actifs actifs configurés en cours de marché. Ouvrir cette page ne lance aucune récupération.</p>
      {!statusAvailable ? <p className="mt-5 text-sm text-amber-500">Les états des cours automatiques sont temporairement indisponibles.</p> : providersResult.count === 0 ? <p className="mt-5 text-sm text-amber-500">Aucun fournisseur de cours n’est configuré dans cet environnement.</p> : null}
      <AutomaticPriceRefresh />
      <section className="mt-8" aria-labelledby="automatic-price-status-title">
        <h2 id="automatic-price-status-title" className="text-xl font-bold">État des actifs automatiques</h2>
        {assets.length ? <ul className="mt-4 grid gap-3 sm:grid-cols-2">
          {assets.map((asset) => {
            const relation = asset.asset_price_refresh_status as { status: string; last_attempted_at: string; last_succeeded_at: string | null; error_code: string | null; source_name: string | null } | Array<{ status: string; last_attempted_at: string; last_succeeded_at: string | null; error_code: string | null; source_name: string | null }> | null;
            const state = Array.isArray(relation) ? relation[0] : relation;
            return <li key={asset.id} className="settings-card min-w-0">
              <h3 className="font-semibold">{asset.name}{asset.symbol ? ` · ${asset.symbol}` : ""}</h3>
              <dl className="mt-3 grid gap-2 text-sm">
                <div><dt className="text-[var(--app-muted)]">Dernier succès</dt><dd>{timestamp(state?.last_succeeded_at ?? null)}</dd></div>
                <div><dt className="text-[var(--app-muted)]">Dernière tentative</dt><dd>{timestamp(state?.last_attempted_at ?? null)}</dd></div>
                <div><dt className="text-[var(--app-muted)]">Source</dt><dd>{sourceLabel(state?.source_name ?? null)}</dd></div>
                {state?.status === "error" ? <div><dt className="text-[var(--app-muted)]">Résultat</dt><dd className="text-red-500">{errorLabel(state.error_code)}</dd></div> : null}
              </dl>
            </li>;
          })}
        </ul> : statusAvailable ? <p className="mt-4 text-sm text-[var(--app-muted)]">Aucun actif actif en mode cours de marché.</p> : null}
      </section>
    </main>
  </div>;
}
