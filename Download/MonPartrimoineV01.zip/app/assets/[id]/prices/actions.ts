"use server";
import { parisBusinessDate } from "@/lib/dates/business-date";

import { revalidatePath } from "next/cache";
import { getCurrentProfile } from "@/lib/auth/profile";
import { createClient } from "@/lib/supabase/server";
import { manualPriceError, validateManualPriceForm, type AssetPriceActionState } from "@/lib/assets/price-core";

export async function saveManualAssetPriceAction(
  _state: AssetPriceActionState,
  form: FormData,
): Promise<AssetPriceActionState> {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active") return { status: "error", message: "Connectez-vous avec le compte autorisé." };

  let values;
  try { values = validateManualPriceForm(form, parisBusinessDate()); }
  catch (error) { return { status: "error", message: error instanceof Error ? error.message : "Prix invalide." }; }

  const supabase = await createClient();
  const owner = current.profile.auth_user_id;
  const asset = await supabase.from("assets")
    .select("id,currency_code")
    .eq("id", values.assetId).eq("owner_user_id", owner).maybeSingle();
  if (asset.error || !asset.data) return { status: "error", message: "Cet actif n’est pas accessible." };

  const result = await supabase.rpc("save_manual_asset_price", {
    requested_asset: values.assetId,
    requested_price: values.price,
    observed_on: values.observedOn,
  });
  if (result.error) return { status: "error", message: manualPriceError(result.error.code, result.error.message) };

  revalidatePath(`/assets/${values.assetId}/prices`);
  revalidatePath("/assets");
  revalidatePath("/");
  return { status: "success", message: "Prix manuel enregistré." };
}
