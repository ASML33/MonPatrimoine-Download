"use client";

import Link from "next/link";
import { formatMoney } from "@/lib/cash/money";

import { useActionState, useMemo, useState } from "react";
import { valuationModeLabel } from "@/lib/assets/asset-core";
import type { AssetPrice, AssetPriceActionState, AssetPriceWorkspace } from "@/lib/assets/price-core";
import { saveManualAssetPriceAction } from "./actions";

const inputClass = "settings-input min-w-0";
const labelClass = "grid min-w-0 gap-2 text-sm font-medium";

function formatPrice(price: AssetPrice) {
  return price.priceEur == null ? "Conversion EUR indisponible" : formatMoney(price.priceEur, "EUR");
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeZone: "UTC" }).format(new Date(`${value}T00:00:00Z`));
}

function formatTimestamp(value: string) {
  return new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Paris" }).format(new Date(value));
}

function CurrentPrice({ workspace }: { workspace: AssetPriceWorkspace }) {
  const current = workspace.currentPrice;
  const automatic = workspace.asset.valuationMode === "market_price";
  return <section className="settings-card min-w-0">
    <h2 className="settings-card-title">Valorisation courante</h2>
    <p className="settings-card-description mt-2">Mode actuel : {valuationModeLabel(workspace.asset.valuationMode)}</p>
    {workspace.asset.valuationMode === "not_applicable"
      ? <p className="mt-5 text-sm text-[var(--app-muted)]">Aucun prix courant n’est utilisé dans ce mode.</p>
      : current
        ? <dl className="mt-5 grid gap-3 text-sm sm:grid-cols-2">
            <div><dt className="text-[var(--app-muted)]">Prix courant</dt><dd className="mt-1 text-xl font-semibold">{formatPrice(current)}</dd></div>
            <div><dt className="text-[var(--app-muted)]">Date du prix</dt><dd className="mt-1 font-medium">{formatTimestamp(current.observedAt)}</dd></div>
            <div><dt className="text-[var(--app-muted)]">Devise</dt><dd className="mt-1">EUR · devise source {current.currencyCode}</dd></div>
            <div><dt className="text-[var(--app-muted)]">Origine</dt><dd className="mt-1">{automatic ? "Automatique" : "Manuel"}</dd></div>
          </dl>
        : <p className="mt-5 text-sm text-[var(--app-muted)]">Aucun prix {automatic ? "automatique" : "manuel"} utilisable n’est encore enregistré.</p>}
    {current && current.currencyCode !== "EUR" && <p className="mt-3 text-xs text-[var(--app-muted)]">Change EUR : {current.eurFxDate ? `${current.eurFxSource} · ${formatDate(current.eurFxDate)}` : "indisponible"}.</p>}
    {automatic && workspace.refreshStatus?.status === "error" && <p role="status" className="mt-5 rounded-md border border-[var(--app-border)] p-3 text-sm text-[var(--app-muted)]">La dernière actualisation automatique a échoué. Le dernier prix connu reste utilisé.</p>}
    {automatic && <p className="mt-4 text-xs text-[var(--app-muted)]">Les prix manuels restent conservés, mais ils ne déterminent pas la valorisation courante dans ce mode.</p>}
  </section>;
}

export function PriceWorkspaceView({ workspace }: { workspace: AssetPriceWorkspace }) {
  const [state, action, pending] = useActionState(saveManualAssetPriceAction, { status: "idle" } as AssetPriceActionState);
  const [observedOn, setObservedOn] = useState(workspace.today);
  const [priceText, setPriceText] = useState(() => workspace.manualPrices.find(price => price.observedOn === workspace.today && price.currencyCode === workspace.asset.currencyCode)?.price ?? "");
  const existingDays = useMemo(() => new Set(workspace.manualPrices.map((price) => price.observedOn)), [workspace.manualPrices]);
  const correctsExisting = existingDays.has(observedOn);
  const selectedManualPrice = workspace.manualPrices.find(price => price.observedOn === observedOn);
  const incompatibleNativeCurrency = Boolean(selectedManualPrice && selectedManualPrice.currencyCode !== workspace.asset.currencyCode);

  if(workspace.asset.assetTypeCode==="real_estate")return <section className="settings-card"><h2 className="settings-card-title">Estimation totale immobilière</h2><p className="mt-3">Consultez et corrigez les estimations datées depuis la fiche du contrat immobilier. Aucun cours unitaire ni PRU n’est utilisé pour ce bien.</p><Link href="/contracts" className="settings-edit-action mt-4">Ouvrir les contrats</Link></section>;
  return <div className="mt-8 grid gap-6">
    {!workspace.asset.isActive && <p role="status" className="rounded-md border border-[var(--app-border)] p-4 text-sm text-[var(--app-muted)]">Cet actif est inactif. Son historique de prix reste consultable et corrigeable.</p>}
    <CurrentPrice workspace={workspace} />
    <section className="settings-card min-w-0">
      <h2 className="settings-card-title">Enregistrer un prix manuel</h2>
      <p className="settings-card-description mt-2">Une nouvelle saisie pour une date existante corrige cette journée sans créer de doublon.</p>
      <form action={action} className="settings-form mt-6">
        <input type="hidden" name="asset_id" value={workspace.asset.id} />
        <div className="grid gap-5 md:grid-cols-2">
          <label className={labelClass}>Prix *
            <div className="flex min-w-0 items-center gap-3"><input name="price" value={priceText} onChange={event => setPriceText(event.target.value)} className={inputClass} inputMode="decimal" pattern="[0-9]+([.,][0-9]{1,8})?" required /><span className="shrink-0 text-sm font-medium">{workspace.asset.currencyCode}</span></div>
          </label>
          <label className={labelClass}>Date du prix *
            <input type="date" name="observed_on" className={inputClass} value={observedOn} max={workspace.today} onChange={(event) => { const date = event.target.value; setObservedOn(date); setPriceText(workspace.manualPrices.find(price => price.observedOn === date && price.currencyCode === workspace.asset.currencyCode)?.price ?? ""); }} required />
          </label>
        </div>
        <dl className="grid gap-2 text-xs text-[var(--app-muted)] sm:grid-cols-2"><div><dt className="inline">Devise : </dt><dd className="inline">{workspace.asset.currencyCode}</dd></div><div><dt className="inline">Origine : </dt><dd className="inline">Manuel</dd></div></dl>
        {incompatibleNativeCurrency && selectedManualPrice && <label className={labelClass}>Observation source conservée ({selectedManualPrice.currencyCode})
          <input className={inputClass} value={selectedManualPrice.price} readOnly />
          <span className="text-xs text-amber-500">Cette observation est dans une autre devise que l’actif. Son montant natif ne sera pas réinterprété ; une correction de source doit être qualifiée séparément.</span>
        </label>}
        {correctsExisting && <p className="text-xs text-[var(--app-muted)]">Un prix existe déjà pour cette date. L’enregistrement le remplacera.</p>}
        <button type="submit" className="settings-primary-button" disabled={pending || incompatibleNativeCurrency}>{pending ? "Enregistrement…" : "Enregistrer le prix"}</button>
        {state.message && <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p>}
      </form>
    </section>
    <section className="settings-card min-w-0">
      <h2 className="settings-card-title">Historique des prix manuels</h2><p className="mt-2 text-xs text-[var(--app-muted)]">Consultation en EUR au change daté disponible ; la saisie reste dans la devise source.</p>
      {!workspace.manualPrices.length ? <p className="mt-5 text-sm text-[var(--app-muted)]">Aucun prix manuel enregistré.</p> :
        <table className="mt-5 block w-full text-left text-sm sm:table">
          <thead className="hidden sm:table-header-group"><tr>{["Date", "Prix", "Devise", "Origine", "Enregistré le"].map((title) => <th key={title} scope="col" className="px-3 pb-3 font-semibold">{title}</th>)}</tr></thead>
          <tbody className="grid gap-4 sm:table-row-group">{workspace.manualPrices.map((price) => <tr key={price.id} className="grid gap-2 border-t border-[var(--app-border)] py-4 sm:table-row [&>td]:min-w-0 sm:[&>td]:p-3">
            <td><span className="mr-2 text-xs text-[var(--app-muted)] sm:hidden">Date</span>{formatDate(price.observedOn)}</td>
            <td className="font-semibold"><span className="mr-2 text-xs font-normal text-[var(--app-muted)] sm:hidden">Prix</span>{formatPrice(price)}{price.currencyCode !== "EUR" && <span className="block text-xs text-[var(--app-muted)]">Change {price.eurFxDate ? `${price.eurFxSource} · ${formatDate(price.eurFxDate)}` : "indisponible"}</span>}</td>
            <td><span className="mr-2 text-xs text-[var(--app-muted)] sm:hidden">Devise</span>EUR · source {price.currencyCode}</td>
            <td><span className="mr-2 text-xs text-[var(--app-muted)] sm:hidden">Origine</span>Manuel</td>
            <td><span className="mr-2 text-xs text-[var(--app-muted)] sm:hidden">Enregistré le</span>{formatTimestamp(price.obtainedAt)}</td>
          </tr>)}</tbody>
        </table>}
    </section>
    <section className="settings-card min-w-0">
      <h2 className="settings-card-title">Historique des prix automatiques</h2>
      {!workspace.automaticPrices.length ? <p className="mt-5 text-sm text-[var(--app-muted)]">Aucun prix automatique enregistré.</p> :
        <ul className="mt-5 grid gap-3 text-sm">{workspace.automaticPrices.slice(0, 10).map((price) => <li key={price.id} className="flex flex-wrap justify-between gap-3 border-t border-[var(--app-border)] pt-3"><span>{formatTimestamp(price.observedAt)} · {price.sourceName ?? "Source automatique"}</span><span className="font-semibold">{formatPrice(price)}{price.currencyCode !== "EUR" && <span className="block text-xs font-normal text-[var(--app-muted)]">Change {price.eurFxDate ? `${price.eurFxSource} · ${formatDate(price.eurFxDate)}` : "indisponible"}</span>}</span></li>)}</ul>}
    </section>
  </div>;
}
