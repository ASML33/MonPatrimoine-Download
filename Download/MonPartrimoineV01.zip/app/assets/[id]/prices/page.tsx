import Link from "next/link";
import { redirect } from "next/navigation";
import { DashboardHeader } from "@/app/components/dashboard-header";
import { getPageProfile } from "@/lib/auth/render-context";
import { getAssetPriceWorkspace } from "@/lib/assets/prices";
import { asSettingsRecord, readProfileSettings } from "@/lib/settings/settings-core";
import { readThemePreference } from "@/lib/theme/theme-core";
import { PriceWorkspaceView } from "./price-workspace";

export const dynamic = "force-dynamic";

export default async function AssetPricesPage({ params }: { params: Promise<{ id: string }> }) {
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (current.status !== "active") redirect("/");
  const { id } = await params;
  const workspace = await getAssetPriceWorkspace(id, current.profile.auth_user_id).catch(() => null);
  const theme = readThemePreference(asSettingsRecord(documents.interface_preferences));
  const settings = readProfileSettings(documents);
  return <div data-theme={theme} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]">
    <DashboardHeader nickname={current.profile.nickname} displayName={settings.displayName} theme={theme} />
    <main className="mx-auto max-w-5xl px-4 py-10 sm:px-6 sm:py-14">
      <Link href="/assets" className="text-sm font-semibold text-[var(--app-gold)]">← Retour aux actifs</Link>
      <h1 className="mt-5 text-3xl font-bold sm:text-4xl">Valorisation de {workspace?.asset.name ?? "l’actif"}</h1>
      <p className="mt-3 max-w-3xl text-sm leading-6 text-[var(--app-muted)] sm:text-base">Consultez et corrigez l’historique des prix manuels. Les prix automatiques existants restent inchangés.</p>
      {workspace ? <PriceWorkspaceView workspace={workspace} /> : <p role="alert" className="mt-8 text-red-500">Les prix de cet actif sont indisponibles. Réessayez ultérieurement.</p>}
    </main>
  </div>;
}
