"use server";

import { revalidatePath } from "next/cache";
import { getCurrentProfile } from "@/lib/auth/profile";
import { createClient } from "@/lib/supabase/server";
import { isUuid } from "@/lib/assets/asset-core";
import { themeError, validateThemeExposureDraft, type ThemeActionState } from "@/lib/assets/theme-core";

function text(form: FormData, key: string) {
  return String(form.get(key) ?? "").trim();
}

export async function saveAssetThemeExposureAction(_state: ThemeActionState, form: FormData): Promise<ThemeActionState> {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active") return { status: "error", message: "Connectez-vous avec le compte autorisé." };
  const operation = text(form, "operation");
  const assetId = text(form, "asset_id");
  if (!isUuid(assetId)) return { status: "error", message: "Actif invalide." };
  const supabase = await createClient();
  const owner = current.profile.auth_user_id;
  const asset = await supabase.from("assets").select("id").eq("id", assetId).eq("owner_user_id", owner).maybeSingle();
  if (asset.error || !asset.data) return { status: "error", message: "Cet actif n’est pas accessible." };

  let result: { error: { code?: string; message?: string } | null };
  if (operation === "save") {
    let draft;
    try { draft = validateThemeExposureDraft(form); }
    catch (error) { return { status: "error", message: error instanceof Error ? error.message : "Brouillon invalide." }; }
    result = await supabase.rpc("save_asset_theme_draft", {
      aid: assetId,
      items: draft.items,
      data_date: draft.dataDate,
      source: draft.source,
      origin: "user",
    });
  } else if (operation === "publish") {
    result = await supabase.rpc("publish_asset_theme_draft", { aid: assetId });
  } else if (operation === "discard") {
    if (form.get("confirm") !== "on") return { status: "error", message: "Confirmez l’abandon du brouillon." };
    result = await supabase.rpc("discard_asset_theme_draft", { aid: assetId });
  } else return { status: "error", message: "Opération invalide." };

  if (result.error) return { status: "error", message: themeError(result.error.code, result.error.message) };
  revalidatePath(`/assets/${assetId}/exposures`);
  revalidatePath("/assets/themes");
  return {
    status: "success",
    message: operation === "publish"
      ? "Répartition thématique effective mise à jour."
      : operation === "discard"
        ? "Brouillon abandonné. La répartition effective est inchangée."
        : "Brouillon enregistré. La répartition effective est inchangée.",
  };
}
