"use client";

import Link from "next/link";
import { useActionState, useMemo, useState } from "react";
import { originLabel } from "@/lib/assets/exposure-core";
import type { ThemeActionState, ThemeExposureSlot, ThemeExposureWorkspace } from "@/lib/assets/theme-core";
import { saveAssetThemeExposureAction } from "./theme-actions";

const inputClass = "settings-input min-w-0";
const labelClass = "grid min-w-0 gap-2 text-sm font-medium";
const initialState: ThemeActionState = { status: "idle" };
type EditableRow = { key: number; themeId: string; weight: string };

function number(value: number) {
  return new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 2 }).format(value);
}

function date(value: string | null) {
  return value ? new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium" }).format(new Date(`${value}T00:00:00`)) : "Non renseignée";
}

function timestamp(value: string | null) {
  return value ? new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Paris" }).format(new Date(value)) : "Non renseignée";
}

function Status({ state }: { state: ThemeActionState }) {
  return state.message
    ? <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p>
    : null;
}

function Provenance({ slot }: { slot: ThemeExposureSlot }) {
  if (!slot.exists) return null;
  return <dl className="mt-4 grid grid-cols-2 gap-2 border-t border-[var(--app-border)] pt-4 text-xs [&_dd]:min-w-0 [&_dd]:break-words [&_dt]:text-[var(--app-muted)]">
    <dt>Date des données</dt><dd>{date(slot.dataDate)}</dd>
    <dt>Source</dt><dd>{slot.source ?? "Non renseignée"}</dd>
    <dt>Origine</dt><dd>{originLabel(slot.origin)}</dd>
    <dt>Mise à jour</dt><dd>{timestamp(slot.updatedAt)}</dd>
  </dl>;
}

export function ThemeExposurePanel({ workspace, hidden }: { workspace: ThemeExposureWorkspace; hidden: boolean }) {
  const { draft, effective } = workspace.slots;
  const base = draft.exists ? draft : effective;
  const [rows, setRows] = useState<EditableRow[]>(() => base.rows.map((row, index) => ({ key: index, themeId: row.themeId, weight: String(row.weightPercent) })));
  const [nextKey, setNextKey] = useState(rows.length);
  const [dataDate, setDataDate] = useState(base.dataDate ?? "");
  const [source, setSource] = useState(base.source ?? "");
  const [dirty, setDirty] = useState(false);
  const [saveState, saveAction, saving] = useActionState(saveAssetThemeExposureAction, initialState);
  const [publishState, publishAction, publishing] = useActionState(saveAssetThemeExposureAction, initialState);
  const [discardState, discardAction, discarding] = useActionState(saveAssetThemeExposureAction, initialState);
  const total = useMemo(() => Math.round(rows.reduce((sum, row) => sum + (Number(row.weight.replace(",", ".")) || 0), 0) * 100) / 100, [rows]);
  const names = new Map(workspace.themes.map((theme) => [theme.id, theme]));

  function updateRow(key: number, field: "themeId" | "weight", value: string) {
    setRows((current) => current.map((row) => row.key === key ? { ...row, [field]: value } : row));
    setDirty(true);
  }

  const savedStatus = dirty
    ? `Modifications non enregistrées — ${number(total)} % cumulés`
    : draft.exists
      ? `Brouillon enregistré — ${number(draft.total)} % cumulés`
      : base.exists ? `Base effective non enregistrée — ${number(total)} % cumulés` : "Aucun brouillon enregistré";

  return <div role="tabpanel" id="panel-theme" aria-labelledby="tab-theme" hidden={hidden} className={`mt-6 items-start gap-6 lg:grid-cols-2 ${hidden ? "hidden" : "grid"}`}>
    <section className="rounded-md border border-[var(--app-border)] bg-[var(--app-field)] p-4 sm:p-5">
      <header className="flex flex-wrap items-center justify-between gap-2"><h3 className="font-semibold">Répartition effective</h3><span className="text-sm font-semibold">Pondérations cumulées : {number(effective.total)} %</span></header>
      {!effective.rows.length ? <p className="mt-4 text-sm text-[var(--app-muted)]">Aucune thématique effective n’est enregistrée.</p>
        : <ul className="mt-4 grid gap-2 text-sm">{effective.rows.map((row) => <li key={row.themeId} className="flex min-w-0 justify-between gap-4"><span className="min-w-0 break-words">{names.get(row.themeId)?.name ?? "Thématique indisponible"}{names.get(row.themeId)?.isActive === false ? " · inactive" : ""}</span><span className="shrink-0 font-medium">{number(row.weightPercent)} %</span></li>)}</ul>}
      <Provenance slot={effective} />
    </section>
    <section className="rounded-md border border-[var(--app-border)] p-4 sm:p-5">
      <header className="flex flex-wrap items-center justify-between gap-2"><div><h3 className="font-semibold">Brouillon</h3><p className="mt-1 text-xs text-[var(--app-muted)]">{savedStatus}</p></div><span className="text-sm font-semibold">Pondérations cumulées : {number(total)} %</span></header>
      <p className="mt-3 text-xs text-[var(--app-muted)]">Les thématiques peuvent se chevaucher : ce cumul peut dépasser 100 %.</p>
      <form action={saveAction} className="mt-5 grid gap-5">
        <input type="hidden" name="operation" value="save" /><input type="hidden" name="asset_id" value={workspace.assetId} />
        <div className="grid gap-3">
          {rows.map((row, index) => <div key={row.key} className="grid min-w-0 gap-3 rounded-md border border-[var(--app-border)] p-3 sm:grid-cols-[minmax(0,1fr)_8rem_auto] sm:items-end">
            <label className={labelClass}>Thématique *<select name="theme_id" className={inputClass} value={row.themeId} required onChange={(event) => updateRow(row.key, "themeId", event.target.value)}><option value="" disabled>Choisir</option>{workspace.themes.filter((theme) => theme.isActive || theme.id === row.themeId).map((theme) => <option key={theme.id} value={theme.id}>{theme.name}{theme.isActive ? "" : " — inactive"}</option>)}</select></label>
            <label className={labelClass}>Pondération (%) *<input name="weight_percent" className={inputClass} inputMode="decimal" pattern="[0-9]+([.,][0-9]{1,2})?" required value={row.weight} onChange={(event) => updateRow(row.key, "weight", event.target.value)} /></label>
            <button type="button" onClick={() => { setRows((current) => current.filter(({ key }) => key !== row.key)); setDirty(true); }} aria-label={`Retirer la ligne ${index + 1}`} className="min-h-11 rounded-md border border-[var(--app-border)] px-3 text-sm">Retirer</button>
          </div>)}
          <button type="button" onClick={() => { setRows((current) => [...current, { key: nextKey, themeId: "", weight: "" }]); setNextKey((key) => key + 1); setDirty(true); }} className="min-h-11 rounded-md border border-[var(--app-border)] px-4 text-sm font-semibold">Ajouter une thématique</button>
          {!workspace.themes.some((theme) => theme.isActive) && <p className="text-xs text-[var(--app-muted)]">Aucune thématique active. <Link href="/assets/references?catalog=theme" className="font-semibold text-[var(--app-gold)] underline underline-offset-4">Gérer le référentiel</Link></p>}
        </div>
        <div className="grid gap-5 md:grid-cols-2">
          <label className={labelClass}>Date des données<input type="date" name="data_date" className={inputClass} value={dataDate} onChange={(event) => { setDataDate(event.target.value); setDirty(true); }} /></label>
          <label className={labelClass}>Source<input name="source" className={inputClass} maxLength={2000} value={source} onChange={(event) => { setSource(event.target.value); setDirty(true); }} /></label>
        </div>
        <p className="text-xs text-[var(--app-muted)]">Origine de cette saisie : Saisie manuelle. Un brouillon vide peut être enregistré pour supprimer toutes les thématiques lors de sa publication.</p>
        <button type="submit" disabled={saving} className="settings-primary-button">{saving ? "Enregistrement…" : "Enregistrer le brouillon"}</button>
        <Status state={saveState} />
      </form>
      <form action={publishAction} className="mt-5 grid gap-3 border-t border-[var(--app-border)] pt-4">
        <input type="hidden" name="operation" value="publish" /><input type="hidden" name="asset_id" value={workspace.assetId} />
        <button type="submit" disabled={!draft.exists || dirty || publishing} className="settings-primary-button">{publishing ? "Publication…" : "Publier le brouillon"}</button>
        {!draft.exists && <p className="text-xs text-[var(--app-muted)]">Enregistrez d’abord un brouillon.</p>}
        {dirty && <p className="text-xs text-[var(--app-muted)]">Enregistrez les modifications locales avant de publier.</p>}
        <Status state={publishState} />
      </form>
      {draft.exists && <form action={discardAction} className="mt-5 grid gap-3 border-t border-[var(--app-border)] pt-4">
        <input type="hidden" name="operation" value="discard" /><input type="hidden" name="asset_id" value={workspace.assetId} />
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" name="confirm" required className="mt-1" />Je confirme l’abandon de ce brouillon.</label>
        <button type="submit" disabled={discarding} className="min-h-11 rounded-md border border-[var(--app-border)] px-4 text-sm font-semibold text-red-500">{discarding ? "Abandon…" : "Abandonner le brouillon"}</button>
        <Status state={discardState} />
      </form>}
    </section>
  </div>;
}
