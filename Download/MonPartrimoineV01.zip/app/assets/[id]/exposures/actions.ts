"use server";

import { revalidatePath } from "next/cache";
import { getCurrentProfile } from "@/lib/auth/profile";
import { createClient } from "@/lib/supabase/server";
import { isUuid } from "@/lib/assets/asset-core";
import {
  exposureError,
  isExposureDimension,
  validateExposureDraft,
  type ExposureActionState,
  type ExposureDimension,
} from "@/lib/assets/exposure-core";

const referenceTable: Record<ExposureDimension, string> = {
  sector: "sectors",
  activity: "sector_activities",
  geography: "exposure_countries",
};

function text(form: FormData, key: string) {
  return String(form.get(key) ?? "").trim();
}

export async function saveAssetExposureAction(_state: ExposureActionState, form: FormData): Promise<ExposureActionState> {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active") return { status: "error", message: "Connectez-vous avec le compte autorisé." };

  const operation = text(form, "operation");
  const assetId = text(form, "asset_id");
  const dimensionValue = text(form, "dimension");
  if (!isUuid(assetId) || !isExposureDimension(dimensionValue)) return { status: "error", message: "Actif ou répartition invalide." };

  const supabase = await createClient();
  const owner = current.profile.auth_user_id;
  const asset = await supabase.from("assets").select("id").eq("id", assetId).eq("owner_user_id", owner).maybeSingle();
  if (asset.error || !asset.data) return { status: "error", message: "Cet actif n’est pas accessible." };

  const effectiveOn=text(form,"effective_on");
  if ((operation==="publish" || operation==="publish_all") && (!/^\d{4}-\d{2}-\d{2}$/.test(effectiveOn) || !Number.isFinite(Date.parse(effectiveOn)) || new Date(effectiveOn).toISOString().slice(0,10)!==effectiveOn)) return {status:"error",message:"Renseignez une date d’effet civile valide."};
  let result: { error: { code?: string; message?: string } | null };
  if (operation === "save") {
    let draft;
    try { draft = validateExposureDraft(form); }
    catch (error) { return { status: "error", message: error instanceof Error ? error.message : "Répartition invalide." }; }

    const references = await supabase.from(referenceTable[draft.dimension]).select("id").in("id", draft.items.map(({ reference_id }) => reference_id));
    if (references.error) return { status: "error", message: "Impossible de vérifier les références. Rechargez la page." };
    const available = new Set((references.data ?? []).map(({ id }) => id));
    if (draft.items.some(({ reference_id }) => !available.has(reference_id))) return { status: "error", message: "Une référence sélectionnée n’est plus disponible. Rechargez la page." };

    result = await supabase.rpc("save_asset_exposure_draft", {
      aid: assetId,
      dimension: draft.dimension,
      items: draft.items,
      data_date: draft.dataDate,
      source: draft.source,
      origin: "user",
    });
  } else if (operation === "publish") {
    result = await supabase.rpc("publish_asset_exposure_draft", { aid: assetId, dimension: dimensionValue, effective_on: effectiveOn });
  } else if (operation === "publish_all") {
    const dimensions = [...new Set(form.getAll("publish_dimension").map(String))].filter(isExposureDimension);
    if (!dimensions.length) return { status: "error", message: "Aucun brouillon complet à valider." };
    result = await supabase.rpc("publish_asset_exposure_drafts", { aid: assetId, dimensions, effective_on: effectiveOn });
  } else if (operation === "discard") {
    if (form.get("confirm") !== "on") return { status: "error", message: "Confirmez l’abandon du brouillon." };
    result = await supabase.rpc("save_asset_exposure_draft", {
      aid: assetId,
      dimension: dimensionValue,
      items: [],
      data_date: null,
      source: null,
      origin: "user",
    });
  } else return { status: "error", message: "Opération invalide." };

  if (result.error) return { status: "error", message: exposureError(result.error.code, result.error.message) };
  revalidatePath(`/assets/${assetId}/exposures`);
  revalidatePath("/assets");
  if(operation==="publish" || operation==="publish_all"){revalidatePath("/contracts");revalidatePath("/reports");revalidatePath("/patrimony");revalidatePath("/");}
  return {
    status: "success",
    message: operation === "publish" || operation === "publish_all"
      ? `Répartition publiée avec effet au ${effectiveOn}. Les versions précédentes sont conservées.`
      : operation === "discard" ? "Brouillon abandonné. La répartition effective est inchangée."
        : "Brouillon enregistré. La répartition effective est inchangée.",
  };
}
