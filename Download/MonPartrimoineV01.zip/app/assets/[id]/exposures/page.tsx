import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { DashboardHeader } from "@/app/components/dashboard-header";
import { getPageProfile } from "@/lib/auth/render-context";
import { getAssetExposureWorkspace } from "@/lib/assets/exposures";
import { getAssetThemeWorkspace } from "@/lib/assets/themes";
import { ThemeSchemaUnavailableError } from "@/lib/assets/theme-schema";
import { asSettingsRecord, readProfileSettings } from "@/lib/settings/settings-core";
import { readThemePreference } from "@/lib/theme/theme-core";
import { ExposureWorkspaceView } from "./exposure-workspace";

export const dynamic = "force-dynamic";

export default async function AssetExposuresPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (current.status !== "active") redirect("/");
  const theme = readThemePreference(asSettingsRecord(documents.interface_preferences));
  const settings = readProfileSettings(documents);
  const [workspace, themeWorkspace] = await Promise.all([
    getAssetExposureWorkspace(id, current.profile.auth_user_id).catch(() => undefined),
    getAssetThemeWorkspace(id, current.profile.auth_user_id).catch((error) => error instanceof ThemeSchemaUnavailableError ? null : undefined),
  ]);
  if (workspace === null) notFound();

  return <div data-theme={theme} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]">
    <DashboardHeader nickname={current.profile.nickname} displayName={settings.displayName} theme={theme} />
    <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
      <Link href="/assets" className="text-sm font-semibold text-[var(--app-gold)] underline underline-offset-4">← Retour aux actifs</Link>
      <h1 className="mt-5 text-3xl font-bold sm:text-4xl">Répartitions de {workspace?.asset.name ?? "l’actif"}</h1>
      <p className="mt-3 max-w-3xl text-sm leading-6 text-[var(--app-muted)] sm:text-base">
        Préparez séparément les secteurs, les activités détaillées, la géographie et les thématiques. Un brouillon ne remplace jamais la répartition effective avant sa publication.
      </p>
      {workspace && themeWorkspace !== undefined
        ? <ExposureWorkspaceView workspace={workspace} themeWorkspace={themeWorkspace} />
        : <p role="alert" className="mt-8 text-red-500">Les répartitions sont indisponibles. Réessayez ultérieurement.</p>}
    </main>
  </div>;
}
