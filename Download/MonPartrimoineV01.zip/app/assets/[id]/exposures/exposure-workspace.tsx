"use client";

import Link from "next/link";
import { useActionState, useCallback, useEffect, useMemo, useState, type KeyboardEvent } from "react";
import {
  EXPOSURE_DIMENSIONS,
  exposureDimensionLabel,
  getExposureDraftUiState,
  originLabel,
  type ExposureActionState,
  type ExposureDimension,
  type ExposureReference,
  type ExposureRow,
  type ExposureSlot,
  type ExposureWorkspace,
} from "@/lib/assets/exposure-core";
import { saveAssetExposureAction } from "./actions";
import { AiExposureAssistant } from "./ai-exposure-assistant";
import type { ThemeExposureWorkspace } from "@/lib/assets/theme-core";
import { ThemeExposurePanel } from "./theme-exposure-panel";

type WorkspaceTab = ExposureDimension | "theme";

const inputClass = "settings-input min-w-0";
const labelClass = "grid min-w-0 gap-2 text-sm font-medium";

function formatNumber(value: number) {
  return new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 2 }).format(value);
}

function formatDate(value: string | null) {
  if (!value) return "Non renseignée";
  return new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeZone: "UTC" }).format(new Date(`${value}T00:00:00Z`));
}

function formatTimestamp(value: string | undefined) {
  if (!value) return "Non renseignée";
  return new Intl.DateTimeFormat("fr-FR", { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Paris" }).format(new Date(value));
}

function referenceLabel(reference: ExposureReference) {
  return reference.detail ? `${reference.name} — ${reference.detail}` : reference.name;
}

function SlotProvenance({ rows }: { rows: ExposureRow[] }) {
  const row = rows[0];
  if (!row) return null;
  return <dl className="mt-4 grid grid-cols-2 gap-2 border-t border-[var(--app-border)] pt-4 text-xs [&_dd]:min-w-0 [&_dd]:break-words [&_dt]:text-[var(--app-muted)]">
    <dt>Date des données</dt><dd>{formatDate(row.dataDate)}</dd>
    <dt>Source</dt><dd>{row.source ?? "Non renseignée"}</dd>
    <dt>Origine</dt><dd>{originLabel(row.origin)}</dd>
    <dt>Mise à jour</dt><dd>{formatTimestamp(row.updatedAt)}</dd>
    {row.effectiveOn!==undefined && <><dt>Date d’effet</dt><dd>{formatDate(row.effectiveOn ?? null)}</dd><dt>Publication</dt><dd>{formatTimestamp(row.publishedAt ?? undefined)}</dd>{row.recoveredAt && <><dt>Reprise initiale</dt><dd>{formatTimestamp(row.recoveredAt)} · publication passée inconnue</dd></>}</>}
  </dl>;
}

function EffectiveSlot({ slot, references }: { slot: ExposureSlot; references: ExposureReference[] }) {
  const names = new Map(references.map((reference) => [reference.id, referenceLabel(reference)]));
  return <section className="rounded-md border border-[var(--app-border)] bg-[var(--app-field)] p-4 sm:p-5">
    <header className="flex flex-wrap items-center justify-between gap-2">
      <h3 className="font-semibold">Répartition effective</h3>
      <span className="text-sm font-semibold">{formatNumber(slot.total)} %</span>
    </header>
    {!slot.rows.length ? <p className="mt-4 text-sm text-[var(--app-muted)]">Aucune répartition effective n’est enregistrée pour cette dimension.</p>
      : <ul className="mt-4 grid gap-2 text-sm">{slot.rows.map((row) => <li key={row.referenceId} className="flex min-w-0 justify-between gap-4">
        <span className="min-w-0 break-words">{names.get(row.referenceId) ?? "Référence indisponible"}</span>
        <span className="shrink-0 font-medium">{formatNumber(row.weightPercent)} %</span>
      </li>)}</ul>}
    <SlotProvenance rows={slot.rows} />
  </section>;
}

type EditableRow = { key: number; referenceId: string; weight: string };

function PublishForm({ assetId, dimension, enabled, disabledMessage }: { assetId: string; dimension: ExposureDimension; enabled: boolean; disabledMessage: string }) {
  const [state, action, pending] = useActionState(saveAssetExposureAction, { status: "idle" } as ExposureActionState);
  return <form action={action} className="grid gap-3">
    <input type="hidden" name="operation" value="publish" />
    <input type="hidden" name="asset_id" value={assetId} />
    <input type="hidden" name="dimension" value={dimension} />
    <label className={labelClass}>Date d’effet<input type="date" name="effective_on" className={inputClass} required disabled={!enabled || pending} /></label>
    <p className="text-xs text-[var(--app-muted)]">Date civile Europe/Paris, distincte de la date des données. L’ancienne version reste applicable auparavant.</p>
    <button type="submit" className="settings-primary-button" disabled={!enabled || pending}>{pending ? "Validation…" : "Valider à 100 %"}</button>
    {!enabled && <p className="text-xs text-[var(--app-muted)]">{disabledMessage}</p>}
    {state.message && <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p>}
  </form>;
}

function DiscardForm({ assetId, dimension }: { assetId: string; dimension: ExposureDimension }) {
  const [state, action, pending] = useActionState(saveAssetExposureAction, { status: "idle" } as ExposureActionState);
  return <section className="grid gap-3 border-t border-[var(--app-border)] pt-4">
    <div><h4 className="text-sm font-semibold">Abandon du brouillon</h4><p className="mt-1 text-xs text-[var(--app-muted)]">La répartition effective restera strictement inchangée.</p></div>
    <form action={action} className="grid gap-3">
      <input type="hidden" name="operation" value="discard" />
      <input type="hidden" name="asset_id" value={assetId} />
      <input type="hidden" name="dimension" value={dimension} />
      <label className="flex items-start gap-2 text-sm"><input type="checkbox" name="confirm" required className="mt-1" />Je confirme l’abandon de ce brouillon.</label>
      <button type="submit" disabled={pending} className="min-h-11 rounded-md border border-[var(--app-border)] px-4 text-sm font-semibold text-red-500 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold-light)]">{pending ? "Abandon…" : "Abandonner le brouillon"}</button>
      {state.message && <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p>}
    </form>
  </section>;
}

function DraftEditor({ assetId, dimension, references, draft, effective, onDirtyChange }: {
  assetId: string;
  dimension: ExposureDimension;
  references: ExposureReference[];
  draft: ExposureSlot;
  effective: ExposureSlot;
  onDirtyChange: (dimension: ExposureDimension, dirty: boolean) => void;
}) {
  const base = draft.rows.length ? draft.rows : effective.rows;
  const [rows, setRows] = useState<EditableRow[]>(() => base.length
    ? base.map((row, index) => ({ key: index, referenceId: row.referenceId, weight: String(row.weightPercent) }))
    : [{ key: 0, referenceId: "", weight: "" }]);
  const [nextKey, setNextKey] = useState(rows.length);
  const [isDirty, setIsDirty] = useState(false);
  const [state, action, pending] = useActionState(saveAssetExposureAction, { status: "idle" } as ExposureActionState);
  const metadata = draft.rows[0] ?? effective.rows[0];
  const [dataDate, setDataDate] = useState(metadata?.dataDate ?? "");
  const [source, setSource] = useState(metadata?.source ?? "");
  const total = useMemo(() => Math.round(rows.reduce((sum, row) => sum + (Number(row.weight.replace(",", ".")) || 0), 0) * 100) / 100, [rows]);
  const draftState = getExposureDraftUiState(draft.rows.length > 0, draft.total, isDirty);
  const showSaveBeforePublish = total === 100 && !draftState.canPublish;

  useEffect(() => { onDirtyChange(dimension, false); }, [dimension, onDirtyChange]);

  function markDirty() {
    setIsDirty(true);
    onDirtyChange(dimension, true);
  }

  function updateRow(key: number, field: "referenceId" | "weight", value: string) {
    setRows((current) => current.map((row) => row.key === key ? { ...row, [field]: value } : row));
    markDirty();
  }

  const statusLabel = draftState.kind === "dirty"
    ? `Modifications non enregistrées — ${formatNumber(total)} %`
    : draftState.kind === "saved_complete"
      ? "Brouillon enregistré — 100 % · complet"
      : draftState.kind === "saved_incomplete"
        ? `Brouillon enregistré — ${formatNumber(draft.total)} % · incomplet`
        : base.length ? `Base de saisie non enregistrée — ${formatNumber(total)} %` : "Base de saisie non enregistrée";
  const publishHelp = draftState.kind === "dirty"
    ? "Enregistrez les modifications locales avant de publier."
    : draftState.kind === "base"
      ? "Enregistrez d’abord cette base de saisie comme brouillon."
      : "Le brouillon enregistré doit totaliser exactement 100 % avant validation.";

  return <section className="rounded-md border border-[var(--app-border)] p-4 sm:p-5">
    <header className="flex flex-wrap items-center justify-between gap-2">
      <div><h3 className="font-semibold">Brouillon</h3><p className="mt-1 text-xs text-[var(--app-muted)]">{statusLabel}</p></div>
      <span className={`text-sm font-semibold ${total > 100 ? "text-red-500" : ""}`}>{formatNumber(total)} %</span>
    </header>
    <form action={action} className="mt-5 grid gap-5">
      <input type="hidden" name="operation" value="save" />
      <input type="hidden" name="asset_id" value={assetId} />
      <input type="hidden" name="dimension" value={dimension} />
      <div className="grid gap-3">
        {rows.map((row, index) => <div key={row.key} className="grid min-w-0 gap-3 rounded-md border border-[var(--app-border)] p-3 sm:grid-cols-[minmax(0,1fr)_8rem_auto] sm:items-end">
          <label className={labelClass}>{dimension === "geography" ? "Pays *" : "Référence *"}
            <select name="reference_id" className={inputClass} value={row.referenceId} onChange={(event) => updateRow(row.key, "referenceId", event.target.value)} required>
              <option value="" disabled>Choisir</option>
              {references.filter((reference) => reference.isActive || reference.id === row.referenceId).map((reference) => <option key={reference.id} value={reference.id}>{referenceLabel(reference)}{reference.isActive ? "" : " — inactif"}</option>)}
            </select>
          </label>
          <label className={labelClass}>Poids (%) *
            <input name="weight_percent" className={inputClass} inputMode="decimal" value={row.weight} onChange={(event) => updateRow(row.key, "weight", event.target.value)} pattern="[0-9]+([.,][0-9]{1,2})?" required />
          </label>
          <button type="button" onClick={() => { setRows((current) => current.filter(({ key }) => key !== row.key)); markDirty(); }} disabled={rows.length === 1} aria-label={`Retirer la ligne ${index + 1}`} className="min-h-11 rounded-md border border-[var(--app-border)] px-3 text-sm disabled:opacity-40">Retirer</button>
        </div>)}
        <button type="button" onClick={() => { setRows((current) => [...current, { key: nextKey, referenceId: "", weight: "" }]); setNextKey((key) => key + 1); markDirty(); }} className="min-h-11 rounded-md border border-[var(--app-border)] px-4 text-sm font-semibold">Ajouter une ligne</button>
        {!references.some((reference) => reference.isActive) && <p className="text-xs text-[var(--app-muted)]">Aucune référence active. <Link href="/assets/references" className="font-semibold text-[var(--app-gold)] underline underline-offset-4">Gérer les référentiels</Link></p>}
      </div>
      <div className="grid gap-5 md:grid-cols-2">
        <label className={labelClass}>Date des données<input type="date" name="data_date" className={inputClass} value={dataDate} onChange={(event) => { setDataDate(event.target.value); markDirty(); }} /></label>
        <label className={labelClass}>Source<input name="source" className={inputClass} maxLength={2000} value={source} onChange={(event) => { setSource(event.target.value); markDirty(); }} /></label>
      </div>
      <p className="text-xs text-[var(--app-muted)]">Origine de cette saisie : Saisie manuelle. L’enregistrement conserve l’effectif actuel.</p>
      {dimension === "activity" && <p className="text-xs text-[var(--app-muted)]">Le total des activités d’un secteur ne peut pas dépasser le poids de ce secteur dans le brouillon, ou dans l’effectif si aucun brouillon sectoriel n’existe.</p>}
      <button type="submit" className="settings-primary-button" disabled={pending || total > 100}>{pending ? "Enregistrement…" : "Enregistrer le brouillon"}</button>
      {showSaveBeforePublish && <p className="text-xs text-[var(--app-muted)]">Enregistrez le brouillon pour pouvoir le valider.</p>}
      {state.message && <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p>}
    </form>
    <div className="mt-5 grid gap-4">
      <PublishForm assetId={assetId} dimension={dimension} enabled={draftState.canPublish} disabledMessage={publishHelp} />
      {draft.rows.length > 0 && <DiscardForm assetId={assetId} dimension={dimension} />}
    </div>
  </section>;
}

function DimensionPanel({ workspace, dimension, hidden, onDirtyChange }: { workspace: ExposureWorkspace; dimension: ExposureDimension; hidden: boolean; onDirtyChange: (dimension: ExposureDimension, dirty: boolean) => void }) {
  const { draft, effective } = workspace.slots[dimension];
  return <div role="tabpanel" id={`panel-${dimension}`} aria-labelledby={`tab-${dimension}`} hidden={hidden} className={`mt-6 items-start gap-6 lg:grid-cols-2 ${hidden ? "hidden" : "grid"}`}>
    <EffectiveSlot slot={effective} references={workspace.references[dimension]} />
    <DraftEditor assetId={workspace.asset.id} dimension={dimension} references={workspace.references[dimension]} draft={draft} effective={effective} onDirtyChange={onDirtyChange} />
  </div>;
}

function PublishAll({ workspace, dirtyDimensions }: { workspace: ExposureWorkspace; dirtyDimensions: Record<ExposureDimension, boolean> }) {
  const complete = EXPOSURE_DIMENSIONS.filter((dimension) => workspace.slots[dimension].draft.isComplete);
  const hasUnsavedChanges = EXPOSURE_DIMENSIONS.some((dimension) => dirtyDimensions[dimension]);
  const [state, action, pending] = useActionState(saveAssetExposureAction, { status: "idle" } as ExposureActionState);
  return <section className="settings-card mt-6 min-w-0">
    <h2 className="settings-card-title">Validation groupée</h2>
    <p className="settings-card-description mt-2">Validez ensemble tous les brouillons enregistrés qui totalisent 100 %. L’opération est atomique.</p>
    <form action={action} className="mt-5 grid gap-3">
      <input type="hidden" name="operation" value="publish_all" />
      <input type="hidden" name="asset_id" value={workspace.asset.id} />
      <input type="hidden" name="dimension" value={complete[0] ?? "sector"} />
      {complete.map((dimension) => <input key={dimension} type="hidden" name="publish_dimension" value={dimension} />)}
      <label className={labelClass}>Date d’effet des publications groupées<input type="date" name="effective_on" className={inputClass} required disabled={!complete.length || hasUnsavedChanges || pending} /></label>
      <p className="text-sm text-[var(--app-muted)]">{complete.length ? complete.map(exposureDimensionLabel).join(" · ") : "Aucun brouillon complet"}</p>
      <button type="submit" className="settings-primary-button" disabled={!complete.length || hasUnsavedChanges || pending}>{pending ? "Validation…" : "Valider les brouillons complets"}</button>
      {hasUnsavedChanges && <p className="text-xs text-[var(--app-muted)]">Enregistrez les modifications locales avant toute validation groupée.</p>}
      {state.message && <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p>}
    </form>
  </section>;
}

export function ExposureWorkspaceView({ workspace, themeWorkspace }: { workspace: ExposureWorkspace; themeWorkspace: ThemeExposureWorkspace | null }) {
  const workspaceTabs = useMemo<WorkspaceTab[]>(() => themeWorkspace ? [...EXPOSURE_DIMENSIONS, "theme"] : [...EXPOSURE_DIMENSIONS], [themeWorkspace]);
  const [active, setActive] = useState<WorkspaceTab>("sector");
  const [dirtyDimensions, setDirtyDimensions] = useState<Record<ExposureDimension, boolean>>({ sector: false, activity: false, geography: false });
  const handleDirtyChange = useCallback((dimension: ExposureDimension, dirty: boolean) => {
    setDirtyDimensions((current) => current[dimension] === dirty ? current : { ...current, [dimension]: dirty });
  }, []);
  function moveTab(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let target = index;
    if (event.key === "ArrowRight" || event.key === "ArrowDown") target = (index + 1) % workspaceTabs.length;
    else if (event.key === "ArrowLeft" || event.key === "ArrowUp") target = (index - 1 + workspaceTabs.length) % workspaceTabs.length;
    else if (event.key === "Home") target = 0;
    else if (event.key === "End") target = workspaceTabs.length - 1;
    else return;
    event.preventDefault();
    const dimension = workspaceTabs[target];
    setActive(dimension);
    document.getElementById(`tab-${dimension}`)?.focus();
  }
  return <div className="mt-8">
    {!workspace.asset.isActive && <p role="status" className="mb-6 rounded-md border border-[var(--app-border)] p-4 text-sm text-[var(--app-muted)]">Cet actif est inactif. Ses répartitions historiques restent consultables et modifiables.</p>}
    <AiExposureAssistant workspace={workspace} />
    <div role="tablist" aria-label="Dimensions de répartition" className="mt-6 grid grid-cols-1 gap-2 rounded-md border border-[var(--app-border)] bg-[var(--app-field)] p-2 sm:grid-cols-2 lg:grid-cols-4">
      {workspaceTabs.map((dimension, index) => <button key={dimension} type="button" role="tab" id={`tab-${dimension}`} aria-selected={active === dimension} aria-controls={`panel-${dimension}`} tabIndex={active === dimension ? 0 : -1} onClick={() => setActive(dimension)} onKeyDown={(event) => moveTab(event, index)} className={`min-h-11 rounded px-3 text-sm font-semibold focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold-light)] ${active === dimension ? "bg-[var(--app-gold)] text-[var(--app-on-gold)]" : "text-[var(--app-foreground)]"}`}>{dimension === "theme" ? "Thématiques / tendances" : exposureDimensionLabel(dimension)}</button>)}
    </div>
    {EXPOSURE_DIMENSIONS.map((dimension) => {
      const { draft, effective } = workspace.slots[dimension];
      const panelKey = `${dimension}:${draft.rows.map((row) => `${row.referenceId}:${row.weightPercent}:${row.updatedAt}`).join("|")}:${effective.rows.map((row) => `${row.referenceId}:${row.weightPercent}:${row.updatedAt}`).join("|")}`;
      return <DimensionPanel key={panelKey} workspace={workspace} dimension={dimension} hidden={active !== dimension} onDirtyChange={handleDirtyChange} />;
    })}
    {themeWorkspace && <ThemeExposurePanel
      key={`${themeWorkspace.slots.draft.updatedAt ?? "no-draft"}:${themeWorkspace.slots.effective.updatedAt ?? "no-effective"}`}
      workspace={themeWorkspace}
      hidden={active !== "theme"}
    />}
    <PublishAll workspace={workspace} dirtyDimensions={dirtyDimensions} />
    {!!workspace.publications?.length && <details className="settings-card mt-6"><summary>Historique des publications</summary><ul className="mt-3 grid gap-2 text-sm">{workspace.publications.map(version=><li key={version.id}>{exposureDimensionLabel(version.dimension)} · {version.initial?`reprise initiale ${formatTimestamp(version.recordedAt)} ; effet et publication passés inconnus`:`effet ${formatDate(version.effectiveOn)} ; publication ${formatTimestamp(version.publishedAt ?? undefined)}`}</li>)}</ul></details>}
  </div>;
}
