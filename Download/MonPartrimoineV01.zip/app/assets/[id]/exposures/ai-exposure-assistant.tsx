"use client";

import { useActionState, useState } from "react";
import { EXPOSURE_DIMENSIONS, exposureDimensionLabel, type ExposureWorkspace } from "@/lib/assets/exposure-core";
import type { AiExposureProposal } from "@/lib/assets/exposure-ai-core";
import {
  applyExposureAiProposalAction,
  prepareExposureAiAction,
  type ExposureAiActionState,
} from "./ai-actions";

function Proposal({ proposal, workspace }: { proposal: AiExposureProposal; workspace: ExposureWorkspace }) {
  return <div className="grid gap-4 lg:grid-cols-3">
    {EXPOSURE_DIMENSIONS.map((dimension) => {
      const names = new Map(workspace.references[dimension].map((reference) => [reference.id, reference.name]));
      const total = proposal[dimension].reduce((sum, item) => sum + item.weight_percent, 0);
      return <section key={dimension} className="rounded-md border border-[var(--app-border)] bg-[var(--app-field)] p-4">
        <h3 className="font-semibold">{exposureDimensionLabel(dimension)}</h3>
        <ul className="mt-3 grid gap-2 text-sm">{proposal[dimension].map((item) => <li key={item.reference_id} className="flex justify-between gap-3"><span>{names.get(item.reference_id)}</span><span className="shrink-0 font-medium">{item.weight_percent} %</span></li>)}</ul>
        <p className="mt-3 border-t border-[var(--app-border)] pt-3 text-sm font-semibold">Total : {total} %</p>
      </section>;
    })}
  </div>;
}

export function AiExposureAssistant({ workspace }: { workspace: ExposureWorkspace }) {
  const [open, setOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [prepareState, prepareAction, preparing] = useActionState(prepareExposureAiAction, { status: "idle" } as ExposureAiActionState);
  const [applyState, applyAction, applying] = useActionState(applyExposureAiProposalAction, { status: "idle" } as ExposureAiActionState);
  const proposal = applyState.applied ? undefined : applyState.proposal ?? prepareState.proposal;
  const hasExistingDraft = Object.values(workspace.slots).some((slot) => slot.draft.rows.length > 0);

  return <section className="settings-card mt-8 min-w-0">
    <button type="button" aria-expanded={open} aria-controls="ai-exposure-assistant" onClick={() => setOpen((value) => !value)} className="flex min-h-11 w-full items-center justify-between gap-4 text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold-light)]">
      <span><span className="settings-card-title block">Aide IA</span><span className="mt-1 block text-sm text-[var(--app-muted)]">Prépare une proposition contrôlable, sans modifier la répartition effective.</span></span>
      <span aria-hidden="true" className="text-xl">{open ? "−" : "+"}</span>
    </button>
    {open && <div id="ai-exposure-assistant" className="mt-6 grid gap-6 border-t border-[var(--app-border)] pt-6">
      <form action={prepareAction} className="grid gap-3">
        <input type="hidden" name="operation" value="generate" />
        <input type="hidden" name="asset_id" value={workspace.asset.id} />
        <button type="submit" className="settings-primary-button" disabled={preparing}>{preparing ? "Préparation…" : "Préparer une proposition"}</button>
      </form>
      {prepareState.prompt && <section className="grid gap-3">
        <label className="grid gap-2 text-sm font-medium">Prompt manuel
          <textarea readOnly value={prepareState.prompt} rows={12} className="settings-input min-h-56 font-mono text-xs" onFocus={(event) => event.currentTarget.select()} />
        </label>
        <button type="button" className="min-h-11 rounded-md border border-[var(--app-border)] px-4 text-sm font-semibold" onClick={async () => { await navigator.clipboard.writeText(prepareState.prompt ?? ""); setCopied(true); }}>{copied ? "Prompt copié" : "Copier le prompt"}</button>
        <p className="text-xs text-[var(--app-muted)]">Copiez ce prompt dans l’IA externe de votre choix, puis importez uniquement sa réponse JSON.</p>
        <form action={prepareAction} className="grid gap-3">
          <input type="hidden" name="operation" value="import" />
          <input type="hidden" name="asset_id" value={workspace.asset.id} />
          <label className="grid gap-2 text-sm font-medium">Réponse structurée
            <textarea name="structured_response" rows={10} className="settings-input min-h-48 font-mono text-xs" required />
          </label>
          <button type="submit" className="settings-primary-button" disabled={preparing}>{preparing ? "Validation…" : "Importer et vérifier"}</button>
        </form>
      </section>}
      {proposal && <section className="grid gap-5">
        <div><h3 className="text-lg font-semibold">Proposition à vérifier</h3><p className="mt-1 text-sm text-[var(--app-muted)]">Aucune donnée effective n’est modifiée à ce stade.</p></div>
        <Proposal proposal={proposal} workspace={workspace} />
        <form action={applyAction} className="grid gap-3">
          <input type="hidden" name="asset_id" value={workspace.asset.id} />
          <input type="hidden" name="proposal" value={JSON.stringify(proposal)} />
          {hasExistingDraft && <label className="flex items-start gap-2 text-sm"><input type="checkbox" name="replace_existing" required className="mt-1" />Je confirme le remplacement explicite des brouillons existants.</label>}
          <button type="submit" className="settings-primary-button" disabled={applying}>{applying ? "Application…" : "Appliquer au brouillon"}</button>
        </form>
      </section>}
      {prepareState.message && <p role="status" aria-live="polite" className={`text-sm ${prepareState.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{prepareState.message}</p>}
      {applyState.message && <p role="status" aria-live="polite" className={`text-sm ${applyState.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{applyState.message}</p>}
    </div>}
  </section>;
}
