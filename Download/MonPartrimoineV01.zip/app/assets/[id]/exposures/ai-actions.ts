"use server";

import { revalidatePath } from "next/cache";
import { readAiConfiguration } from "@/lib/ai/ai-settings-core";
import { getConfiguredAiModel, requestExposureProposal } from "@/lib/ai/exposure-provider";
import { getAiRuntimeConfiguration } from "@/lib/ai/runtime-configuration";
import { getCurrentProfile } from "@/lib/auth/profile";
import {
  buildExposureAiPrompt,
  parseAiExposureProposalJson,
  type AiExposureProposal,
} from "@/lib/assets/exposure-ai-core";
import { getAssetExposureWorkspace } from "@/lib/assets/exposures";
import { isUuid } from "@/lib/assets/asset-core";
import { createClient } from "@/lib/supabase/server";

export type ExposureAiActionState = {
  status: "idle" | "success" | "error";
  message?: string;
  mode?: "api" | "manual";
  prompt?: string;
  proposal?: AiExposureProposal;
  applied?: boolean;
};

function value(form: FormData, key: string) {
  return String(form.get(key) ?? "").trim();
}

async function context(form: FormData) {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active") throw new Error("AUTH_REQUIRED");
  const assetId = value(form, "asset_id");
  if (!isUuid(assetId)) throw new Error("ASSET_INVALID");
  const workspace = await getAssetExposureWorkspace(assetId, current.profile.auth_user_id);
  if (!workspace) throw new Error("ASSET_UNAVAILABLE");
  const asset = {
    name: workspace.asset.name,
    symbol: workspace.asset.symbol,
    isin: workspace.asset.isin,
    asset_type_code: workspace.asset.assetTypeCode,
    metadata: workspace.asset.metadata,
  };
  return { current, assetId, workspace, prompt: buildExposureAiPrompt(workspace, asset) };
}

function actionError(error: unknown): ExposureAiActionState {
  const message = error instanceof Error ? error.message : "";
  if (message === "AUTH_REQUIRED") return { status: "error", message: "Connectez-vous avec le compte autorisé." };
  if (message === "ASSET_INVALID" || message === "ASSET_UNAVAILABLE") return { status: "error", message: "Cet actif n’est pas accessible." };
  if (message.startsWith("AI_PROVIDER_")) return { status: "error", message: "Le fournisseur IA n’a pas renvoyé une proposition exploitable." };
  if (message === "AI_RUNTIME_CONFIGURATION_UNAVAILABLE") return { status: "error", message: "La configuration IA serveur est indisponible." };
  return { status: "error", message: message || "La proposition IA n’a pas pu être préparée." };
}

export async function prepareExposureAiAction(
  _state: ExposureAiActionState,
  form: FormData,
): Promise<ExposureAiActionState> {
  try {
    const request = await context(form);
    const operation = value(form, "operation");
    if (operation === "import") {
      const proposal = parseAiExposureProposalJson(value(form, "structured_response"), request.workspace);
      return { status: "success", mode: "manual", proposal, message: "Réponse importée et validée. Vérifiez-la avant application." };
    }
    if (operation !== "generate") throw new Error("Opération invalide.");

    const sessionClient = await createClient();
    const configurationResult = await sessionClient.rpc("get_ai_configuration").single();
    if (configurationResult.error) throw new Error("AI_RUNTIME_CONFIGURATION_UNAVAILABLE");
    const configuration = readAiConfiguration(configurationResult.data);
    const model = configuration.status === "configured" ? getConfiguredAiModel(configuration.provider) : null;
    if (!model) {
      return {
        status: "success",
        mode: "manual",
        prompt: request.prompt,
        message: configuration.status === "configured"
          ? "La clé IA est configurée, mais aucun modèle serveur n’est sélectionné. Utilisez le prompt manuel."
          : "Aucune API IA exploitable n’est configurée. Utilisez le prompt manuel.",
      };
    }

    const runtime = await getAiRuntimeConfiguration();
    if (runtime.provider !== configuration.provider) throw new Error("AI_RUNTIME_CONFIGURATION_UNAVAILABLE");
    const raw = await requestExposureProposal({ provider: runtime.provider, apiKey: runtime.apiKey, model, prompt: request.prompt });
    const proposal = parseAiExposureProposalJson(raw, request.workspace);
    return { status: "success", mode: "api", proposal, message: "Proposition IA reçue et validée. Vérifiez-la avant application." };
  } catch (error) {
    return actionError(error);
  }
}

export async function applyExposureAiProposalAction(
  _state: ExposureAiActionState,
  form: FormData,
): Promise<ExposureAiActionState> {
  try {
    const request = await context(form);
    const proposal = parseAiExposureProposalJson(value(form, "proposal"), request.workspace);
    const replaceExisting = form.get("replace_existing") === "on";
    const hasExistingDraft = Object.values(request.workspace.slots).some((slot) => slot.draft.rows.length > 0);
    if (hasExistingDraft && !replaceExisting) {
      return { status: "error", proposal, message: "Confirmez le remplacement des brouillons existants." };
    }
    const supabase = await createClient();
    const result = await supabase.rpc("apply_ai_asset_exposure_proposal", {
      aid: request.assetId,
      proposal,
      replace_existing: replaceExisting,
    });
    if (result.error) return {
      status: "error",
      proposal,
      message: result.error.code === "23514" && result.error.message?.includes("Existing exposure draft")
        ? "Confirmez le remplacement des brouillons existants."
        : "La proposition n’a pas pu être appliquée au brouillon.",
    };
    revalidatePath(`/assets/${request.assetId}/exposures`);
    revalidatePath("/assets");
    return { status: "success", applied: true, message: "Proposition appliquée au brouillon. La répartition effective est inchangée." };
  } catch (error) {
    return actionError(error);
  }
}
