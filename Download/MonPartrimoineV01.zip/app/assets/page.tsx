import { redirect } from "next/navigation";
import { DashboardHeader } from "@/app/components/dashboard-header";
import { getPageProfile } from "@/lib/auth/render-context";
import { asSettingsRecord, readProfileSettings } from "@/lib/settings/settings-core";
import { readThemePreference } from "@/lib/theme/theme-core";
import { getManagedAssets } from "@/lib/assets/assets";
import { AssetForms } from "./asset-forms";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function AssetsPage() {
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (current.status !== "active") redirect("/");
  const theme = readThemePreference(asSettingsRecord(documents.interface_preferences));
  const settings = readProfileSettings(documents);
  const assets = await getManagedAssets(current.profile.auth_user_id).catch(() => null);
  return <div data-theme={theme} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]">
    <DashboardHeader nickname={current.profile.nickname} displayName={settings.displayName} theme={theme} />
    <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
      <h1 className="text-3xl font-bold sm:text-4xl">Actifs</h1>
      <p className="mt-3 text-sm leading-6 text-[var(--app-muted)] sm:text-base">Gérez votre catalogue de titres et d’actifs, y compris les actifs inactifs.</p>
      <Link href="/assets/references" className="mt-4 inline-flex text-sm font-semibold text-[var(--app-gold)] underline underline-offset-4">Gérer les référentiels d’analyse</Link>
      {assets ? <AssetForms assets={assets} /> : <p role="alert" className="mt-8 text-red-500">Les actifs sont indisponibles. Réessayez ultérieurement.</p>}
    </main>
  </div>;
}
