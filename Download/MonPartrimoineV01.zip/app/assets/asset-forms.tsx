"use client";

import Link from "next/link";
import { Fragment, useActionState, useCallback, useState, type ReactNode } from "react";
import { compareDisplayNames, displayedName } from "@/lib/ui/display-order";
import { ColorField } from "@/app/components/color-field";
import { FieldHelp } from "@/app/settings/field-help";
import { useCollapseOnSuccess } from "@/app/components/use-collapse-on-success";
import { CreationDisclosure } from "@/app/components/creation-disclosure";
import { ASSET_CLASS_OPTIONS, VALUATION_MODE_OPTIONS, assetClassLabel, valuationModeLabel, type ManagedAsset, type AssetActionState } from "@/lib/assets/asset-core";
import { saveAssetAction } from "./actions";

const inputClass = "settings-input min-w-0 disabled:opacity-60";
const labelClass = "grid min-w-0 gap-2 text-sm font-medium";

function ActionForm({ operation, id, children, submit, onSaved }: { operation: string; id?: string; children?: ReactNode; submit: string; onSaved?: () => void }) {
  const [state, action, pending] = useActionState(saveAssetAction, { status: "idle" } as AssetActionState);
  const ref = useCollapseOnSuccess(state, pending, operation === "update", onSaved);
  return <form ref={ref} data-edit-trigger={id ? `asset-edit-${id}` : undefined} action={action} className="settings-form">
    <input type="hidden" name="operation" value={operation} />
    {id && <input type="hidden" name="id" value={id} />}
    <fieldset disabled={pending} className="grid min-w-0 gap-4">{children}
      <button type="submit" className="settings-primary-button">{pending ? "Enregistrement…" : submit}</button>
    </fieldset>
    {state.message && <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p>}
  </form>;
}

function AssetFields({ asset }: { asset?: ManagedAsset }) {
  const [assetClass,setAssetClass]=useState(asset?.asset_type_code??"");
  const [valuationMode,setValuationMode]=useState(asset?.asset_type_code==="real_estate"?"manual":asset?.valuation_mode??"market_price");
  const id = asset?.id ?? "create";
  const locked = asset?.hasDependencies ?? false;
  const customClass = asset && !ASSET_CLASS_OPTIONS.some(([code]) => code === asset.asset_type_code);
  return <>
    <label className={labelClass}>Nom *<input name="name" className={inputClass} defaultValue={asset?.name ?? ""} maxLength={200} required /></label>
    <label className={labelClass}>Nom d’affichage<input name="display_name" className={inputClass} defaultValue={asset?.display_name ?? ""} maxLength={120} /><span className="text-xs font-normal text-[var(--app-muted)]">Utilisé dans le Dashboard et les graphiques. Le nom complet reste conservé.</span></label>
    <div className="grid gap-5 md:grid-cols-2">
      <label className={labelClass}>Ticker / symbole<input name="symbol" className={inputClass} defaultValue={asset?.symbol ?? ""} /></label>
      <label className={labelClass}>ISIN<input name="isin" className={inputClass} defaultValue={asset?.isin ?? ""} pattern="[A-Za-z0-9]{12}" maxLength={12} disabled={locked} /></label>
      <label className={labelClass}>Classe *<select name="asset_type_code" className={inputClass} value={assetClass} onChange={e=>{setAssetClass(e.target.value);if(e.target.value==="real_estate")setValuationMode("manual");}} required disabled={locked}>
        <option value="" disabled>Choisir une classe</option>
        {ASSET_CLASS_OPTIONS.map(([code, label]) => <option key={code} value={code}>{label}</option>)}
        {customClass && <option value={asset.asset_type_code}>{asset.asset_type_code}</option>}
      </select></label>
      <label className={labelClass}>Devise *<input name="currency_code" className={inputClass} defaultValue={asset?.currency_code ?? "EUR"} pattern="[A-Za-z]{3}" maxLength={3} required disabled={locked} /></label>
    </div>
    {locked && <>
      <input type="hidden" name="isin" value={asset!.isin ?? ""} />
      <input type="hidden" name="asset_type_code" value={asset!.asset_type_code} />
      <input type="hidden" name="currency_code" value={asset!.currency_code} />
      <p className="text-xs text-[var(--app-muted)]">ISIN, classe et devise sont verrouillés : cet actif a déjà été utilisé dans votre patrimoine.</p>
    </>}
    <div className="grid gap-5 md:grid-cols-2">
      <label className={labelClass}>Mode de valorisation *<select name="valuation_mode" className={inputClass} value={valuationMode} onChange={e=>setValuationMode(e.target.value as typeof valuationMode)} disabled={assetClass==="real_estate"} required>
        {VALUATION_MODE_OPTIONS.map(([code, label]) => <option key={code} value={code}>{label}</option>)}
      </select></label>
      {assetClass==="real_estate"?<><input type="hidden" name="valuation_mode" value="manual"/><p className="self-end text-sm text-[var(--app-muted)]">Estimations totales datées depuis la fiche du contrat ; aucun cours automatique.</p></>:null}
      <div className={labelClass}>
        <div className="relative flex items-center gap-2 [&_.field-help]:static [&_.field-help-panel]:left-0">
          <label htmlFor={`source-${id}`}>Source de prix</label>
          <FieldHelp id={`source-help-${id}`} label="Source de prix">Cette indication décrit la source de prix. Elle ne déclenche aucune récupération automatique de cours.</FieldHelp>
        </div>
        <input id={`source-${id}`} name="price_source" className={inputClass} defaultValue={asset?.price_source ?? ""} />
      </div>
    </div>
    <ColorField key={asset?.color ?? "none"} initial={asset?.color ?? null} id={id} />
  </>;
}

function AssetEditor({ asset, onSaved }: { asset: ManagedAsset; onSaved: () => void }) {
  return <div className="grid gap-4 p-4 sm:p-5">
    {asset.asset_type_code==="real_estate"?<Link className="settings-edit-action justify-self-start" href={`/geography/asset/${asset.id}`}>Localisation du bien</Link>:null}
    <ActionForm operation="update" id={asset.id} submit="Enregistrer" onSaved={onSaved}><AssetFields asset={asset} /></ActionForm>
    <ActionForm operation={asset.is_active ? "deactivate" : "activate"} id={asset.id} submit={asset.is_active ? "Désactiver" : "Réactiver"} />
    <p className="text-xs text-[var(--app-muted)]">La désactivation conserve l’historique et interdit les nouvelles positions sur cet actif.</p>
    {asset.hasDependencies ? <p className="text-xs text-[var(--app-muted)]">Suppression interdite : cet actif a déjà été utilisé. Vous pouvez le désactiver.</p> :
      <details><summary className="cursor-pointer py-2 text-sm">Supprimer</summary>
        <ActionForm operation="delete" id={asset.id} submit="Supprimer définitivement">
          <p className="text-xs text-[var(--app-muted)]">La suppression reste soumise à l’absence de toute dépendance, notamment de prix ou d’expositions.</p>
          <label className="flex items-start gap-2 text-sm"><input type="checkbox" name="confirm" required className="mt-1" />Je confirme la suppression définitive de cet actif.</label>
        </ActionForm>
      </details>}
  </div>;
}

export function AssetForms({ assets }: { assets: ManagedAsset[] }) {
  const [editedId, setEditedId] = useState<string | null>(null);
  const closeEditor = useCallback(() => setEditedId(null), []);
  return <div className="mt-8 grid gap-6">
    <section className="settings-card min-w-0">
      <h2 className="settings-card-title mb-5">Catalogue ({assets.length})</h2>
      {!assets.length ? <p className="text-[var(--app-muted)]">Vous n’avez pas encore d’actif.</p> :
        <table className="block w-full text-left text-sm lg:table">
          <thead className="hidden lg:table-header-group"><tr>{["Actif", "Identifiants", "Classe / devise", "Valorisation", "Statut / couleur", "Gestion"].map((title) => <th key={title} scope="col" className="px-3 pb-4 font-semibold">{title}</th>)}</tr></thead>
          <tbody className="grid gap-6 lg:table-row-group">{[...assets].sort(compareDisplayNames).map((asset) => <Fragment key={asset.id}><tr className="grid min-w-0 gap-3 border-t border-[var(--app-border)] py-4 lg:table-row [&>td]:min-w-0 [&>td]:break-words lg:[&>td]:p-3 lg:[&>td]:align-top">
            <td className="font-semibold lg:max-w-44" title={asset.name}><span className="mr-2 text-xs font-normal text-[var(--app-muted)] lg:hidden">Actif</span>{displayedName(asset)}</td>
            <td className="lg:max-w-40"><span className="mr-2 text-xs text-[var(--app-muted)] lg:hidden">Identifiants</span>{asset.symbol ?? "Sans symbole"}<br /><span className="text-[var(--app-muted)]">{asset.isin ?? "Sans ISIN"}</span></td>
            <td><span className="mr-2 text-xs text-[var(--app-muted)] lg:hidden">Classe / devise</span>{assetClassLabel(asset.asset_type_code)} · {asset.currency_code}</td>
            <td className="lg:max-w-40"><span className="mr-2 text-xs text-[var(--app-muted)] lg:hidden">Valorisation</span>{valuationModeLabel(asset.valuation_mode)}<br /><span className="text-[var(--app-muted)]">{asset.price_source ?? "Source non renseignée"}</span></td>
            <td><span className="mr-2 text-xs text-[var(--app-muted)] lg:hidden">Statut</span>{asset.is_active ? "Actif" : "Inactif"}<span className="mt-2 flex items-center gap-2"><span aria-hidden="true" className="size-4 shrink-0 rounded border border-[var(--app-border)]" style={{ backgroundColor: asset.color ?? "transparent" }} />{asset.color ?? "Sans couleur"}</span></td>
            <td className="lg:w-80"><span className="text-xs text-[var(--app-muted)] lg:hidden">Gestion</span><div className="grid gap-3 sm:grid-cols-2"><Link href={`/assets/${asset.id}/prices`} className="min-h-11 rounded-md border border-[var(--app-border)] px-3 py-3 text-center font-semibold text-[var(--app-gold)]">Valorisation</Link><Link href={`/assets/${asset.id}/exposures`} className="min-h-11 rounded-md border border-[var(--app-border)] px-3 py-3 text-center font-semibold text-[var(--app-gold)]">Répartitions</Link><button id={`asset-edit-${asset.id}`} type="button" aria-expanded={editedId===asset.id} aria-controls={`asset-editor-${asset.id}`} onClick={()=>setEditedId((current)=>current===asset.id?null:asset.id)} className="settings-edit-action sm:col-span-2">{editedId===asset.id?"Fermer":"Modifier"}</button></div></td>
          </tr>{editedId===asset.id?<tr id={`asset-editor-${asset.id}`}><td colSpan={6} className="border-t border-[var(--app-border)] p-0"><AssetEditor asset={asset} onSaved={closeEditor}/></td></tr>:null}</Fragment>)}</tbody>
        </table>}
    </section>
    <CreationDisclosure title="Créer un actif">
      <ActionForm operation="create" submit="Créer l’actif"><AssetFields /></ActionForm>
    </CreationDisclosure>
  </div>;
}
