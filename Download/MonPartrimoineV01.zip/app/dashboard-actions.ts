"use server";

import { revalidatePath } from "next/cache";

import { updateCurrentInterfacePreferences } from "@/lib/interface-preferences";
import type { ThemePreference } from "@/lib/theme/theme-core";
import { getCurrentProfile } from "@/lib/auth/profile";
import { refreshAutomaticAssetPrices, type AutomaticPriceRefreshSummary } from "@/lib/assets/automatic-prices";
import { parisDateFromIso } from "@/lib/cash/cash-core";
import { captureDailyPatrimony } from "@/lib/patrimony/daily-history";

export type AutomaticPriceRefreshState = {
  status: "idle" | "success" | "error";
  summary?: AutomaticPriceRefreshSummary;
  message?: string;
};

function revalidateAutomaticPriceViews() {
  for (const path of ["/", "/assets", "/assets/refresh", "/contracts", "/reports", "/reports/history", "/patrimony"]) revalidatePath(path);
  revalidatePath("/assets/[id]/prices", "page");
  revalidatePath("/contracts/[id]", "page");
}

export async function updateThemeAction(formData: FormData) {
  const requested = String(formData.get("theme") ?? "");
  if (requested !== "dark" && requested !== "light") return;
  const theme: ThemePreference = requested;

  await updateCurrentInterfacePreferences({ theme });
  revalidatePath("/");
}

export async function refreshAutomaticPricesAction(): Promise<AutomaticPriceRefreshState> {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active") return { status: "error", message: "Connectez-vous avec le compte autorisé." };
  try {
    const summary = await refreshAutomaticAssetPrices({ ownerId: current.profile.auth_user_id, mode: "manual" });
    let historyWarning = "";
    if (summary.persistedPrices > 0) {
      const businessDate = parisDateFromIso(new Date().toISOString());
      await captureDailyPatrimony(businessDate, { requestedRevision: true }).catch(() => { historyWarning = " L’historique du jour n’a pas pu être actualisé ; les cours enregistrés sont conservés."; });
    }
    revalidateAutomaticPriceViews();
    return { status: summary.failures || historyWarning ? "error" : "success", summary, message: summary.message + historyWarning };
  } catch {
    return { status: "error", message: "L’actualisation automatique est temporairement indisponible. Les derniers prix connus sont conservés." };
  }
}
