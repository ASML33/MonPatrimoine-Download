'use server';
import {getCurrentProfile} from '@/lib/auth/profile';
import {createClient} from '@/lib/supabase/server';
import {revalidatePath} from 'next/cache';
import {isUuid} from '@/lib/assets/asset-core';
import {logReferenceDiagnostic,type ReferenceDiagnosticId} from '@/lib/fiscal/reference-diagnostics';
export type EnvelopeActionState={status:'idle'|'error'|'success';message?:string;id?:string};
export async function saveEnvelope(_state:EnvelopeActionState,form:FormData):Promise<EnvelopeActionState>{
 if((await getCurrentProfile().catch(()=>null))?.status!=='active')return {status:'error',message:'Accès réservé au compte actif. Référence REF-AUTH.'};
 try{
  const client=await createClient(),operation=String(form.get('operation')??'');
  const readiness=await client.rpc('get_envelopes');
  if(readiness.error||readiness.data?.version!==2){logReferenceDiagnostic('REF-SQL-DEPENDENCY','mutation',readiness.error);return {status:'error',message:'Gestion temporairement indisponible : la mise à jour SQL de la période unique doit être installée. Vos saisies sont conservées. Référence REF-SQL-DEPENDENCY.'};}
  const raw=String(form.get('requested')??'{}');if(raw.length>32000)return {status:'error',message:'Paramétrage trop volumineux.'};
  const requested=JSON.parse(raw);let result;
  if(operation==='create')result=await client.rpc('create_envelope_bundle',{requested});
  else{
   const envelope=String(form.get('envelope')??''),ident=String(form.get('id')??'')||null;
   if(!isUuid(envelope)||(ident&&!isUuid(ident))||!['add','edit','delete','evolve'].includes(operation))return {status:'error',message:'Opération invalide.'};
   if((operation==='delete'||operation==='evolve')&&form.get('confirm')!=='on')return {status:'error',message:'Confirmez cette opération avant d’enregistrer.'};
   result=await client.rpc('change_envelope_fiscality',{operation,envelope,ident,expected:Number(form.get('revision'))||null,requested,transition:null});
  }
  if(result.error){const mapping:Record<string,[ReferenceDiagnosticId,string]>={P7201:['REF-PROTECTED','Cette fiscalité est utilisée. Ajoutez une évolution datée pour conserver son sens antérieur.'],P7202:['REF-COVERAGE','L’inutilisation ne peut pas être démontrée. Une évolution datée reste possible.'],P7203:['REF-PERIOD','La fin de période doit suivre ou égaler son début.'],P7204:['REF-COMBINATION','Configuration non prise en charge : vérifiez la portée, les assiettes et les paliers numériques strictement croissants, à partir de 0 mois.'],P7200:['REF-SQL-DEPENDENCY','Ce parcours a été remplacé par Enveloppes.'],'40001':['REF-CONFLICT','La configuration a changé simultanément. Vos saisies sont conservées ; relisez la fiche avant de réessayer.'],'23505':['REF-VALIDATION','Ce nom existe déjà ou une évolution a été ajoutée simultanément.'],'42501':['REF-AUTH','Opération non autorisée.'],'42883':['REF-SQL-DEPENDENCY','Gestion indisponible : la migration Enveloppes doit être installée.'],PGRST202:['REF-SQL-DEPENDENCY','Gestion indisponible : la migration Enveloppes doit être installée.']};
   const [id,message]=mapping[result.error.code]??['REF-VALIDATION','Paramètres invalides : vérifiez le modèle, les taux, le nom et les périodes.'];logReferenceDiagnostic(id,'mutation',result.error);return {status:'error',message:message+' Référence '+id+'.'};
  }
  for(const path of ['/envelopes','/contracts','/reports','/patrimony','/ai','/'])revalidatePath(path);
  const envelope=String(form.get('envelope')??'');if(envelope)revalidatePath('/envelopes/'+envelope);
  return {status:'success',id:operation==='create'?String(result.data):undefined,message:'Configuration enregistrée. Les données BRUT et les captures publiées sont conservées.'};
 }catch{logReferenceDiagnostic('REF-VALIDATION','mutation');return {status:'error',message:'Paramétrage invalide ou service indisponible. Vos saisies sont conservées. Référence REF-VALIDATION.'};}
}
