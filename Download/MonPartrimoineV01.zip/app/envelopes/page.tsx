import {EnvelopePage} from './envelope-page';
export const dynamic='force-dynamic';
export default function Page(){return <EnvelopePage/>;}
