import {EnvelopePage} from '../envelope-page';
export const dynamic='force-dynamic';
export default async function Page({params}:{params:Promise<{id:string}>}){return <EnvelopePage id={(await params).id}/>;}
