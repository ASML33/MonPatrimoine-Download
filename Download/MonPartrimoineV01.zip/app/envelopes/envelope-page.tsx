import Link from 'next/link';
import {notFound,redirect} from 'next/navigation';
import {DashboardHeader} from '@/app/components/dashboard-header';
import {getPageProfile} from '@/lib/auth/render-context';
import {asSettingsRecord,readProfileSettings} from '@/lib/settings/settings-core';
import {readThemePreference} from '@/lib/theme/theme-core';
import {readEnvelopes} from '@/lib/fiscal/envelopes';
import {EnvelopeList,EnvelopeDetail} from './envelope-forms';
export async function EnvelopePage({id}:{id?:string}){
 const {current,documents}=await getPageProfile();if(current.status==='unauthenticated')redirect('/login');if(current.status!=='active')redirect('/');
 const data=await readEnvelopes();if(id&&data&&!data.catalog.types.some(t=>t.id===id))notFound();
 const theme=readThemePreference(asSettingsRecord(documents.interface_preferences));const name=id?data?.catalog.types.find(t=>t.id===id)?.label:'Enveloppes';
 return <div data-theme={theme} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]"><DashboardHeader nickname={current.profile.nickname} displayName={readProfileSettings(documents).displayName} theme={theme}/><main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">{id?<Link href="/envelopes" className="text-sm font-semibold text-[var(--app-gold)]">← Retour aux enveloppes</Link>:null}<header className="mt-5 max-w-3xl"><h1 className="text-3xl font-bold sm:text-4xl">{name??'Enveloppe'}</h1><p className="mt-3 text-sm leading-6 text-[var(--app-muted)] sm:text-base">{id?'Une fiche pour les informations de l’enveloppe et ses fiscalités.':'Gérez les catégories de vos contrats et leurs fiscalités.'}</p></header>{data?id?<EnvelopeDetail data={data} id={id}/>:<EnvelopeList data={data}/>:<p role="status" className="settings-card mt-8">Les enveloppes sont indisponibles : la configuration SQL doit être installée et accessible. Référence REF-SQL-DEPENDENCY.</p>}</main></div>;
}
