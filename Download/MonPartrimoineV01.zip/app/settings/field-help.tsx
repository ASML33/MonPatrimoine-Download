"use client";

import { useEffect, useRef } from "react";

type FieldHelpProps = {
  id: string;
  label: string;
  children: string;
  icon?: "?" | "i";
};

export function FieldHelp({ id, label, children, icon = "?" }: FieldHelpProps) {
  const detailsRef = useRef<HTMLDetailsElement>(null);

  function dismiss(details: HTMLDetailsElement) {
    details.open = false;
    // Hover/focus must not immediately redisplay an explicitly dismissed help.
    details.dataset.dismissed = "true";
  }

  function activate(details: HTMLDetailsElement) {
    document.querySelectorAll<HTMLDetailsElement>("details.field-help").forEach((other) => {
      if (other !== details) dismiss(other);
    });
    delete details.dataset.dismissed;
  }

  useEffect(() => {
    const details = detailsRef.current;
    if (!details) return;

    function onOutsideClick(event: MouseEvent) {
      if (event.target instanceof Node && !details!.contains(event.target)) dismiss(details!);
    }

    function onEscape(event: KeyboardEvent) {
      if (event.key !== "Escape") return;
      const focusedInside = details!.contains(document.activeElement);
      if (details!.open || focusedInside || details!.matches(":hover")) {
        if (focusedInside) details!.querySelector("summary")?.focus();
        dismiss(details!);
      }
    }

    document.addEventListener("click", onOutsideClick, true);
    document.addEventListener("keydown", onEscape);
    return () => {
      document.removeEventListener("click", onOutsideClick, true);
      document.removeEventListener("keydown", onEscape);
    };
  }, []);

  return (
    <details
      ref={detailsRef}
      className="field-help"
      onPointerEnter={(event) => activate(event.currentTarget)}
      onFocus={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget)) activate(event.currentTarget);
      }}
      onToggle={(event) => {
        if (event.currentTarget.open) activate(event.currentTarget);
        else dismiss(event.currentTarget);
      }}
    >
      <summary aria-controls={id} aria-label={`Aide : ${label}`}>
        {icon}
      </summary>
      <span className="field-help-panel" id={id} role="note">
        {children}
      </span>
    </details>
  );
}
