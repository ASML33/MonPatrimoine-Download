"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { updateThemeAction } from "@/app/dashboard-actions";
import { DisclosureCard } from "@/app/components/creation-disclosure";
import { FieldHelp } from "@/app/settings/field-help";
import { GoogleDriveSettings } from "@/app/settings/google-drive-settings";
import type { DriveView } from "@/lib/backups/google-drive-core";
import { PriceProviderSettings } from "@/app/settings/price-provider-settings";

import type { ThemePreference } from "@/lib/theme/theme-core";

import {
  updateEmailAction,
  updateIdentifierAction,
  updatePasswordAction,
  updateUserInformationAction,
} from "@/app/settings-actions";
import type {
  ProfileSettingsFormValues,
  SettingsActionState,
} from "@/lib/settings/settings-core";
import type { PriceProviderConfiguration } from "@/lib/assets/price-provider-configuration-core";

const initialState: SettingsActionState = { status: "idle" };

function StatusMessage({ state }: { state: SettingsActionState }) {
  if (!state.message) return null;
  return (
    <p
      className={`text-sm ${
        state.status === "success" ? "text-emerald-500" : "text-red-500"
      }`}
      aria-live="polite"
      role="status"
    >
      {state.message}
    </p>
  );
}

export function SettingsForms({
  identifier,
  email,
  theme,
  settings,
  priceProviderConfigurations,
  driveView,
  driveResult,
}: {
  identifier: string;
  email: string;
  theme: ThemePreference;
  settings: ProfileSettingsFormValues;
  priceProviderConfigurations: PriceProviderConfiguration[];
  driveView: DriveView;
  driveResult?: string;
}) {
  const [openSection, setOpenSection] = useState<string | null>(driveResult ? "drive" : null);
  const toggleSection = (section: string) => setOpenSection((current) => current === section ? null : section);
  const [identifierState, identifierAction, identifierPending] = useActionState(
    updateIdentifierAction,
    initialState,
  );
  const [emailState, emailAction, emailPending] = useActionState(
    updateEmailAction,
    initialState,
  );
  const [passwordState, passwordAction, passwordPending] = useActionState(
    updatePasswordAction,
    initialState,
  );
  const [informationState, informationAction, informationPending] =
    useActionState(updateUserInformationAction, initialState);
  const passwordForm = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (passwordState.status === "success") passwordForm.current?.reset();
  }, [passwordState]);

  return (
    <div className="mt-10 grid gap-6 sm:mt-12 sm:gap-8">
      <GoogleDriveSettings view={driveView} result={driveResult} open={openSection === "drive"} onToggle={() => toggleSection("drive")} />
      <DisclosureCard title="Fournisseurs de cours" description="Configurez jusqu’à dix fournisseurs, leur priorité et leur périmètre." icon="€" open={openSection === "prices"} onToggle={() => toggleSection("prices")}>
        <PriceProviderSettings configurations={priceProviderConfigurations} />
      </DisclosureCard>
      <DisclosureCard title="Identité" description="Vos informations personnelles et de connexion." icon="●" open={openSection === "identity"} onToggle={() => toggleSection("identity")}>

        <div className="mt-7 grid gap-7 lg:grid-cols-2 lg:gap-8">
          <form action={identifierAction} className="settings-form">
            <div className="grid gap-2 text-sm font-medium">
              <div className="flex items-center gap-2">
                <label htmlFor="identifier">Identifiant</label>
                <FieldHelp id="identifier-help" label="Identifiant">
                  Identifiant utilisé pour vous connecter à MonPatrimoine. Il doit
                  être unique.
                </FieldHelp>
              </div>
              <input
                className="settings-input"
                defaultValue={identifier}
                id="identifier"
                maxLength={40}
                minLength={3}
                name="identifier"
                required
                autoComplete="username"
              />
            </div>
            <StatusMessage state={identifierState} />
            <button
              className="settings-primary-button w-full"
              disabled={identifierPending}
              type="submit"
            >
              {identifierPending ? "Enregistrement…" : "Modifier l’identifiant"}
            </button>
          </form>

          <form action={emailAction} className="settings-form">
            <div className="grid gap-2 text-sm font-medium">
              <div className="flex items-center gap-2">
                <label htmlFor="email">Email</label>
                <FieldHelp id="email-help" label="Email">
                  Adresse email associée à votre compte, utilisable pour la
                  connexion et la récupération du compte.
                </FieldHelp>
              </div>
              <input
                className="settings-input"
                defaultValue={email}
                id="email"
                name="email"
                required
                type="email"
                autoComplete="email"
              />
            </div>
            <StatusMessage state={emailState} />
            <button
              className="settings-primary-button w-full"
              disabled={emailPending}
              type="submit"
            >
              {emailPending ? "Enregistrement…" : "Modifier l’e-mail"}
            </button>
          </form>
        </div>
        <form
          ref={passwordForm}
          action={passwordAction}
          className="mt-7 grid gap-5"
        >
          <div className="grid gap-5 md:grid-cols-2 md:gap-8">
            <label className="grid gap-2 text-sm font-medium" htmlFor="password">
              Nouveau mot de passe
              <input
                className="settings-input"
                id="password"
                name="password"
                required
                type="password"
                autoComplete="new-password"
              />
            </label>
            <label className="grid gap-2 text-sm font-medium" htmlFor="confirmation">
              Confirmer le mot de passe
              <input
                className="settings-input"
                id="confirmation"
                name="confirmation"
                required
                type="password"
                autoComplete="new-password"
              />
            </label>
          </div>
          <StatusMessage state={passwordState} />
          <button
            className="settings-primary-button w-full"
            disabled={passwordPending}
            type="submit"
          >
            {passwordPending ? "Enregistrement…" : "Modifier le mot de passe"}
          </button>
        </form>
      </DisclosureCard>

      <DisclosureCard title="Personnalisation Interface" description="Personnalisez le nom affiché et le thème de l’interface." icon="◐" open={openSection === "personalization"} onToggle={() => toggleSection("personalization")}>

        <div className="mt-7 grid gap-8 lg:grid-cols-2 lg:gap-10">
          <form action={informationAction} className="settings-form">
            <div className="grid gap-2 text-sm font-medium">
              <div className="flex items-center gap-2">
                <label htmlFor="displayName">Nom d’usage</label>
                <FieldHelp id="display-name-help" label="Nom d’usage">
                  Nom affiché dans l’interface. Il ne modifie pas votre Identifiant
                  de connexion.
                </FieldHelp>
              </div>
              <input
                className="settings-input"
                defaultValue={settings.displayName}
                id="displayName"
                maxLength={80}
                name="displayName"
                autoComplete="name"
              />
            </div>
            <StatusMessage state={informationState} />
            <button
              className="settings-primary-button"
              disabled={informationPending}
              type="submit"
            >
              {informationPending
                ? "Enregistrement…"
                : "Enregistrer les informations"}
            </button>
          </form>

          <form action={updateThemeAction} className="grid content-start gap-2">
            <fieldset>
              <legend className="mb-2 text-sm font-medium">Thème</legend>

              <div className="theme-selector">
                {(["dark", "light"] as const).map((value) => (
                  <button
                    key={value}
                    className="theme-option"
                    data-selected={theme === value}
                    name="theme"
                    value={value}
                    aria-pressed={theme === value}
                    type="submit"
                  >
                    <span className="text-lg leading-none" aria-hidden="true">
                      {value === "dark" ? "☾" : "☀"}
                    </span>
                    {value === "dark" ? "Sombre" : "Clair"}
                  </button>
                ))}
              </div>
            </fieldset>
          </form>
        </div>
      </DisclosureCard>





    </div>
  );
}
