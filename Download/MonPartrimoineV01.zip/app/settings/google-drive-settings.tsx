"use client";

import { DisclosureCard } from "@/app/components/creation-disclosure";
import type { DriveView } from "@/lib/backups/google-drive-core";

const labels = {
  not_configured: "La connexion Google Drive n’est pas encore disponible.",
  not_connected: "Google Drive n’est pas connecté.",
  connected: "Connexion Google Drive vérifiée.",
  needs_check: "Connexion enregistrée ; son accès doit être vérifié.",
  reconnect_required: "La connexion Google Drive doit être rétablie.",
  unavailable: "L’état de la connexion Google Drive est momentanément indisponible.",
};
export function GoogleDriveSettings({ view, result, open, onToggle }: { view: DriveView; result?: string; open: boolean; onToggle: () => void }) {
  const enabled = view.status !== "not_configured";
  const message = result === "cancelled" ? "Connexion annulée. Votre connexion précédente est conservée."
    : result === "unavailable" ? "La connexion n’a pas pu être vérifiée. Réessayez ou reconnectez Google Drive."
      : result === "connected" || result === "checked" ? "Vérification terminée." : null;
  return (
    <DisclosureCard title="Connexion Google Drive" icon="↔" open={open} onToggle={onToggle}>
      <div id="google-drive">
      <p className="mt-2 text-sm text-[var(--app-muted)]">Autorisez uniquement les fichiers utilisés par MonPatrimoine. Cette connexion ne crée pas encore de sauvegarde.</p>
      <a className="mt-2 inline-block text-sm underline" href="/google-drive-privacy">Utilisation de vos données Google Drive</a>
      <p className="mt-3 text-sm" role="status">{labels[view.status]}</p>
      {view.verifiedAt && <p className="mt-1 text-sm text-[var(--app-muted)]">Dernière vérification : {new Intl.DateTimeFormat("fr-FR", { timeZone: "Europe/Paris", dateStyle: "short", timeStyle: "short" }).format(new Date(view.verifiedAt))}.</p>}
      {message && <p className="mt-2 text-sm" role="status">{message}</p>}
      {enabled && <div className="mt-4 flex flex-wrap gap-3">
        <form method="post" action="/api/backups/google-drive/oauth/start">
          <button className="settings-primary-button" type="submit">{view.status === "not_connected" ? "Connecter Google Drive" : "Reconnecter Google Drive ou changer de compte"}</button>
        </form>
        {["connected", "needs_check"].includes(view.status) && <form method="post" action="/api/backups/google-drive/connection">
          <button className="settings-primary-button" type="submit">Vérifier la connexion</button>
        </form>}
      </div>}
      </div>
    </DisclosureCard>
  );
}
