"use client";

import { useActionState, useCallback, useEffect, useRef, useState } from "react";
import {
  deletePriceProviderConfigurationAction,
  savePriceProviderConfigurationAction,
} from "@/app/settings-actions";
import {
  PRICE_PROVIDER_CAPABILITY_OPTIONS,
  PRICE_PROVIDER_REGION_OPTIONS,
  priceProviderLabel,
  type PriceProviderConfiguration,
} from "@/lib/assets/price-provider-configuration-core";
import type { SettingsActionState } from "@/lib/settings/settings-core";
import {
  beginPriceProviderNotification,
  completePriceProviderNotification,
  priceProviderNotificationForSlot,
  type PriceProviderNotification,
} from "./price-provider-notification-core";

const initialState: SettingsActionState = { status: "idle" };
const fixedKeyMask = "••••••••••••";

function ProviderStatus({ configuration }: { configuration?: PriceProviderConfiguration }) {
  if (!configuration) return <span className="text-xs font-semibold text-[var(--app-muted)]">Non configuré</span>;
  if (configuration.adapter === "marketstack") return <span className="text-xs font-semibold text-amber-500">Préparation désactivée — couverture et droits non établis</span>;
  const values = {
    validated: { label: "Clé valide", className: "text-emerald-500" },
    invalid: { label: "Clé invalide", className: "text-red-500" },
    unsupported: { label: "Fournisseur non pris en charge", className: "text-amber-500" },
    untested: { label: "Clé non testée", className: "text-[var(--app-muted)]" },
  } as const;
  const status = values[configuration.status];
  return <span className={`text-xs font-semibold ${status.className}`}>{status.label}</span>;
}

function ActionStatus({ state }: { state: SettingsActionState }) {
  return state.message ? (
    <p role="status" aria-live="polite" className={`text-sm ${state.status === "success" ? "text-emerald-500" : "text-red-500"}`}>
      {state.message}
    </p>
  ) : null;
}

function ProviderSlot({
  slot,
  configuration,
  notification,
  onActionStart,
  onActionResult,
}: {
  slot: number;
  configuration?: PriceProviderConfiguration;
  notification: PriceProviderNotification | null;
  onActionStart: (slot: number) => number;
  onActionResult: (slot: number, token: number, state: SettingsActionState) => void;
}) {
  const [latestAction, setLatestAction] = useState<"save" | "delete">("save");
  const [saveState, saveAction, savePending] = useActionState(savePriceProviderConfigurationAction, initialState);
  const [deleteState, deleteAction, deletePending] = useActionState(deletePriceProviderConfigurationAction, initialState);
  const keyInput = useRef<HTMLInputElement>(null);
  const actionToken = useRef(0);

  useEffect(() => {
    if (saveState.status !== "idle" && keyInput.current) keyInput.current.value = "";
  }, [saveState]);
  useEffect(() => {
    const state = latestAction === "save" ? saveState : deleteState;
    if (state.status !== "idle") onActionResult(slot, actionToken.current, state);
  }, [deleteState, latestAction, onActionResult, saveState, slot]);
  const visibleState = priceProviderNotificationForSlot(notification, slot);
  const fieldKey = `${configuration?.providerName ?? ""}:${configuration?.priority ?? ""}:${configuration?.region ?? ""}:${configuration?.capability ?? ""}:${configuration?.active ?? false}`;

  function beginAction(action: "save" | "delete") {
    setLatestAction(action);
    actionToken.current = onActionStart(slot);
  }

  return (
    <article className="rounded-lg border border-[var(--app-border)] p-4">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <h3 className="font-semibold">Fournisseur {slot}</h3>
        <ProviderStatus configuration={configuration} />
      </div>
      <form action={saveAction} onSubmit={() => beginAction("save")} className="grid gap-4 md:grid-cols-2">
        <input type="hidden" name="slot" value={slot} />
        <label className="grid gap-2 text-sm font-medium">
          Nom du fournisseur <span aria-hidden="true">*</span>
          <input key={`name:${fieldKey}`} className="settings-input" type="text" name="providerName" defaultValue={configuration?.providerName ?? ""} maxLength={120} required />
        </label>
        <label className="grid gap-2 text-sm font-medium">
          Priorité <span aria-hidden="true">*</span>
          <select key={`priority:${fieldKey}`} className="settings-input" name="priority" defaultValue={configuration?.priority ?? ""} required>
            <option value="">Sélectionner…</option>
            {Array.from({ length: 10 }, (_, index) => index + 1).map((value) => <option key={value} value={value}>{value}</option>)}
          </select>
        </label>
        <label className="grid gap-2 text-sm font-medium">
          Zone <span aria-hidden="true">*</span>
          <select key={`region:${fieldKey}`} className="settings-input" name="region" defaultValue={configuration?.region ?? ""} required>
            <option value="">Sélectionner…</option>
            {PRICE_PROVIDER_REGION_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
          </select>
        </label>
        <label className="grid gap-2 text-sm font-medium">
          Capacité <span aria-hidden="true">*</span>
          <select key={`capability:${fieldKey}`} className="settings-input" name="capability" defaultValue={configuration?.capability ?? ""} required>
            <option value="">Sélectionner…</option>
            {PRICE_PROVIDER_CAPABILITY_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
          </select>
        </label>
        <label className="grid gap-2 text-sm font-medium md:col-span-2">
          Clé API <span aria-hidden="true">*</span>
          <input ref={keyInput} className="settings-input" type="password" name="apiKey" maxLength={4096} autoComplete="new-password" required={!configuration} placeholder={configuration ? fixedKeyMask : ""} />
          {configuration ? <span className="text-xs font-normal text-[var(--app-muted)]">Une clé est enregistrée. Laissez vide pour la conserver.</span> : null}
        </label>
        <label className="flex min-h-11 items-center gap-3 text-sm font-medium">
          <input key={`active:${fieldKey}`} type="checkbox" name="active" defaultChecked={configuration?.active ?? false} />
          Actif <span aria-hidden="true">*</span>
          {configuration?.adapter ? <span className="text-xs font-normal text-[var(--app-muted)]">Adaptateur {priceProviderLabel(configuration.adapter)}</span> : null}
        </label>
        <div className="flex flex-wrap justify-end gap-3">
          <button className="settings-primary-button" type="submit" disabled={savePending || deletePending}>{savePending ? "Enregistrement…" : "Enregistrer"}</button>
        </div>
      </form>
      {configuration ? (
        <form action={deleteAction} onSubmit={() => beginAction("delete")} className="mt-3 grid gap-3">
          <input type="hidden" name="slot" value={slot} />
          <button className="min-h-11 rounded-md border border-[var(--app-border)] px-4 text-sm font-semibold hover:bg-[var(--app-hover)] disabled:opacity-50" type="submit" disabled={deletePending || savePending}>
            {deletePending ? "Suppression…" : "Supprimer la configuration et la clé"}
          </button>
        </form>
      ) : null}
      <div className="mt-3">{visibleState ? <ActionStatus state={visibleState} /> : null}</div>
    </article>
  );
}

export function PriceProviderSettings({ configurations }: { configurations: PriceProviderConfiguration[] }) {
  const bySlot = new Map(configurations.map((configuration) => [configuration.slot, configuration]));
  const [notification, setNotification] = useState<PriceProviderNotification | null>(null);
  const notificationToken = useRef(0);
  const onActionStart = useCallback((slot: number) => {
    notificationToken.current += 1;
    const token = notificationToken.current;
    setNotification(beginPriceProviderNotification(slot, token));
    return token;
  }, []);
  const onActionResult = useCallback((slot: number, token: number, state: SettingsActionState) => {
    setNotification((current) => completePriceProviderNotification(current, slot, token, state));
  }, []);
  return (
    <div className="grid gap-4 xl:grid-cols-2">
      {Array.from({ length: 10 }, (_, index) => index + 1).map((slot) => (
        <ProviderSlot
          key={slot}
          slot={slot}
          configuration={bySlot.get(slot)}
          notification={notification}
          onActionStart={onActionStart}
          onActionResult={onActionResult}
        />
      ))}
    </div>
  );
}
