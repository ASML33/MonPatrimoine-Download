import type { SettingsActionState } from "@/lib/settings/settings-core";

export type PriceProviderNotification = {
  slot: number;
  token: number;
  pending: boolean;
  state: SettingsActionState;
};

const idleState: SettingsActionState = { status: "idle" };

export function beginPriceProviderNotification(slot: number, token: number): PriceProviderNotification {
  return { slot, token, pending: true, state: idleState };
}

export function completePriceProviderNotification(
  current: PriceProviderNotification | null,
  slot: number,
  token: number,
  state: SettingsActionState,
) {
  if (!current || current.slot !== slot || current.token !== token) return current;
  return { slot, token, pending: false, state } satisfies PriceProviderNotification;
}

export function priceProviderNotificationForSlot(
  notification: PriceProviderNotification | null,
  slot: number,
) {
  return notification?.slot === slot && !notification.pending
    ? notification.state
    : null;
}
