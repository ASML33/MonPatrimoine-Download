import { redirect } from "next/navigation";

import { DashboardHeader } from "@/app/components/dashboard-header";
import { SettingsForms } from "@/app/settings/settings-forms";
import { getDriveConnectionView } from "@/lib/backups/google-drive";
import { getPageProfile } from "@/lib/auth/render-context";
import { getCurrentPriceProviderConfigurations } from "@/lib/assets/price-provider-configurations";
import {
  asSettingsRecord,
  canAccessSettings,
  readProfileSettings,
} from "@/lib/settings/settings-core";
import { capitalizeNickname, readThemePreference } from "@/lib/theme/theme-core";

export const dynamic = "force-dynamic";

export default async function SettingsPage({ searchParams }: { searchParams: Promise<{ drive?: string }> }) {
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (!canAccessSettings(current.status)) redirect("/");
  if (current.status !== "active") redirect("/");

  const [priceProviderConfigurations, driveView, query] = await Promise.all([
    getCurrentPriceProviderConfigurations(),
    getDriveConnectionView(),
    searchParams,
  ]);
  const interfacePreferences = asSettingsRecord(documents.interface_preferences);
  const theme = readThemePreference(interfacePreferences);
  const settings = readProfileSettings(documents);

  return (
    <div
      data-theme={theme}

      className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]"
    >
      <DashboardHeader
        nickname={current.profile.nickname}
        displayName={settings.displayName}
        theme={theme}


      />

      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
        <header className="max-w-3xl">
          <h1 className="text-3xl font-bold sm:text-4xl">Paramètres</h1>
          <p className="mt-3 text-sm leading-6 text-[var(--app-muted)] sm:text-base">
            Gérez votre compte et personnalisez votre expérience sur MonPatrimoine.
          </p>
        </header>
        <SettingsForms
          identifier={capitalizeNickname(current.profile.nickname)}
          email={current.profile.email}
          theme={theme}
          settings={settings}
          priceProviderConfigurations={priceProviderConfigurations}
          driveView={driveView}
          driveResult={typeof query.drive === "string" ? query.drive : undefined}
        />
      </main>
    </div>
  );
}
