"use server";

import { revalidatePath } from "next/cache";
import { getCurrentProfile } from "@/lib/auth/profile";
import { isUuid } from "@/lib/assets/asset-core";
import { FISCAL_BASE_TYPES } from "@/lib/fiscal/fiscal-core";
import type { FiscalActionState } from "@/lib/fiscal/fiscal-settings-core";
import { getFiscalSettingsAvailability } from "@/lib/fiscal/fiscal-settings";
import { createClient } from "@/lib/supabase/server";

function optionalNumber(form: FormData, name: string, divisor = 1) {
  const raw = String(form.get(name) ?? "").trim();
  if (!raw) return null;
  const value = Number(raw) / divisor;
  if (!Number.isFinite(value) || value < 0) throw new Error("Valeur numérique invalide.");
  return value;
}

export async function saveFiscalRuleAction(_state: FiscalActionState, form: FormData): Promise<FiscalActionState> {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active") return { status: "error", message: "Connectez-vous avec un compte actif." };
  const regimeId = String(form.get("fiscal_regime_id") ?? "");
  const scope = String(form.get("scope") ?? "");
  if (!isUuid(regimeId) || !["common", "personal"].includes(scope)) return { status: "error", message: "Régime fiscal invalide." };
  if (form.get("confirm") !== "yes") return { status: "error", message: "Vérifiez puis confirmez la nouvelle version." };
  const base = (name: string) => {
    const value = String(form.get(name) ?? "");
    if (!FISCAL_BASE_TYPES.includes(value as (typeof FISCAL_BASE_TYPES)[number])) throw new Error("Base taxable invalide.");
    return value;
  };
  try {
    if ((await getFiscalSettingsAvailability(current.profile.auth_user_id, true)).status !== "available") {
      return { status: "error", message: "Fiscalité indisponible. Aucune modification n’a été enregistrée." };
    }
    const supabase = await createClient();
    const result = await supabase.rpc("create_fiscal_rule_version", {
      requested_regime_id: regimeId,
      requested_scope: scope,
      requested_valid_from: String(form.get("valid_from") ?? ""),
      requested_age_threshold_months: optionalNumber(form, "age_threshold_months"),
      requested_ir_rate_before: optionalNumber(form, "ir_rate_before", 100),
      requested_ir_rate_after: optionalNumber(form, "ir_rate_after", 100),
      requested_ps_rate_before: optionalNumber(form, "ps_rate_before", 100),
      requested_ps_rate_after: optionalNumber(form, "ps_rate_after", 100),
      requested_ir_base_type: base("ir_base_type"),
      requested_ps_base_type: base("ps_base_type"),
      requested_ir_allowance_amount: optionalNumber(form, "ir_allowance_amount"),
      requested_ir_allowance_scope: String(form.get("ir_allowance_scope") ?? "") || null,
      requested_parameters: {},
      requested_description: String(form.get("description") ?? "").trim(),
      requested_source: String(form.get("source") ?? "").trim(),
      requested_source_title: String(form.get("source_title") ?? "").trim(),
      requested_verified_on: String(form.get("verified_on") ?? ""),
    });
    if (result.error) return { status: "error", message: "La nouvelle version fiscale n’a pas pu être enregistrée." };
  } catch (error) {
    return { status: "error", message: error instanceof Error ? error.message : "Valeurs fiscales invalides." };
  }
  revalidatePath("/settings"); revalidatePath("/reports");
  return { status: "success", message: "Nouvelle version fiscale enregistrée." };
}

export async function setFiscalPreferenceAction(_state: FiscalActionState, form: FormData): Promise<FiscalActionState> {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active") return { status: "error", message: "Connectez-vous avec un compte actif." };
  const regimeId = String(form.get("fiscal_regime_id") ?? "");
  if (!isUuid(regimeId)) return { status: "error", message: "Régime fiscal invalide." };
  if ((await getFiscalSettingsAvailability(current.profile.auth_user_id, true)).status !== "available") {
    return { status: "error", message: "Fiscalité indisponible. Aucune modification n’a été enregistrée." };
  }
  const supabase = await createClient();
  const result = await supabase.rpc("set_fiscal_rule_preference", { requested_regime_id: regimeId, requested_use_personal: form.get("use_personal") === "true" });
  if (result.error) return { status: "error", message: "La préférence fiscale n’a pas pu être modifiée." };
  revalidatePath("/settings"); revalidatePath("/reports");
  return { status: "success", message: form.get("use_personal") === "true" ? "Personnalisation activée." : "Règle standard restaurée." };
}
