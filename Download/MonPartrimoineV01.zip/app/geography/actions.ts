"use server";
import {getCurrentProfile} from "@/lib/auth/profile";
import {createClient} from "@/lib/supabase/server";
import {isContractInUserScope} from "@/lib/contracts/contract-scope";
import {revalidatePath} from "next/cache";
type Review={token:string;previous:{countryId:string|null;effectiveOn:string|null}|null;observation:{id:string;countryId:string|null;effectiveOn:string|null}};
export type LocationState={status:"idle"|"preview"|"success"|"error";message?:string;review?:Review};
export async function saveLocation(_state:LocationState,form:FormData):Promise<LocationState>{
 const current=await getCurrentProfile();if(current.status!=="active")return {status:"error",message:"Session non autorisée."};
 const uuid=/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
 const p_kind=String(form.get("kind")),p_target=String(form.get("target")),p_observation=String(form.get("observation")),p_date=String(form.get("date")??"")||null,p_country=String(form.get("country")??"")||null;
 if(p_kind==="contract"&&!isContractInUserScope(p_target))return {status:"error",message:"Contrat inaccessible."};
 if(!["asset","contract"].includes(p_kind)||![p_target,p_observation].every(v=>uuid.test(v))||(p_country&&!uuid.test(p_country))||(p_date&&!/^\d{4}-\d{2}-\d{2}$/.test(p_date)))return {status:"error",message:"Pays, identité ou date invalide."};
 const client=await createClient(),params={p_kind,p_target,p_observation,p_date,p_country};
 if(form.get("phase")!=="confirm"){
  const result=await client.rpc("preview_patrimonial_location",params);
  if(result.error)return {status:"error",message:result.error.code==="23505"?"Cette date est déjà occupée : choisissez l’entrée à corriger dans l’historique.":"Aperçu impossible : vérifiez le pays et la date."};
  return {status:"preview",review:result.data as Review};
 }
 if(form.get("confirm")!=="on")return {status:"error",message:"Confirmez l’aperçu avant l’enregistrement."};
 const result=await client.rpc("save_patrimonial_location",{...params,p_token:String(form.get("token")??"")});
 if(result.error)return {status:"error",message:["40001","40P01"].includes(result.error.code)?"État modifié depuis l’aperçu : rechargez puis vérifiez de nouveau.":"Localisation non enregistrée. Rechargez et vérifiez les informations."};
 revalidatePath("/contracts/[id]","page");
 for(const path of ["/","/assets","/contracts","/patrimony","/reports",`/geography/${p_kind}/${p_target}`])revalidatePath(path);
 return {status:"success",message:"Localisation enregistrée ; historique conservé. Aucune valeur financière modifiée."};
}
