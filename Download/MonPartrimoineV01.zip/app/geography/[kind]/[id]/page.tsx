import Link from "next/link";
import {notFound,redirect} from "next/navigation";
import {getPageProfile} from "@/lib/auth/render-context";
import {createClient} from "@/lib/supabase/server";
import {asSettingsRecord} from "@/lib/settings/settings-core";
import {readThemePreference} from "@/lib/theme/theme-core";
import {countryDisplayName} from "@/lib/assets/country-display";
import {locationHistory} from "@/lib/geography/location-history";
import {isContractInUserScope} from "@/lib/contracts/contract-scope";
import {LocationManager} from "../../location-manager";
export const dynamic="force-dynamic";
export default async function LocationPage({params}:{params:Promise<{kind:string;id:string}>}){
 const {current,documents}=await getPageProfile();if(current.status==="unauthenticated")redirect("/login");if(current.status!=="active")redirect("/");
 const {kind,id}=await params;if(!["asset","contract"].includes(kind)||!/^[0-9a-f-]{36}$/i.test(id)||kind==="contract"&&!isContractInUserScope(id))notFound();
 const client=await createClient();const target=kind==="asset"?await client.from("assets").select("id,name,metadata").eq("id",id).eq("owner_user_id",current.profile.auth_user_id).eq("asset_type_code","real_estate").maybeSingle():await client.from("contracts").select("id,name,metadata,envelope_types(code)").eq("id",id).eq("user_id",current.profile.auth_user_id).maybeSingle();
 if(target.error||!target.data)notFound();
 if(kind==="contract"){const t=target.data as unknown as {metadata?:Record<string,unknown>;envelope_types:{code:string}|{code:string}[]};const code=(Array.isArray(t.envelope_types)?t.envelope_types[0]:t.envelope_types)?.code;if(["pea","cto","pea_pme","compte_titres","immobilier"].includes(code)||t.metadata?.property_replaced_by)notFound();}
 const countries=await client.from("exposure_countries").select("id,name,is_active,code,region_code").neq("code","unspecified").order("name");const regions=await client.from("geographic_regions").select("code,is_active");if(countries.error||regions.error)throw Error("Référentiel pays indisponible");
 return <div data-theme={readThemePreference(asSettingsRecord(documents.interface_preferences))} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]"><main className="mx-auto grid max-w-4xl gap-6 px-4 py-8"><Link className="text-[var(--app-gold)] underline" href={kind==="asset"?"/assets":"/contracts"}>Retour {kind==="asset"?"aux actifs":"aux contrats"}</Link><h1 className="text-2xl font-bold">{kind==="asset"?"Pays de situation du bien":"Pays de rattachement du contrat"} · {target.data.name}</h1><LocationManager kind={kind} target={id} history={locationHistory(target.data.metadata)} countries={(countries.data??[]).map(c=>({...c,name:countryDisplayName(c.name),is_active:c.is_active&&Boolean(regions.data?.find(r=>r.code===c.region_code)?.is_active)}))}/></main></div>;
}
