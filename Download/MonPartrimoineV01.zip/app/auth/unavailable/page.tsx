import { AuthShell } from "@/app/components/auth-shell";

export const metadata = {
  title: "Connexion indisponible — MonPatrimoine",
  robots: { index: false, follow: false },
};

export default function AuthUnavailablePage() {
  return (
    <AuthShell
      title="Connexion indisponible"
      description="La connexion est indisponible pour le moment. Réessayez dans quelques instants."
    >
      {/* A full GET retries Auth even when the client router cached this page. */}
      <form action="/" method="get">
        <button type="submit" className="settings-primary-button">Réessayer</button>
      </form>
    </AuthShell>
  );
}
