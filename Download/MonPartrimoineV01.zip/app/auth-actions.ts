"use server";

import { headers } from "next/headers";
import { redirect } from "next/navigation";

import {
  AUTH_SERVICE_ERROR_MESSAGE,
  authenticateWithIdentifier,
  INVALID_CREDENTIALS_MESSAGE,
  performLogout,
  RECOVERY_RESPONSE_MESSAGE,
  requestRecoveryWithIdentifier,
  type AuthActionState,
} from "@/lib/auth/flow-core";
import { resolveNicknameToAuthEmail } from "@/lib/auth/flow";
import { getCurrentProfile } from "@/lib/auth/profile";
import { createClient } from "@/lib/supabase/server";

export async function loginAction(
  _state: AuthActionState,
  formData: FormData,
): Promise<AuthActionState> {
  const identifier = String(formData.get("identifier") ?? "");
  const password = String(formData.get("password") ?? "");

  let authenticated = false;
  try {
    const supabase = await createClient();
    authenticated = await authenticateWithIdentifier(identifier, password, {
      resolveNickname: resolveNicknameToAuthEmail,
      signIn: async (email, exactPassword) => {
        const { error } = await supabase.auth.signInWithPassword({
          email,
          password: exactPassword,
        });
        if (error) return false;
        const { data: authorized, error: accessError } = await supabase.rpc("is_authorized_user");
        if (accessError || authorized !== true) {
          await supabase.auth.signOut();
          if (accessError) throw new Error("Application access could not be verified.");
          return false;
        }
        return true;
      },
      hasProfile: async () => {
        const result = await getCurrentProfile();
        return result.status === "active";
      },
      signOut: async () => {
        await supabase.auth.signOut();
      },
    });
  } catch {
    return { status: "error", message: AUTH_SERVICE_ERROR_MESSAGE };
  }

  if (!authenticated) {
    return { status: "error", message: INVALID_CREDENTIALS_MESSAGE };
  }

  redirect("/");
}

function getRequestOrigin(requestHeaders: Headers) {
  const configured = process.env.NEXT_PUBLIC_SITE_URL?.trim();
  if (configured) return new URL(configured).origin;

  if (process.env.NODE_ENV === "production") {
    throw new Error("Application URL is unavailable.");
  }

  const host = requestHeaders.get("x-forwarded-host") ?? requestHeaders.get("host");
  if (!host || !/^(localhost|127\.0\.0\.1)(:\d+)?$/.test(host)) {
    throw new Error("Application URL is unavailable.");
  }
  const protocol = requestHeaders.get("x-forwarded-proto") ?? "http";
  return `${protocol}://${host}`;
}

export async function forgotPasswordAction(
  _state: AuthActionState,
  formData: FormData,
): Promise<AuthActionState> {
  const identifier = String(formData.get("identifier") ?? "");

  try {
    const supabase = await createClient();
    const origin = getRequestOrigin(await headers());
    await requestRecoveryWithIdentifier(identifier, {
      resolveNickname: resolveNicknameToAuthEmail,
      requestReset: async (email) => {
        await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: `${origin}/auth/callback?next=/reset-password`,
        });
      },
    });
  } catch {
    // Recovery always returns the same response, including technical failures.
  }

  return { status: "success", message: RECOVERY_RESPONSE_MESSAGE };
}

export async function resetPasswordAction(
  _state: AuthActionState,
  formData: FormData,
): Promise<AuthActionState> {
  const password = String(formData.get("password") ?? "");
  const confirmation = String(formData.get("confirmation") ?? "");

  if (!password || password !== confirmation) {
    return {
      status: "error",
      message: "Les mots de passe ne correspondent pas.",
    };
  }

  try {
    const supabase = await createClient();
    const { data: authorized, error: accessError } = await supabase.rpc("is_authorized_user");
    if (accessError || authorized !== true) return { status: "error", message: INVALID_CREDENTIALS_MESSAGE };
    const { error } = await supabase.auth.updateUser({ password });
    if (error) {
      return {
        status: "error",
        message: "Le mot de passe n’a pas pu être mis à jour.",
      };
    }
    await supabase.auth.signOut();
  } catch {
    return { status: "error", message: AUTH_SERVICE_ERROR_MESSAGE };
  }

  redirect("/login?password=updated");
}

export async function logoutAction() {
  const supabase = await createClient();
  await performLogout(() => supabase.auth.signOut());
  redirect("/login");
}
