'use server';
import { analysisService } from '@/lib/ai/analysis-server';
import { analysisErrorMessage } from '@/lib/ai/analysis-service';
import { revalidatePath } from 'next/cache';
import { changeSharedObjectiveHistory, changeInputHistory } from '@/lib/ai/input-history-server';
import { InputHistoryError } from '@/lib/ai/input-history';

export async function prepareAnalysis(selection: string[], question = '', scopeMode: 'all' | 'selection' = 'selection', additionalInformation = '', expectedObjectiveRevision?: number) {
  try {
    const { id } = await analysisService.prepare(selection, question, scopeMode, additionalInformation, expectedObjectiveRevision);
    return { ok: true as const, prepared: { id } };
  }
  catch (error) { return { ok: false as const, message: analysisErrorMessage(error) }; }
}
export async function manualAnalysisPrompt(id: string, selection: string[], question = '') {
  try { return { ok: true as const, prompt: await analysisService.manualPrompt(id, selection, question) }; }
  catch (error) { return { ok: false as const, message: analysisErrorMessage(error) }; }
}
export async function saveAnalysisInput(field: unknown, text: unknown, submission: unknown, expectedRevision?: number | null) {
  try {
    if(field==='additionalInformation') {
      const result=await changeSharedObjectiveHistory('save',submission,text,expectedRevision);
      revalidatePath('/objectives');revalidatePath('/ai');
      return {ok:true as const,entry:result.entry!,revision:result.revision};
    }
    return {ok:true as const,entry:(await changeInputHistory('save',field,submission,text))!,revision:undefined};
  } catch(error) {return {ok:false as const,message:error instanceof InputHistoryError?error.message:'Enregistrement impossible. Votre saisie est conservée.'};}
}
export async function deleteAnalysisInput(field: unknown, id: unknown, confirmed: boolean, expectedRevision?: number | null) {
  try {
    if(field==='additionalInformation') {
      const result=await changeSharedObjectiveHistory('delete',id,null,expectedRevision,confirmed===true);
      revalidatePath('/objectives');revalidatePath('/ai');
      return {ok:true as const,revision:result.revision};
    }
    await changeInputHistory('delete',field,id,undefined,confirmed===true);
    return {ok:true as const,revision:undefined};
  } catch(error) {return {ok:false as const,message:error instanceof InputHistoryError?error.message:'Suppression impossible. L’entrée reste conservée ; rechargez puis réessayez.'};}
}
export async function discardAnalysis(id: string) {
  try { await analysisService.discard(id); return { ok: true as const }; }
  catch { return { ok: false as const }; }
}

export async function renameAnalysisInput(field:unknown,id:unknown,title:unknown,previousTitle:unknown){
 try {const {renameInputHistory}=await import('@/lib/ai/input-history-server');const entry=await renameInputHistory(field,id,title,previousTitle);revalidatePath('/ai');revalidatePath('/objectives');return {ok:true as const,entry};}
 catch(error){return {ok:false as const,message:error instanceof InputHistoryError?error.message:'Renommage non confirmé. Votre saisie est conservée.'};}
}
