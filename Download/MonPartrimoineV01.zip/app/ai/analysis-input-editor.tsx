'use client';

import { useRef, useState } from 'react';
import { DisclosureCard } from '@/app/components/creation-disclosure';
import { FieldHelp } from '@/app/settings/field-help';
import { GENERAL_OBJECTIVE_LABEL, GENERAL_OBJECTIVE_HELP, inputHistoryDate, type AnalysisInputEntry, type AnalysisInputField } from '@/lib/ai/input-history';
import { analysisInputLength, MAX_ANALYSIS_INPUT_LENGTH, ANALYSIS_INPUT_ERROR, validateAnalysisInputs } from '@/lib/ai/analysis-inputs';
import { HistoryEntryTitle } from './history-entry-title';
import { renameAnalysisInput, deleteAnalysisInput, saveAnalysisInput } from './actions';

export function AnalysisInputEditor({ field, value, onChange, initialEntries = [], initialRevision, heading = false, onRevisionChange }: {
  field: AnalysisInputField; value: string; onChange: (text: string) => void; initialEntries?: AnalysisInputEntry[]; initialRevision?: number; heading?: boolean; onRevisionChange?: (revision:number) => void;
}) {
  const [revision, setRevision] = useState<number | null>(initialRevision ?? null);
  const submission = useRef<{id:string;text:string} | null>(null);
  const [entries, setEntries] = useState(initialEntries);
  const [busy, setBusy] = useState<'save' | 'delete' | null>(null);
  const pending = useRef(false);
  const [message, setMessage] = useState('');
  const [failed, setFailed] = useState(false);
  const [removing, setRemoving] = useState<AnalysisInputEntry | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const trigger = useRef<HTMLButtonElement | null>(null);
  const historyToggle = useRef<HTMLElement | null>(null);
  const id = field === 'question' ? 'ai-question' : 'ai-additional-information';
  const label = field === 'question' ? 'Demande à l’IA' : GENERAL_OBJECTIVE_LABEL;
  const help = field === 'question' ? 'Indiquez ce que vous souhaitez analyser. Sans question, l’IA étudiera la répartition, les concentrations et les limites du patrimoine sélectionné.' : GENERAL_OBJECTIVE_HELP;
  function cancel() { setRemoving(null); setConfirmed(false); trigger.current?.focus(); }
  async function save() {
    if (pending.current || field==='question' && !value.trim()) return;
    try { validateAnalysisInputs(field === 'question' ? value : '', field === 'additionalInformation' ? value : ''); }
    catch { setFailed(true); setMessage(ANALYSIS_INPUT_ERROR); return; }
    pending.current = true; setBusy('save'); setMessage(''); setFailed(false);
    try {
      if (!submission.current || submission.current.text !== value) submission.current={id:crypto.randomUUID(),text:value};
      const result = await saveAnalysisInput(field, value, submission.current.id, revision);
      if (!result.ok) { setFailed(true); setMessage(result.message); return; }
      if(result.revision!==undefined){setRevision(result.revision);onRevisionChange?.(result.revision);}
      submission.current=null;
      setEntries(old => [result.entry, ...old.filter(e => e.id !== result.entry.id)]);
      setMessage('Entrée enregistrée.');
    } catch { setFailed(true); setMessage('Enregistrement non confirmé. Votre saisie est conservée ; rechargez l’historique avant de réessayer.'); }
    finally { pending.current = false; setBusy(null); }
  }
  async function remove() {
    if (pending.current || !removing || !confirmed) return;
    const entry = removing;
    pending.current = true; setBusy('delete'); setMessage(''); setFailed(false);
    try {
      const result = await deleteAnalysisInput(field, entry.id, true, revision);
      if (!result.ok) { setFailed(true); setMessage(result.message); return; }
      if(result.revision!==undefined){setRevision(result.revision);onRevisionChange?.(result.revision);}
      setEntries(old => old.filter(e => e.id !== entry.id));
      setRemoving(null); setConfirmed(false); setMessage('Entrée supprimée. Le texte affiché est conservé.');
      historyToggle.current?.focus();
    } catch { setFailed(true); setMessage('Suppression non confirmée. L’entrée reste affichée ; rechargez puis réessayez.'); }
    finally { pending.current = false; setBusy(null); }
  }
  return <div className={`${heading ? "" : "mt-4 "}grid min-w-0 gap-2 text-sm`}>
    <div className="ai-input-help relative flex items-center gap-2">{heading ? <h2 className="settings-card-title"><label htmlFor={id}>{label}</label></h2> : <label htmlFor={id}>{label}</label>}<FieldHelp id={`${id}-help`} label={label}>{help}</FieldHelp></div>
    <textarea id={id} className="settings-input w-full" rows={3} style={{ minHeight: 96 }} aria-invalid={analysisInputLength(value) > MAX_ANALYSIS_INPUT_LENGTH} value={value} onChange={e => onChange(e.target.value)} />
    {analysisInputLength(value) > MAX_ANALYSIS_INPUT_LENGTH && <p role="alert" className="text-red-500">{ANALYSIS_INPUT_ERROR}</p>}
    <button type="button" className="settings-edit-action justify-self-start" disabled={busy !== null || field==='question' && !value.trim()} onClick={() => void save()}>{busy === 'save' ? 'Enregistrement…' : 'Enregistrer'}</button>
    {!!value && !entries.some(e => e.text === value) && <p className="text-xs text-[var(--app-muted)]">Texte non enregistré dans l’historique.</p>}
    <details>
      <summary ref={historyToggle} className="min-h-11 cursor-pointer py-3 font-semibold">Versions enregistrées</summary>
      {entries.length ? <ul className="grid gap-2 py-2">{entries.map(entry => <li key={entry.id} className="flex min-w-0 items-start gap-2">
        <HistoryEntryTitle title={entry.title??(inputHistoryDate(entry.recordedAt)+(entry.origin==='strategy_transition'?' — reprise de Stratégie (date d’origine inconnue)':''))} disabled={busy!==null} onOpen={()=>onChange(entry.text)} onRename={async title=>{const result=await renameAnalysisInput(field,entry.id,title,entry.title??null);if(!result.ok)return result.message;setEntries(old=>old.map(e=>e.id===entry.id?{...e,title:result.entry.title}:e));return null;}}/>
        <button type="button" className="settings-edit-action min-h-11 min-w-11 shrink-0" disabled={busy !== null} aria-label={`Supprimer l’entrée du ${inputHistoryDate(entry.recordedAt)} — ${label}`} onClick={e => { trigger.current = e.currentTarget; setRemoving(entry); setConfirmed(false); }}>×</button>
      </li>)}</ul> : <p className="py-2 text-xs text-[var(--app-muted)]">Aucune entrée enregistrée.</p>}
    </details>
    {removing && <DisclosureCard title="Confirmer la suppression" open onToggle={() => { if (!busy) cancel(); }}>
      <p>Supprimer l’entrée du {inputHistoryDate(removing.recordedAt)} ? Le texte affiché dans le champ sera conservé.</p>
      <label className="mt-3 flex min-h-11 items-center gap-3"><input type="checkbox" checked={confirmed} disabled={busy !== null} onChange={e => setConfirmed(e.target.checked)} />Je confirme la suppression de cette entrée.</label>
      <div className="mt-3 flex flex-wrap gap-3"><button type="button" className="settings-edit-action" disabled={busy !== null || !confirmed} onClick={() => void remove()}>Supprimer l’entrée</button><button type="button" autoFocus className="settings-edit-action" disabled={busy !== null} onClick={cancel}>Annuler</button></div>
    </DisclosureCard>}
    <p role="status" aria-live="polite" className={failed ? 'text-red-500' : 'text-[var(--app-muted)]'}>{message}</p>
  </div>;
}
