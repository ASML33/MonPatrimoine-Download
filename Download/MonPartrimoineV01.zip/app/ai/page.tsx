import { redirect } from "next/navigation";

import { DashboardHeader } from "@/app/components/dashboard-header";
import { getCurrentProfile } from "@/lib/auth/profile";
import { getCurrentProfileSettings } from "@/lib/settings/profile-settings";
import {
  asSettingsRecord,
  canAccessSettings,
  readProfileSettings,
} from "@/lib/settings/settings-core";
import { readThemePreference } from "@/lib/theme/theme-core";
import { getAnalysisContractChoices } from '@/lib/ai/analysis-server';
import { AnalysisWorkbench } from './analysis-workbench';
import { readSharedObjective, latestAnalysisInputs, readInputHistories } from '@/lib/ai/input-history';

export const dynamic = "force-dynamic";

export default async function AiPage() {
  const current = await getCurrentProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (!canAccessSettings(current.status)) redirect("/");
  if (current.status !== "active") redirect("/");

  const documents = await getCurrentProfileSettings();
  const interfacePreferences = asSettingsRecord(documents.interface_preferences);
  const theme = readThemePreference(interfacePreferences);
  const settings = readProfileSettings(documents);
  const contracts = await getAnalysisContractChoices(current.profile.auth_user_id);
  const shared = readSharedObjective(documents.preferences);
  const histories = readInputHistories(documents.preferences);

  const showFinancialBackup = process.env.XLSX_FINANCIAL_MANUAL_ENABLED === "true"
    && current.profile.auth_user_id === process.env.XLSX_FINANCIAL_OWNER_ID;

  return (
    <div
      data-theme={theme}

      className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]"
    >
      <DashboardHeader
        nickname={current.profile.nickname}
        displayName={settings.displayName}
        theme={theme}


      />

      <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
        <h1 className="text-3xl font-bold sm:text-4xl">Intelligence Artificielle</h1>
        <p className="mt-3 text-sm leading-6 text-[var(--app-muted)] sm:text-base">
          Préparez une photographie de votre patrimoine et un prompt personnalisé pour l’analyser avec l’IA de votre choix.
        </p>
        <AnalysisWorkbench contracts={contracts} initialInputs={latestAnalysisInputs(histories)} initialHistories={histories} sharedObjectiveRevision={shared.revision} showFinancialBackup={showFinancialBackup} />
      </main>
    </div>
  );
}
