'use client';

import { useEffect, useRef, useState } from 'react';

export function PromptCopyButton({ prompt, disabled = false }: { prompt: string; disabled?: boolean }) {
  const [feedback, setFeedback] = useState<{ attempt: number; success: boolean } | null>(null);
  const attempt = useRef(0);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => {
    attempt.current++;
    if (timer.current !== null) clearTimeout(timer.current);
  }, []);

  async function copy() {
    if (disabled || !prompt.trim()) return;
    const current = ++attempt.current;
    if (timer.current !== null) clearTimeout(timer.current);
    timer.current = null;
    setFeedback(null);
    let success = false;
    try {
      await navigator.clipboard.writeText(prompt);
      success = true;
    } catch {
      // A missing clipboard API or a denied write is a failure, never a success.
    }
    if (attempt.current !== current) return;
    setFeedback({ attempt: current, success });
    timer.current = setTimeout(() => {
      if (attempt.current === current) {
        setFeedback(null);
        timer.current = null;
      }
    }, 2000);
  }

  return <div className="w-full">
    <button type="button" className="settings-primary-button" disabled={disabled || !prompt.trim()} onClick={copy}>Copier le prompt</button>
    <p role="status" aria-live="polite" aria-atomic="true" className={`mt-2 min-h-5 text-sm ${feedback?.success ? 'text-green-600' : 'text-red-500'}`}>
      {feedback && <span key={feedback.attempt}>{feedback.success ? 'Prompt copié dans le presse-papiers' : 'Erreur lors de la copie'}</span>}
    </p>
  </div>;
}
