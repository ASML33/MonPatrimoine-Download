'use client';
import { FinancialBackup } from '@/app/backups/financial-backup';
import { PromptCopyButton } from './prompt-copy-button';
import { AnalysisInputEditor } from './analysis-input-editor';
import { DisclosureCard } from '@/app/components/creation-disclosure';
import { emptyInputHistories, type AnalysisInputHistories } from '@/lib/ai/input-history';
import type { AnalysisInputs } from '@/lib/ai/analysis-inputs';
import { useLayoutEffect, useRef, useState } from 'react';
import type { AnalysisContractChoice } from '@/lib/ai/analysis-service';
import { prepareAnalysis, manualAnalysisPrompt, discardAnalysis } from './actions';

const situationBlock = /(^|\n)<situation_et_objectifs>\r?\n([\s\S]*?)\r?\n<\/situation_et_objectifs>(?=\r?\n|$)/;

type PromptReplacement = { text: string; preparationId: string; revision: number };
export function AnalysisWorkbench({ contracts, initialInputs = { question: '', additionalInformation: '' }, initialHistories = emptyInputHistories(), sharedObjectiveRevision = 0, showFinancialBackup = false }: { contracts: AnalysisContractChoice[]; initialInputs?: AnalysisInputs; initialHistories?: AnalysisInputHistories; sharedObjectiveRevision?: number; showFinancialBackup?: boolean }) {
  const [objectiveRevision,setObjectiveRevision]=useState(sharedObjectiveRevision);
  const [selection, setSelection] = useState<string[]>([]), [prepared, setPrepared] = useState<{ id: string } | null>(null);
  const [question, setQuestion] = useState(initialInputs.question);
  const [validated, setValidated] = useState<{ ids: string[]; mode: 'all' | 'selection' } | null>(null);
  const allSelected = contracts.length > 0 && contracts.every(c => selection.includes(c.id));
  const selectionValidated = validated !== null && selection.length > 0 && validated.ids.length === selection.length && validated.ids.every(id => selection.includes(id) && contracts.some(c => c.id === id)) && (validated.mode !== 'all' || allSelected);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false), [manual, setManual] = useState(false);
  const [additionalInformation, setAdditionalInformation] = useState(initialInputs.additionalInformation);
  const [promptDraft, setPromptDraft] = useState('');
  const [promptPreparationId, setPromptPreparationId] = useState('');
  const [replacement, setReplacement] = useState<PromptReplacement | null>(null), [replacementConfirmed, setReplacementConfirmed] = useState(false);
  const currentPrompt = useRef({ text: '', generated: null as string | null });
  const promptArea = useRef<HTMLTextAreaElement | null>(null), promptTrigger = useRef<HTMLButtonElement | null>(null);
  const revision = useRef(0), pending = useRef(false);
  const focusAcceptedPrompt = useRef(false);
  const selectionCurrent = useRef(selectionValidated);
  useLayoutEffect(() => { selectionCurrent.current = selectionValidated; }, [selectionValidated]);
  const promptVisible = manual && selectionValidated && prepared !== null
    && promptPreparationId === prepared.id && replacement === null;
  const situation = situationBlock.exec(promptDraft)?.[2]?.trim();
  const reviewSituation = !!situation && situation !== 'Non renseigné.';

  useLayoutEffect(() => {
    if (promptVisible && focusAcceptedPrompt.current) {
      focusAcceptedPrompt.current = false;
      promptArea.current?.focus();
    }
  }, [promptVisible]);

  function changePromptDraft(text: string) {
    currentPrompt.current.text = text;
    setPromptDraft(text);
    setReplacementConfirmed(false);
  }

  function acceptPrompt(candidate: PromptReplacement) {
    currentPrompt.current = { text: candidate.text, generated: candidate.text };
    setPromptPreparationId(candidate.preparationId);
    setPromptDraft(candidate.text); setManual(true); setReplacement(null); setReplacementConfirmed(false);
  }
  function cancelReplacement() { setReplacement(null); setReplacementConfirmed(false); promptTrigger.current?.focus(); }
  function invalidate() {
    revision.current++;
    if (prepared) void discardAnalysis(prepared.id).catch(() => {});
    setPrepared(null); setMessage(''); setReplacement(null); setReplacementConfirmed(false);
  }
  function changeSelection(id: string, checked: boolean) { invalidate(); setValidated(null); setSelection(old => checked ? [...old, id] : old.filter(x => x !== id)); }
  async function run() {
    if (pending.current) return;
    if (!selectionValidated || !validated) { setMessage('Validez la sélection des contrats avant de poursuivre.'); return; }
    const version = revision.current; pending.current = true; setBusy(true); setMessage('');
    let freshId: string | undefined;
    try {
      if (prepared) void discardAnalysis(prepared.id).catch(() => {});
      setPrepared(null); setReplacement(null); setReplacementConfirmed(false);
      const preparation = await prepareAnalysis(validated.ids, question, validated.mode, additionalInformation, objectiveRevision);
      if (revision.current !== version || !selectionCurrent.current) { if (preparation.ok) void discardAnalysis(preparation.prepared.id).catch(() => {}); return; }
      if (!preparation.ok) { setMessage(preparation.message); return; }
      const fresh = preparation.prepared;
      freshId = fresh.id;
      const reply = await manualAnalysisPrompt(fresh.id, validated.ids, question);

      if (revision.current !== version || !selectionCurrent.current) { void discardAnalysis(fresh.id).catch(() => {}); return; }
      if (!reply.ok) { void discardAnalysis(fresh.id).catch(() => {}); setMessage(reply.message); return; }
      setPrepared(fresh);
      const candidate = { text: reply.prompt, preparationId: fresh.id, revision: version };

      if (currentPrompt.current.generated !== null && currentPrompt.current.text !== currentPrompt.current.generated) setReplacement(candidate);
      else acceptPrompt(candidate);
    } catch { if (freshId) void discardAnalysis(freshId).catch(() => {}); if (revision.current === version && selectionCurrent.current) setMessage('Communication interrompue. Vos textes restent à l’écran ; aucun enregistrement n’a été demandé. Réessayez.'); }
    finally { pending.current = false; setBusy(false); }
  }
  return <div className="mt-7 grid min-w-0 gap-6">
    <section className="settings-card min-w-0"><h2 className="settings-card-title">1. Choisir les contrats</h2><p className="mt-3 text-sm text-[var(--app-muted)]">Aucun contrat sélectionné par défaut. Validez votre sélection pour personnaliser l’analyse. Toute modification des contrats demande une nouvelle validation et annule la photographie précédente.</p><button type="button" className="settings-edit-action mt-3" disabled={!contracts.length} onClick={() => { invalidate(); setValidated(null); setSelection(allSelected ? [] : contracts.map(c => c.id)); }}>{allSelected ? 'Tout désélectionner' : 'Tout sélectionner'}</button>
      <fieldset className="mt-4 grid gap-2 sm:grid-cols-2"><legend className="sr-only">Contrats à analyser</legend>{contracts.map(c => <label key={c.id} className="flex min-h-11 min-w-0 items-center gap-3"><input type="checkbox" checked={selection.includes(c.id)} onChange={e => changeSelection(c.id, e.target.checked)} /><span className="break-words">{c.label}</span></label>)}</fieldset>{!contracts.length ? <p>Aucun contrat disponible.</p> : null}
      <button type="button" className="settings-primary-button mt-4" disabled={busy || !selection.length} aria-controls="ai-personalization" aria-expanded={selectionValidated} onClick={() => { if (!selection.length || selection.some(id => !contracts.some(c => c.id === id))) return; setValidated({ ids: [...selection], mode: allSelected ? 'all' : 'selection' }); setMessage(''); }}>Valider</button>
      <p className="mt-2 text-sm text-[var(--app-muted)]">{selectionValidated ? 'Sélection validée.' : 'La sélection doit être validée avant de préparer une photographie.'}</p>
    </section>
    <section id="ai-personalization" hidden={!selectionValidated} className="settings-card min-w-0"><h2 className="settings-card-title">2. Personnaliser l’analyse</h2>
      <AnalysisInputEditor field="additionalInformation" value={additionalInformation} onChange={text => { invalidate(); setAdditionalInformation(text); }} initialEntries={initialHistories.additionalInformation} initialRevision={sharedObjectiveRevision} onRevisionChange={next=>{setObjectiveRevision(next);invalidate();}} />
      <AnalysisInputEditor field="question" value={question} onChange={text => { invalidate(); setQuestion(text); }} initialEntries={initialHistories.question} />
      <details className="mt-3"><summary className="min-h-11 cursor-pointer py-3 font-semibold">Remarques</summary><div className="grid gap-3 pb-3 text-sm text-[var(--app-muted)]"><p>La photographie est courante, temporaire et utilisable avec une IA externe choisie par vous. Modifier la demande à l’IA ou le texte « Contexte patrimonial et objectifs » annule sa préparation de deux heures.</p><p>Le champ « Contexte patrimonial et objectifs » est commun avec Stratégie. Enregistrez votre texte pour le retrouver sur l’autre page. La génération utilise les textes affichés sans les enregistrer. La répartition utilise les cibles enregistrées dans Stratégie. Déclarations personnelles incluses dans le prompt ; ne saisissez aucun secret.</p></div></details><div className="mt-4"><button ref={promptTrigger} type="button" className="settings-primary-button" disabled={busy || !selectionValidated} onClick={() => void run()}>{busy ? 'Génération…' : 'Générer le prompt'}</button></div></section>
    {/* Keep the backup mounted after the first prompt so a hidden tile can finish an in-flight save. */}
    {manual && <section hidden={!promptVisible} className="settings-card min-w-0"><h2 className="settings-card-title">3. Prompt pour une IA externe</h2>
      <p className="mt-3 text-sm">MonPatrimoine n’appelle aucun fournisseur pour cette analyse. Vérifiez le prompt avant de le transmettre vous-même à une IA externe. La recherche dépend des capacités réelles du service choisi.</p>
        <div className="mt-5 grid min-w-0 gap-3 border-t border-[var(--app-border)] pt-5"><label htmlFor="ai-manual-prompt" className="text-sm font-medium">Prompt</label><textarea ref={promptArea} id="ai-manual-prompt" aria-describedby="ai-manual-prompt-hint" className="settings-input w-full min-w-0 resize-y font-mono text-xs" style={{ minHeight: 224, paddingBlock: 12 }} rows={10} value={promptDraft} onChange={e => changePromptDraft(e.target.value)} /><p id="ai-manual-prompt-hint" className="text-xs text-[var(--app-muted)]">Texte modifiable uniquement dans cette page, sans enregistrement ni modification de la photographie. Copier utilise exactement le texte affiché.</p>{reviewSituation && <p className="text-sm text-[var(--app-muted)]">
          <strong className="block font-medium">Contexte à relire avant la copie</strong>
          Le contexte peut mentionner des contrats hors sélection. Tu peux modifier le prompt ci-dessus ou corriger le texte dans « Personnaliser l’analyse », puis générer un nouveau prompt.
        </p>}<PromptCopyButton prompt={promptDraft} disabled={busy || !promptVisible} /></div>
      {showFinancialBackup && <FinancialBackup forPrompt selectedContracts={contracts.filter(contract => selection.includes(contract.id))} />}
    </section>}
        {replacement && <DisclosureCard title="Remplacer le prompt modifié ?" open onToggle={cancelReplacement}>
          <p>Le nouveau prompt remplacera vos modifications locales. Annuler conserve votre brouillon local.</p>
          <label className="mt-3 flex min-h-11 items-center gap-3"><input type="checkbox" checked={replacementConfirmed} onChange={e => setReplacementConfirmed(e.target.checked)} />Je confirme le remplacement du prompt modifié.</label>
          <div className="mt-3 flex flex-wrap gap-3"><button type="button" className="settings-edit-action" disabled={!replacementConfirmed} onClick={() => { if (!selectionValidated || !replacementConfirmed || revision.current !== replacement.revision || prepared?.id !== replacement.preparationId) return; focusAcceptedPrompt.current = true; acceptPrompt(replacement); }}>Remplacer le prompt</button><button type="button" autoFocus className="settings-edit-action" onClick={cancelReplacement}>Annuler</button></div>
        </DisclosureCard>}
    {message ? <p role="status" aria-live="polite" className="settings-card break-words text-sm">{message}</p> : null}
  </div>;
}
