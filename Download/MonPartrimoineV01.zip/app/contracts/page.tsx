import { redirect } from "next/navigation";
import { DashboardHeader } from "@/app/components/dashboard-header";
import { getPageProfile } from "@/lib/auth/render-context";
import { asSettingsRecord, readProfileSettings } from "@/lib/settings/settings-core";
import { readThemePreference } from "@/lib/theme/theme-core";
import { getManagedContracts } from "@/lib/contracts/contracts";
import { ContractForms } from "./contract-forms";

export const dynamic = "force-dynamic";

export default async function ContractsPage() {
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (current.status !== "active") redirect("/");
  const preferences = asSettingsRecord(documents.interface_preferences);
  const theme = readThemePreference(preferences);
  const settings = readProfileSettings(documents);
  const data = await getManagedContracts(current.profile.auth_user_id).catch(() => null);
  return <div data-theme={theme} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]">
    <DashboardHeader nickname={current.profile.nickname} displayName={settings.displayName} theme={theme} />
    <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
      <header className="max-w-3xl">
        <h1 className="text-3xl font-bold sm:text-4xl">Contrats</h1>
        <p className="mt-3 text-sm leading-6 text-[var(--app-muted)] sm:text-base">Gérez vos contrats, y compris les contrats vides et inactifs.</p>
      </header>
      {data ? <ContractForms {...data} /> : <p role="alert" className="mt-8 text-red-500">Les contrats sont indisponibles. Réessayez ultérieurement.</p>}
    </main>
  </div>;
}
