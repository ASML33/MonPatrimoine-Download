"use server";

import { createHash } from "node:crypto";
import { isContractInUserScope } from "@/lib/contracts/contract-scope";
import { revalidatePath } from "next/cache";
import { getCurrentProfile } from "@/lib/auth/profile";
import { createClient } from "@/lib/supabase/server";
import { isUuid } from "@/lib/assets/asset-core";
import { contractError, validateContractFields, validateContractFiscalFields, type ContractActionState } from "@/lib/contracts/contract-core";
import { envelopeNetMode } from "@/lib/fiscal/envelope-policy";
import { colorWrite } from "@/lib/ui/color-provenance";

export async function saveContractAction(_state: ContractActionState, form: FormData): Promise<ContractActionState> {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active") return { status: "error", message: "Connectez-vous avec un compte actif." };
  const userId = current.profile.auth_user_id;
  const operation = String(form.get("operation") ?? "");
  if (operation !== "create" && !isContractInUserScope(String(form.get("id") ?? ""))) return { status: "error", message: "Contrat indisponible." };
  const id = String(form.get("id") ?? "");
  const supabase = await createClient();
  let error: { code?: string } | null = null;
  let createdContractId: string | undefined;

  if (operation === "create" || operation === "update") {
    if (operation === "update" && !isUuid(id)) return { status: "error", message: "Contrat invalide." };
    let values;
    try { values = { ...validateContractFields(form), ...validateContractFiscalFields(form) }; }
    catch (e) { return { status: "error", message: e instanceof Error ? e.message : "Valeurs invalides." }; }
    const envelopeTypeId = String(form.get("envelope_type_id") ?? "");
    if (!isUuid(envelopeTypeId)) return { status: "error", message: "Choisissez un type d’enveloppe." };
    if(values.fiscal_regime_id||form.get('fiscal_rule_id')||form.get('fiscal_assignment_on'))return {status:'error',message:'La fiscalité se configure désormais dans Enveloppes.'};
    if(operation==='create'){const capability=await supabase.rpc('get_envelopes');if(capability.error||![1,2].includes(capability.data?.version))return {status:'error',message:'Création indisponible : configuration Enveloppes non installée. Référence REF-SQL-DEPENDENCY.'};}
    if (form.has("pea_pme_standard_confirmed") || envelopeTypeId === "71000000-0000-0000-0000-000000000009") {
      values = { ...values, pea_pme_standard_confirmed: form.get("pea_pme_standard_confirmed") === "on" };
    }
    const { color, ...fields } = values;
    const writeValues = { ...fields, ...colorWrite(color, form.get("color_changed") === "true", operation === "create") };
    if (operation === "create") {
      const type = await supabase.from("envelope_types").select("id,code,is_active")
        .eq("id", envelopeTypeId).eq("is_active", true).maybeSingle();
      if (type.error || !type.data) return { status: "error", message: "Ce type d’enveloppe n’est pas accessible." };
      if (envelopeNetMode(type.data.code) === "calculated" && !values.fiscal_started_on)
        return { status: "error", message: "La date de départ de l’ancienneté fiscale est obligatoire." };
      const requestId = String(form.get("creation_id") ?? "");
      if (!isUuid(requestId)) return { status: "error", message: "Rechargez le formulaire de création." };
      const empty = form.get("initial_value_state") === "empty";
      const initialDate = String(form.get("initial_value_on") ?? "");
      if (empty && (type.data.code !== "assurance_vie" || values.currency_code !== "EUR" || !/^\d{4}-\d{2}-\d{2}$/.test(initialDate)
        || !Number.isFinite(Date.parse(initialDate)) || new Date(initialDate).toISOString().slice(0,10) !== initialDate
        || Boolean(values.opened_on && initialDate < values.opened_on)))
        return { status: "error", message: "Confirmez une date valide de valorisation nulle pour une assurance-vie en EUR." };
      const fingerprint = createHash("sha256").update(JSON.stringify({ ...writeValues, envelope_type_id: envelopeTypeId, ...(empty ? { initialValueOn: initialDate } : {}) })).digest("hex");
      const initialized = empty ? await supabase.rpc("create_empty_life_insurance_contract", { requested_id: requestId, requested_fields: writeValues, requested_date: initialDate, requested_receipt: fingerprint }) : null;
      const inserted = initialized ? { data: initialized.error ? null : { id: initialized.data }, error: initialized.error }
        : await supabase.from("contracts").insert({ ...writeValues, id: requestId, envelope_type_id: envelopeTypeId, user_id: userId, is_active: true, metadata: { form_creation_receipt: fingerprint } }).select("id").single();
      error = inserted.error;
      createdContractId = inserted.data?.id;
      if (error?.code === "23505") {
        const prior = await supabase.from("contracts").select("id,metadata").eq("id", requestId).eq("user_id", userId).maybeSingle();
        if (!prior.error && prior.data?.metadata && typeof prior.data.metadata === "object" && !Array.isArray(prior.data.metadata) && prior.data.metadata.form_creation_receipt === fingerprint) {
          error = null;
          createdContractId = prior.data.id;
        }
      }
    } else {
      const { currency_code,fiscal_regime_id: _unchangedRegime, ...mutableValues } = writeValues;
      void _unchangedRegime;
      const updateValues = form.get("currency_locked") === "true" ? mutableValues : { ...mutableValues, currency_code };
      ({ error } = await supabase.from("contracts").update(updateValues)
        .eq("id", id).eq("user_id", userId).select("id").single());
    }
  } else if (["activate", "deactivate", "delete"].includes(operation) && isUuid(id)) {
    if (operation === "delete" && form.get("confirm") !== "on") return { status: "error", message: "Confirmez la suppression." };
    const query = operation === "delete" ? supabase.from("contracts").delete()
      : supabase.from("contracts").update({ is_active: operation === "activate" });
    ({ error } = await query.eq("id", id).eq("user_id", userId).select("id").single());
  } else return { status: "error", message: "Opération invalide." };

  if (error) return { status: "error", message: contractError(error.code) };
  revalidatePath("/contracts");
  if (isUuid(id)) revalidatePath(`/contracts/${id}`);
  revalidatePath("/patrimony");
  revalidatePath("/");
  return { status: "success", message: "Modification enregistrée.", ...(createdContractId ? { createdContractId } : {}) };
}
