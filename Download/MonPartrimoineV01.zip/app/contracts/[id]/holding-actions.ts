"use server";
import { prepareAcquisitionFx } from "@/lib/fx/cto-acquisition-fx";
import { acquisitionDecimal } from "@/lib/contracts/cto-acquisition-input";

import { getCurrentProfile } from "@/lib/auth/profile";
import { createClient } from "@/lib/supabase/server";
import { isContractInUserScope } from "@/lib/contracts/contract-scope";
import { isUuid } from "@/lib/assets/asset-core";
import { revalidatePath } from "next/cache";
import { qualifiedObservation } from "@/lib/patrimony/position-observation-projection";
import type { HistoricalObservation } from "@/lib/patrimony/historical-observations";
import type { PositionObservation, PositionBinding } from "@/lib/contracts/position-observations";
import { linksFlowsToCash } from "@/lib/cash/flow-cash";
import { retainedCtoBrokerCost } from "@/lib/contracts/cto-broker-basis";
export type HoldingState = {
    status: "idle" | "preview" | "success" | "error";
    message?: string;
    review?: {
        token: string;
        contractId: string;
        assetId: string;
        positionId: string;
        observation: PositionObservation;
        destination: boolean;
        dates: {
            date: string;
            status: string;
        }[];
        currentBefore: string;
        currentAfter: string;
    };
};
export async function saveHoldingObservation(_state: HoldingState, form: FormData): Promise<HoldingState> {
    try {
        const user = await getCurrentProfile();
        if (user.status !== "active")
            throw Error("Session requise.");
        const client = await createClient(), contractId = String(form.get("contract_id") ?? ""), positionId = String(form.get("position_id") ?? ""), assetId = String(form.get("asset_id") ?? ""), oid = String(form.get("observation_id") ?? "");
        if (!isUuid(contractId) || !isContractInUserScope(contractId) || !isUuid(assetId) || positionId && !isUuid(positionId) || oid && !isUuid(oid))
            throw Error("Position invalide.");
        if (form.get("intent") === "documented_cost") {
            const request = String(form.get("request_id") ?? "");
            const revision = String(form.get("expected_updated_at") ?? "");
            const date = String(form.get("effective_on") ?? "");
            const amountText = String(form.get("historical_cost_eur") ?? "").trim();
            const cost = amountText ? acquisitionDecimal(amountText, 8) : null;
            const source = String(form.get("historical_cost_source") ?? "").trim();
            if (!positionId || !isUuid(request) || !Number.isFinite(Date.parse(revision)) ||
                !/^\d{4}-\d{2}-\d{2}$/.test(date) || cost === null || !source || source.length > 500)
                throw Error("Indiquez la date, le PRU historique en EUR et sa référence.");
            const saved = await client.rpc("correct_cto_historical_cost", {
                requested_contract: contractId, requested_asset: assetId, requested_position: positionId,
                requested_date: date, expected_position_updated_at: revision, requested_request: request,
                requested_historical_cost_eur: cost, requested_cost_source: source,
            });
            if (saved.error) throw Error(saved.error.code === "40001"
                ? "La position a changé. Rechargez avant de réessayer."
                : "Correction refusée. Vérifiez la date, la preuve et la situation native.");
            for (const path of [`/contracts/${contractId}`, "/contracts", "/reports", "/reports/history", "/patrimony", "/"]) revalidatePath(path);
            return { status: "success", message: "Coût historique EUR documenté enregistré." };
        }
        if (form.has("acquisition_mode")) {
            if (oid) throw Error("Situation CTO invalide.");
            const parent = await client.from("contracts").select("envelope_types(code)").eq("id",contractId).eq("user_id",user.profile.auth_user_id).maybeSingle();
            const envelope = Array.isArray(parent.data?.envelope_types) ? parent.data.envelope_types[0] : parent.data?.envelope_types;
            if (parent.error || !["cto","compte_titres"].includes(envelope?.code ?? "")) throw Error("Ce formulaire est réservé aux actifs CTO.");
            const quantity = acquisitionDecimal(String(form.get("quantity") ?? ""), 8);
            const amountText = String(form.get("acquisition_amount") ?? "").trim();
            const amount = amountText ? acquisitionDecimal(amountText, 28) : null;
            const mode = String(form.get("acquisition_mode") ?? "");
            const changed = String(form.get("acquisition_cost_changed") ?? "");
            const request = String(form.get("request_id") ?? ""), revision = String(form.get("expected_updated_at") ?? ""), date = String(form.get("effective_on") ?? "");
            if (quantity === null || amountText && amount === null || !["total","unit"].includes(mode) || !["yes","no","date"].includes(changed) || !isUuid(request) || (positionId ? !Number.isFinite(Date.parse(revision)) : revision!=="") || !/^\d{4}-\d{2}-\d{2}$/.test(date)) throw Error("Vérifiez la date, la quantité, le montant et la devise. Le brouillon est conservé.");
            const input = {requested_contract:contractId, requested_asset:assetId, requested_position:positionId||null, requested_date:date, requested_quantity:quantity, requested_mode:!positionId||changed==="yes"?mode:changed==="date"?"redate":"preserve", requested_amount:!positionId||changed==="yes"?amount:null, requested_currency:String(form.get("cost_currency")??""), expected_position_updated_at:positionId?revision:null, requested_request:request};
            const prepared = await prepareAcquisitionFx(client,user.profile.auth_user_id,input);
            const saved = prepared.state==="committed"?{data:prepared.result,error:null}:await client.rpc("save_cto_acquisition_action",input);
            if (saved.error) throw Error(saved.error.code==="40001"?"La position a changé. Rechargez sans sauvegarde partielle.":"Enregistrement refusé : vérifiez le montant, la quantité, la date et la devise. Aucune écriture partielle.");
            for (const path of [`/contracts/${contractId}`,"/contracts","/reports","/reports/history","/patrimony","/"]) revalidatePath(path);
            return {status:"success",message:"Situation enregistrée. "+ (prepared.fx?.method==="historical"?"Conversion historique utilisée.":prepared.fx?.method==="last_known"?"Taux de secours utilisé après échec de récupération historique.":prepared.fx?.method==="unavailable"?"Conversion EUR indisponible ; coût natif conservé.":"Coût conservé.")+""};
        }
        const submittedCost=String(form.get("unit_cost")??"").trim().replace(",",".");let retainedCost:string|null=null;
        if(positionId&&/^\d{1,16}\.\d{9,20}$/.test(submittedCost)){
            const saved=await client.from("positions").select("average_cost_per_unit,cost_currency_code,metadata").eq("id",positionId).eq("contract_id",contractId).eq("asset_id",assetId).eq("user_id",user.profile.auth_user_id).maybeSingle();
            if(!saved.error&&saved.data)retainedCost=retainedCtoBrokerCost(saved.data.metadata,saved.data.average_cost_per_unit,saved.data.cost_currency_code,String(form.get("effective_on")??""),submittedCost);
        }
        const decimal = (name: string, optional = false) => { if(name==='unit_cost'&&retainedCost)return retainedCost;const text = String(form.get(name) ?? "").trim(); if (!text && optional)
            return null; if (!/^\d{1,16}([.,]\d{1,8})?$/.test(text))
            throw Error("Quantité et PRU : valeurs positives ou nulles, huit décimales maximum."); return text.replace(",", "."); };
        const params = { requested_contract: contractId, requested_asset: assetId, requested_position: positionId || null, requested_observation: oid || null, requested_date: String(form.get("effective_on") ?? ""), requested_quantity: decimal("quantity"), requested_cost: decimal("unit_cost", true), requested_currency: String(form.get("cost_currency") ?? "") };
        if (!/^\d{4}-\d{2}-\d{2}$/.test(params.requested_date))
            throw Error("Choisissez une date d’effet.");
        const parent = await client.from("contracts").select("envelope_types(code)").eq("id",contractId).eq("user_id",user.profile.auth_user_id).maybeSingle();
        if (parent.error || !parent.data) throw Error("Contrat indisponible.");
        const envelope = Array.isArray(parent.data.envelope_types) ? parent.data.envelope_types[0] : parent.data.envelope_types;
        if (linksFlowsToCash(envelope?.code ?? "")) {
            const request=String(form.get("request_id")??""), revision=String(form.get("expected_updated_at")??"");
            if(!isUuid(request)||positionId&&!Number.isFinite(Date.parse(revision)))throw Error("Rechargez le formulaire avant de réessayer.");
            const saved=await client.rpc("save_securities_position_action",{...params,expected_position_updated_at:positionId?revision:null,requested_request:request});
            if(saved.error)throw Error(saved.error.code==="40001"?"La position a changé. Rechargez sans sauvegarde partielle.":"Enregistrement refusé : vérifiez date, quantité, PRU à deux décimales et droits. Aucune correction partielle.");
            for(const path of [`/contracts/${contractId}`,"/contracts","/reports","/reports/history","/patrimony","/"])revalidatePath(path);
            return {status:"success",message:"Situation enregistrée. Elle remplace les valeurs à partir de sa date d’effet ; sources et inconnus conservés. Aucun flux ni mouvement d’espèces créé."};
        }
        const { data: plan, error } = await client.rpc("preview_position_observation", params);
        if (error || !plan)
            throw Error(error?.code === "40001" ? "La position a changé. Recommencez l’aperçu." : "Aperçu indisponible : vérifiez la date, la devise et les droits d’activité.");
        const dates = (plan.review as {
            date: string;
            protected: boolean;
            captureId: string;
        }[]).map(row => {
            if (row.protected)
                return { date: row.date, status: "Source protégée — inchangée" };
            const binding = (plan.bindings as PositionBinding[]).find(b => b.captureId === row.captureId)!;
            if (binding.restore)
                return { date: row.date, status: "Retour à la capture source conservée" };
            const capture = (plan.captures as HistoricalObservation[]).find(c => c.id === row.captureId)!;
            const result = qualifiedObservation(binding, capture, assetId);
            return { date: row.date, status: result.reason || "BRUT et coût qualifiés ; NET selon les règles applicables" };
        });
        const partial = dates.filter(d => !d.status.startsWith("BRUT") && !d.status.startsWith("Retour"));
        if (form.get("phase") === "confirm") {
            if (form.get("confirm") !== "on")
                throw Error("Confirmez les valeurs et les limites affichées.");
            const saved = await client.rpc("save_position_observation", { ...params, expected_token: String(form.get("token") ?? "") });
            if (saved.error)
                throw Error(saved.error.code === "40001" ? "L’état a changé depuis l’aperçu. Recommencez sans sauvegarde partielle." : "Enregistrement refusé ; aucune correction partielle enregistrée.");
            for (const path of [`/contracts/${contractId}`, "/contracts", "/reports", "/reports/history", "/patrimony", "/"])
                revalidatePath(path);
            return { status: "success", message: `Observation enregistrée. ${partial.length ? "Restitution historique partielle ; sources protégées ou données insuffisantes signalées dans l’aperçu." : "Les limites de l’aperçu restent applicables : l’enregistrement ne garantit pas une restitution historique complète."} Aucun flux ni mouvement d’espèces créé.` };
        }
        const latest = (plan.nextEntries as PositionObservation[]).sort((a, b) => b.effectiveOn.localeCompare(a.effectiveOn))[0];
        return { status: "preview", review: { token: plan.token, contractId, assetId, positionId: plan.position?.id ?? positionId, observation: plan.observation, destination: !!plan.destination, dates, currentBefore: plan.position?.quantity == null ? "Aucune position" : `${plan.position.quantity}${plan.position.is_active === false ? " (inactive ; réactivation après confirmation)" : ""} · PRU ${plan.position.average_cost_per_unit ?? "inconnu"} ${plan.position.cost_currency_code}`, currentAfter: `${latest.quantity} · PRU ${latest.unitCost ?? "inconnu"} ${latest.currency}` } };
    }
    catch (reason) {
        return { status: "error", message: reason instanceof Error ? reason.message : "Observation indisponible." };
    }
}
