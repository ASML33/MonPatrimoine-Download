"use server";

import { addLifeInsuranceFlowAction } from "./life-insurance-actions";
import { isContractInUserScope } from "@/lib/contracts/contract-scope";
import { revalidatePath } from "next/cache";
import { getCurrentProfile } from "@/lib/auth/profile";
import { cashError, parisDateFromIso, validateCashBalanceForm, validateCashFlowForm, type CashActionState } from "@/lib/cash/cash-core";
import { isUuid } from "@/lib/assets/asset-core";
import { resolveFxRate, type FxResolution } from "@/lib/fx/fx-rates";
import { createClient } from "@/lib/supabase/server";
import { linksFlowsToCash, flowCashError, flowReconciliation } from "@/lib/cash/flow-cash";
import { securitiesMoney, securitiesDay, securitiesError } from "@/lib/cash/securities-actions";

type SupabaseClient = Awaited<ReturnType<typeof createClient>>;

async function context(contractId: string) {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active" || !isContractInUserScope(contractId) || !isUuid(contractId)) return null;
  const supabase = await createClient();
  const contract = await supabase.from("contracts").select("id,is_active,opened_on,closed_on,envelope_types(code)")
    .eq("id", contractId).eq("user_id", current.profile.auth_user_id).maybeSingle();
  if (contract.error || !contract.data) return null;
  const currencies = await supabase.from("currencies").select("code").eq("is_active", true);
  if (currencies.error) return null;
  return { supabase, userId: current.profile.auth_user_id, contract: contract.data, currencies: new Set((currencies.data ?? []).map((row) => row.code)) };
}

async function withManualRate(
  supabase: SupabaseClient,
  resolution: FxResolution,
  manualRate: string | null,
  manualConfirmed: boolean,
) {
  if (resolution.status === "resolved" || !manualRate || !manualConfirmed) return resolution;
  const saved = await supabase.rpc("save_manual_fx_rate", {
    requested_currency: resolution.currencyCode,
    requested_date: resolution.requestedOn,
    requested_observed_on: resolution.requestedOn,
    requested_eur_per_unit: manualRate,
    requested_metadata: { note: "Taux de référence manuel confirmé dans MonPatrimoine" },
  });
  if (saved.error || typeof saved.data !== "string") return resolution;
  return { status: "resolved" as const, rateId: saved.data, currencyCode: resolution.currencyCode, requestedOn: resolution.requestedOn, observedOn: resolution.requestedOn, eurPerUnit: manualRate, source: "manual" as const };
}

function revalidateContract(contractId: string) {
  revalidatePath(`/contracts/${contractId}`);
  revalidatePath("/contracts");
  revalidatePath("/reports");
  revalidatePath("/patrimony");
  revalidatePath("/");
}

function resolutionMessage(resolution: FxResolution, success: string) {
  if (resolution.status === "pending") return `${success} La conversion EUR sera retentée dès que les fournisseurs FX seront disponibles.`;
  if (resolution.status === "manual_required") return `${success} Aucun fournisseur automatique ne couvre cette devise à cette date ; renseignez un taux FX manuel de référence.`;
  return success;
}

function linkedRequest(form: FormData, operation: string) {
  const request = String(form.get("request_id") ?? "");
  const revision = String(form.get("expected_updated_at") ?? "");
  if (!isUuid(request) || operation !== "create" && !Number.isFinite(Date.parse(revision))) throw Error("Rechargez le formulaire de flux avant de réessayer.");
  const balances = JSON.parse(String(form.get("expected_balances") ?? "null"));
  if (!Array.isArray(balances) || balances.some(b => !b || !isUuid(b.id) || !Number.isFinite(Date.parse(b.updatedAt)))) throw Error("Rechargez les observations espèces avant de réessayer.");
  return {request, revision: operation === "create" ? null : revision, balances};
}

async function mutateLinkedFlow(supabase: SupabaseClient, contractId: string, flowId: string, operation: string, form: FormData, values: Record<string, unknown>) {
  let request;
  try { request = linkedRequest(form, operation); }
  catch (error) { return { status: "error" as const, message: error instanceof Error ? error.message : "Formulaire obsolète." }; }
  const result = await supabase.rpc("mutate_contract_cash_flow", {
    requested_contract: contractId, requested_flow: operation === "create" ? request.request : flowId,
    requested_operation: operation, requested_request: request.request,
    expected_flow_updated_at: request.revision, expected_balances: request.balances, requested_values: values,
  });
  if (result.error) return {status: "error" as const, message: flowCashError(result.error.message) ?? cashError(result.error.code)};
  revalidateContract(contractId);
  return {status: "success" as const, message: operation === "delete" ? "Flux supprimé et seul effet espèces associé annulé. Le Total versé et le Flux net ont été recalculés." : "Flux enregistré et espèces rapprochées selon le choix confirmé. Le Total versé et le Flux net ont été recalculés."};
}

async function mutateSecuritiesAction(current: NonNullable<Awaited<ReturnType<typeof context>>>, form: FormData, kind: "balance" | "flow"): Promise<CashActionState> {
  try {
    const operation = String(form.get("operation") ?? "");
    if (kind === "flow" && operation !== "create") throw Error("Un flux enregistré ne peut être ni modifié ni supprimé.");
    if (!["create", "update", "delete"].includes(operation)) throw Error("Opération invalide.");
    if (form.has("cash_effect")) throw Error("Ce formulaire utilise l’ancien rapprochement. Rechargez avant d’enregistrer.");
    const request = String(form.get("request_id") ?? "");
    const id = operation === "create" ? request : String(form.get(kind === "flow" ? "flow_id" : "cash_action_id") ?? "");
    if (!isUuid(request) || !isUuid(id)) throw Error("Rechargez le formulaire avant de réessayer.");
    const revisions = JSON.parse(String(form.get("expected_balances") ?? "null"));
    if (!Array.isArray(revisions) || revisions.some(r => !isUuid(r?.id) || !Number.isFinite(Date.parse(r?.updatedAt)))) throw Error("Rechargez les espèces avant de réessayer.");
    const revision = operation === "create" ? null : String(form.get("expected_updated_at") ?? "");
    if (revision !== null && !Number.isFinite(Date.parse(revision))) throw Error("Rechargez l’historique avant de réessayer.");
    let values: Record<string, string | null> = {};
    if (operation !== "delete") {
      const currency = String(form.get("currency_code") ?? "");
      if (!current.currencies.has(currency)) throw Error("Devise invalide.");
      const date = securitiesDay(String(form.get(kind === "flow" ? "occurred_at" : "as_of") ?? "")).day;
      const note = String(form.get("note") ?? "").trim();
      if ([...note].length > 500) throw Error("Le commentaire est limité à 500 caractères.");
      values = { date, amount: securitiesMoney(String(form.get("amount") ?? ""), kind === "balance"), currency_code: currency, ...(kind === "flow" ? {kind: String(form.get("kind") ?? ""), note: note || null} : {}) };
    }
    const saved = await current.supabase.rpc("mutate_securities_cash_action", { requested_contract: current.contract.id, requested_action: id, requested_kind: kind, requested_operation: operation, requested_request: request, expected_balances: revisions, expected_action_revision: revision, requested_values: values });
    if (saved.error) return {status:"error",message:saved.error.code === "40001" ? "Une modification simultanée ou une reprise différente a été détectée. Rechargez sans écriture partielle." : flowCashError(saved.error.message) ?? securitiesError(saved.error.message)};
    if(kind === "flow" && operation !== "delete" && values.currency_code !== "EUR") {
      const currency=values.currency_code!,day=values.date!;
      const fx=await resolveFxRate(currency,day).catch(()=>({status:"pending" as const,currencyCode:currency,requestedOn:day}));
      await current.supabase.from("cash_flows").update({fx_rate_id:fx.status === "resolved" ? fx.rateId : null,fx_status:fx.status}).eq("id",id).eq("user_id",current.userId).eq("currency_code",currency).eq("occurred_at",securitiesDay(day).instant).is("fx_rate_id",null);
    }
    revalidateContract(current.contract.id);
    return {status:"success",message:operation === "delete" ? "Action supprimée. Seul son effet a été retiré ; les autres actions sont conservées." : "Action enregistrée à sa date d’effet. Les indicateurs et l’historique ont été recalculés."};
  } catch (reason) { return {status:"error",message:reason instanceof Error ? reason.message : "Action invalide."}; }
}

export async function saveContributionCorrectionAction(_state:CashActionState,form:FormData):Promise<CashActionState>{
 try{
  const id=String(form.get("contract_id")??""),current=await context(id);
  const envelope=current&&(Array.isArray(current.contract.envelope_types)?current.contract.envelope_types[0]:current.contract.envelope_types);
  if(!current||!linksFlowsToCash(envelope?.code??""))throw Error("Contrat non autorisé.");
  if(form.get("operation")!=="create")throw Error("Une correction se rectifie par une nouvelle saisie.");
  const request=String(form.get("request_id")??""),revision=String(form.get("expected_updated_at")??"");
  if(!isUuid(request)||!Number.isFinite(Date.parse(revision)))throw Error("Rechargez le formulaire avant de réessayer.");
  const date=securitiesDay(String(form.get("effective_on")??"")).day,amount=securitiesMoney(String(form.get("amount")??""));
  const balances=JSON.parse(String(form.get("expected_balances")??"null"));
  if(!Array.isArray(balances)||balances.some(b=>!isUuid(b?.id)||!Number.isFinite(Date.parse(b?.updatedAt))))throw Error("Rechargez les espèces avant de réessayer.");
  const result=await current.supabase.rpc("save_securities_contribution_correction",{requested_contract:id,requested_request:request,expected_revision:revision,expected_balances:balances,requested_date:date,requested_amount:amount});
  if(result.error)return{status:"error",message:securitiesError(result.error.message)};
  revalidateContract(id);return{status:"success",message:"Cumul enregistré à sa date d’effet."};
 }catch(e){return{status:"error",message:e instanceof Error?e.message:"Correction invalide."};}
}

export async function saveCashBalanceAction(_state: CashActionState, form: FormData): Promise<CashActionState> {
  const contractId = String(form.get("contract_id") ?? "");
  const operation = String(form.get("operation") ?? "");
  const balanceId = String(form.get("balance_id") ?? "");
  const current = await context(contractId);
  if (!current) return { status: "error", message: "Connectez-vous avec le compte autorisé." };
  const { supabase, userId, contract, currencies } = current;
  const envelope = Array.isArray(contract.envelope_types) ? contract.envelope_types[0] : contract.envelope_types;
  if (linksFlowsToCash(envelope?.code ?? "")) return mutateSecuritiesAction(current, form, "balance");
  if (operation === "delete") {
    if (!isUuid(balanceId) || form.get("confirm") !== "on") return { status: "error", message: "Confirmez la suppression du solde." };
    const expectedUpdatedAt = String(form.get("expected_updated_at") ?? "");
    const expectedAsOf = String(form.get("expected_as_of") ?? "");
    if (!Number.isFinite(Date.parse(expectedUpdatedAt)) || !Number.isFinite(Date.parse(expectedAsOf))) return { status: "error", message: "Rechargez le solde avant de supprimer cette observation. [CASH-DELETE-STALE]" };
    const deleted = await supabase.rpc("delete_cash_balance_observation", {
      requested_contract: contractId, requested_balance: balanceId,
      expected_updated_at: expectedUpdatedAt, expected_as_of: expectedAsOf,
    });
    if (deleted.error) return { status: "error", message: cashError(deleted.error.code) };
    revalidateContract(contractId);
    return { status: "success", message: "Observation supprimée. Le solde est recalculé à partir des observations restantes ; sans observation, il est non renseigné." };
  }
  if (operation !== "create" && operation !== "update") return { status: "error", message: "Opération invalide." };
  if (operation === "create" && !contract.is_active) return { status: "error", message: "Réactivez le contrat avant d’ajouter un solde." };
  if (operation === "update" && !isUuid(balanceId)) return { status: "error", message: "Solde invalide." };
  let values;
  try { values = validateCashBalanceForm(form, currencies); }
  catch (error) { return { status: "error", message: error instanceof Error ? error.message : "Valeurs invalides." }; }
  const expectedUpdatedAt = String(form.get("expected_updated_at") ?? "");
  const expectedAsOf = String(form.get("expected_as_of") ?? "");
  if (operation === "update" && (!Number.isFinite(Date.parse(expectedUpdatedAt)) || !Number.isFinite(Date.parse(expectedAsOf)))) return { status: "error", message: "Rechargez le solde avant de le corriger." };
  const destination = await supabase.from("cash_balances").select("updated_at").eq("contract_id", contractId).eq("user_id", userId).eq("currency_code", values.currencyCode).maybeSingle();
  if (destination.error) return { status: "error", message: "Solde destination indisponible." };
  const saved = await supabase.rpc("save_cash_balance_observation", {
    requested_contract: contractId, requested_balance: operation === "update" ? balanceId : null,
    expected_updated_at: operation === "update" ? expectedUpdatedAt : null,
    expected_as_of: operation === "update" ? expectedAsOf : null,
    requested_currency: values.currencyCode, requested_amount: values.amount, requested_as_of: values.asOf,
    expected_destination_updated_at: destination.data?.updated_at ?? null,
  });
  if (saved.error) return { status: "error", message: cashError(saved.error.code) };
  // Existing FX resolution remains separate from the atomic native correction.
  let resolution = await resolveFxRate(values.currencyCode, parisDateFromIso(new Date().toISOString())).catch(() => ({ status: "pending" as const, currencyCode: values.currencyCode, requestedOn: parisDateFromIso(new Date().toISOString()) }));
  resolution = await withManualRate(supabase, resolution, values.manualRate, values.manualConfirmed);
  revalidateContract(contractId);
  return { status: "success", message: resolutionMessage(resolution, "Solde enregistré.") };
}

export async function saveLiquidSavingsTotalAction(_state: CashActionState, form: FormData): Promise<CashActionState> {
  try {
    const contractId=String(form.get("contract_id") ?? ""), current=await context(contractId);
    if (!current) return {status:"error",message:"Connectez-vous avec le compte autorisé."};
    const envelope=Array.isArray(current.contract.envelope_types)?current.contract.envelope_types[0]:current.contract.envelope_types;
    if(envelope?.code!=="epargne_liquide" || !current.contract.is_active) return {status:"error",message:"Ce contrat ne permet pas cette opération."};
    const day=securitiesDay(String(form.get("effective_on")??"")).day;
    const values=new FormData();values.set("amount",String(form.get("amount")??""));values.set("currency_code","EUR");values.set("as_of",`${day}T00:00`);
    const parsed=validateCashBalanceForm(values,current.currencies);
    const revisions=JSON.parse(String(form.get("expected_balances")??"null"));
    if(!Array.isArray(revisions)||revisions.some(r=>!isUuid(r?.id)||!Number.isFinite(Date.parse(r?.updatedAt)))) throw Error("Rechargez le solde avant de réessayer.");
    const saved=await current.supabase.rpc("save_liquid_savings_total",{requested_contract:contractId,requested_date:day,requested_amount:parsed.amount,expected_balances:revisions});
    if(saved.error)return {status:"error",message:cashError(saved.error.code)};
    revalidateContract(contractId);return {status:"success",message:"Solde enregistré."};
  } catch(error) { return {status:"error",message:error instanceof Error?error.message:"Enregistrement impossible."}; }
}

export async function saveCashFlowAction(_state: CashActionState, form: FormData): Promise<CashActionState> {
  const contractId = String(form.get("contract_id") ?? "");
  const operation = String(form.get("operation") ?? "");
  const flowId = String(form.get("flow_id") ?? "");
  const current = await context(contractId);
  if (!current) return { status: "error", message: "Connectez-vous avec le compte autorisé." };
  const { supabase, userId, contract, currencies } = current;
  const envelope = Array.isArray(contract.envelope_types) ? contract.envelope_types[0] : contract.envelope_types;
  const linked = linksFlowsToCash(envelope?.code ?? "");
  if(envelope?.code === "assurance_vie") return addLifeInsuranceFlowAction(_state,form);
  if (linked) return mutateSecuritiesAction(current, form, "flow");
  if (operation === "delete") {
    if (!isUuid(flowId) || form.get("confirm") !== "on") return { status: "error", message: "Confirmez la suppression du flux." };
    if (linked) return mutateLinkedFlow(supabase, contractId, flowId, operation, form, {});
    const loaded = await supabase.from("cash_flows").select("destination_contract_id,source_contract_id")
      .eq("id", flowId).eq("user_id", userId).maybeSingle();
    const linkedContractId = loaded.data?.destination_contract_id ?? loaded.data?.source_contract_id;
    if (loaded.error || linkedContractId !== contractId) return { status: "error", message: "Ce flux n’est pas accessible." };
    const deleted = await supabase.from("cash_flows").delete().eq("id", flowId).eq("user_id", userId).select("id").single();
    if (deleted.error) return { status: "error", message: cashError(deleted.error.code) };
    revalidateContract(contractId);
    return { status: "success", message: "Flux supprimé. Le Total versé et le Flux net ont été recalculés." };
  }
  if (operation !== "create" && operation !== "update") return { status: "error", message: "Opération invalide." };
  if (operation === "create" && !contract.is_active) return { status: "error", message: "Réactivez le contrat avant d’ajouter un flux." };
  if (operation === "update" && !isUuid(flowId)) return { status: "error", message: "Flux invalide." };
  if (linked) {
    try { linkedRequest(form, operation); }
    catch (error) { return {status: "error", message: error instanceof Error ? error.message : "Formulaire obsolète."}; }
  }
  let values;
  try { values = validateCashFlowForm(form, currencies); }
  catch (error) { return { status: "error", message: error instanceof Error ? error.message : "Valeurs invalides." }; }
  if ((contract.opened_on && values.occurredOn < contract.opened_on) || (contract.closed_on && values.occurredOn > contract.closed_on)) {
    return { status: "error", message: "La date doit appartenir à la période d’existence du contrat." };
  }
  let existing: { currency_code: string; occurred_at: string; fx_rate_id: string | null; fx_status: "resolved" | "pending" | "manual_required"; destination_contract_id: string | null; source_contract_id: string | null } | null = null;
  if (operation === "update") {
    const loaded = await supabase.from("cash_flows").select("currency_code,occurred_at,fx_rate_id,fx_status,destination_contract_id,source_contract_id")
      .eq("id", flowId).eq("user_id", userId).maybeSingle();
    existing = loaded.data;
    if (loaded.error || !existing || (existing.destination_contract_id ?? existing.source_contract_id) !== contractId) return { status: "error", message: "Ce flux n’est pas accessible." };
  }
  const conversionUnchanged = existing?.currency_code === values.currencyCode && Date.parse(existing.occurred_at) === Date.parse(values.occurredAt) && existing.fx_status === "resolved";
  if (linked) {
    let reconciliation;
    try { reconciliation = flowReconciliation(form); }
    catch (error) { return { status: "error", message: error instanceof Error ? error.message : "Rapprochement invalide." }; }
    const saved = await mutateLinkedFlow(supabase, contractId, flowId, operation, form, {
      ...reconciliation,
      kind: values.kind, amount: values.amount, currency_code: values.currencyCode,
      occurred_at: values.occurredAt, note: values.note,
      fx_rate_id: conversionUnchanged ? existing!.fx_rate_id : null,
      fx_status: values.currencyCode === "EUR" || conversionUnchanged ? "resolved" : "pending",
    });
    // Reconciliation must succeed before any FX lookup/reference write.
    // Native flow and cash are already atomic; pending conversion is explicit.
    if (saved.status !== "success" || values.currencyCode === "EUR" || conversionUnchanged) return saved;
    let conversion = await resolveFxRate(values.currencyCode, values.occurredOn).catch(() => ({status: "pending" as const, currencyCode: values.currencyCode, requestedOn: values.occurredOn}));
    conversion = await withManualRate(supabase, conversion, values.manualRate, values.manualConfirmed);
    if (conversion.status === "resolved") {
      const request = linkedRequest(form, operation);
      const updated = await supabase.from("cash_flows").update({fx_rate_id: conversion.rateId, fx_status: "resolved"})
        .eq("id", operation === "create" ? request.request : flowId).eq("user_id", userId)
        .eq("currency_code", values.currencyCode).eq("occurred_at", values.occurredAt).is("fx_rate_id", null).select("id").maybeSingle();
      revalidateContract(contractId);
      if (updated.error || !updated.data) return {status: "success", message: "Flux et effet espèces enregistrés ensemble. La conversion EUR reste à vérifier ou le flux a changé entre-temps."};
    }
    return {status: "success", message: resolutionMessage(conversion, saved.message!)};
  }
  let resolution: FxResolution = conversionUnchanged
    ? { status: "resolved", rateId: existing!.fx_rate_id, currencyCode: values.currencyCode, requestedOn: values.occurredOn, observedOn: values.occurredOn, eurPerUnit: values.currencyCode === "EUR" ? "1" : "0", source: values.currencyCode === "EUR" ? "identity" : "manual" }
    : await resolveFxRate(values.currencyCode, values.occurredOn).catch(() => ({ status: "pending" as const, currencyCode: values.currencyCode, requestedOn: values.occurredOn }));
  if (!conversionUnchanged) resolution = await withManualRate(supabase, resolution, values.manualRate, values.manualConfirmed);
  const fxRateId = resolution.status === "resolved" ? resolution.rateId : null;
  const fxStatus = resolution.status;
  const row = {
    kind: values.kind,
    amount: values.amount,
    currency_code: values.currencyCode,
    occurred_at: values.occurredAt,
    note: values.note,
    destination_contract_id: values.kind === "contribution" ? contractId : null,
    source_contract_id: values.kind === "withdrawal" ? contractId : null,
    fx_rate_id: fxRateId,
    fx_status: fxStatus,
  };
  const mutation = operation === "create"
    ? supabase.from("cash_flows").insert({ ...row, user_id: userId })
    : supabase.from("cash_flows").update(row).eq("id", flowId).eq("user_id", userId);
  const saved = await mutation.select("id").single();
  if (saved.error) return { status: "error", message: cashError(saved.error.code) };
  revalidateContract(contractId);
  return { status: "success", message: resolutionMessage(resolution, "Flux enregistré. Le Total versé et le Flux net ont été recalculés.") };
}

export async function refreshContractFxAction(_state: CashActionState, form: FormData): Promise<CashActionState> {
  const contractId = String(form.get("contract_id") ?? "");
  const current = await context(contractId);
  if (!current) return { status: "error", message: "Connectez-vous avec le compte autorisé." };
  const { supabase, userId } = current;
  const [balances, flows] = await Promise.all([
    supabase.from("cash_balances").select("currency_code").eq("contract_id", contractId).eq("user_id", userId),
    supabase.from("cash_flows").select("id,currency_code,occurred_at,fx_status,destination_contract_id,source_contract_id").eq("user_id", userId).neq("fx_status", "resolved"),
  ]);
  if (balances.error || flows.error) return { status: "error", message: "Conversions indisponibles. Rechargez la page puis réessayez." };
  const requests = new Map<string, { currencyCode: string; requestedOn: string }>();
  const today = parisDateFromIso(new Date().toISOString());
  for (const balance of balances.data ?? []) if (balance.currency_code !== "EUR") requests.set(`${balance.currency_code}:${today}`, { currencyCode: balance.currency_code, requestedOn: today });
  const contractFlows = (flows.data ?? []).filter((flow) => (flow.destination_contract_id ?? flow.source_contract_id) === contractId);
  for (const flow of contractFlows) {
    const requestedOn = parisDateFromIso(flow.occurred_at);
    requests.set(`${flow.currency_code}:${requestedOn}`, { currencyCode: flow.currency_code, requestedOn });
  }
  const resolutions = new Map<string, FxResolution>();
  for (const [key, request] of requests) resolutions.set(key, await resolveFxRate(request.currencyCode, request.requestedOn).catch(() => ({ status: "pending", ...request })));
  let resolved = 0;
  for (const flow of contractFlows) {
    const requestedOn = parisDateFromIso(flow.occurred_at);
    const resolution = resolutions.get(`${flow.currency_code}:${requestedOn}`);
    if (resolution?.status !== "resolved") continue;
    const saved = await supabase.from("cash_flows").update({ fx_rate_id: resolution.rateId, fx_status: "resolved" }).eq("id", flow.id).eq("user_id", userId).is("fx_rate_id", null);
    if (!saved.error) resolved += 1;
  }
  revalidateContract(contractId);
  const unresolved = [...resolutions.values()].filter((resolution) => resolution.status !== "resolved").length;
  return { status: "success", message: unresolved ? `${resolved} conversion(s) résolue(s). Certaines conversions restent en attente.` : "Conversions EUR actualisées." };
}
