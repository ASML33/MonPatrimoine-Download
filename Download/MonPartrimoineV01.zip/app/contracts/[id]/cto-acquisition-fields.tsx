"use client";
import { useState } from "react";
import { acquisitionDecimal, divideAcquisition, multiplyAcquisition, type AcquisitionMode } from "@/lib/contracts/cto-acquisition-input";

export function CtoAcquisitionFields({ quantity, nativeQuantity, nativeCost, nativeCurrency, currencies, effectiveOn, costEffectiveOn, initialNativeTotal, initialPosition=false }: {
  initialPosition?:boolean; initialNativeTotal?:string|null; effectiveOn?:string; costEffectiveOn?:string; quantity: string; nativeQuantity: string; nativeCost: string | null; nativeCurrency: string; currencies: { code: string }[];
}) {
  const [mode, setMode] = useState<AcquisitionMode>("total");
  const [currency, setCurrency] = useState("USD");
  const [draft, setDraft] = useState("");
  const [changed, setChanged] = useState(false);
  const [notice, setNotice] = useState("");
  const known = nativeCurrency === currency && nativeCost !== null;
  const amount = changed ? draft : !known ? "" : mode === "unit" ? acquisitionDecimal(nativeCost) ?? "" : acquisitionDecimal(quantity,8)===acquisitionDecimal(nativeQuantity,8)&&initialNativeTotal!=null?initialNativeTotal:multiplyAcquisition(nativeCost, acquisitionDecimal(quantity, 8) ?? nativeQuantity) ?? "";
  const switchMode = (next: AcquisitionMode) => {
    if (next === mode) return;
    if (!amount.trim()) { setMode(next); setNotice(""); return; }
    const conversion = next === "unit" ? divideAcquisition(amount, quantity) : null;
    const converted = next === "unit" ? conversion?.exact ? conversion.value : null : multiplyAcquisition(amount, quantity);
    if (converted === null || converted === undefined) {
      setNotice("Conversion exacte impossible avec cette quantité et ce montant. Le brouillon et le type de montant sont conservés.");
      return;
    }
    if (changed) setDraft(converted);
    setMode(next); setNotice("");
  };
  return <div className="grid gap-3 sm:col-span-2 sm:grid-cols-3">
    <input type="hidden" name="acquisition_cost_changed" value={initialPosition||changed ? "yes" : effectiveOn && effectiveOn!==costEffectiveOn && acquisitionDecimal(quantity,8)===acquisitionDecimal(nativeQuantity,8) ? "date" : "no"}/>
    <label className="grid gap-2 text-sm">Type de montant<select name="acquisition_mode" className="settings-input" value={mode} onChange={e => switchMode(e.target.value as AcquisitionMode)}>
      <option value="total">Coût total d’acquisition</option><option value="unit">Prix de Revient Unitaire</option>
    </select></label>
    <label className="grid gap-2 text-sm">Montant<input name="acquisition_amount" className="settings-input" inputMode="decimal" value={amount} onChange={e => { setDraft(e.target.value); setChanged(true); setNotice(""); }}/></label>
    <label className="grid gap-2 text-sm">Devise<select name="cost_currency" className="settings-input" value={currency} onChange={e => {
      const next = e.target.value;
      if (!changed) setDraft(nativeCurrency === next && nativeCost !== null ? mode === "unit" ? acquisitionDecimal(nativeCost) ?? "" : multiplyAcquisition(nativeCost, quantity) ?? "" : "");
      setCurrency(next); setChanged(true); setNotice("Aucune conversion de change n’est effectuée. Vérifiez le montant dans la devise choisie.");
    }}>{!currencies.some(c => c.code === "USD") ? <option value="USD" disabled>USD indisponible</option> : null}{currencies.map(c => <option key={c.code} value={c.code}>{c.code} - {new Intl.DisplayNames(["fr"], { type: "currency" }).of(c.code) ?? c.code}</option>)}</select></label>
    <p className="text-xs text-[var(--app-muted)] sm:col-span-3">{initialPosition?"Le coût total concerne toute la quantité saisie, frais inclus. Sans montant, le coût reste inconnu.":"Le coût total concerne toute la quantité détenue. Montant vide après modification : coût inconnu. Quantité seule : PRU et preuves existants conservés. Un PRU calculé est conservé jusqu’à 20 décimales ; le montant total saisi reste enregistré exactement."}</p>
    {changed && currency !== "EUR" ? <p className="text-xs text-[var(--app-muted)] sm:col-span-3">La conversion EUR sera recherchée à la date d’effet puis figée avec le coût.</p> : null}
    {!initialPosition && !known && !changed ? <p className="text-xs text-[var(--app-muted)] sm:col-span-3">Coût existant en USD indisponible : aucun montant converti n’est prérempli. Le coût existant reste conservé tant que le montant ou sa devise n’est pas modifié.</p> : null}
    {!changed && effectiveOn && effectiveOn!==costEffectiveOn && acquisitionDecimal(quantity,8)===acquisitionDecimal(nativeQuantity,8) ? <p className="text-xs text-[var(--app-muted)] sm:col-span-3">Cette date sera appliquée au coût existant en {nativeCurrency}.</p> : null}
    {notice ? <p role="status" className="text-xs text-[var(--app-muted)] sm:col-span-3">{notice}</p> : null}
  </div>;
}
