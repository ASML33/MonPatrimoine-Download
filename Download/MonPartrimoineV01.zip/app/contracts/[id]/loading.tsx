export default function ContractLoading() {
  return (
    <main className="mx-auto min-h-screen max-w-7xl bg-[var(--app-background)] px-4 py-10 text-[var(--app-foreground)] sm:px-6 sm:py-14">
      <section role="status" aria-busy="true" className="border border-[var(--app-border)] bg-[var(--app-surface)] p-5">
        <h1 className="text-xl font-semibold">Chargement du contrat</h1>
        <p className="mt-2 text-sm text-[var(--app-muted)]">Chargement des valorisations, de l’historique et des répartitions…</p>
      </section>
    </main>
  );
}
