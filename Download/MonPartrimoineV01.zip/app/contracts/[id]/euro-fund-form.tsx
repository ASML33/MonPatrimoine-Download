"use client";
import { useRef, useState } from "react";
import { useSavedPanelAction } from "@/app/components/use-saved-panel-action";
import type { CashActionState } from "@/lib/cash/cash-core";
import { saveLifeInsuranceAmountAction } from "./life-insurance-actions";
export function EuroFundForm({ positionId, revision, currencies, onSaved }: { positionId: string; revision: string; currencies: { code: string }[]; onSaved: () => void }) {
  const [state, action, pending] = useSavedPanelAction(saveLifeInsuranceAmountAction, { status: "idle" } as CashActionState, onSaved);
  const [initialRevision] = useState(revision), request = useRef<HTMLInputElement>(null);
  const names = new Intl.DisplayNames(["fr"], { type: "currency" });
  return <form action={action} onReset={e => e.preventDefault()} onSubmitCapture={() => { if (request.current && !request.current.value) request.current.value = crypto.randomUUID(); }} className="grid gap-3">
    <input type="hidden" name="position_id" value={positionId} /><input type="hidden" name="expected_updated_at" value={initialRevision} /><input ref={request} type="hidden" name="request_id" defaultValue="" />
    <fieldset disabled={pending} className="grid gap-3 sm:grid-cols-3">
      <label className="grid gap-2 text-sm">Valeur totale du support<input className="settings-input" name="amount" inputMode="decimal" required /></label>
      <label className="grid gap-2 text-sm">Devise<select className="settings-input" name="currency" defaultValue="EUR">{currencies.map(c => <option key={c.code} value={c.code}>{c.code} - {names.of(c.code)}</option>)}</select></label>
      <label className="grid gap-2 text-sm">Date de valorisation<input className="settings-input" type="date" name="date" required /></label>
    </fieldset>
    <p className="text-xs text-[var(--app-muted)]">Valeur totale à cette date et pour la suite. Les valorisations suivantes remplacées restent conservées. Aucun flux, espèces ou conversion implicite.</p>
    <button className="settings-primary-button justify-self-start" type="submit" disabled={pending}>{pending ? "Enregistrement…" : "Enregistrer"}</button>
    {state.message ? <p role="status" className={state.status === "error" ? "text-red-500" : ""}>{state.message}</p> : null}
  </form>;
}
