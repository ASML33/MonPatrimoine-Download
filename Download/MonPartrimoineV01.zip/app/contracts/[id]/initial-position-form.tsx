"use client";
import { formatMoney } from "@/lib/cash/money";

import { useActionState, useRef, useState } from "react";
import { HoldingObservationForm } from "./holding-observation-form";
import { createAmountPosition, type InitialAmountState } from "./initial-position-actions";

export type AvailablePositionAsset = { id: string; name: string; symbol: string | null; currencyCode?: string; amountEligible?: boolean };

function InitialAmountForm({ contractId, assetId, currencies, currency }: { contractId: string; assetId: string; currencies: {code: string}[]; currency?: string }) {
  const [state, action, pending] = useActionState(createAmountPosition, {status: "idle"} as InitialAmountState);
  const [cancelled, setCancelled] = useState(false);
  return <div className="grid gap-3">
    <form action={action} onSubmit={() => setCancelled(false)} className="grid gap-3">
      <input type="hidden" name="contract_id" value={contractId}/><input type="hidden" name="asset_id" value={assetId}/>
      <fieldset disabled={pending} className="grid gap-3 sm:grid-cols-3">
        <label className="grid gap-2 text-sm">Date de valorisation<input className="settings-input" name="date" type="date" required/></label>
        <label className="grid gap-2 text-sm">Première valeur totale du support<input className="settings-input" name="amount" inputMode="decimal" required/></label>
        <label className="grid gap-2 text-sm">Devise<select className="settings-input" name="currency" defaultValue={currency ?? "EUR"}>{currencies.map(c => <option key={c.code}>{c.code}</option>)}</select></label>
      </fieldset>
      <p className="text-xs text-[var(--app-muted)]">Valeur totale détenue à cette date, pour un fonds suivi en montant. Aucune quantité, PRU, prix unitaire, espèces ou versement créé. Les fonds suivis en parts conservent leur parcours quantité / PRU.</p>
      <button className="settings-edit-action justify-self-start" disabled={pending}>Afficher l’aperçu du rattachement</button>
    </form>
    {!cancelled && state.status === "preview" && state.request ? <section aria-label="Aperçu du rattachement en montant" className="grid gap-3 border border-[var(--app-border)] p-3 text-sm">
      <p>{state.request.date} · valeur totale {formatMoney(state.request.amount,state.request.currency)}. Le rattachement et sa première valorisation seront créés ensemble.</p>
      <form action={action} className="grid gap-3">
        {Object.entries({...state.request, token: state.token ?? "", phase: "confirm"}).map(([name, value]) => <input key={name} name={name} type="hidden" value={value}/>)}
        <label className="flex min-h-11 items-center gap-3"><input type="checkbox" name="confirm" required/>Je confirme cette première valeur totale, sans mouvement financier.</label>
        <div className="flex flex-wrap gap-3"><button className="settings-primary-button" disabled={pending}>Confirmer le rattachement en montant</button><button type="button" className="settings-edit-action" disabled={pending} onClick={() => setCancelled(true)}>Annuler</button></div>
      </form>
    </section> : null}
    {state.message ? <p role="status">{state.message}</p> : null}
  </div>;
}

export function InitialPositionForm({contractId, assets, currencies,direct=false,ctoAcquisition=false,onSaved}: {direct?:boolean;ctoAcquisition?:boolean;onSaved?:()=>void;contractId: string; assets: AvailablePositionAsset[]; currencies: {code: string}[]}) {
  const [assetId, setAssetId] = useState("");
  const assetGeneration=useRef(0), generation=assetGeneration.current;
  const [mode, setMode] = useState("units");
  const asset = assets.find(a => a.id === assetId);
  return <div className="grid gap-3">
    <label className="grid gap-2 text-sm">Actif<select className="settings-input" value={asset?.id ?? ""} onChange={e => {assetGeneration.current++;setAssetId(e.target.value);setMode("units");}}><option value="" disabled>Choisir un actif</option>{assets.map(a => <option key={a.id} value={a.id}>{a.name}{a.symbol ? ` · ${a.symbol}` : ""}</option>)}</select></label>
    {!direct && asset?.amountEligible ? <label className="grid gap-2 text-sm">Mode de suivi<select className="settings-input" value={mode} onChange={e => setMode(e.target.value)}><option value="units">Parts — quantité / PRU</option><option value="amount">Valeur totale datée</option></select></label> : null}
    {asset ? !direct && mode === "amount" && asset.amountEligible ? <InitialAmountForm key={contractId + asset.id + mode} contractId={contractId} assetId={asset.id} currencies={currencies} currency={asset.currencyCode}/> : <HoldingObservationForm ctoAcquisition={ctoAcquisition} onSaved={ctoAcquisition?()=>{if(generation===assetGeneration.current)onSaved?.();}:undefined} direct={direct} key={contractId + asset.id + mode} contractId={contractId} assetId={asset.id} currencies={currencies} currency={asset.currencyCode}/> : null}
  </div>;
}
