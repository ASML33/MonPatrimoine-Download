"use client";
import { acquisitionDecimal } from "@/lib/contracts/cto-acquisition-input";
import { CtoAcquisitionFields } from "./cto-acquisition-fields";

import { useRef, useState } from "react";
import { useSavedPanelAction } from "@/app/components/use-saved-panel-action";
import type { PositionObservation } from "@/lib/contracts/position-observations";
import { saveHoldingObservation, type HoldingState } from "./holding-actions";
export function HoldingObservationForm({ contractId, assetId, positionId, currencies, initial, quantity, unitCost, currency, assets, direct=false, ctoAcquisition=false, costEffectiveOn, initialNativeTotal, expectedUpdatedAt, onSaved }: {
    onSaved?: () => void;
    direct?: boolean;
    ctoAcquisition?: boolean;
    costEffectiveOn?:string;
    initialNativeTotal?:string|null;
    expectedUpdatedAt?: string;
    contractId: string;
    assetId?: string;
    positionId?: string;
    currencies: {
        code: string;
    }[];
    initial?: PositionObservation;
    quantity?: string;
    unitCost?: string | null;
    currency?: string;
    assets?: {
        id: string;
        name: string;
        symbol: string | null;
    }[];
}) {
    const [state, action, pending] = useSavedPanelAction(saveHoldingObservation, { status: "idle" } as HoldingState, direct ? onSaved : undefined);
    const [cancelled, setCancelled] = useState(false);
    const request=useRef<HTMLInputElement>(null);
    const [documentCost, setDocumentCost] = useState(false);
    const submittedDraft=useRef<string|null>(null);
    const [revision]=useState(expectedUpdatedAt);
    const [dateDraft,setDateDraft]=useState(initial?.effectiveOn??""),[quantityDraft,setQuantityDraft]=useState(initial?.quantity??quantity??""),[costDraft,setCostDraft]=useState(initial ? initial.unitCost ?? "" : unitCost ?? ""),[currencyDraft,setCurrencyDraft]=useState(initial?.currency??currency??"EUR");
    const review = !cancelled && state.status === "preview" ? state.review : null;
    return <div className="grid gap-3">
 <form action={action} onReset={direct?e=>e.preventDefault():undefined} onSubmit={e => {setCancelled(false);if(ctoAcquisition&&(!positionId||documentCost)&&request.current){const data=new FormData(e.currentTarget);const draft=JSON.stringify(["contract_id","asset_id","effective_on","quantity","acquisition_mode","acquisition_amount","cost_currency","historical_cost_eur","historical_cost_source"].map(k=>{const v=String(data.get(k)??"");return[k,k==="quantity"?acquisitionDecimal(v,8)??v.trim():k==="acquisition_amount"?v.trim()?acquisitionDecimal(v,28)??v.trim():"":v];}));if(draft!==submittedDraft.current){request.current.value=crypto.randomUUID();submittedDraft.current=draft;}}if(request.current&&!request.current.value)request.current.value=crypto.randomUUID();}} className="grid gap-3">
 {direct?<><input ref={request} type="hidden" name="request_id" defaultValue=""/><input type="hidden" name="expected_updated_at" value={revision??""}/></>:null}
 <input type="hidden" name="contract_id" value={contractId}/><input type="hidden" name="position_id" value={positionId ?? ""}/><input type="hidden" name="observation_id" value={initial?.id ?? ""}/>
 {assetId ? <input type="hidden" name="asset_id" value={assetId}/> : <label className="grid gap-2 text-sm">Actif<select className="settings-input" name="asset_id" required defaultValue=""><option value="" disabled>Choisir un actif</option>{assets?.map(a => <option key={a.id} value={a.id}>{a.name}{a.symbol ? ` · ${a.symbol}` : ""}</option>)}</select></label>}
 {ctoAcquisition && positionId ? <label className="flex items-center gap-2">
   <input type="checkbox" checked={documentCost} onChange={e => {setDocumentCost(e.target.checked); if(request.current) request.current.value="";}}/>
   Corriger uniquement le PRU historique EUR
 </label> : null}
 <fieldset disabled={pending} className="grid gap-3 sm:grid-cols-2">
 <label className="grid gap-2 text-sm">Date d’effet<input className="settings-input" type="date" name="effective_on" onInput={ctoAcquisition?e=>setDateDraft(e.currentTarget.value):undefined} value={direct?dateDraft:undefined} defaultValue={direct?undefined:initial?.effectiveOn ?? ""} onChange={direct?e=>setDateDraft(e.target.value):undefined} required/></label>
 {documentCost ? <>
   <input type="hidden" name="intent" value="documented_cost"/>
   <label className="grid gap-2 text-sm">PRU historique EUR<input className="settings-input" name="historical_cost_eur" inputMode="decimal" required/></label>
   <label className="grid gap-2 text-sm">Référence du coût<input className="settings-input" name="historical_cost_source" maxLength={500} required/></label>
 </> : <>
 <label className="grid gap-2 text-sm">Quantité totale détenue<input className="settings-input" name="quantity" inputMode="decimal" value={direct?quantityDraft:undefined} defaultValue={direct?undefined:initial?.quantity ?? quantity ?? ""} onChange={direct?e=>setQuantityDraft(e.target.value):undefined} required/></label>
 {ctoAcquisition ? <CtoAcquisitionFields initialPosition={!positionId} initialNativeTotal={initialNativeTotal} effectiveOn={dateDraft} costEffectiveOn={costEffectiveOn} quantity={quantityDraft} nativeQuantity={initial?.quantity??quantity??""} nativeCost={initial?initial.unitCost:unitCost??null} nativeCurrency={initial?.currency??currency??"EUR"} currencies={currencies}/> : <> <label className="grid gap-2 text-sm">PRU final (vide : inconnu)<input className="settings-input" name="unit_cost" inputMode="decimal" value={direct?costDraft:undefined} defaultValue={direct?undefined:initial ? initial.unitCost ?? "" : unitCost ?? ""} onChange={direct?e=>setCostDraft(e.target.value):undefined}/></label>
 <label className="grid gap-2 text-sm">Devise native du PRU<select className="settings-input" name="cost_currency" value={direct?currencyDraft:undefined} defaultValue={direct?undefined:initial?.currency ?? currency ?? "EUR"} onChange={direct?e=>setCurrencyDraft(e.target.value):undefined}>{currencies.map(c => <option key={c.code}>{c.code}</option>)}</select></label></>}
 </>}
 </fieldset>
 <p className="text-xs text-[var(--app-muted)]">Saisissez le total détenu, pas « +1 ». Zéro termine la détention. La devise choisie exprime le PRU saisi sans conversion implicite. Aucun mouvement d’espèces ni achat n’est créé.</p>
 {direct?<button className="settings-primary-button relative justify-self-start" style={{width:"max-content",minHeight:"2.75rem",padding:"0.5rem 0.75rem",fontWeight:600}} type="submit" disabled={pending}><span aria-hidden style={{visibility:"hidden"}}>Afficher l’aperçu</span><span className="absolute inset-0 flex items-center justify-center">{pending?"Enregistrement…":"Enregistrer"}</span></button>:<button className="settings-edit-action justify-self-start" type="submit" disabled={pending}>{pending ? "Vérification…" : "Afficher l’aperçu"}</button>}
 </form>
 {review ? <section aria-label="Aperçu de la situation" className="min-w-0 border border-[var(--app-border)] p-3 text-sm">
 <p>Date {review.observation.effectiveOn} · quantité {review.observation.quantity} · PRU {review.observation.unitCost ?? "inconnu"} {review.observation.currency}</p>
 <p>Situation courante : {review.currentBefore} → {review.currentAfter}.</p>
 {review.destination ? <p className="text-amber-500">Une observation occupe cette date. Elle sera remplacée ; les deux états précédents seront conservés.</p> : null}
 <p>Effet jusqu’à la prochaine observation explicite, exclue. Les deux intervalles sont examinés en cas de déplacement. Les sources protégées restent inchangées.</p>
 <details className="my-3"><summary className="cursor-pointer py-2">{review.dates.length} date(s) financière(s) concernée(s)</summary><ul className="max-h-64 overflow-y-auto break-words">{review.dates.map(d => <li key={d.date} className="py-1">{d.date} : {d.status}</li>)}</ul></details>
 <form action={action} className="grid gap-3"><input type="hidden" name="phase" value="confirm"/><input type="hidden" name="token" value={review.token}/>{Object.entries({ contract_id: review.contractId, asset_id: review.assetId, position_id: review.positionId, observation_id: review.observation.id, effective_on: review.observation.effectiveOn, quantity: review.observation.quantity, unit_cost: review.observation.unitCost ?? "", cost_currency: review.observation.currency }).map(([name, value]) => <input key={name} type="hidden" name={name} value={value}/>)}
 <label className="flex min-h-11 items-center gap-3"><input type="checkbox" name="confirm" required/>Je confirme ces valeurs, le remplacement éventuel et les limites de restitution.</label>
 <div className="flex flex-wrap gap-3"><button type="submit" className="settings-primary-button" disabled={pending}>{pending ? "Enregistrement…" : "Confirmer la situation"}</button><button type="button" className="settings-edit-action" disabled={pending} onClick={() => setCancelled(true)}>Annuler</button></div></form>
 </section> : null}
 {state.message ? <p role="status" className={state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}>{state.message}</p> : null}
 </div>;
}
