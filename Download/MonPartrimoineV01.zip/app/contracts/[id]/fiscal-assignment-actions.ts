'use server';
export type FiscalAssignmentReview={contractId:string;date:string;regimeId:string;ruleId:string|null;name:string;context:{fiscalStartedOn:string|null;historyComplete:boolean;socialContributionsPaidEur:number|null};destination:{name:string;date:string}|null;nextDate:string|null;expected:string;unchanged:boolean;submissionId:string};
export type FiscalAssignmentState={status:'idle'|'preview'|'success'|'error';message?:string;review?:FiscalAssignmentReview};
export async function changeContractFiscalAssignment(_state:FiscalAssignmentState,_form:FormData):Promise<FiscalAssignmentState>{
 void _state;void _form;return {status:'error',message:'La fiscalité se configure désormais dans Enveloppes ; aucune affectation par contrat n’est enregistrée.'};
}
