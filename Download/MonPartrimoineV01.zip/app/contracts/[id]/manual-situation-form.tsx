"use client";
import {useActionState,useState} from "react";
import {formatMoney} from "@/lib/cash/money";
import type {EmployeeSavingsValue} from "@/lib/patrimony/employee-savings-values";
import {saveEmployeeSavingsValue,type EmployeeValueState} from "./employee-savings-actions";
const money=(v:string|null)=>v===null?"Non fourni":formatMoney(Number(v),"EUR");
function ValueEditor({contractId,kind,initial}:{contractId:string;kind:"peg"|"per_col";initial?:EmployeeSavingsValue}){
 const [state,action,pending]=useActionState(saveEmployeeSavingsValue,{status:"idle"} as EmployeeValueState),[cancelled,cancel]=useState(false);
 const review=!cancelled&&state.status==="preview"?state.review:null;
 return <div className="mt-4 grid min-w-0 gap-3"><form action={action} onSubmit={()=>cancel(false)} className="grid gap-3">
 <input type="hidden" name="contract_id" value={contractId}/><input type="hidden" name="edited_ref" value={initial?.ref??""}/>
 <fieldset disabled={pending} className={`grid items-start gap-4 ${kind==="peg"?"sm:grid-cols-3":"sm:grid-cols-2"}`}>
 <label className="grid gap-2 text-sm">Date<input className="settings-input" type="date" name="effective_on" defaultValue={initial?.date??""} required/></label>
 <label className="grid gap-2 text-sm">Montant total BRUT en EUR<input className="settings-input" inputMode="decimal" name="gross_eur" defaultValue={initial?.gross??""} required/></label>
 {kind==="peg"?<label className="grid gap-2 text-sm">Montant NET en EUR<input className="settings-input" inputMode="decimal" name="net_eur" defaultValue={initial?.net??""} required/></label>:null}
 </fieldset><p className="text-xs text-[var(--app-muted)]">{kind==="peg"?"NET déclaré obligatoire, y compris pour corriger une ancienne observation importée sans NET. Aucun NET calculé ni ancien NET repris.":"PER COL : aucun NET fourni ou calculé."} Cette saisie ne crée aucun flux, achat ou mouvement d’espèces.</p>
 <button className="settings-edit-action justify-self-start" disabled={pending}>{pending?"Vérification…":"Enregistrer"}</button></form>
 {review?<section aria-label="Aperçu de la valorisation" className="grid gap-3 border border-[var(--app-border)] p-4 text-sm">
 <p>{review.date} · BRUT {money(review.gross)} · NET {money(review.net)}</p>
 {review.before?<p>Avant : {review.before.date} · BRUT {money(review.before.gross)} · NET {money(review.before.net)}</p>:<p>Nouvelle observation individuelle.</p>}
 {review.moved?<p>La date est déplacée : l’ancienne observation ne restera pas effective à son ancienne date.</p>:null}
 {review.destination&&!review.unchanged?<p className="text-amber-500">La date de destination possède une observation : elle sera remplacée, avec conservation de sa preuve.</p>:null}
 {review.netCleared?<p className="text-amber-500">Le NET précédent sera effacé de l’observation effective ; sa preuve restera conservée.</p>:null}
 {review.unchanged?<p>Aucune valeur à modifier : répétition sans nouvelle version.</p>:null}
 <p>Valeur maintenue jusqu’à la prochaine observation individuelle{review.nextDate?` du ${review.nextDate}`:" applicable"}. Les captures restent conservées. Si seule une valeur individuelle remplace un groupe commun, l’autre membre demeure inconnu et le total reste partiel ; aucune ventilation du groupe n’est déduite.</p>
 <form action={action} className="grid gap-3"><input type="hidden" name="phase" value="confirm"/><input type="hidden" name="token" value={review.token}/><input type="hidden" name="submission_id" value={review.submissionId}/>{Object.entries({contract_id:contractId,edited_ref:review.editedRef??"",effective_on:review.date,gross_eur:review.gross,net_eur:review.net??""}).map(([name,value])=><input key={name} type="hidden" name={name} value={value}/>)}
 <label className="flex min-h-11 items-center gap-3"><input type="checkbox" name="confirm" required/>Je confirme les valeurs et remplacements présentés.</label>
 <div className="flex flex-wrap gap-3"><button className="settings-primary-button" disabled={pending}>Confirmer l’enregistrement</button><button type="button" className="settings-edit-action" disabled={pending} onClick={()=>cancel(true)}>Annuler</button></div></form></section>:null}
 {state.message?<p role="status" className={state.status==="error"?"text-red-500":"text-[var(--app-muted)]"}>{state.message}</p>:null}</div>;
}
export function EmployeeSavingsValueForm({contractId,kind,value,observations,archives,active}:{contractId:string;kind:"peg"|"per_col";value:EmployeeSavingsValue|null;observations:EmployeeSavingsValue[];archives:EmployeeSavingsValue[];active:boolean}){
 return <section className="settings-card mt-6 min-w-0"><h2 className="text-xl font-semibold">Valorisation déclarée</h2>
 <p className="mt-3">BRUT : {value?money(value.gross):"Indisponible"}{kind==="peg"?<> · NET déclaré : {value?money(value.net):"Non fourni"}</>:null}</p>
 <p className="mt-2 break-words text-sm text-[var(--app-muted)]">{value?`Valeur du ${value.date} · ${value.provenance}`:"Aucune observation individuelle disponible."}</p>
 <p className="mt-2 text-xs text-[var(--app-muted)]">Date réelle de l’observation, précision {value?.precision==="date"?"journalière":value?.precision==="evening"?"soirée, heure inconnue":"connue à la source"}. {kind==="peg"?"Un NET déclaré n’est pas calculé ni certifié par l’application.":"Valeur totale BRUT déclarée."}</p>
 {active?<details className="mt-4"><summary className="settings-edit-action cursor-pointer">Modifier la valeur</summary><ValueEditor kind={kind} contractId={contractId}/></details>:null}
 <details className="mt-4"><summary className="min-h-11 cursor-pointer py-2 font-semibold">Historique des valorisations individuelles ({observations.length})</summary>
 <p className="my-2 text-xs text-[var(--app-muted)]">Les sources communes PEG/PER restent communes dans le graphique ; elles ne sont pas éditables comme valeurs individuelles.</p>
 {[...observations].reverse().map(e=><article key={e.ref} className="border-t border-[var(--app-border)] py-3"><p>{e.date} · BRUT {money(e.gross)}{kind==="peg"?<> · NET {money(e.net)}</>:null} · version {e.version}</p><p className="break-words text-xs text-[var(--app-muted)]">{e.provenance}</p>{active?<details className="mt-2"><summary className="settings-edit-action cursor-pointer">Modifier cette observation</summary><ValueEditor kind={kind} contractId={contractId} initial={e}/></details>:null}</article>)}
 <details className="mt-3"><summary className="min-h-11 cursor-pointer py-2">Anciennes preuves ({archives.length})</summary>{archives.map(e=><p className="break-words border-t border-[var(--app-border)] py-2 text-xs" key={e.ref}>{e.date} · BRUT {money(e.gross)}{kind==="peg"?<> · NET {money(e.net)}</>:null} · {e.provenance} · remplacée, non additive</p>)}</details>
 </details></section>;
}
