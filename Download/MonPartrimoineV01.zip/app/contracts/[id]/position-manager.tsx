"use client";
import { AmountObservationForm } from "./amount-observation-form";
import { EuroFundForm } from "./euro-fund-form";
import { HoldingObservationForm } from "./holding-observation-form";
import { InitialCtoPositionDisclosure } from "./initial-cto-position-disclosure";
import { InitialPositionForm, type AvailablePositionAsset } from "./initial-position-form";

import Link from "next/link";
import { useActionState, useId, useRef, useState, type ReactNode } from "react";
import { useCollapseOnSuccess } from "@/app/components/use-collapse-on-success";
import { CreationDisclosure } from "@/app/components/creation-disclosure";
import { formatMoney, formatPercentage, formatSignedMoney } from "@/lib/cash/money";
import type { ContractPositionView } from "@/lib/contracts/contract-details";
import type { PositionActionState } from "@/lib/contracts/contract-detail-core";
import { savePositionAction } from "./actions";


function formatNumber(value: number | string, maximumFractionDigits = 8) {
  return new Intl.NumberFormat("fr-FR", { maximumFractionDigits }).format(Number(value));
}

function formatHistoryQuantity(value: string) {
  return value.replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "");
}

function PositionQuantityHistory({ position }: { position: ContractPositionView }) {
  const entries = [...new Map([
    ...(position.observations ?? []),
    ...(position.archivedObservations ?? []).flatMap(archive => archive.entries),
  ].map(entry => [`${entry.id}:${entry.version}`, entry])).values()]
    .sort((a, b) => b.effectiveOn.localeCompare(a.effectiveOn));
  const undated = (position.archivedObservations ?? []).flatMap(archive => archive.undatedPrevious ? [archive.undatedPrevious] : []);
  const costLabel = (entry: { unitCost: string | null; currency: string }) => entry.unitCost == null ? "Inconnu" : formatMoney(entry.unitCost, entry.currency, "code");
  return <details className="mt-4">
    <summary className="cursor-pointer py-2">Historique quantité / PRU / date ({entries.length})</summary>
    {entries.map(entry => <p key={`${entry.id}:${entry.version}`} className="border-t border-[var(--app-border)] py-3 text-sm">
      {entry.effectiveOn.split("-").reverse().join("-")} - Quantité : {formatHistoryQuantity(entry.quantity)} - PRU : {costLabel(entry)}
    </p>)}
    {!entries.length ? <p className="text-sm">Position courante non datée. Aucune date de détention passée n’est déduite.</p> : null}
    {undated.map((entry, index) => <p key={index} className="border-t border-[var(--app-border)] py-3 text-sm">Date inconnue - Quantité : {formatHistoryQuantity(entry.quantity)} - PRU : {costLabel(entry)}</p>)}
    <p className="mt-2 text-xs">{position.protectedObservationDates ?? 0} date(s) protégée(s), non remplacée(s). Les valorisations/NET insuffisants restent signalés dans les graphiques. {position.observationArchives ?? 0} état(s) précédent(s) conservé(s). Les preuves de captures sont distinctes des observations saisies.</p>
  </details>;
}

function formatPriceTimestamp(value: string | null) {
  if (!value || !Number.isFinite(Date.parse(value))) return "—";
  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit", hourCycle: "h23", timeZone: "Europe/Paris",
  }).format(new Date(value));
}

function PositionForm({ contractId, operation, positionId, children, submit, onSuccess, triggerId }: { contractId: string; operation: "create" | "update" | "delete"; positionId?: string; children: ReactNode; submit: string; onSuccess?: () => void; triggerId?: string }) {
  const [state, action, pending] = useActionState(savePositionAction, { status: "idle" } as PositionActionState);
  const ref = useCollapseOnSuccess(state, pending, Boolean(onSuccess), onSuccess);
  return <form ref={ref} data-edit-trigger={triggerId} action={action} className="grid gap-4">
    <input type="hidden" name="contract_id" value={contractId} />
    <input type="hidden" name="operation" value={operation} />
    {positionId ? <input type="hidden" name="position_id" value={positionId} /> : null}
    <fieldset disabled={pending} className="grid gap-4">
      {children}
      <button type="submit" className="settings-primary-button">{pending ? "Enregistrement…" : submit}</button>
    </fieldset>
    {state.message ? <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p> : null}
  </form>;
}

function PositionEditor({ contractId, contractActive, position,currencies,securities=false,ctoAcquisition=false }: { ctoAcquisition?:boolean; securities?:boolean; contractId: string; contractActive: boolean; position: ContractPositionView;currencies:{code:string}[] }) {
  const [open, setOpen] = useState(false);
  const panelId = useId();
  const opening = useRef(0);
  const session = opening.current;
  const closeSaved = () => {
    if (opening.current !== session) return;
    const restoreFocus = document.getElementById(panelId)?.contains(document.activeElement);
    setOpen(false);
    if (restoreFocus) requestAnimationFrame(() => document.getElementById(`${panelId}-trigger`)?.focus());
  };
  return <>
    <button id={`${panelId}-trigger`} type="button" aria-expanded={open} aria-controls={panelId} onClick={() => { opening.current++; setOpen((current) => !current); }} className="settings-edit-action" style={open ? undefined : { background: "linear-gradient(180deg, var(--app-gold-light), var(--app-gold))", borderColor: "var(--app-gold-dark)", color: "var(--app-on-gold)" }}>
      Modifier
    </button>
    {!open&&position.euroFund?<div className="basis-full mt-3 text-sm"><p className="text-[var(--app-muted)]">Valeur courante</p><p className="font-semibold">{position.marketValueEur!==null?formatMoney(position.marketValueEur,"EUR"):position.marketValue!==null&&position.currentPriceCurrency?<>{formatMoney(position.marketValue,position.currentPriceCurrency)} · Conversion EUR indisponible</>:"Valorisation indisponible"}</p></div>:null}
    {open ? <div id={panelId} className="mt-3 basis-full border-t border-[var(--app-border)] pt-3">
      {!contractActive?<p className="text-sm">Réactivez le contrat avant de modifier cette position.</p>:position.amountTrackingConflict?<p role="status">Suivi en montant et observations de quantité concurrents. Modification suspendue : une réconciliation ciblée des preuves est nécessaire. Aucun montant n’est supprimé.</p>:securities&&position.amountTracked?<p role="status">Ce support ancien est suivi en montant, sans quantité native qualifiée. Ses sources sont conservées ; aucune suppression ni conversion automatique en titres. Une règle de transition propre à ce support est nécessaire avant correction.</p>:position.euroFund?<><EuroFundForm key={position.id} positionId={position.id} revision={position.updatedAt??""} currencies={currencies} onSaved={closeSaved}/><details className="mt-4"><summary className="cursor-pointer py-2">Historique</summary>{[...(position.amountObservations??[]).map(e=>({...e,replaced:false})),...(position.amountArchived??[]).map(e=>({...e,replaced:true}))].sort((a,b)=>b.date.localeCompare(a.date)).map((e,i)=><p key={e.id+":"+i} className="border-b border-[var(--app-border)] py-3">{new Intl.DateTimeFormat("fr-FR",{timeZone:"Europe/Paris"}).format(new Date(e.date+"T12:00:00Z"))} · {formatMoney(e.amount,e.currency,"code")}{e.replaced?" · Version remplacée":""}</p>)}{!position.amountObservations?.length&&!position.amountArchived?.length?<p>Aucune valorisation enregistrée.</p>:null}</details></>:position.amountEditable?<><AmountObservationForm positionId={position.id} currencies={currencies}/><details className="mt-4"><summary>Valorisations totales datées</summary>{position.amountObservations?.map(e=><details key={e.id} className="mt-3"><summary>{e.date} · {formatMoney(e.amount,e.currency)}</summary><AmountObservationForm key={`${e.id}:${e.date}:${e.amount}:${e.currency}:save`} positionId={position.id} currencies={currencies} initial={e}/><AmountObservationForm key={`${e.id}:${e.date}:${e.amount}:${e.currency}:delete`} positionId={position.id} currencies={currencies} initial={e} operation="delete"/></details>)}</details></>:contractActive ? <><HoldingObservationForm initialNativeTotal={position.acquisitionFx?.quantity&&Number(position.acquisitionFx.quantity)===Number(position.quantity)?position.acquisitionFx.nativeTotal:undefined} costEffectiveOn={position.acquisitionFx?.effectiveOn??position.observationDate??undefined} ctoAcquisition={ctoAcquisition} key={securities?position.id:position.updatedAt} direct={securities} onSaved={securities ? closeSaved : undefined} expectedUpdatedAt={position.updatedAt} contractId={contractId} assetId={position.assetId} positionId={position.id} currencies={currencies} quantity={position.quantity} unitCost={position.averageCostPerUnit} currency={position.costCurrencyCode}/><PositionQuantityHistory position={position}/></>
        : <p className="text-sm text-[var(--app-muted)]">Réactivez le contrat avant de modifier cette position.</p>}
      {!position.amountTracked&&!position.amountTrackingConflict&&!position.observations?.length?<details className="mt-3 border-t border-[var(--app-border)] pt-3">
        <summary className="cursor-pointer py-2 text-sm">Supprimer la position</summary>
        <PositionForm contractId={contractId} operation="delete" positionId={position.id} submit="Supprimer uniquement la position">
          <label className="flex items-start gap-2 text-sm"><input type="checkbox" name="confirm" required className="mt-1" />Je confirme la suppression de cette position. L’actif sera conservé.</label>
        </PositionForm>
      </details>:!position.amountTracked&&!position.amountTrackingConflict?<p className="mt-3 text-xs">Pour terminer la détention, saisissez une nouvelle observation à zéro. Pour un rachat, saisissez le nouveau total.</p>:null}
    </div> : null}
  </>;
}

export function PositionManager({ contractId, contractActive, positions, availableAssets,currencies,securities=false,ctoAcquisition=false }: { ctoAcquisition?:boolean; securities?:boolean; currencies:{code:string}[]; contractId: string; contractActive: boolean; positions: ContractPositionView[]; availableAssets: AvailablePositionAsset[] }) {
  let positionColumns = "sm:grid-cols-6";
  if (ctoAcquisition) {
    positionColumns = "sm:grid-cols-6 lg:grid-cols-7 lg:gap-x-2";
  } else if (securities) {
    positionColumns = "lg:grid-cols-5 lg:gap-x-2";
  }

  return <section className="mt-8">
    <h2 className="text-xl font-semibold">Positions ({positions.length})</h2>
    {!positions.length ? <p className="mt-4 text-sm text-[var(--app-muted)]">Aucune position dans ce contrat.</p> : null}
    <div className="mt-4 grid gap-4">
      {positions.map((position) => <article key={position.id} className="settings-card min-w-0">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <Link href={position.amountEditable||position.amountTrackingConflict?"/assets":`/assets/${position.assetId}/prices`} className="font-semibold text-[var(--app-gold)] underline-offset-4 hover:underline">{position.assetName}{position.symbol ? ` · ${position.symbol}` : ""}</Link>
          <PositionEditor ctoAcquisition={ctoAcquisition} securities={securities} contractId={contractId} contractActive={contractActive} position={position} currencies={currencies} />
        </div>
        {!position.euroFund?<p className="mt-2 text-xs text-[var(--app-muted)]">{position.amountTracked?"Suivi en montant daté":position.observationDate?`Situation maintenue depuis le ${position.observationDate}`:"Position courante non datée"}{!position.amountTracked&&Number(position.quantity)===0?" · Détention terminée":""}</p>:null}
        {!position.euroFund && !position.amountTracked && position.currentPrice !== null ? <p className="mt-1 text-xs text-[var(--app-muted)]">
          {position.currentPriceAt && Number.isFinite(Date.parse(position.currentPriceAt))
            ? <>Cours du <time dateTime={position.currentPriceAt}>{new Intl.DateTimeFormat("fr-FR", { dateStyle: "short", timeZone: "Europe/Paris" }).format(new Date(position.currentPriceAt))}</time></>
            : "Cours de date inconnue"}
          {position.priceSource ? <> fourni par {position.priceSource}</> : null}
        </p> : null}
        {!position.euroFund && position.priceRefreshFailed ? <p className="mt-1 text-xs text-amber-600 dark:text-amber-400">Actualisation échouée. Dernier cours connu conservé.</p> : null}
        {!position.euroFund?<dl className={`mt-3 grid grid-cols-2 gap-x-3 gap-y-2 text-sm min-[480px]:grid-cols-3 ${positionColumns}`}>
          {!position.amountTracked ? <div className="min-w-0"><dt className="text-[var(--app-muted)]">Quantité</dt><dd className="tabular-nums">{formatNumber(position.quantity)}</dd></div> : null}
          <div className="min-w-0"><dt className="text-[var(--app-muted)]">Montant</dt><dd className="font-semibold">{position.marketValueEur === null ? position.marketValue === null ? "Valorisation indisponible" : "Conversion EUR indisponible" : formatMoney(position.marketValueEur, "EUR")}</dd></div>
          {!position.euroFund?<><div className="min-w-0"><dt className="text-[var(--app-muted)]">{ctoAcquisition ? "PRU EUR" : "PRU"}</dt><dd>{position.amountTracked ? "Non applicable" : ctoAcquisition ? position.historicalPruEur ? <>{formatMoney(position.historicalPruEur.unitEur, "EUR")}{position.historicalPruEur.basis === "documented" ? " (documenté)" : position.historicalPruEur.basis === "estimated" ? " (estimé)" : ""}</> : "Indisponible" : position.averageCostPerUnit === null ? "Non renseigné" : position.averageCostPerUnitEur == null ? "Conversion EUR indisponible" : formatMoney(position.averageCostPerUnitEur, "EUR")}</dd></div>
          {ctoAcquisition && !position.amountTracked ? <>
            <div><dt className="text-[var(--app-muted)]">PRU natif</dt><dd>{formatMoney(position.averageCostPerUnit, position.costCurrencyCode, "code")}</dd></div>
            <div><dt className="text-[var(--app-muted)]">Coût total</dt><dd>{position.acquisitionCostEur == null ? "Indisponible" : formatMoney(position.acquisitionCostEur, "EUR")}</dd></div>
          </> : null}
          <div className="min-w-0">
            <dt className="text-[var(--app-muted)]">Cours utilisé</dt>
            <dd>{position.amountTracked ? "Non applicable" : position.currentPriceEur == null ? position.currentPrice === null ? "Prix indisponible" : "Conversion EUR indisponible" : formatMoney(position.currentPriceEur, "EUR")}</dd>
          </div>
          <div className="min-w-0"><dt className="text-[var(--app-muted)]">{position.amountTracked?"Gain du support":"+/- Latentes"}</dt><dd className={position.unrealizedGainEur === null ? "" : position.unrealizedGainEur < 0 ? "text-red-500" : position.unrealizedGainEur > 0 ? "text-emerald-500" : ""}>{position.unrealizedGainEur === null ? "Indisponible" : <>{formatSignedMoney(position.unrealizedGainEur, "EUR")}{position.unrealizedGainPercentage === null ? "" : ` (${formatPercentage(position.unrealizedGainPercentage, true).replace(/^-/u, "\u2212")})`}</>}</dd></div>
          </>:null}{!position.euroFund && (position.amountTracked || position.currentPrice === null && position.currentPriceAt) ? <div className="min-w-0"><dt className="text-[var(--app-muted)]">Date de valorisation</dt><dd>{formatPriceTimestamp(position.currentPriceAt)}</dd></div> : null}
        </dl>:null}
        {position.ctoCostConflict ? <p role="alert" className="mt-2 text-sm text-amber-500">Les preuves de coût CTO se contredisent.</p> : null}
        {position.acquisitionFx?.label?<p className="mt-2 text-xs text-[var(--app-muted)]">{position.acquisitionFx.label}</p>:null}
        {position.brokerCost?.status === "unavailable" ? <p className="mt-2 text-xs text-[var(--app-muted)]">Preuve de coût courtier incomplète ou divergente : coût EUR et gains latents indisponibles.</p> : position.brokerCost?.status === "not_applicable" ? <p className="mt-2 text-xs text-[var(--app-muted)]">Référence courtier non applicable à ce PRU : règles natives conservées.</p> : null}
        {position.amountTracked&&!position.euroFund?<p className="mt-2 text-xs text-[var(--app-muted)]">Suivi en montant daté. Gain du support indisponible : flux et arbitrages non attribués à ce support. Le gain du contrat reste distinct.</p>:null}
      </article>)}
    </div>
    {contractActive ? <div className="mt-6">{ctoAcquisition?<InitialCtoPositionDisclosure contractId={contractId} assets={availableAssets} currencies={currencies}/>:<CreationDisclosure title="Ajouter une position" description="Sélectionnez un actif existant ; aucun nouvel actif ne sera créé.">
      {availableAssets.length ? <InitialPositionForm direct={securities} contractId={contractId} currencies={currencies} assets={availableAssets}/> : <p className="text-sm text-[var(--app-muted)]">Tous les actifs sont déjà présents dans ce contrat. <Link href="/assets" className="font-semibold text-[var(--app-gold)] underline-offset-4 hover:underline">Créer un nouvel actif</Link></p>}
    </CreationDisclosure>}</div> : <p className="mt-6 text-sm text-[var(--app-muted)]">Réactivez le contrat pour ajouter ou modifier une position.</p>}
  </section>;
}
