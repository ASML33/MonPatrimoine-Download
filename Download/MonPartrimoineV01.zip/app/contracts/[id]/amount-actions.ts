"use server";
import {getCurrentProfile} from "@/lib/auth/profile";
import {createClient} from "@/lib/supabase/server";
import {isUuid} from "@/lib/assets/asset-core";
import {revalidatePath} from "next/cache";
export type AmountState={status:"idle"|"preview"|"success"|"error";message?:string;token?:string;request?:{position:string;snapshot:string;date:string;amount:string;currency:string;operation:string}};
export async function editAmountObservation(_state:AmountState,form:FormData):Promise<AmountState>{
 try{
  const user=await getCurrentProfile();if(user.status!=="active")throw Error("Session requise.");
  const request={position:String(form.get("position_id")??""),snapshot:String(form.get("snapshot_id")??""),date:String(form.get("date")??""),amount:String(form.get("amount")??"").trim().replace(",","."),currency:String(form.get("currency")??""),operation:String(form.get("operation")??"save")};
  if(!isUuid(request.position)||request.snapshot&&!isUuid(request.snapshot)||!["save","delete"].includes(request.operation)||request.operation==="save"&&(!/^\d{4}-\d{2}-\d{2}$/.test(request.date)||!/^\d{1,16}(\.\d{1,8})?$/.test(request.amount)||! /^[A-Z]{3}$/.test(request.currency)))throw Error("Observation invalide.");
  const confirmed=form.get("phase")==="confirm";if(confirmed&&form.get("confirm")!=="on")throw Error("Confirmez les valeurs et les limites.");
  const client=await createClient();
  const r=await client.rpc("edit_amount_observation",{requested_position:request.position,requested_snapshot:request.snapshot||null,requested_date:request.operation==="delete"?null:request.date,requested_amount:request.operation==="delete"?null:request.amount,requested_currency:request.currency,requested_operation:request.operation,expected_token:confirmed?String(form.get("token")??""):null,confirmed});
  if(r.error||!r.data)throw Error(r.error?.code==="40001"?"L’état a changé. Recommencez l’aperçu.":"Observation refusée : vérifiez la date, la devise et le suivi en montant. La dernière preuve ne peut pas être supprimée.");
  if(!confirmed)return{status:"preview",token:r.data.token,request};
  for(const path of ["/contracts","/contracts/[id]","/reports","/reports/history","/patrimony","/"])if(path.includes("[id]"))revalidatePath(path,"page");else revalidatePath(path);
  return{status:"success",message:"Valorisation mise à jour. Version précédente conservée. Aucun versement ni mouvement d’espèces créé."};
 }catch(e){return{status:"error",message:e instanceof Error?e.message:"Valorisation indisponible."};}
}
