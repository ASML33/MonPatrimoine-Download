"use server";

import { isContractInUserScope } from "@/lib/contracts/contract-scope";

import { revalidatePath } from "next/cache";
import { getCurrentProfile } from "@/lib/auth/profile";
import { createClient } from "@/lib/supabase/server";
import { isUuid } from "@/lib/assets/asset-core";
import { parisLocalDateTimeToIso } from "@/lib/cash/cash-core";
import { validateManualSituation } from "@/lib/patrimony/manual-situation-core";

export async function saveManualSituation(_previous: { status?: string; message: string }, form: FormData) {
  const current = await getCurrentProfile();
  if (current.status !== "active") return { status: "error", message: "Connectez-vous avec le compte autorisé." };
  const id = String(form.get("contract_id") ?? "");
  if (!isContractInUserScope(id) || !isUuid(id)) return { status: "error", message: "Contrat invalide." };
  let values, situatedAt;
  try {
    values = validateManualSituation(form);
    situatedAt = parisLocalDateTimeToIso(String(form.get("situated_at") ?? ""));
    if (Date.parse(situatedAt) > Date.now()) throw new Error("La date de situation ne peut pas être future.");
  } catch (error) { return { status: "error", message: error instanceof Error ? error.message : "Situation invalide." }; }
  const client = await createClient();
  const result = await client.rpc("save_contract_manual_situation", {
    requested_contract: id, requested_situated_at: situatedAt, requested_gross: values.gross,
    requested_gain: values.gain, requested_source_net: values.sourceNet,
    requested_source: "Situation saisie manuellement", requested_ps_rate: values.rate,
  });
  if (result.error) return { status: "error", message: "Situation non enregistrée. Vérifiez la disponibilité du module et les données." };
  for (const path of [`/contracts/${id}`, "/", "/reports", "/patrimony"]) revalidatePath(path);
  return { status: "success", message: "Situation et hypothèse personnelle enregistrées." };
}
