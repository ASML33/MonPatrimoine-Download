import {PropertyManager} from "./property-manager";
import { EmployeeSavingsValueForm } from "./manual-situation-form";
import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { DashboardHeader } from "@/app/components/dashboard-header";
import { getPageProfile } from "@/lib/auth/render-context";
import { formatParisLocalInput } from "@/lib/cash/cash-core";
import { formatContractPriceRetrievalTimestamp } from "@/lib/contracts/contract-detail-core";
import { getContractDetail } from "@/lib/contracts/contract-details";
import { asSettingsRecord, readProfileSettings } from "@/lib/settings/settings-core";
import { readThemePreference } from "@/lib/theme/theme-core";
import { PositionManager } from "./position-manager";
import { CashManager } from "./cash-manager";
import { SessionPatrimonyCharts } from "@/app/components/navigation-session";
import { getPageNavigationStamp } from "@/lib/navigation/stamp";
import { withNavigationReadScope } from "@/lib/navigation/read-scope";
import { randomUUID } from "node:crypto";

export const dynamic = "force-dynamic";

export default async function ContractDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { current, documents } = await getPageProfile();
  if (current.status === "unauthenticated") redirect("/login");
  if (current.status !== "active") redirect("/");
  const { id } = await params;
  const [detail,stamp] = await withNavigationReadScope(()=>Promise.all([
    getContractDetail(id, current.profile.auth_user_id).catch(() => null),
    getPageNavigationStamp(current.profile.auth_user_id).catch(() => null),
  ]));
  if (!detail) notFound();
  const theme = readThemePreference(asSettingsRecord(documents.interface_preferences));
  const settings = readProfileSettings(documents);
  const { contract } = detail;
  return <div data-theme={theme} className="min-h-screen bg-[var(--app-background)] text-[var(--app-foreground)]">
    <DashboardHeader nickname={current.profile.nickname} displayName={settings.displayName} theme={theme} />
    <main className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
      <Link href="/contracts" className="text-sm font-semibold text-[var(--app-gold)]">← Retour aux contrats</Link>
      <header className="mt-5">
        <h1 className="text-3xl font-bold sm:text-4xl">{contract.name}</h1>
        <p className="mt-2 text-sm text-[var(--app-muted)]">{contract.envelopeTypeLabel} · {contract.institutionName ?? "Établissement non renseigné"}</p>
      </header>
      <SessionPatrimonyCharts key={contract.id} owner={current.profile.auth_user_id} expectedRevision={stamp?[stamp.session,stamp.revision].join(':'):'unavailable'} validationId={randomUUID()} fixedContractId={contract.id}/>
      {contract.replacedBy?<p className="settings-card mt-6">Contrat source historique remplacé ; preuves conservées. <Link className="text-[var(--app-gold)] underline" href={`/contracts/${contract.replacedBy}`}>Ouvrir le contrat regroupé</Link></p>:detail.manual?.authorized ? detail.manual.available ? <EmployeeSavingsValueForm kind={contract.envelopeTypeCode as "peg"|"per_col"} contractId={contract.id} value={detail.manual.value} observations={detail.manual.observations} archives={detail.manual.archives} active={contract.isActive} /> : <p role="status">Module de situations manuelles indisponible.</p> : <CashManager
        contractId={contract.id}
        contractActive={contract.isActive}
        livretAForm={contract.envelopeTypeCode === "epargne_liquide" && contract.sourceKey === "livret_a"}
        currencies={detail.currencies}
        balances={detail.cashBalances}
        flows={detail.cashFlows}
        cashRevision={detail.cashRevision}
        currencySummaries={detail.currencySummaries}
        lastFlowCurrencyCode={detail.lastFlowCurrencyCode}
        defaultDateTime={formatParisLocalInput()}
        contributionCorrections={detail.contributionCorrections}
        contributionRevision={detail.contributionRevision}
        displayedContributionsEur={detail.displayedContributionsEur}
        contractGain={detail.gain}
        totalValueEur={detail.totalValueEur}
        unrealizedGainEur={detail.unrealizedGainEur}
        unrealizedGainPercentage={detail.unrealizedGainPercentage}
        valuedUnrealizedPositions={detail.valuedUnrealizedPositions}
        incompleteUnrealizedPositions={detail.incompleteUnrealizedPositions}
        incompletePositions={detail.incompletePositions}
        incompleteCashBalances={detail.incompleteCashBalances}
        incompleteContributionFlows={detail.incompleteContributionFlows}
        incompleteNetCashFlows={detail.incompleteNetCashFlows}
        envelopeTypeCode={contract.envelopeTypeCode}
        knownTotalContributionsEur={detail.knownTotalContributionsEur}
        knownTotalContributionsAsOf={detail.knownTotalContributionsAsOf}
        knownNetCashFlowsEur={detail.knownNetCashFlowsEur}
        estimationVariationEur={detail.estimationVariationEur}
        estimationVariationPercentage={detail.estimationVariationPercentage}
        initialEstimationAt={detail.initialEstimationAt}
      />}
      <dl className="mt-6 grid gap-3 border border-[var(--app-border)] bg-[var(--app-surface)] p-5 text-sm sm:grid-cols-2 lg:grid-cols-4">
        <div><dt className="text-[var(--app-muted)]">Type d’enveloppe</dt><dd>{contract.envelopeTypeLabel}</dd></div>
        <div><dt className="text-[var(--app-muted)]">Ouverture</dt><dd>{contract.openedOn ? new Intl.DateTimeFormat("fr-FR").format(new Date(`${contract.openedOn}T00:00:00`)) : "Non renseignée"}</dd></div>
        <div><dt className="text-[var(--app-muted)]">{detail.currencySummaries.length > 1 ? "Devises" : "Devise"}</dt><dd>{detail.currencySummaries.map((summary) => summary.currencyCode).join(" · ")}</dd></div>
        <div><dt className="text-[var(--app-muted)]">Date d’actualisation</dt><dd>{formatContractPriceRetrievalTimestamp(detail.valuationUpdatedAt)}</dd></div>
      </dl>
      {!contract.replacedBy && contract.envelopeTypeCode==="immobilier"?<PropertyManager contractId={contract.id} positions={detail.positions} assets={detail.availableAssets} currencies={detail.currencies} active={contract.isActive} sources={contract.propertySources}/>:null}
      {!contract.replacedBy && !detail.manual?.authorized && !["immobilier","epargne_liquide"].includes(contract.envelopeTypeCode) ? <PositionManager ctoAcquisition={["cto","compte_titres"].includes(contract.envelopeTypeCode)} securities={["pea","pea_pme","cto","compte_titres"].includes(contract.envelopeTypeCode)} contractId={contract.id} contractActive={contract.isActive} positions={detail.positions} availableAssets={detail.availableAssets} currencies={detail.currencies} /> : null}
    </main>
  </div>;
}
