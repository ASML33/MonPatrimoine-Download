"use client";
import { useRef, useState } from "react";
import Link from "next/link";
import { DisclosureCard } from "@/app/components/creation-disclosure";
import { InitialPositionForm, type AvailablePositionAsset } from "./initial-position-form";

export function InitialCtoPositionDisclosure({contractId,assets,currencies}:{contractId:string;assets:AvailablePositionAsset[];currencies:{code:string}[]}){
 const [open,setOpen]=useState(false),opening=useRef(0),container=useRef<HTMLDivElement>(null),session=opening.current;
 const closeSaved=()=>{if(opening.current!==session)return;opening.current++;setOpen(false);container.current?.querySelector<HTMLButtonElement>("button")?.focus();};
 return <div ref={container} data-creation-disclosure><DisclosureCard title="Ajouter une position" description="Sélectionnez un actif existant ; aucun nouvel actif ne sera créé." open={open} onToggle={()=>{opening.current++;setOpen(v=>!v);}}>
  {open?assets.length?<InitialPositionForm direct ctoAcquisition onSaved={closeSaved} contractId={contractId} assets={assets} currencies={currencies}/>:<p className="text-sm text-[var(--app-muted)]">Tous les actifs sont déjà présents dans ce contrat. <Link href="/assets" className="font-semibold text-[var(--app-gold)] underline-offset-4 hover:underline">Créer un nouvel actif</Link></p>:null}
 </DisclosureCard></div>;
}
