"use client";
import { LifeInsuranceFlowPanel } from "./life-insurance-flow-panel";
import { saveLifeInsuranceCumulativeAction } from "./life-insurance-actions";
import { ContributionCorrectionPanel } from "./contribution-correction-panel";
import type { ContributionHistory } from "@/lib/cash/contribution-corrections";
import { SecuritiesCashPanel } from "./securities-cash-panel";
import type {HistoricalContractGain} from "@/lib/patrimony/chart-core";

import { calculateCashFlowAggregates } from "@/lib/cash/cash-core";
import { linksFlowsToCash, type CashRevision } from "@/lib/cash/flow-cash";

import { useActionState, useCallback, useEffect, useId, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { useCollapseOnSuccess } from "@/app/components/use-collapse-on-success";
import { useSavedPanelAction } from "@/app/components/use-saved-panel-action";
import type { CashActionState, ContractCurrencySummary } from "@/lib/cash/cash-core";
import { formatMoney, formatPercentage } from "@/lib/cash/money";
import type { ContractCashBalanceView, ContractCashFlowView, SupportedCurrency } from "@/lib/contracts/contract-details";
import { refreshContractFxAction, saveCashBalanceAction, saveCashFlowAction, saveLiquidSavingsTotalAction } from "./cash-actions";

const inputClass = "settings-input min-w-0";
const labelClass = "grid gap-2 text-sm font-medium";

function dateTime(value: string) {
  return new Intl.DateTimeFormat("fr-FR", { dateStyle: "short", timeStyle: "short", timeZone: "Europe/Paris" }).format(new Date(value));
}

function CurrencySelect({ currencies, value, initialValue, onChange }: { currencies: SupportedCurrency[]; value: string; initialValue?: string; onChange?: (value: string) => void }) {
  const display = typeof Intl.DisplayNames === "function" ? new Intl.DisplayNames(["fr"], { type: "currency" }) : null;
  return <label className={labelClass}>Devise *
    <select className={inputClass} name="currency_code" defaultValue={initialValue ?? value} onChange={(event) => onChange?.(event.target.value)} required>
      {!value ? <option value="" disabled>Sélectionner…</option> : null}
      {currencies.map((currency) => <option key={currency.code} value={currency.code}>{currency.code} · {display?.of(currency.code) ?? currency.code}</option>)}
    </select>
  </label>;
}

function ManualFxFields() {
  return <details className="border-t border-[var(--app-border)] pt-3">
    <summary className="cursor-pointer py-2 text-sm text-[var(--app-gold)]">Taux FX manuel de référence</summary>
    <div className="grid gap-3 pt-2">
      <p className="text-xs text-[var(--app-muted)]">Utilisez ce recours uniquement si les sources automatiques ne couvrent durablement pas la devise. Le taux représente des euros pour une unité de devise native.</p>
      <label className={labelClass}>Taux EUR pour 1 unité
        <input className={inputClass} name="manual_fx_rate" inputMode="decimal" pattern="[0-9]+([.,][0-9]{1,8})?" />
      </label>
      <label className="flex items-start gap-2 text-sm"><input type="checkbox" name="confirm_manual_fx" className="mt-1" />Je confirme qu’il s’agit du taux de référence MonPatrimoine pour cette date.</label>
    </div>
  </details>;
}

function ActionForm({ action, operation, contractId, itemId, children, submit, onSuccess, triggerId, closeImmediately = false, cashRevision }: { action: typeof saveCashBalanceAction | typeof saveCashFlowAction; operation: string; contractId: string; itemId?: { name: "balance_id" | "flow_id"; value: string }; children: ReactNode; submit: string; onSuccess?: () => void; triggerId?: string; closeImmediately?: boolean; cashRevision?: CashRevision[] }) {
  const [state, formAction, pending] = useActionState(action, { status: "idle" } as CashActionState);
  const requestId = useRef<HTMLInputElement>(null);
  const [initialCashRevision] = useState(cashRevision);
  const ref = useCollapseOnSuccess(state, pending, Boolean(onSuccess) && !closeImmediately, onSuccess);
  useLayoutEffect(() => {
    if (!closeImmediately || pending || state.status !== "success") return;
    const form = ref.current;
    if (form?.contains(form.ownerDocument.activeElement) && triggerId) form.ownerDocument.getElementById(triggerId)?.focus();
    onSuccess?.();
  }, [closeImmediately, pending, state, onSuccess, triggerId, ref]);
  return <form ref={ref} data-edit-trigger={triggerId} action={formAction} onSubmitCapture={() => { if (requestId.current && !requestId.current.value) requestId.current.value = crypto.randomUUID(); }} className="grid gap-4">
    <input type="hidden" name="operation" value={operation} />
    <input type="hidden" name="contract_id" value={contractId} />
    {itemId ? <input type="hidden" name={itemId.name} value={itemId.value} /> : null}
    {initialCashRevision ? <><input ref={requestId} type="hidden" name="request_id" defaultValue="" /><input type="hidden" name="expected_balances" value={JSON.stringify(initialCashRevision)} /></> : null}
    <fieldset disabled={pending} className="grid gap-4">
      {children}
      <button type="submit" className="settings-primary-button">{pending ? "Enregistrement…" : submit}</button>
    </fieldset>
    {state.message ? <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p> : null}
  </form>;
}

function BalanceFields({ currencies, defaultDateTime, balance, initialCurrency = "" }: { currencies: SupportedCurrency[]; defaultDateTime: string; balance?: ContractCashBalanceView; initialCurrency?: string }) {
  const resetCurrency = balance?.currencyCode ?? initialCurrency;
  const [currency, setCurrency] = useState(resetCurrency);
  const fields = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const form = fields.current?.closest("form");
    const reset = () => setCurrency(resetCurrency);
    form?.addEventListener("reset", reset);
    return () => form?.removeEventListener("reset", reset);
  }, [resetCurrency]);
  return <>
    {balance && <><input type="hidden" name="expected_updated_at" value={balance.updatedAt ?? ""} /><input type="hidden" name="expected_as_of" value={balance.asOf} /></>}
    <div ref={fields} className="grid items-start gap-4 lg:grid-cols-3">
      <label className={`${labelClass} min-w-0`}>Montant *
        <input className={inputClass} name="amount" inputMode="decimal" pattern="[0-9]+([.,][0-9]{1,8})?" defaultValue={balance?.amount ?? ""} required />
      </label>
      <CurrencySelect currencies={currencies} value={currency} initialValue={resetCurrency} onChange={setCurrency} />
      <label className={`${labelClass} min-w-0`}>Date de situation *
        <input className={inputClass} name="as_of" type="datetime-local" defaultValue={balance?.asOfLocal ?? defaultDateTime} required />
      </label>
    </div>
    <p className="text-xs text-[var(--app-muted)]">Le montant est exprimé dans la devise sélectionnée. Changer la devise ne convertit pas le montant. Une modification corrige cette observation uniquement ; la destination de même devise et jour est remplacée.</p>
    {currency !== "EUR" ? <ManualFxFields /> : null}
  </>;
}

function LiquidSavingsForm({contractId,revision,date,onSaved}:{contractId:string;revision:CashRevision[];date:string;onSaved:()=>void}) {
  const [state,action,pending]=useSavedPanelAction(saveLiquidSavingsTotalAction,{status:"idle"} as CashActionState,onSaved);
  const [amount,setAmount]=useState(""),[effective,setEffective]=useState(date),[expected]=useState(revision);
  return <form action={action} onReset={event=>event.preventDefault()} className="grid gap-3">
    <input type="hidden" name="contract_id" value={contractId}/><input type="hidden" name="expected_balances" value={JSON.stringify(expected)}/>
    <fieldset disabled={pending} className="grid gap-3 sm:grid-cols-2"><label className={labelClass}>Nouveau solde total en EUR<input className={inputClass} name="amount" inputMode="decimal" pattern="[0-9]+([.,][0-9]{1,8})?" value={amount} onChange={event=>setAmount(event.target.value)} required/></label><label className={labelClass}>Date d’effet<input className={inputClass} type="date" name="effective_on" value={effective} onChange={event=>setEffective(event.target.value)} required/></label></fieldset>
    <p className="text-xs text-[var(--app-muted)]">Ce montant remplace le solde total du contrat à partir de la date choisie, y compris les observations ultérieures. Aucun versement ni retrait n’est créé.</p>
    <button className="settings-primary-button justify-self-start" type="submit" disabled={pending}>{pending?"Enregistrement…":"Enregistrer"}</button>
    {state.message?<p role="status" className={state.status==="error"?"text-red-500":"text-[var(--app-muted)]"}>{state.message}</p>:null}
  </form>;
}
function BalanceRow({ contractId, currencies, defaultDateTime, balance }: { contractId: string; currencies: SupportedCurrency[]; defaultDateTime: string; balance: ContractCashBalanceView }) {
  const [open, setOpen] = useState(false);
  const panelId = useId();
  const close = useCallback(() => setOpen(false), []);
  return <article className="border-b border-[var(--app-border)] py-3 last:border-b-0">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div className="min-w-0"><p className="font-semibold text-[var(--app-gold)]">{balance.amountEur === null ? "Conversion EUR indisponible" : formatMoney(balance.amountEur, "EUR")}</p><p className="text-xs text-[var(--app-muted)]">Situation au {dateTime(balance.asOf)} · devise source {balance.currencyCode}</p></div>
      <div className="flex items-center gap-4"><span className="text-sm font-semibold">{balance.amountEur === null ? "Conversion en attente" : formatMoney(balance.amountEur, "EUR")}</span><button id={`${panelId}-trigger`} type="button" aria-expanded={open} aria-controls={panelId} onClick={() => setOpen((current) => !current)} className="settings-edit-action">Modifier</button></div>
    </div>
    {balance.fxSource ? <p className="mt-1 text-xs text-[var(--app-muted)]">Taux {balance.fxSourceLabel} du {balance.fxObservedOn}</p> : null}
    {open ? <div id={panelId} className="mt-3 border-t border-[var(--app-border)] pt-4">
      <ActionForm action={saveCashBalanceAction} operation="update" contractId={contractId} itemId={{ name: "balance_id", value: balance.id }} submit="Enregistrer" triggerId={`${panelId}-trigger`} onSuccess={close}>
        <BalanceFields currencies={currencies} defaultDateTime={defaultDateTime} balance={balance} />
      </ActionForm>
      <details className="mt-3 border-t border-[var(--app-border)] pt-3">
        <summary className="cursor-pointer py-2 text-sm">Supprimer le solde</summary>
        <ActionForm action={saveCashBalanceAction} operation="delete" contractId={contractId} itemId={{ name: "balance_id", value: balance.id }} submit="Supprimer le solde" triggerId={`${panelId}-trigger`} onSuccess={close} closeImmediately>
          <input type="hidden" name="expected_updated_at" value={balance.updatedAt ?? ""} />
          <input type="hidden" name="expected_as_of" value={balance.asOf} />
          <p className="text-xs text-[var(--app-muted)]">Seule l’observation affichée est retirée. Les observations restantes et les captures historiques sont conservées.</p>
          <label className="flex items-start gap-2 text-sm"><input type="checkbox" name="confirm" required className="mt-1" />Je confirme la suppression de cette observation.</label>
        </ActionForm>
      </details>
    </div> : null}
  </article>;
}

function ExpectedFlowRevision({revision}: {revision?: string}) {
  const [original] = useState(revision);
  return <input type="hidden" name="expected_updated_at" value={original ?? ""} />;
}
function FlowFields({ currencies, defaultDateTime, defaultCurrencyCode, flow }: { currencies: SupportedCurrency[]; defaultDateTime: string; defaultCurrencyCode: string; flow?: ContractCashFlowView; linked?: boolean }) {
  return <>
    {flow ? <ExpectedFlowRevision revision={flow.updatedAt} /> : null}
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <label className={labelClass}>Type *
        <select className={inputClass} name="kind" defaultValue={flow?.kind ?? "contribution"} required>
          <option value="contribution">Versement</option>
          <option value="withdrawal">Retrait</option>
        </select>
      </label>
      <label className={labelClass}>Montant *
        <input className={inputClass} name="amount" inputMode="decimal" pattern="[0-9]+([.,][0-9]{1,8})?" defaultValue={flow?.amount ?? ""} required />
      </label>
      <CurrencySelect currencies={currencies} value={flow?.currencyCode ?? defaultCurrencyCode} />
      <label className={labelClass}>Date et heure *
        <input className={inputClass} name="occurred_at" type="datetime-local" defaultValue={flow?.occurredAtLocal ?? defaultDateTime} required />
      </label>
    </div>
    <label className={labelClass}>Commentaire
      <textarea className={`${inputClass} min-h-20 py-3`} name="note" maxLength={500} defaultValue={flow?.note ?? ""} />
    </label>
    {flow?.currencyCode !== "EUR" || !flow ? <ManualFxFields /> : null}
  </>;
}

function FlowRow({ contractId, currencies, defaultDateTime, flow, cashRevision }: { contractId: string; currencies: SupportedCurrency[]; defaultDateTime: string; flow: ContractCashFlowView; cashRevision?: CashRevision[] }) {
  const [open, setOpen] = useState(false);
  const panelId = useId();
  const close = useCallback(() => setOpen(false), []);
  return <article className="border-b border-[var(--app-border)] py-3 last:border-b-0" data-flow-row>
    <div className="grid gap-x-4 gap-y-1 text-sm sm:grid-cols-[minmax(6rem,0.7fr)_minmax(7rem,1fr)_minmax(10rem,2fr)_auto_auto] sm:items-center">
      <span className="font-semibold text-[var(--app-gold)]">{flow.kind === "contribution" ? "Versement" : "Retrait"}</span>
      <span className="font-semibold" title={`Devise source : ${flow.currencyCode}`}>{flow.amountEur === null ? "Conversion EUR indisponible" : formatMoney(flow.amountEur, "EUR")}<span title={flow.amountEur === null ? undefined : `${formatMoney(flow.amountEur, "EUR")}${flow.fxSource ? ` · Taux ${flow.fxSourceLabel} du ${flow.fxObservedOn}` : ""}`} className={`ml-1 text-xs font-normal ${flow.amountEur === null ? "text-amber-500" : "text-[var(--app-muted)]"}`}>· {flow.amountEur === null ? flow.fxStatus === "manual_required" ? "Taux manuel requis" : "Conversion en attente" : "Résolu"}</span></span>
      <span className="min-w-0 break-words text-[var(--app-muted)]">{flow.note || "—"}</span>
      <time dateTime={flow.occurredAt} className="whitespace-nowrap text-[var(--app-muted)] sm:text-right">{dateTime(flow.occurredAt)}</time>
      <button id={`${panelId}-trigger`} type="button" aria-expanded={open} aria-controls={panelId} onClick={() => setOpen((current) => !current)} className="settings-edit-action justify-self-start sm:justify-self-end">Modifier</button>
    </div>
    {open ? <div id={panelId} className="mt-3 border-t border-[var(--app-border)] pt-4">
      <ActionForm action={saveCashFlowAction} operation="update" contractId={contractId} itemId={{ name: "flow_id", value: flow.id }} submit="Enregistrer" triggerId={`${panelId}-trigger`} onSuccess={close} cashRevision={cashRevision}>
        <FlowFields currencies={currencies} defaultDateTime={defaultDateTime} defaultCurrencyCode={flow.currencyCode} flow={flow} linked={flow.cashLinked === true} />
      </ActionForm>
      <details className="mt-3 border-t border-[var(--app-border)] pt-3">
        <summary className="cursor-pointer py-2 text-sm">Supprimer le flux</summary>
        <ActionForm action={saveCashFlowAction} operation="delete" contractId={contractId} itemId={{ name: "flow_id", value: flow.id }} submit="Supprimer le flux" cashRevision={cashRevision}>
          <ExpectedFlowRevision revision={flow.updatedAt} />
          <label className="flex items-start gap-2 text-sm"><input type="checkbox" name="confirm" required className="mt-1" />Je confirme la suppression de ce flux. Le Total versé et le Flux net seront recalculés.</label>
        </ActionForm>
      </details>
    </div> : null}
  </article>;
}

function RefreshFx({ contractId }: { contractId: string }) {
  const [state, action, pending] = useActionState(refreshContractFxAction, { status: "idle" } as CashActionState);
  return <form action={action} className="grid justify-items-start gap-2">
    <input type="hidden" name="contract_id" value={contractId} />
    <button type="submit" disabled={pending} className="settings-primary-button">{pending ? "Actualisation…" : "Actualiser les conversions EUR"}</button>
    {state.message ? <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p> : null}
  </form>;
}

function SummaryButton({ title, panelId, open, onClick, children, command, subdued = false }: { title: string; panelId: string; open: boolean; onClick: () => void; children: ReactNode; command?: string | null; subdued?:boolean }) {
  if (command !== undefined) {
    const inlineCommand = command === "Modifier";
    const heading = <h2 className="text-sm text-[var(--app-muted)]">{title}</h2>;
    const button = command ? <button id={`${panelId}-trigger`} type="button" aria-expanded={open} aria-controls={panelId} onClick={onClick} className={`${subdued?"settings-edit-action":"settings-primary-button"} ${inlineCommand ? "shrink-0" : "mt-4"}`} style={command === "Modifier" ? open ? undefined : {background:"linear-gradient(180deg, var(--app-gold-light), var(--app-gold))",borderColor:"var(--app-gold-dark)",color:"var(--app-on-gold)"} : command === "Gérer les flux" && open ? { background: "transparent", borderColor: "var(--app-border)", color: "var(--app-gold)" } : undefined}>{command}</button> : null;
    return <article className={`settings-card flex h-full min-w-0 ${inlineCommand ? "items-center justify-between gap-3" : "flex-col justify-start"}`}>
      {inlineCommand ? <div className="flex min-w-0 flex-col">{heading}{children}</div> : <>{heading}{children}</>}
      {button}
    </article>;
  }
  return <button id={`${panelId}-trigger`} type="button" aria-expanded={open} aria-controls={panelId} onClick={onClick} className="settings-card flex h-full min-w-0 cursor-pointer flex-col justify-start text-left text-[var(--app-foreground)] transition-colors hover:bg-[var(--app-hover)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)]">
    <span className="flex items-center justify-between gap-3"><span className="text-sm text-[var(--app-muted)]">{title}</span><span aria-hidden="true" className={`text-lg text-[var(--app-gold)] transition-transform ${open ? "rotate-45" : ""}`}>+</span></span>
    {children}
  </button>;
}

export function CashManager({
  contractId, contractActive, currencies, balances, flows, lastFlowCurrencyCode, defaultDateTime, livretAForm = false, cashRevision,
  totalValueEur, contractGain, contributionCorrections, contributionRevision, displayedContributionsEur,
  incompletePositions, incompleteCashBalances, incompleteContributionFlows, incompleteNetCashFlows,
  envelopeTypeCode, knownTotalContributionsEur, knownTotalContributionsAsOf, knownNetCashFlowsEur,
  estimationVariationEur, estimationVariationPercentage, initialEstimationAt,
}: {
  contributionCorrections?:ContributionHistory; contributionRevision?:string; displayedContributionsEur?:number|null;
  contractId: string;
  contractActive: boolean;
  livretAForm?: boolean;
  currencies: SupportedCurrency[];
  balances: ContractCashBalanceView[];
  flows: ContractCashFlowView[];
  cashRevision?: CashRevision[];
  currencySummaries: ContractCurrencySummary[];
  lastFlowCurrencyCode: string | null;
  defaultDateTime: string;
  totalValueEur: number | null;
  contractGain: HistoricalContractGain;
  unrealizedGainEur: number;
  unrealizedGainPercentage: number | null;
  valuedUnrealizedPositions: number;
  incompleteUnrealizedPositions: number;
  incompletePositions: number;
  incompleteCashBalances: number;
  incompleteContributionFlows: number;
  incompleteNetCashFlows: number;
  envelopeTypeCode: string;
  knownTotalContributionsEur: number | null;
  knownTotalContributionsAsOf: string | null;
  knownNetCashFlowsEur: number | null;
  estimationVariationEur: number | null;
  estimationVariationPercentage: number | null;
  initialEstimationAt: string | null;
}) {
  const [openPanel, setOpenPanel] = useState<"cash" | "flows" | "contributions" | null>(null);
  const [addingBalance, setAddingBalance] = useState(false);
  const [addingFlow, setAddingFlow] = useState(false);
  const closeBalanceCreation = useCallback(() => setAddingBalance(false), []);
  const closeFlowCreation = useCallback(() => setAddingFlow(false), []);
  const cashPanelId = useId();
  const flowPanelId = useId();
  const contributionPanelId = useId();

  const flowTotals = calculateCashFlowAggregates(flows);
  const cashTotalEur = balances.reduce((sum,balance) => sum + (balance.amountEur ?? 0), 0);
  const isRealEstate = envelopeTypeCode === "immobilier";
  const isLiquidSavings = envelopeTypeCode === "epargne_liquide";
  const linked = linksFlowsToCash(envelopeTypeCode);
  const lifeInsurance = envelopeTypeCode === "assurance_vie";
  const cumulativePanel = linked || lifeInsurance;
  const flowRevision = linked ? cashRevision ?? balances.filter(b => b.updatedAt).map(b => ({id: b.id, updatedAt: b.updatedAt!})) : undefined;
  const panelOpening = useRef(0);
  const [panelSession,setPanelSession] = useState(0);
  const closeSavedPanel = (panel: "cash" | "contributions" | "flows") => {
    if (panelOpening.current !== panelSession) return;
    const id = panel === "cash" ? cashPanelId : panel === "flows" ? flowPanelId : contributionPanelId;
    const restoreFocus = document.getElementById(id)?.contains(document.activeElement);
    setOpenPanel(current => current === panel ? null : current);
    if (restoreFocus) requestAnimationFrame(() => document.getElementById(`${id}-trigger`)?.focus());
  };
  function togglePanel(panel: "cash" | "flows" | "contributions") {
    panelOpening.current++;
    setPanelSession(panelOpening.current);
    setOpenPanel((current) => current === panel ? null : panel);
    setAddingBalance(false);
    setAddingFlow(false);
  }
  const flowHistory = !flows.length ? <p className="mt-5 text-sm text-[var(--app-muted)]">Aucun versement ou retrait enregistré.</p> : <div className="mt-4">{flows.map((flow) => <FlowRow key={flow.id} contractId={contractId} currencies={currencies} defaultDateTime={defaultDateTime} flow={flow} cashRevision={flowRevision} />)}</div>;
  const changeContent = isRealEstate
    ? estimationVariationEur === null
      ? <p className="mt-2 text-sm font-semibold">Indisponible</p>
      : <p className={`mt-2 flex flex-wrap gap-x-1 font-semibold ${estimationVariationEur > 0 ? "text-emerald-500" : estimationVariationEur < 0 ? "text-red-500" : ""}`}><span>{formatMoney(estimationVariationEur, "EUR")}</span>{estimationVariationPercentage === null ? null : <span>({formatPercentage(estimationVariationPercentage)})</span>}</p>
    : contractGain.amount !== null
      ? <p className={`mt-2 flex flex-wrap items-baseline gap-x-1 font-semibold ${contractGain.amount < 0 ? "text-red-500" : contractGain.amount > 0 ? "text-emerald-500" : ""}`}><span>{formatMoney(contractGain.amount, "EUR")}</span>{contractGain.percentage === null ? null : <span>({formatPercentage(contractGain.percentage)})</span>}</p>
      : <p className="mt-2 text-sm font-semibold">Indisponible</p>;
  return <>
    <section className={`mt-8 grid items-stretch gap-4 sm:grid-cols-2 ${isRealEstate ? "lg:grid-cols-3" : isLiquidSavings ? "lg:grid-cols-1" : lifeInsurance ? "lg:grid-cols-4" : "lg:grid-cols-5"}`}>
      {isLiquidSavings ? <SummaryButton title="Solde" panelId={cashPanelId} open={openPanel === "cash"} onClick={() => togglePanel("cash")} command="Modifier" subdued><span className="mt-2 text-2xl font-bold">{totalValueEur === null ? "Indisponible" : formatMoney(totalValueEur, "EUR")}</span></SummaryButton> : <article className="settings-card flex h-full flex-col justify-start"><h2 className="text-sm text-[var(--app-muted)]">{isRealEstate ? "Estimation" : "Valorisation"}</h2><p className="mt-2 text-2xl font-bold">{totalValueEur === null ? "Indisponible" : formatMoney(totalValueEur, "EUR")}</p>{incompletePositions + incompleteCashBalances ? <p className="mt-2 text-xs text-amber-500">Incomplète : {incompletePositions + incompleteCashBalances} élément(s) sans valorisation EUR.</p> : null}</article>}
      {!isLiquidSavings ? <article className="settings-card flex h-full flex-col justify-start">
        <h2 className="text-sm text-[var(--app-muted)]">{isRealEstate ? "Variation d’estimation" : "Gain du contrat"}</h2>
        {changeContent}
        {isRealEstate ? <p className="mt-2 text-xs text-[var(--app-muted)]">Référence initiale{initialEstimationAt ? ` du ${dateTime(initialEstimationAt)}` : " indisponible"}. Cette variation n’est ni un gain fiscal ni une performance annualisée.</p> : <p className="mt-2 text-xs text-[var(--app-muted)]">{contractGain.missing==="contract_value"?"Valorisation complète du contrat ou conversion EUR manquante.":contractGain.missing==="net_cash_flows"?"Flux externes cumulés manquants ou conversion historique indisponible.":contractGain.missing==="total_contributions"?"Gain connu ; pourcentage indisponible : versements cumulés inconnus.":contractGain.missing==="zero_contributions"?"Pourcentage indisponible : base de versements nulle.":"Valorisation + retraits externes − versements externes. Ratio sur les versements, non annualisé."}</p>}
      </article> : null}
      {isRealEstate ? <article className="settings-card flex h-full flex-col justify-start"><h2 className="text-sm text-[var(--app-muted)]">Estimation</h2><p className="mt-2 font-semibold">{totalValueEur === null ? "Indisponible" : formatMoney(totalValueEur, "EUR")}</p><p className="mt-2 text-xs text-[var(--app-muted)]">Modifiable depuis le bien et son historique d’estimations totales.</p></article> : isLiquidSavings || lifeInsurance ? null : <SummaryButton title="Solde Espèces" panelId={cashPanelId} open={openPanel === "cash"} onClick={() => togglePanel("cash")} subdued={linked} command={linked ? "Modifier le solde" : undefined}>
        <span className="mt-2 grid gap-1">{<span className="font-semibold">EUR : {linked && !balances.length ? "Non renseigné" : linked && balances.every(b=>b.amountEur===null) ? "Indisponible" : formatMoney(cashTotalEur, "EUR")}{incompleteCashBalances ? " (partiel)" : ""}</span>}</span>
      </SummaryButton>}
      {!isRealEstate && !isLiquidSavings ? <SummaryButton title={cumulativePanel?"Cumul des versements":"Total Versé"} panelId={cumulativePanel?contributionPanelId:flowPanelId} open={openPanel === (cumulativePanel?"contributions":"flows")} onClick={() => togglePanel(cumulativePanel?"contributions":"flows")} subdued={cumulativePanel} command={cumulativePanel ? "Modifier le cumul" : undefined}>
        <span className="mt-2 grid gap-1">{cumulativePanel&&displayedContributionsEur!==undefined?<span className="font-semibold">EUR : {displayedContributionsEur===null?"Indisponible":formatMoney(displayedContributionsEur,"EUR")}</span>:knownTotalContributionsEur !== null ? <span className="font-semibold"><span className="text-sm text-[var(--app-muted)]">EUR :</span> {formatMoney(knownTotalContributionsEur, "EUR")}</span> : <span className="font-semibold">EUR : {formatMoney(flowTotals.totalContributionsEur, "EUR")}{incompleteContributionFlows ? " (partiel)" : ""}</span>}</span>
        {knownTotalContributionsEur !== null && !(cumulativePanel&&contributionCorrections?.entries.length) ? <span className="mt-2 block text-xs text-[var(--app-muted)]">Cumul connu{knownTotalContributionsAsOf ? ` au ${new Intl.DateTimeFormat("fr-FR", { timeZone: "Europe/Paris" }).format(new Date(`${knownTotalContributionsAsOf}T12:00:00Z`))}` : " sans date inventée"} · historique des versements incomplet.</span> : null}
        {incompleteContributionFlows ? <span className="mt-2 block text-xs text-amber-500">Conversion EUR incomplète pour certains versements.</span> : null}
      </SummaryButton> : null}
      {!isRealEstate && !isLiquidSavings ? <SummaryButton title="Flux Net" panelId={flowPanelId} open={openPanel === "flows"} onClick={() => togglePanel("flows")} command={cumulativePanel ? "Gérer les flux" : undefined}>
        <span className="mt-2 grid gap-1">{knownNetCashFlowsEur !== null ? <span className="font-semibold"><span className="text-sm text-[var(--app-muted)]">EUR :</span> {formatMoney(knownNetCashFlowsEur, "EUR")}</span> : <span className="font-semibold">EUR : {formatMoney(flowTotals.netCashFlowsEur, "EUR")}{incompleteNetCashFlows ? " (partiel)" : ""}</span>}</span>
        {incompleteNetCashFlows ? <span className="mt-2 block text-xs text-amber-500">Conversion EUR incomplète pour certains flux.</span> : null}
      </SummaryButton> : null}
    </section>

    {isLiquidSavings && openPanel === "cash" ? <section id={cashPanelId} className="mt-4 border border-[var(--app-border)] bg-[var(--app-surface)] p-5 sm:p-6">{contractActive?<LiquidSavingsForm key={`${contractId}:${panelSession}`} contractId={contractId} revision={cashRevision ?? []} date={defaultDateTime.slice(0,10)} onSaved={()=>closeSavedPanel("cash")}/>:<p>Réactivez le contrat avant de modifier son solde.</p>}</section> : null}
    {!linked && !lifeInsurance && !isRealEstate && !isLiquidSavings ? <section id={cashPanelId} hidden={openPanel !== "cash"} className="mt-4 border border-[var(--app-border)] bg-[var(--app-surface)] p-5 sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-4"><div><h2 className="text-xl font-semibold">Gérer les espèces</h2><p className="mt-1 text-sm text-[var(--app-muted)]">Chaque solde conserve son montant et sa devise d’origine.</p></div><RefreshFx contractId={contractId} /></div>
      {!balances.length ? <p className="mt-5 text-sm text-[var(--app-muted)]">Solde espèces : Non renseigné.</p> : <div className="mt-4">{balances.map((balance) => <BalanceRow key={balance.id} contractId={contractId} currencies={currencies} defaultDateTime={defaultDateTime} balance={balance} />)}</div>}
      {contractActive && currencies.length ? <div className="mt-5 border-t border-[var(--app-border)] pt-4">
        <button type="button" aria-expanded={addingBalance} aria-controls={`${cashPanelId}-create`} onClick={() => setAddingBalance((current) => !current)} className="text-sm font-semibold text-[var(--app-gold)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)]">{livretAForm ? "Modifier le solde" : "Ajouter une observation"}</button>
        {addingBalance ? <div id={`${cashPanelId}-create`} className="mt-4"><ActionForm action={saveCashBalanceAction} operation="create" contractId={contractId} submit="Enregistrer le solde" onSuccess={closeBalanceCreation}><BalanceFields currencies={currencies} defaultDateTime={defaultDateTime} initialCurrency={livretAForm ? "EUR" : ""} /></ActionForm></div> : null}
      </div> : null}
    </section> : null}

    {!linked && !lifeInsurance && !isRealEstate && !isLiquidSavings ? <section id={flowPanelId} hidden={openPanel !== "flows"} className="mt-4 border border-[var(--app-border)] bg-[var(--app-surface)] p-5 sm:p-6">
      <div><h2 className="text-xl font-semibold">{linked ? "Gérer les flux" : "Historique des flux"}</h2><p className="mt-1 text-sm text-[var(--app-muted)]">{linked ? "Les nouveaux versements et retraits ajustent les espèces de la même devise à leur date d’effet. Un solde connu et une chronologie réconciliable sont nécessaires. Les anciens flux restent indépendants ; les transferts ne sont pas proposés." : "Les versements et retraits n’ajustent pas automatiquement les soldes espèces ; les transferts ne sont pas proposés."}</p></div>
      {!linked ? flowHistory : null}
      {contractActive ? <div className="mt-5 border-t border-[var(--app-border)] pt-4">
        <button type="button" aria-expanded={addingFlow} aria-controls={`${flowPanelId}-create`} onClick={() => setAddingFlow((current) => !current)} style={linked ? { width: "11rem", maxWidth: "100%" } : undefined} className={linked ? "settings-primary-button" : "text-sm font-semibold text-[var(--app-gold)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--app-gold)]"}>Ajouter un flux</button>
        {addingFlow ? <div id={`${flowPanelId}-create`} className="mt-4"><ActionForm action={saveCashFlowAction} operation="create" contractId={contractId} submit="Enregistrer le flux" onSuccess={closeFlowCreation} cashRevision={flowRevision}><FlowFields currencies={currencies} defaultDateTime={defaultDateTime} defaultCurrencyCode={lastFlowCurrencyCode ?? ""} linked={linked} /></ActionForm></div> : null}
      </div> : <p className="mt-5 text-sm text-[var(--app-muted)]">Le contrat inactif accepte encore la correction ou la suppression de ses flux existants.</p>}
      {linked ? <><h3 className="mt-6 text-lg font-semibold">Historique</h3>{flowHistory}</> : null}
    </section> : null}
    {cumulativePanel&&openPanel==="contributions"?<ContributionCorrectionPanel saveAction={lifeInsurance?saveLifeInsuranceCumulativeAction:undefined} onSaved={() => closeSavedPanel("contributions")} balances={lifeInsurance?[]:flowRevision??[]} key={contractId} contractId={contractId} active={contractActive} revision={contributionRevision??""} history={contributionCorrections??{version:1,entries:[],archived:[]}} date={defaultDateTime.slice(0,10)} panelId={contributionPanelId}/>:null}
    {lifeInsurance&&openPanel==="flows"?<LifeInsuranceFlowPanel onSaved={() => closeSavedPanel("flows")} key={contractId} contractId={contractId} active={contractActive} currencies={currencies} date={defaultDateTime} flows={flows} panelId={flowPanelId}/>:null}
    {linked ? <SecuritiesCashPanel onSaved={() => closeSavedPanel(openPanel === "flows" ? "flows" : "cash")} key={`${contractId}:${openPanel}`} contractId={contractId} active={contractActive} mode={openPanel==="contributions"?null:openPanel} cashPanelId={cashPanelId} flowPanelId={flowPanelId} balances={balances} flows={flows} currencies={currencies} revisions={flowRevision ?? []} date={defaultDateTime}/> : null}
  </>;
}
