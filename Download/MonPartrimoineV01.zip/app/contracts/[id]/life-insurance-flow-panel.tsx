"use client";
import { useRef } from "react";
import { useSavedPanelAction } from "@/app/components/use-saved-panel-action";
import { addLifeInsuranceFlowAction } from "./life-insurance-actions";
import type { CashActionState } from "@/lib/cash/cash-core";
import type { ContractCashFlowView } from "@/lib/contracts/contract-details";
import { formatMoney } from "@/lib/cash/money";
function FlowForm({ contractId, currencies, date, onSaved }: { contractId: string; currencies: { code: string }[]; date: string; onSaved?: () => void }) {
  const resetAllowed=useRef(false);
  const [state, action, pending] = useSavedPanelAction(addLifeInsuranceFlowAction, { status: "idle" } as CashActionState,()=>{resetAllowed.current=true;onSaved?.();}), request = useRef<HTMLInputElement>(null);
  return <form action={action} onReset={e => { if (!resetAllowed.current) e.preventDefault(); else resetAllowed.current=false; }} onSubmitCapture={() => { if (request.current && !request.current.value) request.current.value = crypto.randomUUID(); }} className="grid gap-3">
    <input type="hidden" name="contract_id" value={contractId} /><input type="hidden" name="operation" value="create" /><input ref={request} type="hidden" name="request_id" defaultValue="" />
    <fieldset disabled={pending} className="grid gap-3">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <label className="grid gap-2 text-sm">Type<select className="settings-input" name="kind"><option value="contribution">Versement</option><option value="withdrawal">Retrait</option></select></label>
      <label className="grid gap-2 text-sm">Montant<input className="settings-input" name="amount" inputMode="decimal" required /></label>
      <label className="grid gap-2 text-sm">Devise<select className="settings-input" name="currency_code" defaultValue="EUR">{currencies.map(c => <option key={c.code}>{c.code}</option>)}</select></label>
      <label className="grid gap-2 text-sm">Date d’effet<input className="settings-input" type="date" name="occurred_at" defaultValue={date.slice(0, 10)} required /></label>
      </div>
      <label className="grid gap-2 text-sm">Commentaire<textarea className="settings-input" name="note" maxLength={500} /></label>
    </fieldset>
    <button className="settings-primary-button justify-self-start" style={{ width: "11rem", maxWidth: "100%" }} disabled={pending}>{pending ? "Enregistrement…" : "Enregistrer"}</button>
    {state.message ? <p role="status">{state.message}</p> : null}
  </form>;
}
export function LifeInsuranceFlowPanel({ contractId, active, currencies, date, flows, panelId, onSaved }: { contractId: string; active: boolean; currencies: { code: string }[]; date: string; flows: ContractCashFlowView[]; panelId: string; onSaved?: () => void }) {
  return <section id={panelId} className="mt-4 border border-[var(--app-border)] bg-[var(--app-surface)] p-5 sm:p-6"><h2 className="text-xl font-semibold">Gérer les flux</h2><p className="mt-2 text-sm text-[var(--app-muted)]">Flux externes uniquement. Aucun solde espèces ni support n’est modifié automatiquement.</p>
    {active ? <div className="mt-5 border-t border-[var(--app-border)] pt-4"><FlowForm contractId={contractId} currencies={currencies} date={date} onSaved={onSaved} /></div> : null}
    <details className="mt-6"><summary className="cursor-pointer text-lg font-semibold">Historique</summary>{[...flows].sort((a, b) => b.occurredAt.localeCompare(a.occurredAt)).map(f => <article key={f.id} className="border-b border-[var(--app-border)] py-3">{new Intl.DateTimeFormat("fr-FR", { timeZone: "Europe/Paris" }).format(new Date(f.occurredAt))} · {f.kind === "contribution" ? "Versement" : "Retrait"} · {formatMoney(Number(f.amount), f.currencyCode)}{f.note ? <p>{f.note}</p> : null}</article>)}{!flows.length ? <p className="mt-3">Aucun versement ou retrait enregistré.</p> : null}</details>
  </section>;
}
