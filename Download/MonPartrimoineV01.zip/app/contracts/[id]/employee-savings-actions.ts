"use server";
import {randomUUID} from "node:crypto";
import {getCurrentProfile} from "@/lib/auth/profile";
import {createClient} from "@/lib/supabase/server";
import {isUuid} from "@/lib/assets/asset-core";
import {isContractInUserScope} from "@/lib/contracts/contract-scope";
import {validateEmployeeSavingsValue} from "@/lib/patrimony/employee-savings-values";
import {parisDate} from "@/lib/patrimony/current-valuation-core";
import {revalidatePath} from "next/cache";
export type EmployeeValueState={status:"idle"|"preview"|"error"|"success";message?:string;review?:{token:string;submissionId:string;date:string;gross:string;net:string|null;editedRef:string|null;destination:boolean;moved:boolean;netCleared:boolean;unchanged:boolean;nextDate:string|null;before:{date:string;gross:string;net:string|null}|null}};
export async function saveEmployeeSavingsValue(_state:EmployeeValueState,form:FormData):Promise<EmployeeValueState>{
 try{
  const actor=await getCurrentProfile();if(actor.status!=="active")throw Error("Connectez-vous avec le compte autorisé.");
  const contract=String(form.get("contract_id")??"");if(!isUuid(contract)||!isContractInUserScope(contract))throw Error("Contrat invalide.");
  const value=validateEmployeeSavingsValue(form,parisDate(new Date().toISOString())),client=await createClient();
  const params={requested_contract:contract,requested_edited_ref:value.editedRef,requested_date:value.date,requested_gross:value.gross,requested_net:value.net};
  if(form.get("phase")==="confirm"){
   const submission=String(form.get("submission_id")??"");if(form.get("confirm")!=="on"||!isUuid(submission))throw Error("Confirmez les valeurs présentées.");
   const result=await client.rpc("save_employee_savings_value",{...params,expected_token:String(form.get("token")??""),requested_submission:submission});
   if(result.error)throw Error(result.error.code==="40001"?"L’état a changé depuis l’aperçu. Recommencez ; aucune sauvegarde partielle.":"Valorisation refusée. Vérifiez les dates et les droits du contrat.");
   for(const path of [`/contracts/${contract}`,"/contracts","/","/reports","/patrimony"])revalidatePath(path);
   return {status:"success",message:"Valorisation enregistrée. Anciennes preuves conservées ; aucun flux ni mouvement d’espèces créé."};
  }
  const preview=await client.rpc("preview_employee_savings_value",params);if(preview.error||!preview.data)throw Error("Aperçu indisponible : vérifiez la date et la disponibilité du module.");
  const p=preview.data,before=p.edited??p.destination??null;
  return {status:"preview",review:{token:p.token,submissionId:randomUUID(),date:value.date,gross:value.gross,net:value.net,editedRef:value.editedRef,destination:!!p.destination,moved:!!p.edited&&p.edited.date!==value.date,netCleared:before?.net!=null&&value.net===null,unchanged:p.unchanged,nextDate:p.nextDate,before:before?{date:before.date,gross:before.gross,net:before.net}:null}};
 }catch(error){return {status:"error",message:error instanceof Error?error.message:"Valorisation indisponible."};}
}
