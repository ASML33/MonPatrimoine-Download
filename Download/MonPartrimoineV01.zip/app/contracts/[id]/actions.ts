"use server";

import { isContractInUserScope } from "@/lib/contracts/contract-scope";
import { revalidatePath } from "next/cache";
import { getCurrentProfile } from "@/lib/auth/profile";
import { isUuid } from "@/lib/assets/asset-core";
import { createClient } from "@/lib/supabase/server";
import { positionError, type PositionActionState } from "@/lib/contracts/contract-detail-core";

export async function savePositionAction(_state: PositionActionState, form: FormData): Promise<PositionActionState> {
  const current = await getCurrentProfile().catch(() => null);
  if (current?.status !== "active") return { status: "error", message: "Connectez-vous avec le compte autorisé." };
  const userId = current.profile.auth_user_id;
  const contractId = String(form.get("contract_id") ?? "");
  const positionId = String(form.get("position_id") ?? "");
  const operation = String(form.get("operation") ?? "");
  if (!isContractInUserScope(contractId) || !isUuid(contractId) || (operation !== "create" && !isUuid(positionId))) return { status: "error", message: "Position ou contrat invalide." };
  if (operation !== "delete") return { status: "error", message: "Utilisez la saisie datée et son aperçu pour ajouter ou modifier une détention." };
  const supabase = await createClient();
  const contract = await supabase.from("contracts").select("id,is_active").eq("id", contractId).eq("user_id", userId).maybeSingle();
  if (contract.error || !contract.data) return { status: "error", message: "Ce contrat n’est pas accessible." };
  if (!contract.data.is_active && operation !== "delete") return { status: "error", message: "Réactivez le contrat avant de modifier ses positions." };

  let error: { code?: string } | null = null;
  if (operation === "delete") {
    if (form.get("confirm") !== "on") return { status: "error", message: "Confirmez la suppression de la position." };
    ({ error } = await supabase.from("positions").delete().eq("id", positionId).eq("contract_id", contractId).eq("user_id", userId).select("id").single());
  } else return { status: "error", message: "Opération invalide." };

  if (error) return { status: "error", message: positionError(error.code) };
  revalidatePath(`/contracts/${contractId}`);
  revalidatePath("/contracts");
  revalidatePath("/reports");
  revalidatePath("/patrimony");
  revalidatePath("/");
  return { status: "success", message: operation === "delete" ? "Position supprimée. L’actif est conservé." : "Position enregistrée." };
}
