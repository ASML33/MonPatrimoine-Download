"use server";
import { formatMoney } from "@/lib/cash/money";
import {getCurrentProfile} from "@/lib/auth/profile";
import {createClient} from "@/lib/supabase/server";
import {isUuid} from "@/lib/assets/asset-core";
import {isContractInUserScope} from "@/lib/contracts/contract-scope";
import {getPatrimonyChartData} from "@/lib/patrimony/charts";
import {revalidatePath} from "next/cache";
import type {PropertyObservation} from "@/lib/contracts/property-valuations";
export type PropertyState={status:"idle"|"preview"|"success"|"error";message?:string;review?:{token:string;positionId:string;assetId:string;observation:PropertyObservation;destination:boolean;dates:{date:string;before:string;after:string;status:string}[]}};
export async function savePropertyValuation(_state:PropertyState,form:FormData):Promise<PropertyState>{
 try{
  const user=await getCurrentProfile();if(user.status!=="active")throw Error("Session requise.");
  const contractId=String(form.get("contract_id")??""),assetId=String(form.get("asset_id")??""),positionId=String(form.get("position_id")??""),oid=String(form.get("observation_id")??""),kind=String(form.get("kind")??""),amount=String(form.get("amount")??"").trim();
  if(!isUuid(contractId)||!isContractInUserScope(contractId)||!isUuid(assetId)||positionId&&!isUuid(positionId)||oid&&!isUuid(oid)||!["valuation","end"].includes(kind)||kind==="valuation"&&!/^\d{1,16}([.,]\d{1,8})?$/.test(amount))throw Error("Bien, date ou montant invalide.");
  const params={requested_contract:contractId,requested_asset:assetId,requested_position:positionId||null,requested_observation:oid||null,requested_date:String(form.get("effective_on")??""),requested_kind:kind,requested_amount:kind==="end"?null:amount.replace(",","."),requested_currency:String(form.get("currency")??"")};
  const client=await createClient();
  if(form.get("phase")==="confirm"){
   if(form.get("confirm")!=="on")throw Error("Confirmation requise.");
   const saved=await client.rpc("save_property_valuation",{...params,expected_token:String(form.get("token")??"")});if(saved.error)throw Error(saved.error.code==="40001"?"L’état a changé depuis l’aperçu. Recommencez sans sauvegarde partielle.":"Observation refusée. Vérifiez les dates et les droits du bien.");
   for(const path of [`/contracts/${contractId}`,"/contracts","/reports","/reports/history","/patrimony","/"])revalidatePath(path);
   return {status:"success",message:"Observation immobilière enregistrée ; versions et sources conservées. Aucun flux ni encaissement créé."};
  }
  const result=await client.rpc("preview_property_valuation",params);if(result.error||!result.data)throw Error("Aperçu indisponible : vérifiez la date, la devise et la détention.");
  const plan=result.data;
  const before=await getPatrimonyChartData("total",contractId);
  const after=await getPatrimonyChartData("total",contractId,undefined,{positionId:positionId||"preview:new",contractId,assetId,entries:plan.nextEntries});
  const key=`asset:${contractId}:${assetId}`,show=(v:unknown)=>typeof v==="number"?formatMoney(v,"EUR"):"Indisponible";
  const dates=(plan.review as {date:string;authority:string}[]).map(d=>({date:d.date,before:show(before.points.find(p=>p.date===d.date)?.values[key]),after:show(after?.points.find(p=>p.date===d.date)?.values[key]),status:d.authority}));
  return {status:"preview",review:{token:plan.token,positionId:plan.position?.id??positionId,assetId,observation:plan.observation,destination:!!plan.destination,dates}};
 }catch(e){return {status:"error",message:e instanceof Error?e.message:"Observation indisponible."};}
}
