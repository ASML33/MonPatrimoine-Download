"use server";
import { getCurrentProfile } from "@/lib/auth/profile";
import { createClient } from "@/lib/supabase/server";
import { isUuid } from "@/lib/assets/asset-core";
import { securitiesDay, securitiesMoney } from "@/lib/cash/securities-actions";
import type { CashActionState } from "@/lib/cash/cash-core";
import { revalidatePath } from "next/cache";

function refresh() {
  for (const path of ["/contracts", "/reports", "/reports/history", "/patrimony", "/"]) revalidatePath(path);
  revalidatePath("/contracts/[id]", "page");
}
async function context(form: FormData) {
  const current = await getCurrentProfile();
  if (current.status !== "active") throw Error("Session requise.");
  const request = String(form.get("request_id") ?? "");
  if (!isUuid(request)) throw Error("Rechargez le formulaire avant de réessayer.");
  return { client: await createClient(), request };
}
function failure(e: unknown): CashActionState {
  return { status: "error", message: e instanceof Error ? e.message : "Enregistrement refusé." };
}
function check(error: { code?: string } | null) {
  if (error) throw Error(error.code === "40001" ? "L’état a changé ou cette reprise diffère. Rechargez le volet ; aucune écriture partielle." : "Enregistrement refusé : vérifiez le contrat, la date, la devise et les valeurs.");
}
export async function saveLifeInsuranceAmountAction(_state: CashActionState, form: FormData): Promise<CashActionState> {
  try {
    const { client, request } = await context(form), position = String(form.get("position_id") ?? ""), revision = String(form.get("expected_updated_at") ?? "");
    if (!isUuid(position) || !Number.isFinite(Date.parse(revision))) throw Error("Rechargez le support avant de réessayer.");
    const amount = String(form.get("amount") ?? "").trim().replace(",", "."), currency = String(form.get("currency") ?? "");
    if (!/^\d{1,16}(\.\d{1,8})?$/.test(amount) || !/^[A-Z]{3}$/.test(currency)) throw Error("Montant ou devise invalide.");
    const result = await client.rpc("save_life_insurance_amount", { requested_position: position, requested_request: request, expected_revision: revision, requested_date: securitiesDay(String(form.get("date") ?? "")).day, requested_amount: amount, requested_currency: currency });
    check(result.error); refresh();
    return { status: "success", message: "Valeur enregistrée à sa date et pour la suite. Versions précédentes conservées." };
  } catch (e) { return failure(e); }
}
export async function saveLifeInsuranceCumulativeAction(_state: CashActionState, form: FormData): Promise<CashActionState> {
  try {
    const { client, request } = await context(form), id = String(form.get("contract_id") ?? ""), revision = String(form.get("expected_updated_at") ?? "");
    if (!isUuid(id) || !Number.isFinite(Date.parse(revision)) || form.get("operation") !== "create") throw Error("Rechargez le cumul avant de réessayer.");
    const result = await client.rpc("save_life_insurance_cumulative", { requested_contract: id, requested_request: request, expected_revision: revision, requested_date: securitiesDay(String(form.get("effective_on") ?? "")).day, requested_amount: securitiesMoney(String(form.get("amount") ?? "")) });
    check(result.error); refresh(); return { status: "success", message: "Cumul enregistré à sa date d’effet." };
  } catch (e) { return failure(e); }
}
export async function addLifeInsuranceFlowAction(_state: CashActionState, form: FormData): Promise<CashActionState> {
  try {
    const { client, request } = await context(form), id = String(form.get("contract_id") ?? ""), kind = String(form.get("kind") ?? ""), currency = String(form.get("currency_code") ?? ""), note = String(form.get("note") ?? "").trim();
    if (!isUuid(id) || form.get("operation") !== "create" || !["contribution", "withdrawal"].includes(kind) || !/^[A-Z]{3}$/.test(currency) || [...note].length > 500) throw Error("Flux invalide. Les flux enregistrés restent en ajout seul.");
    const amount=String(form.get("amount")??"").trim().replace(",",".");
    if(!/^\d{1,16}(\.\d{1,8})?$/.test(amount)||Number(amount)<=0)throw Error("Montant positif, huit décimales maximum.");
    const result = await client.rpc("add_life_insurance_flow", { requested_contract: id, requested_request: request, requested_date: securitiesDay(String(form.get("occurred_at") ?? "")).day, requested_kind: kind, requested_amount: amount, requested_currency: currency, requested_note: note || null });
    check(result.error); refresh();
    return { status: "success", message: "Flux externe enregistré. Aucun solde espèces ni support modifié." };
  } catch (e) { return failure(e); }
}
