"use server";

import {getCurrentProfile} from "@/lib/auth/profile";
import {createClient} from "@/lib/supabase/server";
import {isUuid} from "@/lib/assets/asset-core";
import {revalidatePath} from "next/cache";

export type InitialAmountState = {status: "idle" | "preview" | "success" | "error"; message?: string; token?: string; request?: {contract_id: string; asset_id: string; date: string; amount: string; currency: string}};

export async function createAmountPosition(_state: InitialAmountState, form: FormData): Promise<InitialAmountState> {
  try {
    const current = await getCurrentProfile();
    if (current.status !== "active") throw Error("Session requise.");
    const request = {contract_id: String(form.get("contract_id") ?? ""), asset_id: String(form.get("asset_id") ?? ""), date: String(form.get("date") ?? ""), amount: String(form.get("amount") ?? "").trim().replace(",", "."), currency: String(form.get("currency") ?? "")};
    if (!isUuid(request.contract_id) || !isUuid(request.asset_id) || !/^\d{4}-\d{2}-\d{2}$/.test(request.date) || !/^\d{1,16}(\.\d{1,8})?$/.test(request.amount) || !/^[A-Z]{3}$/.test(request.currency)) throw Error("Première valorisation invalide.");
    const confirmed = form.get("phase") === "confirm";
    if (confirmed && form.get("confirm") !== "on") throw Error("Confirmez la première valeur totale.");
    const client = await createClient();
    const args = {requested_contract: request.contract_id, requested_asset: request.asset_id, requested_date: request.date, requested_amount: request.amount, requested_currency: request.currency};
    const result = confirmed ? await client.rpc("create_amount_position", {...args, expected_token: String(form.get("token") ?? "")}) : await client.rpc("preview_amount_position", args);
    if (result.error || !result.data) throw Error(result.error?.code === "40001" ? "L’état a changé. Recommencez l’aperçu." : "Rattachement refusé : vérifiez la date, la devise et le fonds manuel. Un support déjà suivi en parts ou disposant de cours reste suivi en parts.");
    if (!confirmed) return {status: "preview", token: result.data.token, request};
    for (const path of ["/contracts", `/contracts/${request.contract_id}`, "/patrimony", "/"]) revalidatePath(path);
    return {status: "success", message: "Support rattaché avec sa première valeur totale. Aucun mouvement financier créé."};
  } catch (error) {
    return {status: "error", message: error instanceof Error ? error.message : "Rattachement indisponible."};
  }
}
