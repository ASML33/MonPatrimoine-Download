"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import {envelopeNetMode,envelopeModeLabel} from "@/lib/fiscal/envelope-policy";
import { Fragment, createContext, useContext, useActionState, useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { compareDisplayNames, displayedName } from "@/lib/ui/display-order";
import { FieldHelp } from "@/app/settings/field-help";
import type { ContractActionState, ContractCurrency, ContractEnvelopeType, ContractFiscalRegime, ManagedContract } from "@/lib/contracts/contract-core";
import { saveContractAction } from "./actions";
import { useCollapseOnSuccess } from "@/app/components/use-collapse-on-success";
import { DisclosureCard } from "@/app/components/creation-disclosure";
import { ColorField } from "@/app/components/color-field";

const inputClass = "settings-input min-w-0";
const labelClass = "grid gap-2 text-sm font-medium";

function ActionForm({ operation, id, children, submit, onSaved, onCreated }: { operation: string; id?: string; children?: ReactNode; submit: string; onSaved?: () => void; onCreated?: (id: string) => void }) {
  const createdInOpening = useContext(CreatedContext);
  const allowReset = useRef(false);
  const creating = useRef(false);
  const creationId = useRef<HTMLInputElement>(null);
  const [state, action, pending] = useActionState(async (previous: ContractActionState, form: FormData) => {
    allowReset.current = false;
    const result = await saveContractAction(previous, form).catch(error => { if (operation !== "create") throw error; return { status: "error" as const, message: "Création indisponible. Vos saisies sont conservées ; réessayez sans changer de formulaire." }; }).finally(() => { creating.current = false; });
    if (operation === "create" && result.status === "success" && result.createdContractId) (onCreated ?? createdInOpening)?.(result.createdContractId);
    allowReset.current = result.status === "success";
    return result;
  }, { status: "idle" } as ContractActionState);
  const formRef = useCollapseOnSuccess(state, pending, operation === "update", onSaved);
  return <form ref={formRef} onSubmitCapture={event => { if (operation !== "create") return; if (creating.current) { event.preventDefault(); event.stopPropagation(); return; } creating.current = true; if (creationId.current && !creationId.current.value) creationId.current.value = crypto.randomUUID(); }} onResetCapture={event => { if (!allowReset.current) { event.preventDefault(); event.stopPropagation(); } }} data-edit-trigger={id ? `contract-edit-${id}` : undefined} action={action} className="settings-form">
    <input type="hidden" name="operation" value={operation} />
    {operation === "create" ? <input ref={creationId} type="hidden" name="creation_id" defaultValue="" /> : null}
    {id && <input type="hidden" name="id" value={id} />}
    <fieldset disabled={pending} className="grid min-w-0 gap-4">
      {children}
      <button className="settings-primary-button" type="submit">{pending ? "Enregistrement…" : submit}</button>
    </fieldset>
    {state.message && <p role="status" aria-live="polite" className={`text-sm ${state.status === "error" ? "text-red-500" : "text-[var(--app-muted)]"}`}>{state.message}</p>}
  </form>;
}

function ContractCreation({title,description,children}:{title:string;description:string;children:ReactNode}) {
  const [open,setOpen]=useState(false),opening=useRef(0),router=useRouter();
  const session=opening.current;
  const created=(id:string)=>{if(opening.current!==session)return;opening.current++;setOpen(false);router.push(`/contracts/${encodeURIComponent(id)}`);};
  return <div data-creation-disclosure><DisclosureCard title={title} description={description} open={open} onToggle={()=>{opening.current++;setOpen(v=>!v);}}>{open?<CreationActionContext onCreated={created}>{children}</CreationActionContext>:null}</DisclosureCard></div>;
}
function CreationActionContext({children,onCreated}:{children:ReactNode;onCreated:(id:string)=>void}) {
 return <CreatedContext.Provider value={onCreated}>{children}</CreatedContext.Provider>;
}
const CreatedContext = createContext<((id:string)=>void)|undefined>(undefined);
function ContractFields({ contract, envelopeTypes, currencies, dashboardTiles = [] }: { dashboardTiles?: string[]; contract?: ManagedContract; envelopeTypes: ContractEnvelopeType[]; currencies: ContractCurrency[]; fiscalRegimes: ContractFiscalRegime[] }) {
  const fieldId = contract?.id ?? "create";
  const [tileChoice, setTileChoice] = useState("");
  const [newTileName, setNewTileName] = useState("");
  const tileSelect = useRef<HTMLSelectElement>(null);
  useEffect(() => {
    const form = tileSelect.current?.form;
    const reset = () => { setTileChoice(""); setNewTileName(""); };
    form?.addEventListener("reset", reset);
    return () => form?.removeEventListener("reset", reset);
  }, []);
  const activeTypes = envelopeTypes.filter((type) => type.is_active || type.id === contract?.envelope_type_id);
  const [selectedType, setSelectedType] = useState(contract?.envelope_type_id ?? "");
  const [openedOn, setOpenedOn] = useState(contract?.opened_on ?? "");
  const [fiscalStartedOn, setFiscalStartedOn] = useState(contract?.fiscal_started_on ?? "");
  const [useOpeningDate, setUseOpeningDate] = useState(false);
  const [emptyLifeInsurance, setEmptyLifeInsurance] = useState(false);
  const copyOpeningDate = useOpeningDate && Boolean(openedOn);
  const displayedFiscalStart = copyOpeningDate ? openedOn : fiscalStartedOn;
  const selectedCode=activeTypes.find(t=>t.id===selectedType)?.code??"";
  const usesTax=Boolean(selectedType)&&envelopeNetMode(selectedCode)==="calculated";
  return <>
    <label className={labelClass}>Enveloppe *
      <select className={inputClass} name="envelope_type_id" value={selectedType} required onChange={(event) => {setSelectedType(event.target.value);}} disabled={Boolean(contract)}>
        <option value="" disabled>Choisir un type d’enveloppe</option>
        {activeTypes.map((type) => <option key={type.id} value={type.id}>{type.label}{!type.is_active ? " (inactif)" : ""}</option>)}
      </select>
    </label>
    {contract ? <input type="hidden" name="envelope_type_id" value={contract.envelope_type_id} /> : null}
    <p className="text-sm text-[var(--app-muted)]">{selectedType?envelopeModeLabel(selectedCode):'Choisissez une enveloppe.'} · <Link className="text-[var(--app-gold)] underline" href={selectedType?`/envelopes/${selectedType}`:'/envelopes'}>Voir l’enveloppe</Link></p>
    {!contract && selectedCode === "assurance_vie" ? <div className="grid gap-3">
      <label className={labelClass}>Situation du contrat
        <select className={inputClass} name="initial_value_state" value={emptyLifeInsurance ? "empty" : "unknown"} onChange={event => setEmptyLifeInsurance(event.target.value === "empty")}>
          <option value="unknown">Contrat existant — valeur à renseigner</option>
          <option value="empty">Contrat vide — 0 EUR confirmé</option>
        </select>
      </label>
      {emptyLifeInsurance ? <label className={labelClass}>Date du constat de valeur nulle *
        <input className={inputClass} type="date" name="initial_value_on" min={openedOn || undefined} required />
      </label> : null}
      <p className="text-sm text-[var(--app-muted)]">Un fonds en euros sera créé. {emptyLifeInsurance ? "Sa valorisation nulle sera enregistrée uniquement à la date indiquée, sans espèces ni versement. Les dates antérieures et la fiscalité ne sont pas présumées connues." : "Sans valorisation renseignée, sa valeur reste inconnue, y compris pour un contrat ancien."}</p>
    </div> : null}
    <label className={labelClass}>Nom du contrat *
      <input className={inputClass} name="name" defaultValue={contract?.name ?? ""} maxLength={120} required />
    </label>
    <label className={labelClass}>Nom d’affichage
      <input className={inputClass} name="display_name" defaultValue={contract?.display_name ?? ""} maxLength={120} />
      <span className="text-xs font-normal text-[var(--app-muted)]">Utilisé dans le Dashboard et les graphiques. Le nom complet reste conservé.</span>
    </label>
    {contract ? <label className={labelClass}>Tuile du tableau de bord
      <input className={inputClass} name="dashboard_tile_name" defaultValue={contract.dashboard_tile_name ?? ""} maxLength={120} />
      <span className="text-xs font-normal text-[var(--app-muted)]">Les contrats portant exactement le même nom sont regroupés. Laissez vide pour masquer ce contrat des tuiles.</span>
    </label> : <div className={labelClass}>
      <label htmlFor="dashboard-tile-create">Tuile du tableau de bord</label>
      <select ref={tileSelect} id="dashboard-tile-create" className={inputClass} value={tileChoice} onChange={event=>setTileChoice(event.target.value)}>
        <option value="">Aucune tuile</option>
        {dashboardTiles.map(name=><option key={name} value={"tile:"+name}>{name}</option>)}
        <option value="new">Créer une nouvelle tuile</option>
      </select>
      {tileChoice==="new"?<label className={labelClass}>Nom de la nouvelle tuile<input className={inputClass} name="dashboard_tile_name" value={newTileName} onChange={event=>setNewTileName(event.target.value)} maxLength={120}/></label>:<input type="hidden" name="dashboard_tile_name" value={tileChoice.startsWith("tile:")?tileChoice.slice(5):""}/>}
      <span className="text-xs font-normal text-[var(--app-muted)]">Les contrats portant exactement le même nom sont regroupés. Aucune tuile masque ce contrat des tuiles.</span>
    </div>}
    <ColorField key={contract?.color ?? "none"} initial={contract?.color ?? null} id={`contract-${fieldId}`} />
    <div className="grid gap-5 md:grid-cols-2 md:gap-8">
      <label className={labelClass}>Devise *
        <select className={inputClass} name="currency_code" defaultValue={contract?.currency_code ?? "EUR"} required disabled={contract?.hasDependencies}>
          {currencies.map((currency) => <option key={currency.code} value={currency.code}>{currency.code}</option>)}
        </select>
      </label>
      <label className={labelClass}>Date d’ouverture
        <input className={inputClass} name="opened_on" type="date" value={openedOn} onChange={(event) => setOpenedOn(event.target.value)} />
      </label>
      {contract?.hasDependencies ? <><input type="hidden" name="currency_code" value={contract.currency_code} /><input type="hidden" name="currency_locked" value="true" /></> : null}
    </div>
    {usesTax?<>
    <div className="grid gap-5 md:grid-cols-2 md:gap-8">
      <div className={labelClass}>
        <div className="flex items-center gap-2"><label htmlFor={`fiscal-start-${fieldId}`}>Date de départ de l’ancienneté fiscale{!contract ? " *" : ""}</label><FieldHelp id={`fiscal-start-help-${fieldId}`} label="Date fiscale">Date du premier versement ou date fiscale fiable. Elle n’est jamais déduite de la date de création informatique et ne désigne pas le début de l’historique fiable dans MonPatrimoine.</FieldHelp></div>
        <input className={inputClass} id={`fiscal-start-${fieldId}`} name="fiscal_started_on" type="date" required={!contract} value={displayedFiscalStart} readOnly={copyOpeningDate} onChange={(event) => setFiscalStartedOn(event.target.value)} />
        <label className="flex items-start gap-2 text-sm"><input type="checkbox" checked={copyOpeningDate} disabled={!openedOn} onChange={(event) => setUseOpeningDate(event.target.checked)} />Utiliser la date d’ouverture comme date de départ fiscal</label>
      </div>
    </div>
    <div className="grid gap-4">
      <div className={labelClass}>
        <div className="flex items-center gap-2"><label htmlFor={`fiscal-ps-paid-${fieldId}`}>PS déjà acquittés (€)</label><FieldHelp id={`fiscal-ps-paid-help-${fieldId}`} label="Prélèvements sociaux déjà acquittés">Un champ vide est interprété comme 0 € dans le calcul. Si un montant est renseigné, il est utilisé. Les autres informations nécessaires au NET restent requises.</FieldHelp></div>
        <input className={inputClass} id={`fiscal-ps-paid-${fieldId}`} name="social_contributions_paid_eur" type="number" min="0" step="0.01" defaultValue={contract?.social_contributions_paid_eur ?? ""} />
      </div>
    {activeTypes.find((type) => type.id === selectedType)?.code === "pea_pme" ? <label className="flex items-start gap-3 text-sm"><input type="checkbox" name="pea_pme_standard_confirmed" defaultChecked={contract?.pea_pme_standard_confirmed ?? false} />Je confirme le périmètre titres ordinaires cotés du PEA-PME. Les titres non cotés et leurs cas particuliers restent hors calcul.</label> : null}
    <label className="flex items-start gap-3 text-sm font-medium"><input className="mt-1" type="checkbox" name="fiscal_history_complete" defaultChecked={contract?.fiscal_history_complete ?? false} />Je confirme que l’historique fiscal utile de ce contrat est complet.</label>
      <p className="text-xs text-[var(--app-muted)]">La complétude de l’historique est indépendante de la date de bascule. Un montant vide reste inconnu, jamais zéro.</p>
    </div>
    </>:<><input type="hidden" name="fiscal_started_on" value={contract?.fiscal_started_on??''}/><input type="hidden" name="social_contributions_paid_eur" value={contract?.social_contributions_paid_eur??''}/><input type="hidden" name="fiscal_history_complete" value={contract?.fiscal_history_complete?'on':''}/></>}
    <div className="grid gap-5 md:grid-cols-2 md:gap-8">
      <label className={labelClass}>Établissement
        <input className={inputClass} name="institution_name" defaultValue={contract?.institution_name ?? ""} />
      </label>
    </div>
    <div className="grid gap-5 md:grid-cols-2 md:gap-8">
      <div className={labelClass}>
        <div className="relative flex items-center gap-2 [&_.field-help]:static [&_.field-help-panel]:left-0">
          <label htmlFor={`closed-${fieldId}`}>Date de clôture</label>
          <FieldHelp id={`closed-help-${fieldId}`} label="Date de clôture">
            La clôture ne peut pas précéder l’ouverture. Elle est indépendante de la désactivation, qui conserve toutes les données du contrat.
          </FieldHelp>
        </div>
        <input className={inputClass} id={`closed-${fieldId}`} name="closed_on" type="date" defaultValue={contract?.closed_on ?? ""} />
      </div>
    </div>
  </>;
}

export function ContractForms({ contracts, envelopeTypes, currencies, fiscalRegimes }: { contracts: ManagedContract[]; envelopeTypes: ContractEnvelopeType[]; currencies: ContractCurrency[]; fiscalRegimes: ContractFiscalRegime[] }) {
  const availableTypes = envelopeTypes.filter((type) => type.is_active);
  const dashboardTiles = [...new Set(contracts.map(contract=>contract.dashboard_tile_name).filter((name):name is string=>Boolean(name)))].sort((a,b)=>a.localeCompare(b,"fr"));
  const [editedId, setEditedId] = useState<string | null>(null);
  const closeEditor = useCallback(() => setEditedId(null), []);
  return <div className="mt-8 grid gap-6">
    <h2 className="text-xl font-semibold">Contrats ({contracts.length})</h2>
    {!contracts.length && <p className="text-[var(--app-muted)]">Vous n’avez pas encore de contrat.</p>}
    {contracts.length ? <section className="settings-card min-w-0"><table className="block w-full text-left text-sm lg:table">
      <thead className="hidden lg:table-header-group"><tr>{["Contrat", "Type / devise", "Établissement", "Dates", "Statut / tuile", "Gestion"].map((title) => <th key={title} scope="col" className="px-3 pb-4 font-semibold">{title}</th>)}</tr></thead>
      <tbody className="grid gap-6 lg:table-row-group">{[...contracts].sort(compareDisplayNames).map((contract) => <Fragment key={contract.id}>
        <tr className="grid min-w-0 gap-3 border-t border-[var(--app-border)] py-4 lg:table-row [&>td]:min-w-0 [&>td]:break-words lg:[&>td]:p-3 lg:[&>td]:align-top">
          <td className="font-semibold lg:max-w-44"><Link href={`/contracts/${contract.id}`} prefetch={false} title={contract.name} className="text-[var(--app-gold)] underline-offset-4 hover:underline">{displayedName(contract)}</Link>{contract.display_name ? <p className="mt-1 text-xs font-normal text-[var(--app-muted)]">{contract.name}</p> : null}</td>
          <td>{contract.envelopeTypeLabel}<p className="text-[var(--app-muted)]">{contract.currency_code}</p></td>
          <td className="lg:max-w-40">{contract.institution_name ?? "Établissement non renseigné"}</td>
          <td className="lg:max-w-48"><p>Ouverture : {contract.opened_on ?? "Non renseignée"}</p>{contract.closed_on ? <p>Clôture : {contract.closed_on}</p> : null}<p className="text-[var(--app-muted)]"><Link href={`/envelopes/${contract.envelope_type_id}`}>Mode NET de l’enveloppe</Link></p></td>
          <td>{contract.is_active ? "Actif" : "Inactif"}<p className="text-[var(--app-muted)]">Tuile : {contract.dashboard_tile_name ?? "Masqué"}</p></td>
          <td><button id={`contract-edit-${contract.id}`} type="button" aria-expanded={editedId === contract.id} aria-controls={`contract-editor-${contract.id}`} onClick={() => setEditedId((current) => current === contract.id ? null : contract.id)} className="settings-edit-action">{editedId === contract.id ? "Fermer" : "Modifier"}</button></td>
        </tr>
        {editedId === contract.id ? <tr id={`contract-editor-${contract.id}`}><td colSpan={6} className="border-t border-[var(--app-border)] p-4 sm:p-5">
            <p className="mb-4 text-xs text-[var(--app-muted)]">Le type d’enveloppe ne peut pas être changé. La devise est verrouillée dès que des données sont liées.</p>
            {!["pea","cto","pea_pme","compte_titres","immobilier"].includes(contract.envelopeTypeCode)?<Link className="settings-edit-action mb-4" href={`/geography/contract/${contract.id}`}>Pays de rattachement</Link>:null}
            <ActionForm operation="update" id={contract.id} submit="Enregistrer" onSaved={closeEditor}><ContractFields contract={contract} envelopeTypes={envelopeTypes} currencies={currencies} fiscalRegimes={fiscalRegimes} /></ActionForm>
          <ActionForm operation={contract.is_active ? "deactivate" : "activate"} id={contract.id} submit={contract.is_active ? "Désactiver" : "Réactiver"} />
          <p className="mt-3 text-xs text-[var(--app-muted)]">Désactiver conserve les positions, liquidités, flux et historiques, sans modifier la date de clôture.</p>
          {contract.hasDependencies && !contract.canDeleteEmptyAutomaticFund
            ? <p className="mt-3 text-xs text-[var(--app-muted)]">Suppression indisponible : des données sont liées. Utilisez la désactivation.</p>
            : <details className="mt-4"><summary className="cursor-pointer py-2 text-sm">Supprimer le contrat vide</summary>
              {contract.canDeleteEmptyAutomaticFund ? <p className="my-3 text-xs text-[var(--app-muted)]">La ligne Fonds en euros automatique sans valeur sera retirée avec ce contrat. Aucun actif de catalogue ne sera supprimé.</p> : null}
              <ActionForm operation="delete" id={contract.id} submit="Supprimer définitivement">
                <label className="flex items-start gap-2 text-sm"><input type="checkbox" name="confirm" required className="mt-1" />Je confirme la suppression définitive de ce contrat.</label>
              </ActionForm>
            </details>}
        </td></tr> : null}
      </Fragment>)}</tbody>
    </table></section> : null}
    <ContractCreation
      title="Créer un contrat"
      description="Le contrat sera actif. Son type classe le contrat sans créer une enveloppe patrimoniale séparée."
    >
      {availableTypes.length ? <ActionForm operation="create" submit="Créer le contrat">
        <ContractFields dashboardTiles={dashboardTiles} envelopeTypes={availableTypes} currencies={currencies} fiscalRegimes={fiscalRegimes} />
      </ActionForm> : <p className="text-sm text-[var(--app-muted)]">Aucun type d’enveloppe actif n’est disponible.</p>}
    </ContractCreation>
  </div>;
}
