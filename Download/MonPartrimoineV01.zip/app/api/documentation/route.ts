import { ApplicationAccessDeniedError, getCurrentUser } from "@/lib/auth/user";
import { createDocumentApi } from "@/lib/documentation/document-api";
import { createDocumentStore } from "@/lib/documentation/storage";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const handler = createDocumentApi({
  async authorize() {
    try {
      const user = await getCurrentUser();
      return user ? { owner: user.id } : { status: 401 };
    } catch (error) {
      if (error instanceof ApplicationAccessDeniedError) return { status: 403 };
      throw error;
    }
  },
  store: createDocumentStore,
});

export { handler as GET, handler as POST, handler as DELETE };
