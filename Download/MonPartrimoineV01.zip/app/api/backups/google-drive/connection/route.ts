import { getDriveActor, getDriveConnection } from "@/lib/backups/google-drive";
import { createDriveHandlers } from "@/lib/backups/google-drive-http";

export const runtime = "nodejs";
export const maxDuration = 60;
export const dynamic = "force-dynamic";
export const POST = createDriveHandlers({ actor: getDriveActor, connection: getDriveConnection }).check;
