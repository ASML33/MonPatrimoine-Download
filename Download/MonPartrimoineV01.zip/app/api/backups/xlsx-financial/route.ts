import { getDriveActor } from "@/lib/backups/google-drive";
import { financialError, financialJson, validFinancialPost } from "@/lib/backups/xlsx-financial-http";
import { initializeFinancialXlsx, publishFinancialXlsx } from "@/lib/backups/xlsx-financial-service";
import { publicationId } from "@/lib/backups/xlsx-publication";
import { parisBusinessDate } from "@/lib/dates/business-date";

export const runtime = "nodejs";
export const maxDuration = 90;

export async function POST(request: Request) {
  if (process.env.XLSX_FINANCIAL_MANUAL_ENABLED !== "true") return financialJson({}, 404);
  try {
    if (!await validFinancialPost(request, process.env.NEXT_PUBLIC_SITE_URL)) return financialJson({}, 403);
    const operation = request.headers.get("idempotency-key") ?? "";
    if (!publicationId.test(operation)) return financialJson({ message: "Référence de sauvegarde invalide." }, 400);
    const actor = await getDriveActor();
    if (!actor || actor.userId !== process.env.XLSX_FINANCIAL_OWNER_ID) return financialJson({}, 403);
    const history = await initializeFinancialXlsx(actor.userId, 20_000, 20);
    if (history.status === "initializing") return financialJson(history, 202);
    return financialJson(await publishFinancialXlsx(actor.userId, "manual", parisBusinessDate(), operation));
  } catch (error) {
    return financialError(error);
  }
}
