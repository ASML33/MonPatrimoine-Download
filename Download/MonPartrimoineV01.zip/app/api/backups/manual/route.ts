import {createManualHandler} from '@/lib/backups/manual-http.mjs';
import {createManualBackupService} from '@/lib/backups/application-backup-manual';
import {getDriveActor} from '@/lib/backups/google-drive';
import {getBackupAutomationView} from '@/lib/backups/application-backup-automation';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export const maxDuration=60;
export const POST=createManualHandler({getActor:getDriveActor,createService:createManualBackupService,getAutomationView:()=>getBackupAutomationView(false),allowArchiveCreation:()=>false,origin:process.env.NEXT_PUBLIC_SITE_URL});
