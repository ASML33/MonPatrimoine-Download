import { getDriveActor } from "@/lib/backups/google-drive";
import { downloadFinancialArchive, financialDestinationView } from "@/lib/backups/xlsx-financial-destination";
import { financialError, financialJson } from "@/lib/backups/xlsx-financial-http";
import { financialArchiveReference } from "@/lib/backups/xlsx-drive-transport";
import { PATRIMONIAL_XLSX_MIME } from "@/lib/exports/patrimonial-xlsx";
import { parisBusinessDate } from "@/lib/dates/business-date";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function GET(request: Request) {
  if (process.env.XLSX_FINANCIAL_MANUAL_ENABLED !== "true") return financialJson({}, 404);
  try {
    const actor = await getDriveActor();
    if (!actor || actor.userId !== process.env.XLSX_FINANCIAL_OWNER_ID) return financialJson({}, 403);
    const reference = new URL(request.url).searchParams.get("download");
    if (reference === null) {
      const view = await financialDestinationView(actor.userId);
      return financialJson({ ...view, today: parisBusinessDate() });
    }
    if (!financialArchiveReference.test(reference)) return financialJson({ message: "Référence de fichier invalide." }, 400);
    const file = await downloadFinancialArchive(actor.userId, reference);
    if (!file) return financialJson({ message: "Ce fichier n’est plus disponible dans le dossier de sauvegarde." }, 404);

    const body = new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(file.bytes);
        controller.close();
      },
    });
    return new Response(body, { headers: {
      "Content-Type": "mime" in file ? String(file.mime) : PATRIMONIAL_XLSX_MIME,
      "Content-Disposition": `attachment; filename="${file.name}"`,
      "Cache-Control": "private, no-store",
      "Referrer-Policy": "no-referrer",
      "X-Content-Type-Options": "nosniff",
    } });
  } catch (error) { return financialError(error); }
}
