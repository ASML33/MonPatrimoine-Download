import { getDriveActor } from "@/lib/backups/google-drive";
import { financialError, financialJson, validFinancialPost } from "@/lib/backups/xlsx-financial-http";
import { initializeFinancialXlsx } from "@/lib/backups/xlsx-financial-service";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(request: Request) {
  if (process.env.XLSX_FINANCIAL_SEED_ENABLED !== "true") return financialJson({}, 404);
  try {
    if (!await validFinancialPost(request, process.env.NEXT_PUBLIC_SITE_URL)) return financialJson({}, 403);
    const actor = await getDriveActor();
    if (!actor || actor.userId !== process.env.XLSX_FINANCIAL_OWNER_ID) return financialJson({}, 403);
    return financialJson(await initializeFinancialXlsx(actor.userId, 20_000, 20));
  } catch (error) {
    return financialError(error);
  }
}
