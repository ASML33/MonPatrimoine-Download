import { getPageProfile } from '@/lib/auth/render-context';
import { getPatrimonyChartData } from '@/lib/patrimony/charts';
import { withNavigationReadScope } from '@/lib/navigation/read-scope';
import { NavigationAccessError, readNavigationStamp, sameNavigationStamp } from '@/lib/navigation/stamp';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
const json = (body: unknown,status=200) => Response.json(body,{status,headers:{'Cache-Control':'private, no-store, max-age=0','Vary':'Cookie'}});

export async function GET(request: Request) {
  return withNavigationReadScope(async()=>{
    try{
      const { current }=await getPageProfile();
      if(current.status!=='active')return json({error:'Session indisponible'},401);
      const stamp=await readNavigationStamp(current.profile.auth_user_id);
      const query=new URL(request.url).searchParams;
      const known=query.get('revision')===stamp.revision&&query.get('session')===stamp.session&&query.get('day')===stamp.day;
      if(known||query.get('check')==='1')return json({stamp,unchanged:known,changed:!known});
      // Common model once; contract and property scope are presentation selections.
      const data=await getPatrimonyChartData('total',null,undefined,undefined,true);
      // No read-scope memoization for either revision call. Reject a load crossing
      // a concurrent commit/session/day change rather than publishing mixed data.
      const after=await readNavigationStamp(current.profile.auth_user_id);
      if(!sameNavigationStamp(stamp,after))return json({error:'Données modifiées pendant le chargement. Réessayez.'},409);
      return json({stamp:after,data});
    }catch(error){
      return json({error:'Historique indisponible'},error instanceof NavigationAccessError?401:503);
    }
  });
}
