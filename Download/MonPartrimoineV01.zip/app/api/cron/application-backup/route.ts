export const dynamic = "force-dynamic";

export function GET() {
  return Response.json({ status: "disabled" }, { status: 410, headers: { "Cache-Control": "no-store" } });
}
