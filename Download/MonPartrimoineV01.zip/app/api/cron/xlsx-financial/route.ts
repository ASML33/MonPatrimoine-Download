import { authorizedFinancialScheduler, scheduledFinancialDate } from "@/lib/backups/xlsx-financial-clock";
import { financialError, financialJson } from "@/lib/backups/xlsx-financial-http";
import { initializeFinancialXlsx, publishFinancialXlsx } from "@/lib/backups/xlsx-financial-service";

export const runtime = "nodejs";
export const maxDuration = 120;

export async function GET(request: Request) {
  const owner = process.env.XLSX_FINANCIAL_OWNER_ID;
  if (process.env.XLSX_FINANCIAL_AUTOMATIC_ENABLED !== "true" || !owner) return financialJson({}, 404);
  if (!authorizedFinancialScheduler(request.headers.get("authorization"), process.env.CRON_SECRET)) {
    return financialJson({}, 401);
  }
  try {
    const scheduledAt = request.headers.get("ce-vssscheduledat");
    const date = scheduledFinancialDate(new Date(), scheduledAt);
    if (!date) {
      console.info("xlsx_financial_automatic", { status: "outside_window" });
      return financialJson({ status: "outside_window" });
    }
    const history = await initializeFinancialXlsx(owner, 55_000, 1000);
    if (history.status === "initializing") {
      console.info("xlsx_financial_automatic", { date, status: history.status, imported: history.imported });
      return financialJson(history, 202);
    }
    const stillScheduled = () => scheduledFinancialDate(new Date(), scheduledAt) === date;
    if (!stillScheduled()) {
      console.info("xlsx_financial_automatic", { date, status: "window_elapsed" });
      return financialJson({ date, status: "window_elapsed" });
    }
    const result = await publishFinancialXlsx(owner, "automatic", date, undefined, stillScheduled);
    console.info("xlsx_financial_automatic", { date: result.date, status: result.status });
    return financialJson(result);
  } catch (error) {
    const response = financialError(error);
    console.warn("xlsx_financial_automatic", { status: response.status, code: (await response.clone().json()).code });
    return response;
  }
}
