import { handleAssetPriceCron } from "@/lib/assets/asset-price-cron";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

export async function GET(request: Request) {
  return handleAssetPriceCron(request);
}
