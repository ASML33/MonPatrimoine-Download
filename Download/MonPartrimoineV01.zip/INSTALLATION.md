# Installer MonPatrimoine

Ce guide accompagne le ZIP pour installer MonPatrimoine sur vos propres comptes. Gardez-le ouvert pendant la configuration.

## Avant de commencer

- Préparez Windows 10 ou 11, une connexion Internet, [Node.js 24 LTS](https://nodejs.org/fr/download), [Git pour Windows](https://git-scm.com/install/windows) et [GitHub CLI](https://cli.github.com/). Après l’installation des outils, ouvrez une nouvelle fenêtre. Dans PowerShell, `node -v`, `git --version` et `gh --version` doivent chacun afficher une version.
- Connectez-vous à vos comptes [GitHub](https://github.com/), [Vercel](https://vercel.com/dashboard) et [Supabase](https://supabase.com/dashboard). Choisissez le compte sous lequel vous voulez posséder cette instance. Les confirmations de connexion et le choix d'un forfait se font sur les sites des services.
- Décompressez le ZIP dans un dossier dédié. Ouvrez `COMMENCER-ICI.html`, puis double-cliquez sur `Lancer-MonPatrimoine.cmd`. Dans PowerShell, depuis le dossier extrait, vous pouvez aussi lancer `node .\scripts\installation\installer.mjs`.

## Première installation

1. **Supabase.** Créez un projet neuf. Conservez son mot de passe de base de données dans votre gestionnaire de mots de passe. Une fois le projet prêt, ouvrez **Authentication → Sign In / Providers**. Laissez **Email** activé, désactivez **Allow new users to sign up** et les connexions anonymes, puis enregistrez.
2. **Cible.** Dans Supabase, le bouton **Connect** donne la chaîne **Session pooler**, port `5432`. Le panneau **Connect** ou la section des clés API donne la clé **Publishable** et la clé **Secret**. Suivez les demandes du programme pour saisir les valeurs. Si nécessaire, téléchargez le certificat dans **Settings → Database → SSL Configuration**, conservez-le hors du dossier extrait et indiquez son chemin. La clé **Secret** et les deux mots de passe se saisissent uniquement aux invites masquées du programme.
3. **Compte de l’application.** Choisissez l’e-mail, le surnom et le mot de passe du premier utilisateur. Cette identité sert à ouvrir MonPatrimoine après le déploiement. Elle est distincte de votre compte Supabase et du mot de passe de la base PostgreSQL.
4. **GitHub et Vercel.** Vérifiez les comptes affichés par le programme. Si une connexion s'ouvre dans le navigateur, terminez-la puis revenez dans la fenêtre d'installation. Pour l'espace personnel ou l'équipe Vercel, saisissez l'identifiant visible après `vercel.com/` dans l'adresse du tableau de bord de cet espace. Le programme prépare le schéma, initialise le dépôt privé et déploie la nouvelle instance Vercel. Conservez l'adresse et le fichier local `.monpatrimoine-install.json` dans votre dossier d'installation. Ce fichier identifie l'instance pour les futures mises à jour.
5. **Vérification.** Ouvrez l'adresse affichée, connectez-vous avec le compte de l'application. Dans **Contrats**, choisissez **Créer un contrat**, sélectionnez **Épargne liquide**, indiquez le nom `Livret de test`, la devise `EUR` et une date d'ouverture. Enregistrez, puis rechargez la page. Vérifiez que le contrat reste visible. Dans **Documentation**, déposez puis téléchargez un fichier TXT ou DOCX fictif.

La configuration fournie démarre avec le suivi manuel et la bibliothèque de documents. Pour activer Google Drive ou les cours planifiés, configurez ensuite les services, clés et tâches de **votre** instance. Dans Supabase **Authentication → URL Configuration**, renseignez l'origine affichée par l'installateur comme **Site URL**. Ajoutez les URL complètes de cette origine suivies de `/auth/callback?next=/reset-password` et `/auth/callback?next=/settings`. Vérifiez la réception des e-mails si vous activez leur envoi. [Configuration des redirections Supabase](https://supabase.com/docs/guides/auth/redirect-urls)

## Appliquer un ZIP de mise à jour

Gardez le dossier de l’installation en cours et sa fiche `.monpatrimoine-install.json`. Décompressez le ZIP de mise à jour dans **un autre dossier**, puis lancez son `Lancer-MonPatrimoine.cmd`. Lorsque le programme le demande, indiquez la fiche de la dernière installation réussie et authentifiez-vous auprès des mêmes comptes. Il vérifie la version précédente, l’identité de l’instance et les migrations avant de publier. Après validation, utilisez la fiche écrite dans le nouveau dossier pour la version suivante.

## Si une étape s’arrête

| Message ou symptôme | Action |
| --- | --- |
| Outil introuvable | Installez l’outil indiqué depuis sa page officielle, puis rouvrez la fenêtre et relancez. |
| Fichier absent ou différent dans le ZIP | Décompressez à nouveau dans un dossier vide et vérifiez le SHA-256 du ZIP avec `Get-FileHash -Algorithm SHA256` dans PowerShell. |
| Échec d’authentification GitHub ou Vercel | Vérifiez le compte ouvert dans le navigateur, puis reprenez avec le compte propriétaire choisi pour cette instance. |
| Connexion Supabase refusée | Vérifiez que la référence et les clés viennent du même projet, que le pooler est en mode **Session** et que le mot de passe est celui de la base. En cas d’erreur TLS, utilisez le certificat officiel du projet. |
| Cible, registre ou version inattendus | Arrêtez-vous au message. Vérifiez les références affichées et reprenez avec le bon projet, la bonne fiche et le bon ZIP. |
| Interruption pendant l’installation | Relancez depuis le même dossier avec les mêmes cibles, afin de retrouver l’état de cette tentative. |

Pour la recette autonome, notez le texte de tout message bloquant et l’étape où il apparaît. Gardez les clés, les mots de passe et les chaînes de connexion hors de vos captures et comptes rendus.
