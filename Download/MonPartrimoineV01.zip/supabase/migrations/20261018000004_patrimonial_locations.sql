-- Dated location evidence on existing identities. No geographic catalogue,
-- financial observation or retrospective acquisition date is created here.
begin;
create table private.location_write_guards (
 transaction_id bigint not null, target_kind text not null, target_id uuid not null,
 before_metadata jsonb not null, after_metadata jsonb not null,
 primary key(transaction_id,target_kind,target_id)
);
revoke all on private.location_write_guards from public,anon,authenticated;

create function private.guard_location_history() returns trigger
language plpgsql security definer set search_path=pg_catalog,public,private as $$
declare old_location jsonb; new_location jsonb;
begin
 old_location=case when tg_op='INSERT' then null else old.metadata->'geographic_location' end;
 new_location=case when tg_op='DELETE' then null else new.metadata->'geographic_location' end;
 if old_location is distinct from new_location and not exists (
  select 1 from private.location_write_guards g where g.transaction_id=txid_current()
  and g.target_kind=case when tg_table_name='assets' then 'asset' else 'contract' end
  and g.target_id=case when tg_op='DELETE' then old.id else new.id end
  and g.before_metadata=case when tg_op='INSERT' then '{}'::jsonb else coalesce(old.metadata,'{}') end
  and g.after_metadata=case when tg_op='DELETE' then '{}'::jsonb else coalesce(new.metadata,'{}') end
 ) then raise exception 'Location history requires controlled correction' using errcode='42501';end if;
 if tg_table_name='assets' and tg_op='UPDATE' then
  if old_location is not null and new.asset_type_code is distinct from old.asset_type_code then raise exception 'Located property identity is protected' using errcode='23514';end if;
 end if;
 if tg_op='DELETE' then return old;end if;return new;
end $$;
revoke all on function private.guard_location_history() from public,anon,authenticated;
create trigger assets_location_guard before insert or update or delete on public.assets for each row execute function private.guard_location_history();
create trigger contracts_location_guard before insert or update or delete on public.contracts for each row execute function private.guard_location_history();

create function private.guard_located_country() returns trigger
language plpgsql security definer set search_path=pg_catalog,public,private as $$
begin
 if tg_op='UPDATE' then
  if (new.id,new.code,new.region_code) is not distinct from (old.id,old.code,old.region_code) then return new;end if;
 end if;
 if exists(select 1 from public.assets a where exists(select 1 from jsonb_array_elements(coalesce(a.metadata#>'{geographic_location,entries}','[]')||coalesce(a.metadata#>'{geographic_location,archived}','[]')) e where e->>'countryId'=old.id::text))
 or exists(select 1 from public.contracts c where exists(select 1 from jsonb_array_elements(coalesce(c.metadata#>'{geographic_location,entries}','[]')||coalesce(c.metadata#>'{geographic_location,archived}','[]')) e where e->>'countryId'=old.id::text)) then
  raise exception 'Country referenced by location evidence' using errcode='23514';
 end if;
 if tg_op='DELETE' then return old;end if;return new;
end $$;
revoke all on function private.guard_located_country() from public,anon,authenticated;
create trigger exposure_countries_location_guard before update or delete on public.exposure_countries for each row execute function private.guard_located_country();

create function private.location_plan(p_kind text,p_target uuid,p_observation uuid,p_date date,p_country uuid)
returns jsonb language plpgsql security definer set search_path=pg_catalog,public,private as $$
declare target jsonb; h jsonb; previous jsonb; request jsonb; catalog_hash text; token text; proposed jsonb;
begin
 if public.is_authorized_user() is not true or auth.uid() is null then raise exception 'Unauthorized' using errcode='42501';end if;
 if p_observation is null then raise exception 'Observation identity required' using errcode='23514';end if;
 if p_kind='asset' then
  select to_jsonb(a) into target from public.assets a where a.id=p_target and a.owner_user_id=auth.uid() and a.asset_type_code='real_estate';
 elsif p_kind='contract' then
  select to_jsonb(c) into target from public.contracts c join public.envelope_types t on t.id=c.envelope_type_id
   where c.id=p_target and c.user_id=auth.uid() and t.code not in ('pea','cto','pea_pme','compte_titres','immobilier') and not(c.metadata ? 'property_replaced_by');
 else raise exception 'Invalid target' using errcode='23514';end if;
 if target is null then raise exception 'Unavailable target' using errcode='42501';end if;
 h=coalesce(target#>'{metadata,geographic_location}','{"version":1,"entries":[],"archived":[],"receipts":[]}'::jsonb);
 if h->>'version'<>'1' or jsonb_typeof(h->'entries')<>'array' or jsonb_typeof(h->'archived')<>'array' then raise exception 'Invalid history' using errcode='23514';end if;
 select e into previous from jsonb_array_elements(h->'entries') e where e->>'id'=p_observation::text;
 if p_date is null and (previous is null or previous->>'origin'<>'confirmed_history') then raise exception 'An effect date is required' using errcode='23514';end if;
 if p_date is not null and (p_date<'0001-01-01' or p_date>(now() at time zone 'Europe/Paris')::date) then raise exception 'Invalid date' using errcode='23514';end if;
 if exists(select 1 from jsonb_array_elements(h->'entries') e where (e->>'effectiveOn')::date is not distinct from p_date and e->>'id'<>p_observation::text) then raise exception 'Date already occupied; correct the identified entry' using errcode='23505';end if;
 if p_country is not null and not exists(select 1 from public.exposure_countries c join public.geographic_regions r on r.code=c.region_code where c.id=p_country and ((c.is_active and r.is_active) or previous->>'countryId'=p_country::text) and c.code<>'unspecified') then raise exception 'Invalid active country' using errcode='23514';end if;
 request=jsonb_build_object('kind',p_kind,'target',p_target,'observation',p_observation,'date',p_date,'country',p_country);
 select md5(coalesce(jsonb_agg(to_jsonb(c) order by c.id)::text,'')) into catalog_hash from public.exposure_countries c;
 select catalog_hash||md5(coalesce(jsonb_agg(to_jsonb(r) order by r.code)::text,'')) into catalog_hash from public.geographic_regions r;
 token=md5(target::text||request::text||catalog_hash);
 proposed=jsonb_build_object('id',p_observation,'version',coalesce((previous->>'version')::int,0)+1,'countryId',p_country,'effectiveOn',p_date,'origin',case when p_date is null then 'confirmed_history' else 'dated' end,
 'source',case when p_date is null then previous->>'source' else 'Localisation saisie explicitement par l’utilisateur' end,'recordedAt',now());
 return jsonb_build_object('token',token,'request',request,'previous',previous,'observation',proposed,'history',h,'targetMetadata',coalesce(target->'metadata','{}'));
end $$;
revoke all on function private.location_plan(text,uuid,uuid,date,uuid) from public,anon,authenticated;

create function public.preview_patrimonial_location(p_kind text,p_target uuid,p_observation uuid,p_date date,p_country uuid)
returns jsonb language sql security definer set search_path=pg_catalog,public,private as $$
 select private.location_plan(p_kind,p_target,p_observation,p_date,p_country)-'history'-'targetMetadata'
$$;
revoke all on function public.preview_patrimonial_location(text,uuid,uuid,date,uuid) from public,anon;
grant execute on function public.preview_patrimonial_location(text,uuid,uuid,date,uuid) to authenticated;

create function public.save_patrimonial_location(p_kind text,p_target uuid,p_observation uuid,p_date date,p_country uuid,p_token text)
returns uuid language plpgsql security definer set search_path=pg_catalog,public,private as $$
declare metadata_before jsonb; metadata_after jsonb; plan jsonb; h jsonb; request jsonb; entries jsonb; archives jsonb;
begin
 if public.is_authorized_user() is not true or auth.uid() is null then raise exception 'Unauthorized' using errcode='42501';end if;
 lock table public.exposure_countries, public.geographic_regions in share mode;
 if p_kind='asset' then select a.metadata into metadata_before from public.assets a where a.id=p_target and a.owner_user_id=auth.uid() for update;
 elsif p_kind='contract' then select c.metadata into metadata_before from public.contracts c where c.id=p_target and c.user_id=auth.uid() for update;
 else raise exception 'Invalid target' using errcode='23514';end if;
 if not found then raise exception 'Unavailable target' using errcode='42501';end if;
 request=jsonb_build_object('kind',p_kind,'target',p_target,'observation',p_observation,'date',p_date,'country',p_country);
 if exists(select 1 from jsonb_array_elements(coalesce(metadata_before#>'{geographic_location,receipts}','[]')) r where r->>'token'=p_token and r->'request'=request) then return p_observation;end if;
 plan=private.location_plan(p_kind,p_target,p_observation,p_date,p_country);
 if p_token is null or p_token<>plan->>'token' then raise exception 'Concurrent change; preview again' using errcode='40001';end if;
 h=plan->'history';
 select coalesce(jsonb_agg(e),'[]') into entries from jsonb_array_elements(h->'entries') e where e->>'id'<>p_observation::text;
 archives=h->'archived';if plan->'previous'<>'null'::jsonb then archives=archives||jsonb_build_array(plan->'previous');end if;
 h=jsonb_build_object('version',1,'entries',entries||jsonb_build_array(plan->'observation'),'archived',archives,'receipts',coalesce(h->'receipts','[]')||jsonb_build_array(jsonb_build_object('token',p_token,'request',request)));
 metadata_before=coalesce(metadata_before,'{}');metadata_after=jsonb_set(metadata_before,'{geographic_location}',h);
 insert into private.location_write_guards values(txid_current(),p_kind,p_target,metadata_before,metadata_after);
 if p_kind='asset' then update public.assets set metadata=metadata_after where id=p_target;else update public.contracts set metadata=metadata_after where id=p_target;end if;
 delete from private.location_write_guards where transaction_id=txid_current() and target_kind=p_kind and target_id=p_target;
 return p_observation;
end $$;
revoke all on function public.save_patrimonial_location(text,uuid,uuid,date,uuid,text) from public,anon;
grant execute on function public.save_patrimonial_location(text,uuid,uuid,date,uuid,text) to authenticated;
commit;
