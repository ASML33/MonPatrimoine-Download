-- Uniform management for analysis reference catalogues.
begin;

alter table public.sectors
  add column is_active boolean not null default true,
  add column has_been_used boolean not null default false,
  add column created_at timestamptz not null default now(),
  add column updated_at timestamptz not null default now();
alter table public.sector_activities
  add column is_active boolean not null default true,
  add column has_been_used boolean not null default false,
  add column created_at timestamptz not null default now(),
  add column updated_at timestamptz not null default now();
alter table public.geographic_regions
  add column is_active boolean not null default true,
  add column has_been_used boolean not null default false,
  add column created_at timestamptz not null default now(),
  add column updated_at timestamptz not null default now();
alter table public.exposure_countries
  add column is_active boolean not null default true,
  add column has_been_used boolean not null default false,
  add column created_at timestamptz not null default now(),
  add column updated_at timestamptz not null default now();
alter table public.themes add column has_been_used boolean not null default false;

update public.sectors sector set has_been_used = true where exists(
  select 1 from public.asset_sector_exposures exposure where exposure.sector_id = sector.id
) or exists(
  select 1 from public.asset_activity_exposures exposure
  join public.sector_activities activity on activity.id = exposure.activity_id
  where activity.sector_id = sector.id
);
update public.sector_activities activity set has_been_used = true where exists(
  select 1 from public.asset_activity_exposures exposure where exposure.activity_id = activity.id
);
update public.exposure_countries country set has_been_used = true where exists(
  select 1 from public.asset_geography_exposures exposure where exposure.country_id = country.id
);
update public.geographic_regions region set has_been_used = true where exists(
  select 1 from public.exposure_countries country
  join public.asset_geography_exposures exposure on exposure.country_id = country.id
  where country.region_code = region.code
);
update public.themes theme set has_been_used = true where exists(
  select 1 from public.asset_theme_exposures exposure where exposure.theme_id = theme.id
);

create function private.mark_analysis_reference_used()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_table_name = 'asset_sector_exposures' then
    update public.sectors set has_been_used = true where id = new.sector_id and not has_been_used;
  elsif tg_table_name = 'asset_activity_exposures' then
    update public.sector_activities set has_been_used = true where id = new.activity_id and not has_been_used;
    update public.sectors sector set has_been_used = true
      from public.sector_activities activity
      where activity.id = new.activity_id and sector.id = activity.sector_id and not sector.has_been_used;
  elsif tg_table_name = 'asset_geography_exposures' then
    update public.exposure_countries set has_been_used = true where id = new.country_id and not has_been_used;
    update public.geographic_regions region set has_been_used = true
      from public.exposure_countries country
      where country.id = new.country_id and region.code = country.region_code and not region.has_been_used;
  elsif tg_table_name = 'asset_theme_exposures' then
    update public.themes set has_been_used = true where id = new.theme_id and not has_been_used;
  end if;
  return new;
end $$;
revoke all on function private.mark_analysis_reference_used() from public, anon, authenticated;
create trigger mark_sector_reference_used after insert or update of sector_id on public.asset_sector_exposures
  for each row execute function private.mark_analysis_reference_used();
create trigger mark_activity_reference_used after insert or update of activity_id on public.asset_activity_exposures
  for each row execute function private.mark_analysis_reference_used();
create trigger mark_country_reference_used after insert or update of country_id on public.asset_geography_exposures
  for each row execute function private.mark_analysis_reference_used();
create trigger mark_theme_reference_used after insert or update of theme_id on public.asset_theme_exposures
  for each row execute function private.mark_analysis_reference_used();

create unique index sectors_normalized_name_idx on public.sectors(lower(btrim(name)));
create unique index sector_activities_parent_normalized_name_idx
  on public.sector_activities(sector_id, lower(btrim(name)));
create unique index geographic_regions_normalized_name_idx
  on public.geographic_regions(lower(btrim(name)));
create unique index exposure_countries_normalized_name_idx
  on public.exposure_countries(lower(btrim(name)));

create trigger sectors_set_updated_at before update on public.sectors
  for each row execute function public.set_updated_at();
create trigger sector_activities_set_updated_at before update on public.sector_activities
  for each row execute function public.set_updated_at();
create trigger geographic_regions_set_updated_at before update on public.geographic_regions
  for each row execute function public.set_updated_at();
create trigger exposure_countries_set_updated_at before update on public.exposure_countries
  for each row execute function public.set_updated_at();

-- Catalogue writes are available only through identity-checking RPCs.
revoke insert, update, delete on public.sectors, public.sector_activities,
  public.geographic_regions, public.exposure_countries from public, anon, authenticated;

create function private.assert_analysis_catalog_access()
returns void language plpgsql stable security definer set search_path = '' as $$
begin
  if not public.is_authorized_user() then
    raise exception 'Access denied' using errcode = '42501';
  end if;
end $$;
revoke all on function private.assert_analysis_catalog_access() from public, anon, authenticated;

create function public.create_sector(sector_name text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare created_id uuid := gen_random_uuid();
begin
  perform private.assert_analysis_catalog_access();
  if sector_name is null or length(btrim(sector_name)) not between 1 and 120 then
    raise exception 'Invalid sector name' using errcode = '23514';
  end if;
  insert into public.sectors(id, taxonomy, code, name)
    values(created_id, 'monpatrimoine', 'custom_' || replace(created_id::text, '-', ''), btrim(sector_name));
  insert into public.sector_activities(sector_id, code, name)
    values(created_id, 'unspecified', 'Non détaillé');
  return created_id;
end $$;

create function public.rename_sector(requested_id uuid, sector_name text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_analysis_catalog_access();
  if sector_name is null or length(btrim(sector_name)) not between 1 and 120 then
    raise exception 'Invalid sector name' using errcode = '23514';
  end if;
  update public.sectors set name = btrim(sector_name) where id = requested_id;
  if not found then raise exception 'Sector unavailable' using errcode = '42501'; end if;
end $$;

create function public.set_sector_active(requested_id uuid, active boolean)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_analysis_catalog_access();
  if active is null then raise exception 'Invalid sector status' using errcode = '23514'; end if;
  if not active and exists(select 1 from public.sectors where id = requested_id and taxonomy = 'monpatrimoine' and code = 'unspecified') then
    raise exception 'Technical sector is protected' using errcode = '23514';
  end if;
  update public.sectors set is_active = active where id = requested_id;
  if not found then raise exception 'Sector unavailable' using errcode = '42501'; end if;
end $$;

create function public.delete_sector(requested_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_analysis_catalog_access();
  if exists(select 1 from public.sectors where id = requested_id and taxonomy = 'monpatrimoine' and code = 'unspecified') then
    raise exception 'Technical sector is protected' using errcode = '23514';
  end if;
  if exists(select 1 from public.sectors where id = requested_id and has_been_used)
    or exists(select 1 from public.sector_activities where sector_id = requested_id and has_been_used) then
    raise exception 'Sector is referenced' using errcode = '23503';
  end if;
  delete from public.sector_activities where sector_id = requested_id;
  delete from public.sectors where id = requested_id;
  if not found then raise exception 'Sector unavailable' using errcode = '42501'; end if;
end $$;

create function public.create_sector_activity(requested_sector uuid, activity_name text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare created_id uuid := gen_random_uuid();
begin
  perform private.assert_analysis_catalog_access();
  if activity_name is null or length(btrim(activity_name)) not between 1 and 160 then
    raise exception 'Invalid activity name' using errcode = '23514';
  end if;
  if not exists(select 1 from public.sectors where id = requested_sector and is_active) then
    raise exception 'Sector unavailable' using errcode = '42501';
  end if;
  insert into public.sector_activities(id, sector_id, code, name)
    values(created_id, requested_sector, 'custom_' || replace(created_id::text, '-', ''), btrim(activity_name));
  return created_id;
end $$;

create function public.rename_sector_activity(requested_id uuid, activity_name text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_analysis_catalog_access();
  if activity_name is null or length(btrim(activity_name)) not between 1 and 160 then
    raise exception 'Invalid activity name' using errcode = '23514';
  end if;
  update public.sector_activities set name = btrim(activity_name) where id = requested_id;
  if not found then raise exception 'Activity unavailable' using errcode = '42501'; end if;
end $$;

create function public.set_sector_activity_active(requested_id uuid, active boolean)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_analysis_catalog_access();
  if active is null then raise exception 'Invalid activity status' using errcode = '23514'; end if;
  if not active and exists(select 1 from public.sector_activities where id = requested_id and code = 'unspecified') then
    raise exception 'Technical activity is protected' using errcode = '23514';
  end if;
  if active and not exists(
    select 1 from public.sector_activities activity
    join public.sectors sector on sector.id = activity.sector_id
    where activity.id = requested_id and sector.is_active
  ) then raise exception 'Parent sector unavailable' using errcode = '42501'; end if;
  update public.sector_activities set is_active = active where id = requested_id;
  if not found then raise exception 'Activity unavailable' using errcode = '42501'; end if;
end $$;

create function public.delete_sector_activity(requested_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_analysis_catalog_access();
  if exists(select 1 from public.sector_activities where id = requested_id and code = 'unspecified') then
    raise exception 'Technical activity is protected' using errcode = '23514';
  end if;
  if exists(select 1 from public.sector_activities where id = requested_id and has_been_used) then
    raise exception 'Activity is referenced' using errcode = '23503';
  end if;
  delete from public.sector_activities where id = requested_id;
  if not found then raise exception 'Activity unavailable' using errcode = '42501'; end if;
end $$;

create function public.create_geographic_region(region_name text)
returns text language plpgsql security definer set search_path = '' as $$
declare created_code text := 'custom_' || translate(replace(gen_random_uuid()::text, '-', ''), '0123456789', 'abcdefghij');
begin
  perform private.assert_analysis_catalog_access();
  if region_name is null or length(btrim(region_name)) not between 1 and 160 then
    raise exception 'Invalid region name' using errcode = '23514';
  end if;
  insert into public.geographic_regions(code, name) values(created_code, btrim(region_name));
  return created_code;
end $$;

create function public.rename_geographic_region(requested_code text, region_name text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_analysis_catalog_access();
  if region_name is null or length(btrim(region_name)) not between 1 and 160 then
    raise exception 'Invalid region name' using errcode = '23514';
  end if;
  update public.geographic_regions set name = btrim(region_name) where code = requested_code;
  if not found then raise exception 'Region unavailable' using errcode = '42501'; end if;
end $$;

create function public.set_geographic_region_active(requested_code text, active boolean)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_analysis_catalog_access();
  if active is null then raise exception 'Invalid region status' using errcode = '23514'; end if;
  if requested_code = 'unspecified' and not active then
    raise exception 'Technical region is protected' using errcode = '23514';
  end if;
  update public.geographic_regions set is_active = active where code = requested_code;
  if not found then raise exception 'Region unavailable' using errcode = '42501'; end if;
end $$;

create function public.delete_geographic_region(requested_code text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_analysis_catalog_access();
  if requested_code = 'unspecified' then raise exception 'Technical region is protected' using errcode = '23514'; end if;
  if exists(select 1 from public.geographic_regions where code = requested_code and has_been_used)
    or exists(select 1 from public.exposure_countries where region_code = requested_code) then
    raise exception 'Region is referenced' using errcode = '23503';
  end if;
  delete from public.geographic_regions where code = requested_code;
  if not found then raise exception 'Region unavailable' using errcode = '42501'; end if;
end $$;

create function public.create_exposure_country(country_code text, country_name text, requested_region text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare created_id uuid;
begin
  perform private.assert_analysis_catalog_access();
  country_code := upper(btrim(country_code));
  if country_code !~ '^[A-Z]{2}$' or country_name is null or length(btrim(country_name)) not between 1 and 160 then
    raise exception 'Invalid country' using errcode = '23514';
  end if;
  if not exists(select 1 from public.geographic_regions where code = requested_region and is_active) then
    raise exception 'Region unavailable' using errcode = '42501';
  end if;
  insert into public.exposure_countries(code, name, region_code)
    values(country_code, btrim(country_name), requested_region) returning id into created_id;
  return created_id;
end $$;

create function public.update_exposure_country(requested_id uuid, country_name text, requested_region text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_analysis_catalog_access();
  if country_name is null or length(btrim(country_name)) not between 1 and 160 then
    raise exception 'Invalid country name' using errcode = '23514';
  end if;
  if not exists(select 1 from public.geographic_regions where code = requested_region and is_active) then
    raise exception 'Region unavailable' using errcode = '42501';
  end if;
  update public.exposure_countries set name = btrim(country_name), region_code = requested_region where id = requested_id;
  if not found then raise exception 'Country unavailable' using errcode = '42501'; end if;
end $$;

create function public.set_exposure_country_active(requested_id uuid, active boolean)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_analysis_catalog_access();
  if active is null then raise exception 'Invalid country status' using errcode = '23514'; end if;
  if not active and exists(select 1 from public.exposure_countries where id = requested_id and code = 'unspecified') then
    raise exception 'Technical country is protected' using errcode = '23514';
  end if;
  if active and not exists(
    select 1 from public.exposure_countries country
    join public.geographic_regions region on region.code = country.region_code
    where country.id = requested_id and region.is_active
  ) then raise exception 'Region unavailable' using errcode = '42501'; end if;
  update public.exposure_countries set is_active = active where id = requested_id;
  if not found then raise exception 'Country unavailable' using errcode = '42501'; end if;
end $$;

create function public.delete_exposure_country(requested_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_analysis_catalog_access();
  if exists(select 1 from public.exposure_countries where id = requested_id and code = 'unspecified') then
    raise exception 'Technical country is protected' using errcode = '23514';
  end if;
  if exists(select 1 from public.exposure_countries where id = requested_id and has_been_used) then
    raise exception 'Country is referenced' using errcode = '23503';
  end if;
  delete from public.exposure_countries where id = requested_id;
  if not found then raise exception 'Country unavailable' using errcode = '42501'; end if;
end $$;

create or replace function public.delete_theme(theme_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_theme_owner(theme_id);
  if exists(select 1 from public.themes where id = theme_id and has_been_used) then
    raise exception 'Theme is referenced' using errcode = '23503';
  end if;
  delete from public.themes where id = theme_id and owner_user_id = auth.uid();
end $$;

-- Inactive references remain readable, but can only be retained by an asset
-- that already uses them in a draft or effective allocation.
create or replace function public.save_asset_exposure_draft(
  aid uuid, dimension text, items jsonb, data_date date default null,
  source text default null, origin text default 'user'
)
returns void language plpgsql security definer set search_path = '' as $$
declare tab text; refcol text; item jsonb; requested_reference uuid; requested_weight numeric;
begin
  tab := private.exposure_write_scope(aid, dimension);
  if jsonb_typeof(items) is distinct from 'array' then raise exception 'Invalid distribution' using errcode = '22023'; end if;
  refcol := case dimension when 'sector' then 'sector_id' when 'activity' then 'activity_id' else 'country_id' end;
  for item in select value from jsonb_array_elements(items) loop
    begin
      requested_reference := (item ->> 'reference_id')::uuid;
      requested_weight := (item ->> 'weight_percent')::numeric;
    exception when others then raise exception 'Invalid exposure item' using errcode = '22023'; end;
    if requested_weight is null or requested_weight <= 0 or requested_weight > 100
      or trunc(requested_weight, 2) <> requested_weight then
      raise exception 'Weight must be in (0,100] with at most two decimals' using errcode = '23514';
    end if;
    if dimension = 'sector' and not exists(
      select 1 from public.sectors reference where reference.id = requested_reference
        and (reference.is_active or exists(select 1 from public.asset_sector_exposures existing where existing.asset_id = aid and existing.sector_id = reference.id))
    ) then raise exception 'Reference unavailable' using errcode = '42501'; end if;
    if dimension = 'activity' and not exists(
      select 1 from public.sector_activities reference join public.sectors parent on parent.id = reference.sector_id
      where reference.id = requested_reference and ((reference.is_active and parent.is_active)
        or exists(select 1 from public.asset_activity_exposures existing where existing.asset_id = aid and existing.activity_id = reference.id))
    ) then raise exception 'Reference unavailable' using errcode = '42501'; end if;
    if dimension = 'geography' and not exists(
      select 1 from public.exposure_countries reference join public.geographic_regions parent on parent.code = reference.region_code
      where reference.id = requested_reference and ((reference.is_active and parent.is_active)
        or exists(select 1 from public.asset_geography_exposures existing where existing.asset_id = aid and existing.country_id = reference.id))
    ) then raise exception 'Reference unavailable' using errcode = '42501'; end if;
  end loop;
  execute format('delete from public.%I where asset_id=$1 and stage=''draft''', tab) using aid;
  for item in select value from jsonb_array_elements(items) loop
    execute format('insert into public.%I(asset_id,%I,weight_percent,stage,data_date,source,origin) values($1,$2,$3,''draft'',$4,$5,$6)', tab, refcol)
      using aid, (item ->> 'reference_id')::uuid, (item ->> 'weight_percent')::numeric, data_date, source, origin;
  end loop;
  perform private.check_asset_exposures(aid);
end $$;

revoke all on function public.create_sector(text), public.rename_sector(uuid, text),
  public.set_sector_active(uuid, boolean), public.delete_sector(uuid),
  public.create_sector_activity(uuid, text), public.rename_sector_activity(uuid, text),
  public.set_sector_activity_active(uuid, boolean), public.delete_sector_activity(uuid),
  public.create_geographic_region(text), public.rename_geographic_region(text, text),
  public.set_geographic_region_active(text, boolean), public.delete_geographic_region(text),
  public.create_exposure_country(text, text, text), public.update_exposure_country(uuid, text, text),
  public.set_exposure_country_active(uuid, boolean), public.delete_exposure_country(uuid)
  from public, anon;
grant execute on function public.create_sector(text), public.rename_sector(uuid, text),
  public.set_sector_active(uuid, boolean), public.delete_sector(uuid),
  public.create_sector_activity(uuid, text), public.rename_sector_activity(uuid, text),
  public.set_sector_activity_active(uuid, boolean), public.delete_sector_activity(uuid),
  public.create_geographic_region(text), public.rename_geographic_region(text, text),
  public.set_geographic_region_active(text, boolean), public.delete_geographic_region(text),
  public.create_exposure_country(text, text, text), public.update_exposure_country(uuid, text, text),
  public.set_exposure_country_active(uuid, boolean), public.delete_exposure_country(uuid)
  to authenticated;

commit;
