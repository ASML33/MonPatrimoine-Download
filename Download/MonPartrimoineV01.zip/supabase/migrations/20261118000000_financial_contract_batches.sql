
begin;
create table private.financial_batches (
 owner_id uuid not null, folder_id text not null, operation_id uuid not null,
 business_date date not null, captured_at timestamptz not null,
 plan jsonb, manifest jsonb, completed_at timestamptz, retired boolean not null default false,
 lease uuid, leased_until timestamptz, cleaned boolean not null default false,
 primary key(owner_id,folder_id,operation_id),
 foreign key(owner_id,folder_id) references private.xlsx_drive_destinations(owner_id,folder_id),
 check (plan is null or octet_length(plan::text)<=33554432)
);
alter table private.financial_batches enable row level security;
revoke all on private.financial_batches from public,anon,authenticated,service_role;

create function public.financial_batch_store(p_owner uuid,p_folder text,p_operation uuid,p_action text,p_token uuid default null,p_payload jsonb default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare
 cfg private.xlsx_financial_configuration;
 job private.xlsx_financial_jobs;
 b private.financial_batches;
 stamp timestamptz:=clock_timestamp();
begin
 if not exists(select 1 from private.application_principal a join public.profiles p on p.auth_user_id=a.auth_user_id
   where a.singleton and p.is_active and a.auth_user_id=p_owner) then
   raise exception 'Unauthorized batch owner' using errcode='42501';
 end if;
 select * into cfg from private.xlsx_financial_configuration where owner_id=p_owner for update;
 if p_action='list' then
   if cfg.owner_id is null or not cfg.enabled or cfg.folder_id is distinct from p_folder then
     return jsonb_build_object('batches','[]'::jsonb);
   end if;
   return jsonb_build_object('batches',coalesce((select jsonb_agg(manifest || jsonb_build_object('retired',retired,'cleaned',cleaned) order by captured_at desc)
     from private.financial_batches where owner_id=p_owner and folder_id=p_folder and completed_at is not null and (not retired or not cleaned or jsonb_path_exists(manifest,'$.files[*] ? (@.archive == true)'))),'[]'::jsonb));
 end if;
 if cfg.owner_id is null or not cfg.enabled or cfg.folder_id is distinct from p_folder then
   raise exception 'Inactive batch destination' using errcode='42501';
 end if;
 select * into job from private.xlsx_financial_jobs where owner_id=p_owner and operation_id=p_operation;
 if not found then raise exception 'Unknown batch job' using errcode='42501'; end if;
 if p_action='lease' then
   insert into private.financial_batches(owner_id,folder_id,operation_id,business_date,captured_at)
     values(p_owner,p_folder,p_operation,job.business_date,job.captured_at) on conflict do nothing;
 end if;
 select * into b from private.financial_batches where owner_id=p_owner and folder_id=p_folder and operation_id=p_operation for update;
 if not found then raise exception 'Unknown batch' using errcode='42501'; end if;
 if p_action='lease' then
   if b.leased_until>stamp and b.lease is distinct from p_token then return jsonb_build_object('status','busy'); end if;
   if p_token is null then raise exception 'Missing lease token' using errcode='22023'; end if;
   update private.financial_batches set lease=p_token,leased_until=stamp+interval '60 seconds'
     where owner_id=p_owner and folder_id=p_folder and operation_id=p_operation;
   return jsonb_build_object('status','leased','plan',b.plan,'complete',b.completed_at is not null);
 end if;
 if b.lease is distinct from p_token or b.leased_until<=stamp then raise exception 'Expired batch lease' using errcode='42501'; end if;
 if p_action='guard' then return jsonb_build_object('status','leased'); end if;
 if p_action='prepare' then
   if b.plan is null then
     if jsonb_typeof(p_payload) is distinct from 'object' or octet_length(p_payload::text)>33554432
       or p_payload->'batch'->>'operation' is distinct from p_operation::text
       or p_payload->'batch'->>'date' is distinct from job.business_date::text
       or (p_payload->'batch'->>'capturedAt')::timestamptz is distinct from job.captured_at
       or jsonb_array_length(p_payload->'batch'->'files')<1
       then raise exception 'Invalid batch plan' using errcode='22023'; end if;
     update private.financial_batches set plan=p_payload where owner_id=p_owner and folder_id=p_folder and operation_id=p_operation;
     b.plan:=p_payload;
   elsif b.plan is distinct from p_payload then raise exception 'Batch plan changed' using errcode='22023'; end if;
   return jsonb_build_object('status','prepared','plan',b.plan);
 elsif p_action='commit' then
   if b.plan is null or job.prepared is null then raise exception 'Missing prepared batch' using errcode='22023'; end if;
   if b.completed_at is null then
     -- This transaction is the only visibility boundary. No pending file is listed.
     update private.financial_batches set manifest=(plan->'batch') || '{"complete":true}'::jsonb,
       completed_at=stamp where owner_id=p_owner and folder_id=p_folder and operation_id=p_operation;
     insert into private.xlsx_financial_days(owner_id,business_date,captured_at,published_at,payload)
       values(p_owner,job.business_date,job.captured_at,stamp,job.prepared)
       on conflict(owner_id,business_date) do update set captured_at=excluded.captured_at,published_at=excluded.published_at,payload=excluded.payload;

   end if;
   return jsonb_build_object('status','published');
 elsif p_action='retire' then
   if b.completed_at is null then raise exception 'Incomplete lot' using errcode='22023'; end if;
   -- Only completed lots superseded by another same-date lot or outside five newest dates.
   update private.financial_batches old set retired=true where old.owner_id=p_owner and old.folder_id=p_folder
     and old.completed_at is not null and old.operation_id<>p_operation
     and (old.business_date=b.business_date or old.business_date not in
       (select distinct business_date from private.financial_batches where owner_id=p_owner and folder_id=p_folder
          and completed_at is not null order by business_date desc limit 5))
     -- December is pinned until a January batch declares the rollover secured.
     and (extract(month from old.business_date)<>12 or exists(select 1 from private.financial_batches newer where newer.owner_id=p_owner and newer.folder_id=p_folder and newer.completed_at is not null and extract(year from newer.business_date)=extract(year from old.business_date) and extract(month from newer.business_date)=12 and (newer.business_date,newer.captured_at)>(old.business_date,old.captured_at)) or exists(
       select 1 from private.financial_batches jan where jan.owner_id=p_owner and jan.folder_id=p_folder
       and jan.completed_at is not null and jan.manifest->>'securedDecember'=extract(year from old.business_date)::text));
   return jsonb_build_object('status','retired');
 elsif p_action='cleaned' then
   update private.financial_batches set cleaned=true where owner_id=p_owner and folder_id=p_folder
     and operation_id=(p_payload->>'operation')::uuid and retired and completed_at is not null;
   return jsonb_build_object('status','cleaned');
 elsif p_action='finish' then
   if b.completed_at is null then raise exception 'Incomplete lot' using errcode='22023'; end if;
   update private.financial_batches set plan=jsonb_build_object('batch',manifest,'contents','{}'::jsonb) where owner_id=p_owner and folder_id=p_folder and operation_id=p_operation;
   update private.xlsx_financial_jobs set completed_at=stamp,source=null,prepared=null,last_error=null
     where owner_id=p_owner and operation_id=p_operation;
   return jsonb_build_object('status','published');
 elsif p_action='release' then
   update private.financial_batches set lease=null,leased_until=null where owner_id=p_owner and folder_id=p_folder and operation_id=p_operation;
   return jsonb_build_object('status','released');
 end if;
 raise exception 'Unknown batch action' using errcode='22023';
end $$;
revoke all on function public.financial_batch_store(uuid,text,uuid,text,uuid,jsonb) from public,anon,authenticated,service_role;
grant execute on function public.financial_batch_store(uuid,text,uuid,text,uuid,jsonb) to service_role;

-- Prevent changing the destination while a resumable file set still owns it.
do $$
declare definition text;
begin
 select pg_get_functiondef('public.xlsx_financial_destination(uuid,text,text,text)'::regprocedure) into definition;
 definition:=replace(definition,'if found then','if found then
    if exists(select 1 from private.financial_batches b where b.owner_id=p_owner and b.operation_id=pending.operation_id and b.completed_at is null) then
      return jsonb_build_object(''status'',''busy'');
    end if;');
 execute definition;
end $$;
commit;
