-- Canonical business identifiers only; Auth identities are not modified.
begin;

create function public.canonicalize_profile_identifiers()
returns trigger
language plpgsql
security invoker
set search_path = ''
as $$
begin
  new.nickname := pg_catalog.lower(new.nickname::text);
  new.email := pg_catalog.lower(new.email::text);
  return new;
end;
$$;

revoke all on function public.canonicalize_profile_identifiers() from public;

create trigger profiles_canonicalize_identifiers
  before insert or update on public.profiles
  for each row execute function public.canonicalize_profile_identifiers();

-- Existing citext UNIQUE constraints already exclude case-only collisions.
-- Compare text, not citext, to detect the stored representation.
update public.profiles
set nickname = pg_catalog.lower(nickname::text),
    email = pg_catalog.lower(email::text)
where nickname::text collate "C" <> pg_catalog.lower(nickname::text) collate "C"
   or email::text collate "C" <> pg_catalog.lower(email::text) collate "C";

commit;
