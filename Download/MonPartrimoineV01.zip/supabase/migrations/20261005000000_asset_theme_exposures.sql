-- Phase 7.6: user-managed themes and overlapping asset exposures.
begin;

create table public.themes (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null default auth.uid()
    references public.profiles(auth_user_id) on delete restrict on update cascade,
  name text not null check(length(btrim(name)) between 1 and 160),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index themes_owner_normalized_name_idx
  on public.themes(owner_user_id, lower(btrim(name)));

create table public.asset_theme_exposure_sets (
  asset_id uuid not null references public.assets(id) on delete restrict on update cascade,
  stage text not null check(stage in ('draft', 'effective')),
  data_date date check(data_date is null or isfinite(data_date)),
  source text check(source is null or length(btrim(source)) between 1 and 2000),
  origin text check(origin is null or origin ~ '^[a-z0-9_-]{1,50}$'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key(asset_id, stage)
);

create table public.asset_theme_exposures (
  asset_id uuid not null,
  stage text not null check(stage in ('draft', 'effective')),
  theme_id uuid not null references public.themes(id) on delete restrict on update cascade,
  weight_percent numeric(5,2) not null
    check(weight_percent > 0 and weight_percent <= 100 and trunc(weight_percent, 2) = weight_percent),
  primary key(asset_id, stage, theme_id),
  foreign key(asset_id, stage)
    references public.asset_theme_exposure_sets(asset_id, stage)
    on delete cascade on update cascade
);

create index asset_theme_exposures_theme_idx on public.asset_theme_exposures(theme_id);
create index asset_theme_exposures_effective_asset_idx
  on public.asset_theme_exposures(asset_id) where stage = 'effective';

create trigger themes_set_updated_at before update on public.themes
  for each row execute function public.set_updated_at();
create trigger asset_theme_sets_set_updated_at before update on public.asset_theme_exposure_sets
  for each row execute function public.set_updated_at();

alter table public.themes enable row level security;
alter table public.themes force row level security;
alter table public.asset_theme_exposure_sets enable row level security;
alter table public.asset_theme_exposure_sets force row level security;
alter table public.asset_theme_exposures enable row level security;
alter table public.asset_theme_exposures force row level security;

revoke all on public.themes, public.asset_theme_exposure_sets, public.asset_theme_exposures
  from public, anon, authenticated;
grant select on public.themes, public.asset_theme_exposure_sets, public.asset_theme_exposures
  to authenticated;

create policy themes_read on public.themes for select to authenticated
  using(public.is_authorized_user() and owner_user_id = auth.uid());
create policy theme_sets_read on public.asset_theme_exposure_sets for select to authenticated
  using(public.is_authorized_user() and exists(
    select 1 from public.assets a where a.id = asset_id and a.owner_user_id = auth.uid()
  ));
create policy theme_exposures_read on public.asset_theme_exposures for select to authenticated
  using(public.is_authorized_user() and exists(
    select 1 from public.assets a where a.id = asset_id and a.owner_user_id = auth.uid()
  ));

create function private.assert_theme_owner(requested_theme uuid, require_active boolean default false)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_authorized_user() or not exists(
    select 1 from public.themes
    where id = requested_theme and owner_user_id = auth.uid()
      and (not require_active or is_active)
  ) then
    raise exception 'Theme unavailable' using errcode = '42501';
  end if;
end $$;

create function private.lock_theme_asset(requested_asset uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_authorized_user() or not exists(
    select 1 from public.assets where id = requested_asset and owner_user_id = auth.uid()
  ) then
    raise exception 'Asset unavailable' using errcode = '42501';
  end if;
  insert into private.sector_write_guards as guard(asset_id, revision)
    values(requested_asset, 1)
    on conflict(asset_id) do update set revision = guard.revision + 1;
end $$;

revoke all on function private.assert_theme_owner(uuid, boolean), private.lock_theme_asset(uuid)
  from public, anon, authenticated;

create function public.create_theme(theme_name text)
returns uuid language plpgsql security definer set search_path = '' as $$
declare created_id uuid;
begin
  if not public.is_authorized_user() then raise exception 'Access denied' using errcode = '42501'; end if;
  if theme_name is null or length(btrim(theme_name)) not between 1 and 160 then
    raise exception 'Invalid theme name' using errcode = '23514';
  end if;
  insert into public.themes(owner_user_id, name)
    values(auth.uid(), btrim(theme_name)) returning id into created_id;
  return created_id;
end $$;

create function public.rename_theme(theme_id uuid, theme_name text)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_theme_owner(theme_id);
  if theme_name is null or length(btrim(theme_name)) not between 1 and 160 then
    raise exception 'Invalid theme name' using errcode = '23514';
  end if;
  update public.themes set name = btrim(theme_name)
    where id = theme_id and owner_user_id = auth.uid();
end $$;

create function public.set_theme_active(theme_id uuid, active boolean)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_theme_owner(theme_id);
  if active is null then raise exception 'Invalid theme status' using errcode = '23514'; end if;
  update public.themes set is_active = active
    where id = theme_id and owner_user_id = auth.uid();
end $$;

create function public.delete_theme(theme_id uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.assert_theme_owner(theme_id);
  if exists(select 1 from public.asset_theme_exposures exposure where exposure.theme_id = delete_theme.theme_id) then
    raise exception 'Theme is referenced' using errcode = '23503';
  end if;
  delete from public.themes where id = theme_id and owner_user_id = auth.uid();
end $$;

create function public.save_asset_theme_draft(
  aid uuid,
  items jsonb,
  data_date date default null,
  source text default null,
  origin text default 'user'
)
returns void language plpgsql security definer set search_path = '' as $$
declare item jsonb; requested_theme uuid; requested_weight numeric;
begin
  perform private.lock_theme_asset(aid);
  if jsonb_typeof(items) is distinct from 'array' then
    raise exception 'Invalid theme distribution' using errcode = '22023';
  end if;
  if data_date is not null and not isfinite(data_date) then
    raise exception 'Invalid data date' using errcode = '22023';
  end if;
  if source is not null and length(btrim(source)) not between 1 and 2000 then
    raise exception 'Invalid source' using errcode = '23514';
  end if;
  if origin is not null and origin !~ '^[a-z0-9_-]{1,50}$' then
    raise exception 'Invalid origin' using errcode = '23514';
  end if;

  for item in select value from jsonb_array_elements(items) loop
    begin
      requested_theme := (item ->> 'theme_id')::uuid;
      requested_weight := (item ->> 'weight_percent')::numeric;
    exception when others then
      raise exception 'Invalid theme item' using errcode = '22023';
    end;
    if requested_weight is null or requested_weight <= 0 or requested_weight > 100
      or trunc(requested_weight, 2) <> requested_weight then
      raise exception 'Weight must be in (0,100] with at most two decimals' using errcode = '23514';
    end if;
    if not exists(
      select 1 from public.themes t
      where t.id = requested_theme and t.owner_user_id = auth.uid()
        and (t.is_active or exists(
          select 1 from public.asset_theme_exposures existing
          where existing.asset_id = aid and existing.theme_id = t.id
        ))
    ) then
      raise exception 'Theme unavailable' using errcode = '42501';
    end if;
  end loop;

  insert into public.asset_theme_exposure_sets(asset_id, stage, data_date, source, origin)
    values(aid, 'draft', data_date, nullif(btrim(source), ''), origin)
    on conflict(asset_id, stage) do update
      set data_date = excluded.data_date, source = excluded.source,
          origin = excluded.origin, updated_at = clock_timestamp();
  delete from public.asset_theme_exposures where asset_id = aid and stage = 'draft';
  for item in select value from jsonb_array_elements(items) loop
    insert into public.asset_theme_exposures(asset_id, stage, theme_id, weight_percent)
      values(aid, 'draft', (item ->> 'theme_id')::uuid, (item ->> 'weight_percent')::numeric);
  end loop;
end $$;

create function public.publish_asset_theme_draft(aid uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.lock_theme_asset(aid);
  if not exists(select 1 from public.asset_theme_exposure_sets where asset_id = aid and stage = 'draft') then
    raise exception 'Theme draft unavailable' using errcode = '23514';
  end if;
  delete from public.asset_theme_exposure_sets where asset_id = aid and stage = 'effective';
  insert into public.asset_theme_exposure_sets(asset_id, stage, data_date, source, origin)
    select asset_id, 'effective', data_date, source, origin
    from public.asset_theme_exposure_sets where asset_id = aid and stage = 'draft';
  insert into public.asset_theme_exposures(asset_id, stage, theme_id, weight_percent)
    select asset_id, 'effective', theme_id, weight_percent
    from public.asset_theme_exposures where asset_id = aid and stage = 'draft';
  delete from public.asset_theme_exposure_sets where asset_id = aid and stage = 'draft';
end $$;

create function public.discard_asset_theme_draft(aid uuid)
returns void language plpgsql security definer set search_path = '' as $$
begin
  perform private.lock_theme_asset(aid);
  delete from public.asset_theme_exposure_sets where asset_id = aid and stage = 'draft';
end $$;

create function public.effective_asset_theme_exposures(requested_assets uuid[])
returns table(
  asset_id uuid, theme_id uuid, weight_percent numeric,
  data_date date, source text, origin text, updated_at timestamptz
)
language plpgsql stable security invoker set search_path = '' as $$
begin
  if not public.is_authorized_user() then raise exception 'Access denied' using errcode = '42501'; end if;
  return query
    select item.asset_id, item.theme_id, item.weight_percent,
           exposure_set.data_date, exposure_set.source, exposure_set.origin, exposure_set.updated_at
    from public.asset_theme_exposures item
    join public.asset_theme_exposure_sets exposure_set
      on exposure_set.asset_id = item.asset_id and exposure_set.stage = item.stage
    where item.stage = 'effective' and item.asset_id = any(requested_assets);
end $$;

revoke all on function public.create_theme(text), public.rename_theme(uuid, text),
  public.set_theme_active(uuid, boolean), public.delete_theme(uuid),
  public.save_asset_theme_draft(uuid, jsonb, date, text, text),
  public.publish_asset_theme_draft(uuid), public.discard_asset_theme_draft(uuid),
  public.effective_asset_theme_exposures(uuid[])
  from public, anon;
grant execute on function public.create_theme(text), public.rename_theme(uuid, text),
  public.set_theme_active(uuid, boolean), public.delete_theme(uuid),
  public.save_asset_theme_draft(uuid, jsonb, date, text, text),
  public.publish_asset_theme_draft(uuid), public.discard_asset_theme_draft(uuid),
  public.effective_asset_theme_exposures(uuid[])
  to authenticated;

commit;
