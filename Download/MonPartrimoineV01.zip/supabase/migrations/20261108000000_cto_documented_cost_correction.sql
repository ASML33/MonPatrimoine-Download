-- Local synthetic qualification only.
begin;
-- Reconstitute the two trigger definitions from the original liquid savings deployment.
-- Both exact definitions and the complete predecessor seal are verified before any repair.
do $replay$
declare entry record; original text; historical text;
begin
 if private.app_backup_schema() is distinct from 'ca1a2b5cfb965c3b2831322fa24d96828fab8d86bd0f8ae081a4f6952c559582'
 then return; end if;
 for entry in select * from (values
    ('public.guard_liquid_savings_retirement()', '9ce25eedba1c3b1c28635ce7e57b4b84', 'd79e0c8b4bfcbe61f121e28f4b75da5b', array[4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]),
    ('public.lock_liquid_savings_cash_parent()', '88f69a57ffe6e888a2137cac263cdb85', '08b384d3c3f0f057f4bf61d8cc2165b2', array[5, 6, 7, 8, 9, 10, 11])
 ) as source(signature, clean_hash, historical_hash, cr_offsets)
 loop
  original:=pg_get_functiondef(entry.signature::regprocedure);
  if md5(original) is distinct from entry.clean_hash
  then raise exception 'Unexpected clean replay definition for %', entry.signature; end if;
  select string_agg(line || case when ordinality - 1 = any(entry.cr_offsets) then chr(13) else '' end, chr(10) order by ordinality)
  into historical from unnest(string_to_array(original, chr(10))) with ordinality as lines(line, ordinality);
  if md5(historical) is distinct from entry.historical_hash
  then raise exception 'Unexpected historical replay definition for %', entry.signature; end if;
  execute historical;
 end loop;
end $replay$;

do $preflight$
begin
 if (select count(*) from supabase_migrations.schema_migrations) <> 89
 or exists(select 1 from supabase_migrations.schema_migrations where version='20261031000001')
 or private.app_backup_schema() is distinct from '453c2862b1178534239de99c96ef8e72b15cf37f0bb3c0956f6f6118c62d8fa2'
 or md5(pg_get_functiondef('public.save_position_observation(uuid,uuid,uuid,uuid,date,numeric,numeric,text,text)'::regprocedure)) <> 'a44c4443d46ece9e6e2ecb6de7fe8ce5'
 or md5(pg_get_functiondef('public.guard_position_observations()'::regprocedure)) <> 'f5ccc87a37451b09e2c665a5ab2f01e1'
 or md5(pg_get_functiondef('public.preview_position_observation(uuid,uuid,uuid,uuid,date,numeric,numeric,text)'::regprocedure)) <> 'c5d8d4126a440fa74fca84ef309d2364'
 or md5(pg_get_functiondef('public.save_securities_position_action(uuid,uuid,uuid,uuid,date,numeric,numeric,text,timestamptz,uuid)'::regprocedure)) <> '173374a0d98fe033e626dffaac729385'
 then raise exception 'CTO documented cost predecessor drift'; end if;
end $preflight$;

create table private.cto_documented_cost_context (
 transaction_id bigint not null, backend_id integer not null, owner_id uuid not null,
 contract_id uuid not null, asset_id uuid not null, observation_id uuid not null,
 effective_on date not null, quantity numeric not null, native_cost numeric not null,
 currency text not null, evidence jsonb not null,
 primary key(transaction_id,backend_id,owner_id,contract_id,asset_id,observation_id)
);
alter table private.cto_documented_cost_context enable row level security;
alter table private.cto_documented_cost_context force row level security;
revoke all on private.cto_documented_cost_context from public,anon,authenticated,service_role;

create function public.cto_documented_cost_context(c uuid,a uuid,o uuid,d date,q numeric,n numeric,cur text)
returns jsonb language sql stable security definer set search_path='' as $$
 select evidence from private.cto_documented_cost_context
 where transaction_id=txid_current_if_assigned() and backend_id=pg_backend_pid()
 and owner_id=auth.uid() and contract_id=c and asset_id=a and observation_id=o
 and effective_on=d and quantity=q and native_cost=n and currency=cur
$$;
revoke all on function public.cto_documented_cost_context(uuid,uuid,uuid,date,numeric,numeric,text) from public,anon,service_role;
grant execute on function public.cto_documented_cost_context(uuid,uuid,uuid,date,numeric,numeric,text) to authenticated;

CREATE OR REPLACE FUNCTION public.preview_position_observation(requested_contract uuid, requested_asset uuid, requested_position uuid, requested_observation uuid, requested_date date, requested_quantity numeric, requested_cost numeric, requested_currency text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
declare p public.positions; h jsonb; entries jsonb; previous jsonb; incoming jsonb; next_entries jsonb; plan jsonb; oid uuid:=coalesce(requested_observation,gen_random_uuid()); state_hash text; stamp timestamptz:=clock_timestamp(); parent public.contracts;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 select * into parent from public.contracts where id=requested_contract and user_id=auth.uid();
 if not found or not parent.is_active then raise exception 'Active contract required' using errcode='42501';end if;
 if requested_date is null or requested_date>(stamp at time zone 'Europe/Paris')::date or requested_date<parent.opened_on
 or requested_quantity is null or requested_quantity<0 or requested_quantity>=1e16 or requested_quantity<>round(requested_quantity,8)
 or requested_cost<0 or requested_cost>=1e16 or (requested_cost<>round(requested_cost,8)and not public.cto_broker_cost_precision(requested_contract,requested_asset,requested_date,requested_cost,requested_currency)and not(requested_cost=round(requested_cost,20)and exists(select 1 from public.contracts cc join public.envelope_types ee on ee.id=cc.envelope_type_id where cc.id=requested_contract and cc.user_id=auth.uid()and ee.code in('cto','compte_titres'))))
 or not exists(select 1 from public.currencies where code=requested_currency and is_active) then raise exception 'Invalid dated holding' using errcode='22023';end if;
 select * into p from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid();
 if requested_position is not null and p.id is distinct from requested_position then raise exception 'Position unavailable' using errcode='40001';end if;
 if p.id is null then
  if not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required' using errcode='42501';end if;
 elsif not p.is_active and not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required for reactivation' using errcode='23514';end if;
 h:=coalesce(p.metadata->'position_observations',jsonb_build_object('version',1,'entries','[]'::jsonb,'archived','[]'::jsonb,'bindings','[]'::jsonb,'receipts','[]'::jsonb));
 entries:=h->'entries';select e into previous from jsonb_array_elements(entries) e where e->>'id'=oid::text;
 incoming:=jsonb_build_object('id',oid,'version',coalesce((previous->>'version')::int,0)+1,'effectiveOn',requested_date,'quantity',requested_quantity::text,'unitCost',case when requested_cost is null then null else requested_cost::text end,'currency',requested_currency,'recordedAt',stamp,'provenance','Situation saisie et confirmée par l’utilisateur');
 select coalesce(jsonb_agg(e order by e->>'effectiveOn'),'[]') into next_entries from jsonb_array_elements(entries) e where e->>'id'<>oid::text and case when exists(select 1 from public.envelope_types t where t.id=parent.envelope_type_id and t.code in('pea','pea_pme','cto','compte_titres'))then (e->>'effectiveOn')::date<requested_date else e->>'effectiveOn'<>requested_date::text end;
 if previous is not null and (previous->>'effectiveOn')::date=requested_date and (previous->>'quantity')::numeric=requested_quantity and (previous->>'unitCost')::numeric is not distinct from requested_cost and previous->>'currency'=requested_currency then incoming:=previous;end if;
 declare
  correction jsonb := public.cto_documented_cost_context(requested_contract,requested_asset,oid,requested_date,requested_quantity,requested_cost,requested_currency);
  basis jsonb := public.position_observation_at(entries,requested_date);
 begin
  if correction is not null then
   select coalesce(jsonb_agg(e order by e->>'effectiveOn'),'[]') into next_entries
   from jsonb_array_elements(entries) e
   where e->>'id'<>oid::text and e->>'effectiveOn'<>requested_date::text;
   if incoming is not distinct from previous then
    incoming:=incoming||jsonb_build_object('version',(incoming->>'version')::int+1,'recordedAt',stamp);
   end if;
   incoming:=incoming||jsonb_build_object('costEvidence',correction);
  elsif basis ? 'costEvidence' and basis->>'currency'=requested_currency
    and (basis->>'unitCost')::numeric is not distinct from requested_cost then
   incoming:=incoming||jsonb_build_object('costEvidence',basis->'costEvidence');
  end if;
 end;
 next_entries:=next_entries||jsonb_build_array(incoming);
 if p.id is not null and p.quantity=0 and coalesce((public.position_observation_at(next_entries,(stamp at time zone 'Europe/Paris')::date)->>'quantity')::numeric,0)>0 and not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required for renewed holding' using errcode='23514';end if;
 plan:=public.position_capture_plan(requested_contract,requested_asset,entries,next_entries);
 select md5(coalesce(jsonb_agg(jsonb_build_array(id,revision,inputs,result) order by id)::text,'')) into state_hash from public.patrimonial_daily_captures where user_id=auth.uid() and state='published';
 state_hash:=md5(state_hash||coalesce((select jsonb_agg(jsonb_build_array(id,payload) order by id)::text from public.patrimonial_legacy_sources where user_id=auth.uid()),''));
 return plan||jsonb_build_object('observation',incoming,'previous',previous,'nextEntries',next_entries,'history',h,'position',to_jsonb(p),'destination', (select e from jsonb_array_elements(entries) e where e->>'effectiveOn'=requested_date::text and e->>'id'<>oid::text),'token',md5(coalesce(to_jsonb(p)::text,'null')||state_hash||jsonb_build_array(requested_contract,requested_asset,oid,requested_date,requested_quantity,requested_cost,requested_currency)::text));
end$function$;

CREATE OR REPLACE FUNCTION public.save_securities_position_action(requested_contract uuid, requested_asset uuid, requested_position uuid, requested_observation uuid, requested_date date, requested_quantity numeric, requested_cost numeric, requested_currency text, expected_position_updated_at timestamp with time zone, requested_request uuid)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare p public.positions; parent public.contracts; plan jsonb; receipt private.securities_action_requests; payload jsonb; oid uuid:=coalesce(requested_observation,requested_request); saved uuid;
begin
 if auth.uid()is null or public.is_authorized_user()is not true then raise exception'Unauthorized'using errcode='42501';end if;
 if requested_request is null then raise exception'Invalid request'using errcode='22023';end if;
 select * into parent from public.contracts where id=requested_contract and user_id=auth.uid()for update;
 if not found or not exists(select 1 from public.envelope_types t where t.id=parent.envelope_type_id and t.code in('pea','pea_pme','cto','compte_titres'))then raise exception'Unauthorized contract'using errcode='42501';end if;
 payload:=jsonb_build_array('position',requested_contract,requested_asset,requested_position,requested_observation,requested_date,requested_quantity,requested_cost,requested_currency,expected_position_updated_at);
 select * into receipt from private.securities_action_requests where user_id=auth.uid()and request_id=requested_request;
 if found then if receipt.payload is distinct from payload then raise exception'SECURITIES-REPLAY'using errcode='40001';end if;
  if not exists(select 1 from public.positions replay_position where replay_position.id=receipt.result and replay_position.user_id=auth.uid()and replay_position.metadata#>array['securities_action_requests',requested_request::text]=payload)then raise exception'SECURITIES-JOURNAL-MISMATCH'using errcode='40001';end if;return receipt.result;
 end if;
 select * into p from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid()for update;
 if p.updated_at is distinct from expected_position_updated_at or p.id is distinct from requested_position then raise exception'SECURITIES-STALE'using errcode='40001';end if;
 if p.id is not null and exists(select 1 from public.assets a where a.id=p.asset_id and a.asset_type_code='fund'and a.valuation_mode='manual')and exists(select 1 from public.position_snapshots s where s.position_id=p.id and s.user_id=auth.uid())then raise exception'Legacy amount holding requires a qualified transition'using errcode='23514';end if;
 if exists(select 1 from public.envelope_types e where e.id=parent.envelope_type_id and e.code in ('cto','compte_titres'))
 and not exists(
  select 1 from private.cto_broker_repair_permits permit
  cross join lateral jsonb_array_elements(permit.plan->'positions') line
  where permit.tx=txid_current() and permit.backend=pg_backend_pid() and permit.owner=auth.uid()
    and permit.contract_id=requested_contract and permit.plan->>'date'=requested_date::text
    and line->>'assetId'=requested_asset::text and requested_currency='USD'
    and (line->>'quantity')::numeric=requested_quantity and (line->>'unitCostUsd')::numeric=requested_cost
    and requested_request=md5(permit.request_id::text||':'||p.id::text)::uuid and oid=requested_request
 )
 and not coalesce(
  p.id is not null and requested_cost=p.average_cost_per_unit and requested_currency=btrim(p.cost_currency_code)
  and p.metadata ? 'cto_broker_basis'
  and public.cto_broker_cost_precision(requested_contract,requested_asset,requested_date,requested_cost,requested_currency)
  and exists(
   select 1 from jsonb_array_elements(coalesce(p.metadata#>'{position_observations,entries}','[]')) e
   where (requested_observation is null or e->>'id'=requested_observation::text)
     and e->>'effectiveOn'=requested_date::text
     and (e->>'unitCost')::numeric=requested_cost and e->>'currency'=requested_currency
     and not exists(select 1 from jsonb_array_elements(p.metadata#>'{position_observations,entries}') later
                    where later->>'effectiveOn'>requested_date::text)
  ),false
 )
 then raise exception 'CTO-COST-RELOAD' using errcode='40001'; end if;
 if requested_cost is not null and requested_cost<>round(requested_cost,2)and not(public.cto_broker_cost_precision(requested_contract,requested_asset,requested_date,requested_cost,requested_currency)and(exists(select 1 from private.cto_broker_repair_permits permit where permit.tx=txid_current()and permit.backend=pg_backend_pid()and permit.owner=auth.uid()and permit.contract_id=requested_contract)or(requested_cost=p.average_cost_per_unit and requested_currency=btrim(p.cost_currency_code))))then raise exception'PRU: two decimals'using errcode='22023';end if;
 perform public.lock_position_capture_sources();
 plan:=public.preview_position_observation(requested_contract,requested_asset,requested_position,oid,requested_date,requested_quantity,requested_cost,requested_currency);
 saved:=public.save_position_observation(requested_contract,requested_asset,requested_position,oid,requested_date,requested_quantity,requested_cost,requested_currency,plan->>'token');
 update public.positions set metadata=metadata||jsonb_build_object('securities_action_requests',coalesce(metadata->'securities_action_requests','{}')||jsonb_build_object(requested_request::text,payload))where id=saved and user_id=auth.uid();
 insert into private.securities_action_requests(user_id,contract_id,request_id,payload,result)values(auth.uid(),requested_contract,requested_request,payload,saved);
 return saved;
end$function$;

create function public.correct_cto_historical_cost(
 requested_contract uuid, requested_asset uuid, requested_position uuid,
 requested_date date, expected_position_updated_at timestamptz, requested_request uuid,
 requested_historical_cost_eur numeric, requested_cost_source text
) returns uuid language plpgsql security definer set search_path='' as $$
declare
 parent public.contracts;
 holding public.positions;
 prior jsonb;
 exact_day jsonb;
 receipt private.securities_action_requests;
 payload jsonb;
 evidence jsonb;
 saved uuid;
 target_observation uuid;
 native_cost numeric;
 native_quantity numeric;
 native_currency text;
 plan jsonb;
 source text := nullif(btrim(requested_cost_source),'');
begin
 if auth.uid() is null or public.is_authorized_user() is not true then
  raise exception 'Unauthorized' using errcode='42501';
 end if;
 select * into parent from public.contracts where id=requested_contract and user_id=auth.uid() for update;
 if not found or not exists(select 1 from public.envelope_types where id=parent.envelope_type_id and code in ('cto','compte_titres')) then
  raise exception 'Unauthorized CTO' using errcode='42501';
 end if;
 if requested_request is null or requested_position is null or requested_date is null or source is null or length(source)>500
 or requested_historical_cost_eur is null or requested_historical_cost_eur<0 or requested_historical_cost_eur>=1e16
 or requested_historical_cost_eur<>round(requested_historical_cost_eur,8) then
  raise exception 'Historical EUR cost requires its document reference' using errcode='22023';
 end if;
 payload:=jsonb_build_array('position',requested_contract,requested_asset,requested_position,'cto-documented-eur-v1',
  requested_date,expected_position_updated_at,requested_historical_cost_eur,source);
 select * into receipt from private.securities_action_requests where user_id=auth.uid() and request_id=requested_request;
 if found then
  if receipt.payload is distinct from payload or not exists(select 1 from public.positions r where r.id=receipt.result
   and r.user_id=auth.uid() and r.metadata#>array['securities_action_requests',requested_request::text]=payload) then
   raise exception 'SECURITIES-REPLAY' using errcode='40001';
  end if;
  return receipt.result;
 end if;
 select * into holding from public.positions where id=requested_position and contract_id=requested_contract
  and asset_id=requested_asset and user_id=auth.uid() for update;
 if not found or holding.updated_at is distinct from expected_position_updated_at then
  raise exception 'SECURITIES-STALE' using errcode='40001';
 end if;
 prior:=public.position_observation_at(coalesce(holding.metadata#>'{position_observations,entries}','[]'),requested_date);
 native_cost:=(prior->>'unitCost')::numeric;
 native_quantity:=(prior->>'quantity')::numeric;
 native_currency:=prior->>'currency';
 if native_cost is null or native_quantity is null or native_currency is null
 or (native_currency='EUR' and requested_historical_cost_eur<>native_cost) then
  raise exception 'No matching native observation' using errcode='22023';
 end if;
 exact_day:=case when prior->>'effectiveOn'=requested_date::text then prior else null end;
 target_observation:=coalesce((exact_day->>'id')::uuid,requested_request);
 evidence:=coalesce(prior->'costEvidence','{}')||jsonb_build_object(
  'version',1,'nativeUnitCost',prior->>'unitCost','currency',native_currency,
  'fiscalUnitCostEur',requested_historical_cost_eur::text,'fiscalSource',source,'fiscalRecordedAt',clock_timestamp(),
  'fiscalEffectiveOn',requested_date,'fiscalObservationId',target_observation);
 insert into private.cto_documented_cost_context values(txid_current(),pg_backend_pid(),auth.uid(),requested_contract,
  requested_asset,target_observation,requested_date,native_quantity,native_cost,native_currency,evidence);
 perform public.lock_position_capture_sources();
 plan:=public.preview_position_observation(requested_contract,requested_asset,requested_position,target_observation,
  requested_date,native_quantity,native_cost,native_currency);
 saved:=public.save_position_observation(requested_contract,requested_asset,requested_position,target_observation,
  requested_date,native_quantity,native_cost,native_currency,plan->>'token');
 delete from private.cto_documented_cost_context context where transaction_id=txid_current() and backend_id=pg_backend_pid()
  and owner_id=auth.uid() and contract_id=requested_contract and asset_id=requested_asset and context.observation_id=target_observation;
 update public.positions set metadata=metadata||jsonb_build_object('securities_action_requests',
  coalesce(metadata->'securities_action_requests','{}')||jsonb_build_object(requested_request::text,payload))
 where id=saved and user_id=auth.uid();
 insert into private.securities_action_requests(user_id,contract_id,request_id,payload,result)
 values(auth.uid(),requested_contract,requested_request,payload,saved);
 return saved;
end $$;
revoke all on function public.correct_cto_historical_cost(uuid,uuid,uuid,date,timestamptz,uuid,numeric,text) from public,anon,service_role;
grant execute on function public.correct_cto_historical_cost(uuid,uuid,uuid,date,timestamptz,uuid,numeric,text) to authenticated;
do $$ begin
 if private.app_backup_schema() is distinct from '453c2862b1178534239de99c96ef8e72b15cf37f0bb3c0956f6f6118c62d8fa2'
 then raise exception 'CTO documented cost schema seal changed'; end if;
end $$;
commit;
