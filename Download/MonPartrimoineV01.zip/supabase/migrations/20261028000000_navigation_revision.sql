-- Read-only version of the owner's visible graph dependencies. No data, table,
-- trigger, RLS policy or archive format is changed. No global/shared data cache.
begin;
set local lock_timeout='5s';
set local statement_timeout='20s';
create or replace function public.patrimony_navigation_revision()
returns text language plpgsql stable security invoker set search_path = '' as $$
declare relation_name text; part text; parts text := 'navigation-v1';
begin
  if auth.uid() is null or not public.is_authorized_user() then
    raise exception 'Access denied' using errcode = '42501';
  end if;
  -- Explicit physical dependencies of charts/current report and their SQL views.
  -- MVCC versions detect UPDATE (even backdated), INSERT and DELETE without
  -- reading the large capture payloads or relying on optional updated_at fields.
  -- Every SELECT runs as the caller, under the existing RLS/column privileges.
  foreach relation_name in array array[
    'assets','themes','sectors','fx_rates','profiles','contracts','positions',
    'cash_flows','currencies','asset_prices','fiscal_rules','cash_balances',
    'envelope_types','fiscal_regimes','sector_activities','exposure_countries',
    'geographic_regions','position_snapshots','user_sector_labels',
    'envelope_fiscalities','asset_theme_exposures','asset_sector_exposures',
    'asset_exposure_versions','envelope_fiscal_regimes','property_consolidations',
    'asset_activity_exposures','cash_balance_snapshots','asset_geography_exposures',
    'asset_theme_exposure_sets','asset_price_refresh_status',
    'contract_manual_situations','patrimonial_daily_captures',
    'patrimonial_legacy_sources','contract_manual_simulations',
    'user_fiscal_regime_preferences','patrimonial_legacy_account_maps'
  ] loop
    execute format('select coalesce(string_agg(xmin::text || '':'' || ctid::text, '','' order by ctid), '''') from public.%I', relation_name) into part;
    parts := parts || '|' || relation_name || ':' || pg_catalog.encode(pg_catalog.sha256(pg_catalog.convert_to(part,'UTF8')),'hex');
  end loop;
  return pg_catalog.encode(pg_catalog.sha256(pg_catalog.convert_to(parts,'UTF8')),'hex');
end $$;
revoke all on function public.patrimony_navigation_revision() from public, anon;
grant execute on function public.patrimony_navigation_revision() to authenticated;
comment on function public.patrimony_navigation_revision() is
  'Opaque read-only revision of visible navigation dependencies, under caller RLS. Not an authorization or archive fingerprint.';

commit;
