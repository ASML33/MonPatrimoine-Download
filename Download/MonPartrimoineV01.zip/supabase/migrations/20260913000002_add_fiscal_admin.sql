﻿-- MonPatrimoine - Phase 2
-- Add admin role and fiscal_rules administration policies.
-- Regular users keep full control of their own profile data,
-- except that the role cannot be changed by an authenticated user.

alter table public.profiles
  add column role text not null default 'user';

alter table public.profiles
  add constraint profiles_role_check
  check (role in ('user', 'admin'));

-- Helper used by RLS policies.
-- SECURITY DEFINER avoids relying on the caller's ability to read
-- another user's profile while checking the current user's role.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.profiles
    where auth_user_id = auth.uid()
      and role = 'admin'
      and is_active = true
  );
$$;

revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to authenticated;

-- Prevent authenticated users from changing their own role.
-- They retain the existing ability to update all other profile fields.
create function public.prevent_profile_role_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if auth.uid() is not null
     and old.role is distinct from new.role then
    raise exception 'profile role cannot be changed by an authenticated user';
  end if;

  return new;
end;
$$;

revoke all on function public.prevent_profile_role_change() from public;
grant execute on function public.prevent_profile_role_change() to authenticated;

create trigger profiles_prevent_role_change
  before update on public.profiles
  for each row
  execute function public.prevent_profile_role_change();

-- Authenticated users may read fiscal rules.
-- This policy already exists in the previous migration and remains unchanged.

-- Only administrators may create fiscal rules.
create policy fiscal_rules_admin_insert
  on public.fiscal_rules
  for insert
  to authenticated
  with check (public.is_admin());

-- Only administrators may modify fiscal rules.
-- This includes deactivation through active = false.
create policy fiscal_rules_admin_update
  on public.fiscal_rules
  for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- No DELETE policy is created:
-- fiscal rules are deactivated with active = false so their history is preserved.
grant insert, update on table public.fiscal_rules to authenticated;

