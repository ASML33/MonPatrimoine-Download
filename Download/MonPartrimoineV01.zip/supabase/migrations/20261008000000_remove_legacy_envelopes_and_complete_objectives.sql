-- Phase 7 closure: remove the transitional envelope instance layer and expose
-- three independent, concurrency-safe objective dimensions.
begin;

do $$
begin
  if exists(select 1 from public.contracts where envelope_type_id is null or currency_code is null) then
    raise exception 'Legacy envelope removal requires every contract to be classified' using errcode = '23514';
  end if;
  if exists(select 1 from public.envelope_snapshots) then
    raise exception 'Legacy envelope snapshots must be preserved before removal' using errcode = '23514';
  end if;
  if exists(select 1 from public.target_allocations
    where scope_kind <> 'global' or scope_envelope_id is not null
       or target_kind = 'envelope' or target_envelope_id is not null) then
    raise exception 'Legacy envelope objectives require an explicit migration decision' using errcode = '23514';
  end if;
  if exists(select 1 from public.fiscal_rules where envelope_definition_version_id is not null) then
    raise exception 'Linked fiscal history must be remapped before legacy definition removal' using errcode = '23514';
  end if;
end;
$$;

-- Contract identity is now fully carried by the user, type and contract.
drop trigger if exists contracts_envelope_guard on public.contracts;
drop trigger if exists positions_envelope_guard on public.positions;
drop trigger if exists balances_envelope_guard on public.cash_balances;
drop trigger if exists flows_envelope_guard on public.cash_flows;
drop trigger if exists allocations_envelope_guard on public.target_allocations;
drop trigger if exists snapshots_envelope_guard on public.envelope_snapshots;
drop function if exists public.guard_envelope_dependency();

alter table public.contracts
  drop constraint if exists contracts_envelope_id_user_id_fkey,
  drop constraint if exists contracts_envelope_id_name_key;
drop index if exists public.contracts_envelope_active_idx;
alter table public.contracts drop column envelope_id;
alter table public.contracts add constraint contracts_user_name_key unique(user_id,name);

create or replace function public.guard_contract_identity()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.id is distinct from old.id or new.user_id is distinct from old.user_id
     or new.envelope_type_id is distinct from old.envelope_type_id then
    raise exception 'Contract identity and envelope type are immutable' using errcode = '23514';
  end if;
  if new.currency_code is distinct from old.currency_code
     and public.contract_has_dependencies(old.id) then
    raise exception 'Contract currency is locked while data is attached' using errcode = '23514';
  end if;
  return new;
end;
$$;

create or replace function public.guard_contract_reference_model()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  new.name := btrim(new.name);
  new.currency_code := upper(btrim(new.currency_code));
  if not exists(select 1 from public.envelope_types t where t.id = new.envelope_type_id and t.is_active) then
    raise exception 'Envelope type is unavailable' using errcode = '42501';
  end if;
  if not exists(select 1 from public.currencies c where c.code = new.currency_code and c.is_active) then
    raise exception 'Currency is unavailable' using errcode = '42501';
  end if;
  return new;
end;
$$;

-- Remove the two legacy envelope objective axes while preserving global asset
-- targets already stored in the generic engine.
drop function if exists public.target_allocation_status(public.allocation_scope_kind,public.allocation_target_kind,uuid);
drop trigger if exists target_allocations_total_check on public.target_allocations;
drop trigger if exists target_allocations_serialize_writes on public.target_allocations;
drop trigger if exists target_allocations_validate_reference on public.target_allocations;
drop trigger if exists target_allocations_validate_asset_access on public.target_allocations;
drop index if exists public.target_allocations_scope_idx;
drop index if exists public.target_allocations_envelope_unique_idx;
drop index if exists public.target_allocations_asset_unique_idx;
drop index if exists public.target_allocations_envelope_type_unique_idx;
drop index if exists public.target_allocations_contract_unique_idx;
alter table public.target_allocations
  drop constraint if exists target_allocations_check,
  drop constraint if exists target_allocations_scope_envelope_id_user_id_fkey,
  drop constraint if exists target_allocations_target_envelope_id_user_id_fkey,
  drop constraint if exists target_allocations_target_shape_check,
  drop constraint if exists target_allocations_target_percent_check;
alter table public.target_allocations
  drop column if exists scope_envelope_id,
  drop column if exists target_envelope_id,
  drop column if exists target_asset_type_code,
  drop column if exists scope_kind;

alter type public.allocation_target_kind rename to allocation_target_kind_legacy;
create type public.allocation_target_kind as enum ('envelope_type','contract','asset');
alter table public.target_allocations alter column target_kind
  type public.allocation_target_kind using target_kind::text::public.allocation_target_kind;
drop type public.allocation_target_kind_legacy;
drop type public.allocation_scope_kind;

alter table public.target_allocations
  add constraint target_allocations_target_percent_check check (
    (target_percent > 0 and target_percent <= 100)
    or (target_kind = 'asset' and target_percent = -1)
  ),
  add constraint target_allocations_target_shape_check check (
    (target_kind = 'envelope_type' and target_envelope_type_id is not null and target_contract_id is null and target_asset_id is null)
    or (target_kind = 'contract' and target_envelope_type_id is null and target_contract_id is not null and target_asset_id is null)
    or (target_kind = 'asset' and target_envelope_type_id is null and target_contract_id is null and target_asset_id is not null)
  );
create unique index target_allocations_envelope_type_unique_idx
  on public.target_allocations(user_id,target_envelope_type_id) where target_kind='envelope_type';
create unique index target_allocations_contract_unique_idx
  on public.target_allocations(user_id,target_contract_id) where target_kind='contract';
create unique index target_allocations_asset_unique_idx
  on public.target_allocations(user_id,target_asset_id) where target_kind='asset';
create index target_allocations_dimension_idx on public.target_allocations(user_id,target_kind);

revoke insert,update,delete on public.target_allocations from authenticated;
grant select on public.target_allocations to authenticated;

create or replace function public.target_allocation_status(requested_kind public.allocation_target_kind)
returns table(positive_total numeric,remaining_percent numeric,is_complete boolean)
language plpgsql stable security invoker set search_path = '' as $$
begin
  if not public.is_authorized_user() then
    raise exception 'Unauthorized' using errcode = '42501';
  end if;
  if requested_kind is null then
    raise exception 'invalid or inaccessible allocation dimension' using errcode = '22023';
  end if;
  return query select total,100-total,total=100 from (
    select coalesce(sum(target_percent) filter(where target_percent>0),0) total
    from public.target_allocations
    where user_id=auth.uid() and target_kind=requested_kind
  ) values_by_dimension;
end;
$$;
revoke all on function public.target_allocation_status(public.allocation_target_kind) from public,anon;
grant execute on function public.target_allocation_status(public.allocation_target_kind) to authenticated;

create function public.get_target_allocation_revision()
returns bigint language plpgsql stable security definer set search_path = '' as $$
declare result bigint;
begin
  if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501'; end if;
  select revision into result from private.allocation_write_guards where user_id=auth.uid();
  return coalesce(result,0);
end;
$$;
revoke all on function public.get_target_allocation_revision() from public,anon;
grant execute on function public.get_target_allocation_revision() to authenticated;

create function public.save_target_allocations(
  requested_kind public.allocation_target_kind,
  requested_targets jsonb,
  expected_revision bigint
)
returns table(revision bigint,positive_total numeric,is_complete boolean)
language plpgsql security definer set search_path = '' as $$
declare owner_id uuid:=auth.uid(); current_revision bigint; total numeric; item jsonb; target_id uuid; target_value numeric;
begin
  if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501'; end if;
  if requested_kind is null or jsonb_typeof(requested_targets) <> 'array' or expected_revision is null then
    raise exception 'Invalid objective request' using errcode='22023';
  end if;
  insert into private.allocation_write_guards as g(user_id,revision) values(owner_id,0)
    on conflict(user_id) do nothing;
  select g.revision into current_revision from private.allocation_write_guards g
    where g.user_id=owner_id for update;
  if current_revision <> expected_revision then
    raise exception 'Objectives were modified concurrently' using errcode='40001';
  end if;
  if exists(select 1 from jsonb_array_elements(requested_targets) value
    group by value->>'target_id' having count(*)>1) then
    raise exception 'Duplicate objective target' using errcode='23505';
  end if;
  total:=0;
  for item in select value from jsonb_array_elements(requested_targets) loop
    begin
      target_id:=(item->>'target_id')::uuid;
      target_value:=(item->>'target_percent')::numeric;
    exception when others then raise exception 'Invalid objective value' using errcode='22023'; end;
    if target_value is null or target_value>100 or target_value=0 or target_value< -1
       or (target_value=-1 and requested_kind<>'asset') then
      raise exception 'Invalid objective value' using errcode='23514';
    end if;
    if target_value>0 then total:=total+target_value; end if;
    if requested_kind='envelope_type' and not exists(select 1 from public.envelope_types where id=target_id and is_active) then
      raise exception 'Envelope type target is unavailable' using errcode='42501';
    elsif requested_kind='contract' and not exists(select 1 from public.contracts where id=target_id and user_id=owner_id) then
      raise exception 'Contract target is unavailable' using errcode='42501';
    elsif requested_kind='asset' and not exists(select 1 from public.assets where id=target_id and owner_user_id=owner_id and is_active) then
      raise exception 'Asset target is unavailable' using errcode='42501';
    end if;
  end loop;
  if total>100 then raise exception 'Target allocations cannot exceed 100%%' using errcode='23514'; end if;
  delete from public.target_allocations where user_id=owner_id and target_kind=requested_kind;
  insert into public.target_allocations(user_id,target_kind,target_envelope_type_id,target_contract_id,target_asset_id,target_percent)
  select owner_id,requested_kind,
    case when requested_kind='envelope_type' then (value->>'target_id')::uuid end,
    case when requested_kind='contract' then (value->>'target_id')::uuid end,
    case when requested_kind='asset' then (value->>'target_id')::uuid end,
    (value->>'target_percent')::numeric
  from jsonb_array_elements(requested_targets) value;
  update private.allocation_write_guards g set revision=g.revision+1 where g.user_id=owner_id returning g.revision into current_revision;
  return query select current_revision,total,total=100;
end;
$$;
revoke all on function public.save_target_allocations(public.allocation_target_kind,jsonb,bigint) from public,anon;
grant execute on function public.save_target_allocations(public.allocation_target_kind,jsonb,bigint) to authenticated;

-- Unlinked generic fiscal rules remain intact. Only the obsolete historical
-- definition link is removed after the safety assertion above.
drop trigger if exists fiscal_rules_guard_linked_history on public.fiscal_rules;
drop index if exists public.fiscal_rules_envelope_version_idx;
drop index if exists public.fiscal_rules_linked_identity_idx;
alter table public.fiscal_rules drop constraint if exists fiscal_rules_envelope_definition_version_id_fkey;
alter table public.fiscal_rules drop column envelope_definition_version_id;

drop table public.envelope_snapshots;
drop table public.envelopes;
drop table public.envelope_definition_versions;
drop table public.envelope_definitions;

drop function if exists public.envelope_has_dependencies(uuid);
drop function if exists public.create_private_envelope_definition(text,text);
drop function if exists public.guard_envelope_lifecycle();
drop function if exists public.guard_envelope_definition_identity();
drop function if exists public.validate_envelope_definition_use();
drop function if exists public.guard_envelope_version_history();
drop function if exists public.guard_linked_fiscal_history();
drop function if exists public.initialize_envelope_color();
drop function if exists public.normalize_definition_color();
drop function if exists public.validate_target_allocation_reference();
drop function if exists public.validate_target_asset_access();
drop function if exists public.enforce_target_allocation_total();
drop function if exists public.serialize_allocation_writes();

commit;
