begin;
create or replace function public.rename_analysis_input_history(requested_field text,requested_entry uuid,requested_title text,expected_title text default null) returns jsonb language plpgsql security definer set search_path='' as $function$
declare prefs jsonb;doc jsonb;entries jsonb;original jsonb;renamed jsonb;clean text;
begin
 if auth.uid() is null or not public.is_authorized_user()then raise exception 'Unauthorized' using errcode='42501';end if;
 clean:=btrim(requested_title,E' \t\n\r'||chr(160)||chr(8203)||chr(65279));
 if requested_field is null or requested_field not in('question','additionalInformation')or requested_entry is null or clean is null or length(clean)=0 or length(clean)>200 then raise exception 'Invalid title' using errcode='22023';end if;
 select preferences into prefs from public.profiles where auth_user_id=auth.uid() for update;
 if not found then raise exception 'Unauthorized' using errcode='42501';end if;
 doc:=prefs->'ai_photograph';entries:=doc#>array['histories',requested_field];
 if doc->>'historyVersion' is distinct from '1'or jsonb_typeof(entries)is distinct from 'array'then raise exception 'History unavailable';end if;
 select e into original from jsonb_array_elements(entries)e where e->>'id'=requested_entry::text;
 if original is null then raise exception 'Entry unavailable' using errcode='42501';end if;
 if original->>'title'=clean then return original;end if;
 if original->>'title' is distinct from expected_title then raise exception 'Title changed' using errcode='40001';end if;
 renamed:=original||jsonb_build_object('title',clean);
 select jsonb_agg(case when e->>'id'=requested_entry::text then renamed else e end order by ord)into entries from jsonb_array_elements(entries)with ordinality t(e,ord);
 update public.profiles set preferences=jsonb_set(prefs,array['ai_photograph','histories',requested_field],entries)where auth_user_id=auth.uid();
 return renamed;
end$function$;
revoke all on function public.rename_analysis_input_history(text,uuid,text,text)from public,anon;
grant execute on function public.rename_analysis_input_history(text,uuid,text,text)to authenticated;
commit;
