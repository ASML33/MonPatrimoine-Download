begin;

-- The API writes validated PDFs with the server-only Storage client.
-- Restrictive policies prevent direct access even if a broader policy exists.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('monpatrimoine-documentation', 'monpatrimoine-documentation', false, 4194304, array['application/pdf']);

create policy documentation_objects_server_only
on storage.objects as restrictive for all to anon, authenticated
using (bucket_id <> 'monpatrimoine-documentation')
with check (bucket_id <> 'monpatrimoine-documentation');

create policy documentation_bucket_server_only
on storage.buckets as restrictive for all to anon, authenticated
using (id <> 'monpatrimoine-documentation')
with check (id <> 'monpatrimoine-documentation');

commit;
