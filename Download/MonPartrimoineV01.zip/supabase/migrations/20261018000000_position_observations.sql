-- Dated absolute holdings on existing position identities; no business backfill.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
lock table public.positions in share row exclusive mode;
create function public.position_observation_at(entries jsonb, day date) returns jsonb
language sql immutable set search_path='' as $$
 select e from jsonb_array_elements(entries) e where (e->>'effectiveOn')::date<=day order by e->>'effectiveOn' desc limit 1
$$;
create function public.position_capture_plan(cid uuid, aid uuid, prior jsonb, next_entries jsonb)
returns jsonb language plpgsql stable set search_path='' as $$
declare r record; before_e jsonb; after_e jsonb; protected boolean; binds jsonb:='[]'; review jsonb:='[]'; native_rows jsonb:='[]'; archived jsonb;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 if exists(select 1 from public.patrimonial_daily_captures where user_id=auth.uid() and state='published' and (inputs#>>'{historicalSelection,authority}'='approved_csv_priority' and result->>'engineVersion'='patrimony-legacy-import-v1' and inputs#>>'{historicalSelection,version}'='1' and inputs#>>'{historicalSelection,sourceSha256}'=inputs->>'sourceSha256' and inputs->>'sourceSha256' ~ '^[a-f0-9]{64}$') group by business_date having count(*)>1) then raise exception 'Ambiguous historical authorities' using errcode='23514';end if;
 if exists(select 1 from public.patrimonial_daily_captures where user_id=auth.uid() and state='published' group by business_date having count(*) filter(where result->>'engineVersion'='patrimony-history-v1')=0 and count(*) filter(where (inputs#>>'{historicalSelection,authority}'='approved_csv_priority' and result->>'engineVersion'='patrimony-legacy-import-v1' and inputs#>>'{historicalSelection,version}'='1' and inputs#>>'{historicalSelection,sourceSha256}'=inputs->>'sourceSha256' and inputs->>'sourceSha256' ~ '^[a-f0-9]{64}$'))=0 and count(distinct coalesce(inputs->>'sourceSha256','null'))>1) then raise exception 'Ambiguous legacy historical sources' using errcode='23514';end if;
 for r in select distinct on (business_date) * from public.patrimonial_daily_captures
   where user_id=auth.uid() and state='published' order by business_date,case when (inputs#>>'{historicalSelection,authority}'='approved_csv_priority' and result->>'engineVersion'='patrimony-legacy-import-v1' and inputs#>>'{historicalSelection,version}'='1' and inputs#>>'{historicalSelection,sourceSha256}'=inputs->>'sourceSha256' and inputs->>'sourceSha256' ~ '^[a-f0-9]{64}$') then 0 when result->>'engineVersion'='patrimony-history-v1' then 1 else 2 end,revision desc,captured_at desc,id loop
  before_e:=public.position_observation_at(prior,r.business_date);
  after_e:=public.position_observation_at(next_entries,r.business_date);
  if before_e is not distinct from after_e then continue; end if;
  if not exists(select 1 from jsonb_array_elements(r.result#>'{report,contracts}') c where c->>'id'=cid::text) then continue;end if;
  protected:=r.result->>'engineVersion'<>'patrimony-history-v1'
   or exists(select 1 from public.patrimonial_daily_captures a where a.user_id=auth.uid() and a.business_date=r.business_date and a.state='published' and (a.inputs#>>'{historicalSelection,authority}'='approved_csv_priority' and a.result->>'engineVersion'='patrimony-legacy-import-v1' and a.inputs#>>'{historicalSelection,version}'='1' and a.inputs#>>'{historicalSelection,sourceSha256}'=a.inputs->>'sourceSha256' and a.inputs->>'sourceSha256' ~ '^[a-f0-9]{64}$'))
   or exists(select 1 from public.patrimonial_legacy_sources s where s.user_id=auth.uid() and s.business_date=r.business_date and s.payload->>'kind'='approved_contract_correction' and s.payload->>'contractId'=cid::text)
   or exists(select 1 from jsonb_array_elements(coalesce(r.inputs->'contracts','[]')) c where c->>'id'=cid::text and c#>>'{metadata,knownLiquidationNetEur}' is not null)
   or exists(select 1 from jsonb_array_elements(r.result#>'{report,contracts}') c where c->>'id'=cid::text and c->>'manualSituationAt' is not null);
  review:=review||jsonb_build_array(jsonb_build_object('date',r.business_date,'protected',protected,'captureId',r.id));
  if protected then continue;end if;
  select p into archived from jsonb_array_elements(coalesce(r.inputs->'positions','[]')) p where p->>'contract_id'=cid::text and p->>'asset_id'=aid::text limit 1;
  binds:=binds||jsonb_build_array(jsonb_build_object('captureId',r.id,'date',r.business_date,'observation',after_e,'restore',after_e is null and not (coalesce(archived->'metadata','{}') ? 'position_observations')));
  native_rows:=native_rows||jsonb_build_array(jsonb_build_object('id',r.id,'business_date',r.business_date,'revision',r.revision,'captured_at',r.captured_at,'inputs',jsonb_build_object('assets',coalesce((select jsonb_agg(a) from jsonb_array_elements(coalesce(r.inputs->'assets','[]')) a where a->>'id'=aid::text),'[]'),'prices',coalesce((select jsonb_agg(a) from jsonb_array_elements(coalesce(r.inputs->'prices','[]')) a where a->>'asset_id'=aid::text),'[]'),'currentFxRates',coalesce(r.inputs->'currentFxRates','[]'),'historicalFxRates',coalesce(r.inputs->'historicalFxRates','[]')),'result',jsonb_build_object('engineVersion',r.result->>'engineVersion')));
 end loop;
 return jsonb_build_object('bindings',binds,'review',review,'captures',native_rows);
end$$;
create function public.preview_position_observation(requested_contract uuid,requested_asset uuid,requested_position uuid,
 requested_observation uuid,requested_date date,requested_quantity numeric,requested_cost numeric,requested_currency text)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare p public.positions; h jsonb; entries jsonb; previous jsonb; incoming jsonb; next_entries jsonb; plan jsonb; oid uuid:=coalesce(requested_observation,gen_random_uuid()); state_hash text; stamp timestamptz:=clock_timestamp(); parent public.contracts;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 select * into parent from public.contracts where id=requested_contract and user_id=auth.uid();
 if not found or not parent.is_active then raise exception 'Active contract required' using errcode='42501';end if;
 if requested_date is null or requested_date>(stamp at time zone 'Europe/Paris')::date or requested_date<parent.opened_on
 or requested_quantity is null or requested_quantity<0 or requested_quantity>=1e16 or requested_quantity<>round(requested_quantity,8)
 or requested_cost<0 or requested_cost>=1e16 or requested_cost<>round(requested_cost,8)
 or not exists(select 1 from public.currencies where code=requested_currency and is_active) then raise exception 'Invalid dated holding' using errcode='22023';end if;
 select * into p from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid();
 if requested_position is not null and p.id is distinct from requested_position then raise exception 'Position unavailable' using errcode='40001';end if;
 if p.id is null then
  if not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required' using errcode='42501';end if;
 elsif not p.is_active and not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required for reactivation' using errcode='23514';end if;
 h:=coalesce(p.metadata->'position_observations',jsonb_build_object('version',1,'entries','[]'::jsonb,'archived','[]'::jsonb,'bindings','[]'::jsonb,'receipts','[]'::jsonb));
 entries:=h->'entries';select e into previous from jsonb_array_elements(entries) e where e->>'id'=oid::text;
 incoming:=jsonb_build_object('id',oid,'version',coalesce((previous->>'version')::int,0)+1,'effectiveOn',requested_date,'quantity',requested_quantity::text,'unitCost',case when requested_cost is null then null else requested_cost::text end,'currency',requested_currency,'recordedAt',stamp,'provenance','Situation saisie et confirmée par l’utilisateur');
 select coalesce(jsonb_agg(e order by e->>'effectiveOn'),'[]') into next_entries from jsonb_array_elements(entries) e where e->>'id'<>oid::text and e->>'effectiveOn'<>requested_date::text;
 if previous is not null and (previous->>'effectiveOn')::date=requested_date and (previous->>'quantity')::numeric=requested_quantity and (previous->>'unitCost')::numeric is not distinct from requested_cost and previous->>'currency'=requested_currency then incoming:=previous;end if;
 next_entries:=next_entries||jsonb_build_array(incoming);
 if p.id is not null and p.quantity=0 and coalesce((public.position_observation_at(next_entries,(stamp at time zone 'Europe/Paris')::date)->>'quantity')::numeric,0)>0 and not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required for renewed holding' using errcode='23514';end if;
 plan:=public.position_capture_plan(requested_contract,requested_asset,entries,next_entries);
 select md5(coalesce(jsonb_agg(jsonb_build_array(id,revision,inputs,result) order by id)::text,'')) into state_hash from public.patrimonial_daily_captures where user_id=auth.uid() and state='published';
 state_hash:=md5(state_hash||coalesce((select jsonb_agg(jsonb_build_array(id,payload) order by id)::text from public.patrimonial_legacy_sources where user_id=auth.uid()),''));
 return plan||jsonb_build_object('observation',incoming,'previous',previous,'nextEntries',next_entries,'history',h,'position',to_jsonb(p),'destination', (select e from jsonb_array_elements(entries) e where e->>'effectiveOn'=requested_date::text and e->>'id'<>oid::text),'token',md5(coalesce(to_jsonb(p)::text,'null')||state_hash||jsonb_build_array(requested_contract,requested_asset,oid,requested_date,requested_quantity,requested_cost,requested_currency)::text));
end$$;
create function public.lock_position_capture_sources() returns void language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 lock table public.patrimonial_daily_captures,public.patrimonial_legacy_sources in share mode;
end$$;
revoke all on function public.lock_position_capture_sources() from public,anon;
grant execute on function public.lock_position_capture_sources() to authenticated;
create function public.save_position_observation(requested_contract uuid,requested_asset uuid,requested_position uuid,
 requested_observation uuid,requested_date date,requested_quantity numeric,requested_cost numeric,requested_currency text,expected_token text)
returns uuid language plpgsql security invoker set search_path='' as $$
declare p public.positions; plan jsonb; h jsonb; latest jsonb; correction uuid:=gen_random_uuid(); stamp timestamptz:=clock_timestamp(); binds jsonb; meta jsonb; pid uuid;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 perform 1 from public.contracts where id=requested_contract and user_id=auth.uid() for update;
 select * into p from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid() for update;
 if exists(select 1 from jsonb_array_elements(coalesce(p.metadata#>'{position_observations,receipts}','[]')) e where e->>'token'=expected_token and e->'request'=jsonb_build_array(requested_contract,requested_asset,requested_observation,requested_date,requested_quantity,requested_cost,requested_currency)) then return p.id;end if;
 -- Prevent publication/source replacement between confirmation validation and binding.
 perform public.lock_position_capture_sources();
 plan:=public.preview_position_observation(requested_contract,requested_asset,requested_position,requested_observation,requested_date,requested_quantity,requested_cost,requested_currency);
 if plan->>'token' is distinct from expected_token then raise exception 'Preview changed; review again' using errcode='40001';end if;
 h:=plan->'history';
 if plan->'observation' is not distinct from plan->'previous' then return p.id;end if;
 select coalesce(jsonb_agg(b||jsonb_build_object('correctionId',correction)),'[]') into binds from jsonb_array_elements(plan->'bindings') b;
 h:=h||jsonb_build_object('lastReview',plan->'review','entries',plan->'nextEntries','archived',(h->'archived')||jsonb_build_array(jsonb_build_object('entries',h->'entries','undatedPrevious',case when p.id is not null and jsonb_array_length(h->'entries')=0 then jsonb_build_object('quantity',p.quantity::text,'unitCost',case when p.average_cost_per_unit is null then null else p.average_cost_per_unit::text end,'currency',p.cost_currency_code,'isActive',p.is_active) else null end,'replacedAt',stamp,'correctionId',correction)), 'bindings',(h->'bindings')||binds,'receipts',coalesce(h->'receipts','[]')||jsonb_build_array(jsonb_build_object('id',correction,'token',expected_token,'request',jsonb_build_array(requested_contract,requested_asset,requested_observation,requested_date,requested_quantity,requested_cost,requested_currency))));
 latest:=public.position_observation_at(h->'entries',(stamp at time zone 'Europe/Paris')::date);
 meta:=coalesce(p.metadata,'{}')||jsonb_build_object('position_observations',h);
 if p.id is null then
  insert into public.positions(user_id,contract_id,asset_id,quantity,average_cost_per_unit,cost_currency_code,metadata)
  values(auth.uid(),requested_contract,requested_asset,(latest->>'quantity')::numeric,(latest->>'unitCost')::numeric,latest->>'currency',meta) returning id into pid;
 else
  update public.positions set is_active=true,quantity=(latest->>'quantity')::numeric,average_cost_per_unit=(latest->>'unitCost')::numeric,cost_currency_code=latest->>'currency',metadata=meta where id=p.id returning id into pid;
 end if;
 return pid;
end$$;
create function public.guard_position_observations() returns trigger language plpgsql set search_path='' as $$
declare h jsonb; prior jsonb; e jsonb; latest jsonb; seen date[]:='{}'; ids text[]:='{}'; d date; needed jsonb; b jsonb; receipt jsonb; verified jsonb; correction text;
begin
 if tg_op='DELETE' then if old.metadata ? 'position_observations' then raise exception 'Dated holding must be closed with zero' using errcode='23514';end if;return old;end if;
 h:=new.metadata->'position_observations';
 if tg_op='UPDATE' then
  if (new.id,new.user_id,new.contract_id,new.asset_id) is distinct from (old.id,old.user_id,old.contract_id,old.asset_id) then raise exception 'Position identity is immutable' using errcode='23514';end if;
  prior:=old.metadata->'position_observations';
  if prior is not null and not new.is_active then raise exception 'Close dated holding with zero, keeping its identity' using errcode='23514';end if;
  if h is not distinct from prior and (new.quantity,new.average_cost_per_unit,new.cost_currency_code) is not distinct from (old.quantity,old.average_cost_per_unit,old.cost_currency_code) then return new;end if;
 end if;
 if h is null or h->>'version' is distinct from '1' or jsonb_typeof(h->'entries') is distinct from 'array' or jsonb_typeof(h->'archived') is distinct from 'array' or jsonb_typeof(h->'bindings') is distinct from 'array' or jsonb_typeof(h->'receipts') is distinct from 'array' or jsonb_array_length(h->'entries')=0 then raise exception 'Dated observation required' using errcode='23514';end if;
 -- Verify the complete canonical preview even for direct table writes. No caller
 -- supplied flag, schema privilege or bypass of the existing owner RLS is used.
 perform 1 from public.contracts where id=new.contract_id and user_id=auth.uid() for update;
 perform public.lock_position_capture_sources();
 receipt:=h#>'{receipts,-1}'; correction:=receipt->>'id';
 perform correction::uuid;
 if correction is null or jsonb_typeof(receipt->'request') is distinct from 'array' or jsonb_array_length(receipt->'request')<>7
  or (h->'receipts')-(jsonb_array_length(h->'receipts')-1) is distinct from coalesce(prior->'receipts','[]') then raise exception 'Confirmation trace required' using errcode='23514';end if;
 if receipt#>>'{request,0}' is distinct from new.contract_id::text or receipt#>>'{request,1}' is distinct from new.asset_id::text then raise exception 'Confirmation identity differs' using errcode='23514';end if;
 verified:=public.preview_position_observation(new.contract_id,new.asset_id,case when tg_op='UPDATE' then old.id else null end,
  (receipt#>>'{request,2}')::uuid,(receipt#>>'{request,3}')::date,(receipt#>>'{request,4}')::numeric,(receipt#>>'{request,5}')::numeric,receipt#>>'{request,6}');
 select coalesce(jsonb_agg(case when v->>'id'=receipt#>>'{request,2}' then v||jsonb_build_object('recordedAt',(select n->'recordedAt' from jsonb_array_elements(h->'entries') n where n->>'id'=v->>'id')) else v end order by ord),'[]') into e from jsonb_array_elements(verified->'nextEntries') with ordinality t(v,ord);
 verified:=verified||jsonb_build_object('nextEntries',e);
 if h#>'{archived,-1,undatedPrevious}' is distinct from (case when tg_op='UPDATE' and prior is null then jsonb_build_object('quantity',old.quantity::text,'unitCost',case when old.average_cost_per_unit is null then null else old.average_cost_per_unit::text end,'currency',old.cost_currency_code,'isActive',old.is_active) else 'null'::jsonb end) then raise exception 'Undated previous situation must be preserved without inventing a date' using errcode='23514';end if;
 if (h#>>'{archived,-1,replacedAt}')::timestamptz<statement_timestamp() or (h#>>'{archived,-1,replacedAt}')::timestamptz>clock_timestamp() then raise exception 'Invalid correction timestamp' using errcode='23514';end if;
 if verified->>'token' is distinct from receipt->>'token' or verified->'nextEntries' is distinct from h->'entries'
  or verified->'review' is distinct from h->'lastReview' or h#>>'{archived,-1,correctionId}' is distinct from correction
  or h#>>'{archived,-1,replacedAt}' is null then raise exception 'Observation differs from confirmed preview' using errcode='40001';end if;
 for e in select value from jsonb_array_elements(h->'entries') loop
  d:=(e->>'effectiveOn')::date;
  if d is null or e->>'id' is null or jsonb_typeof(e->'quantity') is distinct from 'string' or not (e ? 'unitCost') or jsonb_typeof(e->'unitCost') not in ('string','null') or e->>'version' is null or d=any(seen) or e->>'id'=any(ids) or d>(clock_timestamp() at time zone 'Europe/Paris')::date
   or e->>'quantity' is null or (e->>'quantity')::numeric<0 or (e->>'quantity')::numeric>=1e16 or (e->>'quantity')::numeric<>round((e->>'quantity')::numeric,8)
   or (e->>'unitCost')::numeric<0 or (e->>'unitCost')::numeric>=1e16 or (e->>'unitCost')::numeric<>round((e->>'unitCost')::numeric,8)
   or not exists(select 1 from public.currencies where code=e->>'currency' and is_active)
   or (e->>'version')::int<1 or e->>'recordedAt' is null or (e->>'recordedAt')::timestamptz>clock_timestamp() then raise exception 'Invalid position history' using errcode='23514';end if;
  if e->>'id'=receipt#>>'{request,2}' and (e->>'recordedAt')::timestamptz<statement_timestamp() then raise exception 'Observation timestamp must be recorded by this operation' using errcode='23514';end if;
  perform (e->>'id')::uuid;seen:=array_append(seen,d);ids:=array_append(ids,e->>'id');
 end loop;
 latest:=public.position_observation_at(h->'entries',(clock_timestamp() at time zone 'Europe/Paris')::date);
 if (new.quantity,new.average_cost_per_unit,btrim(new.cost_currency_code)) is distinct from ((latest->>'quantity')::numeric,(latest->>'unitCost')::numeric,latest->>'currency') then raise exception 'Current holding differs from history' using errcode='23514';end if;
 if jsonb_array_length(h->'archived')<>coalesce(jsonb_array_length(prior->'archived'),0)+1 or (h->'archived')-(jsonb_array_length(h->'archived')-1) is distinct from coalesce(prior->'archived','[]') or h#>'{archived,-1,entries}' is distinct from coalesce(prior->'entries','[]') then raise exception 'Previous versions must be preserved' using errcode='23514';end if;
 needed:=public.position_capture_plan(new.contract_id,new.asset_id,coalesce(prior->'entries','[]'),h->'entries');
 if jsonb_array_length(h->'bindings')<>coalesce(jsonb_array_length(prior->'bindings'),0)+jsonb_array_length(needed->'bindings') then raise exception 'Capture replacements missing' using errcode='23514';end if;
 for b in select value from jsonb_array_elements(needed->'bindings') loop
  if not exists(select 1 from jsonb_array_elements(h->'bindings') with ordinality t(n,ord) where ord>coalesce(jsonb_array_length(prior->'bindings'),0) and n-'correctionId'=b and n->>'correctionId'=correction) then raise exception 'Invalid capture replacement' using errcode='23514';end if;
 end loop;
 if prior is not null then
  if (select coalesce(jsonb_agg(value order by ord),'[]') from jsonb_array_elements(h->'bindings') with ordinality t(value,ord) where ord<=jsonb_array_length(prior->'bindings')) is distinct from prior->'bindings' then raise exception 'Capture trace changed' using errcode='23514';end if;
  for e in select value from jsonb_array_elements(prior->'bindings') loop if not (h->'bindings') @> jsonb_build_array(e) then raise exception 'Capture trace removed' using errcode='23514';end if;end loop;
 end if;
 return new;
end$$;
create trigger positions_dated_guard before insert or update or delete on public.positions for each row execute function public.guard_position_observations();
revoke all on function public.guard_position_observations() from public,anon,authenticated;
revoke all on function public.position_observation_at(jsonb,date),public.position_capture_plan(uuid,uuid,jsonb,jsonb) from public,anon;
grant execute on function public.position_observation_at(jsonb,date),public.position_capture_plan(uuid,uuid,jsonb,jsonb) to authenticated;
revoke all on function public.preview_position_observation(uuid,uuid,uuid,uuid,date,numeric,numeric,text),public.save_position_observation(uuid,uuid,uuid,uuid,date,numeric,numeric,text,text) from public,anon;
grant execute on function public.preview_position_observation(uuid,uuid,uuid,uuid,date,numeric,numeric,text),public.save_position_observation(uuid,uuid,uuid,uuid,date,numeric,numeric,text,text) to authenticated;
notify pgrst,'reload schema';
commit;
