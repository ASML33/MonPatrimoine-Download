-- Private envelope CRUD. No historical backfill and no catalogue seed.
begin;

-- All direct dependencies in the current schema. Indirect holdings, cash and
-- flows require a contract, whose presence already makes the envelope nonempty.
create function public.envelope_has_dependencies(envelope_id uuid)
returns boolean language sql stable security invoker set search_path = '' as $$
  select exists(select 1 from public.contracts c where c.envelope_id = $1)
    or exists(select 1 from public.target_allocations a
      where a.scope_envelope_id = $1 or a.target_envelope_id = $1)
    or exists(select 1 from public.envelope_snapshots s where s.envelope_id = $1);
$$;
revoke all on function public.envelope_has_dependencies(uuid) from public, anon;
grant execute on function public.envelope_has_dependencies(uuid) to authenticated;

create function public.guard_envelope_lifecycle()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  new.name := nullif(btrim(new.name), '');
  if tg_op = 'INSERT' then
    if new.opened_on is null then
      raise exception 'Opening date is required' using errcode = '23514';
    end if;
  else
    if new.id is distinct from old.id or new.user_id is distinct from old.user_id then
      raise exception 'Envelope identity is immutable' using errcode = '23514';
    end if;
    if (new.currency_code is distinct from old.currency_code
        or new.envelope_definition_id is distinct from old.envelope_definition_id
        or new.envelope_type_code is distinct from old.envelope_type_code)
       and public.envelope_has_dependencies(old.id) then
      raise exception 'Envelope has dependencies; definition and currency are locked'
        using errcode = '23514';
    end if;
  end if;
  return new;
end;
$$;
create trigger envelopes_00_lifecycle before insert or update on public.envelopes
  for each row execute function public.guard_envelope_lifecycle();

-- Retain definition ownership/activity and legacy provenance guards; enable
-- replacement only through the lifecycle guard above. Detachment stays closed.
create or replace function public.validate_envelope_definition_use()
returns trigger language plpgsql security definer set search_path = '' as $$
declare definition_owner uuid; definition_active boolean;
begin
  if tg_op = 'UPDATE' then
    if (old.envelope_definition_id is not null or new.envelope_definition_id is not null)
       and new.envelope_type_code is distinct from old.envelope_type_code then
      raise exception 'Legacy provenance is immutable when linked' using errcode = '23514';
    end if;
    if old.envelope_definition_id is not null and new.envelope_definition_id is null then
      raise exception 'Definition detachment is not supported' using errcode = '23514';
    end if;
    if new.envelope_definition_id is not distinct from old.envelope_definition_id then
      return new;
    end if;
  elsif new.envelope_definition_id is not null and new.envelope_type_code is not null then
    raise exception 'New linked envelopes cannot supply legacy classification' using errcode = '23514';
  end if;
  if new.envelope_definition_id is null then return new; end if;
  select owner_user_id, is_active into definition_owner, definition_active
    from public.envelope_definitions where id = new.envelope_definition_id for share;
  if not found or not definition_active or
     (definition_owner is not null and definition_owner <> new.user_id) then
    raise exception 'Definition is unavailable' using errcode = '42501';
  end if;
  return new;
end;
$$;

-- Dependency writers UPDATE the parent, not merely SELECT FOR KEY SHARE:
-- this serializes with definition/currency/activation changes, and forces a
-- serialization failure rather than a stale dependency check under RR/SERIALIZABLE.
-- Snapshots remain writable on inactive envelopes: historical recording is not
-- a new investment. Existing rows remain editable; only INSERT/reparenting and
-- reactivation of contracts/positions are new uses.
create function public.guard_envelope_dependency()
returns trigger language plpgsql security definer set search_path = '' as $$
declare parent_id uuid; ref_id uuid; col text; parents uuid[] := '{}';
  active boolean; old_row jsonb; new_row jsonb := to_jsonb(new);
begin
  if tg_op = 'UPDATE' then old_row := to_jsonb(old); end if;
  foreach col in array tg_argv loop
    if tg_op = 'UPDATE' and new_row->col is not distinct from old_row->col
       and not (new_row->>'is_active' = 'true' and old_row->>'is_active' = 'false') then
      continue;
    end if;
    ref_id := (new_row->>col)::uuid;
    if ref_id is null then continue; end if;
    if col like '%contract_id' then
      -- Stabilize the contract/envelope relationship while obtaining its parent.
      select envelope_id into parent_id from public.contracts
        where id = ref_id and user_id = new.user_id for share;
      if not found then raise exception 'Contract unavailable' using errcode = '42501'; end if;
    else parent_id := ref_id;
    end if;
    parents := array_append(parents, parent_id);
  end loop;
  for parent_id in select distinct unnest(parents) order by 1 loop
    update public.envelopes set updated_at = clock_timestamp()
      where id = parent_id and user_id = new.user_id returning is_active into active;
    if not found then raise exception 'Envelope unavailable' using errcode = '42501'; end if;
    if not active and tg_table_name <> 'envelope_snapshots' then
      raise exception 'Envelope is inactive; reactivate it first' using errcode = '23514';
    end if;
  end loop;
  return new;
end;
$$;
create trigger contracts_envelope_guard before insert or update on public.contracts
  for each row execute function public.guard_envelope_dependency('envelope_id');
create trigger allocations_envelope_guard before insert or update on public.target_allocations
  for each row execute function public.guard_envelope_dependency('scope_envelope_id','target_envelope_id');
create trigger snapshots_envelope_guard before insert or update on public.envelope_snapshots
  for each row execute function public.guard_envelope_dependency('envelope_id');
create trigger positions_envelope_guard before insert or update on public.positions
  for each row execute function public.guard_envelope_dependency('contract_id');
create trigger balances_envelope_guard before insert or update on public.cash_balances
  for each row execute function public.guard_envelope_dependency('contract_id');
create trigger flows_envelope_guard before insert or update on public.cash_flows
  for each row execute function public.guard_envelope_dependency('source_contract_id','destination_contract_id');

-- Atomic minimal private definition + version. No owner supplied by the client.
create function public.create_private_envelope_definition(label text, category text)
returns uuid language plpgsql security invoker set search_path = '' as $$
declare definition_id uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required' using errcode = '42501'; end if;
  insert into public.envelope_definitions(owner_user_id,label)
    values(auth.uid(), btrim(label)) returning id into definition_id;
  insert into public.envelope_definition_versions(envelope_definition_id,version_number,category_code,valid_from)
    values(definition_id,1,category,current_date);
  return definition_id;
end;
$$;
revoke all on function public.create_private_envelope_definition(text,text) from public, anon;
grant execute on function public.create_private_envelope_definition(text,text) to authenticated;
revoke all on function public.guard_envelope_lifecycle(), public.guard_envelope_dependency()
  from public, anon, authenticated;
-- Existing owner RLS and all ON DELETE RESTRICT foreign keys remain in force.
commit;
