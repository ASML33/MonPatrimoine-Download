begin;

create function public.get_asset_usage(requested_assets uuid[])
returns table(asset_id uuid,is_used boolean) language sql stable security invoker set search_path='' as $$
  select a.id,public.has_used_asset(a.id) from public.assets a
  where a.owner_user_id=auth.uid() and a.id=any(requested_assets) and public.is_authorized_user();
$$;
create function public.get_contract_dependencies(requested_contracts uuid[])
returns table(contract_id uuid,has_dependencies boolean) language sql stable security invoker set search_path='' as $$
  select c.id,public.contract_has_dependencies(c.id) from public.contracts c
  where c.user_id=auth.uid() and c.id=any(requested_contracts) and public.is_authorized_user();
$$;
revoke all on function public.get_asset_usage(uuid[]),public.get_contract_dependencies(uuid[]) from public,anon;
grant execute on function public.get_asset_usage(uuid[]),public.get_contract_dependencies(uuid[]) to authenticated;

commit;
