-- One effective observation per Paris civil day, within the existing balance identity.
-- Previous versions are retained separately; no business rows are rewritten here.
begin;
set local lock_timeout = '5s';
set local statement_timeout = '30s';
lock table public.cash_balances in share row exclusive mode;

create function public.guard_dated_cash_balance_observations()
returns trigger language plpgsql set search_path = '' as $$
declare
 h jsonb := new.metadata->'cash_balance_observations';
 prior jsonb;
 entry jsonb;
 days date[] := '{}';
 day date;
 latest jsonb;
 archives jsonb;
 old_archives jsonb := '[]';
begin
 if h is null then
   if tg_op='UPDATE' and (old.metadata ? 'cash_balance_observations'
      or row(new.amount,new.as_of) is distinct from row(old.amount,old.as_of)) then
     raise exception 'Dated observation history required' using errcode='23514';
   end if;
   return new;
 end if;
 if h->>'version' is distinct from '2' or jsonb_typeof(h->'entries') is distinct from 'array'
    or jsonb_array_length(h->'entries')=0 or jsonb_typeof(h->'archived') is distinct from 'array' then
   raise exception 'Unsupported dated observation history' using errcode='23514';
 end if;
 for entry in select value from jsonb_array_elements(h->'entries') loop
   if jsonb_typeof(entry->'amount') is distinct from 'string'
      or (entry->>'amount') !~ '^[0-9]{1,16}(\.[0-9]{1,8})?$'
      or entry->>'currencyCode' is distinct from btrim(new.currency_code)
      or entry->>'asOf' is null or entry->>'recordedAt' is null then
     raise exception 'Invalid native cash observation' using errcode='23514';
   end if;
   day := ((entry->>'asOf')::timestamptz at time zone 'Europe/Paris')::date;
   if not isfinite((entry->>'asOf')::timestamptz) or not isfinite((entry->>'recordedAt')::timestamptz)
      or (entry->>'asOf')::timestamptz > clock_timestamp() or day=any(days) then
     raise exception 'Duplicate civil day or invalid observation time' using errcode='23514';
   end if;
   days := array_append(days,day);
   if latest is null or (entry->>'asOf')::timestamptz > (latest->>'asOf')::timestamptz then latest:=entry; end if;
 end loop;
 if (latest->>'amount')::numeric is distinct from new.amount
    or (latest->>'asOf')::timestamptz is distinct from new.as_of then
   raise exception 'Current balance must match latest effective observation' using errcode='23514';
 end if;
 if tg_op='UPDATE' and h is distinct from old.metadata->'cash_balance_observations' then
   prior := old.metadata->'cash_balance_observations';
   if prior is not null then
     if prior->>'version' is distinct from '2' then
       raise exception 'Existing observation history requires explicit review' using errcode='23514';
     end if;
     old_archives := prior->'archived';
   end if;
   archives := h->'archived';
   if jsonb_array_length(archives) <> jsonb_array_length(old_archives)+1
      or (select coalesce(jsonb_agg(value order by ord),'[]') from jsonb_array_elements(archives) with ordinality a(value,ord)
          where ord<=jsonb_array_length(old_archives)) is distinct from old_archives then
     raise exception 'Previous versions must be preserved' using errcode='23514';
   end if;
   entry := archives->-1;
   if entry->>'replacedAt' is null or not isfinite((entry->>'replacedAt')::timestamptz) then
     raise exception 'Correction timestamp required' using errcode='23514';
   end if;
   if prior is not null then
     if entry->'entries' is distinct from prior->'entries' then
       raise exception 'Previous effective observations must be archived exactly' using errcode='23514';
     end if;
   else
     if jsonb_typeof(entry->'entries') is distinct from 'array' or jsonb_array_length(entry->'entries')<>1
        or (entry->'entries'->0->>'amount')::numeric is distinct from old.amount
        or (entry->'entries'->0->>'asOf')::timestamptz is distinct from old.as_of
        or entry->'entries'->0->>'currencyCode' is distinct from btrim(old.currency_code) then
       raise exception 'Original native balance must be archived' using errcode='23514';
     end if;
   end if;
 end if;
 return new;
end;
$$;
revoke all on function public.guard_dated_cash_balance_observations() from public,anon,authenticated;

-- Fail closed on existing prototype/ambiguous histories; never arbitrate data.
do $$ begin
 if exists(select 1 from public.cash_balances where metadata ? 'cash_balance_observations') then
   raise exception 'Existing dated histories require explicit review before migration';
 end if;
 if exists(select 1 from public.cash_balances group by contract_id,currency_code having count(*)>1) then
   raise exception 'Existing balance identities are ambiguous';
 end if;
end $$;
create trigger cash_balances_20_dated_observations before insert or update on public.cash_balances
for each row execute function public.guard_dated_cash_balance_observations();
commit;
