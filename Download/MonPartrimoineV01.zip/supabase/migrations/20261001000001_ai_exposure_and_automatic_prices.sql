-- Phase 7.3E/7.3F: AI-assisted drafts and provider-neutral automatic prices.
begin;

create function public.get_application_principal_for_service()
returns uuid
language sql
stable
security definer
set search_path = ''
as $$
  select auth_user_id from private.application_principal where singleton;
$$;

revoke all on function public.get_application_principal_for_service() from public, anon, authenticated;
grant execute on function public.get_application_principal_for_service() to service_role;

create function public.get_ai_runtime_configuration()
returns table(provider text, api_key text)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  principal uuid;
begin
  select auth_user_id into principal from private.application_principal where singleton;
  return query
  select p.ai_settings ->> 'provider', d.decrypted_secret
  from public.profiles p
  join vault.decrypted_secrets d
    on d.name = 'monpatrimoine.ai.' || principal::text
  where p.auth_user_id = principal
    and p.is_active
    and p.ai_settings ->> 'provider' in ('openai', 'anthropic', 'google')
    and p.ai_settings ->> 'status' = 'configured';
end;
$$;

revoke all on function public.get_ai_runtime_configuration() from public, anon, authenticated;
grant execute on function public.get_ai_runtime_configuration() to service_role;
comment on function public.get_ai_runtime_configuration() is
  'Returns the authorized principal AI credential only to the server service role.';

create table public.price_provider_configurations (
  owner_user_id uuid not null references public.profiles(auth_user_id) on delete cascade on update cascade,
  slot smallint not null check (slot between 1 and 10),
  provider text not null check (provider in ('twelve_data', 'eodhd')),
  active boolean not null default false,
  priority smallint not null check (priority between 1 and 10),
  region text not null check (region in ('us', 'europe', 'global')),
  capability text not null check (capability in ('eod', 'intraday', 'both')),
  status text not null default 'not_configured'
    check (status in ('not_configured', 'configured', 'invalid')),
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  primary key (owner_user_id, slot),
  constraint price_provider_priority_unique unique (owner_user_id, priority)
    deferrable initially deferred,
  constraint eodhd_free_eod_only check (provider <> 'eodhd' or capability = 'eod')
);

alter table public.price_provider_configurations enable row level security;
revoke all on public.price_provider_configurations from public, anon, authenticated;
grant select on public.price_provider_configurations to authenticated;
create policy principal_price_provider_read
on public.price_provider_configurations for select to authenticated
using (public.is_authorized_user() and owner_user_id = auth.uid());

create table public.asset_price_provider_capabilities (
  owner_user_id uuid not null,
  asset_id uuid not null references public.assets(id) on delete cascade on update cascade,
  provider_slot smallint not null,
  capability text not null check (capability in ('eod', 'intraday')),
  market_region text not null check (market_region in ('us', 'europe', 'global')),
  provider_symbol text check (provider_symbol is null or char_length(btrim(provider_symbol)) between 1 and 100),
  status text not null check (status in ('supported', 'unsupported', 'quota_limited', 'temporary_failure', 'authentication_failed')),
  failure_count smallint not null default 0 check (failure_count between 0 and 100),
  last_success_at timestamptz,
  retry_after timestamptz,
  updated_at timestamptz not null default timezone('utc', now()),
  primary key (asset_id, provider_slot, capability),
  foreign key (owner_user_id, provider_slot)
    references public.price_provider_configurations(owner_user_id, slot)
    on delete cascade on update cascade
);

alter table public.asset_price_provider_capabilities enable row level security;
revoke all on public.asset_price_provider_capabilities from public, anon, authenticated;
grant select, insert, update, delete on public.asset_price_provider_capabilities to service_role;

create function public.get_price_provider_configurations()
returns table(
  slot smallint,
  provider text,
  active boolean,
  priority smallint,
  region text,
  capability text,
  status text
)
language sql
stable
security invoker
set search_path = ''
as $$
  select c.slot, c.provider, c.active, c.priority, c.region, c.capability, c.status
  from public.price_provider_configurations c
  where c.owner_user_id = auth.uid()
    and public.is_authorized_user()
  order by c.slot;
$$;

create function public.save_price_provider_configuration(
  requested_slot smallint,
  requested_provider text,
  requested_active boolean,
  requested_priority smallint,
  requested_region text,
  requested_capability text,
  api_key text default null
)
returns void
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  owner_id uuid := auth.uid();
  principal_id uuid;
  current_provider text;
  current_priority smallint;
  current_status text;
  competing_slot smallint;
  replacement_priority smallint;
  secret_id uuid;
  secret_name text;
  next_status text;
begin
  select auth_user_id into principal_id from private.application_principal where singleton;
  if owner_id is null or owner_id is distinct from principal_id
    or not exists (select 1 from public.profiles where auth_user_id = owner_id and is_active) then
    raise exception 'price provider configuration unavailable' using errcode = '42501';
  end if;
  if requested_slot not between 1 and 10 or requested_priority not between 1 and 10
    or requested_provider not in ('twelve_data', 'eodhd')
    or requested_region not in ('us', 'europe', 'global')
    or requested_capability not in ('eod', 'intraday', 'both')
    or (requested_provider = 'eodhd' and requested_capability <> 'eod') then
    raise exception 'invalid price provider configuration' using errcode = '22023';
  end if;
  if api_key is not null and (
    api_key = '' or api_key <> btrim(api_key) or char_length(api_key) > 4096
  ) then
    raise exception 'invalid API key' using errcode = '22023';
  end if;

  select c.provider, c.priority, c.status
    into current_provider, current_priority, current_status
    from public.price_provider_configurations c
    where c.owner_user_id = owner_id and c.slot = requested_slot
    for update;

  secret_name := 'monpatrimoine.price-provider.' || owner_id::text || '.' || requested_slot::text;
  select s.id into secret_id from vault.secrets s where s.name = secret_name;
  if api_key is null and secret_id is not null
    and current_provider is distinct from requested_provider then
    raise exception 'a new key is required when changing provider' using errcode = '22023';
  end if;

  select c.slot into competing_slot
  from public.price_provider_configurations c
  where c.owner_user_id = owner_id
    and c.priority = requested_priority
    and c.slot <> requested_slot
  for update;
  if competing_slot is not null then
    if current_priority is not null then
      replacement_priority := current_priority;
    else
      select candidate::smallint into replacement_priority
      from generate_series(1, 10) candidate
      where candidate <> requested_priority
        and not exists (
          select 1 from public.price_provider_configurations c
          where c.owner_user_id = owner_id and c.priority = candidate
        )
      order by candidate
      limit 1;
    end if;
    if replacement_priority is null then
      raise exception 'no free price provider priority' using errcode = '23514';
    end if;
    update public.price_provider_configurations
      set priority = replacement_priority, updated_at = clock_timestamp()
      where owner_user_id = owner_id and slot = competing_slot;
  end if;

  if api_key is null then
    next_status := case when secret_id is null then 'not_configured'
      when current_status = 'invalid' then 'invalid' else 'configured' end;
  elsif secret_id is null then
    perform vault.create_secret(
      api_key,
      secret_name,
      'MonPatrimoine automatic price provider credential for slot ' || requested_slot::text
    );
    next_status := 'configured';
  else
    perform vault.update_secret(
      secret_id,
      api_key,
      secret_name,
      'MonPatrimoine automatic price provider credential for slot ' || requested_slot::text
    );
    next_status := 'configured';
  end if;

  insert into public.price_provider_configurations (
    owner_user_id, slot, provider, active, priority, region, capability, status
  ) values (
    owner_id, requested_slot, requested_provider, requested_active,
    requested_priority, requested_region, requested_capability, next_status
  ) on conflict (owner_user_id, slot) do update set
    provider = excluded.provider,
    active = excluded.active,
    priority = excluded.priority,
    region = excluded.region,
    capability = excluded.capability,
    status = excluded.status,
    updated_at = clock_timestamp();

  if current_provider is distinct from requested_provider then
    delete from public.asset_price_provider_capabilities
    where owner_user_id = owner_id and provider_slot = requested_slot;
  end if;
end;
$$;

create function public.delete_price_provider_configuration(requested_slot smallint)
returns void
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  owner_id uuid := auth.uid();
  principal_id uuid;
  secret_id uuid;
  secret_name text;
begin
  select auth_user_id into principal_id from private.application_principal where singleton;
  if owner_id is null or owner_id is distinct from principal_id then
    raise exception 'price provider configuration unavailable' using errcode = '42501';
  end if;
  if requested_slot not between 1 and 10 then
    raise exception 'invalid price provider slot' using errcode = '22023';
  end if;
  secret_name := 'monpatrimoine.price-provider.' || owner_id::text || '.' || requested_slot::text;
  select s.id into secret_id from vault.secrets s where s.name = secret_name;
  if secret_id is not null then
    delete from vault.secrets where id = secret_id;
  end if;
  delete from public.price_provider_configurations
  where owner_user_id = owner_id and slot = requested_slot;
end;
$$;

create function public.get_price_provider_runtime_configurations()
returns table(
  slot smallint,
  provider text,
  priority smallint,
  region text,
  capability text,
  api_key text
)
language sql
stable
security definer
set search_path = ''
as $$
  select c.slot, c.provider, c.priority, c.region, c.capability, d.decrypted_secret
  from public.price_provider_configurations c
  join private.application_principal p
    on p.singleton and p.auth_user_id = c.owner_user_id
  join vault.decrypted_secrets d
    on d.name = 'monpatrimoine.price-provider.' || c.owner_user_id::text || '.' || c.slot::text
  where c.active and c.status = 'configured'
  order by c.priority;
$$;

create function public.mark_price_provider_configuration_invalid(requested_slot smallint)
returns void
language sql
volatile
security definer
set search_path = ''
as $$
  update public.price_provider_configurations c
  set status = 'invalid', active = false, updated_at = clock_timestamp()
  from private.application_principal p
  where p.singleton
    and c.owner_user_id = p.auth_user_id
    and c.slot = requested_slot;
$$;

revoke all on function public.get_price_provider_configurations() from public, anon;
revoke all on function public.save_price_provider_configuration(smallint, text, boolean, smallint, text, text, text) from public, anon;
revoke all on function public.delete_price_provider_configuration(smallint) from public, anon;
revoke all on function public.get_price_provider_runtime_configurations() from public, anon, authenticated;
revoke all on function public.mark_price_provider_configuration_invalid(smallint) from public, anon, authenticated;
grant execute on function public.get_price_provider_configurations() to authenticated;
grant execute on function public.save_price_provider_configuration(smallint, text, boolean, smallint, text, text, text) to authenticated;
grant execute on function public.delete_price_provider_configuration(smallint) to authenticated;
grant execute on function public.get_price_provider_runtime_configurations() to service_role;
grant execute on function public.mark_price_provider_configuration_invalid(smallint) to service_role;

create table private.price_provider_usage_windows (
  owner_user_id uuid not null,
  provider_slot smallint not null,
  bucket_kind text not null check (bucket_kind in ('minute', 'day')),
  bucket_start timestamptz not null,
  used_count integer not null default 0 check (used_count >= 0),
  updated_at timestamptz not null default timezone('utc', now()),
  primary key (owner_user_id, provider_slot, bucket_kind, bucket_start),
  foreign key (owner_user_id, provider_slot)
    references public.price_provider_configurations(owner_user_id, slot)
    on delete cascade on update cascade
);

revoke all on private.price_provider_usage_windows from public, anon, authenticated;

create function public.consume_price_provider_quota(
  requested_slot smallint,
  requested_cost integer default 1,
  requested_reserve integer default 0
)
returns table(allowed boolean, retry_after timestamptz)
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  principal_id uuid;
  provider_code text;
  minute_start timestamptz := date_trunc('minute', clock_timestamp());
  day_start timestamptz := date_trunc('day', clock_timestamp());
  minute_used integer := 0;
  day_used integer := 0;
  day_limit integer;
begin
  select auth_user_id into principal_id from private.application_principal where singleton;
  select provider into provider_code
  from public.price_provider_configurations
  where owner_user_id = principal_id and slot = requested_slot and active and status = 'configured';
  if provider_code is null or requested_cost < 1 or requested_cost > 100 or requested_reserve < 0 then
    return query select false, clock_timestamp() + interval '1 hour';
    return;
  end if;

  perform pg_advisory_xact_lock(hashtextextended(principal_id::text || ':' || requested_slot::text, 0));
  insert into private.price_provider_usage_windows values
    (principal_id, requested_slot, 'day', day_start, 0, clock_timestamp())
  on conflict do nothing;
  select used_count into day_used from private.price_provider_usage_windows
  where owner_user_id = principal_id and provider_slot = requested_slot
    and bucket_kind = 'day' and bucket_start = day_start for update;
  day_limit := case provider_code when 'twelve_data' then 800 else 20 end;
  if day_used + requested_cost > greatest(0, day_limit - requested_reserve) then
    return query select false, day_start + interval '1 day';
    return;
  end if;

  if provider_code = 'twelve_data' then
    insert into private.price_provider_usage_windows values
      (principal_id, requested_slot, 'minute', minute_start, 0, clock_timestamp())
    on conflict do nothing;
    select used_count into minute_used from private.price_provider_usage_windows
    where owner_user_id = principal_id and provider_slot = requested_slot
      and bucket_kind = 'minute' and bucket_start = minute_start for update;
    if minute_used + requested_cost > 8 then
      return query select false, minute_start + interval '1 minute';
      return;
    end if;
    update private.price_provider_usage_windows
    set used_count = used_count + requested_cost, updated_at = clock_timestamp()
    where owner_user_id = principal_id and provider_slot = requested_slot
      and bucket_kind = 'minute' and bucket_start = minute_start;
  end if;

  update private.price_provider_usage_windows
  set used_count = used_count + requested_cost, updated_at = clock_timestamp()
  where owner_user_id = principal_id and provider_slot = requested_slot
    and bucket_kind = 'day' and bucket_start = day_start;
  return query select true, null::timestamptz;
end;
$$;

revoke all on function public.consume_price_provider_quota(smallint, integer, integer) from public, anon, authenticated;
grant execute on function public.consume_price_provider_quota(smallint, integer, integer) to service_role;

create function public.apply_ai_asset_exposure_proposal(
  aid uuid,
  proposal jsonb,
  replace_existing boolean default false
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if proposal is null or jsonb_typeof(proposal) <> 'object'
    or jsonb_typeof(proposal -> 'sector') is distinct from 'array'
    or jsonb_typeof(proposal -> 'activity') is distinct from 'array'
    or jsonb_typeof(proposal -> 'geography') is distinct from 'array'
    or jsonb_array_length(proposal -> 'sector') = 0
    or jsonb_array_length(proposal -> 'activity') = 0
    or jsonb_array_length(proposal -> 'geography') = 0 then
    raise exception 'Invalid AI exposure proposal' using errcode = '22023';
  end if;

  -- The existing write guard serializes this check with every draft mutation.
  perform private.exposure_write_scope(aid, 'sector');
  if not replace_existing and exists (
    select 1 from public.asset_exposure_rows
    where asset_id = aid and stage = 'draft'
  ) then
    raise exception 'Existing exposure draft requires explicit replacement'
      using errcode = '23514';
  end if;

  perform public.save_asset_exposure_draft(aid, 'sector', proposal -> 'sector', null, 'Proposition IA', 'ai');
  perform public.save_asset_exposure_draft(aid, 'activity', proposal -> 'activity', null, 'Proposition IA', 'ai');
  perform public.save_asset_exposure_draft(aid, 'geography', proposal -> 'geography', null, 'Proposition IA', 'ai');
end;
$$;

revoke all on function public.apply_ai_asset_exposure_proposal(uuid, jsonb, boolean) from public, anon;
grant execute on function public.apply_ai_asset_exposure_proposal(uuid, jsonb, boolean) to authenticated;
comment on function public.apply_ai_asset_exposure_proposal(uuid, jsonb, boolean) is
  'Atomically replaces draft rows only; effective exposures are never published by this function.';

create table public.asset_price_refresh_status (
  asset_id uuid primary key references public.assets(id) on delete cascade on update cascade,
  status text not null check (status in ('success', 'error')),
  last_attempted_at timestamptz not null,
  last_succeeded_at timestamptz,
  error_code text check (error_code is null or error_code ~ '^[a-z0-9_-]{1,80}$'),
  source_name text check (source_name is null or char_length(btrim(source_name)) between 1 and 200),
  updated_at timestamptz not null default timezone('utc', now())
);

alter table public.asset_price_refresh_status enable row level security;
revoke all on public.asset_price_refresh_status from public, anon, authenticated;
grant select on public.asset_price_refresh_status to authenticated;
create policy principal_refresh_status_read
on public.asset_price_refresh_status for select to authenticated
using (
  public.is_authorized_user()
  and exists (
    select 1 from public.assets a
    where a.id = asset_id and a.owner_user_id = auth.uid()
  )
);

create function private.automatic_price_asset(requested_asset uuid)
returns table(currency_code char(3))
language plpgsql
security definer
set search_path = ''
as $$
declare
  principal uuid;
begin
  select auth_user_id into principal from private.application_principal where singleton;
  return query
  select a.currency_code
  from public.assets a
  where a.id = requested_asset
    and a.owner_user_id = principal
    and a.is_active
    and a.valuation_mode = 'market_price'
  for update;
  if not found then
    raise exception 'Asset is not available for automatic pricing' using errcode = '42501';
  end if;
end;
$$;

revoke all on function private.automatic_price_asset(uuid) from public, anon, authenticated;

create function public.record_automatic_asset_price(
  requested_asset uuid,
  requested_price numeric,
  requested_currency text,
  requested_observed_at timestamptz,
  requested_source text
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  asset_currency char(3);
  saved_id uuid;
begin
  select currency_code into asset_currency from private.automatic_price_asset(requested_asset);
  if requested_price is null or requested_price <= 0 then
    raise exception 'Automatic price must be strictly positive' using errcode = '23514';
  end if;
  if requested_currency is null or requested_currency !~ '^[A-Z]{3}$'
    or requested_currency is distinct from asset_currency::text then
    raise exception 'Automatic price must use the asset currency' using errcode = '23514';
  end if;
  if requested_observed_at is null or requested_observed_at > clock_timestamp() + interval '5 minutes' then
    raise exception 'Automatic price observation time is invalid' using errcode = '23514';
  end if;
  if requested_source is null or char_length(btrim(requested_source)) not between 1 and 200 then
    raise exception 'Automatic price source is invalid' using errcode = '23514';
  end if;

  insert into public.asset_prices (
    asset_id, user_id, origin, price, currency_code, observed_at, obtained_at, source_name
  ) values (
    requested_asset, null, 'automatic', requested_price, asset_currency,
    requested_observed_at, clock_timestamp(), btrim(requested_source)
  ) returning id into saved_id;

  insert into public.asset_price_refresh_status (
    asset_id, status, last_attempted_at, last_succeeded_at, error_code, source_name
  ) values (
    requested_asset, 'success', clock_timestamp(), clock_timestamp(), null, btrim(requested_source)
  ) on conflict (asset_id) do update set
    status = 'success',
    last_attempted_at = excluded.last_attempted_at,
    last_succeeded_at = excluded.last_succeeded_at,
    error_code = null,
    source_name = excluded.source_name,
    updated_at = clock_timestamp();
  return saved_id;
end;
$$;

create function public.record_automatic_asset_price_failure(
  requested_asset uuid,
  requested_error_code text,
  requested_source text
)
returns void
language plpgsql
security definer
set search_path = ''
as $$
declare
  ignored char(3);
begin
  select currency_code into ignored from private.automatic_price_asset(requested_asset);
  if requested_error_code is null or requested_error_code !~ '^[a-z0-9_-]{1,80}$' then
    raise exception 'Automatic price error code is invalid' using errcode = '23514';
  end if;
  if requested_source is null or char_length(btrim(requested_source)) not between 1 and 200 then
    raise exception 'Automatic price source is invalid' using errcode = '23514';
  end if;
  insert into public.asset_price_refresh_status (
    asset_id, status, last_attempted_at, last_succeeded_at, error_code, source_name
  ) values (
    requested_asset, 'error', clock_timestamp(), null, requested_error_code, btrim(requested_source)
  ) on conflict (asset_id) do update set
    status = 'error',
    last_attempted_at = excluded.last_attempted_at,
    error_code = excluded.error_code,
    source_name = excluded.source_name,
    updated_at = clock_timestamp();
end;
$$;

revoke all on function public.record_automatic_asset_price(uuid, numeric, text, timestamptz, text) from public, anon, authenticated;
revoke all on function public.record_automatic_asset_price_failure(uuid, text, text) from public, anon, authenticated;
grant execute on function public.record_automatic_asset_price(uuid, numeric, text, timestamptz, text) to service_role;
grant execute on function public.record_automatic_asset_price_failure(uuid, text, text) to service_role;

comment on table public.asset_price_refresh_status is
  'Sanitized latest automatic price refresh outcome; price history remains in asset_prices.';
comment on function public.record_automatic_asset_price(uuid, numeric, text, timestamptz, text) is
  'Service-only automatic price insert for an active market-price asset.';

commit;
