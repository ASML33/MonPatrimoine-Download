-- Phase 7.3A. Local validation required before any remote application.
begin;

-- Keep the class code extensible. Cash is modelled by cash_balances.
alter table public.assets add constraint assets_not_cash check (asset_type_code <> 'cash');

-- Durable evidence of patrimonial use, not a holdings/history cache.
-- Quotes and analytical classification alone do not constitute ownership.
create table private.asset_usage (
  asset_id uuid not null references public.assets(id) on delete restrict,
  user_id uuid not null references public.profiles(auth_user_id) on delete restrict,
  primary key(asset_id,user_id)
);
alter table private.asset_usage enable row level security;
revoke all on private.asset_usage from public, anon, authenticated;
insert into private.asset_usage
  select asset_id,user_id from public.positions
  union select target_asset_id,user_id from public.target_allocations where target_asset_id is not null
  union select asset_id,user_id from public.asset_prices where origin='manual';

create function public.has_used_asset(requested_asset uuid)
returns boolean language sql stable security definer set search_path='' as $$
  select public.is_authorized_user() and exists(select 1 from private.asset_usage
    where asset_id=requested_asset and user_id=auth.uid());
$$;
revoke all on function public.has_used_asset(uuid) from public,anon;
grant execute on function public.has_used_asset(uuid) to authenticated;

create function public.guard_asset_lifecycle()
returns trigger language plpgsql security definer set search_path='' as $$
begin
  if tg_op='UPDATE' then
    if new.id is distinct from old.id or new.owner_user_id is distinct from old.owner_user_id then
      raise exception 'Asset identity and ownership are immutable' using errcode='23514';
    end if;
    if (new.isin,new.asset_type_code,new.currency_code) is not distinct from
       (old.isin,old.asset_type_code,old.currency_code) then return new; end if;
  end if;
  if exists(select 1 from private.asset_usage where asset_id=old.id) then
    raise exception 'Used asset must retain its structural identity and existence' using errcode='23514';
  end if;
  if tg_op='DELETE' then return old; end if;
  return new;
end;
$$;
create trigger assets_00_lifecycle before update or delete on public.assets
for each row execute function public.guard_asset_lifecycle();

create function public.record_asset_use()
returns trigger language plpgsql security definer set search_path='' as $$
declare aid uuid; active boolean; owner_id uuid; previous jsonb;
begin
  aid := (to_jsonb(new)->>tg_argv[0])::uuid;
  if aid is null then return new; end if;
  if tg_table_name='asset_prices' and new.user_id is null then return new; end if;
  if tg_op='UPDATE' then
    previous := to_jsonb(old);
    if previous->>tg_argv[0] = aid::text and old.user_id=new.user_id
       and not (tg_table_name='positions' and previous->>'is_active'='false'
         and to_jsonb(new)->>'is_active'='true') then return new; end if;
  end if;
  -- A real parent write serializes deactivation/structural edits and new use;
  -- stale repeatable-read writers fail with 40001.
  update public.assets set updated_at=clock_timestamp() where id=aid
    returning is_active,owner_user_id into active,owner_id;
  if not found or (owner_id is distinct from new.user_id) then
    raise exception 'Asset unavailable' using errcode='42501';
  end if;
  if tg_table_name='positions' and not active then
    raise exception 'Inactive asset cannot receive a new position' using errcode='23514';
  end if;
  insert into private.asset_usage values(aid,new.user_id) on conflict do nothing;
  return new;
end;
$$;
create trigger positions_01_asset_use before insert or update on public.positions
for each row execute function public.record_asset_use('asset_id');
create trigger allocations_01_asset_use before insert or update on public.target_allocations
for each row execute function public.record_asset_use('target_asset_id');
create trigger prices_01_asset_use before insert or update on public.asset_prices
for each row execute function public.record_asset_use('asset_id');
revoke all on function public.guard_asset_lifecycle(),public.record_asset_use() from public,anon,authenticated;

create function public.normalize_visual_color(value text)
returns text language plpgsql immutable security invoker set search_path='' as $$
begin
  if value is null then return null; end if;
  if length(value)<>7 or value !~ '^#[0-9a-fA-F]{6}$' then
    raise exception 'Color must be #RRGGBB' using errcode='23514';
  end if;
  return upper(value);
end;
$$;
revoke all on function public.normalize_visual_color(text) from public,anon;
grant execute on function public.normalize_visual_color(text) to authenticated;

alter table public.assets add column color text;
alter table public.envelope_definitions add column color text;
alter table public.envelopes add column color text;
alter table public.contracts add column color text;
-- NULL means no explicit color. Defaults are copied only at creation.
create function public.normalize_entity_color()
returns trigger language plpgsql security invoker set search_path='' as $$
begin new.color:=public.normalize_visual_color(new.color); return new; end;
$$;
do $$ declare tab text; begin
  foreach tab in array array['assets','envelope_definitions','envelopes','contracts'] loop
    execute format('alter table public.%I add constraint %I check (color is null or color ~ ''^#[0-9A-F]{6}$'')',tab,tab||'_color_check');
    execute format('create trigger normalize_color before insert or update of color on public.%I for each row execute function public.normalize_entity_color()',tab);
  end loop;
end $$;
revoke all on function public.normalize_entity_color() from public,anon,authenticated;

alter table public.envelope_definitions rename column color to default_color;
drop trigger normalize_color on public.envelope_definitions;
create function public.normalize_definition_color() returns trigger language plpgsql set search_path='' as $$
begin new.default_color:=public.normalize_visual_color(new.default_color); return new; end $$;
create trigger normalize_color before insert or update of default_color on public.envelope_definitions
for each row execute function public.normalize_definition_color();
grant update(default_color) on public.envelope_definitions to authenticated;
create function public.initialize_envelope_color() returns trigger language plpgsql set search_path='' as $$
begin
 if new.color is null and new.envelope_definition_id is not null then
  select default_color into new.color from public.envelope_definitions where id=new.envelope_definition_id;
 end if;
 return new;
end $$;
create trigger envelopes_initial_color before insert on public.envelopes for each row execute function public.initialize_envelope_color();
revoke all on function public.initialize_envelope_color(),public.normalize_definition_color() from public,anon,authenticated;
commit;
