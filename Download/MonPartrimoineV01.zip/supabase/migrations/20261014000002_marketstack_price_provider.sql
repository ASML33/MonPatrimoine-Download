-- Recognize Marketstack Free as an EOD-only provider and enforce its monthly quota.
begin;

alter table public.price_provider_configurations
  drop constraint price_provider_adapter_valid,
  drop constraint eodhd_free_eod_only;

alter table public.price_provider_configurations
  add constraint price_provider_adapter_valid
    check (provider is null or provider in ('twelve_data', 'eodhd', 'marketstack')),
  add constraint eodhd_free_eod_only
    check (provider not in ('eodhd', 'marketstack') or capability = 'eod');

alter table private.price_provider_usage_windows
  drop constraint price_provider_usage_windows_bucket_kind_check,
  add constraint price_provider_usage_windows_bucket_kind_check
    check (bucket_kind in ('minute', 'day', 'month'));

create or replace function public.save_price_provider_configuration(
  requested_slot smallint,
  requested_provider_name text,
  requested_active boolean,
  requested_priority smallint,
  requested_region text,
  requested_capability text,
  api_key text default null
)
returns void
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  owner_id uuid := auth.uid();
  principal_id uuid;
  normalized_name text;
  requested_adapter text;
  current_adapter text;
  current_priority smallint;
  competing_slot smallint;
  replacement_priority smallint;
  secret_id uuid;
  secret_name text;
begin
  select auth_user_id into principal_id from private.application_principal where singleton;
  if owner_id is null or owner_id is distinct from principal_id
    or not exists (select 1 from public.profiles where auth_user_id = owner_id and is_active) then
    raise exception 'price provider configuration unavailable' using errcode = '42501';
  end if;

  requested_provider_name := btrim(coalesce(requested_provider_name, ''));
  normalized_name := regexp_replace(lower(requested_provider_name), '[^a-z0-9]+', '', 'g');
  requested_adapter := case normalized_name
    when 'twelvedata' then 'twelve_data'
    when 'eodhd' then 'eodhd'
    when 'marketstack' then 'marketstack'
    else null
  end;

  if requested_slot not between 1 and 10 or requested_priority not between 1 and 10
    or char_length(requested_provider_name) not between 1 and 120
    or requested_region not in ('us', 'europe', 'global')
    or requested_capability not in ('eod', 'intraday', 'both')
    or (requested_adapter in ('eodhd', 'marketstack') and requested_capability <> 'eod') then
    raise exception 'invalid price provider configuration' using errcode = '22023';
  end if;
  if api_key is not null and (
    api_key = '' or api_key <> btrim(api_key) or char_length(api_key) > 4096
  ) then
    raise exception 'invalid API key' using errcode = '22023';
  end if;

  select c.provider, c.priority
    into current_adapter, current_priority
    from public.price_provider_configurations c
    where c.owner_user_id = owner_id and c.slot = requested_slot
    for update;

  secret_name := 'monpatrimoine.price-provider.' || owner_id::text || '.' || requested_slot::text;
  select s.id into secret_id from vault.secrets s where s.name = secret_name;
  if api_key is null and secret_id is null then
    raise exception 'an API key is required' using errcode = '22023';
  end if;
  if api_key is null and current_adapter is distinct from requested_adapter then
    raise exception 'a new key is required when changing provider' using errcode = '22023';
  end if;

  select c.slot into competing_slot
  from public.price_provider_configurations c
  where c.owner_user_id = owner_id
    and c.priority = requested_priority
    and c.slot <> requested_slot
  for update;
  if competing_slot is not null then
    if current_priority is not null then
      replacement_priority := current_priority;
    else
      select candidate::smallint into replacement_priority
      from generate_series(1, 10) candidate
      where candidate <> requested_priority
        and not exists (
          select 1 from public.price_provider_configurations c
          where c.owner_user_id = owner_id and c.priority = candidate
        )
      order by candidate
      limit 1;
    end if;
    if replacement_priority is null then
      raise exception 'no free price provider priority' using errcode = '23514';
    end if;
    update public.price_provider_configurations
      set priority = replacement_priority, updated_at = clock_timestamp()
      where owner_user_id = owner_id and slot = competing_slot;
  end if;

  if api_key is not null and secret_id is null then
    perform vault.create_secret(
      api_key,
      secret_name,
      'MonPatrimoine automatic price provider credential for slot ' || requested_slot::text
    );
  elsif api_key is not null then
    perform vault.update_secret(
      secret_id,
      api_key,
      secret_name,
      'MonPatrimoine automatic price provider credential for slot ' || requested_slot::text
    );
  end if;

  insert into public.price_provider_configurations (
    owner_user_id, slot, display_name, provider, active, priority,
    region, capability, status, last_tested_at
  ) values (
    owner_id, requested_slot, requested_provider_name, requested_adapter,
    requested_active, requested_priority, requested_region, requested_capability,
    case when requested_adapter is null then 'unsupported' else 'untested' end,
    null
  ) on conflict (owner_user_id, slot) do update set
    display_name = excluded.display_name,
    provider = excluded.provider,
    active = excluded.active,
    priority = excluded.priority,
    region = excluded.region,
    capability = excluded.capability,
    status = excluded.status,
    last_tested_at = null,
    updated_at = clock_timestamp();

  if current_adapter is distinct from requested_adapter then
    delete from public.asset_price_provider_capabilities
    where owner_user_id = owner_id and provider_slot = requested_slot;
  end if;
end;
$$;

-- The existing unsupported Marketstack slot keeps its Vault secret and ordering.
-- It becomes testable by the application after this migration is applied.
update public.price_provider_configurations
set provider = 'marketstack',
    capability = 'eod',
    status = 'untested',
    last_tested_at = null,
    updated_at = clock_timestamp()
where provider is null
  and regexp_replace(lower(display_name), '[^a-z0-9]+', '', 'g') = 'marketstack';

create or replace function public.consume_price_provider_quota(
  requested_slot smallint,
  requested_cost integer default 1,
  requested_reserve integer default 0
)
returns table(allowed boolean, retry_after timestamptz)
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  principal_id uuid;
  provider_code text;
  minute_start timestamptz := date_trunc('minute', clock_timestamp());
  day_start timestamptz := date_trunc('day', clock_timestamp());
  month_start timestamptz := date_trunc('month', clock_timestamp());
  minute_used integer := 0;
  day_used integer := 0;
  month_used integer := 0;
  day_limit integer;
begin
  select auth_user_id into principal_id from private.application_principal where singleton;
  select provider into provider_code
  from public.price_provider_configurations
  where owner_user_id = principal_id and slot = requested_slot and active and status = 'validated';
  if provider_code is null or requested_cost < 1 or requested_cost > 100 or requested_reserve < 0 then
    return query select false, clock_timestamp() + interval '1 hour';
    return;
  end if;

  perform pg_advisory_xact_lock(hashtextextended(principal_id::text || ':' || requested_slot::text, 0));

  if provider_code = 'marketstack' then
    insert into private.price_provider_usage_windows values
      (principal_id, requested_slot, 'month', month_start, 0, clock_timestamp())
    on conflict do nothing;
    select used_count into month_used from private.price_provider_usage_windows
    where owner_user_id = principal_id and provider_slot = requested_slot
      and bucket_kind = 'month' and bucket_start = month_start for update;
    if month_used + requested_cost > greatest(0, 100 - requested_reserve) then
      return query select false, month_start + interval '1 month';
      return;
    end if;
    update private.price_provider_usage_windows
    set used_count = used_count + requested_cost, updated_at = clock_timestamp()
    where owner_user_id = principal_id and provider_slot = requested_slot
      and bucket_kind = 'month' and bucket_start = month_start;
    return query select true, null::timestamptz;
    return;
  end if;

  insert into private.price_provider_usage_windows values
    (principal_id, requested_slot, 'day', day_start, 0, clock_timestamp())
  on conflict do nothing;
  select used_count into day_used from private.price_provider_usage_windows
  where owner_user_id = principal_id and provider_slot = requested_slot
    and bucket_kind = 'day' and bucket_start = day_start for update;
  day_limit := case provider_code when 'twelve_data' then 800 else 20 end;
  if day_used + requested_cost > greatest(0, day_limit - requested_reserve) then
    return query select false, day_start + interval '1 day';
    return;
  end if;

  if provider_code = 'twelve_data' then
    insert into private.price_provider_usage_windows values
      (principal_id, requested_slot, 'minute', minute_start, 0, clock_timestamp())
    on conflict do nothing;
    select used_count into minute_used from private.price_provider_usage_windows
    where owner_user_id = principal_id and provider_slot = requested_slot
      and bucket_kind = 'minute' and bucket_start = minute_start for update;
    if minute_used + requested_cost > 8 then
      return query select false, minute_start + interval '1 minute';
      return;
    end if;
    update private.price_provider_usage_windows
    set used_count = used_count + requested_cost, updated_at = clock_timestamp()
    where owner_user_id = principal_id and provider_slot = requested_slot
      and bucket_kind = 'minute' and bucket_start = minute_start;
  end if;

  update private.price_provider_usage_windows
  set used_count = used_count + requested_cost, updated_at = clock_timestamp()
  where owner_user_id = principal_id and provider_slot = requested_slot
    and bucket_kind = 'day' and bucket_start = day_start;
  return query select true, null::timestamptz;
end;
$$;

revoke all on function public.save_price_provider_configuration(smallint, text, boolean, smallint, text, text, text) from public, anon;
revoke all on function public.consume_price_provider_quota(smallint, integer, integer) from public, anon, authenticated;
grant execute on function public.save_price_provider_configuration(smallint, text, boolean, smallint, text, text, text) to authenticated;
grant execute on function public.consume_price_provider_quota(smallint, integer, integer) to service_role;

comment on constraint price_provider_adapter_valid on public.price_provider_configurations is
  'Supported runtime adapters. A null provider remains an explicitly unsupported display-only configuration.';
comment on function public.consume_price_provider_quota(smallint, integer, integer) is
  'Atomically enforces provider limits: Twelve Data minute/day, EODHD day, Marketstack Free month.';

commit;
