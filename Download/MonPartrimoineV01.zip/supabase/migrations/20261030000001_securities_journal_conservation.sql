-- LOCAL CANDIDATE ONLY. No provider, credential, activation or timeout change.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
do $$declare x record;begin
 if private.app_backup_schema()<>'405698ddd199f9344105378a5b5b5e27645fcf3076fc16a324bbf6ea87fd7a6f'then raise exception'Unexpected journal conservation predecessor';end if;
 for x in select * from(values
 ('private.app_backup_snapshot()','a4c025cd01f09333f7d3b3565d6e9be9'),
 ('private.app_backup_validate(jsonb)','d6854f71b9d51d2c2e36612876c5c387'),
 ('private.app_backup_replace(jsonb,text)','acb26410ab98b734aab0427161edd8ff'),
 ('private.app_backup_upgrade(jsonb)','30c63377fd2a377dca05b209697e5cf7'),
 ('private.adopt_securities_cash(uuid)','b404496cefc6c9a01fc4bd606a646dd4'),
 ('private.securities_cash_fingerprint(public.cash_balances)','7ad1d2be6db534731d5c8507da6a83b5'),
 ('public.mutate_securities_cash_action(uuid,uuid,text,text,uuid,jsonb,timestamptz,jsonb)','d668b96e96f2262fbd985614318d910d'),
 ('public.save_securities_position_action(uuid,uuid,uuid,uuid,date,numeric,numeric,text,timestamptz,uuid)','c9c1d82a1bfd7e5e49c4e02f87d79a4f'))v(signature,hash)loop
  if md5(pg_get_functiondef(x.signature::regprocedure))is distinct from x.hash then raise exception'Journal conservation source drift: %',x.signature;end if;
 end loop;
end$$;
insert into private.app_backup_datasets(name,relation,predicate,ordinal,shared)values
 ('securities_cash_basis','private.securities_cash_basis','user_id=auth.uid()',80,false),
 ('securities_cash_actions','private.securities_cash_actions','user_id=auth.uid()',81,false),
 ('securities_action_requests','private.securities_action_requests','user_id=auth.uid()',82,false);

-- Full text cells, including versions/receipts: never reconstruct from daily cash.
create function private.securities_journal_document()returns jsonb language plpgsql stable security definer set search_path=''set timezone='UTC'set datestyle='ISO,YMD'as $$
declare d record;r jsonb;data jsonb:='{}';begin
 if public.is_authorized_user()is not true then raise exception'Unauthorized'using errcode='42501';end if;
 for d in select * from private.app_backup_datasets where name in('securities_cash_basis','securities_cash_actions','securities_action_requests')order by ordinal loop
  execute format('select coalesce(jsonb_agg(cells order by cells::text collate "C"),''[]'')from(select jsonb_build_array(%s)cells from %s r where %s)q',(select string_agg(format('r.%I::text',c),',')from unnest(d.columns)c),d.relation,d.predicate)into r;
  data:=data||jsonb_build_object(d.name,jsonb_build_object('columns',d.columns,'rows',r));
 end loop;return data;
end$$;
-- A derived archive checksum, not a second persistent business journal. It is
-- exported/validated but never restored as a shared reference or writable row.
create view private.securities_journal_integrity as select auth.uid()as user_id,encode(extensions.digest(private.securities_journal_document()::text,'sha256'),'hex')as content_sha256;
revoke all on private.securities_journal_integrity from public,anon,authenticated,service_role;
insert into private.app_backup_datasets(name,relation,predicate,ordinal,shared)values('securities_journal_integrity','private.securities_journal_integrity','true',83,true);
update private.app_backup_datasets d set columns=(select array_agg(attname::text order by attnum)from pg_attribute where attrelid=d.relation and attnum>0 and not attisdropped),primary_columns=case when d.name='securities_journal_integrity'then array['user_id']else(select array_agg(a.attname::text order by k.ord)from pg_index i cross join lateral unnest(i.indkey)with ordinality k(num,ord)join pg_attribute a on a.attrelid=i.indrelid and a.attnum=k.num where i.indrelid=d.relation and i.indisprimary)end where name in('securities_cash_basis','securities_cash_actions','securities_action_requests','securities_journal_integrity');

-- Normalize future fingerprints, accept exact previous UTC/Paris serialization
-- of the SAME full row during transition. No data or stored seal is rewritten.
create function private.securities_cash_fingerprint_legacy_paris(b public.cash_balances)returns text language sql immutable set search_path=''set timezone='Europe/Paris'as $$select md5(jsonb_build_array(b.amount,b.currency_code,b.as_of,b.metadata->'cash_balance_observations',b.metadata->'securities_cash_actions',b.metadata->'flow_cash_links',b.metadata->'cash_balance_corrections')::text)$$;
alter function private.securities_cash_fingerprint(public.cash_balances)set timezone='UTC';
create function private.securities_cash_fingerprint_matches(b public.cash_balances,expected text)returns boolean language sql stable set search_path=''as $$select coalesce(expected=private.securities_cash_fingerprint(b)or expected=private.securities_cash_fingerprint_legacy_paris(b),false)$$;
do $fingerprint$declare s text;needle text:='j.source_fingerprint=private.securities_cash_fingerprint(b)';begin
 s:=pg_get_functiondef('private.adopt_securities_cash(uuid)'::regprocedure);if strpos(s,needle)=0 then raise exception'Unexpected fingerprint source';end if;
 execute replace(s,needle,'private.securities_cash_fingerprint_matches(b,j.source_fingerprint)');
end$fingerprint$;
create function private.assert_securities_journal()returns void language plpgsql stable security definer set search_path=''set timezone='UTC'as $$
declare b public.cash_balances;j private.securities_cash_basis;expected jsonb;e jsonb;v numeric;begin
 if public.is_authorized_user()is not true then raise exception'Unauthorized'using errcode='42501';end if;
 if exists(select 1 from private.securities_cash_basis x left join public.cash_balances cb on cb.id=x.balance_id left join public.contracts c on c.id=x.contract_id where x.user_id=auth.uid()and(cb.id is null or c.id is null or cb.user_id<>x.user_id or c.user_id<>x.user_id or cb.contract_id<>x.contract_id))or exists(select 1 from private.securities_cash_actions a left join private.securities_cash_basis x on x.balance_id=a.balance_id where a.user_id=auth.uid()and(x.balance_id is null or x.user_id<>a.user_id or x.contract_id<>a.contract_id or a.action_order<=0 or jsonb_typeof(a.versions)is distinct from'array'))then raise exception'SECURITIES-JOURNAL-RELATION';end if;
 if exists(select action_order from private.securities_cash_actions where user_id=auth.uid()group by action_order having count(*)>1)then raise exception'SECURITIES-JOURNAL-ORDER';end if;
 for b in select * from public.cash_balances where user_id=auth.uid()loop
  select * into j from private.securities_cash_basis where balance_id=b.id and user_id=auth.uid();
  if b.metadata?'securities_cash_actions'and j.balance_id is null then raise exception'SECURITIES-JOURNAL-MISSING';end if;
  if j.balance_id is null then continue;end if;
  if j.initial_action is not null and not exists(select 1 from private.securities_cash_actions a where a.id=j.initial_action and a.balance_id=b.id and a.user_id=auth.uid())then raise exception'SECURITIES-JOURNAL-INITIAL';end if;
  if not private.securities_cash_fingerprint_matches(b,j.source_fingerprint)then raise exception'SECURITIES-JOURNAL-MISMATCH';end if;
  select coalesce(jsonb_agg(jsonb_build_object('id',a.id,'kind',a.kind,'date',a.effective_on,'amount',a.entered_amount::text,'delta',a.delta::text,'order',a.action_order,'revision',a.recorded_at,'legacyMode',a.legacy_mode)order by a.action_order desc),'[]')into expected from private.securities_cash_actions a where a.balance_id=b.id and a.user_id=auth.uid()and a.active;
  if expected is distinct from(select coalesce(jsonb_agg(z.value||jsonb_build_object('revision',(z.value->>'revision')::timestamptz)),'[]')from jsonb_array_elements(b.metadata#>'{securities_cash_actions,entries}')z)then raise exception'SECURITIES-JOURNAL-ACTIONS';end if;
  for e in select * from jsonb_array_elements(b.metadata#>'{cash_balance_observations,entries}')loop
   v:=private.securities_cash_value(b.id,((e->>'asOf')::timestamptz at time zone'Europe/Paris')::date);
   if v is null or v is distinct from(e->>'amount')::numeric then raise exception'SECURITIES-JOURNAL-MATERIALIZATION';end if;
  end loop;
 end loop;
 if exists(select 1 from private.securities_cash_actions a left join public.cash_flows f on f.id=a.id left join public.cash_balances cb on cb.id=a.balance_id where a.user_id=auth.uid()and a.kind='flow'and a.active and(f.id is null or f.user_id<>a.user_id or coalesce(f.destination_contract_id,f.source_contract_id)<>a.contract_id or f.currency_code<>cb.currency_code or f.amount<>a.entered_amount or(f.occurred_at at time zone'Europe/Paris')::date<>a.effective_on or a.delta<>case when a.legacy_mode='included'then 0 when f.kind='contribution'then f.amount else -f.amount end))then raise exception'SECURITIES-JOURNAL-FLOW';end if;
 if exists(select 1 from private.securities_action_requests r left join public.contracts c on c.id=r.contract_id where r.user_id=auth.uid()and(c.id is null or c.user_id<>r.user_id or (case when r.payload->>0='position'then r.payload->>1 else r.payload->>0 end)<>r.contract_id::text or not(exists(select 1 from private.securities_cash_actions a where a.id=r.result and a.user_id=r.user_id and a.contract_id=r.contract_id)or exists(select 1 from public.positions p where p.id=r.result and p.user_id=r.user_id and p.contract_id=r.contract_id))))then raise exception'SECURITIES-JOURNAL-RECEIPT';end if;
 if exists(select 1 from public.positions p cross join lateral jsonb_each(coalesce(p.metadata->'securities_action_requests','{}'))r where p.user_id=auth.uid()and not exists(select 1 from private.securities_action_requests a where a.user_id=p.user_id and a.request_id=r.key::uuid and a.result=p.id and a.payload=r.value))then raise exception'SECURITIES-JOURNAL-RECEIPT-MISSING';end if;
end$$;

create function private.validate_securities_journal_document(doc jsonb)returns void language plpgsql stable security definer set search_path=''as $$
declare data jsonb;expected jsonb;begin
 select jsonb_object_agg(k,v)into data from jsonb_each(doc->'datasets')t(k,v)where k in('securities_cash_basis','securities_cash_actions','securities_action_requests');
 expected:=jsonb_build_array(jsonb_build_array(auth.uid()::text,encode(extensions.digest(data::text,'sha256'),'hex')));
 if doc#>'{datasets,securities_journal_integrity,rows}'is distinct from expected then raise exception'SECURITIES-JOURNAL-DIGEST';end if;
end$$;

-- The sequence is infrastructure, not a per-user datum to roll backwards.
-- Imported action_order values remain exact; the next native allocation is
-- strictly above ALL users' restored values. Restore supplies explicit columns
-- and never calls this allocator, including during the rollback-only preview.
create function private.next_securities_action_order()returns bigint language plpgsql volatile security definer set search_path=''as $$
declare n bigint;m bigint;begin
 perform pg_advisory_xact_lock(hashtextextended('securities-action-order',0));
 n:=nextval('private.securities_action_order');select max(action_order)into m from private.securities_cash_actions;
 if n<=m then perform setval('private.securities_action_order',m,true);n:=nextval('private.securities_action_order');end if;return n;
end$$;
alter table private.securities_cash_actions alter column action_order set default private.next_securities_action_order();
do $patch$declare s text;needle text;begin
 s:=pg_get_functiondef('public.mutate_securities_cash_action(uuid,uuid,text,text,uuid,jsonb,timestamptz,jsonb)'::regprocedure);
 needle:='action_order=nextval(''private.securities_action_order'')';if strpos(s,needle)=0 then raise exception'Unexpected allocation source';end if;
 execute replace(s,needle,'action_order=private.next_securities_action_order()');
 s:=pg_get_functiondef('public.save_securities_position_action(uuid,uuid,uuid,uuid,date,numeric,numeric,text,timestamptz,uuid)'::regprocedure);
 needle:='select 1 from public.positions p where p.id=receipt.result and p.user_id=auth.uid()and p.metadata';
 if strpos(s,needle)=0 then raise exception'Unexpected holding receipt source';end if;
 execute replace(s,needle,'select 1 from public.positions replay_position where replay_position.id=receipt.result and replay_position.user_id=auth.uid()and replay_position.metadata');
 s:=pg_get_functiondef('private.app_backup_snapshot()'::regprocedure);
 needle:='if public.is_authorized_user() is not true then';if strpos(s,needle)=0 then raise exception'Unexpected snapshot source';end if;
 execute replace(s,needle,'perform private.assert_securities_journal(); '||needle);
 s:=pg_get_functiondef('private.app_backup_validate(jsonb)'::regprocedure);
 needle:=E'end$function$';if strpos(s,needle)=0 then raise exception'Unexpected validator source';end if;
 execute replace(s,needle,E'perform private.validate_securities_journal_document(doc);\nend$function$');
 s:=pg_get_functiondef('private.app_backup_replace(jsonb,text)'::regprocedure);
 needle:='where shared loop';if strpos(s,needle)=0 then raise exception'Unexpected shared-reference source';end if;
 s:=replace(s,needle,'where shared and name<>''securities_journal_integrity'' loop');
 needle:='from private.app_backup_datasets order by name loop';if strpos(s,needle)=0 then raise exception'Unexpected restore locks source';end if;
 execute replace(s,needle,'from private.app_backup_datasets where name<>''securities_journal_integrity'' order by name loop');
end$patch$;

alter function private.app_backup_upgrade(jsonb)rename to app_backup_upgrade_before_securities;
create function private.app_backup_upgrade(doc jsonb)returns jsonb language plpgsql security definer set search_path=''as $$
declare d record;obj jsonb;row jsonb;data jsonb;begin
 if public.is_authorized_user()is not true or doc->>'owner'is distinct from auth.uid()::text then raise exception'Unauthorized'using errcode='42501';end if;
 if doc->>'schema'=private.app_backup_schema()then perform private.app_backup_validate(doc);return doc;end if;
 if doc->'datasets'?'securities_cash_basis'or doc->'datasets'?'securities_cash_actions'or doc->'datasets'?'securities_action_requests'or doc->'datasets'?'securities_journal_integrity'then raise exception'Unsupported partial journal archive';end if;
 -- An archive with modern materializations but no journal has lost business
 -- data. Never convert that loss into an apparently fresh empty ledger.
 for d in select * from private.app_backup_datasets where name in('cash_balances','positions','contracts')loop
  for row in select * from jsonb_array_elements(doc#>array['datasets',d.name,'rows'])loop
   select jsonb_object_agg(c,row->(i-1)::int)into obj from jsonb_array_elements_text(doc#>array['datasets',d.name,'columns'])with ordinality t(c,i);
   if(obj->>'metadata')::jsonb?'securities_cash_actions'or(obj->>'metadata')::jsonb?'securities_action_requests'then raise exception'SECURITIES-JOURNAL-MISSING-IN-ARCHIVE';end if;
  end loop;
 end loop;
 for d in select * from private.app_backup_datasets where name in('securities_cash_basis','securities_cash_actions','securities_action_requests')loop
  doc:=jsonb_set(doc,array['datasets',d.name],jsonb_build_object('columns',d.columns,'rows','[]'::jsonb));
 end loop;
 select jsonb_object_agg(k,v)into data from jsonb_each(doc->'datasets')t(k,v)where k in('securities_cash_basis','securities_cash_actions','securities_action_requests');
 doc:=jsonb_set(doc,'{datasets,securities_journal_integrity}',jsonb_build_object('columns',array['user_id','content_sha256'],'rows',jsonb_build_array(jsonb_build_array(auth.uid()::text,encode(extensions.digest(data::text,'sha256'),'hex')))));
 if doc->>'format'='monpatrimoine-app-backup/3'and doc->>'schema'in('8cf0fb641a93c05ee70ab159f60a5b50024a95ba1b2d1749bd1d4f56e5027fc8','405698ddd199f9344105378a5b5b5e27645fcf3076fc16a324bbf6ea87fd7a6f')then
  doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));perform private.app_backup_validate(doc);return doc;
 end if;
 -- Previous exact /1,/2,/3 frontiers remain delegated to the existing allowlist.
 return private.app_backup_upgrade_before_securities(doc);
end$$;
revoke all on function private.securities_journal_document(),private.assert_securities_journal(),private.validate_securities_journal_document(jsonb),private.next_securities_action_order(),private.app_backup_upgrade(jsonb),private.app_backup_upgrade_before_securities(jsonb),private.securities_cash_fingerprint_legacy_paris(public.cash_balances),private.securities_cash_fingerprint_matches(public.cash_balances,text)from public,anon,authenticated,service_role;
commit;
