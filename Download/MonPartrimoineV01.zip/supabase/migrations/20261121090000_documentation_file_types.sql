begin;

do $$
begin
  update storage.buckets
  set allowed_mime_types = array[
    'application/pdf',
    'text/plain',
    'text/markdown',
    'text/csv',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation'
  ]
  where id = 'monpatrimoine-documentation' and not public and file_size_limit = 4194304;

  if not found then
    raise exception 'Expected private Documentation bucket with a 4 MiB limit';
  end if;
end;
$$;

commit;
