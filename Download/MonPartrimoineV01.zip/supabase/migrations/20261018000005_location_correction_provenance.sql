-- Correction provenance is distinct from the archived initial confirmation.
begin;
create or replace function private.location_plan(p_kind text,p_target uuid,p_observation uuid,p_date date,p_country uuid)
returns jsonb language plpgsql security definer set search_path=pg_catalog,public,private as $$
declare target jsonb; h jsonb; previous jsonb; request jsonb; catalog_hash text; token text; proposed jsonb;
begin
 if public.is_authorized_user() is not true or auth.uid() is null then raise exception 'Unauthorized' using errcode='42501';end if;
 if p_observation is null then raise exception 'Observation identity required' using errcode='23514';end if;
 if p_kind='asset' then
  select to_jsonb(a) into target from public.assets a where a.id=p_target and a.owner_user_id=auth.uid() and a.asset_type_code='real_estate';
 elsif p_kind='contract' then
  select to_jsonb(c) into target from public.contracts c join public.envelope_types t on t.id=c.envelope_type_id
   where c.id=p_target and c.user_id=auth.uid() and t.code not in ('pea','cto','pea_pme','compte_titres','immobilier') and not(c.metadata ? 'property_replaced_by');
 else raise exception 'Invalid target' using errcode='23514';end if;
 if target is null then raise exception 'Unavailable target' using errcode='42501';end if;
 h=coalesce(target#>'{metadata,geographic_location}','{"version":1,"entries":[],"archived":[],"receipts":[]}'::jsonb);
 if h->>'version'<>'1' or jsonb_typeof(h->'entries')<>'array' or jsonb_typeof(h->'archived')<>'array' then raise exception 'Invalid history' using errcode='23514';end if;
 select e into previous from jsonb_array_elements(h->'entries') e where e->>'id'=p_observation::text;
 if p_date is null and (previous is null or previous->>'origin'<>'confirmed_history') then raise exception 'An effect date is required' using errcode='23514';end if;
 if p_date is not null and (p_date<'0001-01-01' or p_date>(now() at time zone 'Europe/Paris')::date) then raise exception 'Invalid date' using errcode='23514';end if;
 if exists(select 1 from jsonb_array_elements(h->'entries') e where (e->>'effectiveOn')::date is not distinct from p_date and e->>'id'<>p_observation::text) then raise exception 'Date already occupied; correct the identified entry' using errcode='23505';end if;
 if p_country is not null and not exists(select 1 from public.exposure_countries c join public.geographic_regions r on r.code=c.region_code where c.id=p_country and ((c.is_active and r.is_active) or previous->>'countryId'=p_country::text) and c.code<>'unspecified') then raise exception 'Invalid active country' using errcode='23514';end if;
 request=jsonb_build_object('kind',p_kind,'target',p_target,'observation',p_observation,'date',p_date,'country',p_country);
 select md5(coalesce(jsonb_agg(to_jsonb(c) order by c.id)::text,'')) into catalog_hash from public.exposure_countries c;
 select catalog_hash||md5(coalesce(jsonb_agg(to_jsonb(r) order by r.code)::text,'')) into catalog_hash from public.geographic_regions r;
 token=md5(target::text||request::text||catalog_hash);
 proposed=jsonb_build_object('id',p_observation,'version',coalesce((previous->>'version')::int,0)+1,'countryId',p_country,'effectiveOn',p_date,'origin',case when p_date is null then 'confirmed_history' else 'dated' end,
 'source',case when p_date is null then 'Correction explicite de la localisation historique ; confirmation initiale conservée dans la version précédente' else 'Localisation saisie explicitement par l’utilisateur' end,'recordedAt',now());
 return jsonb_build_object('token',token,'request',request,'previous',previous,'observation',proposed,'history',h,'targetMetadata',coalesce(target->'metadata','{}'));
end $$;
revoke all on function private.location_plan(text,uuid,uuid,date,uuid) from public,anon,authenticated;
commit;
