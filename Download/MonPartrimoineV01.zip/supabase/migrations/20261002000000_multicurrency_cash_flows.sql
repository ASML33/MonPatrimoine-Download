-- Phase 7.4: multi-currency cash balances, dated cash flows and dedicated FX rates.
begin;

create type public.fx_rate_source as enum ('ecb', 'frankfurter', 'manual');
create type public.fx_resolution_status as enum ('resolved', 'pending', 'manual_required');

create table public.currencies (
  code char(3) primary key check (code ~ '^[A-Z]{3}$'),
  is_active boolean not null default true,
  created_at timestamptz not null default timezone('utc', now())
);

insert into public.currencies(code) values
  ('AED'),('AFN'),('ALL'),('AMD'),('ANG'),('AOA'),('ARS'),('AUD'),('AWG'),('AZN'),
  ('BAM'),('BBD'),('BDT'),('BHD'),('BIF'),('BMD'),('BND'),('BOB'),('BRL'),('BSD'),
  ('BTN'),('BWP'),('BYN'),('BZD'),('CAD'),('CDF'),('CHF'),('CLP'),('CMD'),('CNH'),
  ('CNY'),('COP'),('CRC'),('CUP'),('CVE'),('CZK'),('DJF'),('DKK'),('DOP'),('DZD'),
  ('EGP'),('ERN'),('ETB'),('EUR'),('FJD'),('FKP'),('GBP'),('GEL'),('GGP'),('GHS'),
  ('GIP'),('GMD'),('GNF'),('GTQ'),('GYD'),('HKD'),('HNL'),('HTG'),('HUF'),('IDR'),
  ('ILS'),('IMP'),('INR'),('IQD'),('IRR'),('ISK'),('JEP'),('JMD'),('JOD'),('JPY'),
  ('KES'),('KGS'),('KHR'),('KMF'),('KPW'),('KRW'),('KWD'),('KYD'),('KZT'),('LAK'),
  ('LBP'),('LKR'),('LRD'),('LSL'),('LYD'),('MAD'),('MDL'),('MGA'),('MKD'),('MMK'),
  ('MNT'),('MOP'),('MRU'),('MUR'),('MVR'),('MWK'),('MXN'),('MYR'),('MZN'),('NAD'),
  ('NGN'),('NIO'),('NOK'),('NPR'),('NZD'),('OMR'),('PAB'),('PEN'),('PGK'),('PHP'),
  ('PKR'),('PLN'),('PYG'),('QAR'),('RON'),('RSD'),('RUB'),('RWF'),('SAR'),('SBD'),
  ('SCR'),('SDG'),('SEK'),('SGD'),('SHP'),('SLE'),('SOS'),('SRD'),('SSP'),('STN'),
  ('SVC'),('SYP'),('SZL'),('THB'),('TJS'),('TMT'),('TND'),('TOP'),('TRY'),('TTD'),
  ('TWD'),('TZS'),('UAH'),('UGX'),('USD'),('UYU'),('UZS'),('VES'),('VND'),('VUV'),
  ('WST'),('XAF'),('XCD'),('XCG'),('XOF'),('XPF'),('YER'),('ZAR'),('ZMW'),('ZWG');

alter table public.currencies enable row level security;
revoke all on public.currencies from public, anon, authenticated;
grant select on public.currencies to authenticated;
create policy principal_currency_read on public.currencies for select to authenticated
  using (public.is_authorized_user());

create table public.fx_rates (
  id uuid primary key default gen_random_uuid(),
  currency_code char(3) not null references public.currencies(code) on delete restrict on update cascade,
  requested_on date not null,
  observed_on date not null,
  eur_per_unit numeric(28, 12) not null check (eur_per_unit > 0),
  source public.fx_rate_source not null,
  provider_metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(provider_metadata) = 'object'),
  obtained_at timestamptz not null default timezone('utc', now()),
  created_at timestamptz not null default timezone('utc', now()),
  check (currency_code <> 'EUR'),
  check (observed_on <= requested_on)
);

create unique index fx_rates_automatic_request_idx
  on public.fx_rates(currency_code, requested_on, source)
  where source <> 'manual';
create index fx_rates_currency_request_idx
  on public.fx_rates(currency_code, requested_on desc, obtained_at desc);

alter table public.fx_rates enable row level security;
revoke all on public.fx_rates from public, anon, authenticated;
grant select on public.fx_rates to authenticated;
create policy principal_fx_rate_read on public.fx_rates for select to authenticated
  using (public.is_authorized_user());

create table public.fx_provider_attempts (
  currency_code char(3) not null references public.currencies(code) on delete cascade on update cascade,
  requested_on date not null,
  provider text not null check (provider in ('ecb', 'frankfurter')),
  status text not null check (status in ('unsupported', 'temporary_failure')),
  failure_count smallint not null default 1 check (failure_count between 1 and 100),
  retry_after timestamptz not null,
  updated_at timestamptz not null default timezone('utc', now()),
  primary key(currency_code, requested_on, provider)
);
alter table public.fx_provider_attempts enable row level security;
revoke all on public.fx_provider_attempts from public, anon, authenticated;
grant select, insert, update, delete on public.fx_provider_attempts to service_role;

create function public.guard_fx_rate_immutability()
returns trigger language plpgsql set search_path = '' as $$
begin
  raise exception 'FX rates are immutable' using errcode = '23514';
end;
$$;
create trigger fx_rates_immutable before update or delete on public.fx_rates
  for each row execute function public.guard_fx_rate_immutability();
revoke all on function public.guard_fx_rate_immutability() from public, anon, authenticated;

create function public.record_automatic_fx_rate(
  requested_currency text,
  requested_date date,
  requested_observed_on date,
  requested_eur_per_unit numeric,
  requested_source public.fx_rate_source,
  requested_metadata jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare result_id uuid; normalized_currency text := upper(btrim(requested_currency));
begin
  if requested_source not in ('ecb', 'frankfurter') or requested_eur_per_unit <= 0
     or requested_date > current_date or requested_observed_on > requested_date
     or coalesce(jsonb_typeof(requested_metadata), 'null') <> 'object'
     or not exists(select 1 from public.currencies c where c.code = normalized_currency and c.is_active) then
    raise exception 'Invalid automatic FX rate' using errcode = '22023';
  end if;
  insert into public.fx_rates(currency_code, requested_on, observed_on, eur_per_unit, source, provider_metadata)
    values(normalized_currency, requested_date, requested_observed_on, requested_eur_per_unit, requested_source, requested_metadata)
    on conflict do nothing
    returning id into result_id;
  if result_id is null then
    select r.id into result_id from public.fx_rates r
      where r.currency_code = normalized_currency and r.requested_on = requested_date and r.source = requested_source;
  end if;
  return result_id;
end;
$$;
revoke all on function public.record_automatic_fx_rate(text,date,date,numeric,public.fx_rate_source,jsonb) from public, anon, authenticated;
grant execute on function public.record_automatic_fx_rate(text,date,date,numeric,public.fx_rate_source,jsonb) to service_role;

create function public.save_manual_fx_rate(
  requested_currency text,
  requested_date date,
  requested_observed_on date,
  requested_eur_per_unit numeric,
  requested_metadata jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare result_id uuid; normalized_currency text := upper(btrim(requested_currency));
begin
  if not public.is_authorized_user() or requested_eur_per_unit <= 0
     or requested_date > current_date or requested_observed_on > requested_date
     or coalesce(jsonb_typeof(requested_metadata), 'null') <> 'object'
     or not exists(select 1 from public.currencies c where c.code = normalized_currency and c.is_active) then
    raise exception 'Invalid manual FX rate' using errcode = '22023';
  end if;
  if normalized_currency = 'EUR' then
    raise exception 'EUR does not require an FX rate' using errcode = '22023';
  end if;
  insert into public.fx_rates(currency_code, requested_on, observed_on, eur_per_unit, source, provider_metadata)
    values(normalized_currency, requested_date, requested_observed_on, requested_eur_per_unit, 'manual', requested_metadata)
    returning id into result_id;
  return result_id;
end;
$$;
revoke all on function public.save_manual_fx_rate(text,date,date,numeric,jsonb) from public, anon;
grant execute on function public.save_manual_fx_rate(text,date,date,numeric,jsonb) to authenticated;

alter table public.cash_balances
  add constraint cash_balances_currency_reference foreign key(currency_code)
    references public.currencies(code) on delete restrict on update cascade not valid;
alter table public.cash_balances validate constraint cash_balances_currency_reference;

alter table public.cash_flows
  add column fx_rate_id uuid references public.fx_rates(id) on delete restrict,
  add column fx_status public.fx_resolution_status not null default 'pending',
  add constraint cash_flows_currency_reference foreign key(currency_code)
    references public.currencies(code) on delete restrict on update cascade not valid;
alter table public.cash_flows validate constraint cash_flows_currency_reference;

update public.cash_flows set fx_status = case when currency_code = 'EUR'
  then 'resolved'::public.fx_resolution_status else 'pending'::public.fx_resolution_status end;

alter table public.cash_flows
  add constraint cash_flows_fx_state_check check (
    (currency_code = 'EUR' and fx_rate_id is null and fx_status = 'resolved') or
    (currency_code <> 'EUR' and fx_rate_id is not null and fx_status = 'resolved') or
    (currency_code <> 'EUR' and fx_rate_id is null and fx_status in ('pending', 'manual_required'))
  );
create index cash_flows_contract_occurred_idx
  on public.cash_flows(coalesce(destination_contract_id, source_contract_id), occurred_at desc);
create index cash_flows_fx_rate_idx on public.cash_flows(fx_rate_id) where fx_rate_id is not null;

create function public.guard_cash_balance_phase74()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'UPDATE' and (new.id is distinct from old.id or new.user_id is distinct from old.user_id
     or new.contract_id is distinct from old.contract_id or new.currency_code is distinct from old.currency_code) then
    raise exception 'Cash balance identity is immutable' using errcode = '23514';
  end if;
  if new.as_of > clock_timestamp() then
    raise exception 'Cash balance date cannot be in the future' using errcode = '23514';
  end if;
  if not exists(select 1 from public.currencies c where c.code = new.currency_code and c.is_active) then
    raise exception 'Unsupported currency' using errcode = '23514';
  end if;
  return new;
end;
$$;
create trigger cash_balances_10_phase74 before insert or update on public.cash_balances
  for each row execute function public.guard_cash_balance_phase74();
revoke all on function public.guard_cash_balance_phase74() from public, anon, authenticated;

create function public.guard_cash_flow_phase74()
returns trigger language plpgsql security definer set search_path = '' as $$
declare
  flow_date date := (new.occurred_at at time zone 'Europe/Paris')::date;
  contract_id uuid;
  previous_contract_id uuid;
  contract_opened date;
  contract_closed date;
  rate_currency text;
  rate_requested date;
  rate_observed date;
begin
  if tg_op = 'UPDATE' then
    if new.id is distinct from old.id or new.user_id is distinct from old.user_id then
      raise exception 'Cash flow identity is immutable' using errcode = '23514';
    end if;
    previous_contract_id := coalesce(old.destination_contract_id, old.source_contract_id);
    if coalesce(new.destination_contract_id, new.source_contract_id) is distinct from previous_contract_id then
      raise exception 'Cash flow contract is immutable' using errcode = '23514';
    end if;
    if old.fx_rate_id is not null and new.fx_rate_id is distinct from old.fx_rate_id
       and new.currency_code is not distinct from old.currency_code
       and new.occurred_at is not distinct from old.occurred_at then
      raise exception 'Assigned historical FX rate is immutable' using errcode = '23514';
    end if;
  end if;
  if new.occurred_at > clock_timestamp() then
    raise exception 'Cash flow date cannot be in the future' using errcode = '23514';
  end if;
  if not exists(select 1 from public.currencies c where c.code = new.currency_code and c.is_active) then
    raise exception 'Unsupported currency' using errcode = '23514';
  end if;
  for contract_id in select distinct id from unnest(array[new.destination_contract_id, new.source_contract_id]) id where id is not null loop
    select c.opened_on, c.closed_on into contract_opened, contract_closed
      from public.contracts c where c.id = contract_id and c.user_id = new.user_id;
    if not found then raise exception 'Contract unavailable' using errcode = '42501'; end if;
    if flow_date < contract_opened or (contract_closed is not null and flow_date > contract_closed) then
      raise exception 'Cash flow date is outside contract lifetime' using errcode = '23514';
    end if;
  end loop;
  if new.currency_code = 'EUR' then
    if new.fx_rate_id is not null then
      raise exception 'EUR cash flow has invalid FX state' using errcode = '23514';
    end if;
    new.fx_status := 'resolved';
  elsif new.fx_rate_id is not null then
    select r.currency_code, r.requested_on, r.observed_on into rate_currency, rate_requested, rate_observed
      from public.fx_rates r where r.id = new.fx_rate_id;
    if not found or rate_currency <> new.currency_code or rate_requested <> flow_date or rate_observed > flow_date
       or new.fx_status <> 'resolved' then
      raise exception 'Cash flow FX rate is inconsistent' using errcode = '23514';
    end if;
  elsif new.fx_status not in ('pending', 'manual_required') then
    raise exception 'Cash flow FX state is inconsistent' using errcode = '23514';
  end if;
  return new;
end;
$$;
create trigger cash_flows_10_phase74 before insert or update on public.cash_flows
  for each row execute function public.guard_cash_flow_phase74();
revoke all on function public.guard_cash_flow_phase74() from public, anon, authenticated;

commit;
