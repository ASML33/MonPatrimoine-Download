-- Phase 7: contracts become the patrimonial unit and envelope types the reference classification.
-- The legacy envelope layer remains available during the transition.
begin;

create table public.envelope_types (
  id uuid primary key,
  code text not null unique check (code ~ '^[a-z0-9_-]{1,50}$'),
  label text not null unique check (char_length(btrim(label)) between 1 and 120),
  description text,
  fiscal_family_code text check (fiscal_family_code is null or fiscal_family_code ~ '^[a-z0-9_-]{1,50}$'),
  default_color char(7) check (default_color is null or default_color ~ '^#[0-9A-Fa-f]{6}$'),
  is_active boolean not null default true,
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

insert into public.envelope_types(id,code,label,description,fiscal_family_code) values
  ('71000000-0000-0000-0000-000000000001','pea','PEA','Plan d’épargne en actions.','pea'),
  ('71000000-0000-0000-0000-000000000002','cto','CTO','Compte-titres ordinaire.','cto'),
  ('71000000-0000-0000-0000-000000000003','assurance_vie','Assurance-vie','Contrat d’assurance-vie.','assurance_vie'),
  ('71000000-0000-0000-0000-000000000004','epargne_liquide','Épargne liquide','Compte ou livret d’épargne liquide.','epargne_liquide'),
  ('71000000-0000-0000-0000-000000000005','immobilier','Immobilier','Contrat ou support patrimonial immobilier.','immobilier'),
  ('71000000-0000-0000-0000-000000000006','autre','Autre','Type d’enveloppe non couvert par les catégories principales.',null);

create trigger envelope_types_set_updated_at before update on public.envelope_types
  for each row execute function public.set_updated_at();
alter table public.envelope_types enable row level security;
alter table public.envelope_types force row level security;
revoke all on public.envelope_types from public, anon, authenticated;
grant select on public.envelope_types to authenticated;
create policy principal_envelope_types_read on public.envelope_types for select to authenticated
  using (public.is_authorized_user());

alter table public.contracts
  add column envelope_type_id uuid,
  add column currency_code char(3),
  add column show_on_dashboard boolean not null default true;

-- Explicit mapping: effective version code first, then structured legacy code.
-- Labels are intentionally never used as migration authority.
with classified as (
  select c.id,
    coalesce(
      (select v.category_code
       from public.envelope_definition_versions v
       where v.envelope_definition_id = e.envelope_definition_id
         and v.valid_from <= c.opened_on
         and (v.valid_to is null or v.valid_to > c.opened_on)
       order by v.version_number desc limit 1),
      (select v.category_code
       from public.envelope_definition_versions v
       where v.envelope_definition_id = e.envelope_definition_id
       order by v.version_number desc limit 1),
      e.envelope_type_code
    ) as type_code,
    e.currency_code
  from public.contracts c
  join public.envelopes e on e.id = c.envelope_id and e.user_id = c.user_id
), mapped as (
  select classified.id, envelope_types.id as envelope_type_id, classified.currency_code
  from classified
  join public.envelope_types on envelope_types.code = classified.type_code
)
update public.contracts c
set envelope_type_id = mapped.envelope_type_id,
    currency_code = mapped.currency_code
from mapped where mapped.id = c.id;

do $$
begin
  if exists(select 1 from public.contracts where envelope_type_id is null or currency_code is null) then
    raise exception 'Contract envelope type/currency backfill is incomplete' using errcode = '23514';
  end if;
end;
$$;

alter table public.contracts
  alter column envelope_id drop not null,
  alter column envelope_type_id set not null,
  alter column currency_code set not null,
  add constraint contracts_envelope_type_reference foreign key(envelope_type_id)
    references public.envelope_types(id) on delete restrict on update cascade,
  add constraint contracts_currency_reference foreign key(currency_code)
    references public.currencies(code) on delete restrict on update cascade,
  add constraint contracts_currency_code_check check (currency_code ~ '^[A-Z]{3}$');
create index contracts_type_active_idx on public.contracts(user_id,envelope_type_id,is_active);
create index contracts_dashboard_idx on public.contracts(user_id,show_on_dashboard,is_active);

create or replace function public.guard_contract_identity()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.id is distinct from old.id or new.user_id is distinct from old.user_id
     or new.envelope_id is distinct from old.envelope_id
     or new.envelope_type_id is distinct from old.envelope_type_id then
    raise exception 'Contract identity, legacy parent and envelope type are immutable' using errcode = '23514';
  end if;
  if new.currency_code is distinct from old.currency_code
     and public.contract_has_dependencies(old.id) then
    raise exception 'Contract currency is locked while data is attached' using errcode = '23514';
  end if;
  return new;
end;
$$;

create function public.guard_contract_reference_model()
returns trigger language plpgsql security definer set search_path = '' as $$
declare legacy_type_code text; legacy_currency text;
begin
  new.name := btrim(new.name);
  if tg_op = 'INSERT' and new.envelope_type_id is null and new.envelope_id is not null then
    select coalesce(
      (select v.category_code from public.envelope_definition_versions v
       where v.envelope_definition_id=e.envelope_definition_id
         and v.valid_from<=new.opened_on and (v.valid_to is null or v.valid_to>new.opened_on)
       order by v.version_number desc limit 1),
      (select v.category_code from public.envelope_definition_versions v
       where v.envelope_definition_id=e.envelope_definition_id order by v.version_number desc limit 1),
      e.envelope_type_code), e.currency_code
      into legacy_type_code,legacy_currency
      from public.envelopes e where e.id=new.envelope_id and e.user_id=new.user_id;
    select t.id into new.envelope_type_id from public.envelope_types t where t.code=legacy_type_code;
    new.currency_code := coalesce(new.currency_code,legacy_currency);
  end if;
  new.currency_code := upper(btrim(new.currency_code));
  if not exists(select 1 from public.envelope_types t where t.id = new.envelope_type_id and t.is_active) then
    raise exception 'Envelope type is unavailable' using errcode = '42501';
  end if;
  if not exists(select 1 from public.currencies c where c.code = new.currency_code and c.is_active) then
    raise exception 'Currency is unavailable' using errcode = '42501';
  end if;
  return new;
end;
$$;
create trigger contracts_05_reference_model before insert or update of name,envelope_type_id,currency_code
  on public.contracts for each row execute function public.guard_contract_reference_model();
revoke all on function public.guard_contract_reference_model() from public, anon, authenticated;

-- Legacy parent guards remain active for historical contracts, but contracts
-- created directly under the reference model have no legacy envelope parent.
create or replace function public.guard_envelope_dependency()
returns trigger language plpgsql security definer set search_path = '' as $$
declare parent_id uuid; ref_id uuid; col text; parents uuid[] := '{}';
  active boolean; old_row jsonb; new_row jsonb := to_jsonb(new);
begin
  if tg_op = 'UPDATE' then old_row := to_jsonb(old); end if;
  foreach col in array tg_argv loop
    if tg_op = 'UPDATE' and new_row->col is not distinct from old_row->col
       and not (new_row->>'is_active' = 'true' and old_row->>'is_active' = 'false') then
      continue;
    end if;
    ref_id := (new_row->>col)::uuid;
    if ref_id is null then continue; end if;
    if col like '%contract_id' then
      select envelope_id into parent_id from public.contracts
        where id = ref_id and user_id = new.user_id for share;
      if not found then raise exception 'Contract unavailable' using errcode = '42501'; end if;
      if parent_id is null then continue; end if;
    else parent_id := ref_id;
    end if;
    parents := array_append(parents, parent_id);
  end loop;
  for parent_id in select distinct value from unnest(parents) value where value is not null order by 1 loop
    update public.envelopes set updated_at = clock_timestamp()
      where id = parent_id and user_id = new.user_id returning is_active into active;
    if not found then raise exception 'Envelope unavailable' using errcode = '42501'; end if;
    if not active and tg_table_name <> 'envelope_snapshots' then
      raise exception 'Envelope is inactive; reactivate it first' using errcode = '23514';
    end if;
  end loop;
  return new;
end;
$$;

-- Three independent target dimensions share one allocation engine. Legacy
-- envelope targets/scopes remain accepted until the old layer is retired.
alter table public.target_allocations
  add column target_envelope_type_id uuid references public.envelope_types(id) on delete restrict on update cascade,
  add column target_contract_id uuid;
alter table public.target_allocations
  add constraint target_allocations_contract_reference foreign key(target_contract_id,user_id)
    references public.contracts(id,user_id) on delete restrict on update cascade;

drop function public.target_allocation_status(public.allocation_scope_kind,public.allocation_target_kind,uuid);
alter table public.target_allocations
  drop constraint target_allocations_target_shape_check,
  drop constraint target_allocations_target_percent_check;
drop index public.target_allocations_envelope_unique_idx;
drop index public.target_allocations_asset_unique_idx;
alter type public.allocation_target_kind rename to allocation_target_kind_transition;
create type public.allocation_target_kind as enum ('envelope','envelope_type','contract','asset');
alter table public.target_allocations alter column target_kind
  type public.allocation_target_kind using target_kind::text::public.allocation_target_kind;
drop type public.allocation_target_kind_transition;

alter table public.target_allocations
  add constraint target_allocations_target_percent_check check (
    (target_percent > 0 and target_percent <= 100)
    or (target_kind = 'asset' and target_percent = -1)
  ),
  add constraint target_allocations_target_shape_check check (
  (target_kind = 'envelope' and target_envelope_id is not null and target_envelope_type_id is null and target_contract_id is null and target_asset_id is null and scope_kind = 'global')
  or (target_kind = 'envelope_type' and target_envelope_id is null and target_envelope_type_id is not null and target_contract_id is null and target_asset_id is null and scope_kind = 'global' and scope_envelope_id is null)
  or (target_kind = 'contract' and target_envelope_id is null and target_envelope_type_id is null and target_contract_id is not null and target_asset_id is null and scope_kind = 'global' and scope_envelope_id is null)
  or (target_kind = 'asset' and target_envelope_id is null and target_envelope_type_id is null and target_contract_id is null and target_asset_id is not null)
);
create unique index target_allocations_envelope_unique_idx
  on public.target_allocations(user_id,scope_kind,scope_envelope_id,target_envelope_id)
  nulls not distinct where target_kind = 'envelope';
create unique index target_allocations_asset_unique_idx
  on public.target_allocations(user_id,scope_kind,scope_envelope_id,target_asset_id)
  nulls not distinct where target_kind = 'asset';
create unique index target_allocations_envelope_type_unique_idx
  on public.target_allocations(user_id,target_envelope_type_id)
  where target_kind = 'envelope_type';
create unique index target_allocations_contract_unique_idx
  on public.target_allocations(user_id,target_contract_id)
  where target_kind = 'contract';

create function public.validate_target_allocation_reference()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.target_kind = 'envelope_type' and not exists(
    select 1 from public.envelope_types t where t.id = new.target_envelope_type_id and t.is_active
  ) then raise exception 'Envelope type target is unavailable' using errcode = '42501'; end if;
  if new.target_kind = 'contract' and not exists(
    select 1 from public.contracts c where c.id = new.target_contract_id and c.user_id = new.user_id
  ) then raise exception 'Contract target is unavailable' using errcode = '42501'; end if;
  return new;
end;
$$;
create trigger target_allocations_validate_reference before insert or update of target_kind,target_envelope_type_id,target_contract_id,user_id
  on public.target_allocations for each row execute function public.validate_target_allocation_reference();
revoke all on function public.validate_target_allocation_reference() from public, anon, authenticated;

create or replace function public.enforce_target_allocation_total()
returns trigger language plpgsql security definer set search_path = '' as $$
declare total numeric;
begin
  select coalesce(sum(target_percent) filter (where target_percent > 0), 0)
    into total from public.target_allocations
    where user_id = new.user_id and scope_kind = new.scope_kind
      and scope_envelope_id is not distinct from new.scope_envelope_id
      and target_kind = new.target_kind;
  if total > 100 then
    raise exception 'target allocations cannot exceed 100%% for one scope and target kind'
      using errcode = '23514';
  end if;
  return null;
end;
$$;

create function public.target_allocation_status(
  requested_scope public.allocation_scope_kind,
  requested_kind public.allocation_target_kind,
  requested_envelope_id uuid default null
)
returns table(positive_total numeric,remaining_percent numeric,is_complete boolean)
language plpgsql stable security invoker set search_path = '' as $$
begin
  if not public.is_authorized_user() or requested_scope is null or requested_kind is null
    or (requested_scope = 'global' and requested_envelope_id is not null)
    or (requested_scope = 'envelope' and (
      requested_kind <> 'asset' or requested_envelope_id is null or not exists(
        select 1 from public.envelopes where id=requested_envelope_id and user_id=auth.uid()
      )))
    or (requested_kind in ('envelope_type','contract') and requested_scope <> 'global') then
    raise exception 'invalid or inaccessible allocation scope' using errcode = '22023';
  end if;
  return query select total,100-total,total=100 from (
    select coalesce(sum(target_percent) filter(where target_percent>0),0) total
    from public.target_allocations where user_id=auth.uid()
      and scope_kind=requested_scope and target_kind=requested_kind
      and scope_envelope_id is not distinct from requested_envelope_id
  ) values_by_dimension;
end;
$$;
revoke all on function public.target_allocation_status(public.allocation_scope_kind,public.allocation_target_kind,uuid) from public, anon;
grant execute on function public.target_allocation_status(public.allocation_scope_kind,public.allocation_target_kind,uuid) to authenticated;

alter table public.fiscal_rules
  add column envelope_type_id uuid references public.envelope_types(id) on delete restrict on update cascade;
create index fiscal_rules_envelope_type_idx on public.fiscal_rules(envelope_type_id);

commit;
