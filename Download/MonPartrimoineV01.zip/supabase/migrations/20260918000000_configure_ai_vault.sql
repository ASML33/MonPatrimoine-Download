-- Phase 6.6c: per-user AI provider configuration with encrypted Vault storage.
create extension if not exists supabase_vault with schema vault;

revoke insert (ai_settings), update (ai_settings)
  on table public.profiles from authenticated;
revoke all on schema vault from public, anon, authenticated;
revoke all on table vault.secrets from public, anon, authenticated;
revoke all on table vault.decrypted_secrets from public, anon, authenticated;
revoke all on function vault.create_secret(text, text, text, uuid)
  from public, anon, authenticated;

revoke all on function vault.update_secret(uuid, text, text, text, uuid)
  from public, anon, authenticated;

create or replace function public.get_ai_configuration()
returns table (provider text, status text)
language plpgsql
stable
security definer
set search_path = ''
as $$
declare
  owner_id uuid := auth.uid();
  settings jsonb;
  secret_exists boolean;
  provider_is_valid boolean;
begin
  if owner_id is null then
    raise exception 'authentication required' using errcode = '42501';
  end if;

  select p.ai_settings
    into settings
    from public.profiles p
    where p.auth_user_id = owner_id and p.is_active;
  if not found then
    raise exception 'AI configuration unavailable' using errcode = '42501';
  end if;

  provider := settings ->> 'provider';
  provider_is_valid := provider in ('openai', 'anthropic', 'google');
  if provider_is_valid is distinct from true then
    provider := 'openai';
  end if;

  select exists (
    select 1 from vault.secrets s
    where s.name = 'monpatrimoine.ai.' || owner_id::text
  ) into secret_exists;

  status := case
    when not secret_exists then 'not_configured'
    when provider_is_valid is distinct from true then 'invalid'
    when settings ->> 'status' = 'invalid' then 'invalid'
    else 'configured'
  end;
  return next;
end;
$$;

create or replace function public.save_ai_configuration(
  requested_provider text,
  api_key text default null
)
returns void
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  owner_id uuid := auth.uid();
  current_settings jsonb;
  current_provider text;
  secret_id uuid;
  secret_name text;
  next_status text;
begin
  if owner_id is null then
    raise exception 'authentication required' using errcode = '42501';
  end if;
  if requested_provider is null
    or requested_provider not in ('openai', 'anthropic', 'google') then
    raise exception 'invalid AI provider' using errcode = '22023';
  end if;
  if api_key is not null and (
    api_key = '' or api_key <> btrim(api_key) or char_length(api_key) > 4096
  ) then
    raise exception 'invalid API key' using errcode = '22023';
  end if;

  select p.ai_settings
    into current_settings
    from public.profiles p
    where p.auth_user_id = owner_id and p.is_active
    for update;
  if not found then
    raise exception 'AI configuration unavailable' using errcode = '42501';
  end if;

  secret_name := 'monpatrimoine.ai.' || owner_id::text;
  select s.id into secret_id
    from vault.secrets s
    where s.name = secret_name
    for update;
  current_provider := current_settings ->> 'provider';

  if api_key is null then
    if secret_id is not null and current_provider is distinct from requested_provider then
      raise exception 'a new key is required when changing provider'
        using errcode = '22023';
    end if;
    next_status := case when secret_id is null then 'not_configured' else 'configured' end;
  elsif secret_id is null then
    perform vault.create_secret(
      api_key,
      secret_name,
      'MonPatrimoine AI credential for the authenticated user'
    );
    next_status := 'configured';
  else
    perform vault.update_secret(
      secret_id,
      api_key,
      secret_name,
      'MonPatrimoine AI credential for the authenticated user'
    );
    next_status := 'configured';
  end if;

  update public.profiles p
    set ai_settings = current_settings || jsonb_build_object(
      'provider', requested_provider,
      'status', next_status
    )
    where p.auth_user_id = owner_id;
end;
$$;

create or replace function public.delete_ai_configuration_secret()
returns void
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  owner_id uuid := auth.uid();
  current_settings jsonb;
begin
  if owner_id is null then
    raise exception 'authentication required' using errcode = '42501';
  end if;

  select p.ai_settings
    into current_settings
    from public.profiles p
    where p.auth_user_id = owner_id and p.is_active
    for update;
  if not found then
    raise exception 'AI configuration unavailable' using errcode = '42501';
  end if;

  delete from vault.secrets s
    where s.name = 'monpatrimoine.ai.' || owner_id::text;
  update public.profiles p
    set ai_settings = current_settings || jsonb_build_object('status', 'not_configured')
    where p.auth_user_id = owner_id;
end;
$$;

revoke all on function public.get_ai_configuration()
  from public, anon, authenticated;
revoke all on function public.save_ai_configuration(text, text)
  from public, anon, authenticated;
revoke all on function public.delete_ai_configuration_secret()
  from public, anon, authenticated;
grant execute on function public.get_ai_configuration() to authenticated;
grant execute on function public.save_ai_configuration(text, text) to authenticated;
grant execute on function public.delete_ai_configuration_secret() to authenticated;

comment on function public.get_ai_configuration() is
  'Returns only non-sensitive AI provider and status for auth.uid(); never decrypts a secret.';
comment on function public.save_ai_configuration(text, text) is
  'Creates or replaces the auth.uid() AI key in Vault and preserves unknown ai_settings keys.';
comment on function public.delete_ai_configuration_secret() is
  'Deletes only the deterministic Vault secret owned by auth.uid().';
