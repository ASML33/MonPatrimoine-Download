-- Correct one native observation across existing contract/currency identities.
-- No existing business row is changed by this migration.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
lock table public.cash_balances in share row exclusive mode;
create or replace function public.guard_dated_cash_balance_observations()
returns trigger language plpgsql set search_path = '' as $$
declare
 h jsonb := new.metadata->'cash_balance_observations';
 prior jsonb;
 entry jsonb;
 days date[] := '{}';
 day date;
 latest jsonb;
 archives jsonb;
 old_archives jsonb := '[]';
begin
 if h is null then
   if tg_op='UPDATE' and (old.metadata ? 'cash_balance_observations'
      or row(new.amount,new.as_of) is distinct from row(old.amount,old.as_of)) then
     raise exception 'Dated observation history required' using errcode='23514';
   end if;
   return new;
 end if;
 if h->>'version' is distinct from '2' or jsonb_typeof(h->'entries') is distinct from 'array'
    or jsonb_typeof(h->'archived') is distinct from 'array' then
   raise exception 'Unsupported dated observation history' using errcode='23514';
 end if;
 if jsonb_array_length(h->'entries')=0 and (tg_op='INSERT' or not (new.metadata ? 'cash_balance_corrections')) then raise exception 'Empty effective set requires a traced correction' using errcode='23514';end if;
 for entry in select value from jsonb_array_elements(h->'entries') loop
   if jsonb_typeof(entry->'amount') is distinct from 'string'
      or (entry->>'amount') !~ '^[0-9]{1,16}(\.[0-9]{1,8})?$'
      or entry->>'currencyCode' is distinct from btrim(new.currency_code)
      or entry->>'asOf' is null or entry->>'recordedAt' is null then
     raise exception 'Invalid native cash observation' using errcode='23514';
   end if;
   day := ((entry->>'asOf')::timestamptz at time zone 'Europe/Paris')::date;
   if not isfinite((entry->>'asOf')::timestamptz) or not isfinite((entry->>'recordedAt')::timestamptz)
      or (entry->>'asOf')::timestamptz > clock_timestamp() or day=any(days) then
     raise exception 'Duplicate civil day or invalid observation time' using errcode='23514';
   end if;
   days := array_append(days,day);
   if latest is null or (entry->>'asOf')::timestamptz > (latest->>'asOf')::timestamptz then latest:=entry; end if;
 end loop;
 if latest is not null and ((latest->>'amount')::numeric is distinct from new.amount
    or (latest->>'asOf')::timestamptz is distinct from new.as_of) then
   raise exception 'Current balance must match latest effective observation' using errcode='23514';
 end if;
 if tg_op='UPDATE' and h is distinct from old.metadata->'cash_balance_observations' then
   prior := old.metadata->'cash_balance_observations';
   if prior is not null then
     if prior->>'version' is distinct from '2' then
       raise exception 'Existing observation history requires explicit review' using errcode='23514';
     end if;
     old_archives := prior->'archived';
   end if;
   archives := h->'archived';
   if jsonb_array_length(archives) <> jsonb_array_length(old_archives)+1
      or (select coalesce(jsonb_agg(value order by ord),'[]') from jsonb_array_elements(archives) with ordinality a(value,ord)
          where ord<=jsonb_array_length(old_archives)) is distinct from old_archives then
     raise exception 'Previous versions must be preserved' using errcode='23514';
   end if;
   entry := archives->-1;
   if entry->>'replacedAt' is null or not isfinite((entry->>'replacedAt')::timestamptz) then
     raise exception 'Correction timestamp required' using errcode='23514';
   end if;
   if prior is not null then
     if entry->'entries' is distinct from prior->'entries' then
       raise exception 'Previous effective observations must be archived exactly' using errcode='23514';
     end if;
   else
     if jsonb_typeof(entry->'entries') is distinct from 'array' or jsonb_array_length(entry->'entries')<>1
        or (entry->'entries'->0->>'amount')::numeric is distinct from old.amount
        or (entry->'entries'->0->>'asOf')::timestamptz is distinct from old.as_of
        or entry->'entries'->0->>'currencyCode' is distinct from btrim(old.currency_code) then
       raise exception 'Original native balance must be archived' using errcode='23514';
     end if;
   end if;
 end if;
 return new;
end;
$$;
revoke all on function public.guard_dated_cash_balance_observations() from public,anon,authenticated;


create function public.save_cash_balance_observation(
 requested_contract uuid, requested_balance uuid, expected_updated_at timestamptz,
 expected_as_of timestamptz, requested_currency text, requested_amount numeric,
 requested_as_of timestamptz, expected_destination_updated_at timestamptz)
returns uuid language plpgsql security invoker set search_path='' as $$
declare
 actor uuid:=auth.uid(); src public.cash_balances; dst public.cash_balances;
 old_entries jsonb; entries jsonb; dest_entries jsonb; archives jsonb; meta jsonb;
 latest jsonb; after_entry jsonb; before_entry jsonb; stamp timestamptz:=clock_timestamp();
 source_day date; destination_day date; correction uuid:=gen_random_uuid(); link jsonb; destination_id uuid;
begin
 if actor is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 if requested_currency !~ '^[A-Z]{3}$' or requested_amount is null or requested_amount<0
 or requested_amount<>round(requested_amount,8) or requested_amount>=1e16
 or requested_as_of is null or not isfinite(requested_as_of) or requested_as_of>stamp then
 raise exception 'Invalid native observation' using errcode='22023';end if;
 perform 1 from public.contracts where id=requested_contract and user_id=actor for update;
 if not found then raise exception 'Contract unavailable' using errcode='42501';end if;
 if requested_balance is not null then
  select * into src from public.cash_balances where id=requested_balance and contract_id=requested_contract and user_id=actor for update;
  if not found then raise exception 'Balance unavailable' using errcode='42501';end if;
  if src.updated_at is distinct from expected_updated_at then raise exception 'Concurrent observation update' using errcode='40001';end if;
  old_entries:=coalesce(src.metadata#>'{cash_balance_observations,entries}',jsonb_build_array(jsonb_build_object('amount',src.amount::text,'currencyCode',btrim(src.currency_code),'asOf',src.as_of,'recordedAt',src.updated_at)));
  select value into before_entry from jsonb_array_elements(old_entries) where (value->>'asOf')::timestamptz=expected_as_of;
  if before_entry is null then raise exception 'Observation unavailable' using errcode='40001';end if;
  if btrim(src.currency_code)=requested_currency and (before_entry->>'amount')::numeric=requested_amount and expected_as_of=requested_as_of then return src.id;end if;
  source_day:=(expected_as_of at time zone 'Europe/Paris')::date;
 end if;
 select * into dst from public.cash_balances where contract_id=requested_contract and currency_code=requested_currency and user_id=actor for update;
 if dst.updated_at is distinct from expected_destination_updated_at then raise exception 'Concurrent destination update' using errcode='40001';end if;
 if requested_balance is null and dst.id is not null and exists(select 1 from jsonb_array_elements(coalesce(dst.metadata#>'{cash_balance_observations,entries}',jsonb_build_array(jsonb_build_object('amount',dst.amount::text,'asOf',dst.as_of)))) e where (e->>'asOf')::timestamptz=requested_as_of and (e->>'amount')::numeric=requested_amount) then return dst.id;end if;
 destination_id:=coalesce(dst.id,gen_random_uuid());
 destination_day:=(requested_as_of at time zone 'Europe/Paris')::date;
 after_entry:=jsonb_build_object('amount',requested_amount::text,'currencyCode',requested_currency,'asOf',requested_as_of,'recordedAt',stamp);
 link:=jsonb_build_object('id',correction,'sourceBalanceId',src.id,'destinationBalanceId',destination_id,'previous',before_entry,'submitted',after_entry,'recordedAt',stamp);
 if src.id is not null and src.id is distinct from dst.id then
  select coalesce(jsonb_agg(value order by (value->>'asOf')::timestamptz),'[]') into entries from jsonb_array_elements(old_entries) where ((value->>'asOf')::timestamptz at time zone 'Europe/Paris')::date<>source_day;
  archives:=coalesce(src.metadata#>'{cash_balance_observations,archived}','[]')||jsonb_build_array(jsonb_build_object('entries',old_entries,'replacedAt',stamp));
  select value into latest from jsonb_array_elements(entries) order by (value->>'asOf')::timestamptz desc limit 1;
  meta:=src.metadata||jsonb_build_object('cash_balance_observations',jsonb_build_object('version',2,'entries',entries,'archived',archives),'cash_balance_corrections',coalesce(src.metadata->'cash_balance_corrections','[]')||jsonb_build_array(link));
  update public.cash_balances set metadata=meta,amount=coalesce((latest->>'amount')::numeric,src.amount),as_of=coalesce((latest->>'asOf')::timestamptz,src.as_of) where id=src.id;
 end if;
 if dst.id is null then
  insert into public.cash_balances(id,user_id,contract_id,currency_code,amount,as_of,metadata) values(destination_id,actor,requested_contract,requested_currency,requested_amount,requested_as_of,jsonb_build_object('cash_balance_observations',jsonb_build_object('version',2,'entries',jsonb_build_array(after_entry),'archived','[]'::jsonb),'cash_balance_corrections',jsonb_build_array(link)));
 else
  dest_entries:=coalesce(dst.metadata#>'{cash_balance_observations,entries}',jsonb_build_array(jsonb_build_object('amount',dst.amount::text,'currencyCode',btrim(dst.currency_code),'asOf',dst.as_of,'recordedAt',dst.updated_at)));
  select coalesce(jsonb_agg(value order by (value->>'asOf')::timestamptz),'[]') into entries from jsonb_array_elements(dest_entries) where ((value->>'asOf')::timestamptz at time zone 'Europe/Paris')::date<>destination_day and (src.id is distinct from dst.id or ((value->>'asOf')::timestamptz at time zone 'Europe/Paris')::date<>source_day);
  entries:=entries||jsonb_build_array(after_entry);
  select value into latest from jsonb_array_elements(entries) order by (value->>'asOf')::timestamptz desc limit 1;
  archives:=coalesce(dst.metadata#>'{cash_balance_observations,archived}','[]')||jsonb_build_array(jsonb_build_object('entries',dest_entries,'replacedAt',stamp));
  meta:=dst.metadata||jsonb_build_object('cash_balance_observations',jsonb_build_object('version',2,'entries',entries,'archived',archives),'cash_balance_corrections',coalesce(dst.metadata->'cash_balance_corrections','[]')||jsonb_build_array(link));
  update public.cash_balances set metadata=meta,amount=(latest->>'amount')::numeric,as_of=(latest->>'asOf')::timestamptz where id=dst.id;
 end if;
 return destination_id;
end$$;
revoke all on function public.save_cash_balance_observation(uuid,uuid,timestamptz,timestamptz,text,numeric,timestamptz,timestamptz) from public,anon;
grant execute on function public.save_cash_balance_observation(uuid,uuid,timestamptz,timestamptz,text,numeric,timestamptz,timestamptz) to authenticated;
notify pgrst,'reload schema';
commit;