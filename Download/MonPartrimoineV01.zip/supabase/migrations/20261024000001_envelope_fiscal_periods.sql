-- Replacement local candidate: category-level tax schedules. No source value
-- or existing contract/rule/capture is updated. Never apply the superseded 00000.
begin;
set local lock_timeout='5s';set local statement_timeout='120s';
create table private.envelope_archive_frontier(schema_hash text primary key);
insert into private.envelope_archive_frontier select private.app_backup_schema();
revoke all on private.envelope_archive_frontier from public,anon,authenticated,service_role;
create table public.envelope_fiscalities(
 id uuid primary key default gen_random_uuid(),owner_user_id uuid not null references auth.users(id),
 envelope_type_id uuid not null references public.envelope_types(id) on delete restrict,
 rule_id uuid references public.fiscal_rules(id) on delete restrict,
 label text not null check(char_length(btrim(label)) between 1 and 120),
 mode text not null check(mode in('calculated','manual','unsupported','none')),
 starts_on date,ends_on date,transition_on date,
 supersedes_id uuid unique references public.envelope_fiscalities(id) on delete restrict deferrable initially deferred,
 revision integer not null default 1 check(revision>0),adopted boolean not null default false,
 note text not null default '',configuration jsonb not null default '{}',
 check(ends_on is null or starts_on is null or ends_on>=starts_on),
 check((supersedes_id is null)=(transition_on is null)),
 check(mode<>'calculated' or rule_id is not null or coalesce(configuration->>'version'='2',false))
);
alter table public.envelope_fiscalities enable row level security;
alter table public.envelope_fiscalities force row level security;
create policy principal_read on public.envelope_fiscalities for select to authenticated using(public.is_authorized_user() and owner_user_id=auth.uid());
revoke all on public.envelope_fiscalities from public,anon,authenticated,service_role;
grant select on public.envelope_fiscalities to authenticated;

-- Conservative deterministic adoption from identities/parameters, never names.
-- Divergent contracts, personal exceptions and voluntary ledgers stay unresolved.
create function private.envelope_seed(types jsonb,contracts jsonb,rules jsonb,regimes jsonb,actor uuid) returns jsonb language plpgsql set search_path='' as $$
declare t jsonb; c jsonb; f jsonb; signatures text[]; ids uuid[]; fid uuid; note_value text; mode_value text; result jsonb:='[]'; signature text;begin
 for t in select value from jsonb_array_elements(types) loop
  signatures:='{}';ids:='{}';note_value:='';fid:=null;f:=null;
  for c in select value from jsonb_array_elements(contracts) where value->>'envelope_type_id'=t->>'id' loop
   signature:=jsonb_build_array(c->'fiscal_regime_id',c#>'{fiscal_assignments,baseline,ruleIds}')::text;
   if not signature=any(signatures) then signatures:=array_append(signatures,signature);end if;
   if coalesce(jsonb_array_length(c#>'{fiscal_assignments,entries}'),0)>0 then note_value:='Affectations datées antérieures : reprise explicite nécessaire.';end if;
   for fid in select value::uuid from jsonb_array_elements_text(coalesce(c#>'{fiscal_assignments,baseline,ruleIds}','[]')) loop
    if not fid=any(ids) then ids:=array_append(ids,fid);end if;
   end loop;
  end loop;
  if cardinality(signatures)>1 then note_value:='Configurations contractuelles antérieures différentes : aucun choix automatique.';end if;
  if cardinality(signatures)=0 then
   if t->>'default_fiscal_rule_id' is not null then ids:=array[(t->>'default_fiscal_rule_id')::uuid];
   else select coalesce(array_agg((r->>'id')::uuid),'{}') into ids from jsonb_array_elements(rules) r where r->>'owner_user_id' is null and r->>'status'='verified' and exists(select 1 from jsonb_array_elements(regimes) g where g->>'id'=r->>'fiscal_regime_id' and g->>'envelope_type_id'=t->>'id');end if;
  end if;
  if cardinality(ids)=1 then select value into f from jsonb_array_elements(rules) where value->>'id'=ids[1]::text;end if;
  if cardinality(ids)>1 then note_value:='Plusieurs versions ou régimes antérieurs : reprise explicite nécessaire.';end if;
  if f->>'owner_user_id' is not null then note_value:='Paramétrage personnel antérieur : aucune généralisation aux autres contrats.';end if;
  if note_value<>'' then f:=null;mode_value:='unsupported';
  elsif f is not null then mode_value:=case when f->>'calculation_mode'='manual' then 'manual' else 'calculated' end;
  elsif exists(select 1 from jsonb_array_elements(contracts) old_contract where old_contract->>'envelope_type_id'=t->>'id' and old_contract->>'fiscal_regime_id' is not null) then mode_value:='unsupported';note_value:='Ancien régime sans version exécutable : NET non calculé.';
  else mode_value:='none';end if;
  -- Explicit application conventions supersede conflicting old regime anchors.
  -- Old contracts/rules/assignments remain unchanged as evidence.
  if t->>'code' in('epargne_liquide','immobilier','per_col','peg') then
   f:=null; mode_value:=case when t->>'code'='peg' then 'manual' else 'none' end;
   note_value:=case t->>'code' when 'epargne_liquide' then 'NET = BRUT, sans calcul fiscal.' when 'immobilier' then 'Convention applicative NET = BRUT, sans exonération légale déduite.' when 'per_col' then 'BRUT uniquement ; NET volontairement absent.' else 'NET manuel qualifié, lié à sa source et à sa date ; PAGA reste exclu par identité.' end;
  end if;
  result:=result||jsonb_build_array(jsonb_build_object('id',md5('envelope-adoption:'||(t->>'id'))::uuid,'owner_user_id',actor,'envelope_type_id',t->>'id','rule_id',f->>'id','label',case when f is null then 'Fiscalité à configurer' else f->>'rule_name' end,'mode',mode_value,'starts_on',f->>'valid_from','ends_on',null,'transition_on',null,'supersedes_id',null,'revision',1,'adopted',true,'note',note_value,'configuration','{}'::jsonb));
 end loop;return result;
end$$;
insert into public.envelope_fiscalities select * from jsonb_populate_recordset(null::public.envelope_fiscalities,private.envelope_seed(
 (select coalesce(jsonb_agg(to_jsonb(t)),'[]') from public.envelope_types t),(select coalesce(jsonb_agg(to_jsonb(c)),'[]') from public.contracts c),
 (select coalesce(jsonb_agg(to_jsonb(f)),'[]') from public.fiscal_rules f),(select coalesce(jsonb_agg(to_jsonb(r)),'[]') from public.fiscal_regimes r),(select auth_user_id from private.application_principal)));

create function private.envelope_tax_lock() returns trigger language plpgsql security definer set search_path='' as $$
begin perform pg_advisory_xact_lock_shared(hashtextextended('envelope-tax-schedule',0));return null;end$$;
-- Only identified fiscal reference writers participate. No all-table scan,
-- identity registry, generic writer rewrite or global catalogue serialization.
create trigger envelope_tax_writer before insert or delete on public.contracts for each statement execute function private.envelope_tax_lock();
create trigger envelope_tax_choice_writer before update of envelope_type_id,fiscal_assignments,fiscal_regime_id on public.contracts for each statement execute function private.envelope_tax_lock();
do $$declare rel regclass;begin foreach rel in array array['public.patrimonial_daily_captures'::regclass,'public.property_consolidations'::regclass,'public.patrimonial_legacy_sources'::regclass] loop
 execute format('create trigger envelope_tax_writer before insert or update or delete on %s for each statement execute function private.envelope_tax_lock()',rel);
end loop;end$$;
create function private.envelope_tax_usage(f public.envelope_fiscalities) returns text language plpgsql volatile security definer set search_path='' as $$
begin
 if exists(select 1 from public.contracts c where c.envelope_type_id=f.envelope_type_id)
 or exists(select 1 from public.contracts c where f.rule_id is not null and position(f.rule_id::text in c.fiscal_assignments::text)>0)
 or exists(select 1 from public.envelope_fiscalities n where n.supersedes_id=f.id)
 or exists(select 1 from public.patrimonial_daily_captures c where position(f.id::text in (c.inputs::text||coalesce(c.result::text,'')))>0 or (f.rule_id is not null and position(f.rule_id::text in(c.inputs::text||coalesce(c.result::text,'')))>0))
 or exists(select 1 from public.property_consolidations c where position(f.id::text in(c.before_image::text||c.after_image::text))>0 or (f.rule_id is not null and position(f.rule_id::text in(c.before_image::text||c.after_image::text))>0))
 or exists(select 1 from public.patrimonial_legacy_sources c where position(f.id::text in c.payload::text)>0 or (f.rule_id is not null and position(f.rule_id::text in c.payload::text)>0)) then return 'used';end if;
 if f.adopted then return 'insufficient';end if;return 'unused';
end$$;
create function private.guard_envelope_fiscality() returns trigger language plpgsql security definer set search_path='' as $$
declare state text;begin
 perform pg_advisory_xact_lock(hashtextextended('envelope-tax-schedule',0));
 if public.app_restore_permitted(tg_relid,tg_op,case when tg_op='INSERT' then null else to_jsonb(old) end,case when tg_op='DELETE' then null else to_jsonb(new) end) then return case when tg_op='DELETE' then old else new end;end if;
 if tg_op='UPDATE' and (to_jsonb(new)-'revision')=(to_jsonb(old)-'revision') then return old;end if;
 if tg_op<>'INSERT' then
  state:=private.envelope_tax_usage(old);
  if state='used' then raise exception 'Fiscalité utilisée : créez une évolution datée' using errcode='P7201';end if;
  if state='insufficient' then raise exception 'Preuve historique insuffisante' using errcode='P7202';end if;
 end if;
 if tg_op='UPDATE' and (new.id<>old.id or new.owner_user_id<>old.owner_user_id or new.envelope_type_id<>old.envelope_type_id or new.supersedes_id is distinct from old.supersedes_id or new.transition_on is distinct from old.transition_on or new.adopted<>old.adopted) then raise exception 'Identité protégée' using errcode='23514';end if;
 return case when tg_op='DELETE' then old else new end;
end$$;
create trigger fiscality_guard before insert or update or delete on public.envelope_fiscalities for each row execute function private.guard_envelope_fiscality();

-- Reuse installed type/model validators behind private helpers. Retire the old
-- public management and assignment endpoints instead of leaving a second writer.
do $$declare body text;begin
 select pg_get_functiondef('public.save_envelope_type_configuration(jsonb)'::regprocedure) into body;
 execute replace(body,'FUNCTION public.save_envelope_type_configuration','FUNCTION private.create_envelope_type');
 select pg_get_functiondef('public.create_configured_fiscal_version(jsonb)'::regprocedure) into body;
 body:=replace(body,'regime.envelope_type_id,name_value,','regime.envelope_type_id,left(name_value,110)||'' [''||rid::text||'']'',');
 execute replace(body,'FUNCTION public.create_configured_fiscal_version','FUNCTION private.create_envelope_rule');
end$$;
create function private.envelope_rule(p jsonb) returns uuid language plpgsql security definer set search_path='' as $$
declare template public.fiscal_rules; d date:=coalesce((p->>'starts_on')::date,date '0001-01-01');begin
 select * into template from public.fiscal_rules where id=(p->>'templateId')::uuid and status='verified' and active and (owner_user_id is null or owner_user_id=auth.uid());
 if template.id is null or template.ir_base_type is null or template.ps_base_type is null then raise exception 'Modèle non pris en charge' using errcode='P7204';end if;
 return private.create_envelope_rule((p-'label'-'mode'-'starts_on'-'ends_on')||jsonb_build_object('regimeId',null,'expectedVersion',(select max(version_number) from public.fiscal_rules where fiscal_regime_id=template.fiscal_regime_id),'date',d,'name',to_char(d,'YYYY.MM.DD')||' — '||(p->>'label')));
end$$;
-- Version 2 uses only finite existing operations and ordered numeric tiers.
-- No new immutable fiscal_rules row is required: the protected fiscality itself
-- owns the executable definition. Old model rows remain exact archive evidence.
create function private.validate_envelope_common(p jsonb,code text) returns void language plpgsql set search_path='' as $$
declare tier jsonb;prior integer:=-1;months integer;begin
 if exists(select 1 from jsonb_object_keys(p) k where k not in('label','mode','starts_on','ends_on','version','scope','irBase','psBase','tiers','psPaid','remarks')) then raise exception 'Paramètre exclu du socle' using errcode='P7204';end if;
 if p->>'version' is distinct from '2' or p->>'scope' is distinct from (case when code='cto' then 'position' else 'contract' end)
 or p->>'irBase' is null or p->>'psBase' is null or p->>'irBase' not in('none','gross','positive_unrealized_gain','positive_plan_gain','positive_interest_gain') or p->>'psBase' not in('none','gross','positive_unrealized_gain','positive_plan_gain','positive_interest_gain')
 or p->>'psPaid' is null or p->>'psPaid' not in('contract','not_applicable') or jsonb_typeof(p->'remarks') is distinct from 'string' or char_length(p->>'remarks')>2000
 or jsonb_typeof(p->'tiers') is distinct from 'array' then raise exception 'Socle non pris en charge' using errcode='P7204';end if;
 if jsonb_array_length(p->'tiers') not between 1 and 12 then raise exception 'Paliers incomplets' using errcode='P7204';end if;
 if code='cto' and (p->>'irBase' not in('none','positive_unrealized_gain') or p->>'psBase' not in('none','positive_unrealized_gain') or p->>'psPaid'<>'not_applicable') then raise exception 'CTO titre par titre, sans crédit contractuel' using errcode='P7204';end if;
 for tier in select value from jsonb_array_elements(p->'tiers') loop
  if jsonb_typeof(tier) is distinct from 'object' or exists(select 1 from jsonb_object_keys(tier) k where k not in('fromMonths','ir','ps')) or jsonb_typeof(tier->'fromMonths') is distinct from 'number' or jsonb_typeof(tier->'ir') is distinct from 'number' or jsonb_typeof(tier->'ps') is distinct from 'number' then raise exception 'Palier numérique requis' using errcode='P7204';end if;
  months:=(tier->>'fromMonths')::integer;
  if (tier->>'fromMonths')::numeric<>months or months not between 0 and 1200 or months<=prior or (prior=-1 and months<>0) or (tier->>'ir')::numeric not between 0 and 1 or (tier->>'ps')::numeric not between 0 and 1 then raise exception 'Paliers ordonnés sans trou ni doublon requis' using errcode='P7204';end if;
  if (tier->>'ps')::numeric>0 and p->>'psBase' not in('none','positive_unrealized_gain') and p->>'psPaid'<>'contract' then raise exception 'PS déjà acquittés requis pour ce modèle' using errcode='P7204';end if;
  prior:=months;
 end loop;
end$$;
revoke all on function private.validate_envelope_common(jsonb,text) from public,anon,authenticated,service_role;
create function private.insert_envelope_fiscality(tid uuid,p jsonb,prior uuid default null,cut date default null) returns uuid language plpgsql security definer set search_path='' as $$
declare fid uuid; result uuid; mode_value text:=p->>'mode';code text;begin
 select t.code into code from public.envelope_types t where t.id=tid;
 if code in('epargne_liquide','immobilier','peg','per_col') then raise exception 'Mode NET fixé par la convention de cette enveloppe' using errcode='P7204';end if;
 if jsonb_typeof(p)<>'object' or mode_value not in('calculated','manual','unsupported','none') or char_length(btrim(p->>'label')) not between 1 and 120 or exists(select 1 from jsonb_object_keys(p) k where k not in('label','mode','starts_on','ends_on','templateId','months','ir','ps','irAfter','psAfter','allowance','allowanceScope','version','scope','irBase','psBase','tiers','psPaid','remarks')) then raise exception 'Paramètres invalides' using errcode='23514';end if;
 if (p->>'starts_on')::date>(p->>'ends_on')::date or cut>(p->>'ends_on')::date then raise exception 'Période invalide' using errcode='P7203';end if;
 if p->>'version'='2' then
  if mode_value<>'calculated' then raise exception 'Socle réservé au mode calculé' using errcode='P7204';end if;
  perform private.validate_envelope_common(p,code);
 elsif p ? 'version' then raise exception 'Version du socle inconnue' using errcode='P7204';
 elsif mode_value in('calculated','manual') then
  if p->>'allowance' is not null or p->>'allowanceScope' is not null then raise exception 'Abattements exclus de l’estimation' using errcode='P7204';end if;
  fid:=private.envelope_rule(p);
  if (select calculation_mode='manual' from public.fiscal_rules where id=fid)<>(mode_value='manual') then raise exception 'Modèle incompatible' using errcode='P7204';end if;
 end if;
 insert into public.envelope_fiscalities(owner_user_id,envelope_type_id,rule_id,label,mode,starts_on,ends_on,supersedes_id,transition_on,configuration)
 values(auth.uid(),tid,fid,btrim(p->>'label'),mode_value,(p->>'starts_on')::date,(p->>'ends_on')::date,prior,cut,p) returning id into result;return result;
end$$;
create function public.create_envelope_bundle(requested jsonb) returns uuid language plpgsql security definer set search_path='' as $$
declare tid uuid;p jsonb;begin
 if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 perform pg_advisory_xact_lock(hashtextextended('envelope-tax-schedule',0));
 if jsonb_typeof(requested->'fiscalities') is distinct from 'array' or jsonb_array_length(requested->'fiscalities')>20 then raise exception 'Fiscalités invalides' using errcode='23514';end if;
 tid:=private.create_envelope_type(jsonb_build_object('label',requested->>'label','allowed','[]'::jsonb,'active',true));
 for p in select value from jsonb_array_elements(requested->'fiscalities') loop perform private.insert_envelope_fiscality(tid,p);end loop;
 return tid;
end$$;
create function public.change_envelope_fiscality(operation text,envelope uuid,ident uuid,expected integer,requested jsonb,transition date default null) returns uuid language plpgsql security definer set search_path='' as $$
declare f public.envelope_fiscalities; tmp public.envelope_fiscalities; new_id uuid;begin
 if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 perform pg_advisory_xact_lock(hashtextextended('envelope-tax-schedule',0));
 if not exists(select 1 from public.envelope_types where id=envelope) then raise exception 'Enveloppe inconnue' using errcode='23514';end if;
 if operation='add' then return private.insert_envelope_fiscality(envelope,requested);end if;
 select * into f from public.envelope_fiscalities where id=ident and envelope_type_id=envelope and owner_user_id=auth.uid() for update;
 if f.id is null or f.revision is distinct from expected then raise exception 'Révision obsolète' using errcode='40001';end if;
 if operation='evolve' then
  if transition is null or (f.transition_on is not null and transition<=f.transition_on) or exists(select 1 from public.envelope_fiscalities where supersedes_id=f.id) then raise exception 'Évolution concurrente ou date invalide' using errcode='40001';end if;
  return private.insert_envelope_fiscality(envelope,requested,f.id,transition);
 elsif operation='edit' then
  if f.configuration=requested then return f.id;end if;
  if private.envelope_tax_usage(f)<>'unused' then raise exception 'Fiscalité protégée' using errcode=case when private.envelope_tax_usage(f)='used' then 'P7201' else 'P7202' end;end if;
  new_id:=private.insert_envelope_fiscality(envelope,requested);select * into tmp from public.envelope_fiscalities where id=new_id;
  -- Temporary unused row, not a dependency removed to make f unused.
  delete from public.envelope_fiscalities where id=new_id;
  update public.envelope_fiscalities set rule_id=tmp.rule_id,label=tmp.label,mode=tmp.mode,starts_on=tmp.starts_on,ends_on=tmp.ends_on,configuration=tmp.configuration,revision=revision+1 where id=f.id;return f.id;
 elsif operation='delete' then delete from public.envelope_fiscalities where id=f.id;return f.id;
 else raise exception 'Opération invalide' using errcode='23514';end if;
end$$;

create function public.get_envelopes() returns jsonb language plpgsql volatile security definer set search_path='' as $$
begin if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 return public.get_envelope_fiscal_catalog()||jsonb_build_object('version',1,'fiscalities',(select coalesce(jsonb_agg(to_jsonb(f)||jsonb_build_object('protection',private.envelope_tax_usage(f))),'[]') from public.envelope_fiscalities f where owner_user_id=auth.uid()),'counts',(select coalesce(jsonb_object_agg(t.id,(select count(*) from public.contracts c where c.envelope_type_id=t.id)),'{}') from public.envelope_types t));end$$;

create or replace function public.guard_contract_fiscal_assignments() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if public.app_restore_permitted(tg_relid,tg_op,case when tg_op='INSERT' then null else to_jsonb(old) end,to_jsonb(new)) then return new;end if;
 if tg_op='INSERT' then
  if new.fiscal_regime_id is not null or new.fiscal_assignments<>'{}'::jsonb then raise exception 'Fiscalité portée par l’enveloppe' using errcode='P7200';end if;
  if not exists(select 1 from public.envelope_types where id=new.envelope_type_id and is_active) then raise exception 'Enveloppe inactive' using errcode='23514';end if;
  new.fiscal_assignments:=jsonb_build_object('version',1,'baseline',jsonb_build_object('regimeId',null,'ruleIds','[]'::jsonb,'origin','envelope','context',private.fiscal_contract_context(new)),'entries','[]'::jsonb);
 elsif new.fiscal_assignments is distinct from old.fiscal_assignments or new.fiscal_regime_id is distinct from old.fiscal_regime_id then raise exception 'Anciennes affectations conservées en preuve' using errcode='P7200';end if;return new;
end$$;
do $$declare sig text; body text;begin
 foreach sig in array array['public.save_envelope_type_configuration(jsonb)','public.create_configured_fiscal_version(jsonb)','public.set_fiscal_regime_active(uuid,boolean,integer)','public.save_contract_fiscal_assignment(uuid,uuid,uuid,date,text,uuid,boolean)'] loop
  select pg_get_functiondef(sig::regprocedure) into body;
  -- Keep signature, ACL, search_path; replace body with an explicit retirement.
  body:=regexp_replace(body,'AS \$function\$[\s\S]*\$function\$',E'AS $function$ begin raise exception ''Utilisez Enveloppes'' using errcode=''P7200'';end $function$');execute body;
 end loop;
 -- Only snapshot/reference writers that lock before writing need this prefix.
 foreach sig in array array['public.claim_patrimonial_daily_capture(date,boolean)','public.publish_patrimonial_daily_capture(uuid,jsonb)','public.apply_property_consolidation(uuid[],text,text,uuid)','private.app_backup_replace(jsonb,text)'] loop
  select pg_get_functiondef(sig::regprocedure) into body;
  body:=regexp_replace(body,'\mbegin\M',case when sig like 'private.app_backup_replace%' then E'begin\n perform pg_advisory_xact_lock(hashtextextended(''envelope-tax-schedule'',0));' else E'begin\n perform pg_advisory_xact_lock_shared(hashtextextended(''envelope-tax-schedule'',0));' end,'i');execute body;
 end loop;
 select pg_get_functiondef('private.daily_capture_inputs()'::regprocedure) into body;
 body:=replace(body,'select jsonb_build_object(',E'select jsonb_build_object(''envelopeFiscalities'',(select coalesce(jsonb_agg(to_jsonb(f)),''[]'') from public.envelope_fiscalities f))||jsonb_build_object(');execute body;
end$$;

-- Deployment overlap: the original claim keeps its original archive shape for
-- old workers. The new entry point freezes the envelope inputs for new workers.
-- Both serialize on the same date lock and publish through the same immutable
-- publication protocol. An old failed claim is explicitly identified on resume.
do $$declare body text;begin
 select pg_get_functiondef('public.claim_patrimonial_daily_capture(date,boolean)'::regprocedure) into body;
 execute replace(replace(body,'FUNCTION public.claim_patrimonial_daily_capture','FUNCTION public.claim_envelope_daily_capture'),
   'return to_jsonb(saved);','return to_jsonb(saved)||jsonb_build_object(''envelope_capture_version'',case when saved.inputs ? ''envelopeFiscalities'' then 1 else 0 end);');
 body:=replace(body,'private.daily_capture_inputs()','(private.daily_capture_inputs()-''envelopeFiscalities'')');
 execute replace(body,'if old.state<>''published'' then','if old.state<>''published'' then if old.inputs ? ''envelopeFiscalities'' then return null;end if;');
end$$;
revoke all on function public.claim_envelope_daily_capture(date,boolean) from public,anon,authenticated;
grant execute on function public.claim_envelope_daily_capture(date,boolean) to service_role;

-- The new owned dataset is restored atomically with its referenced personal
-- rule versions. Exact permits keep their existing semantics, with no registry.
insert into private.app_backup_datasets(name,relation,predicate,ordinal,shared,columns,primary_columns)
select 'envelope_fiscalities','public.envelope_fiscalities','owner_user_id=auth.uid()',24,false,array_agg(attname::text order by attnum),array['id']::text[] from pg_attribute where attrelid='public.envelope_fiscalities'::regclass and attnum>0 and not attisdropped;
create function private.envelope_archive_rows(doc jsonb,dataset text) returns jsonb language plpgsql security definer set search_path='' as $$
declare d private.app_backup_datasets;objects jsonb;result jsonb;begin
 select * into strict d from private.app_backup_datasets where name=dataset;
 select coalesce(jsonb_agg(obj),'[]') into objects from(select jsonb_object_agg(c,cells->(ord-1)::int) obj from jsonb_array_elements(doc#>array['datasets',dataset,'rows']) cells cross join unnest(d.columns) with ordinality u(c,ord) group by cells) q;
 execute format('select coalesce(jsonb_agg(to_jsonb(x)),''[]'') from (%s)x',private.app_backup_typed_rows(d.relation)) into result using objects;return result;
end$$;
create function private.envelope_upgrade_archive(doc jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
declare rows_json jsonb; colnames text[];begin
 select columns into colnames from private.app_backup_datasets where name='envelope_fiscalities';
 select coalesce(jsonb_agg((select jsonb_agg(case when r->c='null'::jsonb then null else r->>c end order by ord) from unnest(colnames) with ordinality u(c,ord))),'[]') into rows_json
 from jsonb_array_elements(private.envelope_seed(private.envelope_archive_rows(doc,'envelope_types'),private.envelope_archive_rows(doc,'contracts'),private.envelope_archive_rows(doc,'fiscal_rules_shared')||private.envelope_archive_rows(doc,'fiscal_rules'),private.envelope_archive_rows(doc,'fiscal_regimes_shared')||private.envelope_archive_rows(doc,'fiscal_regimes'),(doc->>'owner')::uuid)) r;
 select coalesce(jsonb_agg(value order by value::text collate "C"),'[]') into rows_json from jsonb_array_elements(rows_json);
 return jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()))||jsonb_build_object('datasets',(doc->'datasets')||jsonb_build_object('envelope_fiscalities',jsonb_build_object('columns',colnames,'rows',rows_json)));
end$$;
do $$declare body text;begin
 select pg_get_functiondef('private.app_backup_upgrade(jsonb)'::regprocedure) into body;
 body:=replace(body,'if doc->>''format''=''monpatrimoine-app-backup/2'' then',E'if doc->>''format''=''monpatrimoine-app-backup/2'' and exists(select 1 from private.envelope_archive_frontier where schema_hash=doc->>''schema'') then doc:=private.envelope_upgrade_archive(doc);end if;\n if doc->>''format''=''monpatrimoine-app-backup/2'' then');
 body:=replace(body,E'\n perform private.app_backup_validate(doc);\n return doc;',E'\n doc:=private.envelope_upgrade_archive(doc);\n perform private.app_backup_validate(doc);\n return doc;');execute body;
end$$;
revoke all on function private.envelope_seed(jsonb,jsonb,jsonb,jsonb,uuid),private.envelope_tax_lock(),private.envelope_tax_usage(public.envelope_fiscalities),private.guard_envelope_fiscality(),private.create_envelope_type(jsonb),private.create_envelope_rule(jsonb),private.envelope_rule(jsonb),private.insert_envelope_fiscality(uuid,jsonb,uuid,date),private.envelope_archive_rows(jsonb,text),private.envelope_upgrade_archive(jsonb) from public,anon,authenticated,service_role;
revoke all on function public.create_envelope_bundle(jsonb),public.change_envelope_fiscality(text,uuid,uuid,integer,jsonb,date),public.get_envelopes() from public,anon,service_role;
grant execute on function public.create_envelope_bundle(jsonb),public.change_envelope_fiscality(text,uuid,uuid,integer,jsonb,date),public.get_envelopes() to authenticated;
commit;
