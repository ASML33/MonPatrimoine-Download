-- Phase 7.3D: manual asset prices, one correction-capable row per UTC day.
begin;

alter table public.asset_prices
  drop constraint asset_prices_price_check;
alter table public.asset_prices
  add constraint asset_prices_price_positive check (price > 0);

create unique index asset_prices_manual_daily_unique_idx
on public.asset_prices (
  asset_id,
  user_id,
  ((observed_at at time zone 'UTC')::date)
)
where origin = 'manual';

create function public.guard_manual_asset_price()
returns trigger
language plpgsql
security invoker
set search_path = ''
as $$
declare
  asset_owner uuid;
  asset_currency char(3);
begin
  if new.origin <> 'manual' then
    return new;
  end if;

  if new.price <= 0 then
    raise exception 'Manual asset price must be strictly positive' using errcode = '23514';
  end if;
  if (new.observed_at at time zone 'UTC')::date > (clock_timestamp() at time zone 'UTC')::date then
    raise exception 'Manual asset price date cannot be in the future' using errcode = '23514';
  end if;

  select owner_user_id, currency_code
  into asset_owner, asset_currency
  from public.assets
  where id = new.asset_id;

  if not found or asset_owner is distinct from new.user_id then
    raise exception 'Asset is not available for this manual price' using errcode = '42501';
  end if;
  if new.currency_code is distinct from asset_currency then
    raise exception 'Manual asset price must use the asset currency' using errcode = '23514';
  end if;
  return new;
end;
$$;

create trigger prices_02_manual_rules
before insert or update of asset_id, user_id, origin, price, currency_code, observed_at
on public.asset_prices
for each row execute function public.guard_manual_asset_price();

revoke all on function public.guard_manual_asset_price() from public, anon, authenticated;

create function public.save_manual_asset_price(
  requested_asset uuid,
  requested_price numeric,
  observed_on date
)
returns uuid
language plpgsql
security invoker
set search_path = ''
as $$
declare
  caller uuid := auth.uid();
  asset_currency char(3);
  saved_id uuid;
begin
  if caller is null or not public.is_authorized_user() then
    raise exception 'Authorized principal required' using errcode = '42501';
  end if;
  if requested_asset is null or requested_price is null or observed_on is null then
    raise exception 'Asset, price and observation date are required' using errcode = '23502';
  end if;
  if requested_price <= 0 then
    raise exception 'Manual asset price must be strictly positive' using errcode = '23514';
  end if;
  if observed_on > (clock_timestamp() at time zone 'UTC')::date then
    raise exception 'Manual asset price date cannot be in the future' using errcode = '23514';
  end if;

  select currency_code
  into asset_currency
  from public.assets
  where id = requested_asset and owner_user_id = caller;
  if not found then
    raise exception 'Asset is not available for this manual price' using errcode = '42501';
  end if;

  insert into public.asset_prices (
    asset_id,
    user_id,
    origin,
    price,
    currency_code,
    observed_at,
    obtained_at,
    source_name
  ) values (
    requested_asset,
    caller,
    'manual',
    requested_price,
    asset_currency,
    observed_on::timestamp at time zone 'UTC',
    clock_timestamp(),
    'manual'
  )
  on conflict (
    asset_id,
    user_id,
    ((observed_at at time zone 'UTC')::date)
  ) where origin = 'manual'
  do update set
    price = excluded.price,
    observed_at = excluded.observed_at,
    obtained_at = clock_timestamp(),
    source_name = excluded.source_name
  returning id into saved_id;

  return saved_id;
end;
$$;

revoke all on function public.save_manual_asset_price(uuid, numeric, date) from public, anon;
grant execute on function public.save_manual_asset_price(uuid, numeric, date) to authenticated;

comment on index public.asset_prices_manual_daily_unique_idx is
  'One manual price per asset, authorized user and UTC business day; a later write corrects that row.';
comment on function public.save_manual_asset_price(uuid, numeric, date) is
  'Atomically inserts or corrects the authorized user manual price for one UTC business day.';

commit;
