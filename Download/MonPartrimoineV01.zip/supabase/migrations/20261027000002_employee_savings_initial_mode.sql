-- Create-time default only. Existing contracts and their modes stay untouched.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
do $patch$
declare original text; needle text:='if new.valuation_source=''manual_situation''';
begin
 original:=pg_get_functiondef('private.guard_manual_contract()'::regprocedure);
 if position('if new.valuation_source=''manual_situation''' in original)=0 then raise exception 'Unexpected contract authority guard';end if;
 execute replace(original,needle,$guard$
 if tg_op='INSERT' and exists(select 1 from public.envelope_types where id=new.envelope_type_id and code in ('peg','per_col')) then
  new.valuation_source:='manual_situation';
 end if;
 if new.valuation_source='manual_situation'$guard$);
end $patch$;
notify pgrst,'reload schema';
commit;
