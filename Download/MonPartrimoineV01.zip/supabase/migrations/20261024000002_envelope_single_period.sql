-- Single business period. No existing financial definition, capture or input is rewritten.
-- transition_on remains only for exact legacy replay and the pre-existing paired FK check.
-- New calculations ignore it. New RPCs reject any independent transition argument.
begin;
create or replace function private.insert_envelope_fiscality(tid uuid,p jsonb,prior uuid default null,cut date default null) returns uuid language plpgsql security definer set search_path='' as $$
declare fid uuid; result uuid; mode_value text:=p->>'mode';code text;begin
 select t.code into code from public.envelope_types t where t.id=tid;
 if cut is not null then raise exception 'Seules les bornes de la règle sont acceptées' using errcode='P7203';end if;
 if code in('epargne_liquide','immobilier','peg','per_col') and not (
 p->>'mode'='calculated' and p->>'version'='2' and p->>'scope'='contract'
 and p->>'irBase'='none' and p->>'psBase'='none' and p->>'psPaid'='not_applicable'
 and p->'tiers'='[{"fromMonths":0,"ir":0,"ps":0}]'::jsonb
 and p->>'starts_on' is null and p->>'ends_on' is null) then
 raise exception 'Règle explicite ouverte à un palier zéro requise ; provenance NET conservée' using errcode='P7204';end if;
 if jsonb_typeof(p)<>'object' or mode_value not in('calculated','manual','unsupported','none') or char_length(btrim(p->>'label')) not between 1 and 120 or exists(select 1 from jsonb_object_keys(p) k where k not in('label','mode','starts_on','ends_on','templateId','months','ir','ps','irAfter','psAfter','allowance','allowanceScope','version','scope','irBase','psBase','tiers','psPaid','remarks')) then raise exception 'Paramètres invalides' using errcode='23514';end if;
 if (p->>'starts_on')::date>(p->>'ends_on')::date then raise exception 'Période invalide' using errcode='P7203';end if;
 if p->>'version'='2' then
  if mode_value<>'calculated' then raise exception 'Socle réservé au mode calculé' using errcode='P7204';end if;
  perform private.validate_envelope_common(p,code);
 elsif p ? 'version' then raise exception 'Version du socle inconnue' using errcode='P7204';
 elsif mode_value in('calculated','manual') then
  if p->>'allowance' is not null or p->>'allowanceScope' is not null then raise exception 'Abattements exclus de l’estimation' using errcode='P7204';end if;
  fid:=private.envelope_rule(p);
  if (select calculation_mode='manual' from public.fiscal_rules where id=fid)<>(mode_value='manual') then raise exception 'Modèle incompatible' using errcode='P7204';end if;
 end if;
 insert into public.envelope_fiscalities(owner_user_id,envelope_type_id,rule_id,label,mode,starts_on,ends_on,supersedes_id,transition_on,configuration)
 values(auth.uid(),tid,fid,btrim(p->>'label'),mode_value,(p->>'starts_on')::date,(p->>'ends_on')::date,prior,case when prior is null then null else coalesce((p->>'starts_on')::date,date '0001-01-01') end,p) returning id into result;return result;
end$$;
create or replace function public.change_envelope_fiscality(operation text,envelope uuid,ident uuid,expected integer,requested jsonb,transition date default null) returns uuid language plpgsql security definer set search_path='' as $$
declare f public.envelope_fiscalities; tmp public.envelope_fiscalities; new_id uuid;begin
 if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 perform pg_advisory_xact_lock(hashtextextended('envelope-tax-schedule',0));
 if not exists(select 1 from public.envelope_types where id=envelope) then raise exception 'Enveloppe inconnue' using errcode='23514';end if;
 if transition is not null then raise exception 'Seules les bornes de la règle sont acceptées' using errcode='P7203';end if;
 if operation='add' then
  if exists(select 1 from public.envelope_types t where t.id=envelope and t.code in('epargne_liquide','immobilier','peg','per_col'))
  and exists(select 1 from public.envelope_fiscalities x where x.owner_user_id=auth.uid() and x.envelope_type_id=envelope and x.mode='calculated') then
  raise exception 'Une définition existe déjà : utilisez son évolution' using errcode='23505';end if;
  return private.insert_envelope_fiscality(envelope,requested);
 end if;
 select * into f from public.envelope_fiscalities where id=ident and envelope_type_id=envelope and owner_user_id=auth.uid() for update;
 if f.id is null or f.revision is distinct from expected then raise exception 'Révision obsolète' using errcode='40001';end if;
 if operation='evolve' then
  if exists(select 1 from public.envelope_fiscalities where supersedes_id=f.id) then raise exception 'Évolution concurrente ou date invalide' using errcode='40001';end if;
  return private.insert_envelope_fiscality(envelope,requested,f.id,null);
 elsif operation='edit' then
  if f.configuration=requested then return f.id;end if;
  if private.envelope_tax_usage(f)<>'unused' then raise exception 'Fiscalité protégée' using errcode=case when private.envelope_tax_usage(f)='used' then 'P7201' else 'P7202' end;end if;
  new_id:=private.insert_envelope_fiscality(envelope,requested);select * into tmp from public.envelope_fiscalities where id=new_id;
  -- Temporary unused row, not a dependency removed to make f unused.
  delete from public.envelope_fiscalities where id=new_id;
  update public.envelope_fiscalities set rule_id=tmp.rule_id,label=tmp.label,mode=tmp.mode,starts_on=tmp.starts_on,ends_on=tmp.ends_on,configuration=tmp.configuration,revision=revision+1 where id=f.id;return f.id;
 elsif operation='delete' then delete from public.envelope_fiscalities where id=f.id;return f.id;
 else raise exception 'Opération invalide' using errcode='23514';end if;
end$$;

create or replace function public.get_envelopes() returns jsonb language plpgsql volatile security definer set search_path='' as $$
begin if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 return public.get_envelope_fiscal_catalog()||jsonb_build_object('version',2,'fiscalities',(select coalesce(jsonb_agg(to_jsonb(f)||jsonb_build_object('protection',private.envelope_tax_usage(f))),'[]') from public.envelope_fiscalities f where owner_user_id=auth.uid()),'counts',(select coalesce(jsonb_object_agg(t.id,(select count(*) from public.contracts c where c.envelope_type_id=t.id)),'{}') from public.envelope_types t));end$$;


-- Common zero definitions: additive successors for old mode-only evidence;
-- existing executable configurations are never replaced or duplicated.
create function private.seed_envelope_zero_rules() returns integer language plpgsql security definer set search_path='' as $$
declare t record;f public.envelope_fiscalities;p jsonb;actor uuid;total integer:=0;begin
 perform pg_advisory_xact_lock(hashtextextended('envelope-tax-schedule',0));
 actor:=auth.uid();
 if actor is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 p:='{"label":"Sans prélèvement configuré","mode":"calculated","starts_on":null,"ends_on":null,"version":2,"scope":"contract","irBase":"none","psBase":"none","tiers":[{"fromMonths":0,"ir":0,"ps":0}],"psPaid":"not_applicable","remarks":"Définition fiscale explicite ; provenance du NET conservée selon l’enveloppe."}';
 for t in select id from public.envelope_types where code in('epargne_liquide','immobilier','peg','per_col') loop
  if exists(select 1 from public.envelope_fiscalities where owner_user_id=actor and envelope_type_id=t.id and (mode='calculated' or configuration->>'version'='2')) then continue;end if;
  select x.* into f from public.envelope_fiscalities x where owner_user_id=actor and envelope_type_id=t.id and not exists(select 1 from public.envelope_fiscalities n where n.supersedes_id=x.id) order by x.id limit 1;
  perform private.insert_envelope_fiscality(t.id,p,f.id,null);total:=total+1;
 end loop;
 return total;
end$$;
revoke all on function private.seed_envelope_zero_rules() from public,anon,authenticated,service_role;
-- Reprise deliberately uses the already-authorized principal inside this migration.
-- It runs once on application, never on a read; an explicit repeat is idempotent.
do $$declare actor uuid;previous text:=current_setting('request.jwt.claim.sub',true);begin
 for actor in select distinct owner_user_id from public.envelope_fiscalities loop
  perform set_config('request.jwt.claim.sub',actor::text,true);
  if public.is_authorized_user() then perform private.seed_envelope_zero_rules();end if;
 end loop;
 perform set_config('request.jwt.claim.sub',coalesce(previous,''),true);
end$$;
-- Policy marker is part of copied capture inputs. Old archives without it retain
-- their previous source priority and transition semantics; no schema change.
do $$declare body text;begin
 select pg_get_functiondef('private.daily_capture_inputs()'::regprocedure) into body;
 if position('fiscalConsultationPolicy' in body)=0 then
  body:=replace(body,'select jsonb_build_object(', 'select jsonb_build_object(''fiscalConsultationPolicy'',2)||jsonb_build_object(');
  execute body;
 end if;
end$$;
-- The original pre-envelope claim must keep BOTH its old omissions. Otherwise
-- it would freeze policy 2 without envelope definitions and poison a later retry.
do $$declare body text;needle text:='(private.daily_capture_inputs()-''envelopeFiscalities'')';begin
 select pg_get_functiondef('public.claim_patrimonial_daily_capture(date,boolean)'::regprocedure) into body;
 if position(needle in body)=0 then raise exception 'Legacy claim compatibility target unavailable';end if;
 execute replace(body,needle,'(private.daily_capture_inputs()-''envelopeFiscalities''-''fiscalConsultationPolicy'')');
end$$;
-- An in-flight old worker cannot publish a legacy result under new inputs.
do $$declare body text;needle text:=' update public.patrimonial_daily_captures set state=''published'',result=requested_result';begin
 select pg_get_functiondef('public.publish_patrimonial_daily_capture(uuid,jsonb)'::regprocedure) into body;
 if position(needle in body)=0 then raise exception 'Publication guard target unavailable';end if;
 body:=replace(body,needle,$guard$
 perform 1 from public.patrimonial_daily_captures where claim_token=requested_token for update;
 if exists(select 1 from public.patrimonial_daily_captures where claim_token=requested_token and inputs->>'fiscalConsultationPolicy'='2')
 and requested_result#>>'{report,meta,fiscalConsultationPolicy}' is distinct from '2' then
 raise exception 'Fiscal consultation policy mismatch' using errcode='23514';end if;
 update public.patrimonial_daily_captures set state='published',result=requested_result$guard$);
 execute body;
end$$;
commit;
