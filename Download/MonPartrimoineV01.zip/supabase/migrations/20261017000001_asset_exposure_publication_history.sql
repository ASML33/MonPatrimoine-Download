-- Extend the existing exposure publication model; immutable versions, same asset identities.
begin;
set local lock_timeout='5s';
set local statement_timeout='60s';
lock table public.asset_sector_exposures,public.asset_activity_exposures,public.asset_geography_exposures in share row exclusive mode;
create table public.asset_exposure_versions (
 id uuid primary key default gen_random_uuid(),
 asset_id uuid not null references public.assets(id) on delete restrict,
 owner_user_id uuid not null references public.profiles(auth_user_id) on delete restrict,
 dimension text not null check(dimension in ('sector','activity','geography')),
 kind text not null check(kind in ('initial_recovery','publication')),
 effective_on date check(effective_on is null or isfinite(effective_on)),
 published_at timestamptz,
 recorded_at timestamptz not null default clock_timestamp(),
 rows jsonb not null check(jsonb_typeof(rows)='array' and jsonb_array_length(rows)>0),
 unique nulls not distinct(asset_id,dimension,effective_on),
 check((kind='initial_recovery' and effective_on is null and published_at is null)
    or(kind='publication' and effective_on is not null and published_at is not null and isfinite(published_at)))
);
alter table public.asset_exposure_versions enable row level security;
alter table public.asset_exposure_versions force row level security;
revoke all on public.asset_exposure_versions from public,anon,authenticated;
grant select on public.asset_exposure_versions to authenticated;
create policy exposure_version_owner on public.asset_exposure_versions for select to authenticated
using(public.is_authorized_user() and owner_user_id=auth.uid());
create function private.guard_exposure_version() returns trigger language plpgsql set search_path='' as $$
begin
 if tg_op<>'INSERT' then raise exception 'Published exposure versions are immutable' using errcode='23514';end if;
 if not exists(select 1 from public.assets a where a.id=new.asset_id and a.owner_user_id=new.owner_user_id)
    or exists(select 1 from jsonb_array_elements(new.rows) e where e->>'asset_id' is distinct from new.asset_id::text or e->>'dimension' is distinct from new.dimension or e->>'stage' is distinct from 'effective')
    or (select sum((e->>'weight_percent')::numeric) from jsonb_array_elements(new.rows)e) is distinct from 100::numeric
    or exists(select 1 from jsonb_array_elements(new.rows)e where (e->>'weight_percent')::numeric<=0 or (e->>'weight_percent')::numeric>100)
    or exists(select 1 from jsonb_array_elements(new.rows)e group by e->>'reference_id' having count(*)>1) then
   raise exception 'Invalid exposure version' using errcode='23514';
 end if;
 return new;
end $$;
revoke all on function private.guard_exposure_version() from public,anon,authenticated;
create trigger immutable_exposure_version before insert or update or delete on public.asset_exposure_versions
 for each row execute function private.guard_exposure_version();
-- Initial copying records recovery NOW, never an invented past publication/effect date.
insert into public.asset_exposure_versions(asset_id,owner_user_id,dimension,kind,rows)
select e.asset_id,a.owner_user_id,e.dimension,'initial_recovery',jsonb_agg(to_jsonb(e) order by e.reference_id)
from public.asset_exposure_rows e join public.assets a on a.id=e.asset_id where e.stage='effective'
group by e.asset_id,a.owner_user_id,e.dimension;

create or replace function public.effective_asset_exposures(requested_assets uuid[])
returns table(asset_id uuid,dimension text,reference_id uuid,weight_percent numeric,data_date date,source text,origin text,updated_at timestamptz)
language sql stable security invoker set search_path='' as $$
 with chosen as (select distinct on(v.asset_id,v.dimension) v.* from public.asset_exposure_versions v
  where v.asset_id=any(requested_assets) and (v.kind='initial_recovery' or v.effective_on <= (statement_timestamp() at time zone 'Europe/Paris')::date)
  order by v.asset_id,v.dimension,v.effective_on desc nulls last)
 select v.asset_id,v.dimension,x.reference_id,x.weight_percent,x.data_date,x.source,x.origin,x.updated_at
 from chosen v cross join lateral jsonb_to_recordset(v.rows) x(reference_id uuid,weight_percent numeric,data_date date,source text,origin text,updated_at timestamptz);
$$;

-- Existing draft/effective constraints remain; parent checks use the applicable
-- current version, while the publication wrapper validates every effective boundary.
create or replace function private.check_asset_exposures(aid uuid) returns void language plpgsql security definer set search_path='' as $$
declare slot text;
begin
 if exists(select 1 from public.asset_exposure_rows where asset_id=aid group by dimension,stage having sum(weight_percent)>100 or(stage='effective' and sum(weight_percent)<>100))then raise exception 'Invalid distribution total' using errcode='23514';end if;
 foreach slot in array array['draft','effective'] loop
  if exists(
   with current_rows as(select * from public.effective_asset_exposures(array[aid])),
   weights as(select reference_id,weight_percent from public.asset_exposure_rows where asset_id=aid and dimension='sector' and stage='draft' and slot='draft'
     union all select reference_id,weight_percent from current_rows where dimension='sector' and (slot='effective' or not exists(select 1 from public.asset_exposure_rows where asset_id=aid and dimension='sector' and stage='draft'))),
   activities as(select reference_id,weight_percent from public.asset_exposure_rows where asset_id=aid and dimension='activity' and stage='draft' and slot='draft'
     union all select reference_id,weight_percent from current_rows where dimension='activity' and slot='effective')
   select 1 from activities e join public.sector_activities a on a.id=e.reference_id left join weights w on w.reference_id=a.sector_id
   group by a.sector_id,w.weight_percent having sum(e.weight_percent)>coalesce(w.weight_percent,0)
  )then raise exception 'Activities exceed parent sector weight' using errcode='23514';end if;
 end loop;
end$$;

-- Keep the same implementation and its identity, locking, weight and parent guards.
alter function public.publish_asset_exposure_drafts(uuid,text[]) set schema private;
revoke all on function private.publish_asset_exposure_drafts(uuid,text[]) from public,anon,authenticated;
create function private.check_exposure_publication_timeline(aid uuid) returns void language plpgsql security definer set search_path='' as $$
declare d date;
begin
 for d in select distinct effective_on from public.asset_exposure_versions where asset_id=aid and effective_on is not null loop
  if exists(
   with chosen as(select distinct on(dimension) dimension,rows from public.asset_exposure_versions
     where asset_id=aid and (effective_on<=d or kind='initial_recovery') order by dimension,effective_on desc nulls last),
   sectors as(select (e->>'reference_id')::uuid id,(e->>'weight_percent')::numeric weight from chosen c cross join lateral jsonb_array_elements(c.rows)e where dimension='sector'),
   activities as(select a.sector_id,sum((e->>'weight_percent')::numeric) weight from chosen c cross join lateral jsonb_array_elements(c.rows)e join public.sector_activities a on a.id=(e->>'reference_id')::uuid where dimension='activity' group by a.sector_id)
   select 1 from activities a left join sectors s on s.id=a.sector_id where a.weight>coalesce(s.weight,0)
  ) then raise exception 'Activities exceed parent sector weight at an effective date' using errcode='23514';end if;
 end loop;
end $$;
revoke all on function private.check_exposure_publication_timeline(uuid) from public,anon,authenticated;
create function public.publish_asset_exposure_drafts(aid uuid,dimensions text[],effective_on date)
returns void language plpgsql security definer set search_path='' as $$
declare dim text; payload jsonb;
begin
 if effective_on is null or not isfinite(effective_on) then raise exception 'Explicit effective date required' using errcode='22023';end if;
 -- Locks the existing per-asset guard before any duplicate or draft inspection.
 perform private.exposure_write_scope(aid,'sector');
 if exists(select 1 from public.asset_exposure_versions v where v.asset_id=aid and v.dimension=any(dimensions) and v.effective_on=publish_asset_exposure_drafts.effective_on) then
  raise exception 'A publication already exists for this effective date' using errcode='23505';end if;
 perform private.publish_asset_exposure_drafts(aid,dimensions);
 for dim in select distinct unnest(dimensions) order by 1 loop
  select jsonb_agg(to_jsonb(e) order by reference_id) into payload from public.asset_exposure_rows e where e.asset_id=aid and e.dimension=dim and e.stage='effective';
  insert into public.asset_exposure_versions(asset_id,owner_user_id,dimension,kind,effective_on,published_at,rows)
  values(aid,auth.uid(),dim,'publication',effective_on,clock_timestamp(),payload);
 end loop;
 perform private.check_exposure_publication_timeline(aid);
end $$;
revoke all on function public.publish_asset_exposure_drafts(uuid,text[],date) from public,anon;
grant execute on function public.publish_asset_exposure_drafts(uuid,text[],date) to authenticated;
create function public.publish_asset_exposure_drafts(aid uuid,dimensions text[])
returns void language plpgsql set search_path='' as $$begin raise exception 'Explicit effective date required' using errcode='22023';end$$;
revoke all on function public.publish_asset_exposure_drafts(uuid,text[]) from public,anon;
grant execute on function public.publish_asset_exposure_drafts(uuid,text[]) to authenticated;
create function public.publish_asset_exposure_draft(aid uuid,dimension text,effective_on date)
returns void language sql security invoker set search_path='' as $$select public.publish_asset_exposure_drafts(aid,array[dimension],effective_on)$$;
revoke all on function public.publish_asset_exposure_draft(uuid,text,date) from public,anon;
grant execute on function public.publish_asset_exposure_draft(uuid,text,date) to authenticated;

-- Future captures read the applicable publication, without rewriting any existing capture.
do $$declare original text; changed text;begin
 original:=pg_get_functiondef('private.daily_capture_inputs()'::regprocedure);
 changed:=replace(original,'public.asset_exposure_rows e','(select x.*, ''effective''::text stage from public.effective_asset_exposures(array(select id from public.assets)) x) e');
 if changed=original then raise exception 'Unexpected daily capture input definition';end if;
 execute changed;
end$$;
notify pgrst,'reload schema';
commit;
