-- Separate AV guard fix. Requires the qualified CTO/PRU migration first.
BEGIN;
SET LOCAL lock_timeout='5s';
DO $preflight$
BEGIN
  IF private.app_backup_schema() IS DISTINCT FROM '453c2862b1178534239de99c96ef8e72b15cf37f0bb3c0956f6f6118c62d8fa2'
    OR md5(pg_get_functiondef('private.guard_av_history()'::regprocedure)) IS DISTINCT FROM '4527f98a12598ff91163e36dd0d04644'
    OR md5(pg_get_functiondef('private.app_backup_upgrade(jsonb)'::regprocedure)) IS DISTINCT FROM 'c9ddd5f99b141a30602025ffd366ab0f'
    OR NOT EXISTS (SELECT 1 FROM supabase_migrations.schema_migrations WHERE version='20261108000000')
    OR EXISTS (SELECT 1 FROM supabase_migrations.schema_migrations WHERE version='20261109000000')
  THEN RAISE EXCEPTION 'AV history guard predecessor drift'; END IF;
END $preflight$;

CREATE OR REPLACE FUNCTION private.guard_av_history()
RETURNS trigger LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $guard$
BEGIN
  IF public.app_restore_permitted(tg_relid,tg_op,to_jsonb(old),to_jsonb(new)) THEN
    RETURN new;
  END IF;
  IF current_user = 'authenticated' THEN
    IF tg_table_name = 'contracts' THEN
      IF new.metadata->'form_creation_receipt' IS DISTINCT FROM old.metadata->'form_creation_receipt' THEN
        RAISE EXCEPTION 'Creation receipt is immutable' USING errcode='42501';
      END IF;
      IF EXISTS (SELECT 1 FROM public.envelope_types WHERE id=old.envelope_type_id AND code='assurance_vie')
        AND (new.metadata->'securities_contribution_corrections' IS DISTINCT FROM old.metadata->'securities_contribution_corrections'
          OR new.metadata->'securities_contribution_requests' IS DISTINCT FROM old.metadata->'securities_contribution_requests') THEN
        RAISE EXCEPTION 'AV history is server managed' USING errcode='42501';
      END IF;
    ELSIF tg_table_name = 'positions' THEN
      IF EXISTS (SELECT 1 FROM public.contracts c JOIN public.envelope_types t ON t.id=c.envelope_type_id
                 WHERE c.id=new.contract_id AND t.code='assurance_vie')
        AND (new.metadata->'av_amount_requests' IS DISTINCT FROM old.metadata->'av_amount_requests'
          OR new.metadata->'amount_observation_audit' IS DISTINCT FROM old.metadata->'amount_observation_audit') THEN
        RAISE EXCEPTION 'AV history is server managed' USING errcode='42501';
      END IF;
    END IF;
  END IF;
  RETURN new;
END $guard$;

-- Complete predecessor archives retain their datasets and journal. Only the
-- schema marker changes, and only across this exact frontier.
DO $archive$
DECLARE
  definition text := pg_get_functiondef('private.app_backup_upgrade(jsonb)'::regprocedure);
  anchor text := ' -- Exact complete /3 predecessor only.';
BEGIN
  IF length(definition)-length(replace(definition,anchor,'')) <> length(anchor) THEN
    RAISE EXCEPTION 'Unexpected archive upgrade insertion';
  END IF;
  EXECUTE replace(definition,anchor,$admission$
 if doc->>'format'='monpatrimoine-app-backup/3'
  and doc->>'schema'='453c2862b1178534239de99c96ef8e72b15cf37f0bb3c0956f6f6118c62d8fa2'
  and private.app_backup_schema()='604bb69e1db9206253df3061d2627ec246ea6f79d7ffe830a8204f054adae9f8' then
  doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));
  perform private.app_backup_validate(doc);
  return doc;
 end if;
$admission$||anchor);
END $archive$;

DO $verify$
BEGIN
  IF private.app_backup_schema() IS DISTINCT FROM '604bb69e1db9206253df3061d2627ec246ea6f79d7ffe830a8204f054adae9f8' THEN
    RAISE EXCEPTION 'Unexpected AV history guard schema seal';
  END IF;
END $verify$;
COMMIT;
