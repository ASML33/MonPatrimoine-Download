-- Local preparation. Server-only minimal references/intents; no retention.
begin;
create table private.app_backup_drive_root(user_id uuid primary key references auth.users(id),installation uuid not null default gen_random_uuid(),folder_id text);
create table private.app_backup_drive_files(
 operation_id uuid primary key,user_id uuid not null references auth.users(id),file_id text not null unique,
 origin text not null check(origin in('manual','pre_restore')),key_id text not null,
 byte_size integer not null check(byte_size between 1 and 2097152),sha256 text not null check(sha256~'^[a-f0-9]{64}$'),
 state text not null default 'pending' check(state in('pending','verified')),created_at timestamptz not null default clock_timestamp()
);
alter table private.app_backup_drive_root enable row level security;
alter table private.app_backup_drive_root force row level security;
alter table private.app_backup_drive_files enable row level security;
alter table private.app_backup_drive_files force row level security;
revoke all on private.app_backup_drive_root,private.app_backup_drive_files from public,anon,authenticated,service_role;
create function public.application_backup_drive_store(operation text,actor uuid,args jsonb default '{}') returns jsonb
language plpgsql security definer set search_path='' as $$
declare root private.app_backup_drive_root; item private.app_backup_drive_files; result jsonb;begin
 if not exists(select 1 from private.application_principal p join public.profiles pr on pr.auth_user_id=p.auth_user_id where p.auth_user_id=actor and pr.is_active) then raise exception 'Backup unavailable' using errcode='42501';end if;
 insert into private.app_backup_drive_root(user_id) values(actor) on conflict do nothing;
 select * into root from private.app_backup_drive_root where user_id=actor for update;
 if operation='root' then return to_jsonb(root);
 elsif operation='folder' then
  if coalesce(args->>'id','')!~'^[A-Za-z0-9_-]{1,160}$' then raise exception 'Invalid reference';end if;
  update private.app_backup_drive_root set folder_id=coalesce(folder_id,args->>'id') where user_id=actor returning * into root;return to_jsonb(root);
 elsif operation='list' then
  return coalesce((select jsonb_agg(to_jsonb(f) order by created_at desc,operation_id) from private.app_backup_drive_files f where user_id=actor),'[]');
 elsif operation in('load','reserve','verify') then
  select * into item from private.app_backup_drive_files where operation_id=(args->>'operation_id')::uuid;
  if item.operation_id is not null and item.user_id<>actor then raise exception 'Backup unavailable' using errcode='42501';end if;
  if operation='reserve' and item.operation_id is null then
   if coalesce(args->>'file_id','')!~'^[A-Za-z0-9_-]{1,160}$' then raise exception 'Invalid reference';end if;
   insert into private.app_backup_drive_files(operation_id,user_id,file_id,origin,key_id,byte_size,sha256)
    values((args->>'operation_id')::uuid,actor,args->>'file_id',args->>'origin',args->>'key_id',(args->>'byte_size')::int,args->>'sha256') returning * into item;
  elsif operation='verify' then
   update private.app_backup_drive_files set state='verified' where operation_id=item.operation_id and user_id=actor returning * into item;
  end if;
  return to_jsonb(item);
 end if;
 raise exception 'Unsupported operation';
end$$;
revoke all on function public.application_backup_drive_store(text,uuid,jsonb) from public,anon,authenticated,service_role;
grant execute on function public.application_backup_drive_store(text,uuid,jsonb) to service_role;
commit;
