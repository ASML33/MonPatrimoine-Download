-- Local candidate: extend the two existing acquisition RPCs to a first CTO attachment.
-- No new ledger, FX implementation, client grant, data rewrite or trigger change.
begin;set local lock_timeout='5s';set local statement_timeout='40s';
do $pre$begin
 if private.app_backup_schema()<>'2c0097879ab93eaae871f815ac30e440110c772f1da42916e186b1e2bb77e73e'or md5(pg_get_functiondef('private.app_backup_upgrade(jsonb)'::regprocedure))<>'c9ddd5f99b141a30602025ffd366ab0f'or md5(pg_get_functiondef('public.prepare_cto_acquisition_action(uuid,uuid,uuid,date,numeric,text,numeric,text,timestamptz,uuid)'::regprocedure))<>'b3f568b6e5f84f515973eeeecf2e6f02'or md5(pg_get_functiondef('public.save_cto_acquisition_action(uuid,uuid,uuid,date,numeric,text,numeric,text,timestamptz,uuid)'::regprocedure))<>'da041e4a21b27be649034ef2d85435cc'then raise exception'CTO-INITIAL-PREDECESSOR';end if;
end$pre$;
CREATE OR REPLACE FUNCTION public.prepare_cto_acquisition_action(requested_contract uuid, requested_asset uuid, requested_position uuid, requested_date date, requested_quantity numeric, requested_mode text, requested_amount numeric, requested_currency text, expected_position_updated_at timestamp with time zone, requested_request uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare p public.positions;c public.contracts;r private.securities_action_requests;w private.cto_acquisition_fx_preparations;
 submission jsonb;cost numeric;currency text;total numeric;rate public.fx_rates;prior jsonb;claimed boolean:=false;plan jsonb;
begin
 if auth.uid()is null or public.is_authorized_user()is not true then raise exception'Unauthorized'using errcode='42501';end if;
 if requested_request is null or requested_mode is null or requested_mode not in('preserve','redate','total','unit')
 or requested_amount<0 or requested_amount>='1e32'::numeric or requested_amount<>round(requested_amount,28)
 or requested_mode in('preserve','redate')and requested_amount is not null
 or(requested_position is null and(expected_position_updated_at is not null or requested_mode in('preserve','redate')))then raise exception'CTO-ACQUISITION-VALUES'using errcode='22023';end if;
 select * into c from public.contracts where id=requested_contract and user_id=auth.uid()for update;
 if not found or not c.is_active or not exists(select 1 from public.envelope_types where id=c.envelope_type_id and code in('cto','compte_titres'))then raise exception'Unauthorized CTO'using errcode='42501';end if;
 submission:=jsonb_build_object('kind','cto-acquisition-v2','contract',requested_contract,'asset',requested_asset,'position',requested_position,'date',requested_date,'quantity',requested_quantity,'mode',requested_mode,'amount',requested_amount,'currency',requested_currency,'revision',expected_position_updated_at);
 select * into r from private.securities_action_requests where user_id=auth.uid()and request_id=requested_request;
 if found then
  if r.contract_id<>requested_contract or (requested_position is not null and r.result<>requested_position) or r.payload->9 is distinct from submission
  or not exists(select 1 from public.positions where id=r.result and user_id=auth.uid()and metadata#>array['securities_action_requests',requested_request::text]=r.payload)then raise exception'SECURITIES-REPLAY'using errcode='40001';end if;
  return jsonb_build_object('state','committed','result',r.result,'fx',r.payload#>'{11,fx}');
 end if;
 -- A first attachment is prepared without inserting a position. The same parent
 -- lock and duplicate/revision check are repeated at final native commit.
 if requested_position is null then
  perform 1 from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid()for update;
  if found then raise exception'SECURITIES-STALE'using errcode='40001';end if;
 else
 select * into p from public.positions where id=requested_position and contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid()for update;
 if not found or p.updated_at is distinct from expected_position_updated_at then raise exception'SECURITIES-STALE'using errcode='40001';end if;
 end if;
 if exists(select 1 from public.assets a where a.id=p.asset_id and a.asset_type_code='fund'and a.valuation_mode='manual')and exists(select 1 from public.position_snapshots where position_id=p.id and user_id=auth.uid())then raise exception'Legacy amount holding requires a qualified transition'using errcode='23514';end if;
 if requested_mode in('preserve','redate')then
  cost:=p.average_cost_per_unit;currency:=btrim(p.cost_currency_code);total:=cost*requested_quantity;
  if requested_mode='redate'then
   if requested_quantity is distinct from p.quantity then raise exception'Redate cannot change quantity'using errcode='22023';end if;
   select v into prior from jsonb_array_elements(coalesce(p.metadata->'cto_acquisition_inputs','[]'))v
    where(v->>'unitCost')::numeric is not distinct from cost and v->>'currency'=currency and(v->>'quantity')::numeric=requested_quantity order by(v->>'recordedAt')::timestamptz desc limit 1;
   if prior is not null then total:=coalesce((prior->>'nativeTotal')::numeric,case when prior->>'amountType'='total'then(prior->>'amount')::numeric else total end);end if;
  end if;
 else
  currency:=requested_currency;
  if requested_amount is null then cost:=null;total:=null;
  elsif requested_mode='unit'then
   if requested_amount<>round(requested_amount,20)then raise exception'CTO-UNIT-PRECISION'using errcode='22023';end if;
   cost:=requested_amount;total:=cost*requested_quantity;
  elsif requested_quantity=0 then
   if requested_amount<>0 then raise exception'CTO-TOTAL-WITHOUT-QUANTITY'using errcode='22023';end if;cost:=null;total:=0;
  else cost:=round(round(requested_amount,28)/requested_quantity,20);total:=requested_amount;end if;
 end if;
 -- Complete native validation before any external call; no transaction spans HTTP.
 perform public.preview_position_observation(requested_contract,requested_asset,requested_position,requested_request,requested_date,requested_quantity,cost,currency);
 select * into w from private.cto_acquisition_fx_preparations where user_id=auth.uid()and request_id=requested_request for update;
 if found then
  if w.submission is distinct from submission then raise exception'SECURITIES-REPLAY'using errcode='40001';end if;
  if w.state='preparing'and w.deadline<clock_timestamp()then
   -- A lost worker never receives a fresh three-call allowance.
   update private.cto_acquisition_fx_preparations set attempts=3,attempt_log=attempt_log||jsonb_build_array(jsonb_build_object('status','worker_deadline')),claim=gen_random_uuid(),deadline=clock_timestamp()+interval'3 seconds'where user_id=w.user_id and request_id=w.request_id returning * into w;claimed:=true;
  end if;
 else
  if requested_mode='preserve'then plan:=jsonb_build_object('method','preserved');
  elsif total is null then plan:=jsonb_build_object('method','unavailable');
  elsif currency='EUR'then plan:=jsonb_build_object('method','identity','direction','EUR_per_native_unit','eurPerUnit','1');
  elsif total=0 then plan:=jsonb_build_object('method','zero');
  else
   select * into rate from public.fx_rates f where f.currency_code=currency and private.cto_valid_fx(f)
    and(f.requested_on=requested_date or(extract(isodow from requested_date)in(6,7)and f.observed_on=requested_date-(extract(isodow from requested_date)::int-5)))
    and f.observed_on<=requested_date order by f.obtained_at desc,f.created_at desc,f.id desc limit 1;
   if found then plan:=jsonb_build_object('method','historical','direction','EUR_per_native_unit','rate',to_jsonb(rate),'attempts','[]'::jsonb);end if;
  end if;
  insert into private.cto_acquisition_fx_preparations(user_id,request_id,submission,native_values,state,fx_plan)
   values(auth.uid(),requested_request,submission,jsonb_build_object('unitCost',cost::text,'currency',currency,'total',total::text),case when plan is null then'preparing'else'ready'end,plan)returning * into w;claimed:=true;
 end if;
 return jsonb_build_object('state',w.state,'claim',case when claimed then w.claim else null end,'attempts',w.attempts,'currency',currency,'date',requested_date,'fx',w.fx_plan);
end$function$
;

CREATE OR REPLACE FUNCTION public.save_cto_acquisition_action(requested_contract uuid, requested_asset uuid, requested_position uuid, requested_date date, requested_quantity numeric, requested_mode text, requested_amount numeric, requested_currency text, expected_position_updated_at timestamp with time zone, requested_request uuid)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare p public.positions;parent public.contracts;receipt private.securities_action_requests;submission jsonb;payload jsonb;plan jsonb;
 cost numeric;currency text;proof jsonb;prior_inputs jsonb;prep private.cto_acquisition_fx_preparations;native_total numeric;eur_total numeric;eur_unit numeric;stamp timestamptz:=clock_timestamp();saved uuid;
begin
 if auth.uid()is null or public.is_authorized_user()is not true then raise exception'Unauthorized'using errcode='42501';end if;
 if requested_request is null or requested_mode is null or requested_mode not in('preserve','redate','total','unit')
 or requested_amount<0 or requested_amount>=1e32 or requested_amount<>round(requested_amount,28)
 or requested_mode in('preserve','redate')and requested_amount is not null
 or(requested_position is null and(expected_position_updated_at is not null or requested_mode in('preserve','redate')))then raise exception'CTO-ACQUISITION-VALUES'using errcode='22023';end if;
 select * into parent from public.contracts where id=requested_contract and user_id=auth.uid()for update;
 if not found or not parent.is_active or not exists(select 1 from public.envelope_types t where t.id=parent.envelope_type_id and t.code in('cto','compte_titres'))then raise exception'Unauthorized CTO'using errcode='42501';end if;
 submission:=jsonb_build_object('kind','cto-acquisition-v2','contract',requested_contract,'asset',requested_asset,'position',requested_position,'date',requested_date,'quantity',requested_quantity,'mode',requested_mode,'amount',requested_amount,'currency',requested_currency,'revision',expected_position_updated_at);
 select * into receipt from private.securities_action_requests where user_id=auth.uid()and request_id=requested_request;
 if found then
  if receipt.contract_id<>requested_contract or (requested_position is not null and receipt.result<>requested_position) or receipt.payload->9 is distinct from submission
  or not exists(select 1 from public.positions x where x.id=receipt.result and x.user_id=auth.uid()and x.metadata#>array['securities_action_requests',requested_request::text]=receipt.payload)then raise exception'SECURITIES-REPLAY'using errcode='40001';end if;
  return receipt.result;
 end if;
 -- A first attachment is prepared without inserting a position. The same parent
 -- lock and duplicate/revision check are repeated at final native commit.
 if requested_position is null then
  perform 1 from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid()for update;
  if found then raise exception'SECURITIES-STALE'using errcode='40001';end if;
 else
 select * into p from public.positions where id=requested_position and contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid()for update;
 if not found or p.updated_at is distinct from expected_position_updated_at then raise exception'SECURITIES-STALE'using errcode='40001';end if;
 end if;
 if exists(select 1 from public.assets a where a.id=p.asset_id and a.asset_type_code='fund'and a.valuation_mode='manual')and exists(select 1 from public.position_snapshots s where s.position_id=p.id and s.user_id=auth.uid())then raise exception'Legacy amount holding requires a qualified transition'using errcode='23514';end if;
 if requested_mode in('preserve','redate') then cost:=p.average_cost_per_unit;currency:=btrim(p.cost_currency_code);
 else
  currency:=requested_currency;
  if requested_amount is null then cost:=null;
  elsif requested_mode='unit' then
   if requested_amount<>round(requested_amount,20)then raise exception'CTO-UNIT-PRECISION'using errcode='22023';end if;
   cost:=requested_amount;
  elsif requested_quantity=0 then
   if requested_amount<>0 then raise exception'CTO-TOTAL-WITHOUT-QUANTITY'using errcode='22023';end if;
   cost:=null;
  else cost:=round(round(requested_amount,28)/requested_quantity,20);end if;
 end if;
 select * into prep from private.cto_acquisition_fx_preparations where user_id=auth.uid()and request_id=requested_request for update;
 if not found or prep.submission is distinct from submission or prep.state<>'ready'then raise exception'CTO-FX-PREPARATION-REQUIRED'using errcode='40001';end if;
 if (prep.native_values->>'unitCost')::numeric is distinct from cost or prep.native_values->>'currency'is distinct from currency then raise exception'CTO-FX-PREPARATION-DIFFERS'using errcode='40001';end if;
 native_total:=(prep.native_values->>'total')::numeric;
 if prep.fx_plan->>'method'in('identity','zero')then eur_total:=native_total;elsif prep.fx_plan->>'method'in('historical','last_known')then eur_total:=native_total*(prep.fx_plan#>>'{rate,eur_per_unit}')::numeric;end if;
 eur_unit:=case when requested_quantity>0 then round(round(eur_total,60)/requested_quantity,40)else null end;
 prior_inputs:=coalesce(p.metadata->'cto_acquisition_inputs','[]');
 if requested_mode<>'preserve'then
  proof:=jsonb_build_object('version',2,'requestId',requested_request,'effectiveOn',requested_date,'quantity',requested_quantity::text,
   'amountType',requested_mode,'amount',requested_amount::text,'unitCost',cost::text,'currency',currency,'recordedAt',stamp,
   'nativeTotal',native_total::text,'totalEur',eur_total::text,'unitEur',eur_unit::text,'fx',prep.fx_plan,'calculation','native total × EUR per native unit; unit EUR divided by quantity, 40 decimals','provenance','Estimation figée à la date choisie par l’utilisateur ; valorisation de marché indépendante');
 end if;
 payload:=jsonb_build_array('position',requested_contract,requested_asset,requested_position,null,requested_date,requested_quantity,cost,currency,submission,prior_inputs,proof);
 perform public.lock_position_capture_sources();
 plan:=public.preview_position_observation(requested_contract,requested_asset,requested_position,requested_request,requested_date,requested_quantity,cost,currency);
 saved:=public.save_position_observation(requested_contract,requested_asset,requested_position,requested_request,requested_date,requested_quantity,cost,currency,plan->>'token');
 insert into private.securities_action_requests(user_id,contract_id,request_id,payload,result)values(auth.uid(),requested_contract,requested_request,payload,saved);
 update public.positions set metadata=metadata||jsonb_build_object('securities_action_requests',coalesce(metadata->'securities_action_requests','{}')||jsonb_build_object(requested_request::text,payload))
  ||case when proof is null then '{}'::jsonb else jsonb_build_object('cto_acquisition_inputs',prior_inputs||jsonb_build_array(proof))end where id=saved and user_id=auth.uid();
 delete from private.cto_acquisition_fx_preparations where user_id=auth.uid()and request_id=requested_request;
 return saved;
end$function$
;

do $post$begin if private.app_backup_schema()<>'2c0097879ab93eaae871f815ac30e440110c772f1da42916e186b1e2bb77e73e'then raise exception'CTO-INITIAL-SCHEMA';end if;end$post$;
commit;
