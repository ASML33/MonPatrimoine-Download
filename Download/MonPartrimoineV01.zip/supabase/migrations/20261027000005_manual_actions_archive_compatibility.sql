-- Exact /3 predecessor frontier for the A1-A4 + automatic-fund candidate.
-- Columns and archived cells are unchanged; only the SQL schema seal changes.
-- No archive, application row, restore permit or privilege is written here.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';


-- The archived PostgreSQL signature includes the literal text of trigger functions.
-- A clean LF replay yields a different seal from the historical CRLF deployment.
-- Translate only this exact predecessor to the original seal before checking it.
do $replay$
declare
 entry record;
 original text;
 historical text;
begin
 if private.app_backup_schema() is distinct from 'c88a0034700cb9289bfb6c1da237183a7d3ed8936fabd8b86554ea393c5b3e91'
 then return; end if;
 for entry in select * from (values
    ('public.check_exposure_trigger()', '3f46c952321087c2a3ea2cfdae91c92d', 'fc37daab4a89a7d546ba387a32e4ba52', array[5, 6]),
    ('private.guard_exposure_version()', '24abba6a485d579982ca8429c0ca25cf', '4045451623433c7086945b37b5019a7b', array[4, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]),
    ('public.validate_asset_price_access()', '989d751c4590fa6cfc3d1065bf4208e0', '0cfc84799272f4db406f1a3aeb1466ac', array[4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]),
    ('public.record_asset_use()', 'd8538e092439974c3634b877b4647d6f', '23472fbcce758eae7817758654407990', array[5, 6, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]),
    ('public.enforce_sector_total()', '194eea1b107ad7771a664990a48d64e8', '951d8c9e7243a59c822ef84c87f45dc1', array[5]),
    ('public.set_updated_at()', 'd21279a0969204d51748a427e67dd6c7', '3bd23512ffabe3f955f99ed80151f77d', array[4, 7, 8, 9, 10]),
    ('public.guard_asset_lifecycle()', '160fe20ee4b586f25dc5a718fbc2c12b', '3189ce5e9bfeaed36c4f9d3945c40c31', array[5, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]),
    ('private.guard_property_asset_mode()', 'e2ab7e0cdfe9958fe7f6423460b29496', '006f3f50f6c9834eabceaa42ba0b3cbd', array[5, 6]),
    ('public.normalize_entity_color()', '044bbba552ea41789e97fca3a0c3a52d', '54b1f54ef878af131aee8b1b1d5ede83', array[4, 5]),
    ('public.guard_dated_cash_balance_observations()', 'b4dfc8353ff3cf0c4cbe06e0f8aed8b9', '551606a703be43b222d8abc9514f8610', array[4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80]),
    ('private.guard_property_rows()', '51a7204e34caaf5905bfb2a5be40b8a3', 'f38da4fd6e37bb9a28c467b34959f1e9', array[5, 6, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21]),
    ('public.validate_asset_access()', 'bdfca8c750fe5269a08caf231cb7d62c', '970a9ea36b7dbf43a2e8161b51c7718a', array[4, 5, 6, 7, 8, 9, 10, 11, 12, 13]),
    ('public.guard_activity_parent()', '26998db7282ed53ab40332b90c7cdda9', 'bce1586ce887febe0f33f2712115fba0', array[4, 5])
 ) as source(signature, clean_hash, historical_hash, cr_offsets)
 loop
  original:=pg_get_functiondef(entry.signature::regprocedure);
  if md5(original) is distinct from entry.clean_hash
  then raise exception 'Unexpected clean replay definition for %', entry.signature; end if;
  select string_agg(line || case when ordinality - 1 = any(entry.cr_offsets) then chr(13) else '' end, chr(10) order by ordinality)
  into historical from unnest(string_to_array(original, chr(10))) with ordinality as lines(line, ordinality);
  if md5(historical) is distinct from entry.historical_hash
  then raise exception 'Unexpected historical replay definition for %', entry.signature; end if;
  execute historical;
 end loop;
end $replay$;

do $patch$
declare original text; needle text:=
 'if doc->>''format''=''monpatrimoine-app-backup/3'' then perform private.app_backup_validate(doc);return doc;end if;';
begin
 -- Obtained by replaying the five unchanged migrations on the exact live
 -- predecessor definitions. A different installation must be reviewed again.
 if private.app_backup_schema()<>'77258048d2a433ddaf6cba7acc8c3a2890bf5c3ca3280f842d0f057c06e4c740'
 then raise exception 'Unexpected manual-actions archive frontier';end if;
 original:=pg_get_functiondef('private.app_backup_upgrade(jsonb)'::regprocedure);
 if (length(original)-length(replace(original,needle,'')))/length(needle)<>1
 then raise exception 'Unexpected archive upgrade prerequisite';end if;
 execute replace(original,needle,$upgrade$
 if doc->>'format'='monpatrimoine-app-backup/3' then
  if doc->>'schema' is distinct from private.app_backup_schema() then
   -- No wildcard, unconditional restamping or intermediate candidate schemas.
   if doc->>'schema' is distinct from '3ca73f81c329737a9939a5ce041e43e8846fac1da23b433f0f2618fbe18b46fd'
   then raise exception 'Unsupported archive schema version';end if;
   doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));
  end if;
  -- Owner, exact datasets/columns, cells, native casts and ownership remain
  -- checked against the installed target. No monetary history is transformed.
  perform private.app_backup_validate(doc);return doc;
 end if;
 $upgrade$);
end $patch$;
-- The existing /1 and /2 frontiers, reader, format, ACLs and SQL replacement
-- checks stay intact. This helper itself is not part of the schema seal.
notify pgrst,'reload schema';
commit;
