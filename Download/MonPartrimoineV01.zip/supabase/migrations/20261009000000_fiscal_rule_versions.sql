-- Versioned fiscal regimes and rules used by the liquidation estimate.
-- Existing fiscal_rules rows are preserved; new executable versions are append-only.
begin;

create table public.fiscal_regimes (
  id uuid primary key,
  code text not null unique check (code ~ '^[a-z0-9_-]{1,60}$'),
  envelope_type_id uuid not null references public.envelope_types(id) on delete restrict on update cascade,
  label text not null unique check (char_length(btrim(label)) between 1 and 160),
  description text not null check (char_length(btrim(description)) > 0),
  calculation_kind text not null check (calculation_kind in ('exempt','pea_liquidation','cto_liquidation','interest_gain','unsupported')),
  status text not null check (status in ('verified','limited','pending_verification','unsupported')),
  is_active boolean not null default true,
  created_at timestamptz not null default timezone('utc',now()),
  updated_at timestamptz not null default timezone('utc',now())
);
create trigger fiscal_regimes_set_updated_at before update on public.fiscal_regimes
  for each row execute function public.set_updated_at();

insert into public.fiscal_regimes(id,code,envelope_type_id,label,description,calculation_kind,status) values
 ('81000000-0000-0000-0000-000000000001','pea_standard','71000000-0000-0000-0000-000000000001','PEA — régime standard','Estimation d’une liquidation du PEA selon son ancienneté.','pea_liquidation','limited'),
 ('81000000-0000-0000-0000-000000000002','cto_pfu','71000000-0000-0000-0000-000000000002','CTO — PFU par défaut','Simulation fiscale des plus-values latentes des positions restantes, hors option globale au barème.','cto_liquidation','limited'),
 ('81000000-0000-0000-0000-000000000003','assurance_vie','71000000-0000-0000-0000-000000000003','Assurance-vie','Régime nécessitant les générations de versements, les seuils globaux et l’abattement annuel du foyer.','unsupported','unsupported'),
 ('81000000-0000-0000-0000-000000000004','livret_a','71000000-0000-0000-0000-000000000004','Livret A','Intérêts exonérés d’impôt sur le revenu et de prélèvements sociaux.','exempt','verified'),
 ('81000000-0000-0000-0000-000000000005','ldds','71000000-0000-0000-0000-000000000004','LDDS','Intérêts exonérés d’impôt sur le revenu et de prélèvements sociaux.','exempt','verified'),
 ('81000000-0000-0000-0000-000000000006','livret_fiscalise','71000000-0000-0000-0000-000000000004','Livret fiscalisé','Régime sur les intérêts ; une base d’intérêts fiable reste nécessaire.','interest_gain','limited'),
 ('81000000-0000-0000-0000-000000000007','per','71000000-0000-0000-0000-000000000006','PER','Les compartiments versements déduits, non déduits et épargne salariale doivent être distingués.','unsupported','unsupported'),
 ('81000000-0000-0000-0000-000000000008','pel_cel_pending','71000000-0000-0000-0000-000000000004','PEL / CEL — règle à vérifier','Aucune règle exécutable tant que les paramètres officiels applicables au contrat ne sont pas établis sans ambiguïté.','unsupported','pending_verification');

alter table public.fiscal_rules
  add column fiscal_regime_id uuid references public.fiscal_regimes(id) on delete restrict on update cascade,
  add column owner_user_id uuid references auth.users(id) on delete cascade,
  add column version_number integer check (version_number is null or version_number > 0),
  add column age_threshold_months integer check (age_threshold_months is null or age_threshold_months >= 0),
  add column ir_rate_before numeric check (ir_rate_before is null or ir_rate_before between 0 and 1),
  add column ir_rate_after numeric check (ir_rate_after is null or ir_rate_after between 0 and 1),
  add column ps_rate_before numeric check (ps_rate_before is null or ps_rate_before between 0 and 1),
  add column ps_rate_after numeric check (ps_rate_after is null or ps_rate_after between 0 and 1),
  add column ir_base_type text check (ir_base_type is null or ir_base_type in ('none','positive_unrealized_gain','positive_plan_gain','positive_interest_gain','gross')),
  add column ps_base_type text check (ps_base_type is null or ps_base_type in ('none','positive_unrealized_gain','positive_plan_gain','positive_interest_gain','gross')),
  add column ir_allowance_amount numeric check (ir_allowance_amount is null or ir_allowance_amount >= 0),
  add column ir_allowance_scope text check (ir_allowance_scope is null or ir_allowance_scope in ('contract','household_annual')),
  add column parameters jsonb not null default '{}'::jsonb check (jsonb_typeof(parameters)='object'),
  add column source_title text,
  add column verified_on date,
  add column status text check (status is null or status in ('draft','verified','retired')),
  add column created_by uuid references auth.users(id) on delete set null,
  add column supersedes_id uuid references public.fiscal_rules(id) on delete restrict;

alter table public.fiscal_rules add constraint fiscal_rules_version_shape_check check (
  fiscal_regime_id is null or (
    version_number is not null
    and ir_rate_before is not null
    and ps_rate_before is not null
    and ir_base_type is not null
    and ps_base_type is not null
    and status is not null
    and source_title is not null and btrim(source_title) <> ''
    and verified_on is not null
    and source ~ '^https://'
    and description is not null and btrim(description) <> ''
    and (age_threshold_months is null or (ir_rate_after is not null and ps_rate_after is not null))
    and ((ir_allowance_amount is null and ir_allowance_scope is null)
      or (ir_allowance_amount is not null and ir_allowance_scope is not null))
  )
);

create unique index fiscal_rules_common_version_unique_idx
  on public.fiscal_rules(fiscal_regime_id,version_number) where fiscal_regime_id is not null and owner_user_id is null;
create unique index fiscal_rules_personal_version_unique_idx
  on public.fiscal_rules(fiscal_regime_id,owner_user_id,version_number) where fiscal_regime_id is not null and owner_user_id is not null;
create index fiscal_rules_effective_lookup_idx
  on public.fiscal_rules(fiscal_regime_id,owner_user_id,valid_from desc) where fiscal_regime_id is not null and active;

insert into public.fiscal_rules(
 id,env,rule_code,rule_name,min_years,tax_rate,social_rate,valid_from,description,source,active,
 fiscal_regime_id,version_number,age_threshold_months,ir_rate_before,ir_rate_after,ps_rate_before,ps_rate_after,
 ir_base_type,ps_base_type,source_title,verified_on,status
) values
 ('82000000-0000-0000-0000-000000000001','fr','pea_standard_2026','PEA — régime standard 2026',0,0.128,0.186,'2026-01-01','IR avant cinq ans ; exonération IR à partir de cinq ans. Les PS restent dus.','https://www.impots.gouv.fr/particulier/questions/jai-un-plan-depargne-en-actions-pea-les-retraits-sont-ils-imposables',true,'81000000-0000-0000-0000-000000000001',1,60,0.128,0,0.186,0.186,'positive_plan_gain','positive_plan_gain','impots.gouv.fr — fiscalité des retraits du PEA','2026-10-05','verified'),
 ('82000000-0000-0000-0000-000000000002','fr','cto_pfu_2026','CTO — PFU par défaut 2026',0,0.128,0.186,'2026-01-01','Simulation de liquidation des positions restantes au PFU, distincte des revenus et cessions déjà réalisés.','https://www.impots.gouv.fr/particulier/les-cessions-mobilieres',true,'81000000-0000-0000-0000-000000000002',1,null,0.128,null,0.186,null,'positive_unrealized_gain','positive_unrealized_gain','impots.gouv.fr — cessions mobilières','2026-10-05','verified'),
 ('82000000-0000-0000-0000-000000000003','fr','livret_a_exempt','Livret A — exonération',0,0,0,'2026-01-01','Intérêts exonérés d’IR et de PS.','https://www.service-public.fr/particuliers/vosdroits/F2365',true,'81000000-0000-0000-0000-000000000004',1,null,0,null,0,null,'none','none','Service-Public.fr — Livret A','2026-10-05','verified'),
 ('82000000-0000-0000-0000-000000000004','fr','ldds_exempt','LDDS — exonération',0,0,0,'2026-01-01','Intérêts exonérés d’IR et de PS.','https://www.economie.gouv.fr/particuliers/gerer-mon-argent/gerer-mon-budget-et-mon-epargne/livret-de-developpement-durable-et-solidaire-ldds-comment-ca-marche',true,'81000000-0000-0000-0000-000000000005',1,null,0,null,0,null,'none','none','economie.gouv.fr — LDDS','2026-10-05','verified');

create table public.user_fiscal_regime_preferences (
  user_id uuid not null references auth.users(id) on delete cascade,
  fiscal_regime_id uuid not null references public.fiscal_regimes(id) on delete cascade,
  use_personal_rule boolean not null default false,
  updated_at timestamptz not null default timezone('utc',now()),
  primary key(user_id,fiscal_regime_id)
);
create trigger user_fiscal_regime_preferences_set_updated_at before update on public.user_fiscal_regime_preferences
  for each row execute function public.set_updated_at();

alter table public.contracts
  add column fiscal_regime_id uuid references public.fiscal_regimes(id) on delete restrict on update cascade,
  add column fiscal_started_on date,
  add column fiscal_history_complete boolean not null default false,
  add column social_contributions_paid_eur numeric check (social_contributions_paid_eur is null or social_contributions_paid_eur >= 0);

-- PEA is the only existing envelope type whose initial regime is unambiguous.
update public.contracts set fiscal_regime_id='81000000-0000-0000-0000-000000000001'
 where envelope_type_id='71000000-0000-0000-0000-000000000001';

create function public.validate_contract_fiscal_regime()
returns trigger language plpgsql security definer set search_path='' as $$
begin
  if new.fiscal_regime_id is not null and not exists(
    select 1 from public.fiscal_regimes r
    where r.id=new.fiscal_regime_id and r.envelope_type_id=new.envelope_type_id and r.is_active
  ) then raise exception 'Fiscal regime is incompatible or unavailable' using errcode='23514'; end if;
  if new.fiscal_started_on is not null and new.fiscal_started_on > coalesce(new.closed_on,current_date) then
    raise exception 'Fiscal start date is inconsistent' using errcode='23514';
  end if;
  return new;
end;
$$;
create trigger contracts_25_fiscal_regime before insert or update of envelope_type_id,fiscal_regime_id,fiscal_started_on,closed_on
  on public.contracts for each row execute function public.validate_contract_fiscal_regime();
revoke all on function public.validate_contract_fiscal_regime() from public,anon,authenticated;

create function public.guard_fiscal_rule_history()
returns trigger language plpgsql security definer set search_path='' as $$
begin
  if old.fiscal_regime_id is not null then
    raise exception 'Fiscal rule history is append-only' using errcode='23514';
  end if;
  return case when tg_op='DELETE' then old else new end;
end;
$$;
create trigger fiscal_rules_append_only before update or delete on public.fiscal_rules
  for each row execute function public.guard_fiscal_rule_history();
revoke all on function public.guard_fiscal_rule_history() from public,anon,authenticated;

alter table public.fiscal_regimes enable row level security;
alter table public.fiscal_regimes force row level security;
alter table public.user_fiscal_regime_preferences enable row level security;
alter table public.user_fiscal_regime_preferences force row level security;

drop policy if exists principal_read on public.fiscal_rules;
drop policy if exists principal_insert on public.fiscal_rules;
drop policy if exists principal_update on public.fiscal_rules;
drop policy if exists fiscal_rules_read_authenticated on public.fiscal_rules;
drop policy if exists fiscal_rules_admin_insert on public.fiscal_rules;
drop policy if exists fiscal_rules_admin_update on public.fiscal_rules;
create policy principal_fiscal_rules_read on public.fiscal_rules for select to authenticated
  using(public.is_authorized_user() and (owner_user_id is null or owner_user_id=auth.uid()));
create policy principal_fiscal_regimes_read on public.fiscal_regimes for select to authenticated
  using(public.is_authorized_user());
create policy principal_fiscal_preferences on public.user_fiscal_regime_preferences for select to authenticated
  using(public.is_authorized_user() and user_id=auth.uid());

revoke all on public.fiscal_regimes,public.user_fiscal_regime_preferences from public,anon,authenticated;
grant select on public.fiscal_regimes,public.fiscal_rules,public.user_fiscal_regime_preferences to authenticated;
revoke insert,update,delete on public.fiscal_rules from authenticated;

create function public.create_fiscal_rule_version(
  requested_regime_id uuid, requested_scope text, requested_valid_from date,
  requested_age_threshold_months integer, requested_ir_rate_before numeric, requested_ir_rate_after numeric,
  requested_ps_rate_before numeric, requested_ps_rate_after numeric,
  requested_ir_base_type text, requested_ps_base_type text,
  requested_ir_allowance_amount numeric, requested_ir_allowance_scope text,
  requested_parameters jsonb, requested_description text, requested_source text,
  requested_source_title text, requested_verified_on date
) returns uuid language plpgsql security definer set search_path='' as $$
declare owner_id uuid; next_version integer; previous_id uuid; result uuid; regime record;
begin
  if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501'; end if;
  if requested_scope not in ('common','personal') then raise exception 'Invalid fiscal scope' using errcode='22023'; end if;
  -- In the active mono-user architecture, the verified application principal is
  -- also the only catalog administrator. The obsolete workspace role is not used.
  owner_id:=case when requested_scope='personal' then auth.uid() end;
  select * into regime from public.fiscal_regimes where id=requested_regime_id and is_active for share;
  if not found then raise exception 'Fiscal regime unavailable' using errcode='42501'; end if;
  if requested_valid_from is null or requested_verified_on is null or requested_verified_on > current_date
     or btrim(coalesce(requested_source,'')) !~ '^https://'
     or btrim(coalesce(requested_source_title,''))='' or btrim(coalesce(requested_description,''))='' then
    raise exception 'Fiscal rule source and dates are required' using errcode='22023';
  end if;
  if requested_ir_base_type not in ('none','positive_unrealized_gain','positive_plan_gain','positive_interest_gain','gross')
     or requested_ps_base_type not in ('none','positive_unrealized_gain','positive_plan_gain','positive_interest_gain','gross') then
    raise exception 'Invalid fiscal base' using errcode='22023';
  end if;
  if requested_ir_rate_before is null or requested_ps_rate_before is null
     or (requested_age_threshold_months is not null and (requested_ir_rate_after is null or requested_ps_rate_after is null))
     or ((requested_ir_allowance_amount is null) <> (requested_ir_allowance_scope is null)) then
    raise exception 'Incomplete fiscal rule parameters' using errcode='22023';
  end if;
  perform pg_advisory_xact_lock(hashtextextended(requested_regime_id::text||coalesce(owner_id::text,'common'),0));
  select id,version_number into previous_id,next_version from public.fiscal_rules
    where fiscal_regime_id=requested_regime_id and owner_user_id is not distinct from owner_id
    order by version_number desc limit 1;
  next_version:=coalesce(next_version,0)+1;
  insert into public.fiscal_rules(
    env,rule_code,rule_name,min_years,tax_rate,social_rate,valid_from,description,source,active,
    fiscal_regime_id,owner_user_id,version_number,age_threshold_months,
    ir_rate_before,ir_rate_after,ps_rate_before,ps_rate_after,ir_base_type,ps_base_type,
    ir_allowance_amount,ir_allowance_scope,parameters,source_title,verified_on,status,created_by,supersedes_id
  ) values(
    'fr',regime.code||'_'||requested_scope||'_'||coalesce(left(owner_id::text,8),'catalog')||'_v'||next_version,regime.label||' — version '||next_version,0,
    requested_ir_rate_before,requested_ps_rate_before,requested_valid_from,btrim(requested_description),btrim(requested_source),true,
    requested_regime_id,owner_id,next_version,requested_age_threshold_months,
    requested_ir_rate_before,requested_ir_rate_after,requested_ps_rate_before,requested_ps_rate_after,
    requested_ir_base_type,requested_ps_base_type,requested_ir_allowance_amount,requested_ir_allowance_scope,
    coalesce(requested_parameters,'{}'::jsonb),btrim(requested_source_title),requested_verified_on,'verified',auth.uid(),previous_id
  ) returning id into result;
  if owner_id is not null then
    insert into public.user_fiscal_regime_preferences(user_id,fiscal_regime_id,use_personal_rule)
      values(owner_id,requested_regime_id,true)
      on conflict(user_id,fiscal_regime_id) do update set use_personal_rule=true;
  end if;
  return result;
end;
$$;
revoke all on function public.create_fiscal_rule_version(uuid,text,date,integer,numeric,numeric,numeric,numeric,text,text,numeric,text,jsonb,text,text,text,date) from public,anon;
grant execute on function public.create_fiscal_rule_version(uuid,text,date,integer,numeric,numeric,numeric,numeric,text,text,numeric,text,jsonb,text,text,text,date) to authenticated;

create function public.set_fiscal_rule_preference(requested_regime_id uuid,requested_use_personal boolean)
returns void language plpgsql security definer set search_path='' as $$
begin
  if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501'; end if;
  if requested_use_personal and not exists(select 1 from public.fiscal_rules where fiscal_regime_id=requested_regime_id and owner_user_id=auth.uid() and active and status='verified') then
    raise exception 'No personal fiscal rule is available' using errcode='23514';
  end if;
  insert into public.user_fiscal_regime_preferences(user_id,fiscal_regime_id,use_personal_rule)
    values(auth.uid(),requested_regime_id,requested_use_personal)
    on conflict(user_id,fiscal_regime_id) do update set use_personal_rule=excluded.use_personal_rule;
end;
$$;
revoke all on function public.set_fiscal_rule_preference(uuid,boolean) from public,anon;
grant execute on function public.set_fiscal_rule_preference(uuid,boolean) to authenticated;

commit;
