-- LOCAL CANDIDATE ONLY. Exact broker repair; no business data changed by installation.
begin;set local lock_timeout='5s';set local statement_timeout='40s';
do $p$begin if private.app_backup_schema()<>'7b8d63de5bc463697251a1c84a5ab7a2d34723fd9b0b94c0654c313d8b5a34f1'then raise exception'CTO-BROKER-PREDECESSOR';end if;if md5(pg_get_functiondef('public.guard_position_observations()'::regprocedure))<>'8aeedfcdcd0044b48604e4c3ae17cc0f'then raise exception'CTO-BROKER-DEFINITION';end if;if md5(pg_get_functiondef('public.preview_position_observation(uuid,uuid,uuid,uuid,date,numeric,numeric,text)'::regprocedure))<>'45a3f0e199628234acadc55d2df103a3'then raise exception'CTO-BROKER-DEFINITION';end if;if md5(pg_get_functiondef('public.mutate_securities_cash_action(uuid,uuid,text,text,uuid,jsonb,timestamp with time zone,jsonb)'::regprocedure))<>'0fae021be10603ed921b019ebdc432a9'then raise exception'CTO-BROKER-DEFINITION';end if;if md5(pg_get_functiondef('public.save_securities_position_action(uuid,uuid,uuid,uuid,date,numeric,numeric,text,timestamp with time zone,uuid)'::regprocedure))<>'444eff02fb442f88bbba4194dc2563d8'then raise exception'CTO-BROKER-DEFINITION';end if;if md5(pg_get_functiondef('private.app_backup_upgrade(jsonb)'::regprocedure))<>'75bd493fed87c200200ac7137f48f4e4'then raise exception'CTO-BROKER-DEFINITION';end if;if md5(pg_get_functiondef('public.guard_dated_cash_balance_observations()'::regprocedure))<>'c9a64d762a88d09e9bc0d2b25382324f'then raise exception'CTO-BROKER-DEFINITION';end if;end$p$;
alter table public.cash_balances alter column amount type numeric;alter table public.positions alter column average_cost_per_unit type numeric;

create table private.cto_broker_repair_permits(tx bigint not null,backend int not null,owner uuid not null,contract_id uuid not null,request_id uuid not null,plan jsonb not null,primary key(tx,backend,owner,contract_id));
alter table private.cto_broker_repair_permits enable row level security;alter table private.cto_broker_repair_permits force row level security;revoke all on private.cto_broker_repair_permits from public,anon,authenticated,service_role;
create function public.cto_broker_cost_precision(cid uuid,aid uuid,day date,cost numeric,currency text)returns boolean language sql stable security definer set search_path=''as $h$
 select auth.uid()is not null and currency='USD'and cost>=0 and cost<1e16 and cost=round(cost,20)and exists(select 1 from public.positions p join public.contracts c on c.id=p.contract_id join public.envelope_types e on e.id=c.envelope_type_id where p.contract_id=cid and p.asset_id=aid and p.user_id=auth.uid()and c.user_id=auth.uid()and e.code='cto'and(
 exists(select 1 from private.cto_broker_repair_permits permit cross join lateral jsonb_array_elements(permit.plan->'positions')r where permit.tx=txid_current()and permit.backend=pg_backend_pid()and permit.owner=auth.uid()and permit.contract_id=cid and r->>'assetId'=aid::text and (r->>'unitCostUsd')::numeric=cost and permit.plan->>'date'=day::text)
 or(p.metadata#>>'{cto_broker_basis,version}'='1'and p.metadata#>>'{cto_broker_basis,effectiveOn}'<=day::text and p.metadata#>>'{cto_broker_basis,method}'='dated_official_reference_fx_estimate'and(p.metadata#>>'{cto_broker_basis,unitCostUsd}')::numeric=cost)));
$h$;revoke all on function public.cto_broker_cost_precision(uuid,uuid,date,numeric,text)from public,anon;grant execute on function public.cto_broker_cost_precision(uuid,uuid,date,numeric,text)to authenticated;
create function private.cto_broker_cash_precision(cid uuid,currency text,day date,amount numeric)returns boolean language sql stable security definer set search_path=''as $h$
 select currency='EUR'and amount>=0 and amount=round(amount,12)and exists(select 1 from private.cto_broker_repair_permits p where p.tx=txid_current()and p.backend=pg_backend_pid()and p.owner=auth.uid()and p.contract_id=cid and p.plan#>>'{cash,date}'=day::text and(p.plan#>>'{cash,amount}')::numeric=amount);
$h$;revoke all on function private.cto_broker_cash_precision(uuid,text,date,numeric)from public,anon,authenticated,service_role;
create function public.guard_cto_broker_basis()returns trigger language plpgsql security definer set search_path=''as $g$
begin
 if public.app_restore_permitted(tg_relid,tg_op,case when tg_op='INSERT'then null else to_jsonb(old)end,to_jsonb(new))then return new;end if;
 if new.metadata->'cto_broker_basis'is not distinct from(case when tg_op='UPDATE'then old.metadata->'cto_broker_basis'end)then return new;end if;
 if not exists(select 1 from private.cto_broker_repair_permits p cross join lateral jsonb_array_elements(p.plan->'positions')r where p.tx=txid_current()and p.backend=pg_backend_pid()and p.owner=new.user_id and p.contract_id=new.contract_id and r->>'assetId'=new.asset_id::text and r->'basis'=new.metadata->'cto_broker_basis'and(new.quantity,new.average_cost_per_unit,btrim(new.cost_currency_code))=((r->>'quantity')::numeric,(r->>'unitCostUsd')::numeric,'USD'))then raise exception'CTO-BROKER-PROOF-IMMUTABLE'using errcode='23514';end if;return new;
end$g$;revoke all on function public.guard_cto_broker_basis()from public,anon,authenticated,service_role;create trigger positions_broker_basis_guard before insert or update on public.positions for each row execute function public.guard_cto_broker_basis();
create function private.cto_broker_repair_must_finish()returns trigger language plpgsql set search_path=''as $g$begin if exists(select 1 from private.cto_broker_repair_permits p where p.tx=new.tx and p.backend=new.backend and p.owner=new.owner and p.contract_id=new.contract_id)then raise exception'CTO-BROKER-INCOMPLETE'using errcode='23514';end if;return null;end$g$;
create constraint trigger cto_broker_repair_complete after insert on private.cto_broker_repair_permits deferrable initially deferred for each row execute function private.cto_broker_repair_must_finish();revoke all on function private.cto_broker_repair_must_finish()from public,anon,authenticated,service_role;

CREATE OR REPLACE FUNCTION public.guard_position_observations()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare h jsonb; prior jsonb; e jsonb; latest jsonb; seen date[]:='{}'; ids text[]:='{}'; d date; needed jsonb; b jsonb; receipt jsonb; verified jsonb; correction text;
begin
 if public.app_restore_permitted(tg_relid,tg_op,case when tg_op='INSERT' then null else to_jsonb(old) end,case when tg_op='DELETE' then null else to_jsonb(new) end) then if tg_op='DELETE' then return old;else return new;end if;end if;

 if tg_op<>'DELETE' and private.property_permitted('position',case when tg_op='UPDATE' then to_jsonb(old) else null end,to_jsonb(new)) then return new;end if;
 
 if tg_op='DELETE' and auth.uid()=old.user_id and public.is_authorized_user()
  and old.metadata=jsonb_build_object('initial_amount',jsonb_build_object('version',1,'kind','empty_euro_fund'))
  and old.quantity is null and old.average_cost_per_unit is null and old.opened_on is null
  and not exists(select 1 from public.contracts where id=old.contract_id)
  and not exists(select 1 from public.position_snapshots where position_id=old.id)
 then return old;end if;
 if tg_op='DELETE' and old.metadata ? 'initial_amount' then raise exception 'Monetary proof must be reconciled, not deleted' using errcode='23514';end if; if tg_op='DELETE' then if old.metadata ? 'position_observations' then raise exception 'Dated holding must be closed with zero' using errcode='23514';end if;return old;end if;

 if tg_op='INSERT' and new.metadata ? 'initial_amount' then
  -- Already fully validated by positions_00_amount_validation, before the
  -- ordinary parent-use triggers. Those triggers and owner RLS still apply.
  return new;
 end if;
 if tg_op='UPDATE' and new.metadata->'initial_amount' is distinct from old.metadata->'initial_amount' then
  raise exception 'Initial monetary provenance is immutable' using errcode='23514';end if;
 h:=new.metadata->'position_observations';
 if tg_op='UPDATE' then
  if (new.id,new.user_id,new.contract_id,new.asset_id) is distinct from (old.id,old.user_id,old.contract_id,old.asset_id) then raise exception 'Position identity is immutable' using errcode='23514';end if;
  prior:=old.metadata->'position_observations';
  if prior is not null and not new.is_active then raise exception 'Close dated holding with zero, keeping its identity' using errcode='23514';end if;
  if h is not distinct from prior and (new.quantity,new.average_cost_per_unit,new.cost_currency_code) is not distinct from (old.quantity,old.average_cost_per_unit,old.cost_currency_code) then return new;end if;
 end if;
 if h is null or h->>'version' is distinct from '1' or jsonb_typeof(h->'entries') is distinct from 'array' or jsonb_typeof(h->'archived') is distinct from 'array' or jsonb_typeof(h->'bindings') is distinct from 'array' or jsonb_typeof(h->'receipts') is distinct from 'array' or jsonb_array_length(h->'entries')=0 then raise exception 'Dated observation required' using errcode='23514';end if;
 -- Verify the complete canonical preview even for direct table writes. No caller
 -- supplied flag, schema privilege or bypass of the existing owner RLS is used.
 perform 1 from public.contracts where id=new.contract_id and user_id=auth.uid() for update;
 perform public.lock_position_capture_sources();
 receipt:=h#>'{receipts,-1}'; correction:=receipt->>'id';
 perform correction::uuid;
 if correction is null or jsonb_typeof(receipt->'request') is distinct from 'array' or jsonb_array_length(receipt->'request')<>7
  or (h->'receipts')-(jsonb_array_length(h->'receipts')-1) is distinct from coalesce(prior->'receipts','[]') then raise exception 'Confirmation trace required' using errcode='23514';end if;
 if receipt#>>'{request,0}' is distinct from new.contract_id::text or receipt#>>'{request,1}' is distinct from new.asset_id::text then raise exception 'Confirmation identity differs' using errcode='23514';end if;
 verified:=public.preview_position_observation(new.contract_id,new.asset_id,case when tg_op='UPDATE' then old.id else null end,
  (receipt#>>'{request,2}')::uuid,(receipt#>>'{request,3}')::date,(receipt#>>'{request,4}')::numeric,(receipt#>>'{request,5}')::numeric,receipt#>>'{request,6}');
 select coalesce(jsonb_agg(case when v->>'id'=receipt#>>'{request,2}' then v||jsonb_build_object('recordedAt',(select n->'recordedAt' from jsonb_array_elements(h->'entries') n where n->>'id'=v->>'id')) else v end order by ord),'[]') into e from jsonb_array_elements(verified->'nextEntries') with ordinality t(v,ord);
 verified:=verified||jsonb_build_object('nextEntries',e);
 if h#>'{archived,-1,undatedPrevious}' is distinct from (case when tg_op='UPDATE' and prior is null then jsonb_build_object('quantity',old.quantity::text,'unitCost',case when old.average_cost_per_unit is null then null else old.average_cost_per_unit::text end,'currency',old.cost_currency_code,'isActive',old.is_active) else 'null'::jsonb end) then raise exception 'Undated previous situation must be preserved without inventing a date' using errcode='23514';end if;
 if (h#>>'{archived,-1,replacedAt}')::timestamptz<statement_timestamp() or (h#>>'{archived,-1,replacedAt}')::timestamptz>clock_timestamp() then raise exception 'Invalid correction timestamp' using errcode='23514';end if;
 if verified->>'token' is distinct from receipt->>'token' or verified->'nextEntries' is distinct from h->'entries'
  or verified->'review' is distinct from h->'lastReview' or h#>>'{archived,-1,correctionId}' is distinct from correction
  or h#>>'{archived,-1,replacedAt}' is null then raise exception 'Observation differs from confirmed preview' using errcode='40001';end if;
 for e in select value from jsonb_array_elements(h->'entries') loop
  d:=(e->>'effectiveOn')::date;
  if d is null or e->>'id' is null or jsonb_typeof(e->'quantity') is distinct from 'string' or not (e ? 'unitCost') or jsonb_typeof(e->'unitCost') not in ('string','null') or e->>'version' is null or d=any(seen) or e->>'id'=any(ids) or d>(clock_timestamp() at time zone 'Europe/Paris')::date
   or e->>'quantity' is null or (e->>'quantity')::numeric<0 or (e->>'quantity')::numeric>=1e16 or (e->>'quantity')::numeric<>round((e->>'quantity')::numeric,8)
   or (e->>'unitCost')::numeric<0 or (e->>'unitCost')::numeric>=1e16 or ((e->>'unitCost')::numeric<>round((e->>'unitCost')::numeric,8)and not public.cto_broker_cost_precision(new.contract_id,new.asset_id,d,(e->>'unitCost')::numeric,e->>'currency'))
   or not exists(select 1 from public.currencies where code=e->>'currency' and is_active)
   or (e->>'version')::int<1 or e->>'recordedAt' is null or (e->>'recordedAt')::timestamptz>clock_timestamp() then raise exception 'Invalid position history' using errcode='23514';end if;
  if e->>'id'=receipt#>>'{request,2}' and (e->>'recordedAt')::timestamptz<statement_timestamp() then raise exception 'Observation timestamp must be recorded by this operation' using errcode='23514';end if;
  perform (e->>'id')::uuid;seen:=array_append(seen,d);ids:=array_append(ids,e->>'id');
 end loop;
 latest:=public.position_observation_at(h->'entries',(clock_timestamp() at time zone 'Europe/Paris')::date);
 if (new.quantity,new.average_cost_per_unit,btrim(new.cost_currency_code)) is distinct from ((latest->>'quantity')::numeric,(latest->>'unitCost')::numeric,latest->>'currency') then raise exception 'Current holding differs from history' using errcode='23514';end if;
 if jsonb_array_length(h->'archived')<>coalesce(jsonb_array_length(prior->'archived'),0)+1 or (h->'archived')-(jsonb_array_length(h->'archived')-1) is distinct from coalesce(prior->'archived','[]') or h#>'{archived,-1,entries}' is distinct from coalesce(prior->'entries','[]') then raise exception 'Previous versions must be preserved' using errcode='23514';end if;
 needed:=public.position_capture_plan(new.contract_id,new.asset_id,coalesce(prior->'entries','[]'),h->'entries');
 if jsonb_array_length(h->'bindings')<>coalesce(jsonb_array_length(prior->'bindings'),0)+jsonb_array_length(needed->'bindings') then raise exception 'Capture replacements missing' using errcode='23514';end if;
 for b in select value from jsonb_array_elements(needed->'bindings') loop
  if not exists(select 1 from jsonb_array_elements(h->'bindings') with ordinality t(n,ord) where ord>coalesce(jsonb_array_length(prior->'bindings'),0) and n-'correctionId'=b and n->>'correctionId'=correction) then raise exception 'Invalid capture replacement' using errcode='23514';end if;
 end loop;
 if prior is not null then
  if (select coalesce(jsonb_agg(value order by ord),'[]') from jsonb_array_elements(h->'bindings') with ordinality t(value,ord) where ord<=jsonb_array_length(prior->'bindings')) is distinct from prior->'bindings' then raise exception 'Capture trace changed' using errcode='23514';end if;
  for e in select value from jsonb_array_elements(prior->'bindings') loop if not (h->'bindings') @> jsonb_build_array(e) then raise exception 'Capture trace removed' using errcode='23514';end if;end loop;
 end if;
 return new;
end$function$
;
CREATE OR REPLACE FUNCTION public.preview_position_observation(requested_contract uuid, requested_asset uuid, requested_position uuid, requested_observation uuid, requested_date date, requested_quantity numeric, requested_cost numeric, requested_currency text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
declare p public.positions; h jsonb; entries jsonb; previous jsonb; incoming jsonb; next_entries jsonb; plan jsonb; oid uuid:=coalesce(requested_observation,gen_random_uuid()); state_hash text; stamp timestamptz:=clock_timestamp(); parent public.contracts;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 select * into parent from public.contracts where id=requested_contract and user_id=auth.uid();
 if not found or not parent.is_active then raise exception 'Active contract required' using errcode='42501';end if;
 if requested_date is null or requested_date>(stamp at time zone 'Europe/Paris')::date or requested_date<parent.opened_on
 or requested_quantity is null or requested_quantity<0 or requested_quantity>=1e16 or requested_quantity<>round(requested_quantity,8)
 or requested_cost<0 or requested_cost>=1e16 or (requested_cost<>round(requested_cost,8)and not public.cto_broker_cost_precision(requested_contract,requested_asset,requested_date,requested_cost,requested_currency))
 or not exists(select 1 from public.currencies where code=requested_currency and is_active) then raise exception 'Invalid dated holding' using errcode='22023';end if;
 select * into p from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid();
 if requested_position is not null and p.id is distinct from requested_position then raise exception 'Position unavailable' using errcode='40001';end if;
 if p.id is null then
  if not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required' using errcode='42501';end if;
 elsif not p.is_active and not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required for reactivation' using errcode='23514';end if;
 h:=coalesce(p.metadata->'position_observations',jsonb_build_object('version',1,'entries','[]'::jsonb,'archived','[]'::jsonb,'bindings','[]'::jsonb,'receipts','[]'::jsonb));
 entries:=h->'entries';select e into previous from jsonb_array_elements(entries) e where e->>'id'=oid::text;
 incoming:=jsonb_build_object('id',oid,'version',coalesce((previous->>'version')::int,0)+1,'effectiveOn',requested_date,'quantity',requested_quantity::text,'unitCost',case when requested_cost is null then null else requested_cost::text end,'currency',requested_currency,'recordedAt',stamp,'provenance','Situation saisie et confirmée par l’utilisateur');
 select coalesce(jsonb_agg(e order by e->>'effectiveOn'),'[]') into next_entries from jsonb_array_elements(entries) e where e->>'id'<>oid::text and case when exists(select 1 from public.envelope_types t where t.id=parent.envelope_type_id and t.code in('pea','pea_pme','cto','compte_titres'))then (e->>'effectiveOn')::date<requested_date else e->>'effectiveOn'<>requested_date::text end;
 if previous is not null and (previous->>'effectiveOn')::date=requested_date and (previous->>'quantity')::numeric=requested_quantity and (previous->>'unitCost')::numeric is not distinct from requested_cost and previous->>'currency'=requested_currency then incoming:=previous;end if;
 next_entries:=next_entries||jsonb_build_array(incoming);
 if p.id is not null and p.quantity=0 and coalesce((public.position_observation_at(next_entries,(stamp at time zone 'Europe/Paris')::date)->>'quantity')::numeric,0)>0 and not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required for renewed holding' using errcode='23514';end if;
 plan:=public.position_capture_plan(requested_contract,requested_asset,entries,next_entries);
 select md5(coalesce(jsonb_agg(jsonb_build_array(id,revision,inputs,result) order by id)::text,'')) into state_hash from public.patrimonial_daily_captures where user_id=auth.uid() and state='published';
 state_hash:=md5(state_hash||coalesce((select jsonb_agg(jsonb_build_array(id,payload) order by id)::text from public.patrimonial_legacy_sources where user_id=auth.uid()),''));
 return plan||jsonb_build_object('observation',incoming,'previous',previous,'nextEntries',next_entries,'history',h,'position',to_jsonb(p),'destination', (select e from jsonb_array_elements(entries) e where e->>'effectiveOn'=requested_date::text and e->>'id'<>oid::text),'token',md5(coalesce(to_jsonb(p)::text,'null')||state_hash||jsonb_build_array(requested_contract,requested_asset,oid,requested_date,requested_quantity,requested_cost,requested_currency)::text));
end$function$
;
CREATE OR REPLACE FUNCTION public.mutate_securities_cash_action(requested_contract uuid, requested_action uuid, requested_kind text, requested_operation text, requested_request uuid, expected_balances jsonb, expected_action_revision timestamp with time zone, requested_values jsonb)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
<<mutation>>
declare actor uuid:=auth.uid(); c public.contracts; b public.cash_balances; old_b uuid; action private.securities_cash_actions; receipt private.securities_action_requests; payload jsonb; actual jsonb; expected jsonb; code text; currency text; day date; amount numeric; change numeric; stamp timestamptz:=clock_timestamp(); original_day date; base numeric;
begin
 if actor is null or public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 if requested_action is null or requested_request is null or requested_kind is null or requested_operation is null or requested_kind not in('flow','balance')or requested_operation not in('create','update','delete')or jsonb_typeof(expected_balances)is distinct from'array'or jsonb_typeof(requested_values)is distinct from'object'then raise exception 'SECURITIES-REQUEST' using errcode='22023';end if;
 select * into c from public.contracts where id=requested_contract and user_id=actor for update;
 if not found then raise exception 'Unauthorized contract' using errcode='42501';end if;
 select e.code into code from public.envelope_types e where id=c.envelope_type_id;
 if code not in('pea','pea_pme','cto','compte_titres')then raise exception 'Unauthorized envelope' using errcode='42501';end if;
 if requested_kind='flow'and requested_operation<>'create'then raise exception 'SECURITIES-FLOW-IMMUTABLE'using errcode='23514';end if;
 payload:=jsonb_build_array(requested_contract,requested_action,requested_kind,requested_operation,expected_balances,expected_action_revision,requested_values);
 select * into receipt from private.securities_action_requests where user_id=actor and request_id=requested_request;
 if found then if receipt.payload is distinct from payload then raise exception 'SECURITIES-REPLAY' using errcode='40001';end if;
  for b in select * from public.cash_balances where contract_id=c.id and user_id=actor order by id for update loop perform private.adopt_securities_cash(b.id);end loop;return receipt.result;
 end if;
 perform 1 from public.cash_balances where contract_id=c.id and user_id=actor order by id for update;
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'updatedAt',updated_at)order by id),'[]')into actual from public.cash_balances where contract_id=c.id and user_id=actor;
 select coalesce(jsonb_agg(jsonb_build_object('id',(v->>'id')::uuid,'updatedAt',(v->>'updatedAt')::timestamptz)order by (v->>'id')::uuid),'[]')into expected from jsonb_array_elements(expected_balances)v;
 if actual is distinct from expected then raise exception 'SECURITIES-STALE' using errcode='40001';end if;
 for b in select * from public.cash_balances where contract_id=c.id and user_id=actor loop perform private.adopt_securities_cash(b.id);end loop;
 b:=null;
 if requested_operation<>'create' then
  select * into action from private.securities_cash_actions where id=requested_action and user_id=actor and contract_id=c.id for update;
  if not found then raise exception'SECURITIES-STALE'using errcode='40001';end if;
  if not action.active then raise exception'SECURITIES-STALE'using errcode='40001';end if;
  if action.kind<>'balance'then raise exception'SECURITIES-STALE'using errcode='40001';end if;
  if action.recorded_at is distinct from expected_action_revision and not(coalesce(action.legacy_mode='observation',false)and exists(select 1 from public.cash_balances cb where cb.id=action.balance_id and cb.user_id=actor and cb.updated_at=expected_action_revision and not(cb.metadata?'securities_cash_actions')))then raise exception 'SECURITIES-STALE' using errcode='40001';end if;
  old_b:=action.balance_id;original_day:=action.effective_on;
  update private.securities_cash_actions set active=false,versions=versions||jsonb_build_array(to_jsonb(action)-'versions'),recorded_at=stamp where id=action.id;
 elsif exists(select 1 from private.securities_cash_actions where id=requested_action)then raise exception 'SECURITIES-REPLAY' using errcode='40001';end if;
 if requested_operation<>'delete'then
  if requested_operation='create'and not c.is_active then raise exception 'Inactive contract' using errcode='23514';end if;
  currency:=requested_values->>'currency_code';day:=(requested_values->>'date')::date;amount:=(requested_values->>'amount')::numeric;
  if day is null or day>(stamp at time zone'Europe/Paris')::date or day<c.opened_on or day>c.closed_on or amount is null or amount<0 or amount>=1e16 or (amount<>round(amount,2)and not(requested_kind='balance'and private.cto_broker_cash_precision(c.id,currency,day,amount)))or not exists(select 1 from public.currencies where currencies.code=currency and is_active)or requested_kind='flow'and(amount=0 or requested_values->>'kind'is null or requested_values->>'kind'not in('contribution','withdrawal'))then raise exception 'SECURITIES-VALUES' using errcode='22023';end if;
  if requested_kind='flow'and(c.metadata?'knownTotalContributionsEur'or c.metadata?'knownNetCashFlowsEur')and(c.metadata->>'knownTotalContributionsAsOf'is null or c.metadata->>'knownTotalContributionsAsOf'>=day::text)then raise exception 'FLOW-CASH-ANCHOR' using errcode='23514';end if;
  select * into b from public.cash_balances where contract_id=c.id and user_id=actor and currency_code=currency;
  if b.id is null then
   if requested_kind='flow'then raise exception 'SECURITIES-UNKNOWN' using errcode='23514';end if;
   insert into public.cash_balances(user_id,contract_id,currency_code,amount,as_of)values(actor,c.id,currency,0,day::timestamp at time zone'Europe/Paris')returning * into b;
   insert into private.securities_cash_basis(balance_id,user_id,contract_id,entries,initial_action,source_fingerprint)values(b.id,actor,c.id,jsonb_build_array(jsonb_build_object('amount','0','currencyCode',currency,'asOf',b.as_of,'recordedAt',stamp)),requested_action,private.securities_cash_fingerprint(b));
   base:=0;
  else
   if exists(select 1 from private.securities_cash_basis where balance_id=b.id and initial_action=requested_action)then
    update private.securities_cash_basis set entries=jsonb_build_array(jsonb_build_object('amount','0','currencyCode',currency,'asOf',day::timestamp at time zone'Europe/Paris','recordedAt',stamp))where balance_id=b.id;
    base:=coalesce((select sum(a.delta)from private.securities_cash_actions a where a.balance_id=b.id and a.active and a.effective_on<=day),0);
   elsif exists(select 1 from private.securities_cash_basis j where j.balance_id=b.id and j.initial_action is not null and not exists(select 1 from private.securities_cash_actions a where a.id=j.initial_action and a.active))and requested_kind='balance'then
    update private.securities_cash_basis set initial_action=requested_action,entries=jsonb_build_array(jsonb_build_object('amount','0','currencyCode',currency,'asOf',day::timestamp at time zone'Europe/Paris','recordedAt',stamp))where balance_id=b.id;
    base:=coalesce((select sum(a.delta)from private.securities_cash_actions a where a.balance_id=b.id and a.active and a.effective_on<=day),0);
   else base:=private.securities_cash_value(b.id,day);end if;
   if base is null then raise exception 'SECURITIES-UNKNOWN' using errcode='23514';end if;
  end if;
  change:=case when requested_kind='balance'then amount-base when requested_values->>'kind'='contribution'then amount else -amount end;
  insert into private.securities_cash_actions(id,balance_id,user_id,contract_id,kind,effective_on,entered_amount,delta,recorded_at)
   values(requested_action,b.id,actor,c.id,requested_kind,day,amount,change,stamp)
   on conflict(id)do update set balance_id=excluded.balance_id,effective_on=excluded.effective_on,entered_amount=excluded.entered_amount,delta=excluded.delta,active=true,recorded_at=stamp,action_order=private.next_securities_action_order();
 end if;
 if requested_kind='flow'then
  insert into public.cash_flows(id,user_id,kind,source_contract_id,destination_contract_id,amount,currency_code,occurred_at,note,fx_status)values(requested_action,actor,(requested_values->>'kind')::public.cash_flow_kind,case when requested_values->>'kind'='withdrawal'then c.id end,case when requested_values->>'kind'='contribution'then c.id end,amount,currency,day::timestamp at time zone'Europe/Paris',requested_values->>'note',case when currency='EUR'then'resolved'::public.fx_resolution_status else'pending'::public.fx_resolution_status end);
 end if;
 if old_b is not null then perform private.materialize_securities_cash(old_b,least(original_day,coalesce(day,original_day)));end if;
 if b.id is not null and b.id is distinct from old_b then perform private.materialize_securities_cash(b.id,day);end if;
 insert into private.securities_action_requests values(actor,c.id,requested_request,payload,requested_action,stamp);
 return requested_action;
end$function$
;
CREATE OR REPLACE FUNCTION public.save_securities_position_action(requested_contract uuid, requested_asset uuid, requested_position uuid, requested_observation uuid, requested_date date, requested_quantity numeric, requested_cost numeric, requested_currency text, expected_position_updated_at timestamp with time zone, requested_request uuid)
 RETURNS uuid
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare p public.positions; parent public.contracts; plan jsonb; receipt private.securities_action_requests; payload jsonb; oid uuid:=coalesce(requested_observation,requested_request); saved uuid;
begin
 if auth.uid()is null or public.is_authorized_user()is not true then raise exception'Unauthorized'using errcode='42501';end if;
 if requested_request is null then raise exception'Invalid request'using errcode='22023';end if;
 select * into parent from public.contracts where id=requested_contract and user_id=auth.uid()for update;
 if not found or not exists(select 1 from public.envelope_types t where t.id=parent.envelope_type_id and t.code in('pea','pea_pme','cto','compte_titres'))then raise exception'Unauthorized contract'using errcode='42501';end if;
 payload:=jsonb_build_array('position',requested_contract,requested_asset,requested_position,requested_observation,requested_date,requested_quantity,requested_cost,requested_currency,expected_position_updated_at);
 select * into receipt from private.securities_action_requests where user_id=auth.uid()and request_id=requested_request;
 if found then if receipt.payload is distinct from payload then raise exception'SECURITIES-REPLAY'using errcode='40001';end if;
  if not exists(select 1 from public.positions replay_position where replay_position.id=receipt.result and replay_position.user_id=auth.uid()and replay_position.metadata#>array['securities_action_requests',requested_request::text]=payload)then raise exception'SECURITIES-JOURNAL-MISMATCH'using errcode='40001';end if;return receipt.result;
 end if;
 select * into p from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid()for update;
 if p.updated_at is distinct from expected_position_updated_at or p.id is distinct from requested_position then raise exception'SECURITIES-STALE'using errcode='40001';end if;
 if p.id is not null and exists(select 1 from public.assets a where a.id=p.asset_id and a.asset_type_code='fund'and a.valuation_mode='manual')and exists(select 1 from public.position_snapshots s where s.position_id=p.id and s.user_id=auth.uid())then raise exception'Legacy amount holding requires a qualified transition'using errcode='23514';end if;
 if requested_cost is not null and requested_cost<>round(requested_cost,2)and not(public.cto_broker_cost_precision(requested_contract,requested_asset,requested_date,requested_cost,requested_currency)and(exists(select 1 from private.cto_broker_repair_permits permit where permit.tx=txid_current()and permit.backend=pg_backend_pid()and permit.owner=auth.uid()and permit.contract_id=requested_contract)or(requested_cost=p.average_cost_per_unit and requested_currency=btrim(p.cost_currency_code))))then raise exception'PRU: two decimals'using errcode='22023';end if;
 perform public.lock_position_capture_sources();
 plan:=public.preview_position_observation(requested_contract,requested_asset,requested_position,oid,requested_date,requested_quantity,requested_cost,requested_currency);
 saved:=public.save_position_observation(requested_contract,requested_asset,requested_position,oid,requested_date,requested_quantity,requested_cost,requested_currency,plan->>'token');
 update public.positions set metadata=metadata||jsonb_build_object('securities_action_requests',coalesce(metadata->'securities_action_requests','{}')||jsonb_build_object(requested_request::text,payload))where id=saved and user_id=auth.uid();
 insert into private.securities_action_requests(user_id,contract_id,request_id,payload,result)values(auth.uid(),requested_contract,requested_request,payload,saved);
 return saved;
end$function$
;


create or replace function private.cto_broker_materialized_precision(bid uuid,day date,amount numeric)returns boolean language sql stable security definer set search_path=''as $h$select amount>=0 and amount=round(amount,12)and amount=private.securities_cash_value(bid,day)and exists(select 1 from public.cash_balances b join public.contracts c on c.id=b.contract_id join public.envelope_types e on e.id=c.envelope_type_id where b.id=bid and b.user_id=auth.uid()and e.code='cto'and exists(select 1 from private.securities_cash_actions a where a.balance_id=b.id and a.user_id=b.user_id and a.kind='balance'and a.active and a.effective_on<=day and a.entered_amount<>round(a.entered_amount,8)))$h$;revoke all on function private.cto_broker_materialized_precision(uuid,date,numeric)from public,anon,authenticated,service_role;
CREATE OR REPLACE FUNCTION public.guard_dated_cash_balance_observations()
 RETURNS trigger
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
declare
 h jsonb := new.metadata->'cash_balance_observations';
 prior jsonb;
 entry jsonb;
 days date[] := '{}';
 day date;
 latest jsonb;
 archives jsonb;
 old_archives jsonb := '[]';
begin
 if current_user='authenticated' and exists(select 1 from public.contracts c join public.envelope_types t on t.id=c.envelope_type_id where c.id=new.contract_id and c.user_id=auth.uid() and t.code in('pea','pea_pme','cto','compte_titres')) and (tg_op='INSERT' or row(new.amount,new.as_of,new.metadata->'cash_balance_observations',new.metadata->'securities_cash_actions',new.metadata->'flow_cash_links',new.metadata->'flow_cash_requests',new.metadata->'cash_balance_corrections') is distinct from row(old.amount,old.as_of,old.metadata->'cash_balance_observations',old.metadata->'securities_cash_actions',old.metadata->'flow_cash_links',old.metadata->'flow_cash_requests',old.metadata->'cash_balance_corrections')) then raise exception 'SECURITIES-RELOAD' using errcode='40001';end if;
 if current_user<>'authenticated' and new.metadata#>>'{securities_cash_actions,known}'='false' and new.metadata#>'{cash_balance_observations,entries}'='[]'::jsonb and new.amount=0 then return new;end if;
 if public.app_restore_permitted(tg_relid,tg_op,case when tg_op='INSERT' then null else to_jsonb(old) end,case when tg_op='DELETE' then null else to_jsonb(new) end) then if tg_op='DELETE' then return old;else return new;end if;end if;

 if h is null then
   if tg_op='UPDATE' and (old.metadata ? 'cash_balance_observations'
      or row(new.amount,new.as_of) is distinct from row(old.amount,old.as_of)) then
     raise exception 'Dated observation history required' using errcode='23514';
   end if;
   return new;
 end if;
 if h->>'version' is distinct from '2' or jsonb_typeof(h->'entries') is distinct from 'array'
    or jsonb_typeof(h->'archived') is distinct from 'array' then
   raise exception 'Unsupported dated observation history' using errcode='23514';
 end if;
 if jsonb_array_length(h->'entries')=0 and (tg_op='INSERT' or not (new.metadata ? 'cash_balance_corrections')) then raise exception 'Empty effective set requires a traced correction' using errcode='23514';end if;
 for entry in select value from jsonb_array_elements(h->'entries') loop
   if jsonb_typeof(entry->'amount') is distinct from 'string'
      or ((entry->>'amount') !~ '^[0-9]{1,16}(\.[0-9]{1,8})?$' and not (case when (entry->>'amount') ~ '^[0-9]{1,16}(\.[0-9]{1,12})?$' then private.cto_broker_materialized_precision(new.id,((entry->>'asOf')::timestamptz at time zone 'Europe/Paris')::date,(entry->>'amount')::numeric)else false end))
      or entry->>'currencyCode' is distinct from btrim(new.currency_code)
      or entry->>'asOf' is null or entry->>'recordedAt' is null then
     raise exception 'Invalid native cash observation' using errcode='23514';
   end if;
   day := ((entry->>'asOf')::timestamptz at time zone 'Europe/Paris')::date;
   if not isfinite((entry->>'asOf')::timestamptz) or not isfinite((entry->>'recordedAt')::timestamptz)
      or (entry->>'asOf')::timestamptz > clock_timestamp() or day=any(days) then
     raise exception 'Duplicate civil day or invalid observation time' using errcode='23514';
   end if;
   days := array_append(days,day);
   if latest is null or (entry->>'asOf')::timestamptz > (latest->>'asOf')::timestamptz then latest:=entry; end if;
 end loop;
 if latest is not null and ((latest->>'amount')::numeric is distinct from new.amount
    or (latest->>'asOf')::timestamptz is distinct from new.as_of) then
   raise exception 'Current balance must match latest effective observation' using errcode='23514';
 end if;
 if tg_op='UPDATE' and h is distinct from old.metadata->'cash_balance_observations' then
   prior := old.metadata->'cash_balance_observations';
   if prior is not null then
     if prior->>'version' is distinct from '2' then
       raise exception 'Existing observation history requires explicit review' using errcode='23514';
     end if;
     old_archives := prior->'archived';
   end if;
   archives := h->'archived';
   if jsonb_array_length(archives) <> jsonb_array_length(old_archives)+1
      or (select coalesce(jsonb_agg(value order by ord),'[]') from jsonb_array_elements(archives) with ordinality a(value,ord)
          where ord<=jsonb_array_length(old_archives)) is distinct from old_archives then
     raise exception 'Previous versions must be preserved' using errcode='23514';
   end if;
   entry := archives->-1;
   if entry->>'replacedAt' is null or not isfinite((entry->>'replacedAt')::timestamptz) then
     raise exception 'Correction timestamp required' using errcode='23514';
   end if;
   if prior is not null then
     if entry->'entries' is distinct from prior->'entries' then
       raise exception 'Previous effective observations must be archived exactly' using errcode='23514';
     end if;
   else
     if jsonb_typeof(entry->'entries') is distinct from 'array' or jsonb_array_length(entry->'entries')<>1
        or (entry->'entries'->0->>'amount')::numeric is distinct from old.amount
        or (entry->'entries'->0->>'asOf')::timestamptz is distinct from old.as_of
        or entry->'entries'->0->>'currencyCode' is distinct from btrim(old.currency_code) then
       raise exception 'Original native balance must be archived' using errcode='23514';
     end if;
   end if;
 end if;
 return new;
end;
$function$;
create or replace function private.prepare_cto_broker_repair(plan jsonb)returns boolean language plpgsql set search_path=''as $f$
declare c public.contracts;p public.positions;b public.cash_balances;s public.patrimonial_legacy_sources;r jsonb;receipt private.securities_action_requests;owner uuid:=auth.uid();cid uuid:=(plan->>'contractId')::uuid;rid uuid:=(plan->>'requestId')::uuid;actual jsonb;request uuid;old_hash text;
begin
 if owner is null or public.is_authorized_user()is not true or plan->>'status'<>'LOCAL-ONLY-NOT-APPLIED-IN-PRODUCTION'or plan->>'financialReplay'<>'false'or jsonb_array_length(plan->'positions')<>4 then raise exception'CTO-BROKER-PLAN';end if;
 perform pg_advisory_xact_lock(hashtextextended('securities-action-order',0));perform pg_advisory_xact_lock(hashtextextended('app-restore:'||owner::text,0));
 select * into c from public.contracts where id=cid and user_id=owner for update;if not found or not exists(select 1 from public.envelope_types where id=c.envelope_type_id and code='cto')then raise exception'CTO-BROKER-OWNER';end if;
 select * into s from public.patrimonial_legacy_sources where id=(plan->>'sourceId')::uuid and user_id=owner for update;
 if s.payload->>'version'='2'then if s.payload#>>'{repair,requestId}'<>rid::text or s.payload#>'{repair,plan}'is distinct from plan then raise exception'CTO-BROKER-REPLAY';end if;return false;end if;
 select * into s from public.patrimonial_legacy_sources where id=(plan->>'sourceId')::uuid and user_id=owner for update;if not found or s.payload->>'kind'<>'approved_cto_broker_history'or s.payload->>'version'<>'1'or s.payload->>'contractId'<>cid::text or s.source_sha256<>plan->>'sourceSha256'or md5(s.payload::text)<>plan#>>'{expected,sourceHash}'or s.payload->>'statementThrough'<>plan->>'date'then raise exception'CTO-BROKER-SOURCE';end if;
 perform 1 from public.positions where user_id=owner and contract_id=cid order by id for update;perform 1 from public.cash_balances where user_id=owner and contract_id=cid order by id for update;
 select jsonb_agg(jsonb_build_object('id',id,'hash',md5(to_jsonb(x)::text))order by id)into actual from public.positions x where user_id=owner and contract_id=cid;
 if actual is distinct from plan#>'{expected,positions}'then raise exception'CTO-BROKER-STALE-POSITIONS'using errcode='40001';end if;
 select jsonb_agg(jsonb_build_object('id',id,'hash',md5(to_jsonb(x)::text))order by id)into actual from public.cash_balances x where user_id=owner and contract_id=cid;
 if actual is distinct from plan#>'{expected,balances}'then raise exception'CTO-BROKER-STALE-CASH'using errcode='40001';end if;
 if (select md5(jsonb_agg(to_jsonb(x)order by id)::text)from public.cash_flows x where user_id=owner and coalesce(destination_contract_id,source_contract_id)=cid)<>plan#>>'{expected,flowsHash}'then raise exception'CTO-BROKER-FLOWS';end if;
 insert into private.cto_broker_repair_permits values(txid_current(),pg_backend_pid(),owner,cid,rid,plan);
 for r in select value from jsonb_array_elements(plan->'positions')loop
  select * into strict p from public.positions where contract_id=cid and asset_id=(r->>'assetId')::uuid and user_id=owner;
  if r#>>'{basis,sourceSha256}'<>s.source_sha256 or r#>>'{basis,method}'<>'dated_official_reference_fx_estimate'or (r->>'quantity')::numeric<>(select sum((a->>'quantity')::numeric)from jsonb_array_elements(s.payload->'acquisitions')a where a->>'assetId'=r->>'assetId')or (r#>>'{basis,totalUsd}')::numeric<>(select sum((a->>'basisUsd')::numeric)from jsonb_array_elements(s.payload->'acquisitions')a where a->>'assetId'=r->>'assetId')or abs((r#>>'{basis,totalEurEstimate}')::numeric-(select (h->>'costEur')::numeric from jsonb_array_elements(s.payload->'days')d cross join lateral jsonb_array_elements(d->'holdings')h where d->>'date'=s.payload->>'through'and h->>'assetId'=r->>'assetId'))>1e-30 or (r->>'unitCostUsd')::numeric<>round((r#>>'{basis,totalUsd}')::numeric(80,40)/(r->>'quantity')::numeric,20)then raise exception'CTO-BROKER-COST';end if;
  request:=md5(rid::text||':'||p.id::text)::uuid;
  perform public.save_securities_position_action(cid,p.asset_id,p.id,request,(plan->>'date')::date,(r->>'quantity')::numeric,(r->>'unitCostUsd')::numeric,'USD',p.updated_at,request);
  update public.positions set metadata=metadata||jsonb_build_object('cto_broker_basis',r->'basis')where id=p.id;
 end loop;
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'updatedAt',updated_at)order by id),'[]')into actual from public.cash_balances where contract_id=cid and user_id=owner;
 request:=md5(rid::text||':cash')::uuid;
 perform public.mutate_securities_cash_action(cid,request,'balance','create',request,actual,null,plan->'cash');
 return true;
end$f$;
revoke all on function private.prepare_cto_broker_repair(jsonb)from public,anon,authenticated,service_role;

create or replace function private.finalize_cto_broker_repair(rid uuid,updated_proof jsonb)returns void language plpgsql set search_path=''as $f$
declare permit private.cto_broker_repair_permits;prior jsonb;d jsonb;
begin
 select * into strict permit from private.cto_broker_repair_permits where tx=txid_current()and backend=pg_backend_pid()and owner=auth.uid()and request_id=rid;
 select payload into strict prior from public.patrimonial_legacy_sources where id=(permit.plan->>'sourceId')::uuid and user_id=auth.uid();
 if updated_proof->>'version'<>'2'or updated_proof->'priorVersions'<>jsonb_build_array(prior)or updated_proof#>>'{repair,requestId}'<>rid::text or updated_proof-'version'-'days'-'priorVersions'-'repair' is distinct from prior-'version'-'days'or jsonb_array_length(updated_proof->'days')<>jsonb_array_length(prior->'days')then raise exception'CTO-BROKER-REBIND';end if;
 for d in select value from jsonb_array_elements(updated_proof->'days')loop if d-'baseline'is distinct from(select p-'baseline'from jsonb_array_elements(prior->'days')p where p->>'date'=d->>'date')then raise exception'CTO-BROKER-HISTORY-CHANGED';end if;end loop;
 updated_proof:=jsonb_set(updated_proof,'{repair,plan}',permit.plan);
 update public.patrimonial_legacy_sources set payload=updated_proof where id=(permit.plan->>'sourceId')::uuid and user_id=auth.uid();

 delete from private.cto_broker_repair_permits where tx=permit.tx and backend=permit.backend and owner=permit.owner and contract_id=permit.contract_id;
end$f$;
revoke all on function private.finalize_cto_broker_repair(uuid,jsonb)from public,anon,authenticated,service_role;


CREATE OR REPLACE FUNCTION private.app_backup_upgrade(doc jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare d record;obj jsonb;row jsonb;data jsonb;begin
 if doc->>'schema'='7b8d63de5bc463697251a1c84a5ab7a2d34723fd9b0b94c0654c313d8b5a34f1'and private.app_backup_schema()='237871bc6c514a148fbb9da4331506d574b1abf41368c61a67177bdd04a2c86a'then doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));end if;

 if public.is_authorized_user()is not true or doc->>'owner'is distinct from auth.uid()::text then raise exception'Unauthorized'using errcode='42501';end if;
 if doc->>'format'='monpatrimoine-app-backup/3' and doc->>'schema'='835028012c2472878aa5c9ad3d097c4bdda27cc617b5fc84e862af7df8bc4bbc' then
 doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));
 end if;
 if doc->>'format'='monpatrimoine-app-backup/3' and doc->>'schema'='e3f63a4322f4ebf7892e0dc0626a7175d290110a652b3394e4c12ee0baaf3f3b' then
 doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));
 end if;
 if doc->>'schema'=private.app_backup_schema()then perform private.app_backup_validate(doc);return doc;end if;
 if doc->'datasets'?'securities_cash_basis'or doc->'datasets'?'securities_cash_actions'or doc->'datasets'?'securities_action_requests'or doc->'datasets'?'securities_journal_integrity'then raise exception'Unsupported partial journal archive';end if;
 -- An archive with modern materializations but no journal has lost business
 -- data. Never convert that loss into an apparently fresh empty ledger.
 for d in select * from private.app_backup_datasets where name in('cash_balances','positions','contracts')loop
  for row in select * from jsonb_array_elements(doc#>array['datasets',d.name,'rows'])loop
   select jsonb_object_agg(c,row->(i-1)::int)into obj from jsonb_array_elements_text(doc#>array['datasets',d.name,'columns'])with ordinality t(c,i);
   if(obj->>'metadata')::jsonb?'securities_cash_actions'or(obj->>'metadata')::jsonb?'securities_action_requests'then raise exception'SECURITIES-JOURNAL-MISSING-IN-ARCHIVE';end if;
  end loop;
 end loop;
 for d in select * from private.app_backup_datasets where name in('securities_cash_basis','securities_cash_actions','securities_action_requests')loop
  doc:=jsonb_set(doc,array['datasets',d.name],jsonb_build_object('columns',d.columns,'rows','[]'::jsonb));
 end loop;
 select jsonb_object_agg(k,v)into data from jsonb_each(doc->'datasets')t(k,v)where k in('securities_cash_basis','securities_cash_actions','securities_action_requests');
 doc:=jsonb_set(doc,'{datasets,securities_journal_integrity}',jsonb_build_object('columns',array['user_id','content_sha256'],'rows',jsonb_build_array(jsonb_build_array(auth.uid()::text,encode(extensions.digest(data::text,'sha256'),'hex')))));
 if doc->>'format'='monpatrimoine-app-backup/3'and doc->>'schema'in('8cf0fb641a93c05ee70ab159f60a5b50024a95ba1b2d1749bd1d4f56e5027fc8','405698ddd199f9344105378a5b5b5e27645fcf3076fc16a324bbf6ea87fd7a6f')then
  doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));perform private.app_backup_validate(doc);return doc;
 end if;
 -- Previous exact /1,/2,/3 frontiers remain delegated to the existing allowlist.
 return private.app_backup_upgrade_before_securities(doc);
end$function$;
commit;
