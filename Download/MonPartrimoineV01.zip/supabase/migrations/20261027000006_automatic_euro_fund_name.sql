-- Future life-insurance contracts only. No existing asset or observation renamed.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';

do $patch$
declare original text; needle text:='new.user_id,''Fonds euros'',''fund''';
begin
 if private.app_backup_schema()<>'77258048d2a433ddaf6cba7acc8c3a2890bf5c3ca3280f842d0f057c06e4c740'
 then raise exception 'Unexpected automatic fund naming prerequisite';end if;
 original:=pg_get_functiondef('private.create_new_euro_fund()'::regprocedure);
 if (length(original)-length(replace(original,needle,'')))/length(needle)<>1
 then raise exception 'Unexpected automatic fund creator';end if;
 -- Use the actual contract name, not its optional display/tile alias.
 -- CREATE OR REPLACE preserves the owner and existing ACLs/trigger binding.
 execute replace(original,needle,'new.user_id,''Fonds en euros ''||new.name,''fund''');

 -- The trigger text participates in the archive schema seal. Archived columns
 -- and cells are unchanged: accept exactly the delivered predecessor too.
 -- Keep the earlier predecessor, ownership validation and all other checks.
 original:=pg_get_functiondef('private.app_backup_upgrade(jsonb)'::regprocedure);
 needle:='if doc->>''schema'' is distinct from ''3ca73f81c329737a9939a5ce041e43e8846fac1da23b433f0f2618fbe18b46fd''';
 if (length(original)-length(replace(original,needle,'')))/length(needle)<>1
 then raise exception 'Unexpected archive naming frontier';end if;
 execute replace(original,needle,needle||' and doc->>''schema'' is distinct from ''77258048d2a433ddaf6cba7acc8c3a2890bf5c3ca3280f842d0f057c06e4c740''');
end $patch$;
notify pgrst,'reload schema';
commit;
