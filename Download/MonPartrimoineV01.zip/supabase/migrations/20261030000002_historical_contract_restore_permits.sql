-- Local-qualified follow-up only. No data rewrite or additional client grants.
begin;
do $preflight$begin
 if private.app_backup_schema()<>'835028012c2472878aa5c9ad3d097c4bdda27cc617b5fc84e862af7df8bc4bbc'
 or md5(pg_get_functiondef('private.guard_manual_contract()'::regprocedure))<>'6f1a9a03599b89421c0db43202b1877d'
 or md5(pg_get_functiondef('private.app_backup_upgrade(jsonb)'::regprocedure))<>'89b6a5d91efd7498aa6950accac390ae' then raise exception 'Historical restore source drift';end if;
end$preflight$;
do $patch$declare s text;needle text;begin
 s:=pg_get_functiondef('private.guard_manual_contract()'::regprocedure);
 needle:='begin';
 -- Only the exact transaction/backend/relation/operation/before/after permit
 -- manufactured by the owner-scoped operator can preserve a historical row.
 s:=overlay(s placing $permit$begin
 if auth.uid() is not null and new.user_id=auth.uid()
 and public.is_authorized_user() is true
 and public.app_restore_permitted(tg_relid,tg_op,
 case when tg_op='INSERT' then null else to_jsonb(old) end,to_jsonb(new)) then
  return new;
 end if;$permit$ from strpos(s,needle) for length(needle));
 execute s;
 s:=pg_get_functiondef('private.app_backup_upgrade(jsonb)'::regprocedure);
 needle:='if doc->>''schema''=private.app_backup_schema()then';
 if strpos(s,needle)=0 then raise exception 'Unexpected upgrade source';end if;
 -- Exact same registered columns/journal; only the guard definition changes.
 -- No unqualified schema is admitted, and ordinary validation still runs.
 execute replace(s,needle,$frontier$if doc->>'format'='monpatrimoine-app-backup/3' and doc->>'schema'='835028012c2472878aa5c9ad3d097c4bdda27cc617b5fc84e862af7df8bc4bbc' then
 doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));
 end if;
 if doc->>'schema'=private.app_backup_schema()then$frontier$);
end$patch$;
commit;
