begin;

create table private.xlsx_financial_configuration (
  owner_id uuid primary key,
  folder_id text not null unique,
  seed_from date not null default date '1900-01-01',
  seed_cutoff timestamptz,
  seeded boolean not null default false,
  enabled boolean not null default false,
  foreign key (owner_id, folder_id) references private.xlsx_drive_destinations(owner_id, folder_id)
);

create table private.xlsx_financial_days (
  owner_id uuid not null references private.xlsx_financial_configuration,
  business_date date not null,
  captured_at timestamptz not null,
  published_at timestamptz,
  payload jsonb not null check (jsonb_typeof(payload) = 'object'),
  primary key (owner_id, business_date)
);

create table private.xlsx_financial_jobs (
  owner_id uuid not null references private.xlsx_financial_configuration,
  operation_id uuid not null,
  business_date date not null,
  mode text not null check (mode in ('manual','automatic')),
  captured_at timestamptz not null,
  source jsonb,
  prepared jsonb,
  completed_at timestamptz,
  last_error text,
  primary key (owner_id, operation_id)
);
create unique index xlsx_financial_one_pending on private.xlsx_financial_jobs(owner_id) where completed_at is null;

alter table private.xlsx_financial_configuration enable row level security;
alter table private.xlsx_financial_days enable row level security;
alter table private.xlsx_financial_jobs enable row level security;
revoke all on private.xlsx_financial_configuration, private.xlsx_financial_days, private.xlsx_financial_jobs from public, anon, authenticated, service_role;

-- Only the approved Production destination may share the historical backup
-- folder. The existing checks for technical FILE IDs and the XLSX lease stay.
do $migration$
declare
  original text := pg_get_functiondef('public.xlsx_publication_store(uuid,text,uuid,text,bigint,jsonb)'::regprocedure);
  old_guard constant text := 'select 1 from private.app_backup_drive_root where folder_id = p_folder';
  new_guard constant text := 'select 1 from private.app_backup_drive_root r where r.folder_id = p_folder
    and not exists (select 1 from private.xlsx_financial_configuration c
      join private.xlsx_financial_jobs j on j.owner_id = c.owner_id
      where c.owner_id = p_owner and c.owner_id = r.user_id and c.folder_id = p_folder
        and c.enabled and c.seeded and j.operation_id = p_operation and j.completed_at is null and j.prepared is not null)';
begin
  if length(original) - length(replace(original,old_guard,'')) <> length(old_guard) then
    raise exception 'Unexpected XLSX destination guard';
  end if;
  execute replace(original, old_guard, new_guard);
end;
$migration$;

create function public.xlsx_financial_store(
  p_owner uuid, p_action text, p_operation uuid default null, p_mode text default null,
  p_date date default null, p_payload jsonb default null
) returns jsonb language plpgsql security definer set search_path='' as $function$
declare
  cfg private.xlsx_financial_configuration;
  job private.xlsx_financial_jobs;
  next_date date;
  stamp timestamptz := statement_timestamp();
  today date := (stamp at time zone 'Europe/Paris')::date;
  archive jsonb;
  identities jsonb;
  source_rows jsonb;
  asset_labels jsonb;
  dated_positions jsonb;
  dated_balances jsonb;
  dated_manual jsonb;
  manual_sources jsonb;
begin
  if not exists (select 1 from private.application_principal a join public.profiles p on p.auth_user_id=a.auth_user_id
    where a.singleton and p.is_active and a.auth_user_id=p_owner) then
    raise exception 'Unauthorized financial XLSX owner' using errcode='42501';
  end if;
  select c.* into cfg from private.xlsx_financial_configuration c join private.app_backup_drive_root r
    on r.user_id=c.owner_id and r.folder_id=c.folder_id where c.owner_id=p_owner for update of c;
  if not found then raise exception 'Unknown financial XLSX destination' using errcode='42501'; end if;

  if p_action in ('seed_read','seed_insert') then
    if cfg.seeded and p_action='seed_read' and not cfg.enabled then return jsonb_build_object('status','seeded'); end if;
    if cfg.enabled or cfg.seeded or exists(select 1 from private.xlsx_financial_jobs where owner_id=p_owner) then
      raise exception 'XLSX history already frozen' using errcode='42501';
    end if;
    if cfg.seed_cutoff is null then
      if p_action <> 'seed_read' then raise exception 'Missing XLSX history cutoff' using errcode='22023'; end if;
      update private.xlsx_financial_configuration set seed_cutoff=stamp where owner_id=p_owner returning * into cfg;
    end if;
    select min(candidates.business_date) into next_date from (
      select c.business_date from public.patrimonial_daily_captures c
        where c.user_id=p_owner and c.state='published' and c.captured_at<=cfg.seed_cutoff
      union all
      select s.business_date from public.patrimonial_legacy_sources s where s.user_id=p_owner and s.imported_at<=cfg.seed_cutoff
        and s.payload->>'kind' in ('approved_manual_gross_observation','approved_contract_correction','user_position_valuation_confirmation')
      union all
      select (entry->>'effectiveOn')::date from public.positions p
        cross join lateral jsonb_array_elements(coalesce(p.metadata#>'{position_observations,entries}','[]')) entry
        where p.user_id=p_owner and (entry->>'recordedAt')::timestamptz<=cfg.seed_cutoff
      union all
      select (b.as_of at time zone 'Europe/Paris')::date from public.cash_balances b
        where b.user_id=p_owner and not (coalesce(b.metadata,'{}') ? 'cash_balance_observations') and b.updated_at<=cfg.seed_cutoff
      union all
      select ((entry->>'asOf')::timestamptz at time zone 'Europe/Paris')::date from public.cash_balances b
        cross join lateral jsonb_array_elements(coalesce(b.metadata#>'{cash_balance_observations,entries}','[]')) entry
        where b.user_id=p_owner and (entry->>'recordedAt')::timestamptz<=cfg.seed_cutoff
      union all
      select (m.situated_at at time zone 'Europe/Paris')::date from public.contract_manual_situations m
        where m.user_id=p_owner and m.recorded_at<=cfg.seed_cutoff
    ) candidates where candidates.business_date > cfg.seed_from
      and candidates.business_date <= (cfg.seed_cutoff at time zone 'Europe/Paris')::date;
    if next_date is null then
      if p_action <> 'seed_read' then raise exception 'No day to import' using errcode='22023'; end if;
      update private.xlsx_financial_configuration set seeded=true where owner_id=p_owner;
      return jsonb_build_object('status','seeded');
    end if;
    if p_action='seed_read' then
      select coalesce(jsonb_agg(jsonb_build_object('id',id,'business_date',business_date,'revision',revision,
        'captured_at',captured_at,'inputs',inputs,'result',result) order by revision desc,id),'[]') into archive
        from public.patrimonial_daily_captures
        where user_id=p_owner and state='published' and captured_at<=cfg.seed_cutoff and business_date=next_date;
      select coalesce(jsonb_object_agg(c.id,jsonb_build_object('label',coalesce(nullif(c.display_name,''),c.name),'envelope',e.code,
        'openedOn',c.opened_on,'closedOn',c.closed_on,'valuationSource',c.valuation_source)),'{}')
        into identities from public.contracts c join public.envelope_types e on e.id=c.envelope_type_id
        where c.user_id=p_owner;
      select coalesce(jsonb_object_agg(a.id,jsonb_build_object('label',coalesce(nullif(a.display_name,''),a.name),'type',a.asset_type_code)),'{}')
        into asset_labels from public.assets a where a.owner_user_id=p_owner;
      select coalesce(jsonb_agg(to_jsonb(s) - 'user_id' order by s.id),'[]') into source_rows from public.patrimonial_legacy_sources s
        where s.user_id=p_owner and s.business_date=next_date and s.imported_at<=cfg.seed_cutoff;
      select coalesce(jsonb_agg(jsonb_build_object('contractId',p.contract_id,'assetId',p.asset_id,'entry',entry)
        order by p.id,entry->>'recordedAt'),'[]') into dated_positions from public.positions p
        cross join lateral (
          select e as entry from jsonb_array_elements(coalesce(p.metadata#>'{position_observations,entries}','[]')) e
          where e->>'effectiveOn'<=next_date::text and (e->>'recordedAt')::timestamptz<=cfg.seed_cutoff
          order by e->>'effectiveOn' desc, (e->>'recordedAt')::timestamptz desc
          limit 1
        ) qualified
        where p.user_id=p_owner;
      select coalesce(jsonb_agg(to_jsonb(b) - 'user_id' order by b.id),'[]') into dated_balances from public.cash_balances b
        join public.contracts c on c.id=b.contract_id join public.envelope_types e on e.id=c.envelope_type_id
        where b.user_id=p_owner and e.code='epargne_liquide';
      select coalesce(jsonb_agg(to_jsonb(m) - 'user_id' order by m.id),'[]') into dated_manual from public.contract_manual_situations m
        join public.contracts c on c.id=m.contract_id join public.envelope_types e on e.id=c.envelope_type_id
        where m.user_id=p_owner and m.recorded_at<=cfg.seed_cutoff and (e.code in ('peg','per_col')
          or (m.situated_at at time zone 'Europe/Paris')::date=next_date);
      select coalesce(jsonb_agg(to_jsonb(s) - 'user_id' order by s.id),'[]') into manual_sources from public.patrimonial_legacy_sources s
        where s.user_id=p_owner and s.imported_at<=cfg.seed_cutoff and s.payload->>'kind'='approved_manual_gross_observation';
      return jsonb_build_object('status','source','date',next_date,'cutoff',cfg.seed_cutoff,
        'captures',archive,'identities',identities,'sources',source_rows,'assets',asset_labels,
        'positionEvidence',dated_positions,'balanceEvidence',dated_balances,'manualEvidence',dated_manual,'manualSources',manual_sources);
    end if;
    if p_date is distinct from next_date or p_payload->>'date' is distinct from next_date::text
      or jsonb_typeof(p_payload) is distinct from 'object'
      or octet_length(p_payload::text)>524288 then
      raise exception 'Invalid XLSX historic projection' using errcode='22023';
    end if;
    if jsonb_array_length(p_payload->'observations') > 0 or jsonb_array_length(p_payload->'closedContracts') > 0 then
      insert into private.xlsx_financial_days(owner_id,business_date,captured_at,payload)
        values(p_owner,next_date,(p_payload->>'capturedAt')::timestamptz,p_payload);
    end if;
    update private.xlsx_financial_configuration set seed_from=next_date where owner_id=p_owner;
    return jsonb_build_object('status','seeded_day','date',next_date);
  end if;

  if not cfg.enabled or not cfg.seeded or not exists (
    select 1 from private.xlsx_drive_destinations d where d.owner_id=p_owner and d.folder_id=cfg.folder_id and d.enabled
  ) then raise exception 'Financial XLSX disabled' using errcode='42501'; end if;

  if p_action='claim' then
    if p_mode is null or p_mode not in ('manual','automatic') or p_date is distinct from today
      or (p_mode='manual' and p_operation is null) or (p_mode='automatic' and p_operation is not null) then
      raise exception 'Invalid financial XLSX claim' using errcode='22023';
    end if;
    if p_mode='manual' then
      select * into job from private.xlsx_financial_jobs where owner_id=p_owner and operation_id=p_operation;
      if found and job.completed_at is not null then return jsonb_build_object('status','already_published','date',job.business_date); end if;
    end if;
    select * into job from private.xlsx_financial_jobs where owner_id=p_owner and completed_at is null;
    if found and (
      (p_mode='automatic' and job.mode<>'automatic' and job.business_date=today)
      or (p_mode='manual' and job.operation_id is distinct from p_operation
        and job.last_error is null and job.captured_at >= stamp - interval '90 seconds')
    ) then
      return jsonb_build_object('status','busy');
    end if;
    if not found then
      if p_mode='automatic' and exists(select 1 from private.xlsx_financial_days where owner_id=p_owner and business_date=today and published_at is not null) then
        return jsonb_build_object('status','already_published','date',today);
      end if;
      -- Existing read-only, single-statement snapshot. Retain inactive dated
      -- positions as evidence of an exit, without including them in calculation.
      archive := private.daily_capture_inputs() || jsonb_build_object('positions',coalesce((
        select jsonb_agg(to_jsonb(p) || jsonb_build_object('quantity',p.quantity::text,'average_cost_per_unit',p.average_cost_per_unit::text) order by p.id)
        from public.positions p where p.user_id=p_owner
          and (p.is_active or p.metadata ? 'position_observations')
      ),'[]'));
      archive := archive || '{"exposures":[],"sectors":[],"activities":[],"countries":[],"regions":[],"themes":[],"themeExposures":[]}'::jsonb;
      if archive->>'userId' is distinct from p_owner::text or octet_length(archive::text)>12582912 then
        raise exception 'XLSX capture scope or size' using errcode='22023';
      end if;
      insert into private.xlsx_financial_jobs(owner_id,operation_id,business_date,mode,captured_at,source)
        values(p_owner,coalesce(p_operation,gen_random_uuid()),today,p_mode,stamp,archive) returning * into job;
    end if;
    return jsonb_build_object('status','claimed','operation',job.operation_id,'date',job.business_date,
      'capturedAt',job.captured_at,'folder',cfg.folder_id,'installation',
      (select r.installation from private.app_backup_drive_root r where r.user_id=p_owner and r.folder_id=cfg.folder_id),
      'prepared',job.prepared,'source',job.source);
  end if;

  select * into job from private.xlsx_financial_jobs where owner_id=p_owner and operation_id=p_operation;
  if not found then raise exception 'Unknown financial XLSX operation' using errcode='42501'; end if;
  if job.completed_at is not null then return jsonb_build_object('status','already_published','date',job.business_date); end if;

  if p_action='prepare' then
    if p_payload->>'date' is distinct from job.business_date::text or jsonb_typeof(p_payload) is distinct from 'object'
      or (p_payload->>'capturedAt')::timestamptz is distinct from job.captured_at
      or octet_length(p_payload::text)>524288 then raise exception 'Invalid financial XLSX day' using errcode='22023'; end if;
    if job.prepared is null then
      update private.xlsx_financial_jobs set prepared=p_payload,source=null
        where owner_id=p_owner and operation_id=p_operation returning * into job;
    elsif job.prepared is distinct from p_payload then
      raise exception 'Financial XLSX projection changed' using errcode='22023';
    end if;
    return jsonb_build_object('status','prepared','day',job.prepared);
  elsif p_action='read_days' then
    select coalesce(jsonb_agg(payload order by business_date),'[]'::jsonb) into archive
      from (select payload,business_date from private.xlsx_financial_days where owner_id=p_owner
        and business_date>coalesce(p_date,date '1899-12-31') and business_date<=job.business_date
        order by business_date limit 32) pages;
    return jsonb_build_object('status','days','days',archive);
  elsif p_action='failure' then
    if coalesce(p_payload->>'code','') !~ '^[a-z_]{1,28}$' then
      raise exception 'Invalid financial XLSX status' using errcode='22023';
    end if;
    update private.xlsx_financial_jobs set last_error=p_payload->>'code' where owner_id=p_owner and operation_id=p_operation;
    return jsonb_build_object('status','retryable');
  elsif p_action='finish' then
    if not exists (select 1 from private.xlsx_publications p where p.owner_id=p_owner and p.folder_id=cfg.folder_id
      and p.operation_id=p_operation and p.business_date=job.business_date and p.state='verified' and p.completed_at is not null
      and p.sha256=p_payload->>'sha256') then
      raise exception 'Financial XLSX publication unconfirmed' using errcode='22023';
    end if;
    insert into private.xlsx_financial_days(owner_id,business_date,captured_at,published_at,payload)
      values(p_owner,job.business_date,job.captured_at,stamp,job.prepared)
      on conflict (owner_id,business_date) do update set captured_at=excluded.captured_at,published_at=excluded.published_at,payload=excluded.payload;
    update private.xlsx_financial_jobs set completed_at=stamp,prepared=null,last_error=null where owner_id=p_owner and operation_id=p_operation;
    return jsonb_build_object('status','published','date',job.business_date);
  end if;
  raise exception 'Invalid financial XLSX operation' using errcode='22023';
end;
$function$;
revoke all on function public.xlsx_financial_store(uuid,text,uuid,text,date,jsonb) from public, anon, authenticated, service_role;
grant execute on function public.xlsx_financial_store(uuid,text,uuid,text,date,jsonb) to service_role;

commit;
