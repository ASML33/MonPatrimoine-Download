-- Keep the business profile aligned only when Supabase Auth makes an email
-- change effective. Pending confirmation requests leave both values unchanged.
begin;

create function private.sync_profile_email_from_auth()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.email is not null and new.email is distinct from old.email then
    update public.profiles
    set email = pg_catalog.lower(new.email)
    where auth_user_id = new.id;
  end if;
  return new;
end;
$$;

revoke all on function private.sync_profile_email_from_auth()
  from public, anon, authenticated;

create trigger monpatrimoine_sync_profile_email
  after update of email on auth.users
  for each row execute function private.sync_profile_email_from_auth();

-- Repair pre-existing drift without ever writing to auth.users.
update public.profiles as profile
set email = pg_catalog.lower(auth_user.email)
from auth.users as auth_user
where profile.auth_user_id = auth_user.id
  and auth_user.email is not null
  and profile.email::text is distinct from pg_catalog.lower(auth_user.email);

commit;
