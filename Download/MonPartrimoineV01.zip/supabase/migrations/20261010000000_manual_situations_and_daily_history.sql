-- Local foundation only until explicit deployment authorization.
begin;

-- A missing historical opening date is unknown data, never a fabricated date.
alter table public.contracts alter column opened_on drop not null;

insert into public.envelope_types(id,code,label,is_active) values
 ('71000000-0000-0000-0000-000000000007','peg','PEG',true),
 ('71000000-0000-0000-0000-000000000008','per_col','PER COL',true),
 ('71000000-0000-0000-0000-000000000009','pea_pme','PEA-PME',true);

insert into public.fiscal_regimes(id,code,envelope_type_id,label,description,calculation_kind,status) values
 ('81000000-0000-0000-0000-000000000009','pea_pme_standard','71000000-0000-0000-0000-000000000009','PEA-PME — régime standard limité','Titres ordinaires : exclut les cas particuliers des titres non cotés et des obligations convertibles non cotées. Aucun plafond repris du PEA.','pea_liquidation','limited');
insert into public.fiscal_rules(id,env,rule_code,rule_name,min_years,tax_rate,social_rate,valid_from,description,source,active,fiscal_regime_id,version_number,age_threshold_months,ir_rate_before,ir_rate_after,ps_rate_before,ps_rate_after,ir_base_type,ps_base_type,source_title,verified_on,status) values
 ('82000000-0000-0000-0000-000000000009','fr','pea_pme_standard_2026','PEA-PME — régime standard limité 2026',0,0.128,0.186,'2026-01-01','IR avant cinq ans, puis exonération ; PS dus. Les exceptions non cotées ne sont pas calculées.','https://www.impots.gouv.fr/particulier/lassurance-vie-et-le-pea-0',true,'81000000-0000-0000-0000-000000000009',1,60,0.128,0,0.186,0.186,'positive_plan_gain','positive_plan_gain','DGFiP — PEA et PEA-PME','2026-10-06','verified');
alter table public.contracts add column pea_pme_standard_confirmed boolean not null default false;

alter table public.contracts add column valuation_source text not null default 'positions'
 check(valuation_source in ('positions','manual_situation'));

create function private.guard_manual_contract() returns trigger language plpgsql set search_path='' as $$
begin
 if new.valuation_source='manual_situation' and (new.currency_code<>'EUR' or not exists(
 select 1 from public.envelope_types t where t.id=new.envelope_type_id and t.code in ('peg','per_col'))) then
 raise exception 'Manual authority requires PEG/PER COL in EUR' using errcode='23514'; end if;
 return new;
end $$;
create trigger contracts_manual_authority before insert or update on public.contracts
 for each row execute function private.guard_manual_contract();

create table public.contract_manual_situations (
 id uuid primary key default gen_random_uuid(), user_id uuid not null,
 contract_id uuid not null, situated_at timestamptz not null,
 gross_eur numeric(24,8) not null check(gross_eur>=0),
 fiscal_gain_eur numeric(24,8), source_net_eur numeric(24,8) check(source_net_eur>=0),
 source text not null check(char_length(source) between 1 and 200),
 source_time_precision text not null default 'exact' check(source_time_precision in ('exact','date','evening')),
 recorded_at timestamptz not null default clock_timestamp(),
 foreign key(contract_id,user_id) references public.contracts(id,user_id) on delete restrict,
 unique(contract_id,situated_at,recorded_at)
);
create table public.contract_manual_simulations (
 id uuid primary key default gen_random_uuid(), user_id uuid not null,
 contract_id uuid not null, version integer not null check(version>0),
 effective_from date not null, ps_rate numeric not null check(ps_rate between 0 and 1),
 provenance text not null default 'hypothèse personnelle de simulation'
   check(provenance='hypothèse personnelle de simulation'),
 created_at timestamptz not null default clock_timestamp(),
 foreign key(contract_id,user_id) references public.contracts(id,user_id) on delete restrict,
 unique(contract_id,version)
);
create function private.guard_manual_history() returns trigger language plpgsql set search_path='' as $$
begin raise exception 'Manual history is append-only' using errcode='23514'; end $$;
create trigger manual_situations_immutable before update or delete on public.contract_manual_situations
 for each row execute function private.guard_manual_history();
create trigger manual_simulations_immutable before update or delete on public.contract_manual_simulations
 for each row execute function private.guard_manual_history();

create or replace function public.contract_has_dependencies(contract_id uuid)
returns boolean language sql stable security invoker set search_path='' as $$
 select exists(select 1 from public.positions p where p.contract_id=$1)
 or exists(select 1 from public.cash_balances b where b.contract_id=$1)
 or exists(select 1 from public.cash_flows f where f.source_contract_id=$1 or f.destination_contract_id=$1)
 or exists(select 1 from public.contract_manual_situations s where s.contract_id=$1)
 or exists(select 1 from public.contract_manual_simulations s where s.contract_id=$1);
$$;

create function public.save_contract_manual_situation(
 requested_contract uuid, requested_situated_at timestamptz, requested_gross numeric,
 requested_gain numeric, requested_source_net numeric, requested_source text,
 requested_ps_rate numeric default null
) returns uuid language plpgsql security definer set search_path='' as $$
declare saved uuid; next_version integer;
begin
 if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501'; end if;
 perform 1 from public.contracts c join public.envelope_types t on t.id=c.envelope_type_id
 where c.id=requested_contract and c.user_id=auth.uid() and c.is_active
 and c.currency_code='EUR' and t.code in ('peg','per_col') for update of c;
 if not found then raise exception 'Manual contract unavailable' using errcode='42501'; end if;
 if requested_situated_at is null or requested_situated_at>clock_timestamp()
 or requested_gross is null or requested_gross<0 or requested_gross::text in ('NaN','Infinity','-Infinity')
 or requested_gain::text in ('NaN','Infinity','-Infinity')
 or requested_source_net<0 or requested_source_net::text in ('NaN','Infinity','-Infinity')
 or requested_source is null or char_length(btrim(requested_source)) not between 1 and 200
 or requested_ps_rate<0 or requested_ps_rate>1 or requested_ps_rate::text in ('NaN','Infinity','-Infinity') then
 raise exception 'Invalid manual situation' using errcode='23514'; end if;
 if requested_ps_rate is not null then
 select coalesce(max(version),0)+1 into next_version from public.contract_manual_simulations where contract_id=requested_contract;
 insert into public.contract_manual_simulations(user_id,contract_id,version,effective_from,ps_rate)
 values(auth.uid(),requested_contract,next_version,(requested_situated_at at time zone 'Europe/Paris')::date,requested_ps_rate);
 end if;
 insert into public.contract_manual_situations(user_id,contract_id,situated_at,gross_eur,fiscal_gain_eur,source_net_eur,source)
 values(auth.uid(),requested_contract,requested_situated_at,requested_gross,requested_gain,requested_source_net,btrim(requested_source)) returning id into saved;
 update public.contracts set valuation_source='manual_situation' where id=requested_contract;
 return saved;
end $$;

create table public.patrimonial_daily_captures (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(auth_user_id),
 business_date date not null, revision integer not null check(revision>0),
 captured_at timestamptz not null default clock_timestamp(),
 claim_token uuid not null unique default gen_random_uuid(),
 lease_until timestamptz not null default clock_timestamp()+interval '5 minutes',
 state text not null default 'running' check(state in ('running','published','failed')),
 engine_version text not null default 'patrimony-history-v1',
 inputs jsonb not null check(jsonb_typeof(inputs)='object'),
 result jsonb check(result is null or jsonb_typeof(result)='object'),
 unique(user_id,business_date,revision),
 check((state='published' and result is not null) or (state<>'published' and result is null))
);

create function private.guard_published_capture() returns trigger language plpgsql set search_path='' as $$
begin
 if old.state='published' then raise exception 'Published history is immutable; create a revision' using errcode='23514'; end if;
 if tg_op='DELETE' then return old; end if;
 return new;
end $$;
create trigger published_capture_immutable before update or delete on public.patrimonial_daily_captures
 for each row execute function private.guard_published_capture();

-- One SQL statement / one MVCC snapshot. Copy data, not only mutable IDs.
create function private.daily_capture_inputs() returns jsonb language sql stable security definer set search_path='' as $$
 select jsonb_build_object(
 'userId',(select auth_user_id from private.application_principal),
 'envelopeTypes',coalesce((select jsonb_agg(to_jsonb(t)) from public.envelope_types t),'[]'),
 'contracts',coalesce((select jsonb_agg(to_jsonb(c)) from public.contracts c where c.user_id=(select auth_user_id from private.application_principal)),'[]'),
 'positions',coalesce((select jsonb_agg(to_jsonb(p)) from public.positions p where p.user_id=(select auth_user_id from private.application_principal) and p.is_active),'[]'),
 'cashBalances',coalesce((select jsonb_agg(to_jsonb(c)) from public.cash_balances c where c.user_id=(select auth_user_id from private.application_principal)),'[]'),
 'cashFlows',coalesce((select jsonb_agg(to_jsonb(f)) from public.cash_flows f where f.user_id=(select auth_user_id from private.application_principal) and f.kind in ('contribution','withdrawal')),'[]'),
 'assets',coalesce((select jsonb_agg(to_jsonb(a)) from public.assets a where a.owner_user_id=(select auth_user_id from private.application_principal)),'[]'),
 'prices',coalesce((select jsonb_agg(to_jsonb(p)) from public.asset_prices p where p.observed_at<=statement_timestamp() and (p.obtained_at is null or p.obtained_at<=statement_timestamp())),'[]'),
 'currentFxRates',coalesce((select jsonb_agg(to_jsonb(f)) from public.fx_rates f where f.obtained_at<=statement_timestamp() and f.requested_on<=(statement_timestamp() at time zone 'Europe/Paris')::date),'[]'),
 'historicalFxRates',coalesce((select jsonb_agg(to_jsonb(f)) from public.fx_rates f where f.obtained_at<=statement_timestamp()),'[]'),
 'fiscalRules',coalesce((select jsonb_agg(to_jsonb(f)) from public.fiscal_rules f where f.active and f.status='verified' and f.fiscal_regime_id is not null and (f.owner_user_id is null or f.owner_user_id=(select auth_user_id from private.application_principal))),'[]'),
 'fiscalPreferences',coalesce((select jsonb_agg(to_jsonb(p)) from public.user_fiscal_regime_preferences p where p.user_id=(select auth_user_id from private.application_principal)),'[]'),
 'manualSituations',coalesce((select jsonb_agg(to_jsonb(s)) from public.contract_manual_situations s where s.user_id=(select auth_user_id from private.application_principal)),'[]'),
 'manualSimulations',coalesce((select jsonb_agg(to_jsonb(s)) from public.contract_manual_simulations s where s.user_id=(select auth_user_id from private.application_principal)),'[]'),
 'positionSnapshots',coalesce((select jsonb_agg(to_jsonb(s)) from public.position_snapshots s where s.user_id=(select auth_user_id from private.application_principal) and s.valued_at<=statement_timestamp()),'[]'),
 'exposures',coalesce((select jsonb_agg(to_jsonb(e)) from public.asset_exposure_rows e join public.assets a on a.id=e.asset_id where e.stage='effective' and a.owner_user_id=(select auth_user_id from private.application_principal)),'[]'),
 'sectors',coalesce((select jsonb_agg(to_jsonb(s)) from public.sectors s),'[]'),
 'activities',coalesce((select jsonb_agg(to_jsonb(s)) from public.sector_activities s),'[]'),
 'countries',coalesce((select jsonb_agg(to_jsonb(s)) from public.exposure_countries s),'[]'),
 'regions',coalesce((select jsonb_agg(to_jsonb(s)) from public.geographic_regions s),'[]'),
 'themes',coalesce((select jsonb_agg(to_jsonb(t)) from public.themes t where t.owner_user_id=(select auth_user_id from private.application_principal)),'[]'),
 'themeExposures',coalesce((select jsonb_agg(jsonb_build_object('asset_id',e.asset_id,'theme_id',e.theme_id,'weight_percent',e.weight_percent,'data_date',s.data_date,'source',s.source,'origin',s.origin,'updated_at',s.updated_at))
 from public.asset_theme_exposures e join public.asset_theme_exposure_sets s on s.asset_id=e.asset_id and s.stage=e.stage
 join public.assets a on a.id=e.asset_id where e.stage='effective' and a.owner_user_id=(select auth_user_id from private.application_principal)),'[]')
 );
$$;

create function public.claim_patrimonial_daily_capture(requested_date date, requested_revision boolean default false)
 returns jsonb language plpgsql security definer set search_path='' as $$
declare old public.patrimonial_daily_captures%rowtype; saved public.patrimonial_daily_captures%rowtype; principal uuid;
begin
 select auth_user_id into principal from private.application_principal;
 if requested_date is null or requested_date<>(clock_timestamp() at time zone 'Europe/Paris')::date then
 raise exception 'Cannot reconstruct a missing past day' using errcode='22023'; end if;
 perform pg_advisory_xact_lock(hashtextextended('patrimonial-capture:'||requested_date::text,0));
 select * into old from public.patrimonial_daily_captures where user_id=principal and business_date=requested_date order by revision desc limit 1 for update;
 if found then
 if old.state='running' and old.lease_until>clock_timestamp() then return null; end if;
 if old.state='published' and not requested_revision then return null; end if;
 if old.state<>'published' then
 -- Resume the SAME archived inputs; never replace yesterday's state with today.
 update public.patrimonial_daily_captures set state='running',claim_token=gen_random_uuid(),lease_until=clock_timestamp()+interval '5 minutes'
 where id=old.id returning * into saved;
 return to_jsonb(saved);
 end if;
 end if;
 insert into public.patrimonial_daily_captures(user_id,business_date,revision,captured_at,inputs)
 values(principal,requested_date,coalesce(old.revision,0)+1,statement_timestamp(),private.daily_capture_inputs()) returning * into saved;
 return to_jsonb(saved);
end $$;

create function public.fail_patrimonial_daily_capture(requested_token uuid)
 returns void language sql security definer set search_path='' as $$
 update public.patrimonial_daily_captures set state='failed'
 where claim_token=requested_token and state='running';
$$;

create function public.publish_patrimonial_daily_capture(requested_token uuid, requested_result jsonb)
 returns void language plpgsql security definer set search_path='' as $$
begin
 if requested_result is null or jsonb_typeof(requested_result)<>'object' or requested_result->>'engineVersion'<>'patrimony-history-v1' then
 raise exception 'Invalid historical result' using errcode='23514'; end if;
 update public.patrimonial_daily_captures set state='published',result=requested_result
 where claim_token=requested_token and state='running' and lease_until>clock_timestamp();
 if not found then raise exception 'Capture claim unavailable' using errcode='40001'; end if;
end $$;

-- Import staging is historical evidence, never implicit current holdings.
create table public.patrimonial_legacy_sources (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(auth_user_id),
 source_sha256 text not null check(source_sha256~'^[0-9a-f]{64}$'),
 business_date date not null, payload jsonb not null check(jsonb_typeof(payload)='object'),
 imported_at timestamptz not null default clock_timestamp(), unique(user_id,source_sha256,business_date)
);
create table public.patrimonial_legacy_account_maps (
 user_id uuid not null references public.profiles(auth_user_id),
 source_sha256 text not null check(source_sha256~'^[0-9a-f]{64}$'),
 source_key text not null,
 contract_id uuid references public.contracts(id) on delete set null,
 primary key(user_id,source_sha256,source_key)
);

do $$ declare tab text; begin
 foreach tab in array array['contract_manual_situations','contract_manual_simulations','patrimonial_daily_captures','patrimonial_legacy_sources','patrimonial_legacy_account_maps'] loop
 execute format('alter table public.%I enable row level security',tab);
 execute format('alter table public.%I force row level security',tab);
 execute format('revoke all on public.%I from public,anon,authenticated',tab);
 execute format('grant select on public.%I to authenticated',tab);
 execute format('create policy principal_read on public.%I for select to authenticated using(public.is_authorized_user() and user_id=auth.uid())',tab);
 end loop;
end $$;
revoke all on function private.guard_manual_history(),private.daily_capture_inputs() from public,anon,authenticated;
revoke all on function private.guard_manual_contract() from public,anon,authenticated;
revoke all on function private.guard_published_capture() from public,anon,authenticated;
revoke all on function public.save_contract_manual_situation(uuid,timestamptz,numeric,numeric,numeric,text,numeric) from public,anon;
grant execute on function public.save_contract_manual_situation(uuid,timestamptz,numeric,numeric,numeric,text,numeric) to authenticated;
revoke all on function public.claim_patrimonial_daily_capture(date,boolean),public.publish_patrimonial_daily_capture(uuid,jsonb) from public,anon,authenticated;
grant execute on function public.claim_patrimonial_daily_capture(date,boolean),public.publish_patrimonial_daily_capture(uuid,jsonb) to service_role;
revoke all on function public.fail_patrimonial_daily_capture(uuid) from public,anon,authenticated;
grant execute on function public.fail_patrimonial_daily_capture(uuid) to service_role;
grant select,insert on public.patrimonial_legacy_sources to service_role;
grant select,insert on public.patrimonial_legacy_account_maps to service_role;

commit;
