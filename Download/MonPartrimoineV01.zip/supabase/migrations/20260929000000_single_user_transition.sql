-- V12 transition. Never infer the principal from a nickname, email or role.
-- Deployment precondition: an inventoried, verified Auth UUID must be supplied
-- by the database operator in the SAME PostgreSQL session as this migration.
-- The Supabase CLI operator must pass it as a startup option, for example:
--   $dbUrl = 'postgresql://postgres@db.<project-ref>.supabase.co:5432/postgres?sslmode=require&options=-c%20monpatrimoine.principal_id%3D<verified-uuid>'
--   npx supabase db push --db-url $dbUrl --password $env:SUPABASE_DB_PASSWORD
-- This keeps the UUID out of the repository and avoids relying on a separate
-- psql session whose GUC would not be inherited by `supabase db push`.
begin;
create table private.application_principal (
 singleton boolean primary key default true check(singleton),
 auth_user_id uuid not null unique references public.profiles(auth_user_id) on delete restrict
);
alter table private.application_principal enable row level security;
revoke all on private.application_principal from public,anon,authenticated;
do $$ declare principal uuid := nullif(current_setting('monpatrimoine.principal_id',false),'')::uuid; begin
 if principal is null or not exists(select 1 from public.profiles p join auth.users u on u.id=p.auth_user_id where u.id=principal and p.is_active) then
  raise exception 'Verified active Auth principal must be supplied before migration';
 end if;
 insert into private.application_principal values(true,principal);
 -- Never transfer another user's catalogue. Inventory/resolution must precede migration.
 if exists(select 1 from public.assets where owner_user_id is not null and owner_user_id<>principal)
 or exists(select 1 from public.envelope_definitions where owner_user_id is not null and owner_user_id<>principal) then
  raise exception 'Other-owned catalogue data requires an explicit inventory and resolution';
 end if;
end $$;
create function public.is_authorized_user() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from private.application_principal a join public.profiles p on p.auth_user_id=a.auth_user_id
 where a.auth_user_id=auth.uid() and p.is_active);
$$;
revoke all on function public.is_authorized_user() from public,anon;
grant execute on function public.is_authorized_user() to authenticated;
-- Preserve legacy distributions for a controlled one-time import after draft slots exist.
create table private.legacy_sector_overrides as table public.user_asset_sector_exposures;
alter table private.legacy_sector_overrides enable row level security;
revoke all on private.legacy_sector_overrides from public,anon,authenticated;
drop table public.user_asset_sector_exposures;
drop function public.user_asset_sector_status(uuid);
drop function public.enforce_user_sector_total();
-- Policies are rebuilt explicitly, never broadened to all authenticated identities.
do $$ declare p record; begin
 for p in select schemaname,tablename,policyname from pg_policies where schemaname='public' loop
 execute format('drop policy %I on %I.%I',p.policyname,p.schemaname,p.tablename);
 end loop;
end $$;
-- Grant no implicit ownership transfer: only former shared references acquire the principal.
alter table public.envelope_definitions disable trigger envelope_definitions_guard_identity;
update public.envelope_definitions set owner_user_id=(select auth_user_id from private.application_principal) where owner_user_id is null;
alter table public.envelope_definitions enable trigger envelope_definitions_guard_identity;
update public.assets set owner_user_id=(select auth_user_id from private.application_principal) where owner_user_id is null;
-- Existing uniqueness constraints deliberately abort on collisions; no automatic merge.
alter table public.assets drop column is_global;
alter table public.assets alter column owner_user_id set not null;
alter table public.assets alter column owner_user_id set default auth.uid();
alter table public.envelope_definitions alter column owner_user_id set not null;
alter table public.envelope_definitions alter column owner_user_id set default auth.uid();
update public.profiles set interface_preferences=interface_preferences-'workspace';
-- Temporary compatibility role column is inert: no remaining policy uses it.
create or replace function public.is_admin() returns boolean language sql stable security invoker set search_path='' as $$select public.is_authorized_user()$$;
revoke all on function public.is_admin() from public,anon,authenticated;
do $$ declare tab text; col text; begin
 foreach tab in array array['profiles','envelopes','contracts','positions','cash_balances','cash_flows','target_allocations','envelope_snapshots','position_snapshots','cash_balance_snapshots','assets','envelope_definitions'] loop
 col:=case when tab='profiles' then 'auth_user_id' when tab in ('assets','envelope_definitions') then 'owner_user_id' else 'user_id' end;
 execute format('create policy principal_owner on public.%I for all to authenticated using(public.is_authorized_user() and %I=auth.uid()) with check(public.is_authorized_user() and %I=auth.uid())',tab,col,col);
 end loop;
end $$;
revoke insert,delete on public.profiles from authenticated;
create policy principal_read on public.sectors for select to authenticated using(public.is_authorized_user());
create policy principal_read on public.fiscal_rules for select to authenticated using(public.is_authorized_user());
create policy principal_insert on public.fiscal_rules for insert to authenticated with check(public.is_authorized_user());
create policy principal_update on public.fiscal_rules for update to authenticated using(public.is_authorized_user()) with check(public.is_authorized_user());
create policy principal_versions on public.envelope_definition_versions for all to authenticated
 using(public.is_authorized_user() and exists(select 1 from public.envelope_definitions d where d.id=envelope_definition_id))
 with check(public.is_authorized_user() and exists(select 1 from public.envelope_definitions d where d.id=envelope_definition_id));
create policy principal_exposures on public.asset_sector_exposures for all to authenticated
 using(public.is_authorized_user() and exists(select 1 from public.assets a where a.id=asset_id))
 with check(public.is_authorized_user() and exists(select 1 from public.assets a where a.id=asset_id));
create policy principal_prices_read on public.asset_prices for select to authenticated
 using(public.is_authorized_user() and exists(select 1 from public.assets a where a.id=asset_id) and (origin='automatic' or user_id=auth.uid()));
create policy principal_prices_write on public.asset_prices for all to authenticated
 using(public.is_authorized_user() and origin='manual' and user_id=auth.uid())
 with check(public.is_authorized_user() and origin='manual' and user_id=auth.uid());

create or replace function public.validate_asset_access()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  asset_owner uuid;
begin
  select owner_user_id into asset_owner from public.assets where id = new.asset_id;
  if not found or (asset_owner is distinct from new.user_id) then
    raise exception 'asset is not available to this user';
  end if;
  return new;
end;
$$;

create or replace function public.validate_target_asset_access()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  asset_owner uuid;
begin
  if new.target_asset_id is null then return new; end if;
  select owner_user_id into asset_owner from public.assets where id = new.target_asset_id;
  if not found or (asset_owner is distinct from new.user_id) then
    raise exception 'target asset is not available to this user';
  end if;
  return new;
end;
$$;

create or replace function public.validate_asset_price_access()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  asset_owner uuid;
begin
  select owner_user_id into asset_owner from public.assets where id = new.asset_id;
  if not found
    or (new.origin = 'manual' and asset_owner is distinct from new.user_id) then
    raise exception 'asset is not available for this price';
  end if;
  return new;
end;
$$;

create or replace function public.validate_envelope_definition_use()
returns trigger language plpgsql security definer set search_path = '' as $$
declare definition_owner uuid; definition_active boolean;
begin
  if tg_op = 'UPDATE' then
    if (old.envelope_definition_id is not null or new.envelope_definition_id is not null)
       and new.envelope_type_code is distinct from old.envelope_type_code then
      raise exception 'Legacy provenance is immutable when linked' using errcode = '23514';
    end if;
    if old.envelope_definition_id is not null and new.envelope_definition_id is null then
      raise exception 'Definition detachment is not supported' using errcode = '23514';
    end if;
    if new.envelope_definition_id is not distinct from old.envelope_definition_id then
      return new;
    end if;
  elsif new.envelope_definition_id is not null and new.envelope_type_code is not null then
    raise exception 'New linked envelopes cannot supply legacy classification' using errcode = '23514';
  end if;
  if new.envelope_definition_id is null then return new; end if;
  select owner_user_id, is_active into definition_owner, definition_active
    from public.envelope_definitions where id = new.envelope_definition_id for share;
  if not found or not definition_active or
     (definition_owner is distinct from new.user_id) then
    raise exception 'Definition is unavailable' using errcode = '42501';
  end if;
  return new;
end;
$$;

create or replace function public.guard_linked_fiscal_history()
returns trigger language plpgsql security definer set search_path = '' as $$
declare version_start date; definition_owner uuid;
begin
  if tg_op <> 'INSERT' then
    if old.envelope_definition_version_id is not null then
      raise exception 'linked fiscal history is immutable; create a new version' using errcode = '23514';
    end if;
    if tg_op = 'DELETE' then return old; end if;
  end if;
  if new.envelope_definition_version_id is null then return new; end if;
  select v.valid_from, d.owner_user_id into version_start, definition_owner
    from public.envelope_definition_versions v
    join public.envelope_definitions d on d.id = v.envelope_definition_id
    where v.id = new.envelope_definition_version_id for share of v, d;
  if not found then
    raise exception 'Fiscal version unavailable' using errcode = '23514';
  end if;
  if version_start <= current_date or new.valid_from < version_start then
    raise exception 'fiscal rules must be prepared for a future version' using errcode = '23514';
  end if;
  return new;
end;
$$;

alter function public.create_private_envelope_definition(text,text) rename to create_envelope_definition;
-- Every client-callable definer RPC gets the same explicit gate. Trigger-only
-- functions retain their internal integrity work, but cannot be invoked as RPCs.
do $$ declare f record; definition text; begin
 for f in select p.oid,p.proname,p.prorettype from pg_proc p join pg_namespace n on n.oid=p.pronamespace
 where n.nspname='public' and p.prosecdef and p.proname<>'is_authorized_user' loop
 if f.prorettype='trigger'::regtype then
  execute format('revoke all on function %s from public,anon,authenticated',f.oid::regprocedure);
 elsif f.proname in ('get_ai_configuration','save_ai_configuration','delete_ai_configuration_secret') then
  definition:=pg_get_functiondef(f.oid);
  definition:=regexp_replace(definition,'(?i)begin', E'begin\n  if not public.is_authorized_user() then raise exception ''Access denied'' using errcode=''42501''; end if;');
  execute definition;
 end if;
 end loop;
end $$;
commit;
