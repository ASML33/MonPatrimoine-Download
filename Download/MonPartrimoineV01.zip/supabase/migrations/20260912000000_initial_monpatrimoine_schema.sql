-- MonPatrimoine — Phase 2 initial schema
-- This migration is intentionally self-contained and is designed for Supabase
-- PostgreSQL.  It contains no credentials and may be applied with `supabase db push`.

create extension if not exists pgcrypto with schema extensions;
create extension if not exists citext with schema extensions;

create type public.price_origin as enum ('automatic', 'manual');
create type public.cash_flow_kind as enum ('contribution', 'withdrawal', 'transfer');
create type public.allocation_scope_kind as enum ('global', 'envelope');
create type public.allocation_target_kind as enum ('envelope', 'asset_class', 'asset');

create function public.set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = timezone('utc', now());
  return new;
end;
$$;

create table public.profiles (
  id uuid primary key default gen_random_uuid(),
  auth_user_id uuid not null unique references auth.users(id) on delete restrict on update cascade,
  nickname extensions.citext not null unique check (char_length(nickname) between 3 and 40),
  email extensions.citext not null unique,
  profile_kind text not null default 'individual' check (char_length(profile_kind) between 1 and 50),
  preferences jsonb not null default '{}'::jsonb check (jsonb_typeof(preferences) = 'object'),
  interface_preferences jsonb not null default '{}'::jsonb check (jsonb_typeof(interface_preferences) = 'object'),
  strategy_parameters jsonb not null default '{}'::jsonb check (jsonb_typeof(strategy_parameters) = 'object'),
  ai_settings jsonb not null default '{}'::jsonb check (jsonb_typeof(ai_settings) = 'object'),
  -- Reserved only to preserve the undocumented legacy "-1" notion.  No meaning is assigned here.
  legacy_metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(legacy_metadata) = 'object'),
  is_active boolean not null default true,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now())
);

create table public.envelopes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(auth_user_id) on delete restrict on update cascade,
  name text not null check (char_length(btrim(name)) between 1 and 120),
  -- Intentionally a code rather than an enum: PEA, CTO, AV, bank account, etc. remain extensible.
  envelope_type_code text not null check (envelope_type_code ~ '^[a-z0-9_-]{1,50}$'),
  currency_code char(3) not null default 'EUR' check (currency_code ~ '^[A-Z]{3}$'),
  is_active boolean not null default true,
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  unique (id, user_id),
  unique (user_id, name)
);

create table public.contracts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(auth_user_id) on delete restrict on update cascade,
  envelope_id uuid not null,
  name text not null check (char_length(btrim(name)) between 1 and 120),
  institution_name text,
  account_reference text,
  is_active boolean not null default true,
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  unique (id, user_id),
  unique (envelope_id, name),
  foreign key (envelope_id, user_id) references public.envelopes(id, user_id) on delete restrict on update cascade
);

create table public.assets (
  id uuid primary key default gen_random_uuid(),
  -- NULL means a globally shared catalogue asset; otherwise it is private to this user.
  owner_user_id uuid references public.profiles(auth_user_id) on delete restrict on update cascade,
  name text not null check (char_length(btrim(name)) between 1 and 200),
  asset_type_code text not null check (asset_type_code ~ '^[a-z0-9_-]{1,50}$'),
  symbol text,
  isin char(12),
  currency_code char(3) not null default 'EUR' check (currency_code ~ '^[A-Z]{3}$'),
  valuation_mode text not null default 'market_price' check (valuation_mode in ('market_price', 'manual', 'not_applicable')),
  price_source text,
  is_active boolean not null default true,
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  check (isin is null or isin ~ '^[A-Z0-9]{12}$')
);

create table public.positions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(auth_user_id) on delete restrict on update cascade,
  contract_id uuid not null,
  asset_id uuid not null references public.assets(id) on delete restrict on update cascade,
  quantity numeric(24, 8) not null check (quantity >= 0),
  average_cost_per_unit numeric(24, 8) check (average_cost_per_unit >= 0),
  cost_currency_code char(3) not null default 'EUR' check (cost_currency_code ~ '^[A-Z]{3}$'),
  opened_on date,
  is_active boolean not null default true,
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  unique (id, user_id),
  unique (contract_id, asset_id),
  foreign key (contract_id, user_id) references public.contracts(id, user_id) on delete restrict on update cascade
);

create table public.cash_balances (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(auth_user_id) on delete restrict on update cascade,
  contract_id uuid not null,
  currency_code char(3) not null check (currency_code ~ '^[A-Z]{3}$'),
  amount numeric(24, 8) not null check (amount >= 0),
  as_of timestamptz not null default timezone('utc', now()),
  metadata jsonb not null default '{}'::jsonb check (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  unique (id, user_id),
  unique (contract_id, currency_code),
  foreign key (contract_id, user_id) references public.contracts(id, user_id) on delete restrict on update cascade
);

create table public.cash_flows (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(auth_user_id) on delete restrict on update cascade,
  kind public.cash_flow_kind not null,
  destination_contract_id uuid,
  source_contract_id uuid,
  amount numeric(24, 8) not null check (amount > 0),
  currency_code char(3) not null check (currency_code ~ '^[A-Z]{3}$'),
  occurred_at timestamptz not null,
  note text,
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  check (
    (kind = 'contribution' and destination_contract_id is not null and source_contract_id is null) or
    (kind = 'withdrawal' and source_contract_id is not null and destination_contract_id is null) or
    (kind = 'transfer' and source_contract_id is not null and destination_contract_id is not null and source_contract_id <> destination_contract_id)
  ),
  foreign key (destination_contract_id, user_id) references public.contracts(id, user_id) on delete restrict on update cascade,
  foreign key (source_contract_id, user_id) references public.contracts(id, user_id) on delete restrict on update cascade
);

create table public.asset_prices (
  id uuid primary key default gen_random_uuid(),
  asset_id uuid not null references public.assets(id) on delete restrict on update cascade,
  -- user_id is populated only for a user's manual override.
  user_id uuid references public.profiles(auth_user_id) on delete restrict on update cascade,
  origin public.price_origin not null,
  price numeric(24, 8) not null check (price >= 0),
  currency_code char(3) not null check (currency_code ~ '^[A-Z]{3}$'),
  observed_at timestamptz not null,
  obtained_at timestamptz not null default timezone('utc', now()),
  source_name text,
  created_at timestamptz not null default timezone('utc', now()),
  check ((origin = 'automatic' and user_id is null) or (origin = 'manual' and user_id is not null))
);

create table public.target_allocations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(auth_user_id) on delete restrict on update cascade,
  scope_kind public.allocation_scope_kind not null,
  scope_envelope_id uuid,
  target_kind public.allocation_target_kind not null,
  target_envelope_id uuid,
  target_asset_type_code text,
  target_asset_id uuid references public.assets(id) on delete restrict on update cascade,
  target_percent numeric(5, 2) not null check (target_percent > 0 and target_percent <= 100),
  created_at timestamptz not null default timezone('utc', now()),
  updated_at timestamptz not null default timezone('utc', now()),
  check (
    (scope_kind = 'global' and scope_envelope_id is null) or
    (scope_kind = 'envelope' and scope_envelope_id is not null)
  ),
  check (
    (target_kind = 'envelope' and target_envelope_id is not null and target_asset_type_code is null and target_asset_id is null and scope_kind = 'global') or
    (target_kind = 'asset_class' and target_envelope_id is null and target_asset_type_code is not null and target_asset_id is null) or
    (target_kind = 'asset' and target_envelope_id is null and target_asset_type_code is null and target_asset_id is not null)
  ),
  foreign key (scope_envelope_id, user_id) references public.envelopes(id, user_id) on delete restrict on update cascade,
  foreign key (target_envelope_id, user_id) references public.envelopes(id, user_id) on delete restrict on update cascade
);

create table public.envelope_snapshots (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(auth_user_id) on delete restrict on update cascade,
  envelope_id uuid not null,
  valued_at timestamptz not null,
  total_value numeric(24, 8) not null check (total_value >= 0),
  currency_code char(3) not null check (currency_code ~ '^[A-Z]{3}$'),
  created_at timestamptz not null default timezone('utc', now()),
  unique (envelope_id, valued_at),
  foreign key (envelope_id, user_id) references public.envelopes(id, user_id) on delete restrict on update cascade
);

create table public.position_snapshots (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(auth_user_id) on delete restrict on update cascade,
  position_id uuid not null,
  valued_at timestamptz not null,
  quantity numeric(24, 8) not null check (quantity >= 0),
  unit_price numeric(24, 8) check (unit_price >= 0),
  market_value numeric(24, 8) not null check (market_value >= 0),
  currency_code char(3) not null check (currency_code ~ '^[A-Z]{3}$'),
  created_at timestamptz not null default timezone('utc', now()),
  unique (position_id, valued_at),
  foreign key (position_id, user_id) references public.positions(id, user_id) on delete restrict on update cascade
);

create table public.cash_balance_snapshots (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(auth_user_id) on delete restrict on update cascade,
  cash_balance_id uuid not null,
  valued_at timestamptz not null,
  amount numeric(24, 8) not null check (amount >= 0),
  created_at timestamptz not null default timezone('utc', now()),
  unique (cash_balance_id, valued_at),
  foreign key (cash_balance_id, user_id) references public.cash_balances(id, user_id) on delete restrict on update cascade
);

-- These indexes support the expected per-user dashboard/history queries.  PKs,
-- unique constraints and foreign keys already provide their own useful indexes.
create index envelopes_user_active_idx on public.envelopes (user_id, is_active);
create index contracts_envelope_active_idx on public.contracts (envelope_id, is_active);
create index positions_contract_active_idx on public.positions (contract_id, is_active);
create unique index assets_isin_unique_idx on public.assets (isin) where isin is not null;
create unique index assets_owner_symbol_unique_idx on public.assets (owner_user_id, symbol) where symbol is not null;
create index asset_prices_asset_observed_idx on public.asset_prices (asset_id, observed_at desc);
create index asset_prices_manual_asset_user_observed_idx on public.asset_prices (asset_id, user_id, observed_at desc) where origin = 'manual';
create index target_allocations_scope_idx on public.target_allocations (user_id, scope_kind, scope_envelope_id);
create index envelope_snapshots_history_idx on public.envelope_snapshots (envelope_id, valued_at desc);
create index position_snapshots_history_idx on public.position_snapshots (position_id, valued_at desc);
create index cash_balance_snapshots_history_idx on public.cash_balance_snapshots (cash_balance_id, valued_at desc);

create function public.validate_asset_access()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  asset_owner uuid;
begin
  select owner_user_id into asset_owner from public.assets where id = new.asset_id;
  if not found or (asset_owner is not null and asset_owner <> new.user_id) then
    raise exception 'asset is not available to this user';
  end if;
  return new;
end;
$$;

create trigger positions_validate_asset_access before insert or update of asset_id, user_id on public.positions
for each row execute function public.validate_asset_access();

create function public.validate_target_asset_access()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  asset_owner uuid;
begin
  if new.target_asset_id is null then return new; end if;
  select owner_user_id into asset_owner from public.assets where id = new.target_asset_id;
  if not found or (asset_owner is not null and asset_owner <> new.user_id) then
    raise exception 'target asset is not available to this user';
  end if;
  return new;
end;
$$;

create trigger target_allocations_validate_asset_access before insert or update of target_asset_id, user_id on public.target_allocations
for each row execute function public.validate_target_asset_access();

create function public.validate_asset_price_access()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  asset_owner uuid;
begin
  select owner_user_id into asset_owner from public.assets where id = new.asset_id;
  if not found
    or (new.origin = 'automatic' and asset_owner is not null)
    or (new.origin = 'manual' and asset_owner is not null and asset_owner <> new.user_id) then
    raise exception 'asset is not available for this price';
  end if;
  return new;
end;
$$;

create trigger asset_prices_validate_asset_access before insert or update of asset_id, user_id, origin on public.asset_prices
for each row execute function public.validate_asset_price_access();

create function public.enforce_target_allocation_total()
returns trigger
language plpgsql
set search_path = public
as $$
declare
  total numeric(7,2);
begin
  select coalesce(sum(target_percent), 0) into total
  from public.target_allocations
  where user_id = new.user_id
    and scope_kind = new.scope_kind
    and scope_envelope_id is not distinct from new.scope_envelope_id;
  if total > 100 then
    raise exception 'target allocations cannot exceed 100%% for one scope';
  end if;
  return null;
end;
$$;

create constraint trigger target_allocations_total_check
after insert or update on public.target_allocations
deferrable initially deferred
for each row execute function public.enforce_target_allocation_total();

create trigger profiles_set_updated_at before update on public.profiles for each row execute function public.set_updated_at();
create trigger envelopes_set_updated_at before update on public.envelopes for each row execute function public.set_updated_at();
create trigger contracts_set_updated_at before update on public.contracts for each row execute function public.set_updated_at();
create trigger assets_set_updated_at before update on public.assets for each row execute function public.set_updated_at();
create trigger positions_set_updated_at before update on public.positions for each row execute function public.set_updated_at();
create trigger cash_balances_set_updated_at before update on public.cash_balances for each row execute function public.set_updated_at();
create trigger cash_flows_set_updated_at before update on public.cash_flows for each row execute function public.set_updated_at();
create trigger target_allocations_set_updated_at before update on public.target_allocations for each row execute function public.set_updated_at();

-- RLS is forced so table owners cannot accidentally bypass it when using the
-- authenticated role.  The Supabase service role still bypasses RLS by design.
alter table public.profiles enable row level security;
alter table public.envelopes enable row level security;
alter table public.contracts enable row level security;
alter table public.assets enable row level security;
alter table public.positions enable row level security;
alter table public.cash_balances enable row level security;
alter table public.cash_flows enable row level security;
alter table public.asset_prices enable row level security;
alter table public.target_allocations enable row level security;
alter table public.envelope_snapshots enable row level security;
alter table public.position_snapshots enable row level security;
alter table public.cash_balance_snapshots enable row level security;

alter table public.profiles force row level security;
alter table public.envelopes force row level security;
alter table public.contracts force row level security;
alter table public.assets force row level security;
alter table public.positions force row level security;
alter table public.cash_balances force row level security;
alter table public.cash_flows force row level security;
alter table public.asset_prices force row level security;
alter table public.target_allocations force row level security;
alter table public.envelope_snapshots force row level security;
alter table public.position_snapshots force row level security;
alter table public.cash_balance_snapshots force row level security;

create policy profiles_self on public.profiles for all to authenticated
using (auth.uid() = auth_user_id) with check (auth.uid() = auth_user_id);

create policy envelopes_owner on public.envelopes for all to authenticated
using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy contracts_owner on public.contracts for all to authenticated
using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy positions_owner on public.positions for all to authenticated
using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy cash_balances_owner on public.cash_balances for all to authenticated
using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy cash_flows_owner on public.cash_flows for all to authenticated
using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy target_allocations_owner on public.target_allocations for all to authenticated
using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy envelope_snapshots_owner on public.envelope_snapshots for all to authenticated
using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy position_snapshots_owner on public.position_snapshots for all to authenticated
using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy cash_balance_snapshots_owner on public.cash_balance_snapshots for all to authenticated
using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy assets_read_catalogue_or_own on public.assets for select to authenticated
using ((owner_user_id is null and is_active) or auth.uid() = owner_user_id);
create policy assets_insert_own on public.assets for insert to authenticated
with check (auth.uid() = owner_user_id);
create policy assets_update_own on public.assets for update to authenticated
using (auth.uid() = owner_user_id) with check (auth.uid() = owner_user_id);
create policy assets_delete_own on public.assets for delete to authenticated
using (auth.uid() = owner_user_id);

create policy asset_prices_read_catalogue_or_own_manual on public.asset_prices for select to authenticated
using (
  (origin = 'automatic' and exists (
    select 1 from public.assets
    where assets.id = asset_prices.asset_id and assets.owner_user_id is null and assets.is_active
  ))
  or (origin = 'manual' and auth.uid() = user_id)
);
create policy asset_prices_insert_manual_own on public.asset_prices for insert to authenticated
with check (origin = 'manual' and auth.uid() = user_id);
create policy asset_prices_update_manual_own on public.asset_prices for update to authenticated
using (origin = 'manual' and auth.uid() = user_id)
with check (origin = 'manual' and auth.uid() = user_id);
create policy asset_prices_delete_manual_own on public.asset_prices for delete to authenticated
using (origin = 'manual' and auth.uid() = user_id);

grant usage on schema public to authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant usage, select on all sequences in schema public to authenticated;
revoke all on all tables in schema public from anon;
revoke all on all sequences in schema public from anon;
