begin;
set local lock_timeout='5s';
set local statement_timeout='30s';

-- Transaction-bound, exact row permits. Only the checked RPCs own this table.
create table private.property_write_guards(tx bigint not null,entity text not null,id uuid not null,before_hash text,after_hash text not null,primary key(tx,entity,id));
revoke all on private.property_write_guards from public,anon,authenticated,service_role;
create table public.property_consolidations(id uuid primary key,user_id uuid not null references public.profiles(auth_user_id),contract_id uuid not null references public.contracts(id),recorded_at timestamptz not null default clock_timestamp(),before_image jsonb not null,after_image jsonb not null,source_hash text not null);
alter table public.property_consolidations enable row level security;
alter table public.property_consolidations force row level security;
create policy property_consolidations_read on public.property_consolidations for select to authenticated using(user_id=auth.uid() and public.is_authorized_user());
revoke all on public.property_consolidations from public,anon,authenticated,service_role;
grant select on public.property_consolidations to authenticated;

create function private.property_permitted(entity_name text,before_row jsonb,after_row jsonb) returns boolean language sql stable security definer set search_path='' as $$
 select auth.uid() is not null and public.is_authorized_user() and exists(select 1 from private.property_write_guards g where g.tx=txid_current() and g.entity=entity_name and g.id=(after_row->>'id')::uuid and g.before_hash is not distinct from case when before_row is null then null else md5((before_row-'updated_at')::text) end and g.after_hash=md5((after_row-'updated_at')::text));
$$;
revoke all on function private.property_permitted(text,jsonb,jsonb) from public,anon,authenticated,service_role;

-- Extend the existing identity guard; no trigger is disabled and no caller flag
-- or schema privilege grants a free transfer. All other behavior stays exact.
do $$declare definition text;begin
 definition:=pg_get_functiondef('public.guard_position_observations()'::regprocedure);
 definition:=replace(definition,'begin'||chr(10)||' if tg_op=', 'begin'||chr(10)||' if tg_op<>''DELETE'' and private.property_permitted(''position'',case when tg_op=''UPDATE'' then to_jsonb(old) else null end,to_jsonb(new)) then return new;end if;'||chr(10)||' if tg_op=');
 if definition=pg_get_functiondef('public.guard_position_observations()'::regprocedure) then raise exception 'Unexpected position guard definition';end if;
 -- The permit helper is private: the trigger itself checks under its owner.
 definition:=replace(definition,'LANGUAGE plpgsql','LANGUAGE plpgsql SECURITY DEFINER');
 execute definition;
end$$;

create function private.guard_property_rows() returns trigger language plpgsql security definer set search_path='' as $$
declare approved boolean; oldj jsonb;newj jsonb;
begin
 oldj:=case when tg_op in('UPDATE','DELETE') then to_jsonb(old) end;newj:=case when tg_op<>'DELETE' then to_jsonb(new) end;
 approved:=tg_op<>'DELETE' and private.property_permitted(case when tg_table_name='positions' then 'position' else 'contract' end,oldj,newj);
 if approved then return new;end if;
 if tg_table_name='contracts' then
  if oldj#>>'{metadata,property_replaced_by}' is not null or oldj#>'{metadata,property_consolidation}' is distinct from newj#>'{metadata,property_consolidation}' or oldj#>'{metadata,property_replaced_by}' is distinct from newj#>'{metadata,property_replaced_by}' then raise exception 'Controlled consolidation required' using errcode='23514';end if;
 else
  if tg_op<>'DELETE' and exists(select 1 from public.assets where id=new.asset_id and asset_type_code='real_estate') and (tg_op='INSERT' or (old.quantity,old.average_cost_per_unit,old.cost_currency_code,old.is_active) is distinct from (new.quantity,new.average_cost_per_unit,new.cost_currency_code,new.is_active)) then raise exception 'Property totals never use a title holding editor' using errcode='23514';end if;
  if oldj#>'{metadata,property_valuations}' is not null and (tg_op='DELETE' or oldj#>'{metadata,property_valuations}' is distinct from newj#>'{metadata,property_valuations}' or (oldj-'metadata'-'updated_at') is distinct from (newj-'metadata'-'updated_at')) then raise exception 'Controlled total valuation required' using errcode='23514';end if;
  if oldj#>'{metadata,property_valuations}' is distinct from newj#>'{metadata,property_valuations}' then raise exception 'Controlled total valuation required' using errcode='23514';end if;
  if tg_op='INSERT' and exists(select 1 from public.assets where id=new.asset_id and asset_type_code='real_estate') then raise exception 'Property valuation preview required' using errcode='23514';end if;
 end if;
 if tg_op='DELETE' then return old;end if;return new;
end$$;
create trigger positions_02_property_guard before insert or update or delete on public.positions for each row execute function private.guard_property_rows();
create trigger contracts_02_property_guard before insert or update or delete on public.contracts for each row execute function private.guard_property_rows();
revoke all on function private.guard_property_rows() from public,anon,authenticated,service_role;

create function private.property_sources_hash() returns text language sql stable security definer set search_path='' as $$
 select md5(coalesce((select jsonb_agg(jsonb_build_array(id,revision,state,inputs,result) order by id)::text from public.patrimonial_daily_captures where user_id=auth.uid()),'')||coalesce((select jsonb_agg(jsonb_build_array(id,source_sha256,payload) order by id)::text from public.patrimonial_legacy_sources where user_id=auth.uid()),'')||coalesce((select jsonb_agg(to_jsonb(f) order by id)::text from public.fx_rates f),''));
$$;
revoke all on function private.property_sources_hash() from public,anon,authenticated,service_role;

create function public.preview_property_consolidation(requested_positions uuid[],requested_name text) returns jsonb language plpgsql security definer set search_path='' as $$
declare p public.positions;c public.contracts;members jsonb:='[]';before_image jsonb:='[]';source_hash text;count_ids int;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 select count(distinct x) into count_ids from unnest(requested_positions) x;
 if count_ids<1 or count_ids<>cardinality(requested_positions) or btrim(requested_name)='' or exists(select 1 from public.contracts where user_id=auth.uid() and lower(name)=lower(btrim(requested_name))) then raise exception 'Invalid consolidation' using errcode='22023';end if;
 for p in select * from public.positions where id=any(requested_positions) and user_id=auth.uid() order by id loop
  select * into c from public.contracts where id=p.contract_id and user_id=auth.uid();
  if not c.is_active or c.valuation_source<>'positions' or c.metadata ? 'property_replaced_by' or p.metadata ? 'position_observations' or p.metadata ? 'property_valuations' or not p.is_active or p.quantity<>1 or p.average_cost_per_unit is not null
   or not exists(select 1 from public.envelope_types where id=c.envelope_type_id and code='immobilier')
   or not exists(select 1 from public.assets where id=p.asset_id and owner_user_id=auth.uid() and asset_type_code='real_estate' and valuation_mode='manual' and is_active)
   or (select count(*) from public.positions where contract_id=c.id)<>1
   or exists(select 1 from public.cash_balances where contract_id=c.id)
   or exists(select 1 from public.cash_flows where source_contract_id=c.id or destination_contract_id=c.id)
   or exists(select 1 from public.contract_manual_situations where contract_id=c.id)
   or exists(select 1 from public.contract_manual_simulations where contract_id=c.id)
   or exists(select 1 from public.target_allocations where target_contract_id=c.id or target_asset_id=p.asset_id or target_envelope_type_id=c.envelope_type_id)
   or exists(select 1 from public.asset_prices where asset_id=p.asset_id)
   or not exists(select 1 from public.position_snapshots where position_id=p.id)
   or exists(select 1 from public.position_snapshots where position_id=p.id group by (valued_at at time zone 'Europe/Paris')::date having count(*)>1) then raise exception 'Consolidation dependency requires reconciliation' using errcode='23514';end if;
  members:=members||jsonb_build_array(jsonb_build_object('sourceContractId',c.id,'positionId',p.id,'assetId',p.asset_id));
  before_image:=before_image||jsonb_build_array(jsonb_build_object('contract',to_jsonb(c),'position',to_jsonb(p),'asset',(select to_jsonb(a) from public.assets a where a.id=p.asset_id),'snapshots',(select jsonb_agg(to_jsonb(s) order by valued_at) from public.position_snapshots s where s.position_id=p.id),'mappings',(select jsonb_agg(to_jsonb(m)) from public.patrimonial_legacy_account_maps m where m.contract_id=c.id)));
 end loop;
 if jsonb_array_length(members)<>count_ids then raise exception 'Position unavailable' using errcode='42501';end if;
 source_hash:=private.property_sources_hash();
 return jsonb_build_object('members',members,'before',before_image,'sourceHash',source_hash,'token',md5(before_image::text||source_hash||btrim(requested_name)));
end$$;

create function public.apply_property_consolidation(requested_positions uuid[],requested_name text,expected_token text,operation_id uuid) returns uuid language plpgsql security definer set search_path='' as $$
declare plan jsonb;cid uuid;typeid uuid;member jsonb;p public.positions;c public.contracts;newj jsonb;entries jsonb;after_image jsonb;existing public.property_consolidations;stamp timestamptz:=clock_timestamp();
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 perform pg_advisory_xact_lock(hashtextextended(auth.uid()::text||':property',0));
 select * into existing from public.property_consolidations where id=operation_id and user_id=auth.uid();
 if found then if existing.before_image->>'token' is distinct from expected_token or existing.before_image->'request' is distinct from to_jsonb(requested_positions) or existing.before_image->>'name' is distinct from btrim(requested_name) then raise exception 'Different replay' using errcode='40001';end if;return existing.contract_id;end if;
 lock table public.positions,public.contracts,public.position_snapshots,public.target_allocations,public.cash_balances,public.cash_flows,public.contract_manual_situations,public.contract_manual_simulations,public.patrimonial_legacy_account_maps,public.assets,public.asset_prices in share row exclusive mode;
 lock table public.patrimonial_daily_captures,public.patrimonial_legacy_sources,public.fx_rates in share mode;
 plan:=public.preview_property_consolidation(requested_positions,requested_name);
 if plan->>'token' is distinct from expected_token then raise exception 'Preview changed' using errcode='40001';end if;
 select id into typeid from public.envelope_types where code='immobilier' and is_active;
 cid:=gen_random_uuid();
 insert into public.contracts(id,user_id,name,envelope_type_id,currency_code,opened_on,dashboard_tile_name) values(cid,auth.uid(),btrim(requested_name),typeid,'EUR',null,'Immobilier');
 select * into c from public.contracts where id=cid;
 newj:=to_jsonb(c)||jsonb_build_object('metadata',c.metadata||jsonb_build_object('property_consolidation',jsonb_build_object('operationId',operation_id,'recordedAt',stamp,'members',plan->'members')));
 insert into private.property_write_guards values(txid_current(),'contract',cid,md5((to_jsonb(c)-'updated_at')::text),md5((newj-'updated_at')::text));
 update public.contracts set metadata=newj->'metadata' where id=cid;
 for member in select value from jsonb_array_elements(plan->'members') loop
  select * into p from public.positions where id=(member->>'positionId')::uuid;
  select jsonb_agg(jsonb_build_object('id',s.id,'version',1,'effectiveOn',(s.valued_at at time zone 'Europe/Paris')::date,'kind','valuation','amount',s.market_value::text,'currency',btrim(s.currency_code),'recordedAt',stamp,'provenance','Reprise technique de snapshot immobilier existant — source originale conservée','origin','recovery','snapshotId',s.id,'originalAt',s.valued_at) order by s.valued_at) into entries from public.position_snapshots s where s.position_id=p.id;
  newj:=to_jsonb(p)||jsonb_build_object('contract_id',cid,'metadata',p.metadata||jsonb_build_object('property_valuations',jsonb_build_object('version',1,'entries',entries,'archived','[]'::jsonb,'receipts','[]'::jsonb)));
  insert into private.property_write_guards values(txid_current(),'position',p.id,md5((to_jsonb(p)-'updated_at')::text),md5((newj-'updated_at')::text));
  update public.positions set contract_id=cid,metadata=newj->'metadata' where id=p.id;
  select * into c from public.contracts where id=(member->>'sourceContractId')::uuid;
  newj:=to_jsonb(c)||jsonb_build_object('is_active',false,'show_on_dashboard',false,'metadata',c.metadata||jsonb_build_object('property_replaced_by',cid));
  insert into private.property_write_guards values(txid_current(),'contract',c.id,md5((to_jsonb(c)-'updated_at')::text),md5((newj-'updated_at')::text));
  update public.contracts set is_active=false,show_on_dashboard=false,metadata=newj->'metadata' where id=c.id;
 end loop;
 select jsonb_build_object('contracts',(select jsonb_agg(to_jsonb(ac) order by ac.id) from public.contracts ac where ac.id=cid or ac.id in(select (m->>'sourceContractId')::uuid from jsonb_array_elements(plan->'members') m)),'positions',(select jsonb_agg(to_jsonb(ap) order by ap.id) from public.positions ap where ap.id=any(requested_positions))) into after_image;
 insert into public.property_consolidations(id,user_id,contract_id,before_image,after_image,source_hash) values(operation_id,auth.uid(),cid,plan||jsonb_build_object('request',to_jsonb(requested_positions),'name',btrim(requested_name)),after_image,plan->>'sourceHash');
 delete from private.property_write_guards where tx=txid_current();
 return cid;
end$$;

create function private.property_observation_at(entries jsonb,at_date date) returns jsonb language sql immutable set search_path='' as $$select e from jsonb_array_elements(entries) e where e->>'effectiveOn'<=at_date::text order by (e->>'kind'='end') desc,e->>'effectiveOn' desc limit 1$$;
revoke all on function private.property_observation_at(jsonb,date) from public,anon,authenticated,service_role;

create function public.preview_property_valuation(requested_contract uuid,requested_asset uuid,requested_position uuid,requested_observation uuid,requested_date date,requested_kind text,requested_amount numeric,requested_currency text) returns jsonb language plpgsql security definer set search_path='' as $$
declare p public.positions;c public.contracts;h jsonb;entries jsonb;previous jsonb;incoming jsonb;next_entries jsonb;oid uuid:=coalesce(requested_observation,gen_random_uuid());stamp timestamptz:=clock_timestamp();dates jsonb;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 select * into c from public.contracts where id=requested_contract and user_id=auth.uid();
 if not found or not c.is_active or c.metadata ? 'property_replaced_by' or c.valuation_source<>'positions' or not exists(select 1 from public.envelope_types where id=c.envelope_type_id and code='immobilier') then raise exception 'Active property contract required' using errcode='42501';end if;
 if requested_date is null or requested_date>(stamp at time zone 'Europe/Paris')::date or requested_date<c.opened_on or requested_kind not in('valuation','end') or requested_kind is null or requested_kind='valuation' and (requested_amount is null or requested_amount<0 or requested_amount>=1e16 or requested_amount<>round(requested_amount,8)) or requested_kind='end' and requested_amount is not null or not exists(select 1 from public.currencies where code=requested_currency and is_active) then raise exception 'Invalid property observation' using errcode='22023';end if;
 if not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and asset_type_code='real_estate' and valuation_mode='manual' and is_active) then raise exception 'Manual property asset required' using errcode='42501';end if;
 select * into p from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid();
 if requested_position is not null and p.id is distinct from requested_position or p.metadata ? 'position_observations' then raise exception 'Position changed' using errcode='40001';end if;
 if p.id is null and requested_kind='end' then raise exception 'No holding to end' using errcode='22023';end if;
 h:=coalesce(p.metadata->'property_valuations',jsonb_build_object('version',1,'entries','[]'::jsonb,'archived','[]'::jsonb,'receipts','[]'::jsonb));entries:=h->'entries';
 select e into previous from jsonb_array_elements(entries) e where e->>'id'=oid::text;
 if requested_kind='end' and not exists(select 1 from jsonb_array_elements(entries) e where e->>'effectiveOn'<=requested_date::text and e->>'kind'='valuation') then raise exception 'No proven holding before end' using errcode='22023';end if;
 if requested_kind='valuation' and exists(select 1 from jsonb_array_elements(entries) e where e->>'kind'='end' and e->>'effectiveOn'<=requested_date::text and e->>'id'<>oid::text) then raise exception 'Correct holding end before a later valuation' using errcode='23514';end if;
 incoming:=jsonb_build_object('id',oid,'version',coalesce((previous->>'version')::int,0)+1,'effectiveOn',requested_date,'kind',requested_kind,'amount',case when requested_amount is null then null else requested_amount::text end,'currency',requested_currency,'recordedAt',stamp,'provenance','Valorisation totale immobilière saisie et confirmée par l’utilisateur','origin','manual');
 if previous is not null and previous->>'effectiveOn'=requested_date::text and previous->>'kind'=requested_kind and (previous->>'amount')::numeric is not distinct from requested_amount and previous->>'currency'=requested_currency then incoming:=previous;end if;
 select coalesce(jsonb_agg(e order by e->>'effectiveOn'),'[]') into next_entries from jsonb_array_elements(entries) e where e->>'id'<>oid::text and e->>'effectiveOn'<>requested_date::text;
 next_entries:=next_entries||jsonb_build_array(incoming);
 select coalesce(jsonb_agg(jsonb_build_object('date',business_date,'authority',case when inputs#>>'{historicalSelection,authority}'='approved_csv_priority' then 'CSV approuvé — restitution immobilière explicitement remplaçable' else 'Capture source conservée' end) order by business_date),'[]') into dates from (select distinct on(business_date) * from public.patrimonial_daily_captures where user_id=auth.uid() and state='published' and private.property_observation_at(entries,business_date) is distinct from private.property_observation_at(next_entries,business_date) order by business_date,revision desc) d;
 return jsonb_build_object('position',to_jsonb(p),'history',h,'observation',incoming,'previous',previous,'nextEntries',next_entries,'review',dates,'destination',(select e from jsonb_array_elements(entries) e where e->>'effectiveOn'=requested_date::text and e->>'id'<>oid::text),'token',md5(coalesce(to_jsonb(p)::text,'null')||to_jsonb(c)::text||private.property_sources_hash()||jsonb_build_array(requested_contract,requested_asset,oid,requested_date,requested_kind,requested_amount,requested_currency)::text));
end$$;

create function public.save_property_valuation(requested_contract uuid,requested_asset uuid,requested_position uuid,requested_observation uuid,requested_date date,requested_kind text,requested_amount numeric,requested_currency text,expected_token text) returns uuid language plpgsql security definer set search_path='' as $$
declare p public.positions;plan jsonb;h jsonb;stamp timestamptz:=clock_timestamp();correction uuid:=gen_random_uuid();newj jsonb;pid uuid;request jsonb:=jsonb_build_array(requested_contract,requested_asset,requested_observation,requested_date,requested_kind,requested_amount,requested_currency);
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 perform 1 from public.contracts where id=requested_contract and user_id=auth.uid() for update;
 select * into p from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid() for update;
 if exists(select 1 from jsonb_array_elements(coalesce(p.metadata#>'{property_valuations,receipts}','[]')) e where e->>'token'=expected_token and e->'request'=request) then return p.id;end if;
 lock table public.patrimonial_daily_captures,public.patrimonial_legacy_sources,public.fx_rates in share mode;
 plan:=public.preview_property_valuation(requested_contract,requested_asset,requested_position,requested_observation,requested_date,requested_kind,requested_amount,requested_currency);
 if plan->>'token' is distinct from expected_token then raise exception 'Preview changed' using errcode='40001';end if;
 if plan->'observation' is not distinct from plan->'previous' then return p.id;end if;
 h:=plan->'history';h:=h||jsonb_build_object('entries',plan->'nextEntries','archived',(h->'archived')||jsonb_build_array(jsonb_build_object('entries',h->'entries','replacedAt',stamp,'correctionId',correction)),'receipts',coalesce(h->'receipts','[]')||jsonb_build_array(jsonb_build_object('token',expected_token,'request',request)));
 if p.id is null then
  pid:=gen_random_uuid();
  -- This scalar is a legacy technical sentinel, never a business quantity.
  insert into private.property_write_guards select txid_current(),'position',pid,null,md5((to_jsonb(jsonb_populate_record(null::public.positions,jsonb_build_object('id',pid,'user_id',auth.uid(),'contract_id',requested_contract,'asset_id',requested_asset,'quantity',1,'average_cost_per_unit',null,'cost_currency_code',requested_currency,'opened_on',null,'is_active',true,'metadata',jsonb_build_object('property_valuations',h),'created_at',stamp)))-'updated_at')::text);
  insert into public.positions(id,user_id,contract_id,asset_id,quantity,cost_currency_code,metadata,created_at) values(pid,auth.uid(),requested_contract,requested_asset,1,requested_currency,jsonb_build_object('property_valuations',h),stamp);
 else
  pid:=p.id;newj:=to_jsonb(p)||jsonb_build_object('metadata',p.metadata||jsonb_build_object('property_valuations',h));
  insert into private.property_write_guards values(txid_current(),'position',p.id,md5((to_jsonb(p)-'updated_at')::text),md5((newj-'updated_at')::text));
  update public.positions set metadata=newj->'metadata' where id=p.id;
 end if;
 delete from private.property_write_guards where tx=txid_current();return pid;
end$$;
revoke all on function public.preview_property_consolidation(uuid[],text),public.apply_property_consolidation(uuid[],text,text,uuid),public.preview_property_valuation(uuid,uuid,uuid,uuid,date,text,numeric,text),public.save_property_valuation(uuid,uuid,uuid,uuid,date,text,numeric,text,text) from public,anon,service_role;
grant execute on function public.preview_property_consolidation(uuid[],text),public.apply_property_consolidation(uuid[],text,text,uuid),public.preview_property_valuation(uuid,uuid,uuid,uuid,date,text,numeric,text),public.save_property_valuation(uuid,uuid,uuid,uuid,date,text,numeric,text,text) to authenticated;
create function private.guard_property_asset_prices() returns trigger language plpgsql security definer set search_path='' as $$begin if exists(select 1 from public.assets where id=new.asset_id and asset_type_code='real_estate') then raise exception 'Use total property valuations, never unit prices' using errcode='23514';end if;return new;end$$;
create trigger asset_prices_05_property_guard before insert or update on public.asset_prices for each row execute function private.guard_property_asset_prices();
revoke all on function private.guard_property_asset_prices() from public,anon,authenticated,service_role;
create function private.guard_property_asset_mode() returns trigger language plpgsql security definer set search_path='' as $$begin if exists(select 1 from public.positions where asset_id=new.id and metadata ? 'property_valuations') and (new.asset_type_code<>'real_estate' or new.valuation_mode<>'manual') then raise exception 'Property total valuation semantics are protected' using errcode='23514';end if;return new;end$$;
create trigger assets_05_property_mode before update on public.assets for each row execute function private.guard_property_asset_mode();
revoke all on function private.guard_property_asset_mode() from public,anon,authenticated,service_role;
notify pgrst,'reload schema';
commit;
