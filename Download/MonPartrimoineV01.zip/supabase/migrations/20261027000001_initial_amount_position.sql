-- Explicit monetary attachment. No holding, PRU, unit price, cash or flow.
begin;
set local lock_timeout='5s';
set local statement_timeout='45s';
lock table public.contracts,public.positions,public.position_snapshots,public.asset_prices in share row exclusive mode;

-- NULL means no units, rather than inventing 1 unit (or declaring a zero holding).
-- Only the new, explicitly validated amount-only mode may use this representation.
alter table public.positions alter column quantity drop not null;
alter table public.position_snapshots alter column quantity drop not null;
alter table public.positions add constraint positions_amount_units check (
 case when metadata ? 'initial_amount' then quantity is null and average_cost_per_unit is null
 else quantity is not null end);

-- Narrow locking capability, not table-write privileges for the browser.
create function public.lock_amount_tracking_asset(requested_asset uuid) returns void
language plpgsql security definer set search_path='' as $$
begin
 if auth.uid() is null or not public.is_authorized_user() or not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid())
 then raise exception 'Unauthorized asset' using errcode='42501';end if;
 lock table public.asset_prices in share mode;
 perform 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() for update;
end $$;
revoke all on function public.lock_amount_tracking_asset(uuid) from public,anon;
grant execute on function public.lock_amount_tracking_asset(uuid) to authenticated;

create function public.preview_amount_position(requested_contract uuid,requested_asset uuid,
 requested_date date,requested_amount numeric,requested_currency text)
returns jsonb language plpgsql security definer set search_path='' as $$
declare c public.contracts; a public.assets; token text;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 select * into c from public.contracts where id=requested_contract and user_id=auth.uid() for update;
 perform public.lock_amount_tracking_asset(requested_asset);
 select * into a from public.assets where id=requested_asset and owner_user_id=auth.uid();
 if c.id is null or not c.is_active or c.valuation_source<>'positions' or a.id is null or not a.is_active
  or a.valuation_mode<>'manual' or a.asset_type_code<>'fund'
 then raise exception 'Active manual fund and positions contract required' using errcode='42501';end if;
 if exists(select 1 from public.positions where contract_id=c.id and asset_id=a.id)
 then raise exception 'Attachment already exists; review again' using errcode='40001';end if;
 if exists(select 1 from public.asset_prices where asset_id=a.id)
  or exists(select 1 from public.positions where asset_id=a.id and (metadata ? 'position_observations' or quantity is not null))
 then raise exception 'Unitized evidence already exists for this asset' using errcode='23514';end if;
 if requested_date is null or not isfinite(requested_date) or requested_date<c.opened_on
  or requested_date>(clock_timestamp() at time zone 'Europe/Paris')::date
  or requested_amount is null or requested_amount<0 or requested_amount>=1e16 or requested_amount<>round(requested_amount,8)
  or not exists(select 1 from public.currencies where code=requested_currency and is_active)
 then raise exception 'Invalid first monetary observation' using errcode='23514';end if;
 token:=md5(to_jsonb(c)::text||to_jsonb(a)::text||jsonb_build_array(requested_date,requested_amount,requested_currency)::text);
 return jsonb_build_object('token',token);
end $$;
revoke all on function public.preview_amount_position(uuid,uuid,date,numeric,text) from public,anon;
grant execute on function public.preview_amount_position(uuid,uuid,date,numeric,text) to authenticated;

-- Validate the full native preview even on a direct positions INSERT. This is
-- not a caller-supplied bypass: the AFTER trigger always creates the first proof.
create function public.validate_initial_amount(p public.positions) returns void
language plpgsql security definer set search_path='' as $$
declare m jsonb:=p.metadata->'initial_amount'; v jsonb;
begin
 if p.user_id is distinct from auth.uid() or not p.is_active or p.quantity is not null
  or p.average_cost_per_unit is not null or p.metadata ? 'position_observations'
  or p.metadata ? 'property_valuations' or m->>'version' is distinct from '1'
  or p.cost_currency_code is distinct from (m->>'currency')::char(3)
 then raise exception 'Invalid amount-only attachment' using errcode='23514';end if;
 v:=public.preview_amount_position(p.contract_id,p.asset_id,(m->>'date')::date,(m->>'amount')::numeric,m->>'currency');
 if v->>'token' is distinct from m->>'token' then raise exception 'Amount preview changed' using errcode='40001';end if;
end $$;
revoke all on function public.validate_initial_amount(public.positions) from public,anon;
grant execute on function public.validate_initial_amount(public.positions) to authenticated;

-- Run BEFORE existing contract/asset-use triggers touch their updated_at.
-- Otherwise a valid confirmation would invalidate its own full-row token.
create function private.check_initial_amount() returns trigger language plpgsql set search_path='' as $$
begin
 if public.app_restore_permitted(tg_relid,tg_op,null,to_jsonb(new)) then return new;end if;
 if new.metadata ? 'initial_amount' then perform public.validate_initial_amount(new);end if;
 return new;
end $$;
revoke all on function private.check_initial_amount() from public,anon,authenticated;
create trigger positions_00_amount_validation before insert on public.positions for each row execute function private.check_initial_amount();

do $patch$
declare original text; needle text:=' h:=new.metadata->''position_observations'';';
begin
 original:=pg_get_functiondef('public.guard_position_observations()'::regprocedure);
 if position(needle in original)=0 then raise exception 'Unexpected dated position guard';end if;
 original:=replace(original,'if tg_op=''DELETE'' then if old.metadata ? ''position_observations''',
 'if tg_op=''DELETE'' and old.metadata ? ''initial_amount'' then raise exception ''Monetary proof must be reconciled, not deleted'' using errcode=''23514'';end if; if tg_op=''DELETE'' then if old.metadata ? ''position_observations''');
 execute replace(original,needle,$guard$
 if tg_op='INSERT' and new.metadata ? 'initial_amount' then
  -- Already fully validated by positions_00_amount_validation, before the
  -- ordinary parent-use triggers. Those triggers and owner RLS still apply.
  return new;
 end if;
 if tg_op='UPDATE' and new.metadata->'initial_amount' is distinct from old.metadata->'initial_amount' then
  raise exception 'Initial monetary provenance is immutable' using errcode='23514';end if;
 h:=new.metadata->'position_observations';$guard$);
end $patch$;

create function private.complete_initial_amount() returns trigger
language plpgsql security definer set search_path='' as $$
declare m jsonb:=new.metadata->'initial_amount';
begin
 -- An exact, operator-issued restore permit already supplies the archived
 -- snapshots. Never manufacture an additional initial proof in that boundary.
 if public.app_restore_permitted(tg_relid,tg_op,null,to_jsonb(new)) then return new;end if;
 if m is not null then
  insert into public.position_snapshots(user_id,position_id,valued_at,quantity,unit_price,market_value,currency_code)
   values(new.user_id,new.id,((m->>'date')::date+time '12:00') at time zone 'Europe/Paris',null,null,(m->>'amount')::numeric,m->>'currency');
 end if;
 return new;
end $$;
revoke all on function private.complete_initial_amount() from public,anon,authenticated;
create trigger positions_initial_amount after insert on public.positions for each row execute function private.complete_initial_amount();

create function private.guard_amount_snapshot_units() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if new.quantity is null and not exists(select 1 from public.positions where id=new.position_id and user_id=new.user_id and metadata ? 'initial_amount')
  or (new.quantity is not null or new.unit_price is not null) and exists(select 1 from public.positions where id=new.position_id and metadata ? 'initial_amount')
 then raise exception 'Snapshot units differ from tracking mode' using errcode='23514';end if;
 return new;
end $$;
revoke all on function private.guard_amount_snapshot_units() from public,anon,authenticated;
create trigger position_snapshots_amount_units before insert or update on public.position_snapshots for each row execute function private.guard_amount_snapshot_units();

create function public.create_amount_position(requested_contract uuid,requested_asset uuid,
 requested_date date,requested_amount numeric,requested_currency text,expected_token text)
returns uuid language plpgsql security invoker set search_path='' as $$
declare result_id uuid;
begin
 -- The INSERT trigger rechecks the preview under the same parent/price locks.
 insert into public.positions(user_id,contract_id,asset_id,quantity,average_cost_per_unit,cost_currency_code,metadata)
 values(auth.uid(),requested_contract,requested_asset,null,null,requested_currency,jsonb_build_object('initial_amount',
  jsonb_build_object('version',1,'date',requested_date,'amount',requested_amount,'currency',requested_currency,'token',expected_token))) returning id into result_id;
 return result_id;
end $$;
revoke all on function public.create_amount_position(uuid,uuid,date,numeric,text,text) from public,anon;
grant execute on function public.create_amount_position(uuid,uuid,date,numeric,text,text) to authenticated;

-- A shared support cannot later acquire units while its monetary proofs exist.
do $patch$
declare original text; needle text:=' h:=coalesce(p.metadata->''position_observations''';
begin
 original:=pg_get_functiondef('public.preview_position_observation(uuid,uuid,uuid,uuid,date,numeric,numeric,text)'::regprocedure);
 if position(needle in original)=0 then raise exception 'Unexpected holding preview';end if;
 execute replace(original,needle,$guard$
 -- Same price/asset lock order as monetary attachment, including across
 -- different contracts sharing an asset. Recheck the mode AFTER the lock.
 perform public.lock_amount_tracking_asset(requested_asset);
 if exists(select 1 from public.positions where asset_id=requested_asset and metadata ? 'initial_amount') then
  raise exception 'Use total monetary observations for this support' using errcode='23514';end if;
 h:=coalesce(p.metadata->'position_observations'$guard$);
end $patch$;
notify pgrst,'reload schema';
commit;
