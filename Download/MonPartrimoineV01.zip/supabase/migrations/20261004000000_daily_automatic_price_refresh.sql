-- Phase 7.5: idempotent daily automatic-price execution and one controlled retry.
begin;

create table private.daily_asset_price_refresh_attempts (
  business_date date not null,
  attempt_number smallint not null check (attempt_number in (1, 2)),
  state text not null check (state in ('running', 'completed', 'retryable_failure', 'final_failure')),
  claim_token uuid not null default gen_random_uuid(),
  started_at timestamptz not null default clock_timestamp(),
  claim_expires_at timestamptz not null default (clock_timestamp() + interval '5 minutes'),
  completed_at timestamptz,
  failure_kind text check (failure_kind is null or failure_kind in ('total_failure', 'technical_failure')),
  successes integer not null default 0 check (successes >= 0),
  failures integer not null default 0 check (failures >= 0),
  ignored integer not null default 0 check (ignored >= 0),
  provider text,
  primary key (business_date, attempt_number),
  unique (claim_token),
  check ((state = 'running' and completed_at is null) or (state <> 'running' and completed_at is not null))
);

alter table private.daily_asset_price_refresh_attempts enable row level security;
revoke all on private.daily_asset_price_refresh_attempts from public, anon, authenticated;

create function public.claim_daily_asset_price_refresh(requested_business_date date)
returns table(claimed boolean, decision text, attempt_number smallint, claim_token uuid)
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  latest private.daily_asset_price_refresh_attempts%rowtype;
  next_attempt smallint;
begin
  if requested_business_date is null then
    raise exception 'daily price refresh date is required' using errcode = '22023';
  end if;

  perform pg_advisory_xact_lock(hashtextextended('daily-asset-prices:' || requested_business_date::text, 0));
  select a.* into latest
  from private.daily_asset_price_refresh_attempts a
  where a.business_date = requested_business_date
  order by a.attempt_number desc
  limit 1
  for update;

  if not found then
    next_attempt := 1;
  elsif latest.state = 'completed' then
    return query select false, 'already_completed'::text, latest.attempt_number, null::uuid;
    return;
  elsif latest.state = 'final_failure' or latest.attempt_number >= 2 then
    if latest.state = 'running' and latest.claim_expires_at <= clock_timestamp() then
      update private.daily_asset_price_refresh_attempts
      set state = 'final_failure', completed_at = clock_timestamp(), failure_kind = 'technical_failure'
      where business_date = requested_business_date and attempt_number = latest.attempt_number;
    end if;
    return query select false,
      case when latest.state = 'running' and latest.claim_expires_at > clock_timestamp()
        then 'in_progress' else 'attempts_exhausted' end,
      latest.attempt_number, null::uuid;
    return;
  elsif latest.state = 'running' and latest.claim_expires_at > clock_timestamp() then
    return query select false, 'in_progress'::text, latest.attempt_number, null::uuid;
    return;
  else
    if latest.state = 'running' then
      update private.daily_asset_price_refresh_attempts
      set state = 'retryable_failure', completed_at = clock_timestamp(), failure_kind = 'technical_failure'
      where business_date = requested_business_date and attempt_number = latest.attempt_number;
    end if;
    next_attempt := 2;
  end if;

  insert into private.daily_asset_price_refresh_attempts (
    business_date, attempt_number, state
  ) values (
    requested_business_date, next_attempt, 'running'
  ) returning private.daily_asset_price_refresh_attempts.claim_token into claim_token;

  return query select true, 'claimed'::text, next_attempt, claim_token;
end;
$$;

create function public.complete_daily_asset_price_refresh(
  requested_claim_token uuid,
  requested_outcome text,
  requested_failure_kind text default null,
  requested_successes integer default 0,
  requested_failures integer default 0,
  requested_ignored integer default 0,
  requested_provider text default null
)
returns text
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  current_attempt smallint;
  final_state text;
begin
  if requested_claim_token is null
    or requested_outcome not in ('completed', 'retryable_failure')
    or requested_successes < 0 or requested_failures < 0 or requested_ignored < 0
    or (requested_outcome = 'completed' and requested_failure_kind is not null)
    or (requested_outcome = 'retryable_failure' and requested_failure_kind not in ('total_failure', 'technical_failure')) then
    raise exception 'invalid daily price refresh completion' using errcode = '22023';
  end if;

  select a.attempt_number into current_attempt
  from private.daily_asset_price_refresh_attempts a
  where a.claim_token = requested_claim_token and a.state = 'running'
  for update;
  if not found then
    raise exception 'daily price refresh claim unavailable' using errcode = '22023';
  end if;

  final_state := case
    when requested_outcome = 'completed' then 'completed'
    when current_attempt = 1 then 'retryable_failure'
    else 'final_failure'
  end;

  update private.daily_asset_price_refresh_attempts
  set state = final_state,
      completed_at = clock_timestamp(),
      failure_kind = requested_failure_kind,
      successes = requested_successes,
      failures = requested_failures,
      ignored = requested_ignored,
      provider = nullif(left(btrim(coalesce(requested_provider, '')), 120), '')
  where claim_token = requested_claim_token;

  return final_state;
end;
$$;

revoke all on function public.claim_daily_asset_price_refresh(date) from public, anon, authenticated;
revoke all on function public.complete_daily_asset_price_refresh(uuid, text, text, integer, integer, integer, text) from public, anon, authenticated;
grant execute on function public.claim_daily_asset_price_refresh(date) to service_role;
grant execute on function public.complete_daily_asset_price_refresh(uuid, text, text, integer, integer, integer, text) to service_role;

comment on table private.daily_asset_price_refresh_attempts is
  'Sanitized Phase 7.5 execution claims for one Europe/Paris business date and at most two automatic attempts.';
comment on function public.claim_daily_asset_price_refresh(date) is
  'Atomically claims attempt 1 or the single retry for a daily automatic-price refresh.';
comment on function public.complete_daily_asset_price_refresh(uuid, text, text, integer, integer, integer, text) is
  'Completes a claimed daily refresh and converts a second retryable failure into a final failure.';

commit;
