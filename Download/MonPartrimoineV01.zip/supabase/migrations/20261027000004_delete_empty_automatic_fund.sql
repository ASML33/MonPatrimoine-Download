-- Remove only the untouched automatic attachment with its empty parent.
-- Keep all assets, usage evidence, restrictive FKs and the currency guard.
begin;
set local lock_timeout='5s';
set local statement_timeout='45s';
lock table public.contracts,public.positions in share row exclusive mode;

create function private.empty_automatic_euro_fund(c public.contracts) returns boolean
language plpgsql stable security definer set search_path='' as $$
declare p public.positions; a public.assets; ids jsonb:=c.metadata->'automatic_euro_fund';
begin
 if auth.uid() is null or not public.is_authorized_user() or c.user_id is distinct from auth.uid()
  or ids->>'version' is distinct from '1' or c.valuation_source<>'positions'
  or c.metadata is distinct from jsonb_build_object('automatic_euro_fund',ids)
  or c.fiscal_history_complete or c.social_contributions_paid_eur is not null
  or not exists(select 1 from public.envelope_types where id=c.envelope_type_id and code='assurance_vie')
 then return false;end if;
 select * into p from public.positions where id::text=ids->>'positionId' and contract_id=c.id and user_id=c.user_id;
 if p.id is null or p.asset_id::text is distinct from ids->>'assetId'
  or p.metadata is distinct from jsonb_build_object('initial_amount',jsonb_build_object('version',1,'kind','empty_euro_fund'))
  or p.quantity is not null or p.average_cost_per_unit is not null or p.opened_on is not null
  or p.cost_currency_code<>'EUR'
 then return false;end if;
 select * into a from public.assets where id=p.asset_id and owner_user_id=c.user_id;
 if a.id is null or a.asset_type_code<>'fund' or a.valuation_mode<>'manual'
  or a.metadata is distinct from jsonb_build_object('automatic_euro_fund',jsonb_build_object('version',1,'contractId',c.id))
 then return false;end if;
 -- Same dependencies as contract_has_dependencies, excluding exactly this
 -- reserved position. Any inactive position, explicit zero or empty ledger
 -- retaining an earlier version still prevents removal.
 if exists(select 1 from public.positions where contract_id=c.id and id<>p.id)
  or exists(select 1 from public.position_snapshots where position_id=p.id)
  or exists(select 1 from public.asset_prices where asset_id=a.id)
  or exists(select 1 from public.cash_balances where contract_id=c.id)
  or exists(select 1 from public.cash_flows where source_contract_id=c.id or destination_contract_id=c.id)
  or exists(select 1 from public.contract_manual_situations where contract_id=c.id)
  or exists(select 1 from public.contract_manual_simulations where contract_id=c.id)
  or exists(select 1 from public.target_allocations where scope_contract_id=c.id or target_contract_id=c.id)
  or exists(select 1 from public.patrimonial_legacy_account_maps where contract_id=c.id)
 then return false;end if;
 -- These historical references may be JSON, not foreign keys. A match in an
 -- uncertain/legacy format is protected too; no archive is opened or changed.
 if exists(select 1 from public.patrimonial_daily_captures h where h.user_id=c.user_id and
   (position(c.id::text in h.inputs::text)>0 or position(p.id::text in h.inputs::text)>0
    or position(a.id::text in h.inputs::text)>0 or position(c.id::text in h.result::text)>0
    or position(p.id::text in h.result::text)>0 or position(a.id::text in h.result::text)>0))
  or exists(select 1 from public.patrimonial_legacy_sources h where h.user_id=c.user_id and
   (position(c.id::text in h.payload::text)>0 or position(p.id::text in h.payload::text)>0 or position(a.id::text in h.payload::text)>0))
  or exists(select 1 from public.property_consolidations h where h.user_id=c.user_id and
   (h.contract_id=c.id or position(c.id::text in h.before_image::text)>0 or position(c.id::text in h.after_image::text)>0
    or position(p.id::text in h.before_image::text)>0 or position(p.id::text in h.after_image::text)>0))
 then return false;end if;
 return true;
end $$;
revoke all on function private.empty_automatic_euro_fund(public.contracts) from public,anon,authenticated,service_role;

create function public.can_delete_empty_automatic_fund(requested_contract uuid) returns boolean
language plpgsql stable security definer set search_path='' as $$
declare c public.contracts;
begin
 if auth.uid() is null or not public.is_authorized_user() then return false;end if;
 select * into c from public.contracts where id=requested_contract and user_id=auth.uid();
 if not found then return false;end if;
 return private.empty_automatic_euro_fund(c);
end $$;
revoke all on function public.can_delete_empty_automatic_fund(uuid) from public,anon;
grant execute on function public.can_delete_empty_automatic_fund(uuid) to authenticated;

-- Extend the existing batched read. Do not change has_dependencies: it also
-- protects currency changes, which are outside this exception.
drop function public.get_contract_dependencies(uuid[]);
create function public.get_contract_dependencies(requested_contracts uuid[])
returns table(contract_id uuid,has_dependencies boolean,can_delete_empty_automatic_fund boolean)
language sql stable security invoker set search_path='' as $$
 select c.id,public.contract_has_dependencies(c.id),public.can_delete_empty_automatic_fund(c.id)
 from public.contracts c where c.user_id=auth.uid() and c.id=any(requested_contracts) and public.is_authorized_user()
$$;
revoke all on function public.get_contract_dependencies(uuid[]) from public,anon;
grant execute on function public.get_contract_dependencies(uuid[]) to authenticated;

create function private.guard_empty_automatic_contract_delete() returns trigger
language plpgsql security definer set search_path='' as $$
begin
 if public.app_restore_permitted(tg_relid,tg_op,to_jsonb(old),null) then return old;end if;
 if not (old.metadata ? 'automatic_euro_fund') then return old;end if;
 -- DELETE already holds the parent lock. Keep the native parent -> position
 -- order, then serialize snapshot/price/history writers until the transaction
 -- finishes. The decision is repeated on the latest rows, not trusted from UI.
 perform 1 from public.positions where contract_id=old.id order by id for update;
 perform public.lock_position_capture_sources();
 perform public.lock_amount_tracking_asset((old.metadata#>>'{automatic_euro_fund,assetId}')::uuid);
 if not private.empty_automatic_euro_fund(old) then
  raise exception 'Contract has a value, history or another dependency' using errcode='23503';end if;
 return old;
end $$;
revoke all on function private.guard_empty_automatic_contract_delete() from public,anon,authenticated,service_role;
create trigger contracts_empty_automatic_delete_guard before delete on public.contracts
 for each row execute function private.guard_empty_automatic_contract_delete();

-- The child remains protected against standalone DELETE. A missing parent can
-- occur here only inside its DELETE statement, before its RESTRICT FK check.
do $patch$
declare original text; needle text:='if tg_op=''DELETE'' and old.metadata ? ''initial_amount''';
begin
 original:=pg_get_functiondef('public.guard_position_observations()'::regprocedure);
 if position(needle in original)=0 then raise exception 'Unexpected monetary position delete guard';end if;
 execute replace(original,needle,$guard$
 if tg_op='DELETE' and auth.uid()=old.user_id and public.is_authorized_user()
  and old.metadata=jsonb_build_object('initial_amount',jsonb_build_object('version',1,'kind','empty_euro_fund'))
  and old.quantity is null and old.average_cost_per_unit is null and old.opened_on is null
  and not exists(select 1 from public.contracts where id=old.contract_id)
  and not exists(select 1 from public.position_snapshots where position_id=old.id)
 then return old;end if;
 if tg_op='DELETE' and old.metadata ? 'initial_amount'$guard$);
end $patch$;

create function private.remove_empty_automatic_attachment() returns trigger
language plpgsql security definer set search_path='' as $$
declare removed uuid;
begin
 if public.app_restore_permitted(tg_relid,tg_op,to_jsonb(old),null) then return old;end if;
 if not (old.metadata ? 'automatic_euro_fund') then return old;end if;
 if not private.empty_automatic_euro_fund(old) then raise exception 'Empty support changed' using errcode='40001';end if;
 delete from public.positions where id::text=old.metadata#>>'{automatic_euro_fund,positionId}'
  and contract_id=old.id and user_id=auth.uid() returning id into removed;
 if removed is null then raise exception 'Reserved empty support unavailable' using errcode='40001';end if;
 -- Deliberately keep assets and private.asset_usage, including any shared use.
 return old;
end $$;
revoke all on function private.remove_empty_automatic_attachment() from public,anon,authenticated,service_role;
-- PostgreSQL runs same-kind row triggers alphabetically. This AFTER trigger
-- precedes native RI_ConstraintTrigger checks; RESTRICT FKs remain intact and
-- still reject all other dependencies. Any later refusal rolls everything back.
create trigger "00_remove_empty_automatic_attachment" after delete on public.contracts
 for each row execute function private.remove_empty_automatic_attachment();
notify pgrst,'reload schema';
commit;
