-- LOCAL CANDIDATE. Installation never adopts or replays business data.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
do $$begin
 if private.app_backup_schema()<>'8cf0fb641a93c05ee70ab159f60a5b50024a95ba1b2d1749bd1d4f56e5027fc8' then raise exception 'Unexpected securities action predecessor';end if;
end$$;
create table private.securities_cash_basis(
 balance_id uuid primary key references public.cash_balances(id),
 user_id uuid not null, contract_id uuid not null,
 entries jsonb not null check(jsonb_typeof(entries)='array'),
 initial_action uuid, adopted_at timestamptz not null default clock_timestamp(), source_fingerprint text
);
create sequence private.securities_action_order;
create table private.securities_cash_actions(
 id uuid primary key, balance_id uuid not null references private.securities_cash_basis(balance_id),
 user_id uuid not null, contract_id uuid not null,
 kind text not null check(kind in('flow','balance')), effective_on date not null,
 entered_amount numeric not null, delta numeric not null,
 action_order bigint not null default nextval('private.securities_action_order'),
 active boolean not null default true, legacy_mode text,
 versions jsonb not null default '[]', recorded_at timestamptz not null default clock_timestamp()
);
create table private.securities_action_requests(
 user_id uuid not null, contract_id uuid not null, request_id uuid not null,
 payload jsonb not null, result uuid not null, recorded_at timestamptz not null default clock_timestamp(),
 primary key(user_id,request_id)
);
alter table private.securities_cash_basis enable row level security;
alter table private.securities_cash_basis force row level security;
alter table private.securities_cash_actions enable row level security;
alter table private.securities_cash_actions force row level security;
alter table private.securities_action_requests enable row level security;
alter table private.securities_action_requests force row level security;
revoke all on private.securities_cash_basis,private.securities_cash_actions,private.securities_action_requests from public,anon,authenticated,service_role;
revoke all on sequence private.securities_action_order from public,anon,authenticated,service_role;

create function private.securities_cash_value(bid uuid,day date) returns numeric
language sql stable set search_path='' as $$
 select case when basis.initial_action is not null and not exists(select 1 from private.securities_cash_actions a where a.id=basis.initial_action and a.balance_id=bid and a.active and a.effective_on<=day) then null else
  (select (e->>'amount')::numeric from jsonb_array_elements(basis.entries)e where (e->>'asOf')::timestamptz at time zone 'Europe/Paris'<(day+1)::timestamp order by (e->>'asOf')::timestamptz desc limit 1)
  +coalesce((select sum(a.delta)from private.securities_cash_actions a where a.balance_id=bid and a.active and a.effective_on<=day),0) end
 from private.securities_cash_basis basis where balance_id=bid and user_id=auth.uid()
$$;

create function private.securities_cash_fingerprint(b public.cash_balances)returns text language sql immutable set search_path=''as $$select md5(jsonb_build_array(b.amount,b.currency_code,b.as_of,b.metadata->'cash_balance_observations',b.metadata->'securities_cash_actions',b.metadata->'flow_cash_links',b.metadata->'cash_balance_corrections')::text)$$;
create function private.adopt_securities_cash(bid uuid) returns void
language plpgsql set search_path='' as $$
<<adoption>>
declare b public.cash_balances; f public.cash_flows; entries jsonb; pair record; d numeric; before_value numeric; after_value numeric; day date; previous_base numeric:=0; initial_id uuid; observation_id uuid; item jsonb; actual_amount numeric; zero_basis jsonb;
begin
 select * into strict b from public.cash_balances where id=bid and user_id=auth.uid() for update;
 if exists(select 1 from private.securities_cash_basis where balance_id=bid and user_id=auth.uid())then
  if not exists(select 1 from private.securities_cash_basis j where j.balance_id=bid and j.source_fingerprint=private.securities_cash_fingerprint(b))then raise exception'SECURITIES-JOURNAL-MISMATCH'using errcode='40001';end if;return;
 end if;
 if b.metadata?'securities_cash_actions'then raise exception'SECURITIES-JOURNAL-MISMATCH'using errcode='40001';end if;
 entries:=coalesce(b.metadata#>'{cash_balance_observations,entries}',jsonb_build_array(jsonb_build_object('amount',b.amount::text,'currencyCode',btrim(b.currency_code),'asOf',b.as_of,'recordedAt',b.updated_at)));
 insert into private.securities_cash_basis values(b.id,b.user_id,b.contract_id,entries,null,clock_timestamp(),private.securities_cash_fingerprint(b));
 for pair in select key,value from jsonb_each(coalesce(b.metadata->'flow_cash_links','{}')) where value->>'active'='true' loop
  select * into f from public.cash_flows where id=pair.key::uuid and user_id=auth.uid() and coalesce(destination_contract_id,source_contract_id)=b.contract_id and currency_code=b.currency_code;
  if not found then raise exception 'SECURITIES-LEGACY-PROOF' using errcode='23514';end if;
  day:=(f.occurred_at at time zone 'Europe/Paris')::date;
  select (e->>'amount')::numeric into before_value from jsonb_array_elements(pair.value->'beforeEntries')e where (e->>'asOf')::timestamptz at time zone 'Europe/Paris'<(day+1)::timestamp order by (e->>'asOf')::timestamptz desc limit 1;
  select (e->>'amount')::numeric into after_value from jsonb_array_elements(pair.value->'afterEntries')e where (e->>'asOf')::timestamptz at time zone 'Europe/Paris'<(day+1)::timestamp order by (e->>'asOf')::timestamptz desc limit 1;
  d:=case when f.kind='contribution' then f.amount else -f.amount end;
  if pair.value->>'cashEffect'='included' then d:=0;end if;
  if before_value is null or after_value-before_value is distinct from d then raise exception 'SECURITIES-LEGACY-PROOF' using errcode='23514';end if;
  insert into private.securities_cash_actions(id,balance_id,user_id,contract_id,kind,effective_on,entered_amount,delta,legacy_mode,recorded_at)
   values(f.id,b.id,b.user_id,b.contract_id,'flow',day,f.amount,d,case when pair.value->>'cashEffect'='included' then 'included' end,coalesce((pair.value->>'recordedAt')::timestamptz,f.updated_at));
 end loop;
 -- Remove only proven active flow deltas from the observation basis. Recombined
 -- values must be exactly equal; independent legacy flows are never replayed.
 select jsonb_agg(e||jsonb_build_object('amount',((e->>'amount')::numeric-coalesce((select sum(a.delta)from private.securities_cash_actions a where a.balance_id=bid and a.active and a.effective_on<=((e->>'asOf')::timestamptz at time zone 'Europe/Paris')::date),0))::text)order by (e->>'asOf')::timestamptz) into entries from jsonb_array_elements(entries)e;
 update private.securities_cash_basis set entries=adoption.entries where balance_id=bid;
 -- Retained absolute observations become fixed transition increments. They
 -- preserve the old effective curve, but do not absorb subsequently recorded
 -- backdated actions. A flow-created observation is not a second balance action.
 for item in select value from jsonb_array_elements(entries)order by (value->>'asOf')::timestamptz loop
  day:=((item->>'asOf')::timestamptz at time zone'Europe/Paris')::date;
  d:=(item->>'amount')::numeric-previous_base;previous_base:=(item->>'amount')::numeric;
  if initial_id is null or d<>0 or not exists(select 1 from private.securities_cash_actions a where a.balance_id=bid and a.kind='flow'and a.effective_on=day)then
   observation_id:=md5(bid::text||':'||day::text)::uuid;
   actual_amount:=(item->>'amount')::numeric+coalesce((select sum(a.delta)from private.securities_cash_actions a where a.balance_id=bid and a.kind='flow'and a.active and a.effective_on<=day),0);
   insert into private.securities_cash_actions(id,balance_id,user_id,contract_id,kind,effective_on,entered_amount,delta,legacy_mode,recorded_at)values(observation_id,bid,b.user_id,b.contract_id,'balance',day,actual_amount,d,'observation',(item->>'recordedAt')::timestamptz);
   if initial_id is null then initial_id:=observation_id;zero_basis:=item||jsonb_build_object('amount','0');end if;
  end if;
 end loop;
 update private.securities_cash_basis set entries=jsonb_build_array(zero_basis),initial_action=initial_id where balance_id=bid;
 for pair in select value e from jsonb_array_elements(coalesce(b.metadata#>'{cash_balance_observations,entries}',jsonb_build_array(jsonb_build_object('amount',b.amount::text,'asOf',b.as_of)))) loop
  if private.securities_cash_value(bid,((pair.e->>'asOf')::timestamptz at time zone 'Europe/Paris')::date) is distinct from (pair.e->>'amount')::numeric then raise exception 'SECURITIES-LEGACY-PROOF' using errcode='23514';end if;
 end loop;
end$$;

create function private.materialize_securities_cash(bid uuid,changed_day date) returns void
language plpgsql set search_path='' as $$
declare b public.cash_balances; entries jsonb:='[]'; e jsonb; last_e jsonb; day date; v numeric; stamp timestamptz:=clock_timestamp(); prior jsonb; meta jsonb; visible jsonb; flow_changes jsonb;
begin
 select * into strict b from public.cash_balances where id=bid and user_id=auth.uid() for update;
 prior:=coalesce(b.metadata->'cash_balance_observations',jsonb_build_object('version',2,'entries',jsonb_build_array(jsonb_build_object('amount',b.amount::text,'currencyCode',btrim(b.currency_code),'asOf',b.as_of,'recordedAt',b.updated_at)),'archived','[]'::jsonb));
 for day in select d from(select ((x->>'asOf')::timestamptz at time zone 'Europe/Paris')::date d from private.securities_cash_basis j cross join lateral jsonb_array_elements(j.entries)x where j.balance_id=bid union select a.effective_on from private.securities_cash_actions a where a.balance_id=bid and a.active)days order by d loop
  v:=private.securities_cash_value(bid,day);
  if v is null then continue;end if;
  if v<0 or v>=1e16 then raise exception 'SECURITIES-NEGATIVE' using errcode='23514';end if;
  e:=jsonb_build_object('amount',trim_scale(v)::text,'currencyCode',btrim(b.currency_code),'asOf',day::timestamp at time zone 'Europe/Paris','recordedAt',stamp);
  entries:=entries||jsonb_build_array(e);last_e:=e;
 end loop;
 select coalesce(jsonb_agg(jsonb_build_object('id',a.id,'kind',a.kind,'date',a.effective_on,'amount',a.entered_amount::text,'delta',a.delta::text,'order',a.action_order,'revision',a.recorded_at,'legacyMode',a.legacy_mode)order by a.action_order desc),'[]') into visible from private.securities_cash_actions a where a.balance_id=bid and a.active;
 select coalesce(jsonb_agg(jsonb_build_object('id',x.id,'date',x.effect_day,'kind',coalesce((select f.kind::text from public.cash_flows f where f.id=x.id and f.user_id=auth.uid()and x.delta=0),case when x.delta>=0 then'contribution'else'withdrawal'end))),'[]')into flow_changes from(
  select a.id,a.effective_on as effect_day,a.delta from private.securities_cash_actions a where a.contract_id=b.contract_id and a.user_id=auth.uid()and a.kind='flow'
  union select a.id,(vr.value->>'effective_on')::date,(vr.value->>'delta')::numeric from private.securities_cash_actions a cross join lateral jsonb_array_elements(a.versions)vr where a.contract_id=b.contract_id and a.user_id=auth.uid()and a.kind='flow'
 )x;
 meta:=b.metadata||jsonb_build_object('securities_cash_actions',jsonb_build_object('version',1,'known',last_e is not null,'entries',visible,'flowChanges',flow_changes),'cash_balance_observations',jsonb_build_object('version',2,'entries',entries,'archived',(prior->'archived')||jsonb_build_array(jsonb_build_object('entries',prior->'entries','replacedAt',stamp))),
  'cash_balance_corrections',coalesce(b.metadata->'cash_balance_corrections','[]')||jsonb_build_array(jsonb_build_object('previous',null,'submitted',jsonb_build_object('asOf',changed_day::timestamp at time zone 'Europe/Paris'),'recordedAt',stamp,'source','ordered_actions')));
 -- Retain existing link evidence, mark the current proven links for native
 -- flow/cumulative projection without replacing their captured before/after.
 for e in select to_jsonb(a)from private.securities_cash_actions a where a.balance_id=bid and a.kind='flow' loop
  meta:=jsonb_set(meta,array['flow_cash_links'],coalesce(meta->'flow_cash_links','{}')||jsonb_build_object(e->>'id',jsonb_build_object('beforeEntries',prior->'entries','afterEntries',entries)||coalesce(meta#>array['flow_cash_links',e->>'id'],'{}')||jsonb_build_object('active',(e->>'active')::boolean,'reconciled',true,'journal',true)));
 end loop;
 for e in select jsonb_build_object('id',a.id)from private.securities_cash_actions a where a.user_id=auth.uid()and a.contract_id=b.contract_id and a.balance_id<>bid and meta#>array['flow_cash_links',a.id::text]is not null loop
  meta:=jsonb_set(meta,array['flow_cash_links',e->>'id','active'],'false'::jsonb);
 end loop;
 update public.cash_balances set metadata=meta,amount=coalesce((last_e->>'amount')::numeric,0),as_of=coalesce((last_e->>'asOf')::timestamptz,b.as_of)where id=bid and user_id=auth.uid();
 update private.securities_cash_basis j set source_fingerprint=private.securities_cash_fingerprint(cb)from public.cash_balances cb where j.balance_id=bid and cb.id=bid and cb.user_id=auth.uid();
end$$;

-- Empty materializations mean unknown, never a known zero. They are writable
-- only by owner-controlled RPCs; ordinary authenticated writes retain the guard.
do $guard$declare src text;begin
 src:=pg_get_functiondef('public.guard_dated_cash_balance_observations()'::regprocedure);
 src:=replace(src,'begin','begin
 if current_user=''authenticated'' and exists(select 1 from public.contracts c join public.envelope_types t on t.id=c.envelope_type_id where c.id=new.contract_id and c.user_id=auth.uid() and t.code in(''pea'',''pea_pme'',''cto'',''compte_titres'')) and (tg_op=''INSERT'' or row(new.amount,new.as_of,new.metadata->''cash_balance_observations'',new.metadata->''securities_cash_actions'',new.metadata->''flow_cash_links'',new.metadata->''flow_cash_requests'',new.metadata->''cash_balance_corrections'') is distinct from row(old.amount,old.as_of,old.metadata->''cash_balance_observations'',old.metadata->''securities_cash_actions'',old.metadata->''flow_cash_links'',old.metadata->''flow_cash_requests'',old.metadata->''cash_balance_corrections'')) then raise exception ''SECURITIES-RELOAD'' using errcode=''40001'';end if;
 if current_user<>''authenticated'' and new.metadata#>>''{securities_cash_actions,known}''=''false'' and new.metadata#>''{cash_balance_observations,entries}''=''[]''::jsonb and new.amount=0 then return new;end if;');
 execute src;
end$guard$;

create function public.mutate_securities_cash_action(requested_contract uuid,requested_action uuid,requested_kind text,requested_operation text,requested_request uuid,expected_balances jsonb,expected_action_revision timestamptz,requested_values jsonb)
returns uuid language plpgsql security definer set search_path='' as $$
<<mutation>>
declare actor uuid:=auth.uid(); c public.contracts; b public.cash_balances; old_b uuid; action private.securities_cash_actions; receipt private.securities_action_requests; payload jsonb; actual jsonb; expected jsonb; code text; currency text; day date; amount numeric; change numeric; stamp timestamptz:=clock_timestamp(); original_day date; base numeric;
begin
 if actor is null or public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 if requested_action is null or requested_request is null or requested_kind is null or requested_operation is null or requested_kind not in('flow','balance')or requested_operation not in('create','update','delete')or jsonb_typeof(expected_balances)is distinct from'array'or jsonb_typeof(requested_values)is distinct from'object'then raise exception 'SECURITIES-REQUEST' using errcode='22023';end if;
 select * into c from public.contracts where id=requested_contract and user_id=actor for update;
 if not found then raise exception 'Unauthorized contract' using errcode='42501';end if;
 select e.code into code from public.envelope_types e where id=c.envelope_type_id;
 if code not in('pea','pea_pme','cto','compte_titres')then raise exception 'Unauthorized envelope' using errcode='42501';end if;
 if requested_kind='flow'and requested_operation<>'create'then raise exception 'SECURITIES-FLOW-IMMUTABLE'using errcode='23514';end if;
 payload:=jsonb_build_array(requested_contract,requested_action,requested_kind,requested_operation,expected_balances,expected_action_revision,requested_values);
 select * into receipt from private.securities_action_requests where user_id=actor and request_id=requested_request;
 if found then if receipt.payload is distinct from payload then raise exception 'SECURITIES-REPLAY' using errcode='40001';end if;
  for b in select * from public.cash_balances where contract_id=c.id and user_id=actor order by id for update loop perform private.adopt_securities_cash(b.id);end loop;return receipt.result;
 end if;
 perform 1 from public.cash_balances where contract_id=c.id and user_id=actor order by id for update;
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'updatedAt',updated_at)order by id),'[]')into actual from public.cash_balances where contract_id=c.id and user_id=actor;
 select coalesce(jsonb_agg(jsonb_build_object('id',(v->>'id')::uuid,'updatedAt',(v->>'updatedAt')::timestamptz)order by (v->>'id')::uuid),'[]')into expected from jsonb_array_elements(expected_balances)v;
 if actual is distinct from expected then raise exception 'SECURITIES-STALE' using errcode='40001';end if;
 for b in select * from public.cash_balances where contract_id=c.id and user_id=actor loop perform private.adopt_securities_cash(b.id);end loop;
 b:=null;
 if requested_operation<>'create' then
  select * into action from private.securities_cash_actions where id=requested_action and user_id=actor and contract_id=c.id for update;
  if not found then raise exception'SECURITIES-STALE'using errcode='40001';end if;
  if not action.active then raise exception'SECURITIES-STALE'using errcode='40001';end if;
  if action.kind<>'balance'then raise exception'SECURITIES-STALE'using errcode='40001';end if;
  if action.recorded_at is distinct from expected_action_revision and not(coalesce(action.legacy_mode='observation',false)and exists(select 1 from public.cash_balances cb where cb.id=action.balance_id and cb.user_id=actor and cb.updated_at=expected_action_revision and not(cb.metadata?'securities_cash_actions')))then raise exception 'SECURITIES-STALE' using errcode='40001';end if;
  old_b:=action.balance_id;original_day:=action.effective_on;
  update private.securities_cash_actions set active=false,versions=versions||jsonb_build_array(to_jsonb(action)-'versions'),recorded_at=stamp where id=action.id;
 elsif exists(select 1 from private.securities_cash_actions where id=requested_action)then raise exception 'SECURITIES-REPLAY' using errcode='40001';end if;
 if requested_operation<>'delete'then
  if requested_operation='create'and not c.is_active then raise exception 'Inactive contract' using errcode='23514';end if;
  currency:=requested_values->>'currency_code';day:=(requested_values->>'date')::date;amount:=(requested_values->>'amount')::numeric;
  if day is null or day>(stamp at time zone'Europe/Paris')::date or day<c.opened_on or day>c.closed_on or amount is null or amount<0 or amount>=1e16 or amount<>round(amount,2)or not exists(select 1 from public.currencies where currencies.code=currency and is_active)or requested_kind='flow'and(amount=0 or requested_values->>'kind'is null or requested_values->>'kind'not in('contribution','withdrawal'))then raise exception 'SECURITIES-VALUES' using errcode='22023';end if;
  if requested_kind='flow'and(c.metadata?'knownTotalContributionsEur'or c.metadata?'knownNetCashFlowsEur')and(c.metadata->>'knownTotalContributionsAsOf'is null or c.metadata->>'knownTotalContributionsAsOf'>=day::text)then raise exception 'FLOW-CASH-ANCHOR' using errcode='23514';end if;
  select * into b from public.cash_balances where contract_id=c.id and user_id=actor and currency_code=currency;
  if b.id is null then
   if requested_kind='flow'then raise exception 'SECURITIES-UNKNOWN' using errcode='23514';end if;
   insert into public.cash_balances(user_id,contract_id,currency_code,amount,as_of)values(actor,c.id,currency,0,day::timestamp at time zone'Europe/Paris')returning * into b;
   insert into private.securities_cash_basis(balance_id,user_id,contract_id,entries,initial_action,source_fingerprint)values(b.id,actor,c.id,jsonb_build_array(jsonb_build_object('amount','0','currencyCode',currency,'asOf',b.as_of,'recordedAt',stamp)),requested_action,private.securities_cash_fingerprint(b));
   base:=0;
  else
   if exists(select 1 from private.securities_cash_basis where balance_id=b.id and initial_action=requested_action)then
    update private.securities_cash_basis set entries=jsonb_build_array(jsonb_build_object('amount','0','currencyCode',currency,'asOf',day::timestamp at time zone'Europe/Paris','recordedAt',stamp))where balance_id=b.id;
    base:=coalesce((select sum(a.delta)from private.securities_cash_actions a where a.balance_id=b.id and a.active and a.effective_on<=day),0);
   elsif exists(select 1 from private.securities_cash_basis j where j.balance_id=b.id and j.initial_action is not null and not exists(select 1 from private.securities_cash_actions a where a.id=j.initial_action and a.active))and requested_kind='balance'then
    update private.securities_cash_basis set initial_action=requested_action,entries=jsonb_build_array(jsonb_build_object('amount','0','currencyCode',currency,'asOf',day::timestamp at time zone'Europe/Paris','recordedAt',stamp))where balance_id=b.id;
    base:=coalesce((select sum(a.delta)from private.securities_cash_actions a where a.balance_id=b.id and a.active and a.effective_on<=day),0);
   else base:=private.securities_cash_value(b.id,day);end if;
   if base is null then raise exception 'SECURITIES-UNKNOWN' using errcode='23514';end if;
  end if;
  change:=case when requested_kind='balance'then amount-base when requested_values->>'kind'='contribution'then amount else -amount end;
  insert into private.securities_cash_actions(id,balance_id,user_id,contract_id,kind,effective_on,entered_amount,delta,recorded_at)
   values(requested_action,b.id,actor,c.id,requested_kind,day,amount,change,stamp)
   on conflict(id)do update set balance_id=excluded.balance_id,effective_on=excluded.effective_on,entered_amount=excluded.entered_amount,delta=excluded.delta,active=true,recorded_at=stamp,action_order=nextval('private.securities_action_order');
 end if;
 if requested_kind='flow'then
  insert into public.cash_flows(id,user_id,kind,source_contract_id,destination_contract_id,amount,currency_code,occurred_at,note,fx_status)values(requested_action,actor,(requested_values->>'kind')::public.cash_flow_kind,case when requested_values->>'kind'='withdrawal'then c.id end,case when requested_values->>'kind'='contribution'then c.id end,amount,currency,day::timestamp at time zone'Europe/Paris',requested_values->>'note',case when currency='EUR'then'resolved'::public.fx_resolution_status else'pending'::public.fx_resolution_status end);
 end if;
 if old_b is not null then perform private.materialize_securities_cash(old_b,least(original_day,coalesce(day,original_day)));end if;
 if b.id is not null and b.id is distinct from old_b then perform private.materialize_securities_cash(b.id,day);end if;
 insert into private.securities_action_requests values(actor,c.id,requested_request,payload,requested_action,stamp);
 return requested_action;
end$$;
revoke all on function public.mutate_securities_cash_action(uuid,uuid,text,text,uuid,jsonb,timestamptz,jsonb)from public,anon;
grant execute on function public.mutate_securities_cash_action(uuid,uuid,text,text,uuid,jsonb,timestamptz,jsonb)to authenticated;
revoke all on function private.securities_cash_value(uuid,date),private.adopt_securities_cash(uuid),private.materialize_securities_cash(uuid,date),private.securities_cash_fingerprint(public.cash_balances)from public,anon,authenticated,service_role;

-- Old clients must reload; authorized owner-controlled migration/RPC paths do
-- not run the old cash-effect trigger. Pure FX completion remains permitted.
create or replace function public.apply_cash_flow_observation()returns trigger language plpgsql security invoker set search_path=''as $$
declare ids uuid[];
begin
 if current_user<>'authenticated'then if tg_op='DELETE'then return old;else return new;end if;end if;
 if tg_op='INSERT'then ids:=array[new.source_contract_id,new.destination_contract_id];elsif tg_op='DELETE'then ids:=array[old.source_contract_id,old.destination_contract_id];else ids:=array[old.source_contract_id,old.destination_contract_id,new.source_contract_id,new.destination_contract_id];end if;
 if exists(select 1 from public.contracts c join public.envelope_types e on e.id=c.envelope_type_id where c.user_id=auth.uid()and c.id=any(ids)and e.code in('pea','pea_pme','cto','compte_titres'))then
  if tg_op='INSERT'then raise exception'SECURITIES-RELOAD'using errcode='40001';end if;
  if tg_op='DELETE'then raise exception'SECURITIES-FLOW-IMMUTABLE'using errcode='23514';end if;
  if(to_jsonb(new)-array['updated_at','fx_rate_id','fx_status'])is distinct from(to_jsonb(old)-array['updated_at','fx_rate_id','fx_status'])then raise exception'SECURITIES-FLOW-IMMUTABLE'using errcode='23514';end if;
 end if;
 if tg_op='DELETE'then return old;else return new;end if;
end$$;
-- The corrected contribution indicator is independent of native flows and tax.
-- Keep its trace in the existing contract metadata; no second private journal.
create function public.save_securities_contribution_correction(requested_contract uuid,requested_request uuid,expected_revision timestamptz,expected_balances jsonb,requested_date date,requested_amount numeric)
returns uuid language plpgsql security definer set search_path=''as $$
declare actor uuid:=auth.uid();c public.contracts;code text;h jsonb;payload jsonb;prior jsonb;entry jsonb;actual jsonb;expected jsonb;stamp timestamptz:=clock_timestamp();
begin
 if actor is null or public.is_authorized_user()is not true then raise exception'Unauthorized'using errcode='42501';end if;
 select * into c from public.contracts where id=requested_contract and user_id=actor for update;
 if not found then raise exception'Unauthorized contract'using errcode='42501';end if;
 select e.code into code from public.envelope_types e where id=c.envelope_type_id;
 if code not in('pea','pea_pme','cto','compte_titres')then raise exception'Unauthorized envelope'using errcode='42501';end if;
 if requested_request is null or expected_revision is null or jsonb_typeof(expected_balances)is distinct from'array'or requested_date is null or requested_amount is null or requested_amount<0 or requested_amount>=1e16 or requested_amount<>round(requested_amount,2)then raise exception'SECURITIES-VALUES'using errcode='22023';end if;
 payload:=jsonb_build_array(requested_contract,expected_revision,expected_balances,requested_date,requested_amount);
 prior:=c.metadata#>array['securities_contribution_requests',requested_request::text];
 if prior is not null then if prior is distinct from payload then raise exception'SECURITIES-REPLAY'using errcode='40001';end if;return requested_request;end if;
 if c.updated_at is distinct from expected_revision then raise exception'SECURITIES-STALE'using errcode='40001';end if;
 if not c.is_active or requested_date<c.opened_on or requested_date>c.closed_on or requested_date>(stamp at time zone'Europe/Paris')::date then raise exception'SECURITIES-VALUES'using errcode='22023';end if;
 perform 1 from public.cash_balances where contract_id=c.id and user_id=actor order by id for update;
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'updatedAt',updated_at)order by id),'[]')into actual from public.cash_balances where contract_id=c.id and user_id=actor;
 select coalesce(jsonb_agg(jsonb_build_object('id',(v->>'id')::uuid,'updatedAt',(v->>'updatedAt')::timestamptz)order by(v->>'id')::uuid),'[]')into expected from jsonb_array_elements(expected_balances)v;
 if actual is distinct from expected then raise exception'SECURITIES-STALE'using errcode='40001';end if;
 h:=coalesce(c.metadata->'securities_contribution_corrections','{"version":1,"entries":[],"archived":[]}'::jsonb);
 if h->>'version'<>'1'or jsonb_typeof(h->'entries')is distinct from'array'or jsonb_typeof(h->'archived')is distinct from'array'then raise exception'SECURITIES-LEGACY-PROOF'using errcode='23514';end if;
 entry:=jsonb_build_object('id',requested_request,'date',requested_date,'amount',requested_amount::text,'order',coalesce((select max((e->>'order')::bigint)from jsonb_array_elements((h->'entries')||(h->'archived'))e),0)+1,'recordedAt',stamp,'flowIds',coalesce((select jsonb_agg(id order by id)from public.cash_flows where user_id=actor and destination_contract_id=c.id and kind='contribution'),'[]'));
 h:=jsonb_build_object('version',1,'entries',coalesce((select jsonb_agg(e order by e->>'date')from jsonb_array_elements(h->'entries')e where(e->>'date')::date<requested_date),'[]')||jsonb_build_array(entry),'archived',(h->'archived')||coalesce((select jsonb_agg(e)from jsonb_array_elements(h->'entries')e where(e->>'date')::date>=requested_date),'[]'));
 update public.contracts set metadata=metadata||jsonb_build_object('securities_contribution_corrections',h,'securities_contribution_requests',coalesce(metadata->'securities_contribution_requests','{}')||jsonb_build_object(requested_request::text,payload))where id=c.id and user_id=actor;
 return requested_request;
end$$;
revoke all on function public.save_securities_contribution_correction(uuid,uuid,timestamptz,jsonb,date,numeric)from public,anon;
grant execute on function public.save_securities_contribution_correction(uuid,uuid,timestamptz,jsonb,date,numeric)to authenticated;
create function public.guard_securities_contribution_corrections()returns trigger language plpgsql security invoker set search_path=''as $$
begin
 if current_user='authenticated'and exists(select 1 from public.envelope_types e where e.id in(old.envelope_type_id,new.envelope_type_id)and e.code in('pea','pea_pme','cto','compte_titres'))and(new.metadata->'securities_contribution_corrections'is distinct from old.metadata->'securities_contribution_corrections'or new.metadata->'securities_contribution_requests'is distinct from old.metadata->'securities_contribution_requests')then raise exception'SECURITIES-RELOAD'using errcode='40001';end if;return new;
end$$;
revoke all on function public.guard_securities_contribution_corrections()from public,anon,authenticated;
create trigger guard_securities_contribution_corrections before update on public.contracts for each row execute function public.guard_securities_contribution_corrections();

-- Holdings replacement: only the requested securities envelopes.
create or replace function public.preview_position_observation(requested_contract uuid,requested_asset uuid,requested_position uuid,
 requested_observation uuid,requested_date date,requested_quantity numeric,requested_cost numeric,requested_currency text)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare p public.positions; h jsonb; entries jsonb; previous jsonb; incoming jsonb; next_entries jsonb; plan jsonb; oid uuid:=coalesce(requested_observation,gen_random_uuid()); state_hash text; stamp timestamptz:=clock_timestamp(); parent public.contracts;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 select * into parent from public.contracts where id=requested_contract and user_id=auth.uid();
 if not found or not parent.is_active then raise exception 'Active contract required' using errcode='42501';end if;
 if requested_date is null or requested_date>(stamp at time zone 'Europe/Paris')::date or requested_date<parent.opened_on
 or requested_quantity is null or requested_quantity<0 or requested_quantity>=1e16 or requested_quantity<>round(requested_quantity,8)
 or requested_cost<0 or requested_cost>=1e16 or requested_cost<>round(requested_cost,8)
 or not exists(select 1 from public.currencies where code=requested_currency and is_active) then raise exception 'Invalid dated holding' using errcode='22023';end if;
 select * into p from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid();
 if requested_position is not null and p.id is distinct from requested_position then raise exception 'Position unavailable' using errcode='40001';end if;
 if p.id is null then
  if not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required' using errcode='42501';end if;
 elsif not p.is_active and not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required for reactivation' using errcode='23514';end if;
 h:=coalesce(p.metadata->'position_observations',jsonb_build_object('version',1,'entries','[]'::jsonb,'archived','[]'::jsonb,'bindings','[]'::jsonb,'receipts','[]'::jsonb));
 entries:=h->'entries';select e into previous from jsonb_array_elements(entries) e where e->>'id'=oid::text;
 incoming:=jsonb_build_object('id',oid,'version',coalesce((previous->>'version')::int,0)+1,'effectiveOn',requested_date,'quantity',requested_quantity::text,'unitCost',case when requested_cost is null then null else requested_cost::text end,'currency',requested_currency,'recordedAt',stamp,'provenance','Situation saisie et confirmée par l’utilisateur');
 select coalesce(jsonb_agg(e order by e->>'effectiveOn'),'[]') into next_entries from jsonb_array_elements(entries) e where e->>'id'<>oid::text and case when exists(select 1 from public.envelope_types t where t.id=parent.envelope_type_id and t.code in('pea','pea_pme','cto','compte_titres'))then (e->>'effectiveOn')::date<requested_date else e->>'effectiveOn'<>requested_date::text end;
 if previous is not null and (previous->>'effectiveOn')::date=requested_date and (previous->>'quantity')::numeric=requested_quantity and (previous->>'unitCost')::numeric is not distinct from requested_cost and previous->>'currency'=requested_currency then incoming:=previous;end if;
 next_entries:=next_entries||jsonb_build_array(incoming);
 if p.id is not null and p.quantity=0 and coalesce((public.position_observation_at(next_entries,(stamp at time zone 'Europe/Paris')::date)->>'quantity')::numeric,0)>0 and not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required for renewed holding' using errcode='23514';end if;
 plan:=public.position_capture_plan(requested_contract,requested_asset,entries,next_entries);
 select md5(coalesce(jsonb_agg(jsonb_build_array(id,revision,inputs,result) order by id)::text,'')) into state_hash from public.patrimonial_daily_captures where user_id=auth.uid() and state='published';
 state_hash:=md5(state_hash||coalesce((select jsonb_agg(jsonb_build_array(id,payload) order by id)::text from public.patrimonial_legacy_sources where user_id=auth.uid()),''));
 return plan||jsonb_build_object('observation',incoming,'previous',previous,'nextEntries',next_entries,'history',h,'position',to_jsonb(p),'destination', (select e from jsonb_array_elements(entries) e where e->>'effectiveOn'=requested_date::text and e->>'id'<>oid::text),'token',md5(coalesce(to_jsonb(p)::text,'null')||state_hash||jsonb_build_array(requested_contract,requested_asset,oid,requested_date,requested_quantity,requested_cost,requested_currency)::text));
end$$;

create function public.save_securities_position_action(requested_contract uuid,requested_asset uuid,requested_position uuid,requested_observation uuid,requested_date date,requested_quantity numeric,requested_cost numeric,requested_currency text,expected_position_updated_at timestamptz,requested_request uuid)
returns uuid language plpgsql security definer set search_path='' as $$
declare p public.positions; parent public.contracts; plan jsonb; receipt private.securities_action_requests; payload jsonb; oid uuid:=coalesce(requested_observation,requested_request); saved uuid;
begin
 if auth.uid()is null or public.is_authorized_user()is not true then raise exception'Unauthorized'using errcode='42501';end if;
 if requested_request is null then raise exception'Invalid request'using errcode='22023';end if;
 select * into parent from public.contracts where id=requested_contract and user_id=auth.uid()for update;
 if not found or not exists(select 1 from public.envelope_types t where t.id=parent.envelope_type_id and t.code in('pea','pea_pme','cto','compte_titres'))then raise exception'Unauthorized contract'using errcode='42501';end if;
 payload:=jsonb_build_array('position',requested_contract,requested_asset,requested_position,requested_observation,requested_date,requested_quantity,requested_cost,requested_currency,expected_position_updated_at);
 select * into receipt from private.securities_action_requests where user_id=auth.uid()and request_id=requested_request;
 if found then if receipt.payload is distinct from payload then raise exception'SECURITIES-REPLAY'using errcode='40001';end if;
  if not exists(select 1 from public.positions p where p.id=receipt.result and p.user_id=auth.uid()and p.metadata#>array['securities_action_requests',requested_request::text]=payload)then raise exception'SECURITIES-JOURNAL-MISMATCH'using errcode='40001';end if;return receipt.result;
 end if;
 select * into p from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid()for update;
 if p.updated_at is distinct from expected_position_updated_at or p.id is distinct from requested_position then raise exception'SECURITIES-STALE'using errcode='40001';end if;
 if p.id is not null and exists(select 1 from public.assets a where a.id=p.asset_id and a.asset_type_code='fund'and a.valuation_mode='manual')and exists(select 1 from public.position_snapshots s where s.position_id=p.id and s.user_id=auth.uid())then raise exception'Legacy amount holding requires a qualified transition'using errcode='23514';end if;
 if requested_cost is not null and requested_cost<>round(requested_cost,2)then raise exception'PRU: two decimals'using errcode='22023';end if;
 perform public.lock_position_capture_sources();
 plan:=public.preview_position_observation(requested_contract,requested_asset,requested_position,oid,requested_date,requested_quantity,requested_cost,requested_currency);
 saved:=public.save_position_observation(requested_contract,requested_asset,requested_position,oid,requested_date,requested_quantity,requested_cost,requested_currency,plan->>'token');
 update public.positions set metadata=metadata||jsonb_build_object('securities_action_requests',coalesce(metadata->'securities_action_requests','{}')||jsonb_build_object(requested_request::text,payload))where id=saved and user_id=auth.uid();
 insert into private.securities_action_requests(user_id,contract_id,request_id,payload,result)values(auth.uid(),requested_contract,requested_request,payload,saved);
 return saved;
end$$;
revoke all on function public.save_securities_position_action(uuid,uuid,uuid,uuid,date,numeric,numeric,text,timestamptz,uuid)from public,anon;
grant execute on function public.save_securities_position_action(uuid,uuid,uuid,uuid,date,numeric,numeric,text,timestamptz,uuid)to authenticated;

commit;
