-- Extend the existing catalogue, executable versions and contract record.
-- No financial observation/capture is recalculated by this migration.
begin;
set local lock_timeout='5s';
set local statement_timeout='60s';
alter table public.envelope_types add column is_standard boolean not null default true,
 add column configuration_revision integer not null default 1 check(configuration_revision>0),
 add column default_fiscal_regime_id uuid references public.fiscal_regimes(id),
 add column default_fiscal_rule_id uuid references public.fiscal_rules(id);
alter table public.fiscal_regimes drop constraint fiscal_regimes_calculation_kind_check;
alter table public.fiscal_regimes add constraint fiscal_regimes_calculation_kind_check check(calculation_kind in('exempt','pea_liquidation','cto_liquidation','interest_gain','unsupported','manual'));
alter table public.fiscal_regimes add column owner_user_id uuid references auth.users(id),add column configuration_revision integer not null default 1;
alter table public.fiscal_rules add column calculation_mode text not null default 'calculated' check(calculation_mode in('calculated','manual'));
alter table public.contracts add column fiscal_assignments jsonb not null default '{}'::jsonb check(jsonb_typeof(fiscal_assignments)='object');
create table public.envelope_fiscal_regimes(envelope_type_id uuid not null references public.envelope_types(id) on delete restrict,fiscal_regime_id uuid not null references public.fiscal_regimes(id) on delete restrict,is_active boolean not null default true,primary key(envelope_type_id,fiscal_regime_id));
insert into public.envelope_fiscal_regimes select envelope_type_id,id,true from public.fiscal_regimes;
alter table public.envelope_fiscal_regimes enable row level security;
alter table public.envelope_fiscal_regimes force row level security;
create policy principal_read on public.envelope_fiscal_regimes for select to authenticated using(public.is_authorized_user());
revoke all on public.envelope_fiscal_regimes from public,anon,authenticated;
grant select on public.envelope_fiscal_regimes to authenticated;

-- Transitional validation inside this transaction permits the single manual
-- regime to be compatible with both canonical types during formalisation.
create or replace function public.validate_contract_fiscal_regime() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if new.fiscal_regime_id is not null and not exists(select 1 from public.envelope_fiscal_regimes a join public.fiscal_regimes r on r.id=a.fiscal_regime_id where a.envelope_type_id=new.envelope_type_id and a.fiscal_regime_id=new.fiscal_regime_id and a.is_active and r.is_active) then raise exception 'Incompatible fiscal regime' using errcode='23514';end if;
 if new.fiscal_started_on is not null and new.fiscal_started_on>coalesce(new.closed_on,current_date) then raise exception 'Fiscal start date is inconsistent' using errcode='23514';end if;
 return new;
end$$;

-- Manual is a mode, not a free-text name or an automatic tax formula.
do $$declare rid uuid:=gen_random_uuid(); fid uuid:=gen_random_uuid(); today date:=(clock_timestamp() at time zone 'Europe/Paris')::date; et uuid;
begin
 select id into strict et from public.envelope_types where code='peg';
 insert into public.fiscal_regimes(id,code,envelope_type_id,label,description,calculation_kind,status)
 values(rid,'manual_declared',et,'Manuelle','Valeurs déclarées, sans calcul fiscal automatique.','manual','limited');
 insert into public.fiscal_rules(id,env,rule_code,rule_name,min_years,tax_rate,social_rate,valid_from,description,source,active,fiscal_regime_id,version_number,ir_rate_before,ps_rate_before,ir_base_type,ps_base_type,source_title,verified_on,status,calculation_mode)
 values(fid,'fr','manual_declared_v1',to_char(today,'YYYY.MM.DD')||' — Manuelle',0,0,0,today,'Mode manuel confirmé : PEG BRUT/NET, PER COL BRUT seul.','https://example.invalid/',true,rid,1,0,0,'none','none','Documentation MonPatrimoine — convention applicative, aucune certification fiscale',today,'verified','manual');
 insert into public.envelope_fiscal_regimes select id,rid,true from public.envelope_types where code in('peg','per_col');
 update public.envelope_types set default_fiscal_regime_id=rid,default_fiscal_rule_id=fid where code in('peg','per_col');
 -- Existing affected identities are resolved by canonical type AND valuation authority.
 -- Excluded PAGA is a positions contract and is not reassigned.
 update public.contracts c set fiscal_regime_id=rid from public.envelope_types t
 where c.envelope_type_id=t.id and t.code in('peg','per_col') and c.valuation_source='manual_situation';
end$$;

create function private.fiscal_contract_context(c public.contracts)returns jsonb language sql stable set search_path='' as $$
 select jsonb_build_object('fiscalStartedOn',c.fiscal_started_on,'historyComplete',c.fiscal_history_complete,'socialContributionsPaidEur',c.social_contributions_paid_eur)
$$;
-- Unknown assignment origin is kept unknown. Freeze the exact existing rule set,
-- not a fictitious past assignment or automatic adoption of a later version.
-- Reuse the existing exact-row, transaction-bound property permits for retired
-- source contracts. No guard is disabled or weakened. The verified application
-- principal is scoped to this server-side metadata initialization and restored.
-- Every permitted after-image differs only by fiscal_assignments.
do $$declare c public.contracts; snapshot jsonb; afterj jsonb; prior_claim text:=current_setting('request.jwt.claim.sub',true);begin
 for c in select * from public.contracts for update loop
  snapshot:=jsonb_build_object('version',1,'baseline',jsonb_build_object(
 'regimeId',c.fiscal_regime_id,'ruleIds',coalesce((select jsonb_agg(f.id order by f.id) from public.fiscal_rules f where f.fiscal_regime_id=c.fiscal_regime_id and f.active and f.status='verified' and f.valid_from<=(statement_timestamp() at time zone 'Europe/Paris')::date and (f.owner_user_id is null or f.owner_user_id=c.user_id)),'[]'::jsonb),
 'usePersonalRule',coalesce((select use_personal_rule from public.user_fiscal_regime_preferences p where p.user_id=c.user_id and p.fiscal_regime_id=c.fiscal_regime_id),false),
 'context',private.fiscal_contract_context(c),'recordedAt',statement_timestamp(),'origin','migration_freeze'),'entries','[]'::jsonb);
  if c.metadata->>'property_replaced_by' is not null then
   if not exists(select 1 from private.application_principal p where p.auth_user_id=c.user_id)then raise exception 'Unverified owner for protected fiscal initialization';end if;
   perform set_config('request.jwt.claim.sub',c.user_id::text,true);
   if not public.is_authorized_user()then raise exception 'Unauthorized protected fiscal initialization';end if;
   afterj:=to_jsonb(c)||jsonb_build_object('fiscal_assignments',snapshot);
   if (afterj-'fiscal_assignments')is distinct from(to_jsonb(c)-'fiscal_assignments')then raise exception 'Unexpected protected financial mutation';end if;
   insert into private.property_write_guards values(txid_current(),'contract',c.id,md5((to_jsonb(c)-'updated_at')::text),md5((afterj-'updated_at')::text));
  end if;
  update public.contracts set fiscal_assignments=snapshot where id=c.id;
  delete from private.property_write_guards where tx=txid_current()and entity='contract'and id=c.id;
 end loop;
 perform set_config('request.jwt.claim.sub',coalesce(prior_claim,''),true);
end$$;

create function private.check_fiscal_choice(typeid uuid,rid uuid,fid uuid,effect date,allow_inactive boolean default false) returns void language plpgsql security definer set search_path='' as $$
declare r public.fiscal_regimes; f public.fiscal_rules; type_code text;
begin
 select * into r from public.fiscal_regimes where id=rid;
 select code into type_code from public.envelope_types where id=typeid;
 if r.id is null or (not allow_inactive and not r.is_active) or (r.owner_user_id is not null and r.owner_user_id<>auth.uid())
 or not exists(select 1 from public.envelope_fiscal_regimes a where a.envelope_type_id=typeid and a.fiscal_regime_id=rid and (a.is_active or allow_inactive))
 or (type_code in('peg','per_col') and r.calculation_kind<>'manual') then raise exception 'Régime incompatible ou désactivé pour cette nouvelle affectation' using errcode='23514';end if;
 if fid is null then
  if r.calculation_kind<>'unsupported' then raise exception 'Choisissez une version précise' using errcode='23514';end if;
 else
  select * into f from public.fiscal_rules where id=fid and fiscal_regime_id=rid and active and status='verified' and (owner_user_id is null or owner_user_id=auth.uid());
  if f.id is null or effect is null or effect<f.valid_from then raise exception 'Version indisponible à la date d’effet choisie' using errcode='23514';end if;
 end if;
end$$;

create or replace function public.validate_contract_fiscal_regime() returns trigger language plpgsql security definer set search_path='' as $$
begin
 if tg_op='UPDATE' and new.fiscal_regime_id is distinct from old.fiscal_regime_id then raise exception 'Utilisez l’affectation fiscale datée dans la fiche du contrat' using errcode='23514';end if;
 if new.fiscal_started_on is not null and new.fiscal_started_on>coalesce(new.closed_on,current_date) then raise exception 'Fiscal start date is inconsistent' using errcode='23514';end if;
 return new;
end$$;

create function public.guard_contract_fiscal_assignments()returns trigger language plpgsql security definer set search_path='' as $$
declare initial jsonb; entry jsonb; effect date;
begin
 if tg_op='INSERT' then
  if not exists(select 1 from public.envelope_types where id=new.envelope_type_id and is_active) then raise exception 'Type désactivé pour une nouvelle sélection' using errcode='23514';end if;
  initial:=new.fiscal_assignments->'initial';
  if initial is not null then
   effect:=(initial->>'date')::date;
   if initial->>'regimeId' is distinct from new.fiscal_regime_id::text then raise exception 'Initial fiscal selection mismatch' using errcode='23514';end if;
   perform private.check_fiscal_choice(new.envelope_type_id,new.fiscal_regime_id,(initial->>'ruleId')::uuid,effect);
   entry:=jsonb_build_object('id',gen_random_uuid(),'date',effect,'regimeId',new.fiscal_regime_id,'ruleId',(initial->>'ruleId')::uuid,'name',coalesce((select rule_name from public.fiscal_rules where id=(initial->>'ruleId')::uuid),(select label from public.fiscal_regimes where id=new.fiscal_regime_id)),
    'context',private.fiscal_contract_context(new),'recordedAt',statement_timestamp(),'supersedes',null,'submissionId',gen_random_uuid());
  elsif new.fiscal_regime_id is not null then raise exception 'Choisissez une version et une date d’effet explicites' using errcode='23514';end if;
  new.fiscal_assignments:=jsonb_build_object('version',1,'baseline',jsonb_build_object('regimeId',null,'ruleIds','[]'::jsonb,'usePersonalRule',false,'context',private.fiscal_contract_context(new),'recordedAt',statement_timestamp(),'origin','new_contract'),'entries',case when entry is null then '[]'::jsonb else jsonb_build_array(entry) end);
 elsif new.fiscal_assignments is distinct from old.fiscal_assignments then
  if current_user<>'postgres' then raise exception 'Use fiscal assignment RPC' using errcode='42501';end if;
  if new.fiscal_assignments->'baseline' is distinct from old.fiscal_assignments->'baseline'
   or new.fiscal_assignments->>'version'<>'1'
   or jsonb_array_length(new.fiscal_assignments->'entries')<>jsonb_array_length(old.fiscal_assignments->'entries')+1
   or (select jsonb_agg(e order by ord) from jsonb_array_elements(new.fiscal_assignments->'entries')with ordinality a(e,ord) where ord<=jsonb_array_length(old.fiscal_assignments->'entries')) is distinct from nullif(old.fiscal_assignments->'entries','[]'::jsonb)
   then raise exception 'Fiscal assignments are append-only' using errcode='23514';end if;
 end if;
 return new;
end$$;
create trigger contracts_26_fiscal_assignments before insert or update of fiscal_assignments on public.contracts for each row execute function public.guard_contract_fiscal_assignments();
-- The ordinary role can keep editing contract metadata, but cannot write the
-- assignment ledger. SECURITY DEFINER RPC appends a single validated event.
revoke update on public.contracts from authenticated;
do $$declare cols text;begin select string_agg(quote_ident(attname),',') into cols from pg_attribute where attrelid='public.contracts'::regclass and attnum>0 and not attisdropped and attname<>'fiscal_assignments';execute 'grant update ('||cols||') on public.contracts to authenticated';end$$;

create function public.get_envelope_fiscal_catalog()returns jsonb language plpgsql stable security definer set search_path='' as $$
begin if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 return jsonb_build_object('types',(select coalesce(jsonb_agg(to_jsonb(t) order by label),'[]'::jsonb) from public.envelope_types t),
 'regimes',(select coalesce(jsonb_agg(to_jsonb(r) order by label),'[]'::jsonb) from public.fiscal_regimes r where r.owner_user_id is null or r.owner_user_id=auth.uid()),
 'rules',(select coalesce(jsonb_agg(to_jsonb(f) order by valid_from,version_number),'[]'::jsonb) from public.fiscal_rules f where f.fiscal_regime_id is not null and (f.owner_user_id is null or f.owner_user_id=auth.uid())),
 'allowed',(select coalesce(jsonb_agg(to_jsonb(a)),'[]'::jsonb) from public.envelope_fiscal_regimes a));
end$$;

create function public.save_envelope_type_configuration(requested jsonb)returns uuid language plpgsql security definer set search_path='' as $$
declare t public.envelope_types; tid uuid:=(requested->>'id')::uuid; label_value text:=btrim(requested->>'label'); rid uuid; fid uuid:=(requested->>'defaultRuleId')::uuid; default_regime uuid:=(requested->>'defaultRegimeId')::uuid;
begin
 if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 if label_value is null or char_length(label_value) not between 1 and 120 or jsonb_typeof(requested->'allowed') is distinct from 'array' then raise exception 'Libellé ou régimes autorisés invalides' using errcode='23514';end if;
 perform pg_advisory_xact_lock(hashtextextended('envelope-fiscal-catalog',0));
 if tid is null then
  tid:=gen_random_uuid();insert into public.envelope_types(id,code,label,is_standard) values(tid,'custom_'||replace(tid::text,'-',''),label_value,false) returning * into t;
 else
  select * into t from public.envelope_types where id=tid for update;
  if t.id is null then raise exception 'Type indisponible' using errcode='42501';end if;
  if t.configuration_revision is distinct from (requested->>'revision')::integer then raise exception 'Configuration modifiée simultanément' using errcode='40001';end if;
 end if;
 for rid in select value::uuid from jsonb_array_elements_text(requested->'allowed') loop
  if not exists(select 1 from public.fiscal_regimes r where r.id=rid and (r.is_active or exists(select 1 from public.envelope_fiscal_regimes a where a.envelope_type_id=tid and a.fiscal_regime_id=rid and a.is_active)) and (r.owner_user_id is null or r.owner_user_id=auth.uid()) and (t.code not in('peg','per_col') or r.calculation_kind='manual')) then raise exception 'Régime autorisé incompatible ou désactivé' using errcode='23514';end if;
 end loop;
 if default_regime is not null and not (requested->'allowed') ? default_regime::text then raise exception 'Le défaut doit faire partie des régimes autorisés' using errcode='23514';end if;
 update public.envelope_fiscal_regimes set is_active=false where envelope_type_id=tid;
 insert into public.envelope_fiscal_regimes select tid,value::uuid,true from jsonb_array_elements_text(requested->'allowed') on conflict(envelope_type_id,fiscal_regime_id)do update set is_active=true;
 if default_regime is not null then perform private.check_fiscal_choice(tid,default_regime,fid,greatest((clock_timestamp() at time zone 'Europe/Paris')::date,coalesce((select valid_from from public.fiscal_rules where id=fid),(clock_timestamp() at time zone 'Europe/Paris')::date)));elsif fid is not null then raise exception 'Défaut incohérent' using errcode='23514';end if;
 update public.envelope_types set label=label_value,is_active=coalesce((requested->>'active')::boolean,true),default_fiscal_regime_id=default_regime,default_fiscal_rule_id=fid,configuration_revision=configuration_revision+1 where id=tid;
 return tid;
end$$;

create function public.create_configured_fiscal_version(requested jsonb)returns uuid language plpgsql security definer set search_path='' as $$
declare template public.fiscal_rules; regime public.fiscal_regimes; rid uuid:=(requested->>'regimeId')::uuid; fid uuid:=gen_random_uuid(); effect date:=(requested->>'date')::date; name_value text:=btrim(requested->>'name'); next_version integer; previous uuid; months integer; ir numeric; ps numeric; ira numeric; psa numeric; allowance numeric; scope_value text;
begin
 if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 if effect is null or effect not between date '0001-01-01' and date '9999-12-31' or name_value is null or name_value not like to_char(effect,'YYYY.MM.DD')||' — _%' or char_length(name_value)>160 then raise exception 'Nom obligatoire : AAAA.MM.JJ — Nom, cohérent avec la date d’effet' using errcode='23514';end if;
 if exists(select 1 from jsonb_object_keys(requested) k where k not in('templateId','regimeId','expectedVersion','date','name','months','ir','ps','irAfter','psAfter','allowance','allowanceScope'))then raise exception 'Paramètre non pris en charge par ce moteur' using errcode='23514';end if;
 perform pg_advisory_xact_lock(hashtextextended('envelope-fiscal-catalog',0));
 select * into template from public.fiscal_rules where id=(requested->>'templateId')::uuid and active and status='verified' and (owner_user_id is null or owner_user_id=auth.uid()) for share;
 if template.id is null then raise exception 'Modèle exécutable indisponible' using errcode='23514';end if;
 select * into regime from public.fiscal_regimes where id=coalesce(rid,template.fiscal_regime_id) and is_active and (owner_user_id is null or owner_user_id=auth.uid()) for update;
 if regime.id is null or (rid is not null and template.fiscal_regime_id<>rid) then raise exception 'Modèle incompatible' using errcode='23514';end if;
 if (requested->>'expectedVersion')::integer is distinct from coalesce((select max(version_number) from public.fiscal_rules where fiscal_regime_id=regime.id),0) then raise exception 'Une version a été créée simultanément' using errcode='40001';end if;
 if rid is null then
  rid:=gen_random_uuid();insert into public.fiscal_regimes(id,code,envelope_type_id,label,description,calculation_kind,status,owner_user_id)values(rid,'custom_'||replace(rid::text,'-',''),regime.envelope_type_id,name_value,'Paramétrage personnel dérivé d’un modèle existant, non certifié.',regime.calculation_kind,'limited',auth.uid());
 else
  if regime.owner_user_id is null then raise exception 'Créez un régime personnel depuis le modèle standard' using errcode='23514';end if;
 end if;
 months:=(requested->>'months')::integer;ir:=(requested->>'ir')::numeric;ps:=(requested->>'ps')::numeric;ira:=(requested->>'irAfter')::numeric;psa:=(requested->>'psAfter')::numeric;allowance:=(requested->>'allowance')::numeric;scope_value:=requested->>'allowanceScope';
 if template.calculation_mode='manual' then
  if months is not null or allowance is not null or ir is distinct from 0 or ps is distinct from 0 or ira is not null or psa is not null then raise exception 'Le mode manuel ne calcule aucun impôt' using errcode='23514';end if;
 elsif ir is null or ps is null or ir not between 0 and 1 or ps not between 0 and 1 or months<0 or months>1200 or (months is not null and (ira is null or psa is null or ira not between 0 and 1 or psa not between 0 and 1)) or (months is null and (ira is not null or psa is not null)) or allowance<0 or ((allowance is null)<>(scope_value is null)) or (scope_value is not null and scope_value not in('contract','household_annual')) then raise exception 'Taux, seuil ou abattement incompatibles' using errcode='23514';end if;
 select id,version_number into previous,next_version from public.fiscal_rules where fiscal_regime_id=rid order by version_number desc limit 1;
 next_version:=coalesce(next_version,0)+1;
 insert into public.fiscal_rules(id,env,rule_code,rule_name,min_years,tax_rate,social_rate,valid_from,description,source,active,fiscal_regime_id,owner_user_id,version_number,age_threshold_months,ir_rate_before,ir_rate_after,ps_rate_before,ps_rate_after,ir_base_type,ps_base_type,ir_allowance_amount,ir_allowance_scope,parameters,source_title,verified_on,status,created_by,supersedes_id,calculation_mode)
 values(fid,template.env,'configured_'||replace(fid::text,'-',''),name_value,0,ir,ps,effect,'Hypothèse personnelle ; modèle et assiettes hérités de '||template.rule_name,template.source,true,rid,auth.uid(),next_version,months,ir,ira,ps,psa,template.ir_base_type,template.ps_base_type,allowance,scope_value,jsonb_build_object('templateRuleId',template.id,'personalConfiguration',true),template.source_title,template.verified_on,'verified',auth.uid(),previous,template.calculation_mode);
 -- No preference, contract, default or assignment is modified here.
 return fid;
end$$;

create function public.set_fiscal_regime_active(requested_id uuid,requested_active boolean,requested_revision integer)returns void language plpgsql security definer set search_path='' as $$
begin
 if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 perform pg_advisory_xact_lock(hashtextextended('envelope-fiscal-catalog',0));
 if not requested_active and exists(select 1 from public.envelope_types where is_active and default_fiscal_regime_id=requested_id) then raise exception 'Retirez d’abord ce régime des défauts de création' using errcode='23514';end if;
 update public.fiscal_regimes set is_active=requested_active,configuration_revision=configuration_revision+1 where id=requested_id and configuration_revision=requested_revision and (owner_user_id is null or owner_user_id=auth.uid());
 if not found then raise exception 'Configuration modifiée simultanément' using errcode='40001';end if;
end$$;

create function public.preview_contract_fiscal_assignment(requested_contract uuid,requested_regime uuid,requested_rule uuid,requested_date date)returns jsonb language plpgsql security definer set search_path='' as $$
declare c public.contracts; destination jsonb; token text; rule_name text; next_date date;
begin
 if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 perform pg_advisory_xact_lock_shared(hashtextextended('envelope-fiscal-catalog',0));
 select * into c from public.contracts where id=requested_contract and user_id=auth.uid();
 if c.id is null then raise exception 'Contrat indisponible' using errcode='42501';end if;
 if requested_date is null or (c.closed_on is not null and requested_date>c.closed_on) or (c.opened_on is not null and requested_date<c.opened_on) then raise exception 'Date d’affectation incompatible avec les dates du contrat' using errcode='23514';end if;
 perform private.check_fiscal_choice(c.envelope_type_id,requested_regime,requested_rule,requested_date);
 select e into destination from jsonb_array_elements(c.fiscal_assignments->'entries') e where e->>'date'=requested_date::text and not exists(select 1 from jsonb_array_elements(c.fiscal_assignments->'entries') n where n->>'supersedes'=e->>'id');
 select min((e->>'date')::date) into next_date from jsonb_array_elements(c.fiscal_assignments->'entries')e where (e->>'date')::date>requested_date;
 select coalesce((select f.rule_name from public.fiscal_rules f where f.id=requested_rule),(select r.label from public.fiscal_regimes r where r.id=requested_regime)) into rule_name;
 token:=md5(jsonb_build_object('contractId',c.id,'date',requested_date,'history',c.fiscal_assignments,'context',private.fiscal_contract_context(c),'regime',(select to_jsonb(r) from public.fiscal_regimes r where id=requested_regime),'rule',(select to_jsonb(f) from public.fiscal_rules f where id=requested_rule),'allowed',(select to_jsonb(a) from public.envelope_fiscal_regimes a where envelope_type_id=c.envelope_type_id and fiscal_regime_id=requested_regime))::text);
 return jsonb_build_object('contractId',c.id,'date',requested_date,'regimeId',requested_regime,'ruleId',requested_rule,'name',rule_name,'context',private.fiscal_contract_context(c),'destination',destination,'nextDate',next_date,'expected',token,'unchanged',destination->>'regimeId'=requested_regime::text and (destination->>'ruleId')::uuid is not distinct from requested_rule and destination->'context'=private.fiscal_contract_context(c));
end$$;

create function public.save_contract_fiscal_assignment(requested_contract uuid,requested_regime uuid,requested_rule uuid,requested_date date,requested_expected text,requested_submission uuid,requested_confirm boolean)returns uuid language plpgsql security definer set search_path='' as $$
declare c public.contracts; plan jsonb; entry jsonb; prior jsonb; eid uuid:=gen_random_uuid();
begin
 if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 perform pg_advisory_xact_lock_shared(hashtextextended('envelope-fiscal-catalog',0));
 select * into c from public.contracts where id=requested_contract and user_id=auth.uid() for update;
 if c.id is null then raise exception 'Contrat indisponible' using errcode='42501';end if;
 select e into prior from jsonb_array_elements(c.fiscal_assignments->'entries')e where e->>'submissionId'=requested_submission::text;
 if prior is not null then
  if prior->>'date'<>requested_date::text or prior->>'regimeId'<>requested_regime::text or (prior->>'ruleId')::uuid is distinct from requested_rule then raise exception 'Identité de soumission déjà utilisée' using errcode='23505';end if;
  return (prior->>'id')::uuid;
 end if;
 if not coalesce(requested_confirm,false) or requested_submission is null then raise exception 'Confirmez l’affectation présentée' using errcode='23514';end if;
 plan:=public.preview_contract_fiscal_assignment(requested_contract,requested_regime,requested_rule,requested_date);
 if requested_expected is distinct from plan->>'expected' then raise exception 'Affectation ou paramètres modifiés simultanément' using errcode='40001';end if;
 if coalesce((plan->>'unchanged')::boolean,false) then return (plan#>>'{destination,id}')::uuid;end if;
 entry:=jsonb_build_object('id',eid,'date',requested_date,'regimeId',requested_regime,'ruleId',requested_rule,'name',plan->>'name','context',plan->'context','recordedAt',clock_timestamp(),'supersedes',plan#>'{destination,id}','submissionId',requested_submission);
 update public.contracts set fiscal_assignments=jsonb_set(fiscal_assignments,'{entries}',(fiscal_assignments->'entries')||jsonb_build_array(entry)) where id=c.id;
 return eid;
end$$;

-- Existing mutation endpoints adopted the latest version globally; retire their
-- client ACLs in favour of explicit catalogue creation and dated assignments.
revoke execute on function public.create_fiscal_rule_version(uuid,text,date,integer,numeric,numeric,numeric,numeric,text,text,numeric,text,jsonb,text,text,text,date),public.set_fiscal_rule_preference(uuid,boolean) from public,anon,authenticated;
revoke all on function private.fiscal_contract_context(public.contracts),private.check_fiscal_choice(uuid,uuid,uuid,date,boolean),public.guard_contract_fiscal_assignments() from public,anon,authenticated;
revoke all on function public.get_envelope_fiscal_catalog(),public.save_envelope_type_configuration(jsonb),public.create_configured_fiscal_version(jsonb),public.set_fiscal_regime_active(uuid,boolean,integer),public.preview_contract_fiscal_assignment(uuid,uuid,uuid,date),public.save_contract_fiscal_assignment(uuid,uuid,uuid,date,text,uuid,boolean) from public,anon;
grant execute on function public.get_envelope_fiscal_catalog(),public.save_envelope_type_configuration(jsonb),public.create_configured_fiscal_version(jsonb),public.set_fiscal_regime_active(uuid,boolean,integer),public.preview_contract_fiscal_assignment(uuid,uuid,uuid,date),public.save_contract_fiscal_assignment(uuid,uuid,uuid,date,text,uuid,boolean) to authenticated;
commit;
