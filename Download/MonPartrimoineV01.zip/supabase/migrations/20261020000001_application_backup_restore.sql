-- LOCAL PREPARATION ONLY. No route/grant exposes this operator-only restore.
-- Fixed scope, full-row text cells (including JSON/numeric), exact row permits.
begin;
create table private.app_backup_datasets (
 name text primary key, relation regclass not null, predicate text not null,
 ordinal integer not null, shared boolean not null default false,
 columns text[] not null default '{}', primary_columns text[] not null default '{}'
);
revoke all on private.app_backup_datasets from public,anon,authenticated,service_role;
insert into private.app_backup_datasets(name,relation,predicate,ordinal,shared) values
 ('currencies','public.currencies','true',1,true),
 ('envelope_types','public.envelope_types','true',2,true),
 ('envelope_fiscal_regimes','public.envelope_fiscal_regimes','true',3,true),
 ('geographic_regions','public.geographic_regions','true',4,true),
 ('exposure_countries','public.exposure_countries','true',5,true),
 ('sector_activities_shared','public.sector_activities','sector_id in (select id from public.sectors where owner_user_id is null)',6,true),
 ('fx_rates','public.fx_rates','true',7,true),
 ('sectors_shared','public.sectors','owner_user_id is null',8,true),
 ('themes_shared','public.themes','owner_user_id is null',9,true),
 ('fiscal_regimes_shared','public.fiscal_regimes','owner_user_id is null',10,true),
 ('fiscal_rules_shared','public.fiscal_rules','owner_user_id is null',11,true),
 ('sectors','public.sectors','owner_user_id=auth.uid()',19,false),
 ('sector_activities','public.sector_activities','sector_id in (select id from public.sectors where owner_user_id=auth.uid())',20,false),
 ('themes','public.themes','owner_user_id=auth.uid()',21,false),
 ('fiscal_regimes','public.fiscal_regimes','owner_user_id=auth.uid()',22,false),
 ('fiscal_rules','public.fiscal_rules','owner_user_id=auth.uid()',23,false),
 ('assets','public.assets','owner_user_id=auth.uid()',24,false),
 ('contracts','public.contracts','user_id=auth.uid()',25,false),
 ('positions','public.positions','user_id=auth.uid()',26,false),
 ('cash_balances','public.cash_balances','user_id=auth.uid()',27,false),
 ('cash_flows','public.cash_flows','user_id=auth.uid()',28,false),
 ('asset_prices','public.asset_prices','asset_id in (select id from public.assets where owner_user_id=auth.uid())',29,false),
 ('target_allocations','public.target_allocations','user_id=auth.uid()',30,false),
 ('position_snapshots','public.position_snapshots','user_id=auth.uid()',31,false),
 ('cash_balance_snapshots','public.cash_balance_snapshots','user_id=auth.uid()',32,false),
 ('contract_manual_situations','public.contract_manual_situations','user_id=auth.uid()',33,false),
 ('contract_manual_simulations','public.contract_manual_simulations','user_id=auth.uid()',34,false),
 ('patrimonial_legacy_sources','public.patrimonial_legacy_sources','user_id=auth.uid()',35,false),
 ('patrimonial_legacy_account_maps','public.patrimonial_legacy_account_maps','user_id=auth.uid()',36,false),
 ('patrimonial_daily_captures','public.patrimonial_daily_captures','user_id=auth.uid() and state=''published''',37,false),
 ('property_consolidations','public.property_consolidations','user_id=auth.uid()',38,false),
 ('asset_sector_exposures','public.asset_sector_exposures','asset_id in (select id from public.assets where owner_user_id=auth.uid())',39,false),
 ('asset_activity_exposures','public.asset_activity_exposures','asset_id in (select id from public.assets where owner_user_id=auth.uid())',40,false),
 ('asset_geography_exposures','public.asset_geography_exposures','asset_id in (select id from public.assets where owner_user_id=auth.uid())',41,false),
 ('asset_theme_exposure_sets','public.asset_theme_exposure_sets','asset_id in (select id from public.assets where owner_user_id=auth.uid())',42,false),
 ('asset_theme_exposures','public.asset_theme_exposures','asset_id in (select id from public.assets where owner_user_id=auth.uid())',43,false),
 ('asset_exposure_versions','public.asset_exposure_versions','owner_user_id=auth.uid()',44,false),
 ('user_sector_labels','public.user_sector_labels','user_id=auth.uid()',45,false),
 ('user_fiscal_regime_preferences','public.user_fiscal_regime_preferences','user_id=auth.uid()',46,false),
 ('asset_usage','private.asset_usage','user_id=auth.uid()',47,false);
-- Shared reference usage flags are monotonic infrastructure evidence: preserve
-- them in place, never roll other users' usage backwards during a personal restore.
update private.app_backup_datasets d set columns=(select array_agg(attname::text order by attnum) from pg_attribute where attrelid=d.relation and attnum>0 and not attisdropped and not(d.shared and attname in('has_been_used','updated_at'))),
 primary_columns=(select array_agg(a.attname::text order by k.ord) from pg_index i cross join lateral unnest(i.indkey) with ordinality k(num,ord) join pg_attribute a on a.attrelid=i.indrelid and a.attnum=k.num where i.indrelid=d.relation and i.indisprimary);

create table private.app_restore_permits (
 tx bigint not null, backend integer not null, relation oid not null,
 operation text not null check(operation in('INSERT','UPDATE','DELETE')),
 before_row jsonb, after_row jsonb
);
revoke all on private.app_restore_permits from public,anon,authenticated,service_role;
create function public.app_restore_permitted(rel oid, op text, prior jsonb, next_row jsonb)
returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from private.app_restore_permits p where p.tx=txid_current() and p.backend=pg_backend_pid()
 and p.relation=rel and p.operation=op and p.before_row is not distinct from prior and p.after_row is not distinct from next_row)
$$;
revoke all on function public.app_restore_permitted(oid,text,jsonb,jsonb) from public,anon,authenticated,service_role;
grant execute on function public.app_restore_permitted(oid,text,jsonb,jsonb) to authenticated,service_role;
-- Trigger bodies retain ordinary guards. Only exact planned before/after rows in
-- this transaction/backend may take the restore branch. No client-controlled GUC.
do $adapt$ declare signature text; original text; replacement text; begin
 foreach signature in array array[
 'public.guard_asset_lifecycle()','public.guard_contract_identity()','public.guard_contract_dependency()',
 'public.guard_position_observations()','public.guard_dated_cash_balance_observations()',
 'public.guard_cash_balance_phase74()','public.guard_cash_flow_phase74()',
 'public.guard_fiscal_rule_history()','public.guard_fx_rate_immutability()',
 'public.guard_contract_fiscal_assignments()','private.guard_color_provenance()',
 'private.guard_exposure_version()','private.guard_location_history()',
 'private.guard_property_rows()','private.guard_published_capture()','private.guard_manual_history()',
 'public.record_asset_use()','private.mark_analysis_reference_used()',
 'public.serialize_sector_writes()','public.set_updated_at()'
 ] loop
  original:=pg_get_functiondef(signature::regprocedure);
  replacement:=regexp_replace(original,'\mbegin\M',
   E'begin\n if public.app_restore_permitted(tg_relid,tg_op,case when tg_op=''INSERT'' then null else to_jsonb(old) end,case when tg_op=''DELETE'' then null else to_jsonb(new) end) then if tg_op=''DELETE'' then return old;else return new;end if;end if;\n','i');
  if replacement=original then raise exception 'Restore guard adaptation failed: %',signature;end if;
  execute replacement;
 end loop;
end $adapt$;

create function private.app_backup_schema() returns text language sql stable security definer set search_path='' as $$
 select encode(extensions.digest(string_agg(s,'|' order by s),'sha256'),'hex') from (
 select d.name||':'||a.attname||':'||format_type(a.atttypid,a.atttypmod)||':'||a.attnotnull as s from private.app_backup_datasets d join pg_attribute a on a.attrelid=d.relation and a.attnum>0 and not a.attisdropped
 union all select d.name||':'||pg_get_constraintdef(c.oid) from private.app_backup_datasets d join pg_constraint c on c.conrelid=d.relation
 union all select d.name||':'||pg_get_triggerdef(t.oid)||':'||pg_get_functiondef(t.tgfoid) from private.app_backup_datasets d join pg_trigger t on t.tgrelid=d.relation and not t.tgisinternal
 ) v
$$;
-- Trusted SQL text is built exclusively from the installed column/type catalogue.
-- Cast each text cell directly: jsonb_populate_record would turn a JSON cell
-- into a JSON string and cannot distinguish JSON null from SQL NULL.
create function private.app_backup_typed_rows(rel regclass) returns text language sql stable security definer set search_path='' as $$
 select 'select '||string_agg(format('(v->>%L)::%s as %I',a.attname,format_type(a.atttypid,a.atttypmod),a.attname),',' order by a.attnum)||' from jsonb_array_elements($1) z(v)'
 from pg_attribute a where a.attrelid=rel and a.attnum>0 and not a.attisdropped
$$;
create function private.app_backup_snapshot() returns jsonb language plpgsql stable security definer set search_path='' set timezone='UTC' set datestyle='ISO,YMD' as $$
declare d record; rows_json jsonb; data jsonb:='{}'; prefs jsonb; begin
 if public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 if exists(select 1 from pg_class c join pg_namespace n on n.oid=c.relnamespace where n.nspname='public' and c.relkind in('r','p') and c.oid not in(select relation from private.app_backup_datasets)
 and c.relname not in('profiles','asset_price_provider_capabilities','asset_price_refresh_status','fx_provider_attempts','price_provider_configurations')) then raise exception 'Unclassified application table';end if;
 if exists(select 1 from public.patrimonial_daily_captures where user_id=auth.uid() and state<>'published') then raise exception 'Capture in progress; retry later';end if;
 for d in select * from private.app_backup_datasets order by ordinal loop
  if d.columns is distinct from (select array_agg(attname::text order by attnum) from pg_attribute where attrelid=d.relation and attnum>0 and not attisdropped and not(d.shared and attname in('has_been_used','updated_at'))) then raise exception 'Unclassified schema change';end if;
  execute format('select coalesce(jsonb_agg(cells order by cells::text collate "C"),''[]'') from (select jsonb_build_array(%s) cells from %s r where %s) q',(select string_agg(format('r.%I::text',c),',') from unnest(d.columns) c),d.relation,d.predicate) into rows_json;
  data:=data||jsonb_build_object(d.name,jsonb_build_object('columns',d.columns,'rows',rows_json));
 end loop;
 select jsonb_build_object('preferences',preferences::text,'interface_preferences',interface_preferences::text,'strategy_parameters',strategy_parameters::text) into prefs from public.profiles where auth_user_id=auth.uid();
 return jsonb_build_object('format','monpatrimoine-app-backup/1','owner',auth.uid(),'schema',private.app_backup_schema(),'datasets',data,'preferences',prefs);
end$$;

create function private.app_backup_validate(doc jsonb) returns void language plpgsql security definer set search_path='' set timezone='UTC' set datestyle='ISO,YMD' as $$
declare d record; row_cells jsonb; cell jsonb; obj jsonb; col text; i integer; normalized jsonb; collision boolean; owned boolean; begin
 if public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 if jsonb_typeof(doc)<>'object' or (select array_agg(k order by k) from jsonb_object_keys(doc) k)<>array['datasets','format','owner','preferences','schema']::text[]
 or doc->>'format' is distinct from 'monpatrimoine-app-backup/1' or doc->>'owner' is distinct from auth.uid()::text or doc->>'schema' is distinct from private.app_backup_schema() then raise exception 'Incompatible archive or owner';end if;
 if (select array_agg(k order by k) from jsonb_object_keys(doc->'datasets') k) is distinct from (select array_agg(name order by name) from private.app_backup_datasets) then raise exception 'Unexpected dataset';end if;
 if (select array_agg(k order by k) from jsonb_object_keys(doc->'preferences') k) is distinct from array['interface_preferences','preferences','strategy_parameters']::text[] then raise exception 'Identity/secret preferences forbidden';end if;
 for col,cell in select * from jsonb_each(doc->'preferences') loop
  if jsonb_typeof(cell)<>'string' or jsonb_typeof((cell#>>'{}')::jsonb)<>'object' then raise exception 'Invalid preferences';end if;
 end loop;
 for d in select * from private.app_backup_datasets order by ordinal loop
  if doc#>array['datasets',d.name,'columns'] is distinct from to_jsonb(d.columns)
   or (select array_agg(k order by k) from jsonb_object_keys(doc#>array['datasets',d.name]) k) is distinct from array['columns','rows']::text[]
   or jsonb_typeof(doc#>array['datasets',d.name,'rows']) is distinct from 'array' then raise exception 'Unexpected columns or rows';end if;
  for row_cells in select value from jsonb_array_elements(doc#>array['datasets',d.name,'rows']) loop
   if jsonb_typeof(row_cells)<>'array' or jsonb_array_length(row_cells)<>cardinality(d.columns) then raise exception 'Invalid row';end if;
   obj:='{}';i:=0;
   foreach col in array d.columns loop
    cell:=row_cells->i;i:=i+1;
    if jsonb_typeof(cell) not in('string','null') then raise exception 'Text/null cells required';end if;
    if col in('user_id','owner_user_id','created_by') and cell<>'null'::jsonb and cell#>>'{}'<>auth.uid()::text then raise exception 'Foreign ownership forbidden';end if;
    obj:=obj||jsonb_build_object(col,cell);
   end loop;
   -- Input type casts must be valid before any replacement. PostgreSQL handles
   -- exact NUMERIC/JSON; JavaScript never parses their content as numbers.
   execute format('select to_jsonb(x) from (%s) x',private.app_backup_typed_rows(d.relation)) into normalized using jsonb_build_array(obj);
   if not d.shared then
    -- Dependent ownership comes from the validated TARGET graph, not only from
    -- currently present roots: an ordinarily deleted sector/asset must be restorable.
    if d.name='sector_activities' then
     select exists(select 1 from jsonb_array_elements(doc#>'{datasets,sectors,rows}') r where r->>((array_position((select columns from private.app_backup_datasets where name='sectors'),'id'))-1)=normalized->>'sector_id') into owned;
    elsif d.name in('asset_prices','asset_sector_exposures','asset_activity_exposures','asset_geography_exposures','asset_theme_exposure_sets','asset_theme_exposures','asset_exposure_versions') then
     select exists(select 1 from jsonb_array_elements(doc#>'{datasets,assets,rows}') r where r->>((array_position((select columns from private.app_backup_datasets where name='assets'),'id'))-1)=normalized->>'asset_id') into owned;
    else
     execute format('select (%s) from (%s) x',d.predicate,private.app_backup_typed_rows(d.relation)) into owned using jsonb_build_array(obj);
    end if;
    if owned is not true then raise exception 'Row outside owned scope';end if;
    execute format('select exists(select 1 from %s r where not (%s) and exists(select 1 from (%s) x where %s))',d.relation,d.predicate,private.app_backup_typed_rows(d.relation),(select string_agg(format('r.%I=x.%I',c,c),' and ') from unnest(d.primary_columns) c)) into collision using jsonb_build_array(obj);
    if collision then raise exception 'Foreign primary key collision';end if;
   end if;
  end loop;
 end loop;
end$$;

create function private.app_backup_replace(doc jsonb,expected_digest text) returns text language plpgsql security definer set search_path='' set timezone='UTC' set datestyle='ISO,YMD' as $$
declare d record; col text; cells jsonb; obj jsonb; objects jsonb; cols text; updates text; pk text; current_doc jsonb; begin
 -- Operator only: there is deliberately no application/browser grant.
 if public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 -- Serializes *all* ordinary DML, including writers unaware of advisory locks.
 for d in select distinct relation::text as name from private.app_backup_datasets order by name loop execute 'lock table '||d.name||' in share row exclusive mode';end loop;
 lock table public.profiles in share row exclusive mode;
 perform private.app_backup_validate(doc);
 current_doc:=private.app_backup_snapshot();
 if encode(extensions.digest(current_doc::text,'sha256'),'hex') is distinct from expected_digest then raise exception 'Concurrent state changed' using errcode='40001';end if;
 for d in select * from private.app_backup_datasets where shared loop
  if current_doc#>array['datasets',d.name] is distinct from doc#>array['datasets',d.name] then raise exception 'Shared reference changed: %',d.name;end if;
 end loop;
 -- Typed private staging. No archive-supplied table, SQL or path is executed.
 create temporary table app_restore_input(name text primary key,objects jsonb) on commit drop;
 for d in select * from private.app_backup_datasets where not shared order by ordinal loop
  objects:='[]';
  for cells in select value from jsonb_array_elements(doc#>array['datasets',d.name,'rows']) loop
   select jsonb_object_agg(c,cells->(ord-1)::int) into obj from unnest(d.columns) with ordinality t(c,ord);
   objects:=objects||jsonb_build_array(obj);
  end loop;
  insert into app_restore_input values(d.name,objects);
 end loop;
 -- Row permits cannot be manufactured by authenticated/service_role callers.
 for d in select * from private.app_backup_datasets where not shared order by ordinal desc loop
  -- Keep surviving root/reference identities so excluded operational rows are
  -- not cascade-deleted. Children are fully replaced; constraints stay active.
  if d.name in('assets','contracts','sectors','sector_activities','themes','fiscal_regimes','fiscal_rules') then
   execute format('insert into private.app_restore_permits select txid_current(),pg_backend_pid(),%s,''DELETE'',to_jsonb(r),null from %s r where %s and not exists(select 1 from (%s) x where x.id=r.id)',d.relation::oid,d.relation,d.predicate,private.app_backup_typed_rows(d.relation)) using (select a.objects from app_restore_input a where name=d.name);
  else
   execute format('insert into private.app_restore_permits select txid_current(),pg_backend_pid(),%s,''DELETE'',to_jsonb(r),null from %s r where %s',d.relation::oid,d.relation,d.predicate);
  end if;
  execute format('delete from %s r where %s and public.app_restore_permitted(%s,''DELETE'',to_jsonb(r),null)',d.relation,d.predicate,d.relation::oid);
 end loop;
 for d in select * from private.app_backup_datasets where not shared order by ordinal loop
  select a.objects into objects from app_restore_input a where name=d.name;
  cols:=(select string_agg(quote_ident(c),',') from unnest(d.columns) c);
  pk:=(select string_agg(quote_ident(c),',') from unnest(d.primary_columns) c);
  updates:=(select string_agg(format('%I=excluded.%I',c,c),',') from unnest(d.columns) c where not c=any(d.primary_columns));
  -- Compute exact UPDATE/INSERT permits against the current surviving rows.
  execute format('insert into private.app_restore_permits select txid_current(),pg_backend_pid(),%s,''INSERT'',null,to_jsonb(x) from (%s) x',d.relation::oid,private.app_backup_typed_rows(d.relation)) using objects;
  execute format('insert into private.app_restore_permits select txid_current(),pg_backend_pid(),%s,''UPDATE'',to_jsonb(r),to_jsonb(x) from (%s) x join %s r on %s',d.relation::oid,private.app_backup_typed_rows(d.relation),d.relation,(select string_agg(format('r.%I=x.%I',c,c),' and ') from unnest(d.primary_columns) c)) using objects;
  execute format('insert into %s(%s) select %s from (%s) x on conflict(%s) %s',d.relation,cols,cols,private.app_backup_typed_rows(d.relation),pk,case when updates is null then 'do nothing' else 'do update set '||updates end) using objects;
 end loop;
 update public.profiles set preferences=(doc#>>'{preferences,preferences}')::jsonb,interface_preferences=(doc#>>'{preferences,interface_preferences}')::jsonb,strategy_parameters=(doc#>>'{preferences,strategy_parameters}')::jsonb where auth_user_id=auth.uid();
 set constraints all immediate;
 if private.app_backup_snapshot() is distinct from doc then raise exception 'Canonical restored content differs';end if;
 delete from private.app_restore_permits where tx=txid_current() and backend=pg_backend_pid();
 return encode(extensions.digest(doc::text,'sha256'),'hex');
end$$;
revoke all on function private.app_backup_schema(),private.app_backup_typed_rows(regclass),private.app_backup_snapshot(),private.app_backup_validate(jsonb),private.app_backup_replace(jsonb,text) from public,anon,authenticated,service_role;
commit;
