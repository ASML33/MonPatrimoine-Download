-- Explicit dated empty AV creation; no initialization of existing contracts.
begin;
set local lock_timeout='5s';
set local statement_timeout='45s';
do $$begin
 if private.app_backup_schema()<>'7b8d63de5bc463697251a1c84a5ab7a2d34723fd9b0b94c0654c313d8b5a34f1'
 or md5(pg_get_functiondef('public.save_life_insurance_amount(uuid,uuid,timestamptz,date,numeric,text)'::regprocedure))<>'062b7fc287886f9fe59967f27fad7638'
 then raise exception 'Empty AV predecessor drift';end if;
end$$;

create function public.create_empty_life_insurance_contract(requested_id uuid,requested_fields jsonb,requested_date date,requested_receipt text)
returns uuid language plpgsql security invoker set search_path='' as $$
declare c public.contracts;p public.positions;v public.contracts;created uuid;
begin
 if auth.uid() is null or public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 if requested_id is null or requested_receipt is null or requested_receipt!~'^[0-9a-f]{64}$'
 or jsonb_typeof(requested_fields) is distinct from 'object'
 or exists(select 1 from jsonb_object_keys(requested_fields)k where k not in('name','display_name','institution_name','currency_code','opened_on','closed_on','dashboard_tile_name','color','color_origin','fiscal_started_on','fiscal_history_complete','social_contributions_paid_eur','fiscal_regime_id','pea_pme_standard_confirmed'))
 then raise exception 'Invalid creation' using errcode='22023';end if;
 v:=jsonb_populate_record(null::public.contracts,requested_fields);
 if requested_date is null or requested_date>(now()at time zone'Europe/Paris')::date or requested_date<v.opened_on
 or v.closed_on is not null or v.currency_code is distinct from 'EUR' or v.fiscal_started_on is null
 then raise exception 'Invalid empty AV date or currency' using errcode='23514';end if;
 -- Serialize the same creation request across all native unique constraints.
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(requested_id::text,0));
 insert into public.contracts(id,user_id,name,display_name,institution_name,envelope_type_id,currency_code,opened_on,closed_on,dashboard_tile_name,color,color_origin,fiscal_started_on,fiscal_history_complete,social_contributions_paid_eur,metadata)
 select requested_id,auth.uid(),v.name,v.display_name,v.institution_name,t.id,'EUR',v.opened_on,null,v.dashboard_tile_name,v.color,coalesce(v.color_origin,'automatic'),v.fiscal_started_on,coalesce(v.fiscal_history_complete,false),v.social_contributions_paid_eur,
 jsonb_build_object('form_creation_receipt',requested_receipt)
 from public.envelope_types t where t.code='assurance_vie' and t.is_active
 on conflict(id)do nothing returning id into created;
 if created is null then
  select *into c from public.contracts where id=requested_id and user_id=auth.uid();
  if c.id is null or c.metadata->>'form_creation_receipt' is distinct from requested_receipt
  then raise exception 'Creation conflict' using errcode='40001';end if;
  -- A retry never initializes or replaces observations on an existing contract.
  return c.id;
 end if;
 select *into strict p from public.positions where contract_id=created and user_id=auth.uid();
 if p.quantity is not null or p.average_cost_per_unit is not null or p.metadata is distinct from '{"initial_amount":{"version":1,"kind":"empty_euro_fund"}}'::jsonb
 or exists(select 1 from public.position_snapshots where position_id=p.id)
 then raise exception 'Automatic empty support changed' using errcode='40001';end if;
 perform public.save_life_insurance_amount(p.id,requested_id,p.updated_at,requested_date,0,'EUR');
 return created;
end$$;
revoke all on function public.create_empty_life_insurance_contract(uuid,jsonb,date,text)from public,anon;
grant execute on function public.create_empty_life_insurance_contract(uuid,jsonb,date,text)to authenticated;
commit;
