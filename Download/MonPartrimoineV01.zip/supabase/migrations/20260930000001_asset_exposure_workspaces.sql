-- Phase 7.3A: draft and effective slots, no detailed version history.
begin;
create table public.sector_activities (
 id uuid primary key default gen_random_uuid(), sector_id uuid not null references public.sectors(id) on delete restrict,
 code text not null check(code ~ '^[a-z0-9_-]{1,80}$'), name text not null check(length(btrim(name)) between 1 and 160), unique(sector_id,code));
insert into public.sector_activities(sector_id,code,name) select id,'unspecified','Non dÃ©taillÃ©' from public.sectors;
create table public.geographic_regions(code text primary key check(code ~ '^[a-z_]{1,50}$'),name text not null);
insert into public.geographic_regions values ('unspecified','Non spÃ©cifiÃ©'),('north_america','AmÃ©rique du Nord'),('central_america','AmÃ©rique centrale'),('south_america','AmÃ©rique du Sud'),('europe','Europe'),('africa','Afrique'),('asia','Asie'),('oceania','OcÃ©anie');
create table public.exposure_countries(id uuid primary key default gen_random_uuid(),code text not null unique check(code='unspecified' or code ~ '^[A-Z]{2}$'),name text not null,region_code text not null references public.geographic_regions(code) on delete restrict);
insert into public.exposure_countries(code,name,region_code) values('unspecified','Non spÃ©cifiÃ©','unspecified');
alter table public.sector_activities enable row level security;
alter table public.sector_activities force row level security;
revoke all on public.sector_activities from public,anon,authenticated;
grant select on public.sector_activities to authenticated;
create policy reference_read on public.sector_activities for select to authenticated using(public.is_authorized_user());
alter table public.geographic_regions enable row level security;
alter table public.geographic_regions force row level security;
revoke all on public.geographic_regions from public,anon,authenticated;
grant select on public.geographic_regions to authenticated;
create policy reference_read on public.geographic_regions for select to authenticated using(public.is_authorized_user());
alter table public.exposure_countries enable row level security;
alter table public.exposure_countries force row level security;
revoke all on public.exposure_countries from public,anon,authenticated;
grant select on public.exposure_countries to authenticated;
create policy reference_read on public.exposure_countries for select to authenticated using(public.is_authorized_user());
alter table public.asset_sector_exposures add column stage text not null default 'effective' check(stage in ('draft','effective'));
alter table public.asset_sector_exposures drop constraint asset_sector_exposures_pkey;
alter table public.asset_sector_exposures add primary key(asset_id,stage,sector_id);
alter table public.asset_sector_exposures add column data_date date check(data_date is null or isfinite(data_date)),
 add column source text check(source is null or length(btrim(source)) between 1 and 2000),
 add column origin text check(origin is null or origin ~ '^[a-z0-9_-]{1,50}$'),
 add column updated_at timestamptz not null default now();
revoke all on public.asset_sector_exposures from public,anon,authenticated;
grant select on public.asset_sector_exposures to authenticated;
create table public.asset_activity_exposures (

 asset_id uuid not null references public.assets(id) on delete cascade,

 activity_id uuid not null references public.sector_activities(id) on delete restrict,
 weight_percent numeric(5,2) not null check(weight_percent>0 and weight_percent<=100),
 stage text not null default 'draft' check(stage in ('draft','effective')),
 primary key(asset_id,stage,activity_id));
alter table public.asset_activity_exposures enable row level security;
alter table public.asset_activity_exposures force row level security;
create policy exposure_read on public.asset_activity_exposures for select to authenticated using(
 exists(select 1 from public.assets a where a.id=asset_id));
create trigger serialize_exposure before insert or update or delete on public.asset_activity_exposures
 for each row execute function public.serialize_sector_writes();
alter table public.asset_activity_exposures add column data_date date check(data_date is null or isfinite(data_date)),
 add column source text check(source is null or length(btrim(source)) between 1 and 2000),
 add column origin text check(origin is null or origin ~ '^[a-z0-9_-]{1,50}$'),
 add column updated_at timestamptz not null default now();
revoke all on public.asset_activity_exposures from public,anon,authenticated;
grant select on public.asset_activity_exposures to authenticated;
create table public.asset_geography_exposures (

 asset_id uuid not null references public.assets(id) on delete cascade,

 country_id uuid not null references public.exposure_countries(id) on delete restrict,
 weight_percent numeric(5,2) not null check(weight_percent>0 and weight_percent<=100),
 stage text not null default 'draft' check(stage in ('draft','effective')),
 primary key(asset_id,stage,country_id));
alter table public.asset_geography_exposures enable row level security;
alter table public.asset_geography_exposures force row level security;
create policy exposure_read on public.asset_geography_exposures for select to authenticated using(
 exists(select 1 from public.assets a where a.id=asset_id));
create trigger serialize_exposure before insert or update or delete on public.asset_geography_exposures
 for each row execute function public.serialize_sector_writes();
alter table public.asset_geography_exposures add column data_date date check(data_date is null or isfinite(data_date)),
 add column source text check(source is null or length(btrim(source)) between 1 and 2000),
 add column origin text check(origin is null or origin ~ '^[a-z0-9_-]{1,50}$'),
 add column updated_at timestamptz not null default now();
revoke all on public.asset_geography_exposures from public,anon,authenticated;
grant select on public.asset_geography_exposures to authenticated;

grant insert,update,delete on public.sector_activities to authenticated;
create policy principal_activities on public.sector_activities for all to authenticated
using(public.is_authorized_user()) with check(public.is_authorized_user());
create or replace function public.enforce_sector_total() returns trigger language plpgsql security definer set search_path='' as $$
begin if (select coalesce(sum(weight_percent),0) from public.asset_sector_exposures where asset_id=new.asset_id and stage=new.stage)>100 then raise exception 'Sector total exceeds 100' using errcode='23514'; end if; return null; end $$;
-- Preserve the legacy personal state of the authorized principal, and archive
-- all original rows privately. No other identity's data is imported.
update public.asset_sector_exposures set stage='draft' where asset_id in
(select asset_id from public.asset_sector_exposures group by asset_id having sum(weight_percent)<100);
do $$ declare x record; principal uuid; begin
 select auth_user_id into principal from private.application_principal;
 for x in select asset_id,sum(weight_percent) total from private.legacy_sector_overrides where user_id=principal group by asset_id loop
  delete from public.asset_sector_exposures where asset_id=x.asset_id and stage=case when x.total=100 then 'effective' else 'draft' end;
  insert into public.asset_sector_exposures(asset_id,sector_id,weight_percent,stage)
  select asset_id,sector_id,weight_percent,case when x.total=100 then 'effective' else 'draft' end
  from private.legacy_sector_overrides where user_id=principal and asset_id=x.asset_id;
 end loop;
end $$;
create view public.asset_exposure_rows with(security_invoker=true) as
select asset_id,'sector'::text dimension,stage,sector_id reference_id,weight_percent,data_date,source,origin,updated_at from public.asset_sector_exposures
union all select asset_id,'activity',stage,activity_id,weight_percent,data_date,source,origin,updated_at from public.asset_activity_exposures
union all select asset_id,'geography',stage,country_id,weight_percent,data_date,source,origin,updated_at from public.asset_geography_exposures;
revoke all on public.asset_exposure_rows from public,anon,authenticated;
grant select on public.asset_exposure_rows to authenticated;
create function public.effective_asset_exposures(requested_assets uuid[])
returns table(asset_id uuid,dimension text,reference_id uuid,weight_percent numeric,data_date date,source text,origin text,updated_at timestamptz)
language sql stable security invoker set search_path='' as $$
select asset_id,dimension,reference_id,weight_percent,data_date,source,origin,updated_at from public.asset_exposure_rows
where asset_id=any(requested_assets) and stage='effective';
$$;
create function public.asset_exposure_status(requested_assets uuid[])
returns table(asset_id uuid,dimension text,stage text,total_percent numeric,is_complete boolean)
language sql stable security invoker set search_path='' as $$
select a.id,d.dimension,t.stage,coalesce(sum(e.weight_percent),0),coalesce(sum(e.weight_percent),0)=100
from public.assets a cross join (values('sector'),('activity'),('geography')) d(dimension)
cross join (values('draft'),('effective')) t(stage)
left join public.asset_exposure_rows e on e.asset_id=a.id and e.dimension=d.dimension and e.stage=t.stage
where a.id=any(requested_assets) group by a.id,d.dimension,t.stage;
$$;
revoke all on function public.effective_asset_exposures(uuid[]),public.asset_exposure_status(uuid[]) from public,anon;
grant execute on function public.effective_asset_exposures(uuid[]),public.asset_exposure_status(uuid[]) to authenticated;
create function private.check_asset_exposures(aid uuid) returns void language plpgsql security definer set search_path='' as $$
declare slot text;
begin
 if exists(select 1 from public.asset_exposure_rows where asset_id=aid group by dimension,stage having sum(weight_percent)>100 or (stage='effective' and sum(weight_percent)<>100)) then raise exception 'Invalid distribution total' using errcode='23514'; end if;
 foreach slot in array array['draft','effective'] loop
  if exists(
   with weights as (select reference_id,weight_percent from public.asset_exposure_rows where asset_id=aid and dimension='sector' and stage=
    case when slot='draft' and exists(select 1 from public.asset_exposure_rows where asset_id=aid and dimension='sector' and stage='draft') then 'draft' else 'effective' end)
   select 1 from public.asset_exposure_rows e join public.sector_activities a on a.id=e.reference_id
   left join weights w on w.reference_id=a.sector_id
   where e.asset_id=aid and e.dimension='activity' and e.stage=slot
   group by a.sector_id,w.weight_percent having sum(e.weight_percent)>coalesce(w.weight_percent,0)
  ) then raise exception 'Activities exceed parent sector weight' using errcode='23514'; end if;
 end loop;
end $$;
revoke all on function private.check_asset_exposures(uuid) from public,anon,authenticated;
create function public.check_exposure_trigger() returns trigger language plpgsql security definer set search_path='' as $$
begin if tg_op<>'INSERT' then perform private.check_asset_exposures(old.asset_id); end if;
 if tg_op<>'DELETE' then perform private.check_asset_exposures(new.asset_id); end if; return null; end $$;
revoke all on function public.check_exposure_trigger() from public,anon,authenticated;
create constraint trigger exposure_consistency after insert or update or delete on public.asset_sector_exposures deferrable initially deferred for each row execute function public.check_exposure_trigger();
create constraint trigger exposure_consistency after insert or update or delete on public.asset_activity_exposures deferrable initially deferred for each row execute function public.check_exposure_trigger();
create constraint trigger exposure_consistency after insert or update or delete on public.asset_geography_exposures deferrable initially deferred for each row execute function public.check_exposure_trigger();

create function private.exposure_write_scope(aid uuid,dimension text)
returns text language plpgsql security definer set search_path='' as $$
begin
 if not public.is_authorized_user() or not exists(select 1 from public.assets where id=aid and owner_user_id=auth.uid()) then
 raise exception 'Asset unavailable' using errcode='42501'; end if;
 if dimension is null or dimension not in ('sector','activity','geography') then raise exception 'Invalid dimension' using errcode='22023'; end if;
 insert into private.sector_write_guards as g values(aid,1) on conflict(asset_id) do update set revision=g.revision+1;
 return 'asset_'||dimension||'_exposures';
end $$;
revoke all on function private.exposure_write_scope(uuid,text) from public,anon,authenticated;
create function public.save_asset_exposure_draft(aid uuid,dimension text,items jsonb,data_date date default null,source text default null,origin text default 'user')
returns void language plpgsql security definer set search_path='' as $$
declare tab text; refcol text; item jsonb;
begin
 tab:=private.exposure_write_scope(aid,dimension);
 if jsonb_typeof(items) is distinct from 'array' then raise exception 'Invalid distribution' using errcode='22023'; end if;
 refcol:=case dimension when 'sector' then 'sector_id' when 'activity' then 'activity_id' else 'country_id' end;
 execute format('delete from public.%I where asset_id=$1 and stage=''draft'' %s',tab,'') using aid,auth.uid();
 for item in select value from jsonb_array_elements(items) loop
  if (item->>'weight_percent')::numeric is null or (item->>'weight_percent')::numeric<=0
   or (item->>'weight_percent')::numeric>100
   or trunc((item->>'weight_percent')::numeric,2)<>(item->>'weight_percent')::numeric then
   raise exception 'Weight must be in (0,100] with at most two decimals' using errcode='23514'; end if;
  execute format('insert into public.%I(asset_id,%I,weight_percent,stage,data_date,source,origin%s) values($1,$2,$3,''draft'',$4,$5,$6%s)',tab,refcol,'','')
  using aid,(item->>'reference_id')::uuid,(item->>'weight_percent')::numeric,data_date,source,origin,auth.uid();
 end loop;
 perform private.check_asset_exposures(aid);
end $$;
create function public.publish_asset_exposure_drafts(aid uuid,dimensions text[])
returns void language plpgsql security definer set search_path='' as $$
declare tab text; total numeric; dim text;
begin
 if dimensions is null or cardinality(dimensions)=0 then raise exception 'Dimensions required' using errcode='22023'; end if;
 for dim in select distinct unnest(dimensions) order by 1 loop
  tab:=private.exposure_write_scope(aid,dim);
  select sum(e.weight_percent) into total from public.asset_exposure_rows e where e.asset_id=aid and e.dimension=dim and e.stage='draft';
  if total is distinct from 100::numeric then raise exception 'Draft must total 100 before validation' using errcode='23514'; end if;
 end loop;
 -- Force the cross-dimension constraints to the transaction boundary, then
 -- explicitly validate before returning. Caller transaction still remains atomic.
 set constraints public.exposure_consistency deferred;
 for dim in select distinct unnest(dimensions) order by 1 loop
  tab:='asset_'||dim||'_exposures';
  execute format('delete from public.%I where asset_id=$1 and stage=''effective'' %s',tab,'') using aid,auth.uid();
  execute format('update public.%I set stage=''effective'',updated_at=clock_timestamp() where asset_id=$1 and stage=''draft'' %s',tab,'') using aid,auth.uid();
 end loop;
 perform private.check_asset_exposures(aid);
end $$;
revoke all on function public.publish_asset_exposure_drafts(uuid,text[]) from public,anon;
grant execute on function public.publish_asset_exposure_drafts(uuid,text[]) to authenticated;
create function public.publish_asset_exposure_draft(aid uuid,dimension text)
returns void language sql security invoker set search_path='' as $$
 select public.publish_asset_exposure_drafts(aid,array[dimension]);
$$;

revoke all on function public.save_asset_exposure_draft(uuid,text,jsonb,date,text,text),public.publish_asset_exposure_draft(uuid,text) from public,anon;
grant execute on function public.save_asset_exposure_draft(uuid,text,jsonb,date,text,text),public.publish_asset_exposure_draft(uuid,text) to authenticated;
create or replace function public.effective_asset_sector_exposures(requested_asset_id uuid)
returns table(sector_id uuid,weight_percent numeric,source text) language plpgsql stable security invoker set search_path='' as $$
begin if not public.is_authorized_user() then raise exception 'Access denied' using errcode='42501'; end if;
return query select e.reference_id,e.weight_percent,e.source from public.effective_asset_exposures(array[requested_asset_id]) e where e.dimension='sector'; end $$;
create or replace function public.asset_sector_status(requested_asset_id uuid)
returns table(total_percent numeric,remaining_percent numeric,is_complete boolean) language plpgsql stable security invoker set search_path='' as $$
begin if not public.is_authorized_user() then raise exception 'Access denied' using errcode='42501'; end if;
return query select coalesce(sum(e.weight_percent),0),100-coalesce(sum(e.weight_percent),0),coalesce(sum(e.weight_percent),0)=100 from public.asset_sector_exposures e where e.asset_id=requested_asset_id and e.stage='effective'; end $$;
create function public.guard_activity_parent() returns trigger language plpgsql security invoker set search_path='' as $$
begin if new.sector_id is distinct from old.sector_id or new.id is distinct from old.id then
 raise exception 'Activity identity and parent are immutable' using errcode='23514'; end if; return new; end $$;
create trigger activity_parent before update on public.sector_activities for each row execute function public.guard_activity_parent();
revoke all on function public.guard_activity_parent() from public,anon,authenticated;
create index asset_activity_reference_idx on public.asset_activity_exposures(activity_id);
create index asset_geography_reference_idx on public.asset_geography_exposures(country_id);
commit;
