begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
do $property_validation$
declare definition text;original text;
begin
 original:=pg_get_functiondef('public.preview_property_valuation(uuid,uuid,uuid,uuid,date,text,numeric,text)'::regprocedure);
 definition:=replace(original,'and e->>''effectiveOn''<=requested_date::text and e->>''id''<>oid::text','and e->>''effectiveOn''<=requested_date::text and e->>''effectiveOn''<>requested_date::text and e->>''id''<>oid::text');
 if definition=original then raise exception 'Unexpected property preview definition';end if;execute definition;
 original:=pg_get_functiondef('private.property_sources_hash()'::regprocedure);
 definition:=replace(original,'from public.fx_rates f),''''));','from public.fx_rates f),'''')||coalesce((select jsonb_agg(to_jsonb(s) order by id)::text from public.position_snapshots s where user_id=auth.uid()),''''));');
 if definition=original then raise exception 'Unexpected property sources hash';end if;execute definition;
 original:=pg_get_functiondef('public.save_property_valuation(uuid,uuid,uuid,uuid,date,text,numeric,text,text)'::regprocedure);
 definition:=replace(original,'public.patrimonial_legacy_sources,public.fx_rates in share mode;','public.patrimonial_legacy_sources,public.fx_rates,public.position_snapshots in share mode;');
 if definition=original then raise exception 'Unexpected property save definition';end if;execute definition;
end $property_validation$;
notify pgrst,'reload schema';
commit;
