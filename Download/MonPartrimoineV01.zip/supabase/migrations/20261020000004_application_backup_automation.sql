-- Local candidate only. Daily server identity, fenced lease and retention intents.
-- No session impersonation, no provider calls, no changes to migrations 001-003.
begin;
alter table private.app_backup_drive_files drop constraint app_backup_drive_files_origin_check;
alter table private.app_backup_drive_files add constraint app_backup_drive_files_origin_check check(origin in('manual','pre_restore','daily'));
create table private.app_backup_automation_lock(singleton boolean primary key default true check(singleton),lease uuid,lease_until timestamptz,run_id uuid);
insert into private.app_backup_automation_lock(singleton) values(true);
create table private.app_backup_daily_runs(
 business_date date primary key,operation_id uuid not null unique,user_id uuid not null references auth.users(id),
 backup_state text not null default 'pending' check(backup_state in('pending','running','failed','unconfirmed','verified')),
 invocations integer not null default 0 check(invocations between 0 and 3),
 verified_at timestamptz,last_error text,failed_at timestamptz,cleanup_error text,retention_planned boolean not null default false,
 keep_daily boolean not null default false,keep_monthly boolean not null default false,
 updated_at timestamptz not null default clock_timestamp()
);
create table private.app_backup_trash_intents(
 operation_id uuid primary key references private.app_backup_drive_files(operation_id),
 state text not null default 'pending' check(state in('pending','trashed')),
 attempts integer not null default 0,last_attempt_at timestamptz,last_error text,confirmed_at timestamptz
);
alter table private.app_backup_automation_lock enable row level security;
alter table private.app_backup_automation_lock force row level security;
alter table private.app_backup_daily_runs enable row level security;
alter table private.app_backup_daily_runs force row level security;
alter table private.app_backup_trash_intents enable row level security;
alter table private.app_backup_trash_intents force row level security;
revoke all on private.app_backup_automation_lock,private.app_backup_daily_runs,private.app_backup_trash_intents from public,anon,authenticated,service_role;

create function public.application_backup_automation(operation text,args jsonb default '{}') returns jsonb
language plpgsql volatile security definer set search_path='' set timezone='UTC' set datestyle='ISO,YMD' as $$
declare uid uuid; day date:=(clock_timestamp() at time zone 'Europe/Paris')::date;
 lock_row private.app_backup_automation_lock; run private.app_backup_daily_runs; item private.app_backup_drive_files;
 result jsonb; doc jsonb; previous_sub text:=current_setting('request.jwt.claim.sub',true); code text;
begin
 -- Service-only RPC selects the principal itself. No actor/session from HTTP.
 select p.auth_user_id into uid from private.application_principal p join public.profiles pr on pr.auth_user_id=p.auth_user_id where p.singleton and pr.is_active;
 if uid is null then raise exception 'Backup unavailable' using errcode='42501';end if;
 if jsonb_typeof(args) is distinct from 'object' or pg_column_size(args)>4096 then raise exception 'Invalid request';end if;
 if operation='view' then
  if args<>'{}'::jsonb then raise exception 'Unexpected fields';end if;
  return jsonb_build_object(
   'lastSuccess',(select jsonb_build_object('businessDate',business_date,'verifiedAt',verified_at) from private.app_backup_daily_runs where user_id=uid and backup_state='verified' order by verified_at desc limit 1),
   'lastFailure',(select jsonb_build_object('businessDate',business_date,'code',last_error,'at',failed_at) from private.app_backup_daily_runs where user_id=uid and last_error is not null order by failed_at desc limit 1),
   'current',(select jsonb_build_object('businessDate',business_date,'state',backup_state,'at',updated_at,'invocations',invocations,'leaseActive',exists(select 1 from private.app_backup_automation_lock where singleton and run_id=r.operation_id and lease_until>clock_timestamp())) from private.app_backup_daily_runs r where user_id=uid order by business_date desc limit 1),
   'retainedDaily',(select count(*) from private.app_backup_daily_runs where user_id=uid and keep_daily),
   'retainedMonthly',(select count(*) from private.app_backup_daily_runs where user_id=uid and keep_monthly),
   'cleanupPending',(select count(*) from private.app_backup_trash_intents t join private.app_backup_drive_files f using(operation_id) where f.user_id=uid and t.state='pending'),
   'cleanupFailed',exists(select 1 from private.app_backup_trash_intents t join private.app_backup_drive_files f using(operation_id) where f.user_id=uid and t.state='pending' and t.last_error is not null)
    or exists(select 1 from private.app_backup_daily_runs where user_id=uid and cleanup_error is not null and business_date=(select max(business_date) from private.app_backup_daily_runs where user_id=uid)));
 end if;
 select * into lock_row from private.app_backup_automation_lock where singleton for update;
 if operation='claim' then
  if (select array_agg(k order by k) from jsonb_object_keys(args) k) is distinct from array['lease']::text[] or (args->>'lease')::uuid is null then raise exception 'Invalid claim';end if;
  if lock_row.lease_until>clock_timestamp() then return jsonb_build_object('status','busy');end if;
  -- One bounded carry-over reconciliation, never a fresh upload for an old day.
  select r.* into run from private.app_backup_daily_runs r join private.app_backup_drive_files f using(operation_id)
   where r.user_id=uid and r.business_date<day and r.backup_state<>'verified' and r.invocations<3 order by r.business_date limit 1;
  if run.operation_id is null then
   insert into private.app_backup_daily_runs(business_date,operation_id,user_id) values(day,gen_random_uuid(),uid) on conflict do nothing;
   select * into run from private.app_backup_daily_runs where business_date=day and user_id=uid for update;
  end if;
  if run.operation_id is null then raise exception 'Principal changed';end if;
  if run.backup_state='verified' and run.retention_planned and not exists(select 1 from private.app_backup_trash_intents where state='pending') and run.cleanup_error is null then return jsonb_build_object('status','already_verified','businessDate',run.business_date);end if;
  if run.invocations>=3 then return jsonb_build_object('status','exhausted','businessDate',run.business_date);end if;
  update private.app_backup_automation_lock set lease=(args->>'lease')::uuid,lease_until=clock_timestamp()+interval '90 seconds',run_id=run.operation_id where singleton;
  update private.app_backup_daily_runs set invocations=invocations+1,backup_state=case when backup_state='verified' then 'verified' else 'running' end,updated_at=clock_timestamp() where operation_id=run.operation_id returning * into run;
  return jsonb_build_object('status','claimed','userId',uid,'operationId',run.operation_id,'businessDate',run.business_date,'verified',run.backup_state='verified');
 end if;
 if lock_row.lease is distinct from (args->>'lease')::uuid or lock_row.lease_until is null or lock_row.lease_until<=clock_timestamp() then raise exception 'Lease expired' using errcode='42501';end if;
 select * into run from private.app_backup_daily_runs where operation_id=(args->>'run_id')::uuid and user_id=uid for update;
 if run.operation_id is null or lock_row.run_id is distinct from run.operation_id then raise exception 'Unknown run';end if;
 if operation='guard' then return jsonb_build_object('authorized',true);
 elsif operation='snapshot' then
  if run.backup_state<>'running' or exists(select 1 from private.app_backup_drive_files where operation_id=run.operation_id) then raise exception 'Reconcile existing intent';end if;
  -- Scoped principal context for the existing SQL reader only. No fabricated JWT
  -- session, no manual restore RPC, and restore permissions remain inaccessible.
  perform set_config('request.jwt.claim.sub',uid::text,true);
  doc:=private.app_backup_snapshot();
  perform set_config('request.jwt.claim.sub',coalesce(previous_sub,''),true);
  return jsonb_build_object('document',doc);
 elsif operation='confirmed' then
  select * into item from private.app_backup_drive_files where operation_id=run.operation_id and user_id=uid and origin='daily' and state='verified';
  if item.operation_id is null then raise exception 'Verified archive required';end if;
  update private.app_backup_daily_runs set backup_state='verified',verified_at=coalesce(verified_at,clock_timestamp()),updated_at=clock_timestamp() where operation_id=run.operation_id;
  return 'true';
 elsif operation='failed' then
  code:=args->>'code';
  if code is null or code not in('BACKUP_FAILED','DRIVE_UNCONFIRMED','SNAPSHOT_TIMEOUT','SNAPSHOT_UNAVAILABLE','RPC_TIMEOUT','RPC_POOL_TIMEOUT','RPC_UNAVAILABLE','ARCHIVE_PLAIN_LIMIT','ARCHIVE_COMPRESSED_LIMIT','ARCHIVE_CODEC_TIMEOUT','ARCHIVE_INVALID','ARCHIVE_AUTHENTICATION') then code:='BACKUP_FAILED';end if;
  update private.app_backup_daily_runs set backup_state=case when exists(select 1 from private.app_backup_drive_files where operation_id=run.operation_id) then 'unconfirmed' else 'failed' end,last_error=code,failed_at=clock_timestamp(),updated_at=clock_timestamp() where operation_id=run.operation_id and backup_state<>'verified';
  return 'true';
 elsif operation='release' then
  update private.app_backup_automation_lock set lease=null,lease_until=null,run_id=null where singleton;return 'true';
 end if;
 -- All cleanup operations require an already verified archive in this run.
 if run.backup_state<>'verified' then raise exception 'No cleanup after failed backup';end if;
 if operation='plan' then
  update private.app_backup_daily_runs r set
   keep_daily=r.operation_id in(select operation_id from private.app_backup_daily_runs where user_id=uid and backup_state='verified' order by business_date desc limit 12),
   keep_monthly=r.operation_id in(select operation_id from (
    select distinct on(date_trunc('month',business_date::timestamp)) operation_id,business_date,verified_at from private.app_backup_daily_runs
    where user_id=uid and backup_state='verified' order by date_trunc('month',business_date::timestamp),verified_at,business_date,operation_id
   ) winners order by business_date desc limit 12)
   where r.user_id=uid;
  if exists(select 1 from private.app_backup_daily_runs r join private.app_backup_trash_intents t using(operation_id) where r.user_id=uid and (r.keep_daily or r.keep_monthly)) then raise exception 'Retention reference conflict';end if;
  insert into private.app_backup_trash_intents(operation_id)
   select f.operation_id from private.app_backup_drive_files f join private.app_backup_daily_runs r using(operation_id)
   where f.user_id=uid and f.origin='daily' and f.state='verified' and r.backup_state='verified' and not r.keep_daily and not r.keep_monthly on conflict do nothing;
  update private.app_backup_daily_runs set retention_planned=true where operation_id=run.operation_id;
  return coalesce((select jsonb_agg(operation_id) from (select t.operation_id from private.app_backup_trash_intents t join private.app_backup_drive_files f using(operation_id) where f.user_id=uid and t.state='pending' order by t.last_attempt_at nulls first,t.operation_id limit 3) q),'[]');
 elsif operation='cleanup_result' then
  update private.app_backup_daily_runs set cleanup_error=case when args->>'code' is null then null else 'ROTATION_FAILED' end where operation_id=run.operation_id;return 'true';
 elsif operation in('trash_load','trash_confirm','trash_failed') then
  select f.* into item from private.app_backup_drive_files f join private.app_backup_daily_runs r using(operation_id) join private.app_backup_trash_intents t using(operation_id)
   where f.operation_id=(args->>'operation_id')::uuid and f.user_id=uid and f.origin='daily' and f.state='verified' and r.backup_state='verified' and not r.keep_daily and not r.keep_monthly and t.state='pending';
  if item.operation_id is null then raise exception 'Archive still retained or foreign';end if;
  if operation='trash_load' then
   update private.app_backup_trash_intents set attempts=attempts+1,last_attempt_at=clock_timestamp() where operation_id=item.operation_id;
   return to_jsonb(item);
  elsif operation='trash_confirm' then
   update private.app_backup_trash_intents set state='trashed',confirmed_at=clock_timestamp(),last_error=null where operation_id=item.operation_id;
  else update private.app_backup_trash_intents set last_error='ROTATION_FAILED' where operation_id=item.operation_id;end if;
  return 'true';
 end if;
 raise exception 'Unsupported operation';
exception when others then perform set_config('request.jwt.claim.sub',coalesce(previous_sub,''),true);raise;
end$$;
revoke all on function public.application_backup_automation(text,jsonb) from public,anon,authenticated,service_role;
grant execute on function public.application_backup_automation(text,jsonb) to service_role;

-- Existing manual RPC: same principal/ACLs, plus automatic origin fencing and
-- view-only retention flags. Old manual/pre-restore archives are never relabelled.
create or replace function public.application_backup_drive_store(operation text,actor uuid,args jsonb default '{}') returns jsonb
language plpgsql security definer set search_path='' as $$
declare root private.app_backup_drive_root; item private.app_backup_drive_files;begin
 if not exists(select 1 from private.application_principal p join public.profiles pr on pr.auth_user_id=p.auth_user_id where p.auth_user_id=actor and pr.is_active) then raise exception 'Backup unavailable' using errcode='42501';end if;
 insert into private.app_backup_drive_root(user_id) values(actor) on conflict do nothing;
 select * into root from private.app_backup_drive_root where user_id=actor for update;
 if operation='root' then return to_jsonb(root);
 elsif operation='folder' then
  if coalesce(args->>'id','')!~'^[A-Za-z0-9_-]{1,160}$' then raise exception 'Invalid reference';end if;
  update private.app_backup_drive_root set folder_id=coalesce(folder_id,args->>'id') where user_id=actor returning * into root;return to_jsonb(root);
 elsif operation='list' then
  return coalesce((select jsonb_agg(to_jsonb(f)||jsonb_build_object('business_date',r.business_date,'monthly',coalesce(r.keep_monthly,false)) order by f.created_at desc,f.operation_id)
   from private.app_backup_drive_files f left join private.app_backup_daily_runs r using(operation_id)
   where f.user_id=actor and not exists(select 1 from private.app_backup_trash_intents t where t.operation_id=f.operation_id)),'[]');
 elsif operation in('load','reserve','verify') then
  select * into item from private.app_backup_drive_files where operation_id=(args->>'operation_id')::uuid;
  if item.operation_id is not null and item.user_id<>actor then raise exception 'Backup unavailable' using errcode='42501';end if;
  if item.operation_id is not null and exists(select 1 from private.app_backup_trash_intents where operation_id=item.operation_id) then raise exception 'Archive retired';end if;
  if (operation='reserve' and args->>'origin'='daily') or (operation='verify' and item.origin='daily') then
   if not exists(select 1 from private.app_backup_automation_lock l join private.app_backup_daily_runs r on r.operation_id=(args->>'operation_id')::uuid
    where l.singleton and l.lease=(args->>'automation_lease')::uuid and l.run_id=r.operation_id and l.lease_until>clock_timestamp() and r.user_id=actor) then raise exception 'Automation lease required' using errcode='42501';end if;
  end if;
  if operation='reserve' and item.operation_id is null then
   if coalesce(args->>'file_id','')!~'^[A-Za-z0-9_-]{1,160}$' then raise exception 'Invalid reference';end if;
   insert into private.app_backup_drive_files(operation_id,user_id,file_id,origin,key_id,byte_size,sha256)
    values((args->>'operation_id')::uuid,actor,args->>'file_id',args->>'origin',args->>'key_id',(args->>'byte_size')::int,args->>'sha256') returning * into item;
  elsif operation='verify' then update private.app_backup_drive_files set state='verified' where operation_id=item.operation_id and user_id=actor returning * into item;end if;
  return to_jsonb(item);
 end if;
 raise exception 'Unsupported operation';
end$$;
revoke all on function public.application_backup_drive_store(text,uuid,jsonb) from public,anon,authenticated,service_role;
grant execute on function public.application_backup_drive_store(text,uuid,jsonb) to service_role;
commit;
