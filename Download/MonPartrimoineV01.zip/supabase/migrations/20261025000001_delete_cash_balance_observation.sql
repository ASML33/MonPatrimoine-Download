-- Local incident candidate: no existing data is modified on installation.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
-- Drain in-flight DML before retiring the legacy DELETE privilege.
lock table public.cash_balances in share row exclusive mode;

create function public.delete_cash_balance_observation(
 requested_contract uuid, requested_balance uuid,
 expected_updated_at timestamptz, expected_as_of timestamptz)
returns uuid language plpgsql security invoker set search_path='' as $$
declare actor uuid:=auth.uid(); src public.cash_balances;
 entries jsonb; remaining jsonb; selected jsonb; latest jsonb;
 stamp timestamptz:=clock_timestamp(); meta jsonb;
begin
 if actor is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 if requested_balance is null or expected_updated_at is null or expected_as_of is null
  or not isfinite(expected_updated_at) or not isfinite(expected_as_of) then raise exception 'CASH-DELETE-REQUEST' using errcode='22023';end if;
 perform 1 from public.contracts where id=requested_contract and user_id=actor for update;
 if not found then raise exception 'CASH-DELETE-CONTRACT' using errcode='42501';end if;
 select * into src from public.cash_balances where id=requested_balance and contract_id=requested_contract and user_id=actor for update;
 if not found then raise exception 'CASH-DELETE-ROW' using errcode='42501';end if;
 if src.updated_at is distinct from expected_updated_at then raise exception 'CASH-DELETE-STALE' using errcode='40001';end if;
 entries:=coalesce(src.metadata#>'{cash_balance_observations,entries}',jsonb_build_array(jsonb_build_object(
  'amount',src.amount::text,'currencyCode',btrim(src.currency_code),'asOf',src.as_of,'recordedAt',src.updated_at)));
 select value into selected from jsonb_array_elements(entries) where (value->>'asOf')::timestamptz=expected_as_of;
 if selected is null then raise exception 'CASH-DELETE-STALE' using errcode='40001';end if;
 select coalesce(jsonb_agg(value order by (value->>'asOf')::timestamptz),'[]') into remaining
  from jsonb_array_elements(entries) where (value->>'asOf')::timestamptz<>expected_as_of;
 select value into latest from jsonb_array_elements(remaining) order by (value->>'asOf')::timestamptz desc limit 1;
 meta:=src.metadata||jsonb_build_object(
  'cash_balance_observations',jsonb_build_object('version',2,'entries',remaining,'archived',
   coalesce(src.metadata#>'{cash_balance_observations,archived}','[]')||jsonb_build_array(jsonb_build_object('entries',entries,'replacedAt',stamp))),
  'cash_balance_corrections',coalesce(src.metadata->'cash_balance_corrections','[]')||jsonb_build_array(
   jsonb_build_object('id',gen_random_uuid(),'operation','delete','sourceBalanceId',src.id,'previous',selected,'recordedAt',stamp)));
 -- An empty effective set retains its physical row and proof. Cached columns
 -- are not effective observations; all readers expand the versioned entries.
 update public.cash_balances set metadata=meta,
  amount=coalesce((latest->>'amount')::numeric,src.amount),
  as_of=coalesce((latest->>'asOf')::timestamptz,src.as_of)
 where id=src.id and contract_id=requested_contract and user_id=actor;
 return src.id;
end $$;
revoke all on function public.delete_cash_balance_observation(uuid,uuid,timestamptz,timestamptz) from public,anon;
grant execute on function public.delete_cash_balance_observation(uuid,uuid,timestamptz,timestamptz) to authenticated;
-- Old server actions use an authenticated direct DELETE. Retire that exact
-- capability; the new RPC only updates the versioned observation set.
-- Operator-owned SECURITY DEFINER restores and service_role retain their rights.
revoke delete on public.cash_balances from public,anon,authenticated;
do $$begin
 if has_table_privilege('authenticated','public.cash_balances','DELETE')
  or has_table_privilege('anon','public.cash_balances','DELETE') then
  raise exception 'CASH-DELETE-LEGACY-GRANT';
 end if;
 if not has_table_privilege('authenticated','public.cash_balances','UPDATE') then
  raise exception 'CASH-DELETE-UPDATE-GRANT';
 end if;
end $$;
notify pgrst,'reload schema';
commit;
