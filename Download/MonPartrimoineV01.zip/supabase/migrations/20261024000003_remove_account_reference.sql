-- Local candidate only. Apply after every reader/worker uses explicit projections.
-- Historical JSON and encrypted archives remain intact; no DROP CASCADE.
begin;
set local lock_timeout='5s';
set local statement_timeout='120s';

-- Accept only the exact previously supported archive frontiers.
create table private.account_reference_archive_frontier (
 schema_hash text primary key, format text not null, contract_columns text[] not null,
 target_columns text[] not null, needs_envelopes boolean not null
);
revoke all on private.account_reference_archive_frontier from public,anon,authenticated,service_role;
insert into private.account_reference_archive_frontier
 select private.app_backup_schema(),'monpatrimoine-app-backup/2',c.columns,t.columns,false
 from private.app_backup_datasets c,private.app_backup_datasets t where c.name='contracts' and t.name='target_allocations';
insert into private.account_reference_archive_frontier
 select f.schema_hash,'monpatrimoine-app-backup/2',c.columns,t.columns,true
 from private.envelope_archive_frontier f,private.app_backup_datasets c,private.app_backup_datasets t
 where c.name='contracts' and t.name='target_allocations';
insert into private.account_reference_archive_frontier
 select f.schema_hash,'monpatrimoine-app-backup/1',c.columns,f.columns,true
 from private.asset_objective_backup_v1 f,private.app_backup_datasets c where c.name='contracts';

do $$begin
 if (select count(*) from pg_attribute where attrelid='public.contracts'::regclass and attname='account_reference' and not attisdropped)<>1
 or not exists(select 1 from private.app_backup_datasets where name='contracts' and 'account_reference'=any(columns))
 then raise exception 'Unexpected account reference prerequisite';end if;
end$$;
alter table public.contracts drop column account_reference;
update private.app_backup_datasets set columns=array_remove(columns,'account_reference') where name='contracts';

-- Preserve existing security/validation bodies and ACLs; only version changes.
do $$declare signature text;body text;begin
 foreach signature in array array['private.app_backup_snapshot()','private.app_backup_validate(jsonb)'] loop
  body:=pg_get_functiondef(signature::regprocedure);
  if position('monpatrimoine-app-backup/2' in body)=0 then raise exception 'Unexpected backup version prerequisite';end if;
  execute replace(body,'monpatrimoine-app-backup/2','monpatrimoine-app-backup/3');
 end loop;
end$$;

create or replace function private.app_backup_upgrade(doc jsonb) returns jsonb
language plpgsql security definer set search_path='' as $$
declare prior private.account_reference_archive_frontier; rows_json jsonb;new_columns text[];removed_index integer;begin
 if public.is_authorized_user() is not true or doc->>'owner' is distinct from auth.uid()::text then raise exception 'Unauthorized' using errcode='42501';end if;
 if doc->>'format'='monpatrimoine-app-backup/3' then perform private.app_backup_validate(doc);return doc;end if;
 select * into prior from private.account_reference_archive_frontier where schema_hash=doc->>'schema' and format=doc->>'format';
 if prior.schema_hash is null
 or doc#>'{datasets,contracts,columns}' is distinct from to_jsonb(prior.contract_columns)
 or doc#>'{datasets,target_allocations,columns}' is distinct from to_jsonb(prior.target_columns)
 or jsonb_typeof(doc#>'{datasets,contracts,rows}') is distinct from 'array'
 or jsonb_typeof(doc#>'{datasets,target_allocations,rows}') is distinct from 'array'
 then raise exception 'Unsupported archive schema version';end if;
 if exists(select 1 from jsonb_array_elements(doc#>'{datasets,contracts,rows}') r where jsonb_typeof(r)<>'array' or jsonb_array_length(r)<>cardinality(prior.contract_columns))
 or exists(select 1 from jsonb_array_elements(doc#>'{datasets,target_allocations,rows}') r where jsonb_typeof(r)<>'array' or jsonb_array_length(r)<>cardinality(prior.target_columns))
 then raise exception 'Invalid legacy row';end if;
 if exists(select 1 from jsonb_array_elements(doc#>'{datasets,contracts,rows}') r cross join lateral jsonb_array_elements(r) cell where jsonb_typeof(cell) not in ('string','null')) then raise exception 'Invalid legacy cell';end if;
 removed_index:=array_position(prior.contract_columns,'account_reference')-1;
 if removed_index is null then raise exception 'Missing retired field frontier';end if;
 new_columns:=array_remove(prior.contract_columns,'account_reference');
 select coalesce(jsonb_agg(r-removed_index order by (r-removed_index)::text collate "C"),'[]') into rows_json from jsonb_array_elements(doc#>'{datasets,contracts,rows}') r;
 doc:=jsonb_set(doc,'{datasets,contracts}',jsonb_build_object('columns',new_columns,'rows',rows_json));
 if prior.format='monpatrimoine-app-backup/1' then
  select coalesce(jsonb_agg(r||'[null]'::jsonb order by (r||'[null]'::jsonb)::text collate "C"),'[]') into rows_json from jsonb_array_elements(doc#>'{datasets,target_allocations,rows}') r;
  doc:=jsonb_set(doc,'{datasets,target_allocations}',jsonb_build_object('columns',prior.target_columns||array['scope_contract_id'],'rows',rows_json));
 end if;
 if prior.needs_envelopes then doc:=private.envelope_upgrade_archive(doc);end if;
 doc:=jsonb_set(jsonb_set(doc,'{format}','"monpatrimoine-app-backup/3"'),'{schema}',to_jsonb(private.app_backup_schema()));
 perform private.app_backup_validate(doc);
 return doc;
end$$;
revoke all on function private.app_backup_upgrade(jsonb) from public,anon,authenticated,service_role;
notify pgrst,'reload schema';
commit;
