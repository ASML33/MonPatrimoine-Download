-- Local candidate only. No legacy target is assigned implicitly.
begin;
-- Exact prior schema is captured before any change. Only this version can be
-- upgraded; unknown historical fingerprints remain fail-closed.
create table private.asset_objective_backup_v1(schema_hash text primary key, columns text[] not null);
revoke all on private.asset_objective_backup_v1 from public,anon,authenticated,service_role;
insert into private.asset_objective_backup_v1 select private.app_backup_schema(),columns from private.app_backup_datasets where name='target_allocations';
alter table public.target_allocations add column scope_contract_id uuid;
alter table public.target_allocations add constraint target_allocations_scope_owner_fk
 foreign key(scope_contract_id,user_id) references public.contracts(id,user_id);
alter table public.target_allocations add constraint target_allocations_scope_shape
 check(scope_contract_id is null or target_kind='asset');
drop index public.target_allocations_asset_unique_idx;
create unique index target_allocations_asset_unique_idx on public.target_allocations(user_id,target_asset_id)
 where target_kind='asset' and scope_contract_id is null;
create unique index target_allocations_scoped_asset_unique_idx on public.target_allocations(user_id,scope_contract_id,target_asset_id)
 where target_kind='asset' and scope_contract_id is not null;

create or replace function public.contract_has_dependencies(contract_id uuid)
returns boolean language sql stable set search_path='' as $$
 select exists(select 1 from public.positions p where p.contract_id=$1)
 or exists(select 1 from public.cash_balances b where b.contract_id=$1)
 or exists(select 1 from public.cash_flows f where f.source_contract_id=$1 or f.destination_contract_id=$1)
 or exists(select 1 from public.contract_manual_situations s where s.contract_id=$1)
 or exists(select 1 from public.contract_manual_simulations s where s.contract_id=$1)
 or exists(select 1 from public.target_allocations t where t.scope_contract_id=$1 or t.target_contract_id=$1);
$$;
-- Deferred invariant also protects operator restores, independently of the RPC.
create function private.check_asset_objective_scopes() returns trigger language plpgsql security definer set search_path='' as $$
declare owner_id uuid:=coalesce(new.user_id,old.user_id);
begin
 if exists(select 1 from public.target_allocations t where t.user_id=owner_id and t.target_kind='asset' and not exists(select 1 from public.assets a where a.id=t.target_asset_id and a.owner_user_id=owner_id)) then
   raise exception 'Foreign asset target' using errcode='42501';
 end if;
 if exists(select 1 from public.target_allocations where user_id=owner_id and target_kind='asset'
   group by scope_contract_id having sum(greatest(target_percent,0))>100) then
   raise exception 'Asset targets exceed 100 percent in their scope' using errcode='23514';
 end if;
 if exists(select 1 from public.target_allocations x join public.target_allocations y
   on y.user_id=x.user_id and y.target_asset_id=x.target_asset_id and y.scope_contract_id is not null
   where x.user_id=owner_id and x.target_kind='asset' and x.scope_contract_id is null and x.target_percent=-1) then
   raise exception 'Resolve the global exclusion explicitly before adding a contract target' using errcode='23514';
 end if;
 return null;
end$$;
revoke all on function private.check_asset_objective_scopes() from public,anon,authenticated,service_role;
create constraint trigger target_allocations_scope_totals after insert or update or delete on public.target_allocations
 deferrable initially deferred for each row execute function private.check_asset_objective_scopes();
create or replace function public.save_target_allocations(
  requested_kind public.allocation_target_kind,
  requested_targets jsonb,
  expected_revision bigint
)
returns table(revision bigint,positive_total numeric,is_complete boolean)
language plpgsql security definer set search_path = '' as $$
declare owner_id uuid:=auth.uid(); current_revision bigint; total numeric; item jsonb; target_id uuid; target_value numeric;
begin
  if not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501'; end if;
  if requested_kind is null or jsonb_typeof(requested_targets) <> 'array' or expected_revision is null then
    raise exception 'Invalid objective request' using errcode='22023';
  end if;
  insert into private.allocation_write_guards as g(user_id,revision) values(owner_id,0)
    on conflict(user_id) do nothing;
  select g.revision into current_revision from private.allocation_write_guards g
    where g.user_id=owner_id for update;
  if current_revision <> expected_revision then
    raise exception 'Objectives were modified concurrently' using errcode='40001';
  end if;
  if exists(select 1 from jsonb_array_elements(requested_targets) value
    group by value->>'target_id' having count(*)>1) then
    raise exception 'Duplicate objective target' using errcode='23505';
  end if;
  if requested_kind='asset' and exists(select 1 from public.target_allocations where user_id=owner_id and target_kind='asset' and scope_contract_id is not null) then
    raise exception 'Legacy asset writer cannot replace scoped targets' using errcode='40001';
  end if;
  total:=0;
  for item in select value from jsonb_array_elements(requested_targets) loop
    begin
      target_id:=(item->>'target_id')::uuid;
      target_value:=(item->>'target_percent')::numeric;
    exception when others then raise exception 'Invalid objective value' using errcode='22023'; end;
    if target_value is null or target_value>100 or target_value=0 or target_value< -1
       or (target_value=-1 and requested_kind<>'asset') then
      raise exception 'Invalid objective value' using errcode='23514';
    end if;
    if target_value>0 then total:=total+target_value; end if;
    if requested_kind='envelope_type' and not exists(select 1 from public.envelope_types where id=target_id and is_active) then
      raise exception 'Envelope type target is unavailable' using errcode='42501';
    elsif requested_kind='contract' and not exists(select 1 from public.contracts where id=target_id and user_id=owner_id) then
      raise exception 'Contract target is unavailable' using errcode='42501';
    elsif requested_kind='asset' and not exists(select 1 from public.assets where id=target_id and owner_user_id=owner_id and is_active) then
      raise exception 'Asset target is unavailable' using errcode='42501';
    end if;
  end loop;
  if total>100 then raise exception 'Target allocations cannot exceed 100%%' using errcode='23514'; end if;
  delete from public.target_allocations where user_id=owner_id and target_kind=requested_kind;
  insert into public.target_allocations(user_id,target_kind,target_envelope_type_id,target_contract_id,target_asset_id,target_percent)
  select owner_id,requested_kind,
    case when requested_kind='envelope_type' then (value->>'target_id')::uuid end,
    case when requested_kind='contract' then (value->>'target_id')::uuid end,
    case when requested_kind='asset' then (value->>'target_id')::uuid end,
    (value->>'target_percent')::numeric
  from jsonb_array_elements(requested_targets) value;
  update private.allocation_write_guards g set revision=g.revision+1 where g.user_id=owner_id returning g.revision into current_revision;
  return query select current_revision,total,total=100;
end;
$$;
revoke all on function public.save_target_allocations(public.allocation_target_kind,jsonb,bigint) from public,anon;
grant execute on function public.save_target_allocations(public.allocation_target_kind,jsonb,bigint) to authenticated;


-- Replaces ONE contract partition. Optional legacy assignment is in the same
-- transaction and preserves the old percentage; destination conflicts refuse.
create function public.save_asset_contract_targets(requested_contract uuid, requested_targets jsonb,
 expected_revision bigint, assign_legacy_asset uuid default null, remove_legacy_asset uuid default null)
returns table(revision bigint,positive_total numeric,is_complete boolean)
language plpgsql security definer set search_path='' as $$
declare owner_id uuid:=auth.uid(); rev bigint; total numeric:=0; item jsonb; aid uuid; pct numeric; inherited numeric;
begin
 if public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 if expected_revision is null or jsonb_typeof(requested_targets) is distinct from 'array'
 or (assign_legacy_asset is not null and remove_legacy_asset is not null) then raise exception 'Invalid request' using errcode='22023';end if;
 insert into private.allocation_write_guards(user_id,revision) values(owner_id,0) on conflict(user_id) do nothing;
 select g.revision into rev from private.allocation_write_guards g where g.user_id=owner_id for update;
 if rev<>expected_revision then raise exception 'Concurrent objectives' using errcode='40001';end if;
 if not exists(select 1 from public.contracts where id=requested_contract and user_id=owner_id) then raise exception 'Unavailable contract' using errcode='42501';end if;
 if jsonb_array_length(requested_targets)>2000 or exists(select 1 from jsonb_array_elements(requested_targets) x group by x->>'target_id' having count(*)>1) then raise exception 'Duplicate or excessive targets' using errcode='23505';end if;
 for item in select value from jsonb_array_elements(requested_targets) loop
   if jsonb_typeof(item)<>'object' or (select array_agg(k order by k) from jsonb_object_keys(item) k) is distinct from array['target_id','target_percent']::text[] then raise exception 'Invalid target' using errcode='22023';end if;
   aid:=(item->>'target_id')::uuid;pct:=(item->>'target_percent')::numeric;
   if pct is null or pct::text in('NaN','Infinity','-Infinity') or (pct<>-1 and (pct<=0 or pct>100)) or round(pct,2)<>pct then raise exception 'Invalid percentage' using errcode='23514';end if;
   if not exists(select 1 from public.assets where id=aid and owner_user_id=owner_id and (is_active or exists(select 1 from public.target_allocations where user_id=owner_id and target_asset_id=aid and scope_contract_id=requested_contract))) then raise exception 'Unavailable asset' using errcode='42501';end if;
   if exists(select 1 from public.target_allocations where user_id=owner_id and target_asset_id=aid and scope_contract_id is null and target_percent=-1 and aid is distinct from remove_legacy_asset) then raise exception 'Global exclusion conflict: remove explicitly' using errcode='23514';end if;
   total:=total+greatest(pct,0);
 end loop;
 if assign_legacy_asset is not null then
   select target_percent into inherited from public.target_allocations where user_id=owner_id and target_kind='asset' and target_asset_id=assign_legacy_asset and scope_contract_id is null;
   if inherited is null or inherited=-1 then raise exception 'Legacy target cannot be assigned' using errcode='23514';end if;
   if exists(select 1 from public.target_allocations where user_id=owner_id and target_asset_id=assign_legacy_asset and scope_contract_id=requested_contract)
     or exists(select 1 from jsonb_array_elements(requested_targets) x where x->>'target_id'=assign_legacy_asset::text) then raise exception 'Destination already has a target' using errcode='23505';end if;
   requested_targets:=requested_targets||jsonb_build_array(jsonb_build_object('target_id',assign_legacy_asset,'target_percent',inherited));
   total:=total+inherited;
   delete from public.target_allocations where user_id=owner_id and target_kind='asset' and target_asset_id=assign_legacy_asset and scope_contract_id is null;
 end if;
 if total>100 then raise exception 'Targets exceed 100 percent' using errcode='23514';end if;
 if remove_legacy_asset is not null then
   delete from public.target_allocations where user_id=owner_id and target_kind='asset' and target_asset_id=remove_legacy_asset and scope_contract_id is null;
   if not found then raise exception 'Legacy target no longer present' using errcode='40001';end if;
 end if;
 delete from public.target_allocations where user_id=owner_id and target_kind='asset' and scope_contract_id=requested_contract;
 insert into public.target_allocations(user_id,target_kind,target_asset_id,target_percent,scope_contract_id)
 select owner_id,'asset',(x->>'target_id')::uuid,(x->>'target_percent')::numeric,requested_contract from jsonb_array_elements(requested_targets) x;
 update private.allocation_write_guards g set revision=g.revision+1 where user_id=owner_id returning g.revision into rev;
 return query select rev,total,total=100;
end$$;
revoke all on function public.save_asset_contract_targets(uuid,jsonb,bigint,uuid,uuid) from public,anon,service_role;
grant execute on function public.save_asset_contract_targets(uuid,jsonb,bigint,uuid,uuid) to authenticated;

-- The legacy status describes only the unassigned partition, never a sum of
-- independently complete contracts.
do $status$ declare definition text;begin
 definition:=pg_get_functiondef('public.target_allocation_status(public.allocation_target_kind)'::regprocedure);
 execute replace(definition,'where user_id=auth.uid() and target_kind=requested_kind','where user_id=auth.uid() and target_kind=requested_kind and (requested_kind<>''asset'' or scope_contract_id is null)');
end $status$;
-- A restore invalidates all previously opened objective editors as well.
do $revision$ declare definition text;begin
 definition:=pg_get_functiondef('private.app_backup_replace(jsonb,text)'::regprocedure);
 execute replace(definition,'set constraints all immediate;',
 'set constraints all immediate; insert into private.allocation_write_guards as g(user_id,revision) values(auth.uid(),1) on conflict(user_id) do update set revision=g.revision+1;');
end $revision$;
-- Catalogue version changes explicitly, so snapshots never omit the new column.
update private.app_backup_datasets set columns=columns||array['scope_contract_id'] where name='target_allocations';

-- Document version 2 includes nullable scope_contract_id. Cipher envelopes and
-- canonical hashing remain unchanged (MPBACK01/02/03 are still readable).
do $version$ declare definition text;signature text;begin
 foreach signature in array array['private.app_backup_snapshot()','private.app_backup_validate(jsonb)'] loop
  definition:=pg_get_functiondef(signature::regprocedure);
  execute replace(definition,'monpatrimoine-app-backup/1','monpatrimoine-app-backup/2');
 end loop;
end $version$;
create function private.app_backup_upgrade(doc jsonb) returns jsonb language plpgsql security definer set search_path='' as $$
declare prior private.asset_objective_backup_v1; rows_json jsonb;begin
 if public.is_authorized_user() is not true or doc->>'owner' is distinct from auth.uid()::text then raise exception 'Unauthorized' using errcode='42501';end if;
 if doc->>'format'='monpatrimoine-app-backup/2' then perform private.app_backup_validate(doc);return doc;end if;
 select * into prior from private.asset_objective_backup_v1 where schema_hash=doc->>'schema';
 if doc->>'format' is distinct from 'monpatrimoine-app-backup/1' or prior.schema_hash is null
 or doc#>'{datasets,target_allocations,columns}' is distinct from to_jsonb(prior.columns)
 or jsonb_typeof(doc#>'{datasets,target_allocations,rows}') is distinct from 'array'
 then raise exception 'Unsupported archive schema version';end if;
 if exists(select 1 from jsonb_array_elements(doc#>'{datasets,target_allocations,rows}') r where jsonb_typeof(r)<>'array' or jsonb_array_length(r)<>cardinality(prior.columns)) then raise exception 'Invalid legacy target row';end if;
 select coalesce(jsonb_agg(r||'[null]'::jsonb order by (r||'[null]'::jsonb)::text collate "C"),'[]'::jsonb) into rows_json from jsonb_array_elements(doc#>'{datasets,target_allocations,rows}') r;
 doc:=jsonb_set(doc,'{datasets,target_allocations}',jsonb_build_object('columns',prior.columns||array['scope_contract_id'],'rows',rows_json));
 doc:=jsonb_set(jsonb_set(doc,'{format}','"monpatrimoine-app-backup/2"'),'{schema}',to_jsonb(private.app_backup_schema()));
 perform private.app_backup_validate(doc);
 return doc;
end$$;
revoke all on function private.app_backup_upgrade(jsonb) from public,anon,authenticated,service_role;
-- Use the existing service-only actor/session boundary; no public diagnostic RPC.
do $adapt$ declare definition text;begin
 definition:=pg_get_functiondef('public.application_backup_server(text,jsonb,jsonb)'::regprocedure);
 definition:=replace(definition,$match$if operation='snapshot' then$match$,$branch$if operation='normalize' then
  if (select array_agg(k order by k) from jsonb_object_keys(args) k) is distinct from array['document']::text[] then raise exception 'Unexpected request fields';end if;
  result:=private.app_backup_upgrade(args->'document');
 elsif operation='snapshot' then$branch$);
 execute definition;
end $adapt$;
commit;
