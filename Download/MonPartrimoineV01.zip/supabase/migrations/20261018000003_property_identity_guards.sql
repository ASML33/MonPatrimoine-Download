begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
create function private.assert_property_sources() returns void language plpgsql security definer set search_path='' as $$begin
 if exists(select 1 from public.patrimonial_daily_captures d where d.user_id=auth.uid() and d.state='published' group by business_date having
 count(*) filter(where d.result->>'engineVersion'='patrimony-legacy-import-v1' and d.inputs#>>'{historicalSelection,version}'='1' and d.inputs#>>'{historicalSelection,authority}'='approved_csv_priority' and d.inputs#>>'{historicalSelection,sourceSha256}'=d.inputs->>'sourceSha256' and d.inputs->>'sourceSha256'~'^[a-f0-9]{64}$')>1
 or (count(*) filter(where d.result->>'engineVersion'='patrimony-history-v1')=0 and count(*) filter(where d.inputs#>>'{historicalSelection,authority}'='approved_csv_priority')=0 and count(distinct coalesce(d.inputs->>'sourceSha256','#missing'))>1)) then raise exception 'Ambiguous historical authorities' using errcode='23514';end if;
 if exists(select 1 from public.patrimonial_daily_captures d where d.user_id=auth.uid() and d.state='published' and d.result->>'engineVersion'='patrimony-legacy-import-v1' and d.inputs#>>'{historicalSelection,authority}'='approved_csv_priority' and (select count(*) from public.patrimonial_legacy_sources s where s.user_id=auth.uid() and s.business_date=d.business_date and s.source_sha256=d.inputs->>'sourceSha256')<>1) then raise exception 'Historical evidence missing or ambiguous' using errcode='23514';end if;
end$$;
revoke all on function private.assert_property_sources() from public,anon,authenticated,service_role;
do $property_identity$
declare definition text;original text;
begin
 original:=pg_get_functiondef('private.guard_property_rows()'::regprocedure);
 definition:=replace(original,'(tg_op=''INSERT'' or (old.quantity,','(tg_op=''INSERT'' or old.metadata->''position_observations'' is distinct from new.metadata->''position_observations'' or (old.quantity,');
 if definition=original then raise exception 'Unexpected property identity guard';end if;execute definition;
 original:=pg_get_functiondef('public.preview_property_valuation(uuid,uuid,uuid,uuid,date,text,numeric,text)'::regprocedure);
 definition:=replace(original,'if not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and asset_type_code=''real_estate'' and valuation_mode=''manual'' and is_active)',
 'select * into p from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid();'||chr(10)||' if not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and asset_type_code=''real_estate'' and valuation_mode=''manual'' and (is_active or p.id is not null))');
 if definition=original then raise exception 'Unexpected property lifecycle guard';end if;
 definition:=replace(definition,' select * into c from public.contracts',' perform private.assert_property_sources();'||chr(10)||' select * into c from public.contracts');
 definition:=replace(definition,'order by business_date,revision desc) d;','order by business_date,case when inputs#>>''{historicalSelection,authority}''=''approved_csv_priority'' then 0 when result->>''engineVersion''=''patrimony-history-v1'' then 1 else 2 end,revision desc) d;');
 execute definition;
 original:=pg_get_functiondef('public.preview_property_consolidation(uuid[],text)'::regprocedure);
 definition:=replace(original,' select count(distinct x)',' perform private.assert_property_sources();'||chr(10)||' select count(distinct x)');
 if definition=original then raise exception 'Unexpected consolidation preview';end if;execute definition;
end $property_identity$;
create or replace function private.guard_property_asset_mode() returns trigger language plpgsql security definer set search_path='' as $$begin
 if new.asset_type_code='real_estate' and new.valuation_mode<>'manual' then raise exception 'Real estate uses manual total valuations' using errcode='23514';end if;
 if exists(select 1 from public.positions where asset_id=new.id and metadata ? 'property_valuations') and (new.asset_type_code<>'real_estate' or new.valuation_mode<>'manual') then raise exception 'Property total valuation semantics are protected' using errcode='23514';end if;return new;end$$;
create trigger assets_06_property_manual_create before insert on public.assets for each row execute function private.guard_property_asset_mode();
notify pgrst,'reload schema';
commit;
