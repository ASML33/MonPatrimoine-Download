
begin;

create table private.xlsx_drive_destinations (
  owner_id uuid not null,
  folder_id text not null check (folder_id ~ '^[A-Za-z0-9_-]{5,160}$'),
  enabled boolean not null default false,
  active_operation uuid,
  lease_revision bigint not null default 0 check (lease_revision >= 0),
  lease_until timestamptz,
  primary key (owner_id, folder_id),
  unique (folder_id),
  check (lease_until is null or active_operation is not null)
);

create table private.xlsx_publications (
  owner_id uuid not null,
  folder_id text not null,
  operation_id uuid not null,
  business_date date not null check (business_date between date '1900-01-01' and date '9999-12-31'),
  state text not null default 'pending' check (state in ('pending','reserved','staged','verified','retired','rejected')),
  drive_file_id text unique check (drive_file_id ~ '^[A-Za-z0-9_-]{5,160}$'),
  byte_size integer not null check (byte_size between 1 and 5242880),
  sha256 text not null check (sha256 ~ '^[0-9a-f]{64}$'),
  created_at timestamptz not null default clock_timestamp(),
  verified_at timestamptz,
  completed_at timestamptz,
  primary key (owner_id, folder_id, operation_id),
  foreign key (owner_id, folder_id) references private.xlsx_drive_destinations,
  check (state not in ('reserved','staged','verified','retired') or drive_file_id is not null),
  check (state not in ('verified','retired') or verified_at is not null)
);

alter table private.xlsx_drive_destinations add foreign key (owner_id, folder_id, active_operation)
  references private.xlsx_publications (owner_id, folder_id, operation_id);

create table private.xlsx_trash_intents (
  owner_id uuid not null,
  folder_id text not null,
  publication_id uuid not null,
  target_id uuid not null,
  planned_at timestamptz not null default clock_timestamp(),
  confirmed_at timestamptz,
  primary key (owner_id, folder_id, publication_id, target_id),
  unique (owner_id, folder_id, target_id),
  foreign key (owner_id, folder_id, publication_id) references private.xlsx_publications,
  foreign key (owner_id, folder_id, target_id) references private.xlsx_publications,
  check (publication_id <> target_id)
);

alter table private.xlsx_drive_destinations enable row level security;
alter table private.xlsx_publications enable row level security;
alter table private.xlsx_trash_intents enable row level security;

revoke all on private.xlsx_drive_destinations, private.xlsx_publications, private.xlsx_trash_intents
  from public, anon, authenticated, service_role;

-- Provisioning is intentionally a database-administrator action. This migration registers no folder.
-- Each RPC call is a short transaction. The worker calls Drive only between committed RPC calls.
create function public.xlsx_publication_store(
  p_owner uuid, p_folder text, p_operation uuid, p_action text,
  p_revision bigint default null, p_details jsonb default '{}'::jsonb
) returns jsonb language plpgsql security definer set search_path = '' as $function$
declare
  destination private.xlsx_drive_destinations;
  publication private.xlsx_publications;
  target private.xlsx_publications;
  stamp timestamptz;
  requested_date date;
  expected_keys text[];
  actual_keys text[];
  requested_target_id uuid;
begin
  if p_owner is null or p_operation is null or not exists (
    select 1 from private.application_principal a
    join public.profiles p on p.auth_user_id = a.auth_user_id
    where a.singleton and a.auth_user_id = p_owner and p.is_active
  ) then
    raise exception 'Unauthorized XLSX owner' using errcode = '42501';
  end if;

  expected_keys := case p_action
    when 'claim' then array['business_date','byte_size','sha256']
    when 'reserve' then array['drive_file_id']
    when 'stage' then array['byte_size','drive_file_id','sha256']
    when 'verify' then array['byte_size','drive_file_id','sha256']
    when 'trash_confirm' then array['drive_file_id','target_id','trashed']
    when 'guard' then array[]::text[]
    when 'release' then array[]::text[]
    when 'finish' then array[]::text[]
    when 'trash_next' then array[]::text[]
    when 'reject' then array[]::text[]
  end;
  if expected_keys is null or jsonb_typeof(p_details) is distinct from 'object' then
    raise exception 'Invalid XLSX request' using errcode = '22023';
  end if;
  select coalesce(array_agg(key order by key collate "C"), array[]::text[])
    into actual_keys from jsonb_object_keys(p_details) as fields(key);
  if actual_keys <> expected_keys then
    raise exception 'Invalid XLSX fields' using errcode = '22023';
  end if;

  select * into destination from private.xlsx_drive_destinations
    where owner_id = p_owner and folder_id = p_folder and enabled for update;
  if not found or exists (
    select 1 from private.app_backup_drive_root where folder_id = p_folder
  ) then
    raise exception 'Unauthorized XLSX destination' using errcode = '42501';
  end if;

  select * into publication from private.xlsx_publications
    where owner_id = p_owner and folder_id = p_folder and operation_id = p_operation;
  stamp := clock_timestamp();

  if p_action = 'claim' then
    if p_revision is not null
      or coalesce(p_details->>'business_date','') !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
      or coalesce(p_details->>'byte_size','') !~ '^[1-9][0-9]{0,6}$'
      or (p_details->>'byte_size')::integer > 5242880
      or coalesce(p_details->>'sha256','') !~ '^[0-9a-f]{64}$' then
      raise exception 'Invalid XLSX publication identity' using errcode = '22023';
    end if;
    requested_date := (p_details->>'business_date')::date;
    if requested_date < date '1900-01-01' then
      raise exception 'Invalid XLSX date' using errcode = '22023';
    end if;
    if publication.operation_id is not null and (
      publication.business_date <> requested_date
      or publication.byte_size <> (p_details->>'byte_size')::integer
      or publication.sha256 <> p_details->>'sha256'
    ) then
      raise exception 'XLSX operation content differs' using errcode = '22023';
    end if;
    if publication.completed_at is not null then
      return jsonb_build_object('status', 'completed', 'phase', publication.state);
    end if;
    if destination.active_operation is not null and (
      destination.active_operation <> p_operation or destination.lease_until > stamp
    ) then
      return jsonb_build_object('status', 'busy');
    end if;
    if publication.operation_id is null then
      if (select count(distinct business_date) from private.xlsx_publications
          where owner_id = p_owner and folder_id = p_folder and state = 'verified'
            and business_date > requested_date) >= 5 then
        raise exception 'XLSX date outside retention window' using errcode = '22023';
      end if;
      insert into private.xlsx_publications (owner_id, folder_id, operation_id, business_date, byte_size, sha256)
        values (p_owner, p_folder, p_operation, requested_date, (p_details->>'byte_size')::integer, p_details->>'sha256')
        returning * into publication;
    end if;

    update private.xlsx_drive_destinations
      set active_operation = p_operation, lease_revision = lease_revision + 1, lease_until = stamp + interval '90 seconds'
      where owner_id = p_owner and folder_id = p_folder returning * into destination;
    return jsonb_build_object('status','claimed','phase',publication.state,'revision',destination.lease_revision::text,
      'lease_until',destination.lease_until,'drive_file_id',publication.drive_file_id);
  end if;

  if publication.operation_id is null or destination.active_operation is distinct from p_operation
    or destination.lease_revision is distinct from p_revision or destination.lease_until is null
    or destination.lease_until <= stamp then
    raise exception 'XLSX lease expired or superseded' using errcode = '42501';
  end if;

  if p_action = 'guard' then
    return jsonb_build_object('status','authorized','lease_until',destination.lease_until);
  elsif p_action = 'release' then
    update private.xlsx_drive_destinations set lease_until = null where owner_id = p_owner and folder_id = p_folder;
    return jsonb_build_object('status','released');
  elsif p_action = 'reserve' then
    if coalesce(p_details->>'drive_file_id','') !~ '^[A-Za-z0-9_-]{5,160}$'
      or exists (select 1 from private.xlsx_drive_destinations where folder_id = p_details->>'drive_file_id')
      or exists (select 1 from private.app_backup_drive_root where folder_id = p_details->>'drive_file_id')
      or exists (select 1 from private.app_backup_drive_files where file_id = p_details->>'drive_file_id') then
      raise exception 'Invalid XLSX file ID' using errcode = '22023';
    end if;
    if publication.drive_file_id is not null then
      if publication.drive_file_id <> p_details->>'drive_file_id' then
        raise exception 'XLSX file already reserved' using errcode = '22023';
      end if;
      return jsonb_build_object('status','reserved','drive_file_id',publication.drive_file_id);
    end if;
    update private.xlsx_publications set drive_file_id = p_details->>'drive_file_id', state = 'reserved'
      where owner_id = p_owner and folder_id = p_folder and operation_id = p_operation;
    return jsonb_build_object('status','reserved','drive_file_id',p_details->>'drive_file_id');
  elsif p_action in ('stage','verify') then
    if publication.drive_file_id is null or publication.drive_file_id is distinct from p_details->>'drive_file_id'
      or publication.byte_size::text is distinct from p_details->>'byte_size'
      or publication.sha256 is distinct from p_details->>'sha256' then
      raise exception 'XLSX readback differs' using errcode = '22023';
    end if;
    if p_action = 'stage' and publication.state in ('reserved','staged') then
      update private.xlsx_publications set state = 'staged'
        where owner_id = p_owner and folder_id = p_folder and operation_id = p_operation;
      return jsonb_build_object('status','staged');
    elsif p_action = 'verify' and publication.state in ('staged','verified') then
      update private.xlsx_publications set state = 'verified', verified_at = coalesce(verified_at, stamp)
        where owner_id = p_owner and folder_id = p_folder and operation_id = p_operation;
      -- A verified replacement displaces the preceding file of the same date.
      -- Other dates are selected only when they fall outside the most recent five.
      insert into private.xlsx_trash_intents (owner_id, folder_id, publication_id, target_id)
      select p_owner, p_folder, p_operation, old.operation_id
      from private.xlsx_publications old
      where old.owner_id = p_owner and old.folder_id = p_folder and old.state = 'verified'
        and old.operation_id <> p_operation and (
          old.business_date = publication.business_date or old.business_date not in (
            select distinct keep.business_date from private.xlsx_publications keep
            where keep.owner_id = p_owner and keep.folder_id = p_folder and keep.state = 'verified'
            order by keep.business_date desc limit 5
          )
        )
      on conflict (owner_id, folder_id, publication_id, target_id) do nothing;
      return jsonb_build_object('status','verified');
    end if;
    raise exception 'Invalid XLSX publication phase' using errcode = '22023';
  elsif p_action in ('trash_next','trash_confirm') then
    if publication.state <> 'verified' then
      raise exception 'XLSX replacement has not been verified' using errcode = '22023';
    end if;
    if p_action = 'trash_confirm' then
      requested_target_id := (p_details->>'target_id')::uuid;
    end if;
    select old.* into target from private.xlsx_trash_intents i join private.xlsx_publications old
      on (old.owner_id, old.folder_id, old.operation_id) = (i.owner_id, i.folder_id, i.target_id)
      where i.owner_id = p_owner and i.folder_id = p_folder and i.publication_id = p_operation
        and ((p_action = 'trash_next' and i.confirmed_at is null and old.state = 'verified')
          or (p_action = 'trash_confirm' and i.target_id = requested_target_id and old.state in ('verified','retired')))
        and not exists (select 1 from private.app_backup_drive_files where file_id = old.drive_file_id)
      order by old.business_date, old.created_at, old.operation_id limit 1;
    if p_action = 'trash_next' then
      if not found then
        if exists (
          select 1 from private.xlsx_trash_intents
          where owner_id = p_owner and folder_id = p_folder and publication_id = p_operation and confirmed_at is null
        ) then raise exception 'XLSX disposal target is protected' using errcode = '42501'; end if;
        return jsonb_build_object('status','none');
      end if;
      return jsonb_build_object('status','planned','target_id',target.operation_id,
        'drive_file_id',target.drive_file_id,'business_date',target.business_date,
        'byte_size',target.byte_size,'sha256',target.sha256);
    end if;
    if not found or target.drive_file_id is distinct from p_details->>'drive_file_id'
      or p_details->'trashed' is distinct from 'true'::jsonb then
      raise exception 'Invalid XLSX disposal proof' using errcode = '22023';
    end if;
    update private.xlsx_trash_intents i set confirmed_at = coalesce(confirmed_at, stamp)
      where i.owner_id = p_owner and i.folder_id = p_folder and i.publication_id = p_operation and i.target_id = target.operation_id;
    update private.xlsx_publications set state = 'retired'
      where owner_id = p_owner and folder_id = p_folder and operation_id = target.operation_id;
    return jsonb_build_object('status','retired');
  elsif p_action = 'reject' then
    -- A staged file may already have been promoted. Such operations must reconcile, not be rejected.
    if publication.state not in ('pending','reserved') then
      raise exception 'XLSX publication must be reconciled' using errcode = '22023';
    end if;
    update private.xlsx_publications set state = 'rejected', completed_at = stamp
      where owner_id = p_owner and folder_id = p_folder and operation_id = p_operation;
  elsif p_action = 'finish' then
    if publication.state <> 'verified' or exists (
      select 1 from private.xlsx_trash_intents
      where owner_id = p_owner and folder_id = p_folder and publication_id = p_operation and confirmed_at is null
    ) then
      raise exception 'XLSX publication or cleanup incomplete' using errcode = '22023';
    end if;
    update private.xlsx_publications set completed_at = stamp
      where owner_id = p_owner and folder_id = p_folder and operation_id = p_operation;
  end if;
  update private.xlsx_drive_destinations set active_operation = null, lease_until = null
    where owner_id = p_owner and folder_id = p_folder;
  return jsonb_build_object('status',case when p_action = 'reject' then 'rejected' else 'completed' end);
end
$function$;

revoke all on function public.xlsx_publication_store(uuid,text,uuid,text,bigint,jsonb)
  from public, anon, authenticated, service_role;
grant execute on function public.xlsx_publication_store(uuid,text,uuid,text,bigint,jsonb) to service_role;

commit;
