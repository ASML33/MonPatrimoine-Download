-- Stable visual defaults for existing contracts. User choices are never overwritten.
with palette(colors) as (
  values (array['#D6A84F','#5B9BD5','#70AD47','#8064A2','#ED7D31','#46B8B0','#C55A72','#9E7B5B','#7F8C8D','#A5A5A5']::text[])
), ranked as (
  select id, row_number() over (partition by user_id order by id) as rank
  from public.contracts
  where color is null
)
update public.contracts as contract
set color = palette.colors[1 + ((ranked.rank - 1) % cardinality(palette.colors))::integer]
from palette, ranked
where contract.id = ranked.id and contract.color is null;
