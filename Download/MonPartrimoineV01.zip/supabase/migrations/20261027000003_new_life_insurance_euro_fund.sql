-- New life-insurance contracts only: an explicit amount support, with no value.
begin;
set local lock_timeout='5s';
set local statement_timeout='45s';
lock table public.contracts,public.assets,public.positions,public.position_snapshots,public.asset_prices in share row exclusive mode;

create function private.initialize_euro_fund_identity() returns trigger
language plpgsql security definer set search_path='' as $$
begin
 if public.app_restore_permitted(tg_relid,tg_op,case when tg_op='INSERT' then null else to_jsonb(old) end,to_jsonb(new)) then return new;end if;
 if tg_op='UPDATE' then
  if new.metadata->'automatic_euro_fund' is distinct from old.metadata->'automatic_euro_fund' then
   raise exception 'Automatic fund identity is immutable' using errcode='23514';end if;
  return new;
 end if;
 if new.metadata ? 'automatic_euro_fund' then raise exception 'Automatic fund identity is server assigned' using errcode='23514';end if;
 if exists(select 1 from public.envelope_types where id=new.envelope_type_id and code='assurance_vie') then
  if auth.uid() is null or not public.is_authorized_user() or new.user_id is distinct from auth.uid()
   then raise exception 'Unauthorized' using errcode='42501';end if;
  new.metadata:=new.metadata||jsonb_build_object('automatic_euro_fund',jsonb_build_object(
   'version',1,'assetId',gen_random_uuid(),'positionId',gen_random_uuid()));
 end if;
 return new;
end $$;
revoke all on function private.initialize_euro_fund_identity() from public,anon,authenticated;
create trigger contracts_01_euro_fund_identity before insert or update on public.contracts
 for each row execute function private.initialize_euro_fund_identity();

create function private.guard_euro_fund_asset() returns trigger
language plpgsql security definer set search_path='' as $$
begin
 if public.app_restore_permitted(tg_relid,tg_op,case when tg_op='INSERT' then null else to_jsonb(old) end,to_jsonb(new)) then return new;end if;
 if tg_op='UPDATE' and new.metadata->'automatic_euro_fund' is distinct from old.metadata->'automatic_euro_fund'
 then raise exception 'Automatic fund binding is immutable' using errcode='23514';end if;
 if tg_op='INSERT' and new.metadata ? 'automatic_euro_fund' and not exists(select 1 from public.contracts c
  where c.id::text=new.metadata#>>'{automatic_euro_fund,contractId}' and c.user_id=new.owner_user_id
  and c.metadata#>>'{automatic_euro_fund,assetId}'=new.id::text)
 then raise exception 'Automatic fund asset not reserved by parent' using errcode='23514';end if;
 return new;
end $$;
revoke all on function private.guard_euro_fund_asset() from public,anon,authenticated;
create trigger assets_euro_fund_binding before insert or update on public.assets for each row execute function private.guard_euro_fund_asset();

-- An INSERT into an existing contract cannot forge a second empty support:
-- both identities are generated on the parent's INSERT and remain immutable.
do $patch$
declare original text; needle text:=' if p.user_id is distinct from auth.uid()';
begin
 original:=pg_get_functiondef('public.validate_initial_amount(public.positions)'::regprocedure);
 if position(needle in original)=0 then raise exception 'Unexpected initial amount validator';end if;
 execute replace(original,needle,$guard$
 if m->>'kind'='empty_euro_fund' then
  if auth.uid() is null or not public.is_authorized_user() or p.user_id is distinct from auth.uid()
   then raise exception 'Unauthorized' using errcode='42501';end if;
  perform 1 from public.contracts c join public.envelope_types t on t.id=c.envelope_type_id
   where c.id=p.contract_id and c.user_id=auth.uid() and c.is_active and c.valuation_source='positions'
   and t.code='assurance_vie' and c.metadata#>>'{automatic_euro_fund,version}'='1'
   and c.metadata#>>'{automatic_euro_fund,assetId}'=p.asset_id::text
   and c.metadata#>>'{automatic_euro_fund,positionId}'=p.id::text for update of c;
  if not found then raise exception 'Automatic support identity unavailable' using errcode='23514';end if;
  perform public.lock_amount_tracking_asset(p.asset_id);
  if not p.is_active or p.quantity is not null or p.average_cost_per_unit is not null or p.opened_on is not null
   or p.cost_currency_code<>'EUR' or p.metadata<>jsonb_build_object('initial_amount',jsonb_build_object('version',1,'kind','empty_euro_fund'))
   or not exists(select 1 from public.assets where id=p.asset_id and owner_user_id=auth.uid() and is_active and asset_type_code='fund' and valuation_mode='manual')
   or exists(select 1 from public.asset_prices where asset_id=p.asset_id)
   or exists(select 1 from public.position_snapshots where position_id=p.id)
   then raise exception 'Invalid empty monetary support' using errcode='23514';end if;
  return;
 end if;
 if p.user_id is distinct from auth.uid()$guard$);
end $patch$;

do $patch$
declare original text; needle text:=' if m is not null then';
begin
 original:=pg_get_functiondef('private.complete_initial_amount()'::regprocedure);
 if position(needle in original)=0 then raise exception 'Unexpected first proof trigger';end if;
 execute replace(original,needle,' if m->>''kind''=''empty_euro_fund'' then return new;end if;'||needle);
end $patch$;

create function private.create_new_euro_fund() returns trigger
language plpgsql security definer set search_path='' as $$
declare ids jsonb:=new.metadata->'automatic_euro_fund';
begin
 if public.app_restore_permitted(tg_relid,tg_op,null,to_jsonb(new)) then return new;end if;
 if ids is null then return new;end if;
 insert into public.assets(id,owner_user_id,name,asset_type_code,valuation_mode,currency_code,metadata)
  values((ids->>'assetId')::uuid,new.user_id,'Fonds euros','fund','manual','EUR',
   jsonb_build_object('automatic_euro_fund',jsonb_build_object('version',1,'contractId',new.id)));
 insert into public.positions(id,user_id,contract_id,asset_id,quantity,average_cost_per_unit,cost_currency_code,metadata)
  values((ids->>'positionId')::uuid,new.user_id,new.id,(ids->>'assetId')::uuid,null,null,'EUR',
   jsonb_build_object('initial_amount',jsonb_build_object('version',1,'kind','empty_euro_fund')));
 return new;
end $$;
revoke all on function private.create_new_euro_fund() from public,anon,authenticated;
create trigger contracts_new_euro_fund after insert on public.contracts for each row execute function private.create_new_euro_fund();

-- Reuse the delivered editor, CAS, audit and final-proof protection. Only this
-- explicit empty origin may receive its first observation without a snapshot.
do $patch$
declare original text; needle text:='or not exists(select 1 from public.position_snapshots where position_id=p.id)';
begin
 original:=pg_get_functiondef('public.edit_amount_observation(uuid,uuid,date,numeric,text,text,text,boolean)'::regprocedure);
 if position(needle in original)=0 then raise exception 'Unexpected amount editor eligibility';end if;
 original:=replace(original,needle,$guard$or (not exists(select 1 from public.position_snapshots where position_id=p.id)
  and not coalesce((p.metadata#>>'{initial_amount,kind}'='empty_euro_fund'
   and c.metadata#>>'{automatic_euro_fund,positionId}'=p.id::text
   and c.metadata#>>'{automatic_euro_fund,assetId}'=p.asset_id::text),false))$guard$);
 -- This new empty-origin support has only a civil date, not a source time.
 -- Its first value must be usable even when entered before noon. Keep the
 -- existing convention for all prior/manual attachments; no stored row changes.
 needle:='(requested_date+time ''12:00'')';
 if (length(original)-length(replace(original,needle,'')))/length(needle)<>2 then raise exception 'Unexpected amount observation timestamp';end if;
 execute replace(original,needle,'(requested_date+case when p.metadata#>>''{initial_amount,kind}''=''empty_euro_fund'' then time ''00:00'' else time ''12:00'' end)');
 original:=pg_get_functiondef('public.save_manual_asset_price(uuid,numeric,date)'::regprocedure);
 needle:=' lock table public.asset_prices in share row exclusive mode;';
 if position(needle in original)=0 then raise exception 'Unexpected price boundary';end if;
 execute replace(original,needle,needle||$guard$
 if exists(select 1 from public.positions where asset_id=requested_asset and metadata ? 'initial_amount') then
  raise exception 'Use total monetary valuation from the contract' using errcode='23514';end if;
 $guard$);
 original:=pg_get_functiondef('public.preview_amount_position(uuid,uuid,date,numeric,text)'::regprocedure);
 needle:=' if c.id is null or not c.is_active';
 if position(needle in original)=0 then raise exception 'Unexpected monetary attachment guard';end if;
 execute replace(original,needle,$guard$
 if a.metadata ? 'automatic_euro_fund' and a.metadata#>>'{automatic_euro_fund,contractId}' is distinct from requested_contract::text then
  raise exception 'Automatic fund belongs to another contract' using errcode='42501';end if;
 if c.id is null or not c.is_active$guard$);
end $patch$;
notify pgrst,'reload schema';
commit;
