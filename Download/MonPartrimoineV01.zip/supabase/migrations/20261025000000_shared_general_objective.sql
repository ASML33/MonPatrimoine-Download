-- Local candidate. Apply only after an explicit release authorization/preflight.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';

create or replace function private.shared_objective_text_valid(content text)
returns boolean language sql immutable set search_path='' as $$
 select content is not null and content !~ '[\x01-\x08\x0B\x0C\x0E-\x1F]'
 and (select coalesce(sum(case when ascii(c)>65535 then 2 else 1 end),0) from regexp_split_to_table(content,'') c)<=4000
$$;
revoke all on function private.shared_objective_text_valid(text) from public,anon,authenticated;

-- Reuse existing entries and dates. A strategy-only import is explicitly dated
-- at transition time; its original save date is unknown, never reconstructed.
do $$
declare p record; doc jsonb; old_strategy jsonb; legacy text; current_text text;
 entries jsonb; field text; e jsonb; stamp text;
begin
 for p in select auth_user_id,preferences,strategy_parameters from public.profiles
 where auth_user_id in(select auth_user_id from private.application_principal) for update loop
  doc:=p.preferences->'ai_photograph';
  if doc->'sharedObjectiveVersion'='1'::jsonb then
   if jsonb_typeof(doc->'sharedObjectiveRevision') is distinct from 'number' or doc->>'sharedObjectiveRevision' !~ '^(0|[1-9][0-9]{0,9})$' then raise exception 'OBJ-STATE';end if;
   continue;
  end if;
  if doc ? 'sharedObjectiveVersion' or doc->>'historyVersion' is distinct from '1' then raise exception 'OBJ-TRANSITION';end if;
  foreach field in array array['question','additionalInformation'] loop
   entries:=doc#>array['histories',field];
   if jsonb_typeof(entries) is distinct from 'array' then raise exception 'OBJ-STATE';end if;
   if (select count(*) from jsonb_array_elements(entries))<>(select count(distinct x->>'id') from jsonb_array_elements(entries) x) then raise exception 'OBJ-STATE';end if;
   for e in select value from jsonb_array_elements(entries) loop
    if jsonb_typeof(e) is distinct from 'object' or e->>'id' !~* '^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$'
     or jsonb_typeof(e->'text') is distinct from 'string' or e->>'recordedAt' is null then raise exception 'OBJ-STATE';end if;
    if not isfinite((e->>'recordedAt')::timestamptz) then raise exception 'OBJ-STATE';end if;
    if (field='question' and public.ai_input_history_text_valid(field,e->>'text') is distinct from true)
     or (field='additionalInformation' and private.shared_objective_text_valid(e->>'text') is distinct from true) then raise exception 'OBJ-TEXT';end if;
   end loop;
  end loop;
  old_strategy:=coalesce(p.strategy_parameters->'strategy','{}');
  if jsonb_typeof(old_strategy)<>'object' or (old_strategy ? 'general_objective' and jsonb_typeof(old_strategy->'general_objective') not in('string','null')) then raise exception 'OBJ-STATE';end if;
  legacy:=coalesce(old_strategy->>'general_objective','');
  select x->>'text' into current_text from jsonb_array_elements(doc#>'{histories,additionalInformation}') with ordinality t(x,ord)
   order by (x->>'recordedAt')::timestamptz desc,ord limit 1;
  current_text:=coalesce(current_text,'');
  if legacy<>'' and current_text<>'' and legacy<>current_text then raise exception 'OBJ-LEGACY-CONFLICT';end if;
  if legacy<>'' and current_text='' then
   if private.shared_objective_text_valid(legacy) is distinct from true then raise exception 'OBJ-TEXT';end if;
   stamp:=to_char(clock_timestamp() at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"');
   doc:=jsonb_set(doc,'{histories,additionalInformation}',jsonb_build_array(jsonb_build_object('id',gen_random_uuid(),'recordedAt',stamp,'text',legacy,'origin','strategy_transition'))||(doc#>'{histories,additionalInformation}'));
  end if;
  doc:=doc||jsonb_build_object('sharedObjectiveVersion',1,'sharedObjectiveRevision',0);
  update public.profiles set preferences=jsonb_set(preferences,'{ai_photograph}',doc),
   strategy_parameters=case when old_strategy ? 'general_objective' then jsonb_set(strategy_parameters,'{strategy}',old_strategy-'general_objective') else strategy_parameters end
   where auth_user_id=p.auth_user_id;
 end loop;
end $$;

-- Preserve the question writer and its idempotency, retire the other old access.
do $$begin
 if to_regprocedure('private.change_ai_input_history_before_shared_objective(text,text,uuid,text,boolean)') is null then
  alter function public.change_ai_input_history(text,text,uuid,text,boolean) rename to change_ai_input_history_before_shared_objective;
  alter function public.change_ai_input_history_before_shared_objective(text,text,uuid,text,boolean) set schema private;
 end if;
end $$;
revoke all on function private.change_ai_input_history_before_shared_objective(text,text,uuid,text,boolean) from public,anon,authenticated,service_role;
create or replace function public.change_ai_input_history(requested_operation text,requested_field text,requested_entry uuid,requested_text text default null,deletion_confirmed boolean default false)
returns jsonb language plpgsql security definer set search_path='' as $$begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 if requested_field is distinct from 'question' then raise exception 'OBJ-OBSOLETE-WRITER' using errcode='55000';end if;
 return private.change_ai_input_history_before_shared_objective(requested_operation,requested_field,requested_entry,requested_text,deletion_confirmed);
end $$;
revoke all on function public.change_ai_input_history(text,text,uuid,text,boolean) from public,anon;
grant execute on function public.change_ai_input_history(text,text,uuid,text,boolean) to authenticated;

create or replace function public.change_shared_objective_history(requested_operation text,requested_entry uuid,requested_text text,expected_revision bigint,deletion_confirmed boolean default false)
returns jsonb language plpgsql security definer set search_path='' as $$
declare prefs jsonb; doc jsonb; entries jsonb; existing jsonb; entry jsonb; revision bigint;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 if requested_operation is null or requested_operation not in('save','delete') or requested_entry is null or expected_revision is null or expected_revision<0 or expected_revision>=2147483647 then raise exception 'OBJ-REQUEST' using errcode='22023';end if;
 if requested_operation='delete' and deletion_confirmed is distinct from true then raise exception 'OBJ-CONFIRM' using errcode='22023';end if;
 if requested_operation='save' and private.shared_objective_text_valid(requested_text) is distinct from true then raise exception 'OBJ-TEXT' using errcode='22023';end if;
 select preferences into prefs from public.profiles where auth_user_id=auth.uid() for update;
 if not found then raise exception 'Unauthorized' using errcode='42501';end if;
 doc:=prefs->'ai_photograph';
 if doc->'sharedObjectiveVersion' is distinct from '1'::jsonb or jsonb_typeof(doc->'sharedObjectiveRevision') is distinct from 'number' or doc->>'sharedObjectiveRevision' is null or doc->>'sharedObjectiveRevision' !~ '^(0|[1-9][0-9]{0,9})$' or jsonb_typeof(doc#>'{histories,additionalInformation}') is distinct from 'array' then raise exception 'OBJ-TRANSITION' using errcode='55000';end if;
 revision:=(doc->>'sharedObjectiveRevision')::bigint;entries:=doc#>'{histories,additionalInformation}';
 select e into existing from jsonb_array_elements(entries) e where e->>'id'=requested_entry::text;
 if requested_operation='save' and existing is not null then
  if existing->>'text' is distinct from requested_text then raise exception 'OBJ-SUBMISSION' using errcode='40001';end if;
  -- Never silently rebase an ambiguous retry onto another tab's newer revision.
  return jsonb_build_object('entry',existing,'revision',expected_revision+1);
 end if;
 if revision<>expected_revision then raise exception 'OBJ-CONFLICT' using errcode='40001';end if;
 if requested_operation='delete' and existing is null then return jsonb_build_object('entry',null,'revision',revision);end if;
 if requested_operation='save' then
  entry:=jsonb_build_object('id',requested_entry,'recordedAt',to_char(clock_timestamp() at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'text',requested_text);
  entries:=jsonb_build_array(entry)||entries;
 else
  select coalesce(jsonb_agg(e order by ord),'[]') into entries from jsonb_array_elements(entries) with ordinality t(e,ord) where e->>'id'<>requested_entry::text;
 end if;
 doc:=jsonb_set(doc,'{histories,additionalInformation}',entries)||jsonb_build_object('sharedObjectiveRevision',revision+1);
 update public.profiles set preferences=jsonb_set(prefs,'{ai_photograph}',doc) where auth_user_id=auth.uid();
 return jsonb_build_object('entry',entry,'revision',revision+1);
end $$;
revoke all on function public.change_shared_objective_history(text,uuid,text,bigint,boolean) from public,anon;
grant execute on function public.change_shared_objective_history(text,uuid,text,bigint,boolean) to authenticated;

-- No other active writer uses this legacy column. Other profile permissions stay.
revoke update(strategy_parameters) on public.profiles from authenticated;
do $$begin
 if has_column_privilege('authenticated','public.profiles','strategy_parameters','UPDATE') then raise exception 'OBJ-LEGACY-GRANT';end if;
end $$;

-- Restore compatibility stays inside the existing operator-only boundary.
-- Normalize the target document before the existing canonical replacement;
-- no trigger, archive-format change, read-side write or general restore bypass.
create or replace function private.shared_objective_restore_document(archive jsonb)
returns jsonb language plpgsql security definer set search_path='' as $$
declare prefs jsonb; params jsonb; doc jsonb; entries jsonb; legacy text; latest text; revision bigint; e jsonb; field text;
begin
 if public.is_authorized_user() is not true or archive->>'owner' is distinct from auth.uid()::text then raise exception 'Unauthorized' using errcode='42501';end if;
 prefs:=(archive#>>'{preferences,preferences}')::jsonb;
 params:=(archive#>>'{preferences,strategy_parameters}')::jsonb;
 doc:=prefs->'ai_photograph';
 if jsonb_typeof(prefs) is distinct from 'object' or jsonb_typeof(params) is distinct from 'object' or doc->>'historyVersion' is distinct from '1' then raise exception 'OBJ-RESTORE-STATE';end if;
 foreach field in array array['question','additionalInformation'] loop
  entries:=doc#>array['histories',field];
  if jsonb_typeof(entries) is distinct from 'array' then raise exception 'OBJ-RESTORE-STATE';end if;
  if (select count(*) from jsonb_array_elements(entries))<>(select count(distinct x->>'id') from jsonb_array_elements(entries) x) then raise exception 'OBJ-RESTORE-STATE';end if;
  for e in select value from jsonb_array_elements(entries) loop
   if e->>'id' is null or e->>'id' !~* '^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$' or jsonb_typeof(e->'text') is distinct from 'string' or e->>'recordedAt' is null or not isfinite((e->>'recordedAt')::timestamptz) then raise exception 'OBJ-RESTORE-STATE';end if;
   if (field='question' and public.ai_input_history_text_valid(field,e->>'text') is distinct from true) or (field='additionalInformation' and private.shared_objective_text_valid(e->>'text') is distinct from true) then raise exception 'OBJ-TEXT';end if;
  end loop;
 end loop;
 if params ? 'strategy' and jsonb_typeof(params->'strategy') is distinct from 'object' then raise exception 'OBJ-RESTORE-STATE';end if;
 if params#>'{strategy,general_objective}' is not null and jsonb_typeof(params#>'{strategy,general_objective}') not in('string','null') then raise exception 'OBJ-RESTORE-STATE';end if;
 legacy:=coalesce(params#>>'{strategy,general_objective}','');
 select x->>'text' into latest from jsonb_array_elements(doc#>'{histories,additionalInformation}') with ordinality t(x,ord) order by (x->>'recordedAt')::timestamptz desc,ord limit 1;
 -- An explicit empty entry is authoritative too. Never resurrect the legacy text.
 if legacy<>'' and legacy is distinct from latest then raise exception 'OBJ-LEGACY-CONFLICT';end if;
 if doc ? 'sharedObjectiveVersion' and doc->'sharedObjectiveVersion' is distinct from '1'::jsonb then raise exception 'OBJ-RESTORE-STATE';end if;
 select (preferences#>>'{ai_photograph,sharedObjectiveRevision}')::bigint into revision from public.profiles where auth_user_id=auth.uid();
 if revision is null or revision<0 or revision>=2147483646 then raise exception 'OBJ-RESTORE-STATE';end if;
 doc:=doc||jsonb_build_object('sharedObjectiveVersion',1,'sharedObjectiveRevision',revision+1);
 prefs:=jsonb_set(prefs,'{ai_photograph}',doc);
 if coalesce(params->'strategy','{}') ? 'general_objective' then params:=jsonb_set(params,'{strategy}',(params->'strategy')-'general_objective');end if;
 archive:=jsonb_set(archive,'{preferences,preferences}',to_jsonb(prefs::text));
 return jsonb_set(archive,'{preferences,strategy_parameters}',to_jsonb(params::text));
end $$;
revoke all on function private.shared_objective_restore_document(jsonb) from public,anon,authenticated,service_role;

do $adapt$ declare definition text; old_call text:=$call$private.app_backup_replace(args->'document',args->>'expected_digest')$call$; old_check text:=$check$receipt.document_digest<>encode(extensions.digest((args->'document')::text,'sha256'),'hex')$check$;
begin
 definition:=pg_get_functiondef('public.application_backup_server(text,jsonb,jsonb)'::regprocedure);
 if position(old_call in definition)>0 then
  if (length(definition)-length(replace(definition,old_call,'')))/length(old_call)<>2 or position(old_check in definition)=0 then raise exception 'OBJ-RESTORE-FRONTIER';end if;
  definition:=replace(definition,old_call,$call$private.app_backup_replace(private.shared_objective_restore_document(args->'document'),args->>'expected_digest')$call$);
  -- Exact original archive SHA plus before-image bind retries; the target digest
  -- includes the normalized preferences and is still checked by the preview token.
  definition:=replace(definition,old_check,$check$receipt.archive_sha256 is distinct from args#>>'{backup,archiveSha256}'$check$);
  execute definition;
 elsif position('private.shared_objective_restore_document' in definition)=0 then raise exception 'OBJ-RESTORE-FRONTIER';end if;
end $adapt$;

notify pgrst,'reload schema';
commit;
