begin;

create or replace function public.xlsx_financial_destination(p_owner uuid,p_folder text default null,p_parent text default null,p_account text default null)
returns jsonb language plpgsql security definer set search_path='' as $$
declare
  cfg private.xlsx_financial_configuration;
  technical text;
  pending private.xlsx_financial_jobs;
begin
  if not exists (
    select 1 from private.application_principal a join public.profiles p on p.auth_user_id=a.auth_user_id
    where a.singleton and p.is_active and a.auth_user_id=p_owner
  ) then raise exception 'Unauthorized financial XLSX owner' using errcode='42501'; end if;
  perform pg_advisory_xact_lock(hashtextextended(p_owner::text,392074));
  select folder_id into technical from private.app_backup_drive_root where user_id=p_owner;
  select * into cfg from private.xlsx_financial_configuration where owner_id=p_owner for update;
  if p_folder is null then
    return jsonb_build_object('status','current','folder',cfg.folder_id,'parent',cfg.drive_parent,
      'account',cfg.drive_account,'technical',technical,'enabled',coalesce(cfg.enabled,false));
  end if;
  if p_folder !~ '^[A-Za-z0-9_-]{5,160}$' or p_parent is null or p_parent !~ '^[A-Za-z0-9_-]{5,160}$'
    or p_account is null or p_account !~ '^[a-f0-9]{64}$'
    or p_parent=p_folder or p_parent=technical then
    raise exception 'Invalid financial XLSX destination' using errcode='22023';
  end if;
  -- The historical root may be reused only if it already belongs to the
  -- financial publication registry. The server verifies its Drive marker.
  if p_folder=technical and not exists (
    select 1 from private.xlsx_drive_destinations d
    where d.owner_id=p_owner and d.folder_id=p_folder and d.enabled
  ) then
    raise exception 'Unregistered historical XLSX destination' using errcode='42501';
  end if;
  if cfg.folder_id is not distinct from p_folder and cfg.drive_account is not null and cfg.drive_account<>p_account then
    raise exception 'Folder belongs to another Google account' using errcode='42501';
  end if;
  if cfg.folder_id is not distinct from p_folder and cfg.drive_account=p_account and cfg.drive_parent=p_parent and cfg.enabled then
    return jsonb_build_object('status','saved');
  end if;
  select * into pending from private.xlsx_financial_jobs where owner_id=p_owner and completed_at is null;
  if found then
    if pending.captured_at>=clock_timestamp()-interval '90 seconds' or exists(
      select 1 from private.xlsx_publications j where j.owner_id=p_owner and j.operation_id=pending.operation_id
    ) then return jsonb_build_object('status','busy'); end if;
    update private.xlsx_financial_jobs set completed_at=clock_timestamp(),last_error='destination_changed',source=null,prepared=null
      where owner_id=p_owner and operation_id=pending.operation_id;
  end if;
  insert into private.xlsx_drive_destinations(owner_id,folder_id,enabled) values(p_owner,p_folder,true)
    on conflict (owner_id,folder_id) do update set enabled=true;
  insert into private.xlsx_financial_configuration(owner_id,folder_id,drive_account,drive_parent,enabled)
    values(p_owner,p_folder,p_account,p_parent,true)
    on conflict (owner_id) do update set folder_id=excluded.folder_id,drive_account=excluded.drive_account,
      drive_parent=excluded.drive_parent,enabled=true;
  return jsonb_build_object('status','saved');
end;
$$;
revoke all on function public.xlsx_financial_destination(uuid,text,text,text) from public,anon,authenticated,service_role;
grant execute on function public.xlsx_financial_destination(uuid,text,text,text) to service_role;

commit;
