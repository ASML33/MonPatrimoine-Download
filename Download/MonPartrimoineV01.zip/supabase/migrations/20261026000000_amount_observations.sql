begin;
set local lock_timeout='5s';
set local statement_timeout='45s';
-- Drain old writers before changing their capability boundary.
lock table public.contracts,public.positions,public.position_snapshots,public.asset_prices in share row exclusive mode;
-- Monetary observations of existing manual supports.
-- No synthetic quantity/unit price, cash flow, cash balance or capture mutation.
create function public.edit_amount_observation(requested_position uuid, requested_snapshot uuid,
 requested_date date, requested_amount numeric, requested_currency text,
 requested_operation text, expected_token text, confirmed boolean default false)
returns jsonb language plpgsql security definer set search_path='' as $$
declare p public.positions; c public.contracts; a public.assets; s public.position_snapshots;
 token text; rows jsonb; audit jsonb; result_id uuid; stamp timestamptz;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 -- Same parent/position lock order as the dated-holding writer.
 select * into p from public.positions where id=requested_position and user_id=auth.uid();
 select * into c from public.contracts where id=p.contract_id and user_id=auth.uid() for update;
 select * into p from public.positions where id=requested_position and user_id=auth.uid() for update;
 -- Serialize the fingerprint with direct snapshot/price writers as well.
 lock table public.position_snapshots in share row exclusive mode;
 lock table public.asset_prices in share mode;
 select * into a from public.assets where id=p.asset_id and owner_user_id=auth.uid() for share;
 if p.id is null or c.id is null or a.id is null or not p.is_active or not c.is_active or c.valuation_source<>'positions'
  or a.valuation_mode<>'manual' or a.asset_type_code<>'fund'
  or p.metadata ? 'position_observations' or p.metadata ? 'property_valuations'
  or exists(select 1 from public.asset_prices where asset_id=a.id)
  or not exists(select 1 from public.position_snapshots where position_id=p.id and unit_price is null)
  or exists(select 1 from public.position_snapshots where position_id=p.id and unit_price is not null)
 then raise exception 'Existing monetary support required' using errcode='23514';end if;
 select coalesce(jsonb_agg(to_jsonb(x) order by x.id),'[]') into rows from public.position_snapshots x where position_id=p.id;
 token:=md5(to_jsonb(p)::text||to_jsonb(c)::text||to_jsonb(a)::text||rows::text);
 if requested_operation not in ('save','delete') or requested_operation is null then raise exception 'Invalid operation' using errcode='23514';end if;
 if requested_snapshot is not null then
  select * into s from public.position_snapshots where id=requested_snapshot and position_id=p.id and user_id=auth.uid() for update;
  if s.id is null then raise exception 'Observation changed' using errcode='40001';end if;
 end if;
 if requested_operation='delete' and (s.id is null or jsonb_array_length(rows)<=1) then
  raise exception 'Keep original monetary evidence; removal of final observation requires reconciliation' using errcode='23514';end if;
 if requested_operation='save' then
  if requested_date is null or requested_date<c.opened_on or requested_date>(clock_timestamp() at time zone 'Europe/Paris')::date
   or requested_amount is null or requested_amount<0 or requested_amount>=1e16 or requested_amount<>round(requested_amount,8)
   or not exists(select 1 from public.currencies where code=requested_currency and is_active)
   or exists(select 1 from public.position_snapshots where position_id=p.id and id is distinct from requested_snapshot and (valued_at at time zone 'Europe/Paris')::date=requested_date)
   then raise exception 'Invalid or occupied observation date' using errcode='23514';end if;
 end if;
 if not confirmed then return jsonb_build_object('token',token,'snapshot',to_jsonb(s),'operation',requested_operation);end if;
 if expected_token is distinct from token then raise exception 'State changed since preview' using errcode='40001';end if;
 audit:=coalesce(p.metadata->'amount_observation_audit','[]');
 if jsonb_typeof(audit)<>'array' then raise exception 'Invalid audit' using errcode='23514';end if;
 stamp:=clock_timestamp();
 if requested_operation='delete' then
  delete from public.position_snapshots where id=s.id and position_id=p.id and user_id=auth.uid();result_id:=s.id;
 elsif s.id is not null then
  update public.position_snapshots set market_value=requested_amount,currency_code=requested_currency,
   valued_at=(requested_date+time '12:00') at time zone 'Europe/Paris' where id=s.id and user_id=auth.uid();result_id:=s.id;
 else
  insert into public.position_snapshots(user_id,position_id,valued_at,quantity,unit_price,market_value,currency_code)
   values(auth.uid(),p.id,(requested_date+time '12:00') at time zone 'Europe/Paris',p.quantity,null,requested_amount,requested_currency) returning id into result_id;
 end if;
 update public.positions set metadata=metadata||jsonb_build_object('amount_observation_audit',audit||jsonb_build_array(
  jsonb_build_object('operation',requested_operation,'snapshotId',result_id,'before',case when s.id is null then null else to_jsonb(s) end,
   'after',(select to_jsonb(x) from public.position_snapshots x where id=result_id),'recordedAt',stamp,'token',token))) where id=p.id and user_id=auth.uid();
 return jsonb_build_object('id',result_id);
end $$;
revoke all on function public.edit_amount_observation(uuid,uuid,date,numeric,text,text,text,boolean) from public,anon;
grant execute on function public.edit_amount_observation(uuid,uuid,date,numeric,text,text,text,boolean) to authenticated;
-- Only this narrowly scoped, owner-checked RPC may mutate snapshots from a
-- browser. Existing operator/backup privileges and FORCE RLS remain unchanged.
alter function public.edit_amount_observation(uuid,uuid,date,numeric,text,text,text,boolean) owner to postgres;
revoke insert,update,delete on public.position_snapshots from public,anon,authenticated;

-- Retire direct browser price writes as well; the existing manual-price RPC
-- keeps its explicit Auth/principal and asset-owner checks. No trigger/schema
-- fingerprint changes: existing /3 archives retain their compatibility frontier.
do $price$
declare original text; needle text:='  insert into public.asset_prices ('; patched text;
begin
 original:=pg_get_functiondef('public.save_manual_asset_price(uuid,numeric,date)'::regprocedure);
 patched:=replace(original,needle,$guard$
 lock table public.asset_prices in share row exclusive mode;
 if exists(select 1 from public.assets a where a.id=requested_asset and a.valuation_mode='manual' and a.asset_type_code='fund')
  and exists(select 1 from public.positions p join public.position_snapshots s on s.position_id=p.id where p.asset_id=requested_asset and s.unit_price is null)
  and not exists(select 1 from public.asset_prices q where q.asset_id=requested_asset)
 then raise exception 'Use total monetary valuation from the contract' using errcode='23514';end if;
  insert into public.asset_prices ($guard$);
 if patched=original then raise exception 'Unexpected manual price definition';end if;
 execute patched;
end $price$;
alter function public.save_manual_asset_price(uuid,numeric,date) security definer;
alter function public.save_manual_asset_price(uuid,numeric,date) owner to postgres;
revoke insert,update,delete on public.asset_prices from public,anon,authenticated;

-- Existing quantity preview, save RPC and table guard share this authority.
do $adapt$
declare original text; needle text:='h:=coalesce(p.metadata->''position_observations'''; patched text;
begin
 original:=pg_get_functiondef('public.preview_position_observation(uuid,uuid,uuid,uuid,date,numeric,numeric,text)'::regprocedure);
 patched:=replace(original,needle,$guard$
 if exists(select 1 from public.assets a where a.id=p.asset_id and a.valuation_mode='manual' and a.asset_type_code='fund')
  and exists(select 1 from public.position_snapshots where position_id=p.id and unit_price is null)
  and not exists(select 1 from public.asset_prices where asset_id=p.asset_id)
 then raise exception 'Use total monetary valuation, not quantity or PRU' using errcode='23514';end if;
 h:=coalesce(p.metadata->'position_observations'$guard$);
 if patched=original then raise exception 'Unexpected holding preview definition';end if;
 execute patched;
end $adapt$;

notify pgrst,'reload schema';
commit;
