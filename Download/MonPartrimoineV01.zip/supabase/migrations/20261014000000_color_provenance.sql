begin;

-- Existing colors are intentionally not rewritten or classified by their value.
alter table public.assets add column color_origin text not null default 'legacy_unknown'
  check (color_origin in ('user','automatic','legacy_unknown'));
alter table public.contracts add column color_origin text not null default 'legacy_unknown'
  check (color_origin in ('user','automatic','legacy_unknown'));

create function private.guard_color_provenance() returns trigger
language plpgsql set search_path='' as $$
begin
  if new.color is null then
    new.color_origin := 'automatic';
  elsif tg_op='UPDATE' and new.color is distinct from old.color
    and new.color_origin='automatic' and old.color_origin in ('user','legacy_unknown') then
    raise exception 'Protected color cannot be replaced automatically' using errcode='23514';
  end if;
  return new;
end $$;

create trigger assets_color_provenance before insert or update on public.assets
for each row execute function private.guard_color_provenance();
create trigger contracts_color_provenance before insert or update on public.contracts
for each row execute function private.guard_color_provenance();

commit;
