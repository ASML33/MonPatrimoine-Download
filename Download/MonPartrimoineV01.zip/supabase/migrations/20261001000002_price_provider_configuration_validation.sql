-- Preserve a free provider display name while keeping runtime adapters explicit.
begin;

alter table public.price_provider_configurations
  add column display_name text;

update public.price_provider_configurations
set display_name = case provider
  when 'twelve_data' then 'Twelve Data'
  when 'eodhd' then 'EODHD'
  else provider
end;

alter table public.price_provider_configurations
  alter column display_name set not null,
  add constraint price_provider_display_name_valid
    check (char_length(btrim(display_name)) between 1 and 120);

alter table public.price_provider_configurations
  drop constraint price_provider_configurations_provider_check,
  drop constraint price_provider_configurations_status_check,
  drop constraint eodhd_free_eod_only,
  alter column provider drop not null;

update public.price_provider_configurations
set status = case
  when provider is null then 'unsupported'
  else 'untested'
end;

alter table public.price_provider_configurations
  add constraint price_provider_adapter_valid
    check (provider is null or provider in ('twelve_data', 'eodhd')),
  add constraint price_provider_status_valid
    check (status in ('untested', 'validated', 'invalid', 'unsupported')),
  add constraint eodhd_free_eod_only
    check (provider <> 'eodhd' or capability = 'eod'),
  add column last_tested_at timestamptz;

drop function public.get_price_provider_configurations();
create function public.get_price_provider_configurations()
returns table(
  slot smallint,
  provider_name text,
  adapter text,
  active boolean,
  priority smallint,
  region text,
  capability text,
  status text,
  last_tested_at timestamptz
)
language sql
stable
security invoker
set search_path = ''
as $$
  select c.slot, c.display_name, c.provider, c.active, c.priority,
    c.region, c.capability, c.status, c.last_tested_at
  from public.price_provider_configurations c
  where c.owner_user_id = auth.uid()
    and public.is_authorized_user()
  order by c.slot;
$$;

drop function public.save_price_provider_configuration(smallint, text, boolean, smallint, text, text, text);
create function public.save_price_provider_configuration(
  requested_slot smallint,
  requested_provider_name text,
  requested_active boolean,
  requested_priority smallint,
  requested_region text,
  requested_capability text,
  api_key text default null
)
returns void
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  owner_id uuid := auth.uid();
  principal_id uuid;
  normalized_name text;
  requested_adapter text;
  current_adapter text;
  current_priority smallint;
  competing_slot smallint;
  replacement_priority smallint;
  secret_id uuid;
  secret_name text;
begin
  select auth_user_id into principal_id from private.application_principal where singleton;
  if owner_id is null or owner_id is distinct from principal_id
    or not exists (select 1 from public.profiles where auth_user_id = owner_id and is_active) then
    raise exception 'price provider configuration unavailable' using errcode = '42501';
  end if;

  requested_provider_name := btrim(coalesce(requested_provider_name, ''));
  normalized_name := regexp_replace(lower(requested_provider_name), '[^a-z0-9]+', '', 'g');
  requested_adapter := case normalized_name
    when 'twelvedata' then 'twelve_data'
    when 'eodhd' then 'eodhd'
    else null
  end;

  if requested_slot not between 1 and 10 or requested_priority not between 1 and 10
    or char_length(requested_provider_name) not between 1 and 120
    or requested_region not in ('us', 'europe', 'global')
    or requested_capability not in ('eod', 'intraday', 'both')
    or (requested_adapter = 'eodhd' and requested_capability <> 'eod') then
    raise exception 'invalid price provider configuration' using errcode = '22023';
  end if;
  if api_key is not null and (
    api_key = '' or api_key <> btrim(api_key) or char_length(api_key) > 4096
  ) then
    raise exception 'invalid API key' using errcode = '22023';
  end if;

  select c.provider, c.priority
    into current_adapter, current_priority
    from public.price_provider_configurations c
    where c.owner_user_id = owner_id and c.slot = requested_slot
    for update;

  secret_name := 'monpatrimoine.price-provider.' || owner_id::text || '.' || requested_slot::text;
  select s.id into secret_id from vault.secrets s where s.name = secret_name;
  if api_key is null and secret_id is null then
    raise exception 'an API key is required' using errcode = '22023';
  end if;
  if api_key is null and current_adapter is distinct from requested_adapter then
    raise exception 'a new key is required when changing provider' using errcode = '22023';
  end if;

  select c.slot into competing_slot
  from public.price_provider_configurations c
  where c.owner_user_id = owner_id
    and c.priority = requested_priority
    and c.slot <> requested_slot
  for update;
  if competing_slot is not null then
    if current_priority is not null then
      replacement_priority := current_priority;
    else
      select candidate::smallint into replacement_priority
      from generate_series(1, 10) candidate
      where candidate <> requested_priority
        and not exists (
          select 1 from public.price_provider_configurations c
          where c.owner_user_id = owner_id and c.priority = candidate
        )
      order by candidate
      limit 1;
    end if;
    if replacement_priority is null then
      raise exception 'no free price provider priority' using errcode = '23514';
    end if;
    update public.price_provider_configurations
      set priority = replacement_priority, updated_at = clock_timestamp()
      where owner_user_id = owner_id and slot = competing_slot;
  end if;

  if api_key is not null and secret_id is null then
    perform vault.create_secret(
      api_key,
      secret_name,
      'MonPatrimoine automatic price provider credential for slot ' || requested_slot::text
    );
  elsif api_key is not null then
    perform vault.update_secret(
      secret_id,
      api_key,
      secret_name,
      'MonPatrimoine automatic price provider credential for slot ' || requested_slot::text
    );
  end if;

  insert into public.price_provider_configurations (
    owner_user_id, slot, display_name, provider, active, priority,
    region, capability, status, last_tested_at
  ) values (
    owner_id, requested_slot, requested_provider_name, requested_adapter,
    requested_active, requested_priority, requested_region, requested_capability,
    case when requested_adapter is null then 'unsupported' else 'untested' end,
    null
  ) on conflict (owner_user_id, slot) do update set
    display_name = excluded.display_name,
    provider = excluded.provider,
    active = excluded.active,
    priority = excluded.priority,
    region = excluded.region,
    capability = excluded.capability,
    status = excluded.status,
    last_tested_at = null,
    updated_at = clock_timestamp();

  if current_adapter is distinct from requested_adapter then
    delete from public.asset_price_provider_capabilities
    where owner_user_id = owner_id and provider_slot = requested_slot;
  end if;
end;
$$;

create function public.get_price_provider_runtime_credential(requested_slot smallint)
returns table(adapter text, api_key text)
language sql
stable
security definer
set search_path = ''
as $$
  select c.provider, d.decrypted_secret
  from public.price_provider_configurations c
  join private.application_principal p
    on p.singleton and p.auth_user_id = c.owner_user_id
  join vault.decrypted_secrets d
    on d.name = 'monpatrimoine.price-provider.' || c.owner_user_id::text || '.' || c.slot::text
  where c.slot = requested_slot
    and c.provider is not null;
$$;

create function public.set_price_provider_validation_status(
  requested_slot smallint,
  requested_status text,
  requested_tested_at timestamptz
)
returns void
language plpgsql
volatile
security definer
set search_path = ''
as $$
begin
  if requested_status not in ('validated', 'invalid') or requested_tested_at is null then
    raise exception 'invalid price provider validation status' using errcode = '22023';
  end if;
  update public.price_provider_configurations c
  set status = requested_status,
      last_tested_at = requested_tested_at,
      updated_at = clock_timestamp()
  from private.application_principal p
  where p.singleton
    and c.owner_user_id = p.auth_user_id
    and c.slot = requested_slot
    and c.provider is not null;
  if not found then
    raise exception 'price provider configuration unavailable' using errcode = '22023';
  end if;
end;
$$;

create or replace function public.get_price_provider_runtime_configurations()
returns table(
  slot smallint,
  provider text,
  priority smallint,
  region text,
  capability text,
  api_key text
)
language sql
stable
security definer
set search_path = ''
as $$
  select c.slot, c.provider, c.priority, c.region, c.capability, d.decrypted_secret
  from public.price_provider_configurations c
  join private.application_principal p
    on p.singleton and p.auth_user_id = c.owner_user_id
  join vault.decrypted_secrets d
    on d.name = 'monpatrimoine.price-provider.' || c.owner_user_id::text || '.' || c.slot::text
  where c.active and c.provider is not null and c.status = 'validated'
  order by c.priority;
$$;

create or replace function public.mark_price_provider_configuration_invalid(requested_slot smallint)
returns void
language sql
volatile
security definer
set search_path = ''
as $$
  update public.price_provider_configurations c
  set status = 'invalid', last_tested_at = clock_timestamp(), updated_at = clock_timestamp()
  from private.application_principal p
  where p.singleton
    and c.owner_user_id = p.auth_user_id
    and c.slot = requested_slot;
$$;

create or replace function public.consume_price_provider_quota(
  requested_slot smallint,
  requested_cost integer default 1,
  requested_reserve integer default 0
)
returns table(allowed boolean, retry_after timestamptz)
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  principal_id uuid;
  provider_code text;
  minute_start timestamptz := date_trunc('minute', clock_timestamp());
  day_start timestamptz := date_trunc('day', clock_timestamp());
  minute_used integer := 0;
  day_used integer := 0;
  day_limit integer;
begin
  select auth_user_id into principal_id from private.application_principal where singleton;
  select provider into provider_code
  from public.price_provider_configurations
  where owner_user_id = principal_id and slot = requested_slot and active and status = 'validated';
  if provider_code is null or requested_cost < 1 or requested_cost > 100 or requested_reserve < 0 then
    return query select false, clock_timestamp() + interval '1 hour';
    return;
  end if;

  perform pg_advisory_xact_lock(hashtextextended(principal_id::text || ':' || requested_slot::text, 0));
  insert into private.price_provider_usage_windows values
    (principal_id, requested_slot, 'day', day_start, 0, clock_timestamp())
  on conflict do nothing;
  select used_count into day_used from private.price_provider_usage_windows
  where owner_user_id = principal_id and provider_slot = requested_slot
    and bucket_kind = 'day' and bucket_start = day_start for update;
  day_limit := case provider_code when 'twelve_data' then 800 else 20 end;
  if day_used + requested_cost > greatest(0, day_limit - requested_reserve) then
    return query select false, day_start + interval '1 day';
    return;
  end if;

  if provider_code = 'twelve_data' then
    insert into private.price_provider_usage_windows values
      (principal_id, requested_slot, 'minute', minute_start, 0, clock_timestamp())
    on conflict do nothing;
    select used_count into minute_used from private.price_provider_usage_windows
    where owner_user_id = principal_id and provider_slot = requested_slot
      and bucket_kind = 'minute' and bucket_start = minute_start for update;
    if minute_used + requested_cost > 8 then
      return query select false, minute_start + interval '1 minute';
      return;
    end if;
    update private.price_provider_usage_windows
    set used_count = used_count + requested_cost, updated_at = clock_timestamp()
    where owner_user_id = principal_id and provider_slot = requested_slot
      and bucket_kind = 'minute' and bucket_start = minute_start;
  end if;

  update private.price_provider_usage_windows
  set used_count = used_count + requested_cost, updated_at = clock_timestamp()
  where owner_user_id = principal_id and provider_slot = requested_slot
    and bucket_kind = 'day' and bucket_start = day_start;
  return query select true, null::timestamptz;
end;
$$;

revoke all on function public.get_price_provider_configurations() from public, anon;
revoke all on function public.save_price_provider_configuration(smallint, text, boolean, smallint, text, text, text) from public, anon;
revoke all on function public.get_price_provider_runtime_credential(smallint) from public, anon, authenticated;
revoke all on function public.set_price_provider_validation_status(smallint, text, timestamptz) from public, anon, authenticated;
revoke all on function public.get_price_provider_runtime_configurations() from public, anon, authenticated;
revoke all on function public.mark_price_provider_configuration_invalid(smallint) from public, anon, authenticated;
revoke all on function public.consume_price_provider_quota(smallint, integer, integer) from public, anon, authenticated;

grant execute on function public.get_price_provider_configurations() to authenticated;
grant execute on function public.save_price_provider_configuration(smallint, text, boolean, smallint, text, text, text) to authenticated;
grant execute on function public.get_price_provider_runtime_credential(smallint) to service_role;
grant execute on function public.set_price_provider_validation_status(smallint, text, timestamptz) to service_role;
grant execute on function public.get_price_provider_runtime_configurations() to service_role;
grant execute on function public.mark_price_provider_configuration_invalid(smallint) to service_role;
grant execute on function public.consume_price_provider_quota(smallint, integer, integer) to service_role;

comment on column public.price_provider_configurations.display_name is
  'Free user-facing provider name. The nullable provider column remains the supported runtime adapter.';
comment on function public.get_price_provider_runtime_credential(smallint) is
  'Returns one supported provider credential only to the server service role for validation.';
comment on function public.set_price_provider_validation_status(smallint, text, timestamptz) is
  'Records a server-side credential test result without exposing the secret.';

commit;
