-- LOCAL CANDIDATE: no runtime timeout/RLS/ACL change. Existing 000002 stays intact.
-- Validator-only work_mem=16MB bounds each executor node; resets on return/error.
-- Restore's existing advisory/table locks serialize this path. No global setting.
begin;set local lock_timeout='5s';set local statement_timeout='45s';
do $$begin
 if md5(pg_get_functiondef('private.app_backup_validate(jsonb)'::regprocedure))<>'729e8deff24324b5c45b34d9d216ef29'
 or md5(pg_get_functiondef('private.app_backup_replace(jsonb,text)'::regprocedure))<>'78a5f0a89dadc6227eb2b12ce3e523b6' then raise exception 'Backup function drift; requalify';end if;
end$$;
create or replace function private.app_backup_validate(doc jsonb)
returns void language plpgsql security definer set search_path='' set timezone='UTC' set datestyle='ISO,YMD' set work_mem='16MB' as $function$
declare d record; col text; cell jsonb; objects jsonb; forced_bytes bigint; owned boolean; collision boolean;
 asset_ids text[]; sector_ids text[]; owner_sql text; cast_sql text;
begin
 if public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 if jsonb_typeof(doc) is distinct from 'object' or (select array_agg(k order by k) from jsonb_object_keys(doc) k) is distinct from array['datasets','format','owner','preferences','schema']::text[]
 or doc->>'format' is distinct from 'monpatrimoine-app-backup/3' or doc->>'owner' is distinct from auth.uid()::text or doc->>'schema' is distinct from private.app_backup_schema() then raise exception 'Incompatible archive or owner';end if;
 if jsonb_typeof(doc->'datasets') is distinct from 'object' or (select array_agg(k order by k) from jsonb_object_keys(doc->'datasets') k) is distinct from (select array_agg(name order by name) from private.app_backup_datasets) then raise exception 'Unexpected dataset';end if;
 if jsonb_typeof(doc->'preferences') is distinct from 'object' or (select array_agg(k order by k) from jsonb_object_keys(doc->'preferences') k) is distinct from array['interface_preferences','preferences','strategy_parameters']::text[] then raise exception 'Identity/secret preferences forbidden';end if;
 for col,cell in select * from jsonb_each(doc->'preferences') loop
  if jsonb_typeof(cell) is distinct from 'string' or jsonb_typeof((cell#>>'{}')::jsonb) is distinct from 'object' then raise exception 'Invalid preferences';end if;
 end loop;
 select array_agg(r->>((array_position((select columns from private.app_backup_datasets where name='assets'),'id'))-1)) into asset_ids from jsonb_array_elements(doc#>'{datasets,assets,rows}') r;
 select array_agg(r->>((array_position((select columns from private.app_backup_datasets where name='sectors'),'id'))-1)) into sector_ids from jsonb_array_elements(doc#>'{datasets,sectors,rows}') r;
 for d in select * from private.app_backup_datasets order by ordinal loop
  if jsonb_typeof(doc#>array['datasets',d.name]) is distinct from 'object' or doc#>array['datasets',d.name,'columns'] is distinct from to_jsonb(d.columns)
   or (select array_agg(k order by k) from jsonb_object_keys(doc#>array['datasets',d.name]) k) is distinct from array['columns','rows']::text[]
   or jsonb_typeof(doc#>array['datasets',d.name,'rows']) is distinct from 'array' then raise exception 'Unexpected columns or rows';end if;
  if exists(select 1 from jsonb_array_elements(doc#>array['datasets',d.name,'rows']) r where case when jsonb_typeof(r.value)='array' then jsonb_array_length(r.value)<>cardinality(d.columns) else true end) then raise exception 'Invalid row';end if;
  if exists(select 1 from jsonb_array_elements(doc#>array['datasets',d.name,'rows']) r cross join lateral jsonb_array_elements(r.value) with ordinality t(cell,i)
    where jsonb_typeof(t.cell) not in('string','null') or (d.columns[i] in('user_id','owner_user_id','created_by') and t.cell<>'null'::jsonb and t.cell#>>'{}'<>auth.uid()::text)) then raise exception 'Text/null cells or ownership invalid';end if;
  select coalesce(jsonb_agg(x.obj order by r.ord),'[]'::jsonb) into objects
  from jsonb_array_elements(doc#>array['datasets',d.name,'rows']) with ordinality r(cells,ord)
  cross join lateral(select jsonb_object_agg(c,r.cells->(i-1)::int) obj from unnest(d.columns) with ordinality t(c,i))x;
  owner_sql:=case when d.shared then 'true' when d.name='sector_activities' then 'x.sector_id::text=any($3)'
   when d.name in('asset_prices','asset_sector_exposures','asset_activity_exposures','asset_geography_exposures','asset_theme_exposure_sets','asset_theme_exposures','asset_exposure_versions') then 'x.asset_id::text=any($2)' else d.predicate end;
  cast_sql:=private.app_backup_typed_rows(d.relation);
  -- The consumed aggregate forces EVERY native cast, including non-PK/shared columns.
  -- to_jsonb(x) consumes the whole typed row; the aggregate cannot prune non-PK casts.
  execute format('with typed as (%s) select coalesce(sum(octet_length(to_jsonb(x)::text)),0),coalesce(bool_and((%s) is true),true) from typed x',cast_sql,owner_sql)
   into forced_bytes,owned using objects,asset_ids,sector_ids;
  if owned is not true then raise exception 'Row outside owned scope';end if;
  if not d.shared then
   execute format('select case when exists(select 1 from %s r where (%s) is not true) then exists(select 1 from (%s) x join (select * from %s r where (%s) is not true) r on %s) else false end',d.relation,d.predicate,cast_sql,d.relation,d.predicate,
     (select string_agg(format('r.%I=x.%I',c,c),' and ') from unnest(d.primary_columns)c)) into collision using objects;
   if collision then raise exception 'Foreign primary key collision';end if;
  end if;
 end loop;
end$function$;
CREATE OR REPLACE FUNCTION private.app_backup_replace(doc jsonb, expected_digest text)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
 SET "TimeZone" TO 'UTC'
 SET "DateStyle" TO 'ISO,YMD'
AS $function$
declare d record; col text; cells jsonb; obj jsonb; objects jsonb; cols text; updates text; pk text; current_doc jsonb; begin
 perform pg_advisory_xact_lock(hashtextextended('envelope-tax-schedule',0));
 -- Operator only: there is deliberately no application/browser grant.
 if public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 if doc->>'owner' is distinct from auth.uid()::text then raise exception 'Incompatible archive or owner';end if;
 -- Serializes *all* ordinary DML, including writers unaware of advisory locks.
 for d in select distinct relation::text as name from private.app_backup_datasets order by name loop execute 'lock table '||d.name||' in share row exclusive mode';end loop;
 lock table public.profiles in share row exclusive mode;
 current_doc:=private.app_backup_snapshot();
 if encode(extensions.digest(current_doc::text,'sha256'),'hex') is distinct from expected_digest then raise exception 'Concurrent state changed' using errcode='40001';end if;
 for d in select * from private.app_backup_datasets where shared loop
  if current_doc#>array['datasets',d.name] is distinct from doc#>array['datasets',d.name] then raise exception 'Shared reference changed: %',d.name using errcode='PBR02';end if;
 end loop;
 perform private.app_backup_validate(doc);
 -- Typed private staging. No archive-supplied table, SQL or path is executed.
 create temporary table app_restore_input(name text primary key,objects jsonb) on commit drop;
 for d in select * from private.app_backup_datasets where not shared order by ordinal loop
  select coalesce(jsonb_agg(x.obj order by r.ord),'[]'::jsonb) into objects
  from jsonb_array_elements(doc#>array['datasets',d.name,'rows']) with ordinality r(cells,ord)
  cross join lateral (select jsonb_object_agg(c,r.cells->(i-1)::int) as obj
    from unnest(d.columns) with ordinality t(c,i)) x;
  insert into app_restore_input values(d.name,objects);
 end loop;
 -- Row permits cannot be manufactured by authenticated/service_role callers.
 for d in select * from private.app_backup_datasets where not shared order by ordinal desc loop
  -- Keep surviving root/reference identities so excluded operational rows are
  -- not cascade-deleted. Children are fully replaced; constraints stay active.
  if d.name in('assets','contracts','sectors','sector_activities','themes','fiscal_regimes','fiscal_rules') then
   execute format('insert into private.app_restore_permits select txid_current(),pg_backend_pid(),%s,''DELETE'',to_jsonb(r),null from %s r where %s and not exists(select 1 from (%s) x where x.id=r.id)',d.relation::oid,d.relation,d.predicate,private.app_backup_typed_rows(d.relation)) using (select a.objects from app_restore_input a where name=d.name);
  else
   execute format('insert into private.app_restore_permits select txid_current(),pg_backend_pid(),%s,''DELETE'',to_jsonb(r),null from %s r where %s',d.relation::oid,d.relation,d.predicate);
  end if;
  execute format('delete from %s r where %s and public.app_restore_permitted(%s,''DELETE'',to_jsonb(r),null)',d.relation,d.predicate,d.relation::oid);
 end loop;
 for d in select * from private.app_backup_datasets where not shared order by ordinal loop
  select a.objects into objects from app_restore_input a where name=d.name;
  cols:=(select string_agg(quote_ident(c),',') from unnest(d.columns) c);
  pk:=(select string_agg(quote_ident(c),',') from unnest(d.primary_columns) c);
  updates:=(select string_agg(format('%I=excluded.%I',c,c),',') from unnest(d.columns) c where not c=any(d.primary_columns));
  -- Compute exact UPDATE/INSERT permits against the current surviving rows.
  execute format('insert into private.app_restore_permits select txid_current(),pg_backend_pid(),%s,''INSERT'',null,to_jsonb(x) from (%s) x',d.relation::oid,private.app_backup_typed_rows(d.relation)) using objects;
  execute format('insert into private.app_restore_permits select txid_current(),pg_backend_pid(),%s,''UPDATE'',to_jsonb(r),to_jsonb(x) from (%s) x join %s r on %s',d.relation::oid,private.app_backup_typed_rows(d.relation),d.relation,(select string_agg(format('r.%I=x.%I',c,c),' and ') from unnest(d.primary_columns) c)) using objects;
  execute format('insert into %s(%s) select %s from (%s) x on conflict(%s) %s',d.relation,cols,cols,private.app_backup_typed_rows(d.relation),pk,case when updates is null then 'do nothing' else 'do update set '||updates end) using objects;
 end loop;
 update public.profiles set preferences=(doc#>>'{preferences,preferences}')::jsonb,interface_preferences=(doc#>>'{preferences,interface_preferences}')::jsonb,strategy_parameters=(doc#>>'{preferences,strategy_parameters}')::jsonb where auth_user_id=auth.uid();
 set constraints all immediate; insert into private.allocation_write_guards as g(user_id,revision) values(auth.uid(),1) on conflict(user_id) do update set revision=g.revision+1;
 if private.app_backup_snapshot() is distinct from doc then raise exception 'Canonical restored content differs';end if;
 delete from private.app_restore_permits where tx=txid_current() and backend=pg_backend_pid();
 return encode(extensions.digest(doc::text,'sha256'),'hex');
end$function$
;
commit;
