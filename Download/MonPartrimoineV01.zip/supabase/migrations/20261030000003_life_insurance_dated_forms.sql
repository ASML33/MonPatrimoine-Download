-- Local candidate only. Existing metadata/snapshot datasets retain all versions.
begin;
set local lock_timeout='5s';
set local statement_timeout='45s';
do $$begin
 if private.app_backup_schema()<>'e3f63a4322f4ebf7892e0dc0626a7175d290110a652b3394e4c12ee0baaf3f3b' then raise exception 'AV predecessor drift';end if;
end$$;

create function public.save_life_insurance_amount(requested_position uuid,requested_request uuid,expected_revision timestamptz,requested_date date,requested_amount numeric,requested_currency text)
returns uuid language plpgsql security definer set search_path='' as $$
declare p public.positions;c public.contracts;a public.assets;payload jsonb;prior jsonb;replaced jsonb;stamp timestamptz:=clock_timestamp();
begin
 if auth.uid() is null or public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 select * into p from public.positions where id=requested_position and user_id=auth.uid();
 select * into c from public.contracts where id=p.contract_id and user_id=auth.uid() for update;
 select * into p from public.positions where id=requested_position and user_id=auth.uid() for update;
 perform public.lock_amount_tracking_asset(p.asset_id);
 lock table public.position_snapshots in share row exclusive mode;
 select * into a from public.assets where id=p.asset_id and owner_user_id=auth.uid() for share;
 if p.id is null or c.id is null or a.id is null or not p.is_active or not c.is_active or c.valuation_source<>'positions'
 or not exists(select 1 from public.envelope_types where id=c.envelope_type_id and code='assurance_vie')
 or a.asset_type_code<>'fund' or a.valuation_mode<>'manual'
 -- Same native monetary boundary as 20261026000001: imported total snapshots
 -- may retain unit_price. Active prices and dated unit holdings remain excluded.
 or not (coalesce(p.metadata#>>'{initial_amount,version}'='1',false) or exists(select 1 from public.position_snapshots where position_id=p.id))
 or p.metadata ? 'position_observations' or p.metadata ? 'property_valuations'
 or exists(select 1 from public.asset_prices where asset_id=a.id)
 then raise exception 'Native euro fund required' using errcode='23514';end if;
 if requested_request is null then raise exception 'Request required' using errcode='22023';end if;
 payload:=jsonb_build_array(expected_revision,requested_date,requested_amount,requested_currency);
 prior:=p.metadata#>array['av_amount_requests',requested_request::text];
 if prior is not null then if prior is distinct from payload then raise exception 'AV-REPLAY' using errcode='40001';end if;return requested_request;end if;
 if p.updated_at is distinct from expected_revision then raise exception 'AV-STALE' using errcode='40001';end if;
 if requested_date is null or requested_date<c.opened_on or requested_date>c.closed_on or requested_date>(stamp at time zone 'Europe/Paris')::date
 or requested_amount is null or requested_amount<0 or requested_amount>=1e16 or requested_amount<>round(requested_amount,8)
 or not exists(select 1 from public.currencies where code=requested_currency and is_active)
 then raise exception 'AV-VALUES' using errcode='22023';end if;
 if jsonb_typeof(coalesce(p.metadata->'amount_observation_audit','[]'))<>'array' then raise exception 'Invalid audit' using errcode='23514';end if;
 select coalesce(jsonb_agg(to_jsonb(s) order by s.valued_at,s.id),'[]') into replaced from public.position_snapshots s
 where position_id=p.id and user_id=auth.uid() and (valued_at at time zone 'Europe/Paris')::date>=requested_date;
 delete from public.position_snapshots where position_id=p.id and user_id=auth.uid() and (valued_at at time zone 'Europe/Paris')::date>=requested_date;
 insert into public.position_snapshots(id,user_id,position_id,valued_at,quantity,unit_price,market_value,currency_code)
 values(requested_request,auth.uid(),p.id,(requested_date+time '00:00') at time zone 'Europe/Paris',p.quantity,null,requested_amount,requested_currency);
 update public.positions set metadata=metadata||jsonb_build_object(
 'amount_observation_audit',coalesce(metadata->'amount_observation_audit','[]')||jsonb_build_array(jsonb_build_object('operation','replace_forward','date',requested_date,'before',replaced,'after',(select to_jsonb(s) from public.position_snapshots s where id=requested_request),'recordedAt',stamp)),
 'av_amount_requests',coalesce(metadata->'av_amount_requests','{}')||jsonb_build_object(requested_request::text,payload)) where id=p.id and user_id=auth.uid();
 return requested_request;
end$$;
revoke all on function public.save_life_insurance_amount(uuid,uuid,timestamptz,date,numeric,text) from public,anon;
grant execute on function public.save_life_insurance_amount(uuid,uuid,timestamptz,date,numeric,text) to authenticated;

create function public.save_life_insurance_cumulative(requested_contract uuid,requested_request uuid,expected_revision timestamptz,requested_date date,requested_amount numeric)
returns uuid language plpgsql security definer set search_path='' as $$
declare c public.contracts;h jsonb;payload jsonb;prior jsonb;entry jsonb;stamp timestamptz:=clock_timestamp();
begin
 if auth.uid() is null or public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 select * into c from public.contracts where id=requested_contract and user_id=auth.uid() for update;
 if c.id is null or not exists(select 1 from public.envelope_types where id=c.envelope_type_id and code='assurance_vie') then raise exception 'Unauthorized AV' using errcode='42501';end if;
 if requested_request is null then raise exception 'Request required' using errcode='22023';end if;
 payload:=jsonb_build_array(expected_revision,requested_date,requested_amount);
 prior:=c.metadata#>array['securities_contribution_requests',requested_request::text];
 if prior is not null then if prior is distinct from payload then raise exception 'AV-REPLAY' using errcode='40001';end if;return requested_request;end if;
 if c.updated_at is distinct from expected_revision then raise exception 'AV-STALE' using errcode='40001';end if;
 if not c.is_active or requested_date is null or requested_date<c.opened_on or requested_date>c.closed_on or requested_date>(stamp at time zone 'Europe/Paris')::date
 or requested_amount is null or requested_amount<0 or requested_amount>=1e16 or requested_amount<>round(requested_amount,2) then raise exception 'AV-VALUES' using errcode='22023';end if;
 h:=coalesce(c.metadata->'securities_contribution_corrections','{"version":1,"entries":[],"archived":[]}');
 if h->>'version' is distinct from '1' or jsonb_typeof(h->'entries') is distinct from 'array' or jsonb_typeof(h->'archived') is distinct from 'array' then raise exception 'Invalid cumulative history' using errcode='23514';end if;
 entry:=jsonb_build_object('id',requested_request,'date',requested_date,'amount',requested_amount::text,'order',coalesce((select max((e->>'order')::bigint) from jsonb_array_elements((h->'entries')||(h->'archived'))e),0)+1,'recordedAt',stamp,'flowIds',coalesce((select jsonb_agg(id order by id) from public.cash_flows where user_id=auth.uid() and destination_contract_id=c.id and kind='contribution'),'[]'));
 h:=jsonb_build_object('version',1,'entries',coalesce((select jsonb_agg(e order by e->>'date') from jsonb_array_elements(h->'entries')e where (e->>'date')::date<requested_date),'[]')||jsonb_build_array(entry),'archived',(h->'archived')||coalesce((select jsonb_agg(e) from jsonb_array_elements(h->'entries')e where (e->>'date')::date>=requested_date),'[]'));
 update public.contracts set metadata=metadata||jsonb_build_object('securities_contribution_corrections',h,'securities_contribution_requests',coalesce(metadata->'securities_contribution_requests','{}')||jsonb_build_object(requested_request::text,payload)) where id=c.id and user_id=auth.uid();
 return requested_request;
end$$;
revoke all on function public.save_life_insurance_cumulative(uuid,uuid,timestamptz,date,numeric) from public,anon;
grant execute on function public.save_life_insurance_cumulative(uuid,uuid,timestamptz,date,numeric) to authenticated;

create function public.add_life_insurance_flow(requested_contract uuid,requested_request uuid,requested_date date,requested_kind text,requested_amount numeric,requested_currency text,requested_note text)
returns uuid language plpgsql security definer set search_path='' as $$
declare c public.contracts;prior public.cash_flows;instant timestamptz;rate uuid;
begin
 if auth.uid() is null or public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 select * into c from public.contracts where id=requested_contract and user_id=auth.uid() for update;
 if c.id is null or not c.is_active or not exists(select 1 from public.envelope_types where id=c.envelope_type_id and code='assurance_vie') then raise exception 'Unauthorized AV' using errcode='42501';end if;
 if requested_request is null or requested_date is null or requested_date<c.opened_on or requested_date>c.closed_on or requested_date>(clock_timestamp() at time zone 'Europe/Paris')::date
 or requested_kind is null or requested_kind not in('contribution','withdrawal') or requested_amount is null or requested_amount<=0 or requested_amount>=1e16 or requested_amount<>round(requested_amount,8)
 or not exists(select 1 from public.currencies where code=requested_currency and is_active) or length(requested_note)>500 then raise exception 'AV-VALUES' using errcode='22023';end if;
 instant:=(requested_date+time '00:00') at time zone 'Europe/Paris';
 select * into prior from public.cash_flows where id=requested_request;
 if found then
 if prior.user_id is distinct from auth.uid() or coalesce(prior.destination_contract_id,prior.source_contract_id) is distinct from c.id
 or prior.kind::text is distinct from requested_kind or prior.amount is distinct from requested_amount or prior.currency_code is distinct from requested_currency
 or prior.occurred_at is distinct from instant or prior.note is distinct from requested_note then raise exception 'AV-REPLAY' using errcode='40001';end if;
 return prior.id;
 end if;
 select id into rate from public.fx_rates where currency_code=requested_currency and requested_on=requested_date order by (source::text='manual'),source,obtained_at desc limit 1;
 insert into public.cash_flows(id,user_id,kind,destination_contract_id,source_contract_id,amount,currency_code,occurred_at,note,fx_rate_id,fx_status)
 values(requested_request,auth.uid(),requested_kind::public.cash_flow_kind,case when requested_kind='contribution' then c.id end,case when requested_kind='withdrawal' then c.id end,requested_amount,requested_currency,instant,requested_note,rate,(case when requested_currency='EUR' or rate is not null then 'resolved' else 'pending' end)::public.fx_resolution_status);
 return requested_request;
end$$;
revoke all on function public.add_life_insurance_flow(uuid,uuid,date,text,numeric,text,text) from public,anon;
grant execute on function public.add_life_insurance_flow(uuid,uuid,date,text,numeric,text,text) to authenticated;

create function private.guard_av_history() returns trigger language plpgsql security invoker set search_path='' as $$
begin
 if public.app_restore_permitted(tg_relid,tg_op,to_jsonb(old),to_jsonb(new)) then return new;end if;
 if current_user='authenticated' then
 if tg_table_name='contracts' and new.metadata->'form_creation_receipt' is distinct from old.metadata->'form_creation_receipt' then raise exception 'Creation receipt is immutable' using errcode='42501';end if;
 if tg_table_name='positions' and exists(select 1 from public.contracts c join public.envelope_types t on t.id=c.envelope_type_id where c.id=(to_jsonb(new)->>'contract_id')::uuid and t.code='assurance_vie') and (new.metadata->'av_amount_requests' is distinct from old.metadata->'av_amount_requests' or new.metadata->'amount_observation_audit' is distinct from old.metadata->'amount_observation_audit') then raise exception 'AV history is server managed' using errcode='42501';end if;
 if tg_table_name='contracts' and exists(select 1 from public.envelope_types where id=old.envelope_type_id and code='assurance_vie') and (new.metadata->'securities_contribution_corrections' is distinct from old.metadata->'securities_contribution_corrections' or new.metadata->'securities_contribution_requests' is distinct from old.metadata->'securities_contribution_requests') then raise exception 'AV history is server managed' using errcode='42501';end if;
 end if;
 return new;
end$$;
revoke all on function private.guard_av_history() from public,anon,authenticated;
create trigger positions_av_history before update on public.positions for each row execute function private.guard_av_history();
create trigger contracts_av_history before update on public.contracts for each row execute function private.guard_av_history();

-- Same datasets/columns; accept only the exact delivered predecessor. No rows
-- or versions are inferred during upgrade. Qualify the encrypted cycle locally.
do $$declare s text;needle text:='if doc->>''schema''=private.app_backup_schema()then';begin
 s:=pg_get_functiondef('private.app_backup_upgrade(jsonb)'::regprocedure);
 if strpos(s,needle)=0 then raise exception 'Unexpected archive upgrade source';end if;
 execute replace(s,needle,$frontier$if doc->>'format'='monpatrimoine-app-backup/3' and doc->>'schema'='e3f63a4322f4ebf7892e0dc0626a7175d290110a652b3394e4c12ee0baaf3f3b' then
 doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));
 end if;
 if doc->>'schema'=private.app_backup_schema()then$frontier$);
end$$;
do $$declare s text;begin
 s:=pg_get_functiondef('private.empty_automatic_euro_fund(public.contracts)'::regprocedure);
 if strpos(s,'or c.metadata is distinct from')=0 then raise exception 'Unexpected empty fund guard';end if;
 execute replace(s,'or c.metadata is distinct from','or (c.metadata - ''form_creation_receipt'') is distinct from');
end$$;
do $$declare s text;needle text:=' if expected_token is distinct from token then';begin
 s:=pg_get_functiondef('public.edit_amount_observation(uuid,uuid,date,numeric,text,text,text,boolean)'::regprocedure);
 if strpos(s,needle)=0 then raise exception 'Unexpected amount source';end if;
 execute replace(s,needle,$guard$
 if exists(select 1 from public.envelope_types where id=c.envelope_type_id and code='assurance_vie')then raise exception 'AV-RELOAD: use direct dated valuation'using errcode='40001';end if;
 if expected_token is distinct from token then$guard$);
end$$;
notify pgrst,'reload schema';
commit;
