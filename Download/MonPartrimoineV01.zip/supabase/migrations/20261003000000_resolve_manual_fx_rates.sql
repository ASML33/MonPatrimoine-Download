begin;

create or replace function public.save_manual_fx_rate(
  requested_currency text,
  requested_date date,
  requested_observed_on date,
  requested_eur_per_unit numeric,
  requested_metadata jsonb default '{}'::jsonb
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  result_id uuid;
  normalized_currency text := upper(btrim(requested_currency));
  principal_id uuid := auth.uid();
begin
  if not public.is_authorized_user() or requested_eur_per_unit <= 0
     or requested_date > current_date or requested_observed_on > requested_date
     or coalesce(jsonb_typeof(requested_metadata), 'null') <> 'object'
     or not exists(select 1 from public.currencies c where c.code = normalized_currency and c.is_active) then
    raise exception 'Invalid manual FX rate' using errcode = '22023';
  end if;
  if normalized_currency = 'EUR' then
    raise exception 'EUR does not require an FX rate' using errcode = '22023';
  end if;

  insert into public.fx_rates(currency_code, requested_on, observed_on, eur_per_unit, source, provider_metadata)
    values(normalized_currency, requested_date, requested_observed_on, requested_eur_per_unit, 'manual', requested_metadata)
    returning id into result_id;

  update public.cash_flows f
    set fx_rate_id = result_id,
        fx_status = 'resolved'
    where f.user_id = principal_id
      and f.currency_code = normalized_currency
      and f.fx_rate_id is null
      and f.fx_status in ('pending', 'manual_required')
      and (f.occurred_at at time zone 'Europe/Paris')::date = requested_date;

  return result_id;
end;
$$;
revoke all on function public.save_manual_fx_rate(text,date,date,numeric,jsonb) from public, anon;
grant execute on function public.save_manual_fx_rate(text,date,date,numeric,jsonb) to authenticated;

create or replace function public.guard_cash_balance_phase74()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'UPDATE' and (new.id is distinct from old.id or new.user_id is distinct from old.user_id
     or new.contract_id is distinct from old.contract_id) then
    raise exception 'Cash balance identity is immutable' using errcode = '23514';
  end if;
  if new.as_of > clock_timestamp() then
    raise exception 'Cash balance date cannot be in the future' using errcode = '23514';
  end if;
  if not exists(select 1 from public.currencies c where c.code = new.currency_code and c.is_active) then
    raise exception 'Unsupported currency' using errcode = '23514';
  end if;
  return new;
end;
$$;
revoke all on function public.guard_cash_balance_phase74() from public, anon, authenticated;

commit;
