begin;
create or replace function public.delete_sector(requested_id uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 perform private.assert_analysis_catalog_access();
 perform 1 from public.sectors where id=requested_id and owner_user_id=auth.uid() for update;
 if not found then raise exception 'Only a personal sector can be deleted' using errcode='42501'; end if;
 if exists(select 1 from public.asset_sector_exposures where sector_id=requested_id)
 or exists(select 1 from public.asset_activity_exposures e join public.sector_activities a on a.id=e.activity_id where a.sector_id=requested_id)
 or exists(select 1 from public.sector_activities where sector_id=requested_id and has_been_used)
 then raise exception 'Sector is referenced' using errcode='23503'; end if;
 delete from public.sector_activities where sector_id=requested_id;
 delete from public.sectors where id=requested_id and owner_user_id=auth.uid();
end $$;
commit;
