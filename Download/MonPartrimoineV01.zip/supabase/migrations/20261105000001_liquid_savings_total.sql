-- Local candidate. One absolute EUR total replaces all earlier currency components
-- from the effective civil date; prior observations and captures remain intact.
begin;
-- Serialize every cash mutation for liquid contracts with the total writer,
-- including insertion of a currency that did not exist when it read revisions.
-- An older path that locked a cash row first may instead receive a deadlock
-- error; PostgreSQL then rolls that entire transaction back.
create function public.lock_liquid_savings_cash_parent()
returns trigger language plpgsql security definer set search_path='' as $$
begin
 perform c.id from public.contracts c join public.envelope_types t on t.id=c.envelope_type_id
 where t.code='epargne_liquide' and c.id in (case when tg_op<>'INSERT' then old.contract_id end, case when tg_op<>'DELETE' then new.contract_id end)
 order by c.id for update of c;
 if tg_op='DELETE' then return old; end if;
 return new;
end$$;
revoke all on function public.lock_liquid_savings_cash_parent() from public,anon,authenticated;
create trigger cash_balances_14_liquid_parent before insert or update or delete on public.cash_balances for each row execute function public.lock_liquid_savings_cash_parent();
-- The retirement marker changes the selected history. Only the narrowly
-- scoped RPC below may write it; regular client writes cannot forge it.
create function public.guard_liquid_savings_retirement()
returns trigger language plpgsql security invoker set search_path='' as $$
begin
 -- An old tab/API can begin before the total is saved and wait on the
 -- parent lock. Once that lock is released it must not add another currency
 -- or rewrite the journal behind the total writer's revision check.
 if current_user='authenticated' and exists (
   select 1 from public.cash_balances b
   join public.contracts c on c.id=b.contract_id
   join public.envelope_types t on t.id=c.envelope_type_id
   where t.code='epargne_liquide'
     and b.contract_id in (case when tg_op<>'INSERT' then old.contract_id end,case when tg_op<>'DELETE' then new.contract_id end)
     and b.metadata->'cash_balance_corrections' @> '[{"kind":"liquid_savings_total"}]'::jsonb
 ) then raise exception 'Liquid savings total must be changed through its total writer' using errcode='40001'; end if;
 if tg_op='DELETE' then return old; end if;
 if current_user='authenticated' and (case when tg_op='INSERT' then new.metadata ? 'liquid_savings_retired_from' else new.metadata->'liquid_savings_retired_from' is distinct from old.metadata->'liquid_savings_retired_from' end) then
   raise exception 'Liquid savings retirement is server managed' using errcode='42501';
 end if;
 return new;
end$$;
revoke all on function public.guard_liquid_savings_retirement() from public,anon,authenticated;
create trigger cash_balances_15_liquid_retirement before insert or update or delete on public.cash_balances for each row execute function public.guard_liquid_savings_retirement();
create function public.save_liquid_savings_total(requested_contract uuid, requested_date date, requested_amount numeric, expected_balances jsonb)
returns uuid language plpgsql security definer set search_path='' as $$
declare
 actor uuid:=auth.uid(); b public.cash_balances; contract_row public.contracts;
 actual jsonb; expected jsonb; prior jsonb; kept jsonb; archives jsonb; meta jsonb;
 after_entry jsonb; latest jsonb; stamp timestamptz:=clock_timestamp(); effective_at timestamptz;
 result_id uuid; old_cut date;
begin
 if actor is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501'; end if;
 if requested_date is null or requested_date>(stamp at time zone 'Europe/Paris')::date or requested_amount is null or requested_amount<0 or requested_amount>=1e16 or requested_amount<>round(requested_amount,8) or jsonb_typeof(expected_balances) is distinct from 'array' then raise exception 'Invalid liquid savings total' using errcode='22023'; end if;
 select c.* into contract_row from public.contracts c join public.envelope_types t on t.id=c.envelope_type_id where c.id=requested_contract and c.user_id=actor and t.code='epargne_liquide' for update of c;
 if not found then raise exception 'Contract unavailable' using errcode='42501'; end if;
 if not contract_row.is_active then raise exception 'Inactive contract' using errcode='23514'; end if;
 perform 1 from public.cash_balances where contract_id=requested_contract and user_id=actor order by id for update;
 select coalesce(jsonb_agg(jsonb_build_array(id,updated_at) order by id),'[]'::jsonb) into actual from public.cash_balances where contract_id=requested_contract and user_id=actor;
 select coalesce(jsonb_agg(jsonb_build_array((v->>'id')::uuid,(v->>'updatedAt')::timestamptz) order by (v->>'id')::uuid),'[]'::jsonb) into expected from jsonb_array_elements(expected_balances) v;
 if actual is distinct from expected then raise exception 'Concurrent observation update' using errcode='40001'; end if;
 effective_at:=requested_date::timestamp at time zone 'Europe/Paris';
 after_entry:=jsonb_build_object('amount',requested_amount::text,'currencyCode','EUR','asOf',effective_at,'recordedAt',stamp);
 for b in select * from public.cash_balances where contract_id=requested_contract and user_id=actor order by id loop
   prior:=coalesce(b.metadata#>'{cash_balance_observations,entries}',jsonb_build_array(jsonb_build_object('amount',b.amount::text,'currencyCode',btrim(b.currency_code),'asOf',b.as_of,'recordedAt',b.updated_at)));
   select coalesce(jsonb_agg(value order by (value->>'asOf')::timestamptz),'[]'::jsonb) into kept from jsonb_array_elements(prior) where ((value->>'asOf')::timestamptz at time zone 'Europe/Paris')::date<requested_date;
   if btrim(b.currency_code)='EUR' then kept:=kept||jsonb_build_array(after_entry); result_id:=b.id; end if;
   archives:=coalesce(b.metadata#>'{cash_balance_observations,archived}','[]'::jsonb)||jsonb_build_array(jsonb_build_object('entries',prior,'replacedAt',stamp));
   meta:=b.metadata||jsonb_build_object('cash_balance_observations',jsonb_build_object('version',2,'entries',kept,'archived',archives),'cash_balance_corrections',coalesce(b.metadata->'cash_balance_corrections','[]'::jsonb)||jsonb_build_array(jsonb_build_object('kind','liquid_savings_total','submitted',after_entry,'recordedAt',stamp)));
   if btrim(b.currency_code)<>'EUR' then
     old_cut:=nullif(b.metadata#>>'{liquid_savings_retired_from,date}','')::date;
     meta:=meta||jsonb_build_object('liquid_savings_retired_from',jsonb_build_object('version',1,'date',least(coalesce(old_cut,requested_date),requested_date)));
   end if;
   select value into latest from jsonb_array_elements(kept) order by (value->>'asOf')::timestamptz desc limit 1;
   update public.cash_balances set metadata=meta,amount=coalesce((latest->>'amount')::numeric,b.amount),as_of=coalesce((latest->>'asOf')::timestamptz,b.as_of) where id=b.id;
 end loop;
 if result_id is null then
   result_id:=gen_random_uuid();
   insert into public.cash_balances(id,user_id,contract_id,currency_code,amount,as_of,metadata) values(result_id,actor,requested_contract,'EUR',requested_amount,effective_at,jsonb_build_object('cash_balance_observations',jsonb_build_object('version',2,'entries',jsonb_build_array(after_entry),'archived','[]'::jsonb),'cash_balance_corrections',jsonb_build_array(jsonb_build_object('kind','liquid_savings_total','submitted',after_entry,'recordedAt',stamp))));
 end if;
 return result_id;
end$$;
revoke all on function public.save_liquid_savings_total(uuid,date,numeric,jsonb) from public,anon;
grant execute on function public.save_liquid_savings_total(uuid,date,numeric,jsonb) to authenticated;
notify pgrst,'reload schema';
commit;
