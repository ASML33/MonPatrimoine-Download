-- Extend the existing append-only manual ledger. No personal observation copied.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
alter table public.contract_manual_situations add column valuation_revision jsonb;
alter table public.contract_manual_situations add constraint manual_valuation_revision_shape check(valuation_revision is null or (
 valuation_revision->>'version'='1' and jsonb_typeof(valuation_revision->'supersedes')='array'
 and valuation_revision->>'submissionId' ~ '^[a-f0-9-]{36}$' and valuation_revision->>'expectedToken' ~ '^[a-f0-9]{32}$'
 and fiscal_gain_eur is null and source_time_precision='date'));
create unique index manual_valuation_submission on public.contract_manual_situations(user_id,(valuation_revision->>'submissionId')) where valuation_revision is not null;

create function private.employee_savings_candidates(requested_contract uuid) returns jsonb
language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(row order by row->>'ref'),'[]'::jsonb) from (
  select jsonb_build_object('ref','manual:'||s.id,'date',(s.situated_at at time zone 'Europe/Paris')::date,
   'gross',s.gross_eur::text,'net',s.source_net_eur::text,'recordedAt',s.recorded_at,'sourceAt',s.situated_at,
   'revision',s.valuation_revision is not null,'supersedes',coalesce(s.valuation_revision->'supersedes','[]'::jsonb)) row
  from public.contract_manual_situations s where s.contract_id=requested_contract and s.user_id=auth.uid()
  union all
  select jsonb_build_object('ref','legacy:'||s.id,'date',s.business_date,'gross',s.payload->>'grossEur','net',null,
   'recordedAt',s.imported_at,'sourceAt',s.business_date,'revision',false,'supersedes',case when s.payload->>'replacesSourceId' is null then '[]'::jsonb else jsonb_build_array('legacy:'||(s.payload->>'replacesSourceId')) end)
  from public.patrimonial_legacy_sources s where s.user_id=auth.uid() and s.payload->>'kind'='approved_manual_gross_observation'
   and s.payload->>'contractId'=requested_contract::text
 ) rows;
$$;
create function private.employee_savings_effective(requested_contract uuid) returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare candidates jsonb:=private.employee_savings_candidates(requested_contract); effective jsonb;
begin
 if exists(select 1 from jsonb_array_elements(candidates) e cross join lateral jsonb_array_elements_text(e->'supersedes') r(ref)
  where not exists(select 1 from jsonb_array_elements(candidates) p where p->>'ref'=r.ref))
  or exists(select 1 from jsonb_array_elements(candidates) e cross join lateral jsonb_array_elements_text(e->'supersedes') r(ref) group by ref having count(*)>1) then
  raise exception 'Unlinked or competing correction' using errcode='23514';end if;
 select coalesce(jsonb_agg(e order by e->>'date',e->>'ref'),'[]') into effective from jsonb_array_elements(candidates) e
 where not exists(select 1 from jsonb_array_elements(candidates) n where n->'supersedes' ? (e->>'ref'))
 and not (e->>'ref' like 'manual:%' and e->>'revision'='false' and exists(select 1 from jsonb_array_elements(candidates) n
   where n->>'ref' like 'manual:%' and n->>'revision'='false' and n->>'date'=e->>'date'
    and (n->>'sourceAt',n->>'recordedAt',n->>'ref')>(e->>'sourceAt',e->>'recordedAt',e->>'ref')));
 if exists(select 1 from jsonb_array_elements(effective) e group by e->>'date' having count(*)>1) then
  raise exception 'Concurrent individual authorities' using errcode='23514';end if;
 return effective;
end $$;

create function public.preview_employee_savings_value(requested_contract uuid,requested_edited_ref text,requested_date date,requested_gross numeric,requested_net numeric)
returns jsonb language plpgsql security definer set search_path='' as $$
declare actor uuid:=auth.uid(); c public.contracts; entries jsonb; edited jsonb; destination jsonb; supersedes jsonb; token text; future_individual date;
begin
 if actor is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 select contracts.* into c from public.contracts join public.envelope_types t on t.id=contracts.envelope_type_id
 where contracts.id=requested_contract and contracts.user_id=actor and contracts.is_active and contracts.currency_code='EUR'
 and contracts.valuation_source='manual_situation' and t.code in ('peg','per_col');
 if not found then raise exception 'Manual contract unavailable' using errcode='42501';end if;
 if requested_date is null or not isfinite(requested_date) or requested_date>(clock_timestamp() at time zone 'Europe/Paris')::date
  or c.opened_on is not null and requested_date<c.opened_on or requested_gross is null or requested_gross<0 or requested_gross>=1e15
  or requested_gross::text in ('NaN','Infinity','-Infinity') or requested_gross<>round(requested_gross,2)
  or requested_net<0 or requested_net>=1e15 or requested_net::text in ('NaN','Infinity','-Infinity') or requested_net<>round(requested_net,2)
  or requested_edited_ref is not null and requested_edited_ref !~ '^(manual|legacy):[a-f0-9-]{36}$' then raise exception 'Invalid declared value' using errcode='23514';end if;
 entries:=private.employee_savings_effective(requested_contract);
 if requested_edited_ref is not null then
  select e into edited from jsonb_array_elements(entries) e where e->>'ref'=requested_edited_ref;
  if edited is null then raise exception 'Edited observation unavailable' using errcode='40001';end if;
 end if;
 select e into destination from jsonb_array_elements(entries) e where e->>'date'=requested_date::text and e->>'ref' is distinct from requested_edited_ref;
 select coalesce(jsonb_agg(ref order by ref),'[]') into supersedes from (select edited->>'ref' ref where edited is not null union select destination->>'ref' where destination is not null) r;
 token:=md5(jsonb_build_object('actor',actor,'contract',to_jsonb(c),'entries',private.employee_savings_candidates(requested_contract),
  'date',requested_date,'gross',requested_gross::numeric(24,2)::text,'net',requested_net::numeric(24,2)::text,'edited',requested_edited_ref)::text);
 select min((e->>'date')::date) into future_individual from jsonb_array_elements(entries) e where e->>'date'>requested_date::text and not (supersedes ? (e->>'ref'));
 return jsonb_build_object('token',token,'edited',edited,'destination',destination,'supersedes',supersedes,'nextDate',future_individual,
  'date',requested_date,'gross',to_char(requested_gross,'FM999999999999990.00'),'net',case when requested_net is null then null else to_char(requested_net,'FM999999999999990.00') end,
  'unchanged',case when edited is not null then edited->>'date'=requested_date::text and (edited->>'gross')::numeric=requested_gross and (edited->>'net')::numeric is not distinct from requested_net
   else destination is not null and (destination->>'gross')::numeric=requested_gross and (destination->>'net')::numeric is not distinct from requested_net end);
end $$;

create function public.save_employee_savings_value(requested_contract uuid,requested_edited_ref text,requested_date date,requested_gross numeric,requested_net numeric,expected_token text,requested_submission uuid)
returns uuid language plpgsql security definer set search_path='' as $$
declare plan jsonb; prior public.contract_manual_situations; saved uuid;
begin
 if auth.uid() is null or not public.is_authorized_user() or requested_submission is null then raise exception 'Unauthorized' using errcode='42501';end if;
 perform 1 from public.contracts where id=requested_contract and user_id=auth.uid() for update;
 if not found then raise exception 'Contract unavailable' using errcode='42501';end if;
 lock table public.contract_manual_situations,public.patrimonial_legacy_sources in share row exclusive mode;
 select * into prior from public.contract_manual_situations where user_id=auth.uid() and valuation_revision->>'submissionId'=requested_submission::text;
 if found then
  if prior.contract_id is distinct from requested_contract or (prior.situated_at at time zone 'Europe/Paris')::date is distinct from requested_date
   or prior.gross_eur is distinct from requested_gross or prior.source_net_eur is distinct from requested_net
   or prior.valuation_revision->>'editedRef' is distinct from requested_edited_ref or prior.valuation_revision->>'expectedToken' is distinct from expected_token
   then raise exception 'Submission identity conflict' using errcode='40001';end if;
  return prior.id;
 end if;
 plan:=public.preview_employee_savings_value(requested_contract,requested_edited_ref,requested_date,requested_gross,requested_net);
 if plan->>'token' is distinct from expected_token then raise exception 'Concurrent observation change' using errcode='40001';end if;
 if plan->>'unchanged'='true' then return coalesce((split_part(plan->'edited'->>'ref',':',2))::uuid,(split_part(plan->'destination'->>'ref',':',2))::uuid);end if;
 insert into public.contract_manual_situations(user_id,contract_id,situated_at,gross_eur,fiscal_gain_eur,source_net_eur,source,source_time_precision,valuation_revision)
 values(auth.uid(),requested_contract,requested_date::timestamp at time zone 'Europe/Paris',requested_gross,null,requested_net,
  'Valorisation déclarée manuellement par l’utilisateur','date',jsonb_build_object('version',1,'submissionId',requested_submission,'editedRef',requested_edited_ref,'supersedes',plan->'supersedes','expectedToken',expected_token)) returning id into saved;
 return saved;
end $$;
revoke all on function private.employee_savings_candidates(uuid),private.employee_savings_effective(uuid) from public,anon,authenticated;
revoke all on function public.preview_employee_savings_value(uuid,text,date,numeric,numeric),public.save_employee_savings_value(uuid,text,date,numeric,numeric,text,uuid) from public,anon;
grant execute on function public.preview_employee_savings_value(uuid,text,date,numeric,numeric),public.save_employee_savings_value(uuid,text,date,numeric,numeric,text,uuid) to authenticated;
-- Include immutable imported proofs only in future MVCC capture inputs.
-- Already-published captures and their readers keep their archived inputs.
do $$declare original text;changed text;begin
 original:=pg_get_functiondef('private.daily_capture_inputs()'::regprocedure);
 changed:=replace(original,'''manualSituations'',','''employeeSavingsSources'',coalesce((select jsonb_agg(to_jsonb(s)) from public.patrimonial_legacy_sources s where s.user_id=(select auth_user_id from private.application_principal) and s.payload->>''kind''=''approved_manual_gross_observation''),''[]''),''manualSituations'',');
 if changed=original then raise exception 'Unexpected daily input definition';end if;execute changed;
end $$;
notify pgrst,'reload schema';
commit;
