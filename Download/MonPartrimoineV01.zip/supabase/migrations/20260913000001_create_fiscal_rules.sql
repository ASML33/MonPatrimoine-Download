-- Parametric fiscal rules for future calculations.
-- This table stores data only; it does not execute or encode fiscal logic.
create table public.fiscal_rules (
  id uuid primary key default gen_random_uuid(),
  env text not null check (char_length(btrim(env)) > 0),
  rule_code text not null check (char_length(btrim(rule_code)) > 0),
  rule_name text not null check (char_length(btrim(rule_name)) > 0),
  min_years numeric not null check (min_years >= 0),
  max_years numeric,
  tax_rate numeric,
  social_rate numeric,
  allowance numeric,
  allowance_type text,
  threshold numeric,
  valid_from date not null,
  valid_to date,
  description text,
  source text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint fiscal_rules_year_range_check
    check (max_years is null or max_years >= min_years),
  constraint fiscal_rules_tax_rate_check
    check (tax_rate is null or tax_rate >= 0),
  constraint fiscal_rules_social_rate_check
    check (social_rate is null or social_rate >= 0),
  constraint fiscal_rules_allowance_check
    check (allowance is null or allowance >= 0),
  constraint fiscal_rules_threshold_check
    check (threshold is null or threshold >= 0),
  constraint fiscal_rules_validity_range_check
    check (valid_to is null or valid_to >= valid_from),
  constraint fiscal_rules_version_identity_unique
    unique (env, rule_code, valid_from)
);

create index fiscal_rules_lookup_idx
  on public.fiscal_rules (env, rule_code, valid_from desc);
create index fiscal_rules_validity_idx
  on public.fiscal_rules (valid_from, valid_to);

create trigger fiscal_rules_set_updated_at
  before update on public.fiscal_rules
  for each row execute function public.set_updated_at();

alter table public.fiscal_rules enable row level security;
alter table public.fiscal_rules force row level security;

-- Rules are readable reference data. Administration and writes are reserved
-- for a future server-side/admin workflow and have no authenticated policy.
create policy fiscal_rules_read_authenticated
  on public.fiscal_rules
  for select
  to authenticated
  using (true);

grant select on table public.fiscal_rules to authenticated;
revoke insert, update, delete, truncate, references, trigger
  on table public.fiscal_rules from authenticated, anon;
