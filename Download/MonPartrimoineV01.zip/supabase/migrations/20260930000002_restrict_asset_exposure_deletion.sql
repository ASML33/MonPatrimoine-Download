-- Phase 7.3B: exposures are business dependencies and must never disappear
-- implicitly when their asset is deleted.
begin;

alter table public.asset_sector_exposures
  drop constraint asset_sector_exposures_asset_id_fkey,
  add constraint asset_sector_exposures_asset_id_fkey
    foreign key (asset_id) references public.assets(id)
    on delete restrict on update cascade;

alter table public.asset_activity_exposures
  drop constraint asset_activity_exposures_asset_id_fkey,
  add constraint asset_activity_exposures_asset_id_fkey
    foreign key (asset_id) references public.assets(id)
    on delete restrict on update cascade;

alter table public.asset_geography_exposures
  drop constraint asset_geography_exposures_asset_id_fkey,
  add constraint asset_geography_exposures_asset_id_fkey
    foreign key (asset_id) references public.assets(id)
    on delete restrict on update cascade;

commit;
