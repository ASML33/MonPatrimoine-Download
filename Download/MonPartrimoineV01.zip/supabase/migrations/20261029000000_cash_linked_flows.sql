-- Local candidate only. No existing flow is replayed, no business row rewritten.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
lock table public.cash_flows, public.cash_balances in share row exclusive mode;
do $$begin
 if private.app_backup_schema()<>'a48d1f799f07e54483c6cfd77b721a889e5195b99c9cda0df0803ae7238066c9' then raise exception 'Unexpected linked-flow archive frontier';end if;
 if exists(select 1 from public.cash_balances where metadata ? 'flow_cash_links' or metadata ? 'flow_cash_requests') then raise exception 'Existing linked-flow metadata requires review';end if;
end $$;

create function public.apply_cash_flow_observation()
returns trigger language plpgsql security invoker set search_path='' as $$
declare
 f public.cash_flows; c public.contracts; b public.cash_balances; target public.cash_balances;
 actor uuid:=auth.uid(); code text; request jsonb; actual jsonb; expected jsonb;
 entries jsonb; prior jsonb; after_entries jsonb; latest jsonb; link jsonb; meta jsonb;
 stamp timestamptz:=clock_timestamp(); value numeric; earliest timestamptz; linked boolean:=false;
begin
 -- Existing operator-owned restoration/import paths restore recorded cells,
 -- including metadata, without replaying financial movements.
 if current_user <> 'authenticated' then
  if tg_op='DELETE' then return old;else return new;end if;
 end if;
 if tg_op='DELETE' then f:=old;else f:=new;end if;
 if actor is null or public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 select * into c from public.contracts where id=coalesce(f.destination_contract_id,f.source_contract_id) and user_id=actor for update;
 if not found then raise exception 'FLOW-CASH-CONTRACT' using errcode='42501';end if;
 select e.code into code from public.envelope_types e where e.id=c.envelope_type_id;
 if tg_op<>'INSERT' then
  select * into b from public.cash_balances where contract_id=c.id and user_id=actor and metadata#>>array['flow_cash_links',old.id::text,'active']='true' for update;
  if found then link:=b.metadata#>array['flow_cash_links',old.id::text];linked:=coalesce((link->>'active')::boolean,false);end if;
 end if;
 -- Historical, unlinked flows keep their original independent semantics.
 if (tg_op<>'INSERT' and not linked) or (tg_op='INSERT' and code not in('pea','pea_pme','cto','compte_titres')) then
  if tg_op='DELETE' then return old;else return new;end if;
 end if;
 if tg_op='UPDATE' and row(new.kind,new.amount,new.currency_code,new.occurred_at) is not distinct from row(old.kind,old.amount,old.currency_code,old.occurred_at) then return new;end if;
 if code not in('pea','pea_pme','cto','compte_titres') then raise exception 'FLOW-CASH-ENVELOPE' using errcode='23514';end if;
 request:=nullif(current_setting('monpatrimoine.flow_cash_request',true),'')::jsonb;
 if request is null or request->>'flowId' is distinct from f.id::text or request->>'operation' is distinct from lower(tg_op)
 then raise exception 'FLOW-CASH-RELOAD' using errcode='40001';end if;
 -- The request context is only optimistic concurrency, never authorization.
 perform 1 from public.cash_balances where contract_id=c.id and user_id=actor order by id for update;
 select coalesce(jsonb_agg(jsonb_build_object('id',id,'updatedAt',updated_at) order by id),'[]') into actual from public.cash_balances where contract_id=c.id and user_id=actor;
 select coalesce(jsonb_agg(jsonb_build_object('id',(v->>'id')::uuid,'updatedAt',(v->>'updatedAt')::timestamptz) order by (v->>'id')::uuid),'[]') into expected from jsonb_array_elements(request->'balances') v;
 if actual is distinct from expected then raise exception 'FLOW-CASH-STALE' using errcode='40001';end if;
 earliest:=case when tg_op='INSERT' then f.occurred_at when tg_op='DELETE' then old.occurred_at else least(old.occurred_at,new.occurred_at) end;
 if (c.metadata ? 'knownTotalContributionsEur' or c.metadata ? 'knownNetCashFlowsEur')
   and (c.metadata->>'knownTotalContributionsAsOf' is null or c.metadata->>'knownTotalContributionsAsOf'>=(earliest at time zone 'Europe/Paris')::date::text)
 then raise exception 'FLOW-CASH-ANCHOR' using errcode='23514';end if;
 if exists(select 1 from public.patrimonial_daily_captures cap where cap.user_id=actor and cap.state='published' and cap.business_date >= (earliest at time zone 'Europe/Paris')::date
   and cap.captured_at>=earliest and (
    jsonb_typeof(cap.inputs->'contracts') is distinct from 'array'
    or exists(select 1 from jsonb_array_elements(case when jsonb_typeof(cap.inputs->'contracts')='array' then cap.inputs->'contracts' else '[]'::jsonb end) v where v->>'id'=c.id::text)
    or exists(select 1 from jsonb_array_elements(case when jsonb_typeof(cap.result#>'{report,contracts}')='array' then cap.result#>'{report,contracts}' else '[]'::jsonb end) v where v->>'id'=c.id::text)
   )) then raise exception 'FLOW-CASH-CAPTURE' using errcode='23514';end if;
 if linked then
  entries:=b.metadata#>'{cash_balance_observations,entries}';
  if entries is distinct from link->'afterEntries' then raise exception 'FLOW-CASH-DEPENDENCY' using errcode='23514';end if;
  prior:=link->'beforeEntries';
  select v into latest from jsonb_array_elements(prior) v order by (v->>'asOf')::timestamptz desc limit 1;
  if latest is null then raise exception 'FLOW-CASH-PROOF' using errcode='23514';end if;
  meta:=b.metadata||jsonb_build_object('cash_balance_observations',jsonb_build_object('version',2,'entries',prior,'archived',coalesce(b.metadata#>'{cash_balance_observations,archived}','[]')||jsonb_build_array(jsonb_build_object('entries',entries,'replacedAt',stamp))));
  meta:=jsonb_set(meta,array['flow_cash_links',old.id::text],link||jsonb_build_object('active',false,'reversedAt',stamp));
  update public.cash_balances set metadata=meta,amount=(latest->>'amount')::numeric,as_of=(latest->>'asOf')::timestamptz where id=b.id and user_id=actor;
 end if;
 if tg_op<>'DELETE' then
  if tg_op='INSERT' and not c.is_active then raise exception 'FLOW-CASH-INACTIVE' using errcode='23514';end if;
  if f.kind not in('contribution','withdrawal') then raise exception 'FLOW-CASH-KIND' using errcode='22023';end if;
  select * into target from public.cash_balances where contract_id=c.id and user_id=actor and currency_code=f.currency_code for update;
  if not found then raise exception 'FLOW-CASH-UNKNOWN' using errcode='23514';end if;
  prior:=coalesce(target.metadata#>'{cash_balance_observations,entries}',jsonb_build_array(jsonb_build_object('amount',target.amount::text,'currencyCode',btrim(target.currency_code),'asOf',target.as_of,'recordedAt',target.updated_at)));
  select v into latest from jsonb_array_elements(prior) v order by (v->>'asOf')::timestamptz desc limit 1;
  if latest is null then raise exception 'FLOW-CASH-UNKNOWN' using errcode='23514';end if;
  if (latest->>'asOf')::timestamptz>f.occurred_at then raise exception 'FLOW-CASH-LATER' using errcode='23514';end if;
  value:=(latest->>'amount')::numeric+case when f.kind='contribution' then f.amount else -f.amount end;
  -- Existing balances forbid negative amounts; retain that protection.
  if value<0 or value>=1e16 then raise exception 'FLOW-CASH-AMOUNT' using errcode='23514';end if;
  perform public.save_cash_balance_observation(c.id,null,null,null,btrim(f.currency_code),value,f.occurred_at,target.updated_at);
  select * into target from public.cash_balances where id=target.id and user_id=actor;
  after_entries:=target.metadata#>'{cash_balance_observations,entries}';
  link:=jsonb_build_object('version',1,'active',true,'flowId',f.id,'beforeEntries',prior,'afterEntries',after_entries,'recordedAt',stamp);
  meta:=target.metadata||jsonb_build_object('flow_cash_links',coalesce(target.metadata->'flow_cash_links','{}')||jsonb_build_object(f.id::text,link));
  update public.cash_balances set metadata=meta where id=target.id and user_id=actor;
 end if;
 if tg_op='DELETE' then return old;else return new;end if;
end $$;
revoke all on function public.apply_cash_flow_observation() from public,anon,authenticated;
create trigger cash_flows_20_cash_observation before insert or update or delete on public.cash_flows for each row execute function public.apply_cash_flow_observation();

create function public.mutate_contract_cash_flow(requested_contract uuid,requested_flow uuid,requested_operation text,requested_request uuid,expected_flow_updated_at timestamptz,expected_balances jsonb,requested_values jsonb)
returns uuid language plpgsql security invoker set search_path='' as $$
declare actor uuid:=auth.uid(); c public.contracts; f public.cash_flows; b public.cash_balances;
 receipt jsonb; payload jsonb; target uuid; context jsonb; op text;
begin
 if actor is null or public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 if requested_contract is null or requested_flow is null or requested_request is null or requested_operation not in('create','update','delete') or jsonb_typeof(expected_balances) is distinct from 'array' or jsonb_typeof(requested_values) is distinct from 'object' then raise exception 'FLOW-CASH-REQUEST' using errcode='22023';end if;
 select * into c from public.contracts where id=requested_contract and user_id=actor for update;
 if not found then raise exception 'FLOW-CASH-CONTRACT' using errcode='42501';end if;
 -- FX resolution may complete after the native transaction. A retry remains
 -- the same native request even if that independent reference was resolved.
 payload:=jsonb_build_object('contract',requested_contract,'flow',requested_flow,'operation',requested_operation,'values',requested_values-'fx_rate_id'-'fx_status','flowRevision',expected_flow_updated_at,'balances',expected_balances);
 select metadata#>array['flow_cash_requests',requested_request::text] into receipt from public.cash_balances where contract_id=c.id and user_id=actor and metadata#>array['flow_cash_requests',requested_request::text] is not null;
 if receipt is not null then
  if receipt->'payload' is distinct from payload then raise exception 'FLOW-CASH-REPLAY' using errcode='40001';end if;
  return requested_flow;
 end if;
 if requested_operation<>'create' then
  select * into f from public.cash_flows where id=requested_flow and user_id=actor and coalesce(destination_contract_id,source_contract_id)=c.id for update;
  if not found then raise exception 'FLOW-CASH-FLOW' using errcode='42501';end if;
  if expected_flow_updated_at is null or f.updated_at is distinct from expected_flow_updated_at then raise exception 'FLOW-CASH-STALE' using errcode='40001';end if;
 end if;
 op:=case requested_operation when 'create' then 'insert' when 'update' then 'update' else 'delete' end;
 context:=jsonb_build_object('flowId',requested_flow,'operation',op,'balances',expected_balances);
 perform set_config('monpatrimoine.flow_cash_request',context::text,true);
 if requested_operation='delete' then
  delete from public.cash_flows where id=f.id and user_id=actor;
 else
  if requested_values->>'kind' not in('contribution','withdrawal') then raise exception 'FLOW-CASH-KIND' using errcode='22023';end if;
  if requested_operation='create' then
   insert into public.cash_flows(id,user_id,kind,destination_contract_id,source_contract_id,amount,currency_code,occurred_at,note,fx_rate_id,fx_status)
    values(requested_flow,actor,(requested_values->>'kind')::public.cash_flow_kind,case when requested_values->>'kind'='contribution' then c.id end,case when requested_values->>'kind'='withdrawal' then c.id end,(requested_values->>'amount')::numeric,requested_values->>'currency_code',(requested_values->>'occurred_at')::timestamptz,requested_values->>'note',(requested_values->>'fx_rate_id')::uuid,(requested_values->>'fx_status')::public.fx_resolution_status);
  else
   update public.cash_flows set kind=(requested_values->>'kind')::public.cash_flow_kind,destination_contract_id=case when requested_values->>'kind'='contribution' then c.id end,source_contract_id=case when requested_values->>'kind'='withdrawal' then c.id end,amount=(requested_values->>'amount')::numeric,currency_code=requested_values->>'currency_code',occurred_at=(requested_values->>'occurred_at')::timestamptz,note=requested_values->>'note',fx_rate_id=(requested_values->>'fx_rate_id')::uuid,fx_status=(requested_values->>'fx_status')::public.fx_resolution_status where id=f.id and user_id=actor;
  end if;
 end if;
 perform set_config('monpatrimoine.flow_cash_request','',true);
 -- Receipts live with the existing observation proof, including after deletion.
 select * into b from public.cash_balances where contract_id=c.id and user_id=actor and metadata#>array['flow_cash_links',requested_flow::text] is not null order by updated_at desc,id limit 1 for update;
 if found then
  update public.cash_balances set metadata=metadata||jsonb_build_object('flow_cash_requests',coalesce(metadata->'flow_cash_requests','{}')||jsonb_build_object(requested_request::text,jsonb_build_object('payload',payload,'recordedAt',clock_timestamp()))) where id=b.id and user_id=actor;
 end if;
 return requested_flow;
end $$;
revoke all on function public.mutate_contract_cash_flow(uuid,uuid,text,uuid,timestamptz,jsonb,jsonb) from public,anon;
grant execute on function public.mutate_contract_cash_flow(uuid,uuid,text,uuid,timestamptz,jsonb,jsonb) to authenticated;
-- Tables, columns and archived cells stay unchanged. Accept exactly the
-- delivered predecessor seal too; retain all ownership/dataset/cell checks.
do $patch$
declare original text; needle text:='if doc->>''schema'' is distinct from ''3ca73f81c329737a9939a5ce041e43e8846fac1da23b433f0f2618fbe18b46fd''';
begin
 original:=pg_get_functiondef('private.app_backup_upgrade(jsonb)'::regprocedure);
 if (length(original)-length(replace(original,needle,'')))/length(needle)<>1 then raise exception 'Unexpected linked-flow archive reader';end if;
 execute replace(original,needle,needle||' and doc->>''schema'' is distinct from ''a48d1f799f07e54483c6cfd77b721a889e5195b99c9cda0df0803ae7238066c9''');
end $patch$;
notify pgrst,'reload schema';
commit;
