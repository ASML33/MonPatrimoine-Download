begin;
create or replace function public.create_sector(sector_name text) returns uuid language plpgsql security definer set search_path='' as $$
declare created_id uuid:=gen_random_uuid(); actor uuid:=auth.uid(); normalized text:=btrim(sector_name);
begin
 perform private.assert_analysis_catalog_access();
 if actor is null then raise exception 'Authentication required' using errcode='42501'; end if;
 if sector_name is null or length(normalized) not between 1 and 120 then raise exception 'Invalid sector name' using errcode='23514'; end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(actor::text||':'||lower(normalized),0));
 if exists(select 1 from public.sectors where owner_user_id=actor and lower(name)=lower(normalized)) or exists(select 1 from public.user_sector_labels where user_id=actor and lower(name)=lower(normalized)) then raise exception 'Duplicate personal sector label' using errcode='23505'; end if;
 insert into public.sectors(id,taxonomy,code,name,owner_user_id) values(created_id,'monpatrimoine','custom_'||replace(created_id::text,'-',''),normalized,actor);
 insert into public.sector_activities(sector_id,code,name) values(created_id,'unspecified','Non détaillé');
 return created_id;
end $$;
create or replace function public.rename_sector(requested_id uuid,sector_name text) returns void language plpgsql security definer set search_path='' as $$
declare personal boolean; actor uuid:=auth.uid(); normalized text:=btrim(sector_name);
begin
 perform private.assert_analysis_catalog_access();
 if sector_name is null or length(normalized) not between 1 and 120 then raise exception 'Invalid sector name' using errcode='23514'; end if;
 select owner_user_id=actor into personal from public.sectors where id=requested_id;
 if not found then raise exception 'Sector unavailable' using errcode='42501'; end if;
 perform pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended(actor::text||':'||lower(normalized),0));
 if exists(select 1 from public.sectors where owner_user_id=actor and id<>requested_id and lower(name)=lower(normalized)) or exists(select 1 from public.user_sector_labels where user_id=actor and sector_id<>requested_id and lower(name)=lower(normalized)) then raise exception 'Duplicate personal sector label' using errcode='23505'; end if;
 if personal then update public.sectors set name=normalized,updated_at=now() where id=requested_id and owner_user_id=actor;
 else insert into public.user_sector_labels(user_id,sector_id,name) values(actor,requested_id,normalized) on conflict(user_id,sector_id) do update set name=excluded.name,updated_at=now(); end if;
end $$;
commit;
