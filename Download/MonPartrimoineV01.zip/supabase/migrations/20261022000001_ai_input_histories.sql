-- Local candidate only. Preferences stay in the existing profile/backup document.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';

create or replace function public.ai_input_history_text_valid(field text, content text)
returns boolean language sql immutable set search_path='' as $$
 select field in ('question','additionalInformation') and content is not null
 and length(btrim(content,E' \t\n\r\v\f'||chr(160)||chr(5760)||chr(8192)||chr(8193)||chr(8194)||chr(8195)||chr(8196)||chr(8197)||chr(8198)||chr(8199)||chr(8200)||chr(8201)||chr(8202)||chr(8232)||chr(8233)||chr(8239)||chr(8287)||chr(12288)||chr(65279)))>0
 and content !~ '[\x01-\x08\x0B\x0C\x0E-\x1F]'
 and (select coalesce(sum(case when ascii(c)>65535 then 2 else 1 end),0) from regexp_split_to_table(content,'') c)<=case when field='question' then 1000 else 4000 end
$$;
revoke all on function public.ai_input_history_text_valid(text,text) from public,anon;
grant execute on function public.ai_input_history_text_valid(text,text) to authenticated;

-- Explicit one-time reprise. These dates attest this migration, not an unknown
-- original save. A version marker prevents resurrection after later deletion.
do $$declare p record; doc jsonb; histories jsonb; field text; content text;
 stamp text:=to_char(clock_timestamp() at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"');
begin
 for p in select auth_user_id,preferences from public.profiles where auth_user_id in (select auth_user_id from private.application_principal) for update loop
  if p.preferences is not null and jsonb_typeof(p.preferences)<>'object' then raise exception 'Profile preferences must be an object';end if;
  doc:=coalesce(nullif(p.preferences->'ai_photograph','null'::jsonb),'{}');
  if doc->>'historyVersion'='1' then continue;end if;
  if jsonb_typeof(doc)<>'object' or doc ? 'historyVersion' or doc ? 'histories' then raise exception 'Unexpected AI preference history state';end if;
  histories:=jsonb_build_object('question','[]'::jsonb,'additionalInformation','[]'::jsonb);
  foreach field in array array['question','additionalInformation'] loop
   if doc ? field and jsonb_typeof(doc->field) not in ('string','null') then raise exception 'Unexpected legacy input';end if;
   content:=doc->>field;
   if coalesce(public.ai_input_history_text_valid(field,content),false) then
    histories:=jsonb_set(histories,array[field],jsonb_build_array(jsonb_build_object('id',gen_random_uuid(),'recordedAt',stamp,'text',content)));
   elsif content is not null and content ~ '[^[:space:]]' and length(btrim(content,chr(160)||chr(65279)))>0 then
    -- Whitespace-only legacy values need no entry; invalid useful text must not be lost.
    if (select coalesce(sum(case when ascii(c)>65535 then 2 else 1 end),0) from regexp_split_to_table(content,'') c)>(case when field='question' then 1000 else 4000 end) or content ~ '[\x01-\x08\x0B\x0C\x0E-\x1F]' then raise exception 'Invalid legacy text; migration stopped';end if;
   end if;
  end loop;
  doc:=(doc-'question'-'additionalInformation')||jsonb_build_object('historyVersion',1,'histories',histories,'legacyImportedAt',stamp);
  update public.profiles set preferences=jsonb_set(coalesce(preferences,'{}'),'{ai_photograph}',doc,true) where auth_user_id=p.auth_user_id;
 end loop;
end$$;

create or replace function public.change_ai_input_history(requested_operation text,requested_field text,requested_entry uuid,requested_text text default null,deletion_confirmed boolean default false)
returns jsonb language plpgsql security definer set search_path='' as $$
declare prefs jsonb; doc jsonb; entries jsonb; entry jsonb; existing jsonb;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 if requested_operation not in ('save','delete') or requested_operation is null or requested_field not in ('question','additionalInformation') or requested_field is null or requested_entry is null then raise exception 'Invalid history request' using errcode='22023';end if;
 if requested_operation='delete' and deletion_confirmed is distinct from true then raise exception 'Confirmation required' using errcode='22023';end if;
 if requested_operation='save' and public.ai_input_history_text_valid(requested_field,requested_text) is distinct from true then raise exception 'Invalid history text' using errcode='22023';end if;
 select preferences into prefs from public.profiles where auth_user_id=auth.uid() for update;
 if not found then raise exception 'Profile unavailable' using errcode='42501';end if;
 doc:=prefs->'ai_photograph';
 if doc->>'historyVersion' is distinct from '1' or jsonb_typeof(doc#>array['histories',requested_field]) is distinct from 'array' then raise exception 'History migration required' using errcode='55000';end if;
 entries:=doc#>array['histories',requested_field];
 select e into existing from jsonb_array_elements(entries) e where e->>'id'=requested_entry::text;
 if requested_operation='save' then
  if existing is not null then
   if existing->>'text' is distinct from requested_text then raise exception 'Submission already used' using errcode='40001';end if;
   return existing;
  end if;
  entry:=jsonb_build_object('id',requested_entry,'recordedAt',to_char(clock_timestamp() at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'text',requested_text);
  entries:=jsonb_build_array(entry)||entries;
 else
  select coalesce(jsonb_agg(e order by ord),'[]') into entries from jsonb_array_elements(entries) with ordinality t(e,ord) where e->>'id'<>requested_entry::text;
  entry:=jsonb_build_object('deleted',existing is not null);
 end if;
 doc:=jsonb_set(doc,array['histories',requested_field],entries);
 update public.profiles set preferences=jsonb_set(prefs,'{ai_photograph}',doc) where auth_user_id=auth.uid();
 return entry;
end$$;
revoke all on function public.change_ai_input_history(text,text,uuid,text,boolean) from public,anon;
grant execute on function public.change_ai_input_history(text,text,uuid,text,boolean) to authenticated;

-- Old application instances submit whole preference documents. Remove that
-- write capability, including table-level grants, while retaining the exact
-- previous UPDATE rights on every other profile column. Narrow definer RPCs
-- below and above derive the principal from verified Auth, never from arguments.
do $$declare columns_to_keep text[]; col text;begin
 select array_agg(attname::text) into columns_to_keep from pg_attribute where attrelid='public.profiles'::regclass and attnum>0 and not attisdropped and attname<>'preferences' and has_column_privilege('authenticated','public.profiles',attname,'UPDATE');
 revoke update on public.profiles from authenticated;
 revoke update (preferences) on public.profiles from authenticated;
 foreach col in array coalesce(columns_to_keep,array[]::text[]) loop
  execute format('grant update (%I) on public.profiles to authenticated',col);
 end loop;
 if has_column_privilege('authenticated','public.profiles','preferences','UPDATE') or has_column_privilege('anon','public.profiles','preferences','UPDATE') then raise exception 'Unexpected inherited preference write grant';end if;
end$$;

create or replace function public.update_profile_user_information(requested_patch jsonb)
returns void language plpgsql security definer set search_path='' as $$
declare prefs jsonb; info jsonb;begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 if jsonb_typeof(requested_patch) is distinct from 'object' or exists(select 1 from jsonb_object_keys(requested_patch) k where k<>'display_name') then raise exception 'Invalid preference patch' using errcode='22023';end if;
 if requested_patch ? 'display_name' and (jsonb_typeof(requested_patch->'display_name') not in ('string','null') or length(requested_patch->>'display_name')>80) then raise exception 'Invalid display name' using errcode='22023';end if;
 select preferences into prefs from public.profiles where auth_user_id=auth.uid() for update;
 if not found then raise exception 'Profile unavailable' using errcode='42501';end if;
 prefs:=coalesce(prefs,'{}');info:=coalesce(prefs->'user_information','{}');
 if jsonb_typeof(prefs)<>'object' or jsonb_typeof(info)<>'object' then raise exception 'Invalid preference state';end if;
 if requested_patch ? 'display_name' then
  if requested_patch->'display_name'='null'::jsonb then info:=info-'display_name';else info:=info||requested_patch;end if;
 end if;
 if info='{}'::jsonb then prefs:=prefs-'user_information';else prefs:=jsonb_set(prefs,'{user_information}',info);end if;
 update public.profiles set preferences=prefs where auth_user_id=auth.uid();
end$$;
revoke all on function public.update_profile_user_information(jsonb) from public,anon;
grant execute on function public.update_profile_user_information(jsonb) to authenticated;
commit;
