-- Supplemental candidate: imported total snapshots may retain a legacy unit_price.
-- Keep the imported rows intact and align the write boundary with isAmountTracked.
begin;
set local lock_timeout='5s';
set local statement_timeout='45s';
lock table public.contracts,public.positions,public.position_snapshots,public.asset_prices in share row exclusive mode;
do $adapt$
declare original text;patched text;needle text;
begin
 original:=pg_get_functiondef('public.edit_amount_observation(uuid,uuid,date,numeric,text,text,text,boolean)'::regprocedure);
 needle:='or not exists(select 1 from public.position_snapshots where position_id=p.id and unit_price is null)';
 if position(needle in original)=0 or position('or exists(select 1 from public.position_snapshots where position_id=p.id and unit_price is not null)' in original)=0 then raise exception 'Unexpected monetary snapshot guard';end if;
 patched:=replace(original,needle,'or not exists(select 1 from public.position_snapshots where position_id=p.id)');
 patched:=replace(patched,'or exists(select 1 from public.position_snapshots where position_id=p.id and unit_price is not null)','');
 execute patched;

 original:=pg_get_functiondef('public.preview_position_observation(uuid,uuid,uuid,uuid,date,numeric,numeric,text)'::regprocedure);
 needle:='and exists(select 1 from public.position_snapshots where position_id=p.id and unit_price is null)';
 if position(needle in original)=0 or position('and not exists(select 1 from public.asset_prices where asset_id=p.asset_id)' in original)=0 then raise exception 'Unexpected holding monetary guard';end if;
 patched:=replace(original,needle,'and exists(select 1 from public.position_snapshots where position_id=p.id)');
 patched:=replace(patched,'and not exists(select 1 from public.asset_prices where asset_id=p.asset_id)',
 'and (p.metadata ? ''abeille_test_repair'' or not exists(select 1 from public.asset_prices where asset_id=p.asset_id))');
 execute patched;

 original:=pg_get_functiondef('public.save_manual_asset_price(uuid,numeric,date)'::regprocedure);
 needle:='where p.asset_id=requested_asset and s.unit_price is null)';
 if position(needle in original)=0 or position('and not exists(select 1 from public.asset_prices q where q.asset_id=requested_asset)' in original)=0 then raise exception 'Unexpected manual price monetary guard';end if;
 patched:=replace(original,needle,'where p.asset_id=requested_asset)');
 patched:=replace(patched,'and not exists(select 1 from public.asset_prices q where q.asset_id=requested_asset)',
 'and (not exists(select 1 from public.asset_prices q where q.asset_id=requested_asset) or exists(select 1 from public.positions p where p.asset_id=requested_asset and p.metadata ? ''abeille_test_repair''))');
 execute patched;
end $adapt$;
notify pgrst,'reload schema';
commit;
