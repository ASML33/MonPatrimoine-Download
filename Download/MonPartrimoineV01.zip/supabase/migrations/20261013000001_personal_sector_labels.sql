begin;
create table public.user_sector_labels(user_id uuid not null references auth.users(id) on delete cascade,sector_id uuid not null references public.sectors(id) on delete cascade,name text not null check(name=btrim(name) and char_length(name) between 1 and 120),updated_at timestamptz not null default now(),primary key(user_id,sector_id));
create unique index user_sector_labels_name_unique on public.user_sector_labels(user_id,lower(name));
alter table public.user_sector_labels enable row level security;
alter table public.user_sector_labels force row level security;
revoke all on public.user_sector_labels from public,anon,authenticated;
grant select on public.user_sector_labels to authenticated;
create policy user_sector_labels_read on public.user_sector_labels for select to authenticated using(user_id=auth.uid() and public.is_authorized_user());
create or replace function public.rename_sector(requested_id uuid,sector_name text) returns void language plpgsql security definer set search_path='' as $$
declare personal boolean;
begin
 perform private.assert_analysis_catalog_access();
 if sector_name is null or length(btrim(sector_name)) not between 1 and 120 then raise exception 'Invalid sector name' using errcode='23514'; end if;
 select owner_user_id=auth.uid() into personal from public.sectors where id=requested_id;
 if not found then raise exception 'Sector unavailable' using errcode='42501'; end if;
 if personal then update public.sectors set name=btrim(sector_name),updated_at=now() where id=requested_id and owner_user_id=auth.uid();
 else insert into public.user_sector_labels(user_id,sector_id,name) values(auth.uid(),requested_id,btrim(sector_name)) on conflict(user_id,sector_id) do update set name=excluded.name,updated_at=now(); end if;
end $$;
create view public.effective_sectors with(security_invoker=true) as select s.id,s.taxonomy,s.code,coalesce(l.name,s.name) name,s.name common_name,s.owner_user_id,s.is_active,s.has_been_used,s.created_at,greatest(s.updated_at,coalesce(l.updated_at,s.updated_at)) updated_at from public.sectors s left join public.user_sector_labels l on l.sector_id=s.id and l.user_id=auth.uid();
revoke all on public.effective_sectors from public,anon,authenticated;
grant select on public.effective_sectors to authenticated;
commit;
