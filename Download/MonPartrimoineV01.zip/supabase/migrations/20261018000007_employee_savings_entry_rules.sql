-- Distinct canonical entry rules; imported PEG observations without NET stay valid.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
do $$declare original text; changed text;begin
 original:=pg_get_functiondef('public.preview_employee_savings_value(uuid,text,date,numeric,numeric)'::regprocedure);
 changed:=replace(original,'entries:=private.employee_savings_effective(requested_contract);',
 'if (select code from public.envelope_types where id=c.envelope_type_id)=''peg'' and requested_net is null
   or (select code from public.envelope_types where id=c.envelope_type_id)=''per_col'' and requested_net is not null then
   raise exception ''Invalid NET for canonical employee-savings type'' using errcode=''23514'';end if;
 entries:=private.employee_savings_effective(requested_contract);');
 if changed=original then raise exception 'Unexpected employee-savings preview definition';end if;
 execute changed;
end $$;
-- Retire the former fiscal-gain writer: it must not bypass the dated value RPC.
revoke all on function public.save_contract_manual_situation(uuid,timestamptz,numeric,numeric,numeric,text,numeric) from public,anon,authenticated;
notify pgrst,'reload schema';
commit;
