-- Local candidate only. No stored content, title, writer, grant or archive format changes.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
-- Existing UTF-16 semantics; CRLF is one line break. Text remains byte-for-byte intact.
create or replace function public.ai_input_history_text_valid(field text, content text)
returns boolean language sql immutable set search_path='' as $$
 select field in ('question','additionalInformation') and content is not null
 and length(btrim(content,E' \t\n\r\v\f'||chr(160)||chr(5760)||chr(8192)||chr(8193)||chr(8194)||chr(8195)||chr(8196)||chr(8197)||chr(8198)||chr(8199)||chr(8200)||chr(8201)||chr(8202)||chr(8232)||chr(8233)||chr(8239)||chr(8287)||chr(12288)||chr(65279)))>0
 and content !~ '[\x01-\x08\x0B\x0C\x0E-\x1F]'
 and (select coalesce(sum(case when ascii(c)>65535 then 2 else 1 end),0) from regexp_split_to_table(replace(content,E'\r\n',E'\n'),'') c)<=10000
$$;
create or replace function private.shared_objective_text_valid(content text)
returns boolean language sql immutable set search_path='' as $$
 select content is not null and content !~ '[\x01-\x08\x0B\x0C\x0E-\x1F]'
 and (select coalesce(sum(case when ascii(c)>65535 then 2 else 1 end),0) from regexp_split_to_table(replace(content,E'\r\n',E'\n'),'') c)<=10000
$$;
notify pgrst,'reload schema';
commit;
