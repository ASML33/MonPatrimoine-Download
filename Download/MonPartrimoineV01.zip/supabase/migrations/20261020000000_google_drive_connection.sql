-- Prepared locally only. No provider token or PKCE verifier is stored in plaintext.
begin;
create table private.google_drive_connections (
  user_id uuid primary key references auth.users(id),
  revision bigint not null default 0 check (revision >= 0),
  cipher text check (char_length(cipher) between 40 and 32768),
  status text not null default 'not_connected' check (status in ('not_connected','connected','reconnect_required')),
  verified_at timestamptz,
  expires_at timestamptz,
  lease uuid,
  lease_until timestamptz
);
create table private.google_drive_oauth_states (
  state_hash text primary key check (state_hash ~ '^[0-9a-f]{64}$'),
  user_id uuid not null references private.google_drive_connections(user_id),
  session_hash text not null check (session_hash ~ '^[0-9a-f]{64}$'),
  verifier text not null check (char_length(verifier) between 40 and 4096),
  revision bigint not null,
  expires_at timestamptz not null,
  unique(user_id,session_hash)
);
alter table private.google_drive_connections enable row level security;
alter table private.google_drive_connections force row level security;
alter table private.google_drive_oauth_states enable row level security;
alter table private.google_drive_oauth_states force row level security;
revoke all on private.google_drive_connections, private.google_drive_oauth_states from public,anon,authenticated,service_role;

-- One narrow server RPC, never granted to a browser role. Caller identity is
-- independently checked against the existing principal and active profile.
create function public.google_drive_connection_store(operation text, actor uuid, args jsonb default '{}')
returns jsonb language plpgsql volatile security definer set search_path = '' as $$
declare row_data private.google_drive_connections; pending private.google_drive_oauth_states; changed integer;
begin
  if actor is null or not exists(select 1 from private.application_principal p
    join public.profiles pr on pr.auth_user_id=p.auth_user_id
    where p.singleton and p.auth_user_id=actor and pr.is_active) then
    raise exception 'Drive unavailable' using errcode='42501';
  end if;
  if operation='load' then
    select * into row_data from private.google_drive_connections where user_id=actor;
    if not found then return jsonb_build_object('revision',0,'cipher',null,'status','not_connected','verified_at',null,'expires_at',null);end if;
    return jsonb_build_object('revision',row_data.revision,'cipher',row_data.cipher,'status',row_data.status,'verified_at',row_data.verified_at,'expires_at',row_data.expires_at);
  elsif operation='begin' then
    insert into private.google_drive_connections(user_id) values(actor) on conflict do nothing;
    -- Lock the connection to serialize concurrent starts for the same principal.
    select * into row_data from private.google_drive_connections where user_id=actor for update;
    delete from private.google_drive_oauth_states where expires_at<=clock_timestamp() or (user_id=actor and session_hash=args->>'session_hash');
    insert into private.google_drive_oauth_states(state_hash,user_id,session_hash,verifier,revision,expires_at)
      values(args->>'state_hash',actor,args->>'session_hash',args->>'verifier',row_data.revision,clock_timestamp()+interval '10 minutes');
    return 'true';
  elsif operation='consume' then
    delete from private.google_drive_oauth_states
      where state_hash=args->>'state_hash' and user_id=actor and session_hash=args->>'session_hash'
        and expires_at>clock_timestamp() returning * into pending;
    if not found then return 'null';end if;
    return jsonb_build_object('verifier',pending.verifier,'revision',pending.revision);
  elsif operation='connect' then
    if args->>'cipher' is null or (args->>'expires_at')::timestamptz<=clock_timestamp() then raise exception 'Drive unavailable';end if;
    update private.google_drive_connections set cipher=args->>'cipher',status='connected',revision=revision+1,
      verified_at=clock_timestamp(),expires_at=(args->>'expires_at')::timestamptz,lease=null,lease_until=null
      where user_id=actor and revision=(args->>'revision')::bigint;
  elsif operation='claim' then
    update private.google_drive_connections set lease=(args->>'lease')::uuid,lease_until=clock_timestamp()+interval '90 seconds'
      where user_id=actor and revision=(args->>'revision')::bigint and status='connected'
        and cipher is not null and (lease_until is null or lease_until<=clock_timestamp());
  elsif operation='refresh' then
    if args->>'cipher' is null or (args->>'expires_at')::timestamptz<=clock_timestamp() then raise exception 'Drive unavailable';end if;
    update private.google_drive_connections set cipher=args->>'cipher',revision=revision+1,
      verified_at=clock_timestamp(),expires_at=(args->>'expires_at')::timestamptz,lease=null,lease_until=null
      where user_id=actor and revision=(args->>'revision')::bigint and lease=(args->>'lease')::uuid and lease_until>clock_timestamp();
  elsif operation='release' then
    update private.google_drive_connections set lease=null,lease_until=null,
      status=case when coalesce((args->>'reconnect')::boolean,false) then 'reconnect_required' else status end
      where user_id=actor and revision=(args->>'revision')::bigint and lease=(args->>'lease')::uuid and lease_until>clock_timestamp();
  else raise exception 'Drive unavailable' using errcode='22023';
  end if;
  get diagnostics changed=row_count;
  return to_jsonb(changed=1);
end $$;
revoke all on function public.google_drive_connection_store(text,uuid,jsonb) from public,anon,authenticated;
grant execute on function public.google_drive_connection_store(text,uuid,jsonb) to service_role;
comment on function public.google_drive_connection_store(text,uuid,jsonb) is 'Server-only encrypted Google Drive connection and one-use session-bound OAuth state. No financial data.';
commit;
