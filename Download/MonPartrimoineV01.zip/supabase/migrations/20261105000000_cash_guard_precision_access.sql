-- Restore the exact function source recorded in the historical migration.
-- The archive preflight hashes the PostgreSQL definition including body CRLF.
do $replay$
begin
  execute replace($historical$CREATE OR REPLACE FUNCTION public.guard_dated_cash_balance_observations()

 RETURNS trigger

 LANGUAGE plpgsql

 SET search_path TO ''

AS $function$



declare



 h jsonb := new.metadata->'cash_balance_observations';



 prior jsonb;



 entry jsonb;



 days date[] := '{}';



 day date;



 latest jsonb;



 archives jsonb;



 old_archives jsonb := '[]';



begin

 if current_user='authenticated' and exists(select 1 from public.contracts c join public.envelope_types t on t.id=c.envelope_type_id where c.id=new.contract_id and c.user_id=auth.uid() and t.code in('pea','pea_pme','cto','compte_titres')) and (tg_op='INSERT' or row(new.amount,new.as_of,new.metadata->'cash_balance_observations',new.metadata->'securities_cash_actions',new.metadata->'flow_cash_links',new.metadata->'flow_cash_requests',new.metadata->'cash_balance_corrections') is distinct from row(old.amount,old.as_of,old.metadata->'cash_balance_observations',old.metadata->'securities_cash_actions',old.metadata->'flow_cash_links',old.metadata->'flow_cash_requests',old.metadata->'cash_balance_corrections')) then raise exception 'SECURITIES-RELOAD' using errcode='40001';end if;

 if current_user<>'authenticated' and new.metadata#>>'{securities_cash_actions,known}'='false' and new.metadata#>'{cash_balance_observations,entries}'='[]'::jsonb and new.amount=0 then return new;end if;

 if public.app_restore_permitted(tg_relid,tg_op,case when tg_op='INSERT' then null else to_jsonb(old) end,case when tg_op='DELETE' then null else to_jsonb(new) end) then if tg_op='DELETE' then return old;else return new;end if;end if;





 if h is null then



   if tg_op='UPDATE' and (old.metadata ? 'cash_balance_observations'



      or row(new.amount,new.as_of) is distinct from row(old.amount,old.as_of)) then



     raise exception 'Dated observation history required' using errcode='23514';



   end if;



   return new;



 end if;



 if h->>'version' is distinct from '2' or jsonb_typeof(h->'entries') is distinct from 'array'



    or jsonb_typeof(h->'archived') is distinct from 'array' then



   raise exception 'Unsupported dated observation history' using errcode='23514';



 end if;



 if jsonb_array_length(h->'entries')=0 and (tg_op='INSERT' or not (new.metadata ? 'cash_balance_corrections')) then raise exception 'Empty effective set requires a traced correction' using errcode='23514';end if;

 for entry in select value from jsonb_array_elements(h->'entries') loop



   -- Resolve the private helper only for privileged, high-precision entries.

   -- Authenticated clients cannot submit values beyond the ordinary precision.

   if jsonb_typeof(entry->'amount') = 'string'

      and (entry->>'amount') !~ '^[0-9]{1,16}(\.[0-9]{1,8})?$' then

     if current_user = 'authenticated' or (entry->>'amount') !~ '^[0-9]{1,16}(\.[0-9]{1,12})?$' then

       raise exception 'Invalid native cash observation' using errcode='23514';

     end if;

     if not private.cto_broker_materialized_precision(new.id,((entry->>'asOf')::timestamptz at time zone 'Europe/Paris')::date,(entry->>'amount')::numeric) then

       raise exception 'Invalid native cash observation' using errcode='23514';

     end if;

   end if;





   if jsonb_typeof(entry->'amount') is distinct from 'string'







      or entry->>'currencyCode' is distinct from btrim(new.currency_code)



      or entry->>'asOf' is null or entry->>'recordedAt' is null then



     raise exception 'Invalid native cash observation' using errcode='23514';



   end if;



   day := ((entry->>'asOf')::timestamptz at time zone 'Europe/Paris')::date;



   if not isfinite((entry->>'asOf')::timestamptz) or not isfinite((entry->>'recordedAt')::timestamptz)



      or (entry->>'asOf')::timestamptz > clock_timestamp() or day=any(days) then



     raise exception 'Duplicate civil day or invalid observation time' using errcode='23514';



   end if;



   days := array_append(days,day);



   if latest is null or (entry->>'asOf')::timestamptz > (latest->>'asOf')::timestamptz then latest:=entry; end if;



 end loop;



 if latest is not null and ((latest->>'amount')::numeric is distinct from new.amount



    or (latest->>'asOf')::timestamptz is distinct from new.as_of) then



   raise exception 'Current balance must match latest effective observation' using errcode='23514';



 end if;



 if tg_op='UPDATE' and h is distinct from old.metadata->'cash_balance_observations' then



   prior := old.metadata->'cash_balance_observations';



   if prior is not null then



     if prior->>'version' is distinct from '2' then



       raise exception 'Existing observation history requires explicit review' using errcode='23514';



     end if;



     old_archives := prior->'archived';



   end if;



   archives := h->'archived';



   if jsonb_array_length(archives) <> jsonb_array_length(old_archives)+1



      or (select coalesce(jsonb_agg(value order by ord),'[]') from jsonb_array_elements(archives) with ordinality a(value,ord)



          where ord<=jsonb_array_length(old_archives)) is distinct from old_archives then



     raise exception 'Previous versions must be preserved' using errcode='23514';



   end if;



   entry := archives->-1;



   if entry->>'replacedAt' is null or not isfinite((entry->>'replacedAt')::timestamptz) then



     raise exception 'Correction timestamp required' using errcode='23514';



   end if;



   if prior is not null then



     if entry->'entries' is distinct from prior->'entries' then



       raise exception 'Previous effective observations must be archived exactly' using errcode='23514';



     end if;



   else



     if jsonb_typeof(entry->'entries') is distinct from 'array' or jsonb_array_length(entry->'entries')<>1



        or (entry->'entries'->0->>'amount')::numeric is distinct from old.amount



        or (entry->'entries'->0->>'asOf')::timestamptz is distinct from old.as_of



        or entry->'entries'->0->>'currencyCode' is distinct from btrim(old.currency_code) then



       raise exception 'Original native balance must be archived' using errcode='23514';



     end if;



   end if;



 end if;



 return new;



end;



$function$;$historical$, chr(10), chr(13) || chr(10));
end
$replay$;
