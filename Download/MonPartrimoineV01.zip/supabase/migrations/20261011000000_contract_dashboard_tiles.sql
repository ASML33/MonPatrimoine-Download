-- Local-only until explicit authorization for Production.
begin;

alter table public.contracts
  add column if not exists dashboard_tile_name text;

alter table public.contracts
  add constraint contracts_dashboard_tile_name_check
  check (
    dashboard_tile_name is null
    or (
      dashboard_tile_name = btrim(dashboard_tile_name)
      and char_length(dashboard_tile_name) between 1 and 120
    )
  );

comment on column public.contracts.dashboard_tile_name is
  'Personal Dashboard grouping label. NULL hides the contract from Dashboard tiles without excluding it from patrimonial totals.';

update public.contracts c
set dashboard_tile_name = case
      when not c.is_active or c.closed_on is not null or not c.show_on_dashboard then null
      when t.code in ('pea', 'cto', 'pea_pme') then 'Comptes boursiers'
      when t.code = 'assurance_vie' then 'Assurance-vie'
      when t.code = 'epargne_liquide' then 'Épargne liquide'
      when t.code = 'immobilier' then 'Immobilier'
      when t.code in ('peg', 'per_col') then 'Épargne salariale'
      else 'Autres'
    end,
    metadata = jsonb_set(coalesce(c.metadata, '{}'::jsonb), '{dashboardTileInitialized}', 'true'::jsonb, true)
from public.envelope_types t
where t.id = c.envelope_type_id
  and not coalesce((c.metadata ->> 'dashboardTileInitialized')::boolean, false);

commit;
