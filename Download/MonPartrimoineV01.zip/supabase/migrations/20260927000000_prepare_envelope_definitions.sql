-- Phase 7.1, local preparation only. No catalogue seed or historical backfill.
-- Categories were validated in the Phase 7.1 functional decisions after V9.
begin;
create extension if not exists btree_gist with schema extensions;
set local search_path = public, extensions, pg_catalog;

create table public.envelope_definitions (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid references public.profiles(auth_user_id) on delete restrict on update restrict,
  label text not null check (char_length(btrim(label)) between 1 and 120),
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index envelope_definitions_owner_active_idx
  on public.envelope_definitions(owner_user_id, is_active);

create table public.envelope_definition_versions (
  id uuid primary key default gen_random_uuid(),
  envelope_definition_id uuid not null references public.envelope_definitions(id)
    on delete restrict on update restrict,
  version_number integer not null check (version_number > 0),
  category_code text not null check (category_code in
    ('pea', 'cto', 'assurance_vie', 'epargne_liquide', 'immobilier', 'autre')),
  valid_from date not null check (isfinite(valid_from)),
  valid_to date check (isfinite(valid_to)),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint envelope_versions_period_check check (valid_to is null or valid_to > valid_from),
  constraint envelope_versions_number_unique unique (envelope_definition_id, version_number),
  constraint envelope_versions_no_overlap exclude using gist
    (envelope_definition_id with =, daterange(valid_from, valid_to, '[)') with &&)
);

alter table public.envelopes
  add column envelope_definition_id uuid references public.envelope_definitions(id)
    on delete restrict on update restrict,
  add column opened_on date,
  add column closed_on date,
  alter column name drop not null,
  alter column envelope_type_code drop not null,
  add constraint envelopes_dates_check check (
    (opened_on is null or isfinite(opened_on)) and
    (closed_on is null or isfinite(closed_on)) and
    (closed_on is null or opened_on is null or closed_on >= opened_on)),
  add constraint envelopes_reference_or_legacy_check check (
    envelope_definition_id is not null or envelope_type_code is not null),
  add constraint envelopes_display_name_check check (
    envelope_definition_id is not null or name is not null);
create index envelopes_definition_idx on public.envelopes(envelope_definition_id);
comment on column public.envelopes.envelope_type_code is
  'Authority only while envelope_definition_id is NULL. Once linked, retained legacy provenance only; never used to classify the linked definition.';
comment on column public.envelopes.opened_on is
  'Business opening date; unknown historical dates remain NULL, never inferred from created_at.';

-- Stable ownership makes the authorization invariant independent of concurrent
-- owner changes. Promotion/ownership transfer is deliberately NOT implemented.
create function public.guard_envelope_definition_identity()
returns trigger language plpgsql security invoker set search_path = '' as $$
begin
  if new.id is distinct from old.id or new.owner_user_id is distinct from old.owner_user_id then
    raise exception 'definition identity and ownership are immutable' using errcode = '23514';
  end if;
  return new;
end;
$$;
create trigger envelope_definitions_guard_identity before update on public.envelope_definitions
  for each row execute function public.guard_envelope_definition_identity();

-- SECURITY DEFINER permits locking a global reference without granting users
-- UPDATE on it. The helper returns no data and cannot be called as an RPC.
create function public.validate_envelope_definition_use()
returns trigger language plpgsql security definer set search_path = '' as $$
declare definition_owner uuid; definition_active boolean;
begin
  if tg_op = 'UPDATE' then
    if old.envelope_definition_id is null and new.envelope_definition_id is not null
       and new.envelope_type_code is distinct from old.envelope_type_code then
      raise exception 'explicit attachment must preserve legacy provenance' using errcode = '23514';
    end if;
    if old.envelope_definition_id is not null and
       new.envelope_definition_id is distinct from old.envelope_definition_id then
      raise exception 'reference replacement is not enabled in this structural lot' using errcode = '23514';
    end if;
    if old.envelope_definition_id is not null and
       new.envelope_type_code is distinct from old.envelope_type_code then
      raise exception 'linked legacy code is read-only provenance' using errcode = '23514';
    end if;
  elsif new.envelope_definition_id is not null and new.envelope_type_code is not null then
    raise exception 'new linked envelopes must not supply a legacy classification' using errcode = '23514';
  end if;
  if new.envelope_definition_id is null then return new; end if;
  -- Alias/activation changes to already linked instances remain possible even
  -- after catalogue deactivation. Only new links/owner changes require active.
  if tg_op = 'UPDATE' then
    if new.envelope_definition_id is not distinct from old.envelope_definition_id
       and new.user_id is not distinct from old.user_id then return new; end if;
  end if;
  select owner_user_id, is_active into definition_owner, definition_active
    from public.envelope_definitions where id = new.envelope_definition_id for share;
  if not found or not definition_active or
     (definition_owner is not null and definition_owner <> new.user_id) then
    raise exception 'definition is not available for this envelope' using errcode = '42501';
  end if;
  return new;
end;
$$;
create trigger envelopes_validate_definition before insert or update on public.envelopes
  for each row execute function public.validate_envelope_definition_use();

-- No retroactive publication; historical imports require a separately reviewed
-- migration. A version's content is immutable. Only its open/future end may be
-- shortened prospectively, followed by INSERT of a successor in one transaction.
create function public.guard_envelope_version_history()
returns trigger language plpgsql security invoker set search_path = '' as $$
begin
  if tg_op = 'DELETE' then
    raise exception 'version history cannot be deleted' using errcode = '23514';
  elsif tg_op = 'INSERT' then
    if new.valid_from < current_date then
      raise exception 'retroactive version publication is not enabled' using errcode = '23514';
    end if;
  else
    if (to_jsonb(new) - 'valid_to' - 'updated_at') is distinct from
       (to_jsonb(old) - 'valid_to' - 'updated_at') then
      raise exception 'create a new business version instead' using errcode = '23514';
    end if;
    if new.valid_to is distinct from old.valid_to and
       (new.valid_to is null or new.valid_to < current_date or
        (old.valid_to is not null and new.valid_to > old.valid_to)) then
      raise exception 'only prospective shortening is permitted' using errcode = '23514';
    end if;
  end if;
  return new;
end;
$$;
create trigger envelope_versions_guard_history before insert or update or delete
  on public.envelope_definition_versions for each row execute function public.guard_envelope_version_history();

create trigger envelope_definitions_set_updated_at before update on public.envelope_definitions
  for each row execute function public.set_updated_at();
create trigger envelope_versions_set_updated_at before update on public.envelope_definition_versions
  for each row execute function public.set_updated_at();

alter table public.envelope_definitions enable row level security;
alter table public.envelope_definitions force row level security;
alter table public.envelope_definition_versions enable row level security;
alter table public.envelope_definition_versions force row level security;
revoke all on public.envelope_definitions, public.envelope_definition_versions from public, anon, authenticated;
grant select, insert on public.envelope_definitions, public.envelope_definition_versions to authenticated;
grant update(label, description, is_active) on public.envelope_definitions to authenticated;
grant update(valid_to) on public.envelope_definition_versions to authenticated;

create policy envelope_definitions_read on public.envelope_definitions for select to authenticated
  using (owner_user_id is null or owner_user_id = auth.uid());
create policy envelope_definitions_insert on public.envelope_definitions for insert to authenticated
  with check (owner_user_id = auth.uid() or (owner_user_id is null and public.is_admin()));
create policy envelope_definitions_update on public.envelope_definitions for update to authenticated
  using (owner_user_id = auth.uid() or (owner_user_id is null and public.is_admin()))
  with check (owner_user_id = auth.uid() or (owner_user_id is null and public.is_admin()));
create policy envelope_versions_read on public.envelope_definition_versions for select to authenticated
  using (exists (select 1 from public.envelope_definitions d where d.id = envelope_definition_id));
create policy envelope_versions_insert on public.envelope_definition_versions for insert to authenticated
  with check (exists (select 1 from public.envelope_definitions d where d.id = envelope_definition_id
    and (d.owner_user_id = auth.uid() or (d.owner_user_id is null and public.is_admin()))));
create policy envelope_versions_update on public.envelope_definition_versions for update to authenticated
  using (exists (select 1 from public.envelope_definitions d where d.id = envelope_definition_id
    and (d.owner_user_id = auth.uid() or (d.owner_user_id is null and public.is_admin()))))
  with check (exists (select 1 from public.envelope_definitions d where d.id = envelope_definition_id
    and (d.owner_user_id = auth.uid() or (d.owner_user_id is null and public.is_admin()))));

-- Legacy fiscal rows are preserved verbatim and remain in the legacy global
-- domain. No fixture is attached, no private fiscal authoring is opened.
alter table public.fiscal_rules add column envelope_definition_version_id uuid
  references public.envelope_definition_versions(id) on delete restrict on update restrict;
create index fiscal_rules_envelope_version_idx on public.fiscal_rules(envelope_definition_version_id);
create unique index fiscal_rules_linked_identity_idx
  on public.fiscal_rules(envelope_definition_version_id, rule_code, valid_from)
  where envelope_definition_version_id is not null;
comment on column public.fiscal_rules.envelope_definition_version_id is
  'NULL = unclassified legacy rule, not automatically applicable. Linked rules belong to a global version only in this first lot.';

drop policy fiscal_rules_read_authenticated on public.fiscal_rules;
create policy fiscal_rules_read_authenticated on public.fiscal_rules for select to authenticated
  using (envelope_definition_version_id is null or exists (
    select 1 from public.envelope_definition_versions v
    join public.envelope_definitions d on d.id = v.envelope_definition_id
    where v.id = envelope_definition_version_id and d.owner_user_id is null));

create function public.guard_linked_fiscal_history()
returns trigger language plpgsql security definer set search_path = '' as $$
declare version_start date; definition_owner uuid;
begin
  if tg_op <> 'INSERT' then
    if old.envelope_definition_version_id is not null then
      raise exception 'linked fiscal history is immutable; create a new version' using errcode = '23514';
    end if;
    if tg_op = 'DELETE' then return old; end if;
  end if;
  if new.envelope_definition_version_id is null then return new; end if;
  select v.valid_from, d.owner_user_id into version_start, definition_owner
    from public.envelope_definition_versions v
    join public.envelope_definitions d on d.id = v.envelope_definition_id
    where v.id = new.envelope_definition_version_id for share of v, d;
  if not found or definition_owner is not null then
    raise exception 'only global fiscal versions are supported in this lot' using errcode = '23514';
  end if;
  if version_start <= current_date or new.valid_from < version_start then
    raise exception 'fiscal rules must be prepared for a future version' using errcode = '23514';
  end if;
  return new;
end;
$$;
create trigger fiscal_rules_guard_linked_history before insert or update or delete on public.fiscal_rules
  for each row execute function public.guard_linked_fiscal_history();

revoke all on function public.guard_envelope_definition_identity(),
  public.validate_envelope_definition_use(), public.guard_envelope_version_history(),
  public.guard_linked_fiscal_history() from public, anon, authenticated;

-- No UPDATE of existing envelopes/fiscal rules. Explicit later reconciliation
-- is required; NULL dates/references never imply a guessed historical truth.
commit;
