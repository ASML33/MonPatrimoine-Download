-- One Paris civil day throughout validation, storage and correction identity.
-- Existing rows are not rewritten; their civil days must remain unambiguous.
begin;
set local lock_timeout='5s';
set local statement_timeout='30s';
lock table public.asset_prices in share row exclusive mode;
do $check$
begin
 if exists(select 1 from public.asset_prices where origin='manual'
  group by asset_id,user_id,(observed_at at time zone 'Europe/Paris')::date having count(*)>1)
 then raise exception 'Ambiguous Paris manual-price days; reconcile separately' using errcode='23514';end if;
end $check$;
drop index public.asset_prices_manual_daily_unique_idx;
create unique index asset_prices_manual_daily_unique_idx on public.asset_prices
 (asset_id,user_id,((observed_at at time zone 'Europe/Paris')::date)) where origin='manual';
do $patch$
declare signature text; original text; needle text := '''UTC'''; expected integer;
begin
 foreach signature in array array['public.guard_manual_asset_price()', 'public.save_manual_asset_price(uuid,numeric,date)'] loop
  original:=pg_get_functiondef(signature::regprocedure);
  expected:=case when signature='public.guard_manual_asset_price()' then 2 else 3 end;
  if (length(original)-length(replace(original,needle,'')))/length(needle)<>expected then
   raise exception 'Unexpected manual price calendar guard: %',signature;
  end if;
  execute replace(original,needle,'''Europe/Paris''');
 end loop;
end $patch$;
comment on index public.asset_prices_manual_daily_unique_idx is 'One manual price per asset, owner and Europe/Paris civil day.';
comment on function public.save_manual_asset_price(uuid,numeric,date) is 'Insert or correct one Paris civil-day manual price, stored at Paris midnight.';
notify pgrst,'reload schema';
commit;
