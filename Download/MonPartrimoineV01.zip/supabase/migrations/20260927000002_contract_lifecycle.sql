-- Phase 7.2: private contract lifecycle; no data rewrite or new reference model.
begin;

create function public.contract_has_dependencies(contract_id uuid)
returns boolean language sql stable security invoker set search_path = '' as $$
  select exists(select 1 from public.positions p where p.contract_id = $1)
    or exists(select 1 from public.cash_balances b where b.contract_id = $1)
    or exists(select 1 from public.cash_flows f
      where f.source_contract_id = $1 or f.destination_contract_id = $1);
$$;
revoke all on function public.contract_has_dependencies(uuid) from public, anon;
grant execute on function public.contract_has_dependencies(uuid) to authenticated;

-- Preserve the historical parent and stable private identity, even via direct SQL.
create function public.guard_contract_identity()
returns trigger language plpgsql security invoker set search_path = '' as $$
begin
  if new.id is distinct from old.id or new.user_id is distinct from old.user_id
     or new.envelope_id is distinct from old.envelope_id then
    raise exception 'Contract identity and parent are immutable' using errcode = '23514';
  end if;
  return new;
end;
$$;
create trigger contracts_00_identity before update on public.contracts
  for each row execute function public.guard_contract_identity();

-- New/reassigned dependencies and position reactivations must lock and check
-- their contract. A real row write serializes with deactivation, including
-- REPEATABLE READ/SERIALIZABLE (stale writers receive 40001).
-- Existing history/corrections are preserved, not cascaded or deactivated.
create function public.guard_contract_dependency()
returns trigger language plpgsql security definer set search_path = '' as $$
declare col text; contract_id uuid; parent_ids uuid[] := '{}'; active boolean;
  new_row jsonb := to_jsonb(new); old_row jsonb;
begin
  if tg_op = 'UPDATE' then old_row := to_jsonb(old); end if;
  foreach col in array tg_argv loop
    if tg_op = 'UPDATE' and new_row->col is not distinct from old_row->col
       and new.user_id is not distinct from old.user_id
       and not coalesce(new_row->>'is_active' = 'true' and old_row->>'is_active' = 'false', false) then
      continue;
    end if;
    contract_id := (new_row->>col)::uuid;
    if contract_id is not null then parent_ids := array_append(parent_ids, contract_id); end if;
  end loop;
  for contract_id in select distinct unnest(parent_ids) order by 1 loop
    update public.contracts c set updated_at = clock_timestamp()
      where c.id = contract_id and c.user_id = new.user_id
      returning c.is_active into active;
    if not found then raise exception 'Contract unavailable' using errcode = '42501'; end if;
    if not active then
      raise exception 'Contract is inactive; reactivate it first' using errcode = '23514';
    end if;
  end loop;
  return new;
end;
$$;
create trigger positions_00_contract_guard before insert or update on public.positions
  for each row execute function public.guard_contract_dependency('contract_id');
create trigger balances_00_contract_guard before insert or update on public.cash_balances
  for each row execute function public.guard_contract_dependency('contract_id');
create trigger flows_00_contract_guard before insert or update on public.cash_flows
  for each row execute function public.guard_contract_dependency('source_contract_id','destination_contract_id');
revoke all on function public.guard_contract_identity(), public.guard_contract_dependency()
  from public, anon, authenticated;

-- Existing owner RLS, dates, envelope activity guard and ON DELETE RESTRICT FKs
-- remain authoritative. Snapshots depend on positions/balances, not directly on
-- contracts, and are protected by the existing restrictive FK chain.
commit;
