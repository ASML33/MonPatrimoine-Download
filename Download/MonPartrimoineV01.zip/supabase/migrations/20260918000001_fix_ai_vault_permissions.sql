-- Fix Phase 6.6c: vault.secrets SELECT must not require UPDATE privilege.

create or replace function public.save_ai_configuration(
  requested_provider text,
  api_key text default null
)
returns void
language plpgsql
volatile
security definer
set search_path = ''
as $$
declare
  owner_id uuid := auth.uid();
  current_settings jsonb;
  current_provider text;
  secret_id uuid;
  secret_name text;
  next_status text;
begin
  if owner_id is null then
    raise exception 'authentication required' using errcode = '42501';
  end if;

  if requested_provider is null
    or requested_provider not in ('openai', 'anthropic', 'google') then
    raise exception 'invalid AI provider' using errcode = '22023';
  end if;

  if api_key is not null and (
    api_key = '' or api_key <> btrim(api_key) or char_length(api_key) > 4096
  ) then
    raise exception 'invalid API key' using errcode = '22023';
  end if;

  select p.ai_settings
    into current_settings
    from public.profiles p
    where p.auth_user_id = owner_id and p.is_active
    for update;

  if not found then
    raise exception 'AI configuration unavailable' using errcode = '42501';
  end if;

  secret_name := 'monpatrimoine.ai.' || owner_id::text;

  select s.id
    into secret_id
    from vault.secrets s
    where s.name = secret_name;

  current_provider := current_settings ->> 'provider';

  if api_key is null then
    if secret_id is not null
      and current_provider is distinct from requested_provider then
      raise exception 'a new key is required when changing provider'
        using errcode = '22023';
    end if;

    next_status :=
      case
        when secret_id is null then 'not_configured'
        else 'configured'
      end;

  elsif secret_id is null then
    perform vault.create_secret(
      api_key,
      secret_name,
      'MonPatrimoine AI credential for the authenticated user'
    );
    next_status := 'configured';

  else
    perform vault.update_secret(
      secret_id,
      api_key,
      secret_name,
      'MonPatrimoine AI credential for the authenticated user'
    );
    next_status := 'configured';
  end if;

  update public.profiles p
    set ai_settings = current_settings || jsonb_build_object(
      'provider', requested_provider,
      'status', next_status
    )
    where p.auth_user_id = owner_id;
end;
$$;
