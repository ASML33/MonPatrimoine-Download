-- Contract lifecycle dates.  This additive migration intentionally does not
-- backfill opened_on: the real opening date must never be inferred.
alter table public.contracts
  add column opened_on date not null,
  add column closed_on date,
  add constraint contracts_closed_on_not_before_opened_on_check
    check (closed_on is null or closed_on >= opened_on);
