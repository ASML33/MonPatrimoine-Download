-- Phase 4: local consolidation. Apply after the four historical migrations.
-- No Auth account or password is provisioned here.

-- At most one functional administrator, including concurrent privileged writes.
create unique index profiles_single_admin_idx on public.profiles ((role))
  where role = 'admin';

-- Column privileges protect SQL access independently of JWT claims and RLS.
revoke insert, update on public.profiles from public, anon, authenticated;
grant insert (id, auth_user_id, nickname, email, profile_kind, preferences,
  interface_preferences, strategy_parameters, ai_settings, legacy_metadata,
  is_active, created_at, updated_at) on public.profiles to authenticated;
grant update (nickname, email, profile_kind, preferences, interface_preferences,
  strategy_parameters, ai_settings, legacy_metadata, is_active, updated_at)
  on public.profiles to authenticated;

-- Defence in depth; use the SQL caller, never the presence of a JWT subject.
-- SECURITY INVOKER is essential here.
create or replace function public.prevent_profile_role_change()
returns trigger language plpgsql security invoker set search_path = '' as $$
begin
  if current_user in ('authenticated', 'anon') then
    if (tg_op = 'INSERT' and new.role <> 'user') then
      raise exception 'profile role cannot be assigned by an authenticated user'
        using errcode = '42501';
    elsif tg_op = 'UPDATE' then
      if old.role is distinct from new.role then
        raise exception 'profile role cannot be changed by an authenticated user'
          using errcode = '42501';
      end if;
    end if;
  end if;
  return new;
end;
$$;
drop trigger profiles_prevent_role_change on public.profiles;
create trigger profiles_prevent_role_change before insert or update on public.profiles
  for each row execute function public.prevent_profile_role_change();

-- Rebuild the enum before the seed: no historical class targets are converted
-- or silently discarded. An existing class target makes the cast fail.
alter table public.target_allocations drop column target_asset_type_code;
alter type public.allocation_target_kind rename to allocation_target_kind_legacy;
create type public.allocation_target_kind as enum ('envelope', 'asset');
alter table public.target_allocations alter column target_kind
  type public.allocation_target_kind using target_kind::text::public.allocation_target_kind;
drop type public.allocation_target_kind_legacy;
alter table public.target_allocations
  add constraint target_allocations_target_shape_check check (
    (target_kind = 'envelope' and target_envelope_id is not null
      and target_asset_id is null and scope_kind = 'global')
    or (target_kind = 'asset' and target_envelope_id is null and target_asset_id is not null)
  ),
  drop constraint target_allocations_target_percent_check,
  add constraint target_allocations_target_percent_check check (
    (target_percent > 0 and target_percent <= 100)
    or (target_kind = 'asset' and target_percent = -1)
  );
comment on column public.target_allocations.target_percent is
  'Positive percentage (0,100]; -1 only for an individual asset target, excluded from objectives, never from holdings or valuation.';

-- PostgreSQL 15+: NULL global scope participates in uniqueness.
create unique index target_allocations_envelope_unique_idx
  on public.target_allocations (user_id, scope_kind, scope_envelope_id, target_envelope_id)
  nulls not distinct where target_kind = 'envelope';
create unique index target_allocations_asset_unique_idx
  on public.target_allocations (user_id, scope_kind, scope_envelope_id, target_asset_id)
  nulls not distinct where target_kind = 'asset';

-- Serialize allocation writers per owner. A real UPDATE (not merely an advisory
-- lock / SELECT FOR UPDATE) also detects stale REPEATABLE READ snapshots.
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;
create table private.allocation_write_guards (
  user_id uuid primary key references public.profiles(auth_user_id) on delete cascade,
  revision bigint not null default 0
);
revoke all on private.allocation_write_guards from public, anon, authenticated;
alter table private.allocation_write_guards enable row level security;

create function public.serialize_allocation_writes()
returns trigger language plpgsql security definer set search_path = '' as $$
declare owner_id uuid;
begin
  -- Sorted when a privileged UPDATE transfers ownership; ordinary RLS forbids it.
  for owner_id in
    select distinct x from unnest(array[
      case when tg_op <> 'INSERT' then old.user_id end,
      case when tg_op <> 'DELETE' then new.user_id end
    ]) x where x is not null order by x
  loop
    insert into private.allocation_write_guards as g (user_id, revision)
      values (owner_id, 1)
      on conflict (user_id) do update set revision = g.revision + 1;
  end loop;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;
revoke all on function public.serialize_allocation_writes() from public, anon, authenticated;
create trigger target_allocations_serialize_writes
  before insert or update or delete on public.target_allocations
  for each row execute function public.serialize_allocation_writes();

create or replace function public.enforce_target_allocation_total()
returns trigger language plpgsql security definer set search_path = '' as $$
declare total numeric;
begin
  select coalesce(sum(target_percent) filter (where target_percent > 0), 0)
    into total from public.target_allocations
    where user_id = new.user_id and scope_kind = new.scope_kind
      and scope_envelope_id is not distinct from new.scope_envelope_id
      and target_kind = new.target_kind;
  if total > 100 then
    raise exception 'target allocations cannot exceed 100%% for one scope and target kind'
      using errcode = '23514';
  end if;
  return null;
end;
$$;
revoke all on function public.enforce_target_allocation_total() from public, anon, authenticated;

-- Includes empty distributions; invoker/RLS and auth.uid() prevent cross-user
-- inspection. Invalid or inaccessible scopes fail instead of appearing valid.
create function public.target_allocation_status(
  requested_scope public.allocation_scope_kind,
  requested_kind public.allocation_target_kind,
  requested_envelope_id uuid default null
)
returns table (positive_total numeric, remaining_percent numeric, is_complete boolean)
language plpgsql stable security invoker set search_path = '' as $$
begin
  if auth.uid() is null or requested_scope is null or requested_kind is null
    or (requested_scope = 'global' and requested_envelope_id is not null)
    or (requested_scope = 'envelope' and (
      requested_kind <> 'asset' or requested_envelope_id is null or not exists (
        select 1 from public.envelopes where id = requested_envelope_id and user_id = auth.uid()
      ))) then
    raise exception 'invalid or inaccessible allocation scope' using errcode = '22023';
  end if;
  return query
    select total, 100 - total, total = 100 from (
      select coalesce(sum(target_percent) filter (where target_percent > 0), 0) as total
      from public.target_allocations where user_id = auth.uid()
        and scope_kind = requested_scope and target_kind = requested_kind
        and scope_envelope_id is not distinct from requested_envelope_id
    ) s;
end;
$$;
revoke all on function public.target_allocation_status from public, anon, authenticated;
grant execute on function public.target_allocation_status to authenticated;

-- Analytical, extensible structural class; never an allocation target.
comment on column public.assets.asset_type_code is
  'Required extensible structural asset class code; analytical only, distinct from economic sectors.';

create table public.sectors (
  id uuid primary key default gen_random_uuid(),
  taxonomy text not null check (taxonomy ~ '^[a-z0-9_-]{1,50}$'),
  code text not null check (char_length(btrim(code)) between 1 and 50),
  name text not null check (char_length(btrim(name)) between 1 and 120),
  unique (taxonomy, code),
  check (taxonomy <> 'gics' or code ~ '^[0-9]{2}$')
);
-- Official MSCI GICS methodology, April 2026, section 1.2; verified 2026-09-15.
-- https://www.msci.com/indexes/documents/methodology/1_MSCI_Global_Industry_Classification_Standard_GICS_Methodology_20250220.pdf
-- French labels are application translations, not additional GICS categories.
insert into public.sectors (taxonomy, code, name) values
  ('gics','10','Énergie'),
  ('gics','15','Matériaux'),
  ('gics','20','Industrie'),
  ('gics','25','Consommation discrétionnaire'),
  ('gics','30','Consommation de base'),
  ('gics','35','Santé'),
  ('gics','40','Finance'),
  ('gics','45','Technologies de l''information'),
  ('gics','50','Services de communication'),
  ('gics','55','Services aux collectivités'),
  ('gics','60','Immobilier'),
  ('monpatrimoine','unspecified','Non spécifié');

create table public.asset_sector_exposures (
  asset_id uuid not null references public.assets(id) on delete cascade on update cascade,
  sector_id uuid not null references public.sectors(id) on delete restrict on update cascade,
  weight_percent numeric(5,2) not null check (weight_percent > 0 and weight_percent <= 100),
  primary key (asset_id, sector_id)
);
create index asset_sector_exposures_sector_idx on public.asset_sector_exposures(sector_id);
comment on table public.asset_sector_exposures is
  'Current weights only. Finalize to 100 with monpatrimoine/unspecified for the unknown remainder; never normalize known weights.';

alter table public.sectors enable row level security;
alter table public.sectors force row level security;
alter table public.asset_sector_exposures enable row level security;
alter table public.asset_sector_exposures force row level security;
revoke all on public.sectors, public.asset_sector_exposures from public, anon, authenticated;
grant select on public.sectors to authenticated;
grant select, insert, update, delete on public.asset_sector_exposures to authenticated;
create policy sectors_read_authenticated on public.sectors for select to authenticated using (true);
create policy asset_sector_exposures_read on public.asset_sector_exposures for select to authenticated
  using (exists (select 1 from public.assets a where a.id = asset_id));
create policy asset_sector_exposures_insert on public.asset_sector_exposures for insert to authenticated
  with check (exists (select 1 from public.assets a where a.id = asset_id and a.owner_user_id = auth.uid()));
create policy asset_sector_exposures_update on public.asset_sector_exposures for update to authenticated
  using (exists (select 1 from public.assets a where a.id = asset_id and a.owner_user_id = auth.uid()))
  with check (exists (select 1 from public.assets a where a.id = asset_id and a.owner_user_id = auth.uid()));
create policy asset_sector_exposures_delete on public.asset_sector_exposures for delete to authenticated
  using (exists (select 1 from public.assets a where a.id = asset_id and a.owner_user_id = auth.uid()));

create table private.sector_write_guards (
  asset_id uuid primary key references public.assets(id) on delete cascade on update cascade,
  revision bigint not null default 0
);
alter table private.sector_write_guards enable row level security;
revoke all on private.sector_write_guards from public, anon, authenticated;
create function public.serialize_sector_writes()
returns trigger language plpgsql security definer set search_path = '' as $$
declare affected_asset uuid;
begin
  for affected_asset in select distinct x from unnest(array[
    case when tg_op <> 'INSERT' then old.asset_id end,
    case when tg_op <> 'DELETE' then new.asset_id end
  ]) x where x is not null order by x loop
    -- During ON DELETE CASCADE the parent may already be gone.
    if exists (select 1 from public.assets where id = affected_asset) then
      insert into private.sector_write_guards as g (asset_id, revision)
        values (affected_asset, 1)
        on conflict (asset_id) do update set revision = g.revision + 1;
    end if;
  end loop;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end;
$$;
revoke all on function public.serialize_sector_writes() from public, anon, authenticated;
create trigger asset_sector_exposures_serialize before insert or update or delete
  on public.asset_sector_exposures for each row execute function public.serialize_sector_writes();
create function public.enforce_sector_total()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if (select coalesce(sum(weight_percent),0) from public.asset_sector_exposures
      where asset_id = new.asset_id) > 100 then
    raise exception 'sector exposures cannot exceed 100%% per asset' using errcode = '23514';
  end if;
  return null;
end;
$$;
revoke all on function public.enforce_sector_total() from public, anon, authenticated;
create constraint trigger asset_sector_exposures_total_check
  after insert or update on public.asset_sector_exposures deferrable initially deferred
  for each row execute function public.enforce_sector_total();

create function public.asset_sector_status(requested_asset_id uuid)
returns table (total_percent numeric, remaining_percent numeric, is_complete boolean)
language plpgsql stable security invoker set search_path = '' as $$
begin
  if not exists (select 1 from public.assets where id = requested_asset_id) then
    raise exception 'asset is not accessible' using errcode = '42501';
  end if;
  return query select total, 100-total, total=100 from (
    select coalesce(sum(weight_percent),0) as total from public.asset_sector_exposures
      where asset_id = requested_asset_id
  ) s;
end;
$$;
revoke all on function public.asset_sector_status from public, anon, authenticated;
grant execute on function public.asset_sector_status to authenticated;

-- Composite FK enforces the global-only invariant even for privileged writes
-- and concurrent changes of asset ownership. No procedural race to maintain.
alter table public.assets add column is_global boolean
  generated always as (owner_user_id is null) stored;
alter table public.assets add constraint assets_id_is_global_unique unique (id, is_global);
create table public.user_asset_sector_exposures (
  user_id uuid not null references public.profiles(auth_user_id) on delete cascade on update cascade,
  asset_id uuid not null,
  sector_id uuid not null references public.sectors(id) on delete restrict on update cascade,
  weight_percent numeric(5,2) not null check (weight_percent > 0 and weight_percent <= 100),
  asset_is_global boolean generated always as (true) stored,
  primary key (user_id, asset_id, sector_id),
  foreign key (asset_id, asset_is_global) references public.assets(id, is_global)
    on delete cascade on update restrict
);
create index user_asset_sector_exposures_asset_idx on public.user_asset_sector_exposures(asset_id);
create index user_asset_sector_exposures_sector_idx on public.user_asset_sector_exposures(sector_id);
comment on table public.user_asset_sector_exposures is
  'Current complete replacement for one user/global asset, never a delta. Incomplete drafts do not override the catalogue.';
alter table public.user_asset_sector_exposures enable row level security;
alter table public.user_asset_sector_exposures force row level security;
revoke all on public.user_asset_sector_exposures from public, anon, authenticated;
grant select, insert, update, delete on public.user_asset_sector_exposures to authenticated;
create policy user_asset_sector_exposures_read on public.user_asset_sector_exposures
  for select to authenticated using (user_id = auth.uid() and exists (
    select 1 from public.assets a where a.id = asset_id and a.owner_user_id is null));
create policy user_asset_sector_exposures_insert on public.user_asset_sector_exposures
  for insert to authenticated with check (user_id = auth.uid() and exists (
    select 1 from public.assets a where a.id = asset_id and a.owner_user_id is null));
create policy user_asset_sector_exposures_update on public.user_asset_sector_exposures
  for update to authenticated
  using (user_id = auth.uid() and exists (
    select 1 from public.assets a where a.id = asset_id and a.owner_user_id is null))
  with check (user_id = auth.uid() and exists (
    select 1 from public.assets a where a.id = asset_id and a.owner_user_id is null));
create policy user_asset_sector_exposures_delete on public.user_asset_sector_exposures
  for delete to authenticated using (user_id = auth.uid() and exists (
    select 1 from public.assets a where a.id = asset_id and a.owner_user_id is null));

-- Reuse the per-asset guard: catalogue and all personal writes for the same
-- asset serialize. Different assets remain independent. No new history table.
create trigger user_asset_sector_exposures_serialize before insert or update or delete
  on public.user_asset_sector_exposures for each row execute function public.serialize_sector_writes();
create function public.enforce_user_sector_total()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if (select coalesce(sum(weight_percent),0) from public.user_asset_sector_exposures
      where user_id = new.user_id and asset_id = new.asset_id) > 100 then
    raise exception 'personal sector exposures cannot exceed 100%% per user and asset' using errcode = '23514';
  end if;
  return null;
end;
$$;
revoke all on function public.enforce_user_sector_total() from public, anon, authenticated;
create constraint trigger user_asset_sector_exposures_total_check
  after insert or update on public.user_asset_sector_exposures deferrable initially deferred
  for each row execute function public.enforce_user_sector_total();

create function public.user_asset_sector_status(requested_asset_id uuid)
returns table (has_override boolean, total_percent numeric, remaining_percent numeric, is_complete boolean)
language plpgsql stable security invoker set search_path = '' as $$
begin
  if auth.uid() is null or not exists (select 1 from public.assets
    where id = requested_asset_id and owner_user_id is null) then
    raise exception 'global asset is not accessible' using errcode = '42501';
  end if;
  return query select n > 0, total, 100-total, total=100 from (
    select count(*) as n, coalesce(sum(weight_percent),0) as total
    from public.user_asset_sector_exposures
    where user_id = auth.uid() and asset_id = requested_asset_id
  ) s;
end;
$$;
revoke all on function public.user_asset_sector_status(uuid) from public, anon, authenticated;
grant execute on function public.user_asset_sector_status(uuid) to authenticated;

create function public.effective_asset_sector_exposures(requested_asset_id uuid)
returns table (sector_id uuid, weight_percent numeric, source text)
language plpgsql stable security invoker set search_path = '' as $$
declare global_asset boolean; use_override boolean := false;
begin
  if auth.uid() is null then
    raise exception 'authentication required' using errcode = '42501';
  end if;
  select a.owner_user_id is null into global_asset from public.assets a where a.id = requested_asset_id;
  if not found then
    raise exception 'asset is not accessible' using errcode = '42501';
  end if;
  if global_asset then
    select s.is_complete into use_override from public.user_asset_sector_status(requested_asset_id) s;
  end if;
  if use_override then
    return query select e.sector_id, e.weight_percent, 'personal'::text
      from public.user_asset_sector_exposures e
      where e.user_id = auth.uid() and e.asset_id = requested_asset_id;
  else
    return query select e.sector_id, e.weight_percent,
      case when global_asset then 'catalogue'::text else 'private'::text end
      from public.asset_sector_exposures e where e.asset_id = requested_asset_id;
  end if;
end;
$$;
revoke all on function public.effective_asset_sector_exposures(uuid) from public, anon, authenticated;
grant execute on function public.effective_asset_sector_exposures(uuid) to authenticated;

-- Identity domains: shared catalogue, then each private owner independently.
drop index public.assets_isin_unique_idx;
drop index public.assets_owner_symbol_unique_idx;
create unique index assets_owner_isin_unique_idx on public.assets (owner_user_id, isin)
  nulls not distinct where isin is not null;
create unique index assets_owner_symbol_unique_idx
  on public.assets (owner_user_id, lower(btrim(symbol)))
  nulls not distinct where symbol is not null;
alter table public.assets add constraint assets_symbol_not_blank_check
  check (symbol is null or char_length(btrim(symbol)) > 0);

-- Explicit grants, independent of Supabase's default ACLs.
revoke all on all tables in schema public from anon;
revoke all on all tables in schema public from public;
revoke all on function public.is_admin() from anon;
