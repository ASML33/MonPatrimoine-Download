-- Local candidate only. No existing business row is changed by installation.
begin;set local lock_timeout='5s';set local statement_timeout='40s';
do $conservation_predecessor$begin
 if private.app_backup_schema()<>'237871bc6c514a148fbb9da4331506d574b1abf41368c61a67177bdd04a2c86a'or md5(pg_get_functiondef('private.app_backup_upgrade(jsonb)'::regprocedure))<>'fe6019cbe4daaa245c5a908113fe156d'then raise exception'CTO-CONSERVATION-PREDECESSOR';end if;
end$conservation_predecessor$;

do $p$begin
if md5(pg_get_functiondef('public.preview_position_observation(uuid,uuid,uuid,uuid,date,numeric,numeric,text)'::regprocedure))<>'5910a087e4388cfb49410cef1adcd776'or md5(pg_get_functiondef('public.guard_position_observations()'::regprocedure))<>'de832104dedf6357f2c85f22a3f953fe'or md5(pg_get_functiondef('public.save_securities_position_action(uuid,uuid,uuid,uuid,date,numeric,numeric,text,timestamptz,uuid)'::regprocedure))<>'173374a0d98fe033e626dffaac729385'then raise exception'CTO-ACQUISITION-PREDECESSOR';end if;end$p$;
CREATE OR REPLACE FUNCTION public.preview_position_observation(requested_contract uuid, requested_asset uuid, requested_position uuid, requested_observation uuid, requested_date date, requested_quantity numeric, requested_cost numeric, requested_currency text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SET search_path TO ''
AS $function$
declare p public.positions; h jsonb; entries jsonb; previous jsonb; incoming jsonb; next_entries jsonb; plan jsonb; oid uuid:=coalesce(requested_observation,gen_random_uuid()); state_hash text; stamp timestamptz:=clock_timestamp(); parent public.contracts;
begin
 if auth.uid() is null or not public.is_authorized_user() then raise exception 'Unauthorized' using errcode='42501';end if;
 select * into parent from public.contracts where id=requested_contract and user_id=auth.uid();
 if not found or not parent.is_active then raise exception 'Active contract required' using errcode='42501';end if;
 if requested_date is null or requested_date>(stamp at time zone 'Europe/Paris')::date or requested_date<parent.opened_on
 or requested_quantity is null or requested_quantity<0 or requested_quantity>=1e16 or requested_quantity<>round(requested_quantity,8)
 or requested_cost<0 or requested_cost>=1e16 or (requested_cost<>round(requested_cost,8)and not public.cto_broker_cost_precision(requested_contract,requested_asset,requested_date,requested_cost,requested_currency)and not(requested_cost=round(requested_cost,20)and exists(select 1 from public.contracts cc join public.envelope_types ee on ee.id=cc.envelope_type_id where cc.id=requested_contract and cc.user_id=auth.uid()and ee.code in('cto','compte_titres'))))
 or not exists(select 1 from public.currencies where code=requested_currency and is_active) then raise exception 'Invalid dated holding' using errcode='22023';end if;
 select * into p from public.positions where contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid();
 if requested_position is not null and p.id is distinct from requested_position then raise exception 'Position unavailable' using errcode='40001';end if;
 if p.id is null then
  if not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required' using errcode='42501';end if;
 elsif not p.is_active and not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required for reactivation' using errcode='23514';end if;
 h:=coalesce(p.metadata->'position_observations',jsonb_build_object('version',1,'entries','[]'::jsonb,'archived','[]'::jsonb,'bindings','[]'::jsonb,'receipts','[]'::jsonb));
 entries:=h->'entries';select e into previous from jsonb_array_elements(entries) e where e->>'id'=oid::text;
 incoming:=jsonb_build_object('id',oid,'version',coalesce((previous->>'version')::int,0)+1,'effectiveOn',requested_date,'quantity',requested_quantity::text,'unitCost',case when requested_cost is null then null else requested_cost::text end,'currency',requested_currency,'recordedAt',stamp,'provenance','Situation saisie et confirmée par l’utilisateur');
 select coalesce(jsonb_agg(e order by e->>'effectiveOn'),'[]') into next_entries from jsonb_array_elements(entries) e where e->>'id'<>oid::text and case when exists(select 1 from public.envelope_types t where t.id=parent.envelope_type_id and t.code in('pea','pea_pme','cto','compte_titres'))then (e->>'effectiveOn')::date<requested_date else e->>'effectiveOn'<>requested_date::text end;
 if previous is not null and (previous->>'effectiveOn')::date=requested_date and (previous->>'quantity')::numeric=requested_quantity and (previous->>'unitCost')::numeric is not distinct from requested_cost and previous->>'currency'=requested_currency then incoming:=previous;end if;
 next_entries:=next_entries||jsonb_build_array(incoming);
 if p.id is not null and p.quantity=0 and coalesce((public.position_observation_at(next_entries,(stamp at time zone 'Europe/Paris')::date)->>'quantity')::numeric,0)>0 and not exists(select 1 from public.assets where id=requested_asset and owner_user_id=auth.uid() and is_active) then raise exception 'Active asset required for renewed holding' using errcode='23514';end if;
 plan:=public.position_capture_plan(requested_contract,requested_asset,entries,next_entries);
 select md5(coalesce(jsonb_agg(jsonb_build_array(id,revision,inputs,result) order by id)::text,'')) into state_hash from public.patrimonial_daily_captures where user_id=auth.uid() and state='published';
 state_hash:=md5(state_hash||coalesce((select jsonb_agg(jsonb_build_array(id,payload) order by id)::text from public.patrimonial_legacy_sources where user_id=auth.uid()),''));
 return plan||jsonb_build_object('observation',incoming,'previous',previous,'nextEntries',next_entries,'history',h,'position',to_jsonb(p),'destination', (select e from jsonb_array_elements(entries) e where e->>'effectiveOn'=requested_date::text and e->>'id'<>oid::text),'token',md5(coalesce(to_jsonb(p)::text,'null')||state_hash||jsonb_build_array(requested_contract,requested_asset,oid,requested_date,requested_quantity,requested_cost,requested_currency)::text));
end$function$;
CREATE OR REPLACE FUNCTION public.guard_position_observations()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare h jsonb; prior jsonb; e jsonb; latest jsonb; seen date[]:='{}'; ids text[]:='{}'; d date; needed jsonb; b jsonb; receipt jsonb; verified jsonb; correction text;
begin
 if public.app_restore_permitted(tg_relid,tg_op,case when tg_op='INSERT' then null else to_jsonb(old) end,case when tg_op='DELETE' then null else to_jsonb(new) end) then if tg_op='DELETE' then return old;else return new;end if;end if;

 if tg_op<>'DELETE' and private.property_permitted('position',case when tg_op='UPDATE' then to_jsonb(old) else null end,to_jsonb(new)) then return new;end if;
 
 if tg_op='DELETE' and auth.uid()=old.user_id and public.is_authorized_user()
  and old.metadata=jsonb_build_object('initial_amount',jsonb_build_object('version',1,'kind','empty_euro_fund'))
  and old.quantity is null and old.average_cost_per_unit is null and old.opened_on is null
  and not exists(select 1 from public.contracts where id=old.contract_id)
  and not exists(select 1 from public.position_snapshots where position_id=old.id)
 then return old;end if;
 if tg_op='DELETE' and old.metadata ? 'initial_amount' then raise exception 'Monetary proof must be reconciled, not deleted' using errcode='23514';end if; if tg_op='DELETE' then if old.metadata ? 'position_observations' then raise exception 'Dated holding must be closed with zero' using errcode='23514';end if;return old;end if;

 if tg_op='INSERT' and new.metadata ? 'initial_amount' then
  -- Already fully validated by positions_00_amount_validation, before the
  -- ordinary parent-use triggers. Those triggers and owner RLS still apply.
  return new;
 end if;
 if tg_op='UPDATE' and new.metadata->'initial_amount' is distinct from old.metadata->'initial_amount' then
  raise exception 'Initial monetary provenance is immutable' using errcode='23514';end if;
 h:=new.metadata->'position_observations';
 if tg_op='UPDATE' then
  if (new.id,new.user_id,new.contract_id,new.asset_id) is distinct from (old.id,old.user_id,old.contract_id,old.asset_id) then raise exception 'Position identity is immutable' using errcode='23514';end if;
  prior:=old.metadata->'position_observations';
  if prior is not null and not new.is_active then raise exception 'Close dated holding with zero, keeping its identity' using errcode='23514';end if;
  if h is not distinct from prior and (new.quantity,new.average_cost_per_unit,new.cost_currency_code) is not distinct from (old.quantity,old.average_cost_per_unit,old.cost_currency_code) then return new;end if;
 end if;
 if h is null or h->>'version' is distinct from '1' or jsonb_typeof(h->'entries') is distinct from 'array' or jsonb_typeof(h->'archived') is distinct from 'array' or jsonb_typeof(h->'bindings') is distinct from 'array' or jsonb_typeof(h->'receipts') is distinct from 'array' or jsonb_array_length(h->'entries')=0 then raise exception 'Dated observation required' using errcode='23514';end if;
 -- Verify the complete canonical preview even for direct table writes. No caller
 -- supplied flag, schema privilege or bypass of the existing owner RLS is used.
 perform 1 from public.contracts where id=new.contract_id and user_id=auth.uid() for update;
 perform public.lock_position_capture_sources();
 receipt:=h#>'{receipts,-1}'; correction:=receipt->>'id';
 perform correction::uuid;
 if correction is null or jsonb_typeof(receipt->'request') is distinct from 'array' or jsonb_array_length(receipt->'request')<>7
  or (h->'receipts')-(jsonb_array_length(h->'receipts')-1) is distinct from coalesce(prior->'receipts','[]') then raise exception 'Confirmation trace required' using errcode='23514';end if;
 if receipt#>>'{request,0}' is distinct from new.contract_id::text or receipt#>>'{request,1}' is distinct from new.asset_id::text then raise exception 'Confirmation identity differs' using errcode='23514';end if;
 verified:=public.preview_position_observation(new.contract_id,new.asset_id,case when tg_op='UPDATE' then old.id else null end,
  (receipt#>>'{request,2}')::uuid,(receipt#>>'{request,3}')::date,(receipt#>>'{request,4}')::numeric,(receipt#>>'{request,5}')::numeric,receipt#>>'{request,6}');
 select coalesce(jsonb_agg(case when v->>'id'=receipt#>>'{request,2}' then v||jsonb_build_object('recordedAt',(select n->'recordedAt' from jsonb_array_elements(h->'entries') n where n->>'id'=v->>'id')) else v end order by ord),'[]') into e from jsonb_array_elements(verified->'nextEntries') with ordinality t(v,ord);
 verified:=verified||jsonb_build_object('nextEntries',e);
 if h#>'{archived,-1,undatedPrevious}' is distinct from (case when tg_op='UPDATE' and prior is null then jsonb_build_object('quantity',old.quantity::text,'unitCost',case when old.average_cost_per_unit is null then null else old.average_cost_per_unit::text end,'currency',old.cost_currency_code,'isActive',old.is_active) else 'null'::jsonb end) then raise exception 'Undated previous situation must be preserved without inventing a date' using errcode='23514';end if;
 if (h#>>'{archived,-1,replacedAt}')::timestamptz<statement_timestamp() or (h#>>'{archived,-1,replacedAt}')::timestamptz>clock_timestamp() then raise exception 'Invalid correction timestamp' using errcode='23514';end if;
 if verified->>'token' is distinct from receipt->>'token' or verified->'nextEntries' is distinct from h->'entries'
  or verified->'review' is distinct from h->'lastReview' or h#>>'{archived,-1,correctionId}' is distinct from correction
  or h#>>'{archived,-1,replacedAt}' is null then raise exception 'Observation differs from confirmed preview' using errcode='40001';end if;
 for e in select value from jsonb_array_elements(h->'entries') loop
  d:=(e->>'effectiveOn')::date;
  if d is null or e->>'id' is null or jsonb_typeof(e->'quantity') is distinct from 'string' or not (e ? 'unitCost') or jsonb_typeof(e->'unitCost') not in ('string','null') or e->>'version' is null or d=any(seen) or e->>'id'=any(ids) or d>(clock_timestamp() at time zone 'Europe/Paris')::date
   or e->>'quantity' is null or (e->>'quantity')::numeric<0 or (e->>'quantity')::numeric>=1e16 or (e->>'quantity')::numeric<>round((e->>'quantity')::numeric,8)
   or (e->>'unitCost')::numeric<0 or (e->>'unitCost')::numeric>=1e16 or ((e->>'unitCost')::numeric<>round((e->>'unitCost')::numeric,8)and not public.cto_broker_cost_precision(new.contract_id,new.asset_id,d,(e->>'unitCost')::numeric,e->>'currency')and not((e->>'unitCost')::numeric=round((e->>'unitCost')::numeric,20)and exists(select 1 from public.contracts cc join public.envelope_types ee on ee.id=cc.envelope_type_id where cc.id=new.contract_id and cc.user_id=auth.uid()and ee.code in('cto','compte_titres'))))
   or not exists(select 1 from public.currencies where code=e->>'currency' and is_active)
   or (e->>'version')::int<1 or e->>'recordedAt' is null or (e->>'recordedAt')::timestamptz>clock_timestamp() then raise exception 'Invalid position history' using errcode='23514';end if;
  if e->>'id'=receipt#>>'{request,2}' and (e->>'recordedAt')::timestamptz<statement_timestamp() then raise exception 'Observation timestamp must be recorded by this operation' using errcode='23514';end if;
  perform (e->>'id')::uuid;seen:=array_append(seen,d);ids:=array_append(ids,e->>'id');
 end loop;
 latest:=public.position_observation_at(h->'entries',(clock_timestamp() at time zone 'Europe/Paris')::date);
 if (new.quantity,new.average_cost_per_unit,btrim(new.cost_currency_code)) is distinct from ((latest->>'quantity')::numeric,(latest->>'unitCost')::numeric,latest->>'currency') then raise exception 'Current holding differs from history' using errcode='23514';end if;
 if jsonb_array_length(h->'archived')<>coalesce(jsonb_array_length(prior->'archived'),0)+1 or (h->'archived')-(jsonb_array_length(h->'archived')-1) is distinct from coalesce(prior->'archived','[]') or h#>'{archived,-1,entries}' is distinct from coalesce(prior->'entries','[]') then raise exception 'Previous versions must be preserved' using errcode='23514';end if;
 needed:=public.position_capture_plan(new.contract_id,new.asset_id,coalesce(prior->'entries','[]'),h->'entries');
 if jsonb_array_length(h->'bindings')<>coalesce(jsonb_array_length(prior->'bindings'),0)+jsonb_array_length(needed->'bindings') then raise exception 'Capture replacements missing' using errcode='23514';end if;
 for b in select value from jsonb_array_elements(needed->'bindings') loop
  if not exists(select 1 from jsonb_array_elements(h->'bindings') with ordinality t(n,ord) where ord>coalesce(jsonb_array_length(prior->'bindings'),0) and n-'correctionId'=b and n->>'correctionId'=correction) then raise exception 'Invalid capture replacement' using errcode='23514';end if;
 end loop;
 if prior is not null then
  if (select coalesce(jsonb_agg(value order by ord),'[]') from jsonb_array_elements(h->'bindings') with ordinality t(value,ord) where ord<=jsonb_array_length(prior->'bindings')) is distinct from prior->'bindings' then raise exception 'Capture trace changed' using errcode='23514';end if;
  for e in select value from jsonb_array_elements(prior->'bindings') loop if not (h->'bindings') @> jsonb_build_array(e) then raise exception 'Capture trace removed' using errcode='23514';end if;end loop;
 end if;
 return new;
end$function$;

-- Ephemeral server work queue, not a financial ledger. Committed evidence and
-- idempotency remain in the existing conserved position/receipt datasets.
create table private.cto_acquisition_fx_preparations(
 user_id uuid not null,request_id uuid not null,submission jsonb not null,
 native_values jsonb not null,state text not null check(state in('preparing','ready')),
 claim uuid not null default gen_random_uuid(),deadline timestamptz not null default(clock_timestamp()+interval '15 seconds'),
 attempts int not null default 0 check(attempts between 0 and 3),attempt_log jsonb not null default'[]',fx_plan jsonb,
 primary key(user_id,request_id));
alter table private.cto_acquisition_fx_preparations enable row level security;
alter table private.cto_acquisition_fx_preparations force row level security;
revoke all on private.cto_acquisition_fx_preparations from public,anon,authenticated,service_role;

create function private.cto_valid_fx(r public.fx_rates)returns boolean language sql stable set search_path=''as $$
 select r.currency_code<>'EUR'and r.eur_per_unit>0 and r.eur_per_unit<'1e16'::numeric
 and r.source in('ecb','frankfurter','manual')and r.observed_on<=r.requested_on
 and r.requested_on<=(r.obtained_at at time zone'Europe/Paris')::date and r.obtained_at<=clock_timestamp()
 and coalesce(r.provider_metadata->>'base',btrim(r.currency_code))=btrim(r.currency_code)
 and coalesce(r.provider_metadata->>'quote','EUR')='EUR'
 and coalesce(r.provider_metadata->>'direction','EUR_per_native_unit')='EUR_per_native_unit'
 and coalesce(r.provider_metadata->>'unitMultiplier','0')='0';$$;
revoke all on function private.cto_valid_fx(public.fx_rates)from public,anon,authenticated,service_role;

create function public.prepare_cto_acquisition_action(requested_contract uuid,requested_asset uuid,requested_position uuid,
 requested_date date,requested_quantity numeric,requested_mode text,requested_amount numeric,requested_currency text,
 expected_position_updated_at timestamptz,requested_request uuid)returns jsonb language plpgsql security definer set search_path=''as $$
declare p public.positions;c public.contracts;r private.securities_action_requests;w private.cto_acquisition_fx_preparations;
 submission jsonb;cost numeric;currency text;total numeric;rate public.fx_rates;prior jsonb;claimed boolean:=false;plan jsonb;
begin
 if auth.uid()is null or public.is_authorized_user()is not true then raise exception'Unauthorized'using errcode='42501';end if;
 if requested_request is null or requested_position is null or requested_mode is null or requested_mode not in('preserve','redate','total','unit')
 or requested_amount<0 or requested_amount>='1e32'::numeric or requested_amount<>round(requested_amount,28)
 or requested_mode in('preserve','redate')and requested_amount is not null then raise exception'CTO-ACQUISITION-VALUES'using errcode='22023';end if;
 select * into c from public.contracts where id=requested_contract and user_id=auth.uid()for update;
 if not found or not c.is_active or not exists(select 1 from public.envelope_types where id=c.envelope_type_id and code in('cto','compte_titres'))then raise exception'Unauthorized CTO'using errcode='42501';end if;
 submission:=jsonb_build_object('kind','cto-acquisition-v2','contract',requested_contract,'asset',requested_asset,'position',requested_position,'date',requested_date,'quantity',requested_quantity,'mode',requested_mode,'amount',requested_amount,'currency',requested_currency,'revision',expected_position_updated_at);
 select * into r from private.securities_action_requests where user_id=auth.uid()and request_id=requested_request;
 if found then
  if r.contract_id<>requested_contract or r.result<>requested_position or r.payload->9 is distinct from submission
  or not exists(select 1 from public.positions where id=r.result and user_id=auth.uid()and metadata#>array['securities_action_requests',requested_request::text]=r.payload)then raise exception'SECURITIES-REPLAY'using errcode='40001';end if;
  return jsonb_build_object('state','committed','result',r.result,'fx',r.payload#>'{11,fx}');
 end if;
 select * into p from public.positions where id=requested_position and contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid()for update;
 if not found or p.updated_at is distinct from expected_position_updated_at then raise exception'SECURITIES-STALE'using errcode='40001';end if;
 if exists(select 1 from public.assets a where a.id=p.asset_id and a.asset_type_code='fund'and a.valuation_mode='manual')and exists(select 1 from public.position_snapshots where position_id=p.id and user_id=auth.uid())then raise exception'Legacy amount holding requires a qualified transition'using errcode='23514';end if;
 if requested_mode in('preserve','redate')then
  cost:=p.average_cost_per_unit;currency:=btrim(p.cost_currency_code);total:=cost*requested_quantity;
  if requested_mode='redate'then
   if requested_quantity is distinct from p.quantity then raise exception'Redate cannot change quantity'using errcode='22023';end if;
   select v into prior from jsonb_array_elements(coalesce(p.metadata->'cto_acquisition_inputs','[]'))v
    where(v->>'unitCost')::numeric is not distinct from cost and v->>'currency'=currency and(v->>'quantity')::numeric=requested_quantity order by(v->>'recordedAt')::timestamptz desc limit 1;
   if prior is not null then total:=coalesce((prior->>'nativeTotal')::numeric,case when prior->>'amountType'='total'then(prior->>'amount')::numeric else total end);end if;
  end if;
 else
  currency:=requested_currency;
  if requested_amount is null then cost:=null;total:=null;
  elsif requested_mode='unit'then
   if requested_amount<>round(requested_amount,20)then raise exception'CTO-UNIT-PRECISION'using errcode='22023';end if;
   cost:=requested_amount;total:=cost*requested_quantity;
  elsif requested_quantity=0 then
   if requested_amount<>0 then raise exception'CTO-TOTAL-WITHOUT-QUANTITY'using errcode='22023';end if;cost:=null;total:=0;
  else cost:=round(round(requested_amount,28)/requested_quantity,20);total:=requested_amount;end if;
 end if;
 -- Complete native validation before any external call; no transaction spans HTTP.
 perform public.preview_position_observation(requested_contract,requested_asset,requested_position,requested_request,requested_date,requested_quantity,cost,currency);
 select * into w from private.cto_acquisition_fx_preparations where user_id=auth.uid()and request_id=requested_request for update;
 if found then
  if w.submission is distinct from submission then raise exception'SECURITIES-REPLAY'using errcode='40001';end if;
  if w.state='preparing'and w.deadline<clock_timestamp()then
   -- A lost worker never receives a fresh three-call allowance.
   update private.cto_acquisition_fx_preparations set attempts=3,attempt_log=attempt_log||jsonb_build_array(jsonb_build_object('status','worker_deadline')),claim=gen_random_uuid(),deadline=clock_timestamp()+interval'3 seconds'where user_id=w.user_id and request_id=w.request_id returning * into w;claimed:=true;
  end if;
 else
  if requested_mode='preserve'then plan:=jsonb_build_object('method','preserved');
  elsif total is null then plan:=jsonb_build_object('method','unavailable');
  elsif currency='EUR'then plan:=jsonb_build_object('method','identity','direction','EUR_per_native_unit','eurPerUnit','1');
  elsif total=0 then plan:=jsonb_build_object('method','zero');
  else
   select * into rate from public.fx_rates f where f.currency_code=currency and private.cto_valid_fx(f)
    and(f.requested_on=requested_date or(extract(isodow from requested_date)in(6,7)and f.observed_on=requested_date-(extract(isodow from requested_date)::int-5)))
    and f.observed_on<=requested_date order by f.obtained_at desc,f.created_at desc,f.id desc limit 1;
   if found then plan:=jsonb_build_object('method','historical','direction','EUR_per_native_unit','rate',to_jsonb(rate),'attempts','[]'::jsonb);end if;
  end if;
  insert into private.cto_acquisition_fx_preparations(user_id,request_id,submission,native_values,state,fx_plan)
   values(auth.uid(),requested_request,submission,jsonb_build_object('unitCost',cost::text,'currency',currency,'total',total::text),case when plan is null then'preparing'else'ready'end,plan)returning * into w;claimed:=true;
 end if;
 return jsonb_build_object('state',w.state,'claim',case when claimed then w.claim else null end,'attempts',w.attempts,'currency',currency,'date',requested_date,'fx',w.fx_plan);
end$$;
revoke all on function public.prepare_cto_acquisition_action(uuid,uuid,uuid,date,numeric,text,numeric,text,timestamptz,uuid)from public,anon;
grant execute on function public.prepare_cto_acquisition_action(uuid,uuid,uuid,date,numeric,text,numeric,text,timestamptz,uuid)to authenticated;

create function public.cto_acquisition_fx_worker(requested_owner uuid,requested_request uuid,requested_claim uuid,operation text,details jsonb default'{}')returns jsonb language plpgsql security definer set search_path=''as $$
declare w private.cto_acquisition_fx_preparations;r public.fx_rates;currency text;day date;b public.fx_provider_attempts;plan jsonb;n int;
begin
 select * into w from private.cto_acquisition_fx_preparations where user_id=requested_owner and request_id=requested_request for update;
 if not found or w.claim is distinct from requested_claim then raise exception'CTO-FX-CLAIM'using errcode='42501';end if;
 if w.state='ready'then return jsonb_build_object('state','ready','fx',w.fx_plan);end if;
 currency:=w.native_values->>'currency';day:=(w.submission->>'date')::date;
 if operation='take'then
  select * into b from public.fx_provider_attempts where currency_code=currency and requested_on=day and provider='ecb';
  if w.attempts>=3 or w.deadline<=clock_timestamp()or b.retry_after>clock_timestamp()then
   update private.cto_acquisition_fx_preparations set attempts=3,attempt_log=attempt_log||jsonb_build_array(jsonb_build_object('status','blocked_or_expired','retryAfter',b.retry_after))where user_id=w.user_id and request_id=w.request_id;
   return jsonb_build_object('allowed',false);
  end if;
  update private.cto_acquisition_fx_preparations set attempts=attempts+1 where user_id=w.user_id and request_id=w.request_id;
  return jsonb_build_object('allowed',true,'attempt',w.attempts+1);
 elsif operation='failure'then
  if w.attempts=0 or details->>'code'not in('temporary_failure','timeout','invalid_response','not_covered','quota_exceeded')then raise exception'Invalid FX failure';end if;
  update private.cto_acquisition_fx_preparations set attempt_log=attempt_log||jsonb_build_array(details||jsonb_build_object('attempt',w.attempts,'recordedAt',clock_timestamp()))where user_id=w.user_id and request_id=w.request_id;
  if w.attempts=3 or details->>'code'in('quota_exceeded','not_covered')then
   insert into public.fx_provider_attempts(currency_code,requested_on,provider,status,failure_count,retry_after)
    values(currency,day,'ecb',case when details->>'code'='not_covered'then'unsupported'else'temporary_failure'end,1,
    clock_timestamp()+case when details->>'code'='not_covered'then interval'30 days'when details->>'code'='quota_exceeded'then greatest(interval'1 hour',least(interval'30 days',coalesce((details->>'retrySeconds')::numeric,3600)*interval'1 second'))else interval'1 hour'end)
   on conflict(currency_code,requested_on,provider)do update set failure_count=least(100,fx_provider_attempts.failure_count+1),retry_after=excluded.retry_after,status=excluded.status,updated_at=clock_timestamp();
  end if;
  return jsonb_build_object('state','preparing');
 elsif operation='finish'then
  if details->>'rateId'is not null then
   if w.attempts=0 then raise exception'FX attempt required';end if;
   select * into r from public.fx_rates f where id=(details->>'rateId')::uuid and currency_code=currency and requested_on=day and observed_on<=day and private.cto_valid_fx(f)and source='ecb';
   if not found then raise exception'Historical FX proof invalid';end if;
   plan:=jsonb_build_object('method','historical');
   delete from public.fx_provider_attempts where currency_code=currency and requested_on=day and provider='ecb';
  else
   if w.attempts<>3 then raise exception'Three attempts required before fallback';end if;
   select * into r from public.fx_rates f where currency_code=currency and private.cto_valid_fx(f)order by obtained_at desc,created_at desc,id desc limit 1;
   plan:=jsonb_build_object('method',case when found then'last_known'else'unavailable'end);
  end if;
  plan:=plan||jsonb_build_object('direction','EUR_per_native_unit','rate',case when r.id is null then null else to_jsonb(r)end,'attempts',w.attempt_log,'retrievedAt',clock_timestamp());
  update private.cto_acquisition_fx_preparations set state='ready',fx_plan=plan where user_id=w.user_id and request_id=w.request_id;
  return jsonb_build_object('state','ready','fx',plan);
 end if;
 raise exception'Unknown FX worker operation';
end$$;
revoke all on function public.cto_acquisition_fx_worker(uuid,uuid,uuid,text,jsonb)from public,anon,authenticated;
grant execute on function public.cto_acquisition_fx_worker(uuid,uuid,uuid,text,jsonb)to service_role;

create function public.save_cto_acquisition_action(requested_contract uuid,requested_asset uuid,requested_position uuid,
 requested_date date,requested_quantity numeric,requested_mode text,requested_amount numeric,requested_currency text,
 expected_position_updated_at timestamptz,requested_request uuid)
returns uuid language plpgsql security definer set search_path='' as $$
declare p public.positions;parent public.contracts;receipt private.securities_action_requests;submission jsonb;payload jsonb;plan jsonb;
 cost numeric;currency text;proof jsonb;prior_inputs jsonb;prep private.cto_acquisition_fx_preparations;native_total numeric;eur_total numeric;eur_unit numeric;stamp timestamptz:=clock_timestamp();saved uuid;
begin
 if auth.uid()is null or public.is_authorized_user()is not true then raise exception'Unauthorized'using errcode='42501';end if;
 if requested_position is null or requested_request is null or requested_mode is null or requested_mode not in('preserve','redate','total','unit')
 or requested_amount<0 or requested_amount>=1e32 or requested_amount<>round(requested_amount,28)
 or requested_mode in('preserve','redate')and requested_amount is not null then raise exception'CTO-ACQUISITION-VALUES'using errcode='22023';end if;
 select * into parent from public.contracts where id=requested_contract and user_id=auth.uid()for update;
 if not found or not parent.is_active or not exists(select 1 from public.envelope_types t where t.id=parent.envelope_type_id and t.code in('cto','compte_titres'))then raise exception'Unauthorized CTO'using errcode='42501';end if;
 submission:=jsonb_build_object('kind','cto-acquisition-v2','contract',requested_contract,'asset',requested_asset,'position',requested_position,'date',requested_date,'quantity',requested_quantity,'mode',requested_mode,'amount',requested_amount,'currency',requested_currency,'revision',expected_position_updated_at);
 select * into receipt from private.securities_action_requests where user_id=auth.uid()and request_id=requested_request;
 if found then
  if receipt.contract_id<>requested_contract or receipt.result<>requested_position or receipt.payload->9 is distinct from submission
  or not exists(select 1 from public.positions x where x.id=receipt.result and x.user_id=auth.uid()and x.metadata#>array['securities_action_requests',requested_request::text]=receipt.payload)then raise exception'SECURITIES-REPLAY'using errcode='40001';end if;
  return receipt.result;
 end if;
 select * into p from public.positions where id=requested_position and contract_id=requested_contract and asset_id=requested_asset and user_id=auth.uid()for update;
 if not found or p.updated_at is distinct from expected_position_updated_at then raise exception'SECURITIES-STALE'using errcode='40001';end if;
 if exists(select 1 from public.assets a where a.id=p.asset_id and a.asset_type_code='fund'and a.valuation_mode='manual')and exists(select 1 from public.position_snapshots s where s.position_id=p.id and s.user_id=auth.uid())then raise exception'Legacy amount holding requires a qualified transition'using errcode='23514';end if;
 if requested_mode in('preserve','redate') then cost:=p.average_cost_per_unit;currency:=btrim(p.cost_currency_code);
 else
  currency:=requested_currency;
  if requested_amount is null then cost:=null;
  elsif requested_mode='unit' then
   if requested_amount<>round(requested_amount,20)then raise exception'CTO-UNIT-PRECISION'using errcode='22023';end if;
   cost:=requested_amount;
  elsif requested_quantity=0 then
   if requested_amount<>0 then raise exception'CTO-TOTAL-WITHOUT-QUANTITY'using errcode='22023';end if;
   cost:=null;
  else cost:=round(round(requested_amount,28)/requested_quantity,20);end if;
 end if;
 select * into prep from private.cto_acquisition_fx_preparations where user_id=auth.uid()and request_id=requested_request for update;
 if not found or prep.submission is distinct from submission or prep.state<>'ready'then raise exception'CTO-FX-PREPARATION-REQUIRED'using errcode='40001';end if;
 if (prep.native_values->>'unitCost')::numeric is distinct from cost or prep.native_values->>'currency'is distinct from currency then raise exception'CTO-FX-PREPARATION-DIFFERS'using errcode='40001';end if;
 native_total:=(prep.native_values->>'total')::numeric;
 if prep.fx_plan->>'method'in('identity','zero')then eur_total:=native_total;elsif prep.fx_plan->>'method'in('historical','last_known')then eur_total:=native_total*(prep.fx_plan#>>'{rate,eur_per_unit}')::numeric;end if;
 eur_unit:=case when requested_quantity>0 then round(round(eur_total,60)/requested_quantity,40)else null end;
 prior_inputs:=coalesce(p.metadata->'cto_acquisition_inputs','[]');
 if requested_mode<>'preserve'then
  proof:=jsonb_build_object('version',2,'requestId',requested_request,'effectiveOn',requested_date,'quantity',requested_quantity::text,
   'amountType',requested_mode,'amount',requested_amount::text,'unitCost',cost::text,'currency',currency,'recordedAt',stamp,
   'nativeTotal',native_total::text,'totalEur',eur_total::text,'unitEur',eur_unit::text,'fx',prep.fx_plan,'calculation','native total × EUR per native unit; unit EUR divided by quantity, 40 decimals','provenance','Estimation figée à la date choisie par l’utilisateur ; valorisation de marché indépendante');
 end if;
 payload:=jsonb_build_array('position',requested_contract,requested_asset,requested_position,null,requested_date,requested_quantity,cost,currency,submission,prior_inputs,proof);
 perform public.lock_position_capture_sources();
 plan:=public.preview_position_observation(requested_contract,requested_asset,requested_position,requested_request,requested_date,requested_quantity,cost,currency);
 saved:=public.save_position_observation(requested_contract,requested_asset,requested_position,requested_request,requested_date,requested_quantity,cost,currency,plan->>'token');
 insert into private.securities_action_requests(user_id,contract_id,request_id,payload,result)values(auth.uid(),requested_contract,requested_request,payload,saved);
 update public.positions set metadata=metadata||jsonb_build_object('securities_action_requests',coalesce(metadata->'securities_action_requests','{}')||jsonb_build_object(requested_request::text,payload))
  ||case when proof is null then '{}'::jsonb else jsonb_build_object('cto_acquisition_inputs',prior_inputs||jsonb_build_array(proof))end where id=saved and user_id=auth.uid();
 delete from private.cto_acquisition_fx_preparations where user_id=auth.uid()and request_id=requested_request;
 return saved;
end$$;
revoke all on function public.save_cto_acquisition_action(uuid,uuid,uuid,date,numeric,text,numeric,text,timestamptz,uuid)from public,anon;
grant execute on function public.save_cto_acquisition_action(uuid,uuid,uuid,date,numeric,text,numeric,text,timestamptz,uuid)to authenticated;

create function public.guard_cto_acquisition_inputs()returns trigger language plpgsql security definer set search_path=''as $$
declare proof jsonb;prior_inputs jsonb;receipt private.securities_action_requests;
begin
 if public.app_restore_permitted(tg_relid,tg_op,case when tg_op='INSERT'then null else to_jsonb(old)end,to_jsonb(new))then return new;end if;
 prior_inputs:=case when tg_op='INSERT'then'[]'::jsonb else coalesce(old.metadata->'cto_acquisition_inputs','[]')end;
 if coalesce(new.metadata->'cto_acquisition_inputs','[]')is not distinct from prior_inputs then return new;end if;
 proof:=new.metadata#>'{cto_acquisition_inputs,-1}';
 select * into receipt from private.securities_action_requests where user_id=new.user_id and request_id=(proof->>'requestId')::uuid and contract_id=new.contract_id and result=new.id;
 if not found or receipt.payload#>>'{9,kind}'is distinct from'cto-acquisition-v2'or receipt.payload->10 is distinct from prior_inputs or receipt.payload->11 is distinct from proof
 or new.metadata->'cto_acquisition_inputs'is distinct from prior_inputs||jsonb_build_array(proof)
 or new.metadata#>array['securities_action_requests',proof->>'requestId']is distinct from receipt.payload
 or new.metadata#>>'{position_observations,entries,-1,id}'is distinct from proof->>'requestId'
 or(new.average_cost_per_unit,btrim(new.cost_currency_code))is distinct from((proof->>'unitCost')::numeric,proof->>'currency')then raise exception'CTO-ACQUISITION-PROOF'using errcode='23514';end if;
 return new;
end$$;
revoke all on function public.guard_cto_acquisition_inputs()from public,anon,authenticated,service_role;
create trigger positions_00_cto_acquisition_guard before insert or update on public.positions for each row execute function public.guard_cto_acquisition_inputs();

-- Preserve the existing normalization API and ACL; only exact known edges change.
CREATE OR REPLACE FUNCTION private.app_backup_upgrade(doc jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
AS $function$
declare d record;obj jsonb;row jsonb;data jsonb;begin
 if doc->>'schema'='7b8d63de5bc463697251a1c84a5ab7a2d34723fd9b0b94c0654c313d8b5a34f1'and private.app_backup_schema()in('237871bc6c514a148fbb9da4331506d574b1abf41368c61a67177bdd04a2c86a','2c0097879ab93eaae871f815ac30e440110c772f1da42916e186b1e2bb77e73e')then doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));end if;

 if public.is_authorized_user()is not true or doc->>'owner'is distinct from auth.uid()::text then raise exception'Unauthorized'using errcode='42501';end if;
 -- Exact complete /3 predecessor only. No dataset, receipt or journal is
 -- synthesized here: the existing validator checks every dataset, column,
 -- owner, typed cell and the conserved journal digest before admission.
 if doc->>'format'='monpatrimoine-app-backup/3'
 and doc->>'schema'='237871bc6c514a148fbb9da4331506d574b1abf41368c61a67177bdd04a2c86a'and private.app_backup_schema()='2c0097879ab93eaae871f815ac30e440110c772f1da42916e186b1e2bb77e73e'then
  doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));
  perform private.app_backup_validate(doc);
  return doc;
 end if;

 if doc->>'format'='monpatrimoine-app-backup/3' and doc->>'schema'='835028012c2472878aa5c9ad3d097c4bdda27cc617b5fc84e862af7df8bc4bbc' then
 doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));
 end if;
 if doc->>'format'='monpatrimoine-app-backup/3' and doc->>'schema'='e3f63a4322f4ebf7892e0dc0626a7175d290110a652b3394e4c12ee0baaf3f3b' then
 doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));
 end if;
 if doc->>'schema'=private.app_backup_schema()then perform private.app_backup_validate(doc);return doc;end if;
 if doc->'datasets'?'securities_cash_basis'or doc->'datasets'?'securities_cash_actions'or doc->'datasets'?'securities_action_requests'or doc->'datasets'?'securities_journal_integrity'then raise exception'Unsupported partial journal archive';end if;
 -- An archive with modern materializations but no journal has lost business
 -- data. Never convert that loss into an apparently fresh empty ledger.
 for d in select * from private.app_backup_datasets where name in('cash_balances','positions','contracts')loop
  for row in select * from jsonb_array_elements(doc#>array['datasets',d.name,'rows'])loop
   select jsonb_object_agg(c,row->(i-1)::int)into obj from jsonb_array_elements_text(doc#>array['datasets',d.name,'columns'])with ordinality t(c,i);
   if(obj->>'metadata')::jsonb?'securities_cash_actions'or(obj->>'metadata')::jsonb?'securities_action_requests'then raise exception'SECURITIES-JOURNAL-MISSING-IN-ARCHIVE';end if;
  end loop;
 end loop;
 for d in select * from private.app_backup_datasets where name in('securities_cash_basis','securities_cash_actions','securities_action_requests')loop
  doc:=jsonb_set(doc,array['datasets',d.name],jsonb_build_object('columns',d.columns,'rows','[]'::jsonb));
 end loop;
 select jsonb_object_agg(k,v)into data from jsonb_each(doc->'datasets')t(k,v)where k in('securities_cash_basis','securities_cash_actions','securities_action_requests');
 doc:=jsonb_set(doc,'{datasets,securities_journal_integrity}',jsonb_build_object('columns',array['user_id','content_sha256'],'rows',jsonb_build_array(jsonb_build_array(auth.uid()::text,encode(extensions.digest(data::text,'sha256'),'hex')))));
 if doc->>'format'='monpatrimoine-app-backup/3'and doc->>'schema'in('8cf0fb641a93c05ee70ab159f60a5b50024a95ba1b2d1749bd1d4f56e5027fc8','405698ddd199f9344105378a5b5b5e27645fcf3076fc16a324bbf6ea87fd7a6f')then
  doc:=jsonb_set(doc,'{schema}',to_jsonb(private.app_backup_schema()));perform private.app_backup_validate(doc);return doc;
 end if;
 -- Previous exact /1,/2,/3 frontiers remain delegated to the existing allowlist.
 return private.app_backup_upgrade_before_securities(doc);
end$function$
;
commit;
