-- Prepared for isolated qualification only. No Production route is installed.
begin;
create table private.app_restore_receipts (
 request_id uuid primary key, actor uuid not null references auth.users(id),
 session_hash text not null, document_digest text not null, before_digest text not null,
 pre_restore_ref text not null, archive_sha256 text not null,
 committed_at timestamptz not null default clock_timestamp()
);
alter table private.app_restore_receipts enable row level security;
alter table private.app_restore_receipts force row level security;
revoke all on private.app_restore_receipts from public,anon,authenticated,service_role;

create function public.application_backup_server(operation text,actor jsonb,args jsonb default '{}')
returns jsonb language plpgsql volatile security definer set search_path='' set timezone='UTC' set datestyle='ISO,YMD' as $$
declare uid uuid; sid uuid; session_hash text; doc jsonb; result jsonb; target_hash text;
 rid uuid; receipt private.app_restore_receipts; backup jsonb;
 previous_sub text:=current_setting('request.jwt.claim.sub',true);
 previous_claims text:=current_setting('request.jwt.claims',true);
begin
 -- Only service_role receives EXECUTE. Actor is supplied by the verified server,
 -- never forwarded from a request owner_id. Recheck the principal and profile.
 if jsonb_typeof(actor) is distinct from 'object'
 or (select array_agg(k order by k) from jsonb_object_keys(actor) k) is distinct from array['sessionId','userId']::text[] then raise exception 'Unauthorized' using errcode='42501';end if;
 uid:=(actor->>'userId')::uuid;sid:=(actor->>'sessionId')::uuid;
 if uid is null or sid is null or not exists(select 1 from private.application_principal p join public.profiles pr on pr.auth_user_id=p.auth_user_id where p.singleton and p.auth_user_id=uid and pr.is_active) then raise exception 'Unauthorized' using errcode='42501';end if;
 if jsonb_typeof(args) is distinct from 'object' or pg_column_size(args)>16777216 then raise exception 'Invalid request';end if;
 session_hash:=encode(extensions.digest(uid::text||':'||sid::text,'sha256'),'hex');
 perform set_config('request.jwt.claim.sub',uid::text,true);
 perform set_config('request.jwt.claims',jsonb_build_object('sub',uid,'session_id',sid,'role','service_role')::text,true);
 if operation='snapshot' then
  if args<>'{}'::jsonb then raise exception 'Unexpected request fields';end if;
  doc:=private.app_backup_snapshot();
  result:=jsonb_build_object('document',doc,'digest',encode(extensions.digest(doc::text,'sha256'),'hex'));
 elsif operation='preview' then
  if (select array_agg(k order by k) from jsonb_object_keys(args) k) is distinct from array['document','expected_digest']::text[] then raise exception 'Unexpected request fields';end if;
  -- Complete constraint validation, all tentative writes rolled back inside this
  -- subtransaction; no receipt or row permits can survive the preview.
  begin
   target_hash:=private.app_backup_replace(args->'document',args->>'expected_digest');
   raise exception using errcode='PBR01';
  exception when sqlstate 'PBR01' then null;end;
  result:=jsonb_build_object('targetDigest',target_hash);
 elsif operation in('status','restore') then
  if operation='status' and (select array_agg(k order by k) from jsonb_object_keys(args) k) is distinct from array['request_id']::text[] then raise exception 'Unexpected request fields';end if;
  if operation='restore' and (select array_agg(k order by k) from jsonb_object_keys(args) k) is distinct from array['backup','document','expected_digest','request_id']::text[] then raise exception 'Unexpected request fields';end if;
  rid:=(args->>'request_id')::uuid;
  if rid is null then raise exception 'Request identity required';end if;
  perform pg_advisory_xact_lock(hashtextextended('app-restore:'||rid::text,0));
  select * into receipt from private.app_restore_receipts r where r.request_id=rid;
  if receipt.request_id is not null then
   if receipt.actor<>uid or receipt.session_hash<>session_hash then raise exception 'Unauthorized' using errcode='42501';end if;
   if operation='restore' and (receipt.document_digest<>encode(extensions.digest((args->'document')::text,'sha256'),'hex') or receipt.before_digest is distinct from args->>'expected_digest') then raise exception 'Request identity conflict';end if;
  elsif operation='restore' then
   backup:=args->'backup';
   if jsonb_typeof(backup) is distinct from 'object' or (select array_agg(k order by k) from jsonb_object_keys(backup) k) is distinct from array['archiveSha256','contentDigest','kind','reference','verified']::text[]
    or backup->>'verified' is distinct from 'true' or coalesce(backup->>'kind','') not in('local-test','google-drive')
    or backup->>'contentDigest' is distinct from args->>'expected_digest'
    or coalesce(backup->>'archiveSha256','')!~'^[0-9a-f]{64}$'
    or coalesce(char_length(backup->>'reference'),0) not between 1 and 240 then raise exception 'Verified pre-restore backup required';end if;
   -- Durability evidence is verified by the trusted server transport, not by a
   -- browser assertion. SQL enforces its binding to the exact current snapshot.
   target_hash:=private.app_backup_replace(args->'document',args->>'expected_digest');
   insert into private.app_restore_receipts(request_id,actor,session_hash,document_digest,before_digest,pre_restore_ref,archive_sha256)
    values(rid,uid,session_hash,target_hash,args->>'expected_digest',backup->>'reference',backup->>'archiveSha256') returning * into receipt;
  end if;
  result:=case when receipt.request_id is null then jsonb_build_object('status','unconfirmed') else jsonb_build_object('status','committed','requestId',receipt.request_id,'targetDigest',receipt.document_digest,'preRestore',receipt.pre_restore_ref,'committedAt',receipt.committed_at) end;
 else raise exception 'Unsupported operation';end if;
 perform set_config('request.jwt.claim.sub',coalesce(previous_sub,''),true);
 perform set_config('request.jwt.claims',coalesce(previous_claims,''),true);
 return result;
exception when others then
 perform set_config('request.jwt.claim.sub',coalesce(previous_sub,''),true);
 perform set_config('request.jwt.claims',coalesce(previous_claims,''),true);
 raise;
end$$;
revoke all on function public.application_backup_server(text,jsonb,jsonb) from public,anon,authenticated,service_role;
grant execute on function public.application_backup_server(text,jsonb,jsonb) to service_role;
commit;
