-- Local candidate only. Preserve exact row equality as the permit authority.
begin;
set local lock_timeout='5s';
set local statement_timeout='45s';
-- Fail closed if the qualified deployed replacement function has drifted.
do $$begin
 if md5(pg_get_functiondef('private.app_backup_replace(jsonb,text)'::regprocedure))<>'9d8c4559cc2fe0410d41a71cba6bca3b' then
  raise exception 'Backup replacement definition changed; requalify before delivery';
 end if;
end$$;
create index app_restore_permits_lookup_idx on private.app_restore_permits
(tx,backend,relation,operation,(coalesce(before_row->>'id','')),(coalesce(after_row->>'id','')));
create or replace function public.app_restore_permitted(rel oid,op text,prior jsonb,next_row jsonb)
returns boolean language sql stable security definer set search_path='' as $$
select exists(select 1 from private.app_restore_permits p
where p.tx=txid_current() and p.backend=pg_backend_pid() and p.relation=rel and p.operation=op
and coalesce(p.before_row->>'id','')=coalesce(prior->>'id','')
and coalesce(p.after_row->>'id','')=coalesce(next_row->>'id','')
and p.before_row is not distinct from prior and p.after_row is not distinct from next_row)
$$;
CREATE OR REPLACE FUNCTION private.app_backup_replace(doc jsonb, expected_digest text)
 RETURNS text
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO ''
 SET "TimeZone" TO 'UTC'
 SET "DateStyle" TO 'ISO,YMD'
AS $function$
declare d record; col text; cells jsonb; obj jsonb; objects jsonb; cols text; updates text; pk text; current_doc jsonb; begin
 perform pg_advisory_xact_lock(hashtextextended('envelope-tax-schedule',0));
 -- Operator only: there is deliberately no application/browser grant.
 if public.is_authorized_user() is not true then raise exception 'Unauthorized' using errcode='42501';end if;
 -- Serializes *all* ordinary DML, including writers unaware of advisory locks.
 for d in select distinct relation::text as name from private.app_backup_datasets order by name loop execute 'lock table '||d.name||' in share row exclusive mode';end loop;
 lock table public.profiles in share row exclusive mode;
 perform private.app_backup_validate(doc);
 current_doc:=private.app_backup_snapshot();
 if encode(extensions.digest(current_doc::text,'sha256'),'hex') is distinct from expected_digest then raise exception 'Concurrent state changed' using errcode='40001';end if;
 for d in select * from private.app_backup_datasets where shared loop
  if current_doc#>array['datasets',d.name] is distinct from doc#>array['datasets',d.name] then raise exception 'Shared reference changed: %',d.name;end if;
 end loop;
 -- Typed private staging. No archive-supplied table, SQL or path is executed.
 create temporary table app_restore_input(name text primary key,objects jsonb) on commit drop;
 for d in select * from private.app_backup_datasets where not shared order by ordinal loop
  select coalesce(jsonb_agg(x.obj order by r.ord),'[]'::jsonb) into objects
  from jsonb_array_elements(doc#>array['datasets',d.name,'rows']) with ordinality r(cells,ord)
  cross join lateral (select jsonb_object_agg(c,r.cells->(i-1)::int) as obj
    from unnest(d.columns) with ordinality t(c,i)) x;
  insert into app_restore_input values(d.name,objects);
 end loop;
 -- Row permits cannot be manufactured by authenticated/service_role callers.
 for d in select * from private.app_backup_datasets where not shared order by ordinal desc loop
  -- Keep surviving root/reference identities so excluded operational rows are
  -- not cascade-deleted. Children are fully replaced; constraints stay active.
  if d.name in('assets','contracts','sectors','sector_activities','themes','fiscal_regimes','fiscal_rules') then
   execute format('insert into private.app_restore_permits select txid_current(),pg_backend_pid(),%s,''DELETE'',to_jsonb(r),null from %s r where %s and not exists(select 1 from (%s) x where x.id=r.id)',d.relation::oid,d.relation,d.predicate,private.app_backup_typed_rows(d.relation)) using (select a.objects from app_restore_input a where name=d.name);
  else
   execute format('insert into private.app_restore_permits select txid_current(),pg_backend_pid(),%s,''DELETE'',to_jsonb(r),null from %s r where %s',d.relation::oid,d.relation,d.predicate);
  end if;
  execute format('delete from %s r where %s and public.app_restore_permitted(%s,''DELETE'',to_jsonb(r),null)',d.relation,d.predicate,d.relation::oid);
 end loop;
 for d in select * from private.app_backup_datasets where not shared order by ordinal loop
  select a.objects into objects from app_restore_input a where name=d.name;
  cols:=(select string_agg(quote_ident(c),',') from unnest(d.columns) c);
  pk:=(select string_agg(quote_ident(c),',') from unnest(d.primary_columns) c);
  updates:=(select string_agg(format('%I=excluded.%I',c,c),',') from unnest(d.columns) c where not c=any(d.primary_columns));
  -- Compute exact UPDATE/INSERT permits against the current surviving rows.
  execute format('insert into private.app_restore_permits select txid_current(),pg_backend_pid(),%s,''INSERT'',null,to_jsonb(x) from (%s) x',d.relation::oid,private.app_backup_typed_rows(d.relation)) using objects;
  execute format('insert into private.app_restore_permits select txid_current(),pg_backend_pid(),%s,''UPDATE'',to_jsonb(r),to_jsonb(x) from (%s) x join %s r on %s',d.relation::oid,private.app_backup_typed_rows(d.relation),d.relation,(select string_agg(format('r.%I=x.%I',c,c),' and ') from unnest(d.primary_columns) c)) using objects;
  execute format('insert into %s(%s) select %s from (%s) x on conflict(%s) %s',d.relation,cols,cols,private.app_backup_typed_rows(d.relation),pk,case when updates is null then 'do nothing' else 'do update set '||updates end) using objects;
 end loop;
 update public.profiles set preferences=(doc#>>'{preferences,preferences}')::jsonb,interface_preferences=(doc#>>'{preferences,interface_preferences}')::jsonb,strategy_parameters=(doc#>>'{preferences,strategy_parameters}')::jsonb where auth_user_id=auth.uid();
 set constraints all immediate; insert into private.allocation_write_guards as g(user_id,revision) values(auth.uid(),1) on conflict(user_id) do update set revision=g.revision+1;
 if private.app_backup_snapshot() is distinct from doc then raise exception 'Canonical restored content differs';end if;
 delete from private.app_restore_permits where tx=txid_current() and backend=pg_backend_pid();
 return encode(extensions.digest(doc::text,'sha256'),'hex');
end$function$
;
commit;
