-- Phase 7.3C: repair mojibake and seed durable exposure references.
-- Country codes and French labels: ISO 3166-1 / United Nations M49.
-- https://www.iso.org/iso-3166-country-codes.html
-- https://unstats.un.org/unsd/methodology/m49/overview/
-- Existing MonPatrimoine regions are reused. The Caribbean is grouped with
-- Central America; Antarctica uses the technical unspecified region.
begin;

update public.geographic_regions
set name = case code
  when 'unspecified' then 'Non spécifié'
  when 'north_america' then 'Amérique du Nord'
  when 'central_america' then 'Amérique centrale'
  when 'south_america' then 'Amérique du Sud'
  when 'europe' then 'Europe'
  when 'africa' then 'Afrique'
  when 'asia' then 'Asie'
  when 'oceania' then 'Océanie'
end
where code in ('unspecified','north_america','central_america','south_america','europe','africa','asia','oceania');

update public.sector_activities
set name = 'Non détaillé'
where code = 'unspecified';

update public.exposure_countries
set name = 'Non spécifié', region_code = 'unspecified'
where code = 'unspecified';

with country_data(code,name,region_code) as (
 values
  ('AD','Andorre','europe'),
  ('AE','Émirats arabes unis','asia'),
  ('AF','Afghanistan','asia'),
  ('AG','Antigua-et-Barbuda','central_america'),
  ('AI','Anguilla','central_america'),
  ('AL','Albanie','europe'),
  ('AM','Arménie','asia'),
  ('AO','Angola','africa'),
  ('AQ','Antarctique','unspecified'),
  ('AR','Argentine','south_america'),
  ('AS','Samoa américaines','oceania'),
  ('AT','Autriche','europe'),
  ('AU','Australie','oceania'),
  ('AW','Aruba','central_america'),
  ('AX','Îles d’Åland','europe'),
  ('AZ','Azerbaïdjan','asia'),
  ('BA','Bosnie-Herzégovine','europe'),
  ('BB','Barbade','central_america'),
  ('BD','Bangladesh','asia'),
  ('BE','Belgique','europe'),
  ('BF','Burkina Faso','africa'),
  ('BG','Bulgarie','europe'),
  ('BH','Bahreïn','asia'),
  ('BI','Burundi','africa'),
  ('BJ','Bénin','africa'),
  ('BL','Saint-Barthélemy','central_america'),
  ('BM','Bermudes','north_america'),
  ('BN','Brunéi Darussalam','asia'),
  ('BO','Bolivie (État plurinational de)','south_america'),
  ('BQ','Bonaire, Saint-Eustache et Saba','central_america'),
  ('BR','Brésil','south_america'),
  ('BS','Bahamas','central_america'),
  ('BT','Bhoutan','asia'),
  ('BV','Île Bouvet','south_america'),
  ('BW','Botswana','africa'),
  ('BY','Bélarus','europe'),
  ('BZ','Belize','central_america'),
  ('CA','Canada','north_america'),
  ('CC','Îles des Cocos (Keeling)','oceania'),
  ('CD','République démocratique du Congo','africa'),
  ('CF','République centrafricaine','africa'),
  ('CG','Congo','africa'),
  ('CH','Suisse','europe'),
  ('CI','Côte d’Ivoire','africa'),
  ('CK','Îles Cook','oceania'),
  ('CL','Chili','south_america'),
  ('CM','Cameroun','africa'),
  ('CN','Chine','asia'),
  ('CO','Colombie','south_america'),
  ('CR','Costa Rica','central_america'),
  ('CU','Cuba','central_america'),
  ('CV','Cabo Verde','africa'),
  ('CW','Curaçao','central_america'),
  ('CX','Île Christmas','oceania'),
  ('CY','Chypre','asia'),
  ('CZ','Tchéquie','europe'),
  ('DE','Allemagne','europe'),
  ('DJ','Djibouti','africa'),
  ('DK','Danemark','europe'),
  ('DM','Dominique','central_america'),
  ('DO','République dominicaine','central_america'),
  ('DZ','Algérie','africa'),
  ('EC','Équateur','south_america'),
  ('EE','Estonie','europe'),
  ('EG','Égypte','africa'),
  ('EH','Sahara occidental','africa'),
  ('ER','Érythrée','africa'),
  ('ES','Espagne','europe'),
  ('ET','Éthiopie','africa'),
  ('FI','Finlande','europe'),
  ('FJ','Fidji','oceania'),
  ('FK','Îles Falkland (Malvinas)','south_america'),
  ('FM','Micronésie (États fédérés de)','oceania'),
  ('FO','Îles Féroé','europe'),
  ('FR','France','europe'),
  ('GA','Gabon','africa'),
  ('GB','Royaume-Uni de Grande-Bretagne et d’Irlande du Nord','europe'),
  ('GD','Grenade','central_america'),
  ('GE','Géorgie','asia'),
  ('GF','Guyane française','south_america'),
  ('GG','Guernesey','europe'),
  ('GH','Ghana','africa'),
  ('GI','Gibraltar','europe'),
  ('GL','Groenland','north_america'),
  ('GM','Gambie','africa'),
  ('GN','Guinée','africa'),
  ('GP','Guadeloupe','central_america'),
  ('GQ','Guinée équatoriale','africa'),
  ('GR','Grèce','europe'),
  ('GS','Géorgie du Sud-et-les Îles Sandwich du Sud','south_america'),
  ('GT','Guatemala','central_america'),
  ('GU','Guam','oceania'),
  ('GW','Guinée-Bissau','africa'),
  ('GY','Guyana','south_america'),
  ('HK','Chine, région administrative spéciale de Hong Kong','asia'),
  ('HM','Île Heard-et-Îles MacDonald','oceania'),
  ('HN','Honduras','central_america'),
  ('HR','Croatie','europe'),
  ('HT','Haïti','central_america'),
  ('HU','Hongrie','europe'),
  ('ID','Indonésie','asia'),
  ('IE','Irlande','europe'),
  ('IL','Israël','asia'),
  ('IM','Île de Man','europe'),
  ('IN','Inde','asia'),
  ('IO','Territoire britannique de l''océan Indien','africa'),
  ('IQ','Iraq','asia'),
  ('IR','Iran (République islamique d’)','asia'),
  ('IS','Islande','europe'),
  ('IT','Italie','europe'),
  ('JE','Jersey','europe'),
  ('JM','Jamaïque','central_america'),
  ('JO','Jordanie','asia'),
  ('JP','Japon','asia'),
  ('KE','Kenya','africa'),
  ('KG','Kirghizistan','asia'),
  ('KH','Cambodge','asia'),
  ('KI','Kiribati','oceania'),
  ('KM','Comores','africa'),
  ('KN','Saint-Kitts-et-Nevis','central_america'),
  ('KP','République populaire démocratique de Corée','asia'),
  ('KR','République de Corée','asia'),
  ('KW','Koweït','asia'),
  ('KY','Îles Caïmanes','central_america'),
  ('KZ','Kazakhstan','asia'),
  ('LA','République démocratique populaire lao','asia'),
  ('LB','Liban','asia'),
  ('LC','Sainte-Lucie','central_america'),
  ('LI','Liechtenstein','europe'),
  ('LK','Sri Lanka','asia'),
  ('LR','Libéria','africa'),
  ('LS','Lesotho','africa'),
  ('LT','Lituanie','europe'),
  ('LU','Luxembourg','europe'),
  ('LV','Lettonie','europe'),
  ('LY','Libye','africa'),
  ('MA','Maroc','africa'),
  ('MC','Monaco','europe'),
  ('MD','République de Moldova','europe'),
  ('ME','Monténégro','europe'),
  ('MF','Saint-Martin (partie française)','central_america'),
  ('MG','Madagascar','africa'),
  ('MH','Îles Marshall','oceania'),
  ('MK','Macédoine du Nord','europe'),
  ('ML','Mali','africa'),
  ('MM','Myanmar','asia'),
  ('MN','Mongolie','asia'),
  ('MO','Chine, région administrative spéciale de Macao','asia'),
  ('MP','Îles Mariannes du Nord','oceania'),
  ('MQ','Martinique','central_america'),
  ('MR','Mauritanie','africa'),
  ('MS','Montserrat','central_america'),
  ('MT','Malte','europe'),
  ('MU','Maurice','africa'),
  ('MV','Maldives','asia'),
  ('MW','Malawi','africa'),
  ('MX','Mexique','central_america'),
  ('MY','Malaisie','asia'),
  ('MZ','Mozambique','africa'),
  ('NA','Namibie','africa'),
  ('NC','Nouvelle-Calédonie','oceania'),
  ('NE','Niger','africa'),
  ('NF','Île Norfolk','oceania'),
  ('NG','Nigéria','africa'),
  ('NI','Nicaragua','central_america'),
  ('NL','Pays-Bas (Royaume des)','europe'),
  ('NO','Norvège','europe'),
  ('NP','Népal','asia'),
  ('NR','Naoero','oceania'),
  ('NU','Nioué','oceania'),
  ('NZ','Nouvelle-Zélande','oceania'),
  ('OM','Oman','asia'),
  ('PA','Panama','central_america'),
  ('PE','Pérou','south_america'),
  ('PF','Polynésie française','oceania'),
  ('PG','Papouasie-Nouvelle-Guinée','oceania'),
  ('PH','Philippines','asia'),
  ('PK','Pakistan','asia'),
  ('PL','Pologne','europe'),
  ('PM','Saint-Pierre-et-Miquelon','north_america'),
  ('PN','Pitcairn','oceania'),
  ('PR','Porto Rico','central_america'),
  ('PS','État de Palestine','asia'),
  ('PT','Portugal','europe'),
  ('PW','Palaos','oceania'),
  ('PY','Paraguay','south_america'),
  ('QA','Qatar','asia'),
  ('RE','Réunion','africa'),
  ('RO','Roumanie','europe'),
  ('RS','Serbie','europe'),
  ('RU','Fédération de Russie','europe'),
  ('RW','Rwanda','africa'),
  ('SA','Arabie saoudite','asia'),
  ('SB','Îles Salomon','oceania'),
  ('SC','Seychelles','africa'),
  ('SD','Soudan','africa'),
  ('SE','Suède','europe'),
  ('SG','Singapour','asia'),
  ('SH','Sainte-Hélène','africa'),
  ('SI','Slovénie','europe'),
  ('SJ','Îles Svalbard-et-Jan Mayen','europe'),
  ('SK','Slovaquie','europe'),
  ('SL','Sierra Leone','africa'),
  ('SM','Saint-Marin','europe'),
  ('SN','Sénégal','africa'),
  ('SO','Somalie','africa'),
  ('SR','Suriname','south_america'),
  ('SS','Soudan du Sud','africa'),
  ('ST','Sao Tomé-et-Principe','africa'),
  ('SV','El Salvador','central_america'),
  ('SX','Saint-Martin (partie néerlandaise)','central_america'),
  ('SY','République arabe syrienne','asia'),
  ('SZ','Eswatini','africa'),
  ('TC','Îles Turques-et-Caïques','central_america'),
  ('TD','Tchad','africa'),
  ('TF','Terres australes françaises','africa'),
  ('TG','Togo','africa'),
  ('TH','Thaïlande','asia'),
  ('TJ','Tadjikistan','asia'),
  ('TK','Tokélaou','oceania'),
  ('TL','Timor-Leste','asia'),
  ('TM','Turkménistan','asia'),
  ('TN','Tunisie','africa'),
  ('TO','Tonga','oceania'),
  ('TR','Türkiye','asia'),
  ('TT','Trinité-et-Tobago','central_america'),
  ('TV','Tuvalu','oceania'),
  ('TW','Taïwan','asia'),
  ('TZ','République-Unie de Tanzanie','africa'),
  ('UA','Ukraine','europe'),
  ('UG','Ouganda','africa'),
  ('UM','Îles mineures éloignées des États-Unis','oceania'),
  ('US','États-Unis d’Amérique','north_america'),
  ('UY','Uruguay','south_america'),
  ('UZ','Ouzbékistan','asia'),
  ('VA','Saint-Siège','europe'),
  ('VC','Saint-Vincent-et-les Grenadines','central_america'),
  ('VE','Venezuela (République bolivarienne du)','south_america'),
  ('VG','Îles Vierges britanniques','central_america'),
  ('VI','Îles Vierges américaines','central_america'),
  ('VN','Viet Nam','asia'),
  ('VU','Vanuatu','oceania'),
  ('WF','Îles Wallis-et-Futuna','oceania'),
  ('WS','Samoa','oceania'),
  ('YE','Yémen','asia'),
  ('YT','Mayotte','africa'),
  ('ZA','Afrique du Sud','africa'),
  ('ZM','Zambie','africa'),
  ('ZW','Zimbabwe','africa')
)
insert into public.exposure_countries(code,name,region_code)
select code,name,region_code from country_data
on conflict(code) do update set name=excluded.name,region_code=excluded.region_code;

with activity_data(sector_code,code,name) as (
 values
  ('45','euv_lithography','Lithographie EUV'),
  ('45','duv_lithography','Lithographie DUV'),
  ('45','semiconductor_optical_metrology','Métrologie optique pour semi-conducteurs'),
  ('45','ebeam_inspection_metrology','Inspection e-beam / métrologie e-beam'),
  ('45','computational_lithography_process_control','Lithographie computationnelle / logiciels de contrôle de procédé'),
  ('45','lithography_equipment_services_support','Services et support des équipements de lithographie'),
  ('20','electrical_distribution_electrification','Électrification / distribution électrique'),
  ('20','energy_management','Gestion de l’énergie'),
  ('20','industrial_automation','Automatisation industrielle'),
  ('20','industrial_digitalization_software','Digitalisation et logiciels industriels'),
  ('20','data_center_solutions','Solutions pour centres de données'),
  ('20','building_energy_management','Gestion technique et énergétique des bâtiments'),
  ('20','grid_infrastructure_solutions','Solutions pour réseaux électriques et infrastructures'),
  ('20','electrical_asset_management_services','Services de gestion des actifs électriques')
)
insert into public.sector_activities(sector_id,code,name)
select s.id,d.code,d.name
from activity_data d
join public.sectors s on s.taxonomy='gics' and s.code=d.sector_code
on conflict(sector_id,code) do update set name=excluded.name;

do $$
begin
 if (select count(*) from public.exposure_countries where code<>'unspecified') <> 249 then
  raise exception 'ISO 3166-1 catalogue must contain 249 real country codes';
 end if;
 if not exists(select 1 from public.exposure_countries where code='unspecified' and name='Non spécifié') then
  raise exception 'Technical unspecified country is missing';
 end if;
 if exists(
  select 1 from (
   select name from public.geographic_regions
   union all select name from public.exposure_countries
   union all select name from public.sector_activities
  ) labels where name like '%Ã%' or name like '%Â%' or name like '%â€%'
 ) then
  raise exception 'Mojibake remains in exposure references';
 end if;
 if (select count(*) from public.sector_activities where code in (
  'euv_lithography','duv_lithography','semiconductor_optical_metrology',
  'ebeam_inspection_metrology','computational_lithography_process_control',
  'lithography_equipment_services_support','electrical_distribution_electrification',
  'energy_management','industrial_automation','industrial_digitalization_software',
  'data_center_solutions','building_energy_management','grid_infrastructure_solutions',
  'electrical_asset_management_services'
 )) <> 14 then
  raise exception 'Initial detailed activity catalogue is incomplete';
 end if;
end
$$;

commit;
