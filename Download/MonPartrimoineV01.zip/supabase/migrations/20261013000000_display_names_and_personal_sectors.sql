begin;

alter table public.assets add column if not exists display_name text;
alter table public.contracts add column if not exists display_name text;
alter table public.assets add constraint assets_display_name_check
  check (display_name is null or (display_name = btrim(display_name) and char_length(display_name) between 1 and 120));
alter table public.contracts add constraint contracts_display_name_check
  check (display_name is null or (display_name = btrim(display_name) and char_length(display_name) between 1 and 120));

alter table public.sectors add column if not exists owner_user_id uuid references auth.users(id) on delete cascade;
create index sectors_owner_idx on public.sectors(owner_user_id);
create unique index sectors_personal_name_unique on public.sectors(owner_user_id, lower(name)) where owner_user_id is not null;

create or replace function public.create_sector(sector_name text) returns uuid language plpgsql security definer set search_path='' as $$
declare created_id uuid:=gen_random_uuid(); actor uuid:=auth.uid();
begin
 perform private.assert_analysis_catalog_access();
 if actor is null then raise exception 'Authentication required' using errcode='42501'; end if;
 if sector_name is null or length(btrim(sector_name)) not between 1 and 120 then raise exception 'Invalid sector name' using errcode='23514'; end if;
 insert into public.sectors(id,taxonomy,code,name,owner_user_id) values(created_id,'monpatrimoine','custom_'||replace(created_id::text,'-',''),btrim(sector_name),actor);
 insert into public.sector_activities(sector_id,code,name) values(created_id,'unspecified','Non détaillé');
 return created_id;
end $$;

create or replace function public.rename_sector(requested_id uuid,sector_name text) returns void language plpgsql security definer set search_path='' as $$
begin
 perform private.assert_analysis_catalog_access();
 if sector_name is null or length(btrim(sector_name)) not between 1 and 120 then raise exception 'Invalid sector name' using errcode='23514'; end if;
 update public.sectors set name=btrim(sector_name),updated_at=now() where id=requested_id and owner_user_id=auth.uid();
 if not found then raise exception 'Only a personal sector can be renamed' using errcode='42501'; end if;
end $$;

create or replace function public.set_sector_active(requested_id uuid,active boolean) returns void language plpgsql security definer set search_path='' as $$
begin
 perform private.assert_analysis_catalog_access();
 if active is null then raise exception 'Invalid sector status' using errcode='23514'; end if;
 update public.sectors set is_active=active,updated_at=now() where id=requested_id and owner_user_id=auth.uid();
 if not found then raise exception 'Only a personal sector can be changed' using errcode='42501'; end if;
end $$;

create or replace function public.delete_sector(requested_id uuid) returns void language plpgsql security definer set search_path='' as $$
begin
 perform private.assert_analysis_catalog_access();
 perform 1 from public.sectors where id=requested_id and owner_user_id=auth.uid() for update;
 if not found then raise exception 'Only a personal sector can be deleted' using errcode='42501'; end if;
 if exists(select 1 from public.asset_sector_exposures where sector_id=requested_id)
 or exists(select 1 from public.asset_activity_exposures e join public.sector_activities a on a.id=e.activity_id where a.sector_id=requested_id)
 or exists(select 1 from public.sector_activities where sector_id=requested_id and has_been_used)
 then raise exception 'Sector is referenced' using errcode='23503'; end if;
 delete from public.sector_activities where sector_id=requested_id;
 delete from public.sectors where id=requested_id and owner_user_id=auth.uid();
end $$;

commit;
