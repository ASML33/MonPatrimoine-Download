export type ThemePreference = "dark" | "light";

export function readThemePreference(value: unknown): ThemePreference {
  if (
    typeof value === "object" &&
    value !== null &&
    "theme" in value &&
    value.theme === "light"
  ) {
    return "light";
  }

  return "dark";
}

export function capitalizeNickname(nickname: string) {
  return nickname.length === 0
    ? nickname
    : nickname[0].toUpperCase() + nickname.slice(1);
}
