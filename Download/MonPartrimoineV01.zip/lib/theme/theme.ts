import "server-only";

import { getCurrentInterfacePreferences } from "@/lib/interface-preferences";
import { readThemePreference } from "@/lib/theme/theme-core";

export async function getCurrentTheme() {
  const preferences = await getCurrentInterfacePreferences();
  return readThemePreference(preferences);
}
