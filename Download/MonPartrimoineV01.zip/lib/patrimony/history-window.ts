import { historicalSelectionIds, isDateInContractScope, type ChartContract, type ChartPoint } from "@/lib/patrimony/chart-core";

const finite = (value: unknown): value is number => typeof value === "number" && Number.isFinite(value);

// Maintained values keep their source date, not a new valuation date. Native
// financial captures and legacy observations otherwise retain their own date.
export function historyValuationDate(point: ChartPoint, id: string, contracts: readonly ChartContract[]): string | null {
  if (id === "employee-savings-combined") return finite(point.employeeSavingsCombined) ? point.date : null;
  const contract = contracts.find(c => c.id === id.split(":")[1]);
  if (!contract || !isDateInContractScope(point.date, contract.openedOn)) return null;
  const value = id.startsWith("contract:") ? point.values[`${id}:gross`] ?? point.values[`${id}:net`] : point.values[id];
  // A partially known contract may have a real dated component even though its
  // complete value is unavailable. Keep that date without inventing its total.
  if (!finite(value)) return id.startsWith("contract:")
    ? contract.children.flatMap(child => { const date = historyValuationDate(point, child.id, contracts); return date ? [date] : []; }).sort().at(-1) ?? null
    : null; // Explicit zero is evidence; unknown alone is not.
  const employee = point.employeeSavingsEvidence?.[contract.id];
  if (employee && id.startsWith("contract:")) return employee.date;
  const property = id.startsWith("contract:")
    ? contract.children.flatMap(c => point.propertyEvidence?.[c.id] ? [point.propertyEvidence[c.id]] : [])
    : point.propertyEvidence?.[id] ? [point.propertyEvidence[id]] : [];
  if (property.length && property.every(e => e.observation?.origin === "manual"))
    return property.map(e => e.observation!.effectiveOn).sort().at(-1)!;
  if (point.valuationSourceDates && id in point.valuationSourceDates) return point.valuationSourceDates[id];
  return point.date;
}

// Keep interior gaps and steps. Only trim the unsubstantiated tail, for the
// actual selection; another contract cannot extend a fixed/partial selection.
export function historyPointsForSelection(points: readonly ChartPoint[], ids: string[], contracts: readonly ChartContract[]): ChartPoint[] {
  let end: string | null = null;
  let start: string | null = null;
  let projected=false;
  const catalog = [...contracts];
  for (const point of points) for (const id of historicalSelectionIds(point, ids, catalog)) {
    const date = historyValuationDate(point, id, contracts);
    if (date && date <= point.date && (!end || date > end)) end = date;
    if(date&&date<=point.date&&(!start||point.date<start))start=point.date;
    // Explicit native read projections may reach the consultation date while
    // retaining the older valuation source date for provenance and exports.
    const evidence=point.continuityEvidence?.[id.split(':')[1]];
    if(date&&evidence?.throughDate===point.date){projected=true;if(!end||point.date>end)end=point.date;}
  }
  return end ? points.filter(point => point.date <= end!&&(!projected||!start||point.date>=start)) : [];
}
