import type { ChartContract, ChartPoint } from "./chart-core";
import type { HistoricalSource } from "./historical-observations";
import { convertToEur, latestFxRatesByCurrency, type FxRateRecord } from "@/lib/fx/fx-core";
import { parisDate } from "./current-valuation-core";

export type InitialCashPeriod = { kind: "approved_initial_cash_period"; version: 1; contractId: string; from: string; through: string; amount: string; currency: string; confirmedOn: string; provenance: string };
export type InitialCashEvidence = InitialCashPeriod & { sourceId: string };
const day = (d: string) => /^\d{4}-\d{2}-\d{2}$/.test(d) && Number.isFinite(Date.parse(d)) && new Date(d).toISOString().slice(0, 10) === d;
const next = (d: string) => new Date(Date.parse(d + "T12:00:00Z") + 86400000).toISOString().slice(0, 10);

// An explicit, bounded historical declaration. It is neither an inferred cash
// balance from a flow, nor a new current holding/price/snapshot. Native history,
// including an explicitly unknown captured total, keeps its authority.
export function projectInitialCashPeriods(points: readonly ChartPoint[], contracts: readonly ChartContract[], sources: readonly HistoricalSource[], rates: readonly FxRateRecord[], now: string): ChartPoint[] {
  const periods = sources.filter(s => s.payload.kind === "approved_initial_cash_period" && (!s.imported_at || Date.parse(s.imported_at) <= Date.parse(now))).map(source => {
    const p = source.payload as unknown as InitialCashPeriod;
    if (p.version !== 1 || !day(p.from) || !day(p.through) || !day(p.confirmedOn) || p.from > p.through || p.through > p.confirmedOn || p.confirmedOn > parisDate(now) || p.from !== source.business_date
      || !/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(p.contractId) || !/^\d{1,16}(?:\.\d{1,8})?$/.test(p.amount)
      || !Number.isFinite(Number(p.amount)) || !/^[A-Z]{3}$/.test(p.currency) || !p.provenance?.trim()) throw Error("Déclaration initiale d’espèces invalide.");
    const c = contracts.find(c => c.id === p.contractId);
    if (!c || !["pea", "pea_pme", "cto", "compte_titres", "epargne_liquide"].includes(c.envelopeTypeCode ?? "") || c.openedOn && p.from < c.openedOn
      || c.envelopeTypeCode === "epargne_liquide" && c.children.some(child => child.kind === "asset")) throw Error("Déclaration initiale incompatible avec le contrat.");
    return { ...p, sourceId: source.id };
  });
  for (const p of periods) if (periods.some(q => q !== p && q.contractId === p.contractId && q.from <= p.through && q.through >= p.from)) throw Error("Déclarations d’espèces concurrentes.");
  if (!periods.length) return points as ChartPoint[];
  const result = new Map(points.map(p => [p.date, p]));
  for (const p of periods) for (let date = p.from; date <= p.through && date <= parisDate(now); date = next(date)) {
    const original = result.get(date), key = `contract:${p.contractId}:gross`, cash = `cash:${p.contractId}`;
    if (original && key in original.values) continue;
    const c = contracts.find(c => c.id === p.contractId)!;
    if (original && c.children.some(ch => ch.kind === "asset" && (typeof original.quantities[ch.id] === "number" && original.quantities[ch.id]! > 0 || original.values[ch.id] != null && original.quantities[ch.id] !== 0))) throw Error("Une détention connue contredit la déclaration d’espèces seules.");
    const point: ChartPoint = original ? structuredClone(original) : { date, values: {}, cash: {}, quantities: {}, contributions: {}, netKinds: {}, employeeSavingsCombined: null, provenance: "Déclaration initiale d’espèces" };
    const amount = convertToEur(p.amount, p.currency, latestFxRatesByCurrency([...rates], date).get(p.currency)).amountEur;
    if (typeof original?.cash[cash] === "number" && original.cash[cash] !== amount) throw Error("Un solde connu contredit la déclaration initiale.");
    point.values[key] = point.values[cash] = point.cash[cash] = amount;
    point.values[`contract:${p.contractId}:net`] = c.envelopeTypeCode === "epargne_liquide" ? amount : null;
    point.netKinds[p.contractId] = c.envelopeTypeCode === "epargne_liquide" && amount !== null ? "calculated" : "unavailable";
    point.initialCashEvidence = { ...point.initialCashEvidence, [p.contractId]: p };
    point.valuationSourceDates = { ...point.valuationSourceDates, [`contract:${p.contractId}`]: p.from, [cash]: p.from };
    point.continuityEvidence = { ...point.continuityEvidence, [p.contractId]: { sourceDate: p.from, throughDate: date } };
    point.provenanceByContract = { ...point.provenanceByContract, [p.contractId]: `${p.provenance} · espèces seules du ${p.from} au ${p.through} · aucune position ni nouveau versement créé` };
    result.set(date, point);
  }
  return [...result.values()].sort((a, b) => a.date.localeCompare(b.date));
}
