import type { ChartContract } from "./chart-core";
import { parisBusinessDate } from "@/lib/dates/business-date";
import { historyPointsForSelection } from "./history-window";
import type { ChartPoint } from "./chart-core";

// Consultation boundary, not a deletion or a replacement of source dates.
export const PATRIMONY_HISTORY_START = "2026-02-13";
export const inPatrimonyHistory = (date: string) => /^\d{4}-\d{2}-\d{2}$/.test(date) && date >= PATRIMONY_HISTORY_START;
export const inPatrimonyHistoryAt = (instant: string) => Number.isFinite(Date.parse(instant)) && inPatrimonyHistory(parisBusinessDate(instant));

// Presentation only: shared financial data and CSV exports keep their history.
// Apply after all selections/projections, so older evidence remains usable.
export function graphHistoryPointsForSelection(points: readonly ChartPoint[], ids: string[], contracts: readonly ChartContract[]): ChartPoint[] {
  return historyPointsForSelection(points, ids, contracts).filter(point => inPatrimonyHistory(point.date));
}

const order = new Intl.Collator("fr-FR", { sensitivity: "base", numeric: true });
const ranks: Record<string, number> = {
  immobilier: 0, epargne_liquide: 1, peg: 2, per_col: 3, assurance_vie: 4,
  pea: 5, pea_pme: 5, cto: 5, compte_titres: 5,
};

// Layers run bottom to top; reverse contract names so the legend reads A to Z.
// Only the patrimony presentation uses this order. Financial selection and
// contract-specific cash/title ordering remain independent.
export function orderPatrimonySeries<T extends { id: string; label: string }>(series: readonly T[], contracts: readonly ChartContract[]): T[] {
  const contract = (id: string) => contracts.find(c => c.id === id.split(":")[1]);
  const rank = (id: string) => id === "employee-savings-combined" ? 2.5 : ranks[contract(id)?.envelopeTypeCode ?? ""] ?? 6;
  return [...series].sort((a, b) => {
    const category = rank(a.id) - rank(b.id);
    if (category) return category;
    const left = contract(a.id), right = contract(b.id);
    if (left?.id !== right?.id) return order.compare(right?.name ?? b.label, left?.name ?? a.label) || (right?.id ?? b.id).localeCompare(left?.id ?? a.id, "en");
    return Number(b.id.startsWith("cash:")) - Number(a.id.startsWith("cash:")) || order.compare(a.label, b.label) || a.id.localeCompare(b.id, "en");
  });
}
