import type {ChartContract,ChartPoint} from "./chart-core";
import type {HistoricalObservation,HistoricalSource} from "./historical-observations";

export const GROSS_OBSERVATION_KIND="approved_manual_gross_observation";
export type ApprovedGrossObservation={kind:typeof GROSS_OBSERVATION_KIND;version:1;businessDate:string;contractId:string;sourceKey:"peg"|"per_col";observationId:string;grossEur:string;netEur?:string|null;currency:"EUR";sourceTimePrecision:"date";currentValuationOverride:false;provenance:string;confirmedOn:string;recordedAt:string;replacesSourceId:string|null;baselineCaptureId:string|null;baselineSourceId:string|null;baselineManualSituationIds:string[]};
export type GrossObservationEvidence={sourceId:string;observationId:string;grossEur:string;provenance:string;recordedAt:string;version:number;baselineCaptureId:string|null;baselineSourceId:string|null;previousGross:number|null;previousNet:number|null};
const uuid=/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const civilDate=(v:string)=>/^\d{4}-\d{2}-\d{2}$/.test(v)&&Number.isFinite(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v;
export function approvedGrossObservations(sources:readonly HistoricalSource[]){
 const groups=new Map<string,Array<{source:HistoricalSource;value:ApprovedGrossObservation}>>();
 for(const source of sources.filter(s=>s.payload.kind===GROSS_OBSERVATION_KIND)){
  const p=source.payload as unknown as ApprovedGrossObservation;
  if(p.version!==1||p.businessDate!==source.business_date||!civilDate(p.businessDate)||!uuid.test(p.contractId)||p.observationId!==source.id||!uuid.test(p.observationId)||p.currentValuationOverride!==false
   ||!["peg","per_col"].includes(p.sourceKey)||p.currency!=="EUR"||p.sourceTimePrecision!=="date"||!/^\d{1,16}\.\d{2}$/.test(p.grossEur)||!Number.isFinite(Number(p.grossEur))
   ||p.netEur!=null&&(!/^\d{1,16}\.\d{2}$/.test(p.netEur)||!Number.isFinite(Number(p.netEur))||p.sourceKey!=="peg")
   ||!p.provenance?.trim()||!civilDate(p.confirmedOn)||!Number.isFinite(Date.parse(p.recordedAt))
   ||![p.replacesSourceId,p.baselineCaptureId,p.baselineSourceId].every(id=>id===null||uuid.test(id))||!Array.isArray(p.baselineManualSituationIds)||p.baselineManualSituationIds.some(id=>!uuid.test(id)))throw Error("Observation BRUT approuvée incohérente.");
  const key=`${p.contractId}:${p.businessDate}`;groups.set(key,[...(groups.get(key)??[]),{source,value:p}]);
 }
 return [...groups.values()].map(rows=>{
  const roots=rows.filter(r=>r.value.replacesSourceId===null);if(roots.length!==1)throw Error("Autorités BRUT concurrentes ou remplacement non relié.");
  let selected=roots[0];const visited=new Set([selected.source.id]);let version=1;
  while(true){const next=rows.filter(r=>r.value.replacesSourceId===selected.source.id);if(next.length>1)throw Error("Corrections BRUT concurrentes non arbitrées.");if(!next.length)break;selected=next[0];if(visited.has(selected.source.id))throw Error("Cycle de correction BRUT.");visited.add(selected.source.id);version++;}
  if(visited.size!==rows.length)throw Error("Correction BRUT non reliée à son prédécesseur.");
  return {...selected,version};
 });
}

// Exact civil dates only. No interval continuation and no synthetic capture.
// The archived group remains a proof; two approved individual observations
// explicitly replace its effective representation at this date alone.
export function applyApprovedGrossObservations(points:readonly ChartPoint[],contracts:readonly ChartContract[],sources:readonly HistoricalSource[],observations:readonly HistoricalObservation[]=[]):ChartPoint[]{
 const selected=approvedGrossObservations(sources);if(!selected.length)return points as ChartPoint[];
 const result=new Map(points.map(p=>[p.date,p]));
 for(const item of selected){
  const {value:p,source}=item;const contract=contracts.find(c=>c.id===p.contractId);
  if(!contract)continue;
  if(contract.sourceKey!==p.sourceKey||contract.envelopeTypeCode!==p.sourceKey||contract.openedOn&&p.businessDate<contract.openedOn)throw Error("Observation BRUT incompatible avec l’identité ou la borne du contrat.");
  if(p.baselineCaptureId&&!observations.some(r=>r.id===p.baselineCaptureId&&r.business_date===p.businessDate))throw Error("Capture d’origine BRUT introuvable.");
  if(p.baselineSourceId&&!sources.some(s=>s.id===p.baselineSourceId&&s.business_date===p.businessDate))throw Error("Source d’origine BRUT introuvable.");
  const previous=result.get(p.businessDate)??{date:p.businessDate,values:{},cash:{},contributions:{},quantities:{},netKinds:{},employeeSavingsCombined:null,provenance:p.provenance};
  const oldEvidence=previous.manualGrossEvidence?.[p.contractId];
  const evidence:GrossObservationEvidence={sourceId:source.id,observationId:p.observationId,grossEur:p.grossEur,provenance:p.provenance,recordedAt:p.recordedAt,version:item.version,baselineCaptureId:p.baselineCaptureId,baselineSourceId:p.baselineSourceId,previousGross:oldEvidence?oldEvidence.previousGross:previous.values[`contract:${p.contractId}:gross`]??null,previousNet:oldEvidence?oldEvidence.previousNet:previous.values[`contract:${p.contractId}:net`]??null};
  const point:ChartPoint={...previous,values:{...previous.values,[`contract:${p.contractId}:gross`]:Number(p.grossEur),[`contract:${p.contractId}:net`]:p.netEur==null?null:Number(p.netEur)},sourceNets:{...previous.sourceNets},netKinds:{...previous.netKinds,[p.contractId]:p.netEur==null?"unavailable":"approximate"},netReasons:{...previous.netReasons,[p.contractId]:p.netEur==null?"BRUT déclaré sans NET fourni ; aucun ancien NET ou gain fiscal associé.":"NET déclaré par l’utilisateur ; non calculé ni certifié."},provenanceByContract:{...previous.provenanceByContract,[p.contractId]:p.provenance},manualGrossEvidence:{...previous.manualGrossEvidence,[p.contractId]:evidence}};
  delete point.sourceNets![p.contractId];
  result.set(p.businessDate,point);
 }
 const members=contracts.filter(c=>c.sourceKey==="peg"||c.sourceKey==="per_col");
 for(const [date,point] of result){if(point.employeeSavingsCombined===null||members.length!==2||!members.every(c=>point.manualGrossEvidence?.[c.id]))continue;
  result.set(date,{...point,archivedEmployeeSavingsCombined:point.employeeSavingsCombined,employeeSavingsCombined:null});
 }
 return [...result.values()].sort((a,b)=>a.date.localeCompare(b.date));
}
