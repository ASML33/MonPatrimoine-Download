// Presentation only. A missing row differs from an off-screen selected date.
export function historyDetailVisibility(selectedDate: string | null | undefined, closed: boolean,
  hasSelectedRow: boolean, period: { first: string; last: string } | null) {
  if (!selectedDate || closed) return 'closed';
  if (!hasSelectedRow) return 'unavailable';
  return period && selectedDate >= period.first && selectedDate <= period.last ? 'visible' : 'outside';
}
