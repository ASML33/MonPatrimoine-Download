import { selectHistoricalObservations, type HistoricalObservation } from "./historical-observations";
import type { RawPublishedExposure, ExposureDimension } from "@/lib/assets/exposure-history";
// Authority/revisions are resolved per asset and dimension. An absent dimension
// in a later capture cannot erase an earlier present proof at the same date.
export function selectExposureObservations<T extends HistoricalObservation>(captures: readonly T[]) {
 const groups=new Map<string,{assetId:string;dimension:ExposureDimension;captures:T[]}>();
 for(const capture of captures){
  const inputs=capture.inputs as {exposures?:RawPublishedExposure[]}|undefined;
  const present=new Map((inputs?.exposures ?? []).filter(row=>row.stage==="effective").map(row=>[`${row.asset_id}:${row.dimension}`,row]));
  for(const [identity,row] of present){const key=`${capture.business_date}:${identity}`,group=groups.get(key)??{assetId:row.asset_id,dimension:row.dimension,captures:[]};group.captures.push(capture);groups.set(key,group);}
 }
 return [...groups.values()].map(group=>({...group,capture:selectHistoricalObservations(group.captures)[0].selected}));
}
