import { chartValue, historicalHoldingState, type ChartContract, type ChartPoint } from "./chart-core";
import { historicalRows, type HistorySeries } from "./history-geometry";

// Presentation only. Identities and values come from the dated native model.
export function lifeInsuranceSupportIds(contract: ChartContract) {
  return contract.children.filter(c => c.kind === "asset").sort((a,b) =>
    Number(b.euroFund === true) - Number(a.euroFund === true) || a.id.localeCompare(b.id, "en")
  ).map(c => c.id);
}

export function lifeInsuranceSupportRows(points: ChartPoint[], series: HistorySeries[], contracts: ChartContract[], contract: ChartContract, hidden: string[] = []) {
  const children = contract.children.filter(c => c.kind === "asset");
  const fallback = `contract:${contract.id}`;
  return points.map(point => {
    const total = chartValue(point, fallback, "gross");
    const values = children.map(c => historicalHoldingState(point,c.id,contracts) === "absent" ? 0
      : historicalHoldingState(point,c.id,contracts) === "unknown" ? null : chartValue(point,c.id,"gross"));
    const sum = values.reduce<number>((s,v) => s + (v ?? 0),0);
    // Never allocate a known total to today's inventory. Require every native
    // component and agreement with the original total, including explicit zero.
    const qualified = contract.valuationAuthority !== "global" && children.length > 0 && values.every(v => v !== null && Number.isFinite(v))
      && total !== null && Number.isFinite(total) && Math.abs(sum-total) < 1e-8;
    const active = qualified ? children.map(c=>c.id) : total !== null ? [fallback] : children.map(c=>c.id);
    return historicalRows([point],series,contracts,"gross",active.filter(id=>!hidden.includes(id)))[0];
  });
}
