import { chartValue, type ChartContract, type ChartMode, type ChartPoint } from "./chart-core";
import { historicalRows, type HistorySeries } from "./history-geometry";

// A whole-contract source can replace only a whole-contract selection.
// It never supplies an allocation or a value for a selected subset of titles.
export function ctoNetHistoryContract(contracts: ChartContract[], ids: string[], mode: ChartMode) {
  if (mode !== "net") return undefined;
  return contracts.find(c => c.envelopeTypeCode === "cto" && c.children.length > 0
    && ids.length === c.children.length && c.children.every(child => ids.includes(child.id)));
}

export function ctoNetHistoryRows(points: ChartPoint[], series: HistorySeries[], contracts: ChartContract[], contract: ChartContract) {
  const detail = contract.children.map(child => child.id), global = `contract:${contract.id}`;
  return points.map(point => {
    const row = historicalRows([point], series, contracts, "net", detail)[0];
    // Zero quantities do not prove an opening cash balance. Require a dated
    // complete gross authority as well as all individually known NET inputs.
    const gross = chartValue(point, global, "gross");
    const emptySource = typeof point.sourceNets?.[contract.id] === "number"
      && !contract.children.some(child => child.kind === "asset" && Number(point.quantities[child.id]) > 0);
    if (row.valid && !emptySource && typeof gross === "number" && Number.isFinite(gross)) {
      // A complete title formula can still use an indicative historical FX.
      // Keep the contract's qualified approximation visible in the detail.
      return point.netKinds[contract.id] === "approximate" ? { ...row, quality: "Net approximatif" } : row;
    }
    const net = chartValue(point, global, "net");
    if (typeof net === "number" && Number.isFinite(net) && net >= 0
      && point.netKinds[contract.id] !== "unavailable"
      && (!contract.openedOn || point.date >= contract.openedOn)) {
      const source = historicalRows([point], series, contracts, "net", [global])[0];
      return { ...source, netReasons: [...source.netReasons, "NET historique global non ventilé ; aucun montant réparti entre titres."] };
    }
    return { ...row, valid: false, quality: "Net indisponible", netReasons: [...row.netReasons, point.netReasons?.[contract.id] ?? "Valorisation complète du contrat non documentée à cette date."] };
  });
}

// Keep partial data in the table, but do not draw cash alone as a complete CTO.
export function ctoNetPlotRows(rows: ReturnType<typeof historicalRows>) {
  return rows.map(row => row.valid ? row : { ...row, activeIds: [] });
}

export function ctoNetHistoryCoverage(rows: ReturnType<typeof historicalRows>, contract: ChartContract) {
  const groups: { kind: "global" | "detail" | "unknown"; first: string; last: string; count: number }[] = [];
  for (const row of rows) {
    const kind = !row.valid ? "unknown" : row.activeIds.includes(`contract:${contract.id}`) ? "global" : "detail";
    const previous = groups.at(-1);
    if (previous?.kind === kind && Date.parse(row.point.date) - Date.parse(previous.last) === 86400000) {
      previous.last = row.point.date; previous.count++;
    } else groups.push({ kind, first: row.point.date, last: row.point.date, count: 1 });
  }
  return groups;
}
