import { historicalGain, type ChartPoint, type ChartChild } from './chart-core';

// Use the selected point's qualified EUR basis, never today's PRU or plotted NET.
export function historicalSeriesGain(point: ChartPoint, id: string, child?: ChartChild): { percentage: number | null } | null {
  if (child?.kind !== 'asset' || point.amountTrackedIds?.includes(id) ||
      !(child.quantified === true || point.quantities[id] != null)) return null;
  const inputs = [point.values[id], point.quantities[id], point.historicalUnitCosts?.[id]];
  if (inputs.some(value => typeof value !== 'number' || !Number.isFinite(value))) return { percentage: null };
  const result = historicalGain(point.values, point.quantities, point.historicalUnitCosts ?? {}, [id]);
  const percentage = result.percentage;
  if (percentage === null || !Number.isFinite(percentage)) return { percentage: null };
  const rounded = Math.round((Math.abs(percentage) + Number.EPSILON) * 100) / 100;
  return { percentage: rounded === 0 ? 0 : Math.sign(percentage) * rounded };
}
