import type { ChartContract, ChartPoint } from './chart-core';

export const HISTORY_DAY = 86400000;
export const HISTORY_PAD = 36;
const civilTime = (date: string) => Date.parse(date + 'T12:00:00Z');
const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));

// Temporal scope only: every possible presentation of this contract (or of the
// allowed portfolio), independent of BRUT/NET, filters and financial availability.
export function historyTimeScopeIds(contracts: ChartContract[], fixedId: string | null, excluded: string[] = []) {
  const scope = contracts.filter(c => fixedId ? c.id === fixedId : !excluded.includes(c.id));
  return [...new Set(scope.flatMap(c => [`contract:${c.id}`, ...c.children.map(ch => ch.id),
    ...(['peg', 'per_col'].includes(c.sourceKey ?? '') ? ['employee-savings-combined'] : [])]))];
}

export function historyTimeDomain(points: readonly Pick<ChartPoint, 'date'>[]) {
  const dates = points.map(p => p.date).filter(d => Number.isFinite(civilTime(d))).sort();
  const first = dates[0] ?? null, last = dates.at(-1) ?? null;
  return { first, last, firstTime: first ? civilTime(first) : 0,
    spanDays: first && last ? Math.round((civilTime(last) - civilTime(first)) / HISTORY_DAY) : 0 };
}
export type HistoryTimeDomain = ReturnType<typeof historyTimeDomain>;
export type HistoryTimeAnchor = { centerTime: number; atEnd: boolean };
export type HistoryViewportState = { intervals: number | null; anchor: HistoryTimeAnchor };
export type HistoryViewportRef = { current: HistoryViewportState | null };

// Reference: the delivered long-history PEA BRUT uses (W - 72) / 29,
// with a one-pixel lower bound. The common default is exactly half of it,
// clamped only by fit-all and the five-date bound of a short history.
export function historyTimeScale(domain: HistoryTimeDomain, viewport: number, requestedIntervals: number | null, padding = HISTORY_PAD) {
  const viewportWidth = Math.max(1, viewport), plotWidth = Math.max(1, viewportWidth - padding * 2);
  const span = Math.max(1, domain.spanDays), minimumIntervals = Math.min(4, span);
  const referenceDayWidth = Math.max(1, plotWidth / 29), defaultDayWidth = referenceDayWidth / 2;
  const intervals = clamp(requestedIntervals ?? plotWidth / defaultDayWidth, minimumIntervals, span);
  const dayWidth = plotWidth / intervals, width = Math.max(viewportWidth, padding * 2 + domain.spanDays * dayWidth);
  const zoom = span === minimumIntervals ? 0 : 100 * Math.log(span / intervals) / Math.log(span / minimumIntervals);
  return { ...domain, padding, viewportWidth, plotWidth, dayWidth, width, intervals, referenceDayWidth,
    defaultDayWidth, zoom, disabled: domain.spanDays <= 4, atMaximum: intervals === minimumIntervals };
}
export type HistoryTimeScale = ReturnType<typeof historyTimeScale>;

export function historyIntervalsAtZoom(domain: HistoryTimeDomain, zoom: number) {
  const span = Math.max(1, domain.spanDays), minimum = Math.min(4, span);
  if (zoom <= 0) return span;
  if (zoom >= 100) return minimum;
  return span * Math.pow(minimum / span, clamp(zoom, 0, 100) / 100);
}
export function historyTimeX(scale: HistoryTimeScale, date: string) {
  return scale.spanDays === 0 ? scale.viewportWidth / 2
    : scale.padding + (civilTime(date) - scale.firstTime) / HISTORY_DAY * scale.dayWidth;
}
export function historyTimeAnchor(scale: HistoryTimeScale, left: number): HistoryTimeAnchor {
  return { atEnd: scale.width - scale.viewportWidth - left <= 1.5,
    centerTime: scale.firstTime + (left + scale.viewportWidth / 2 - scale.padding) / scale.dayWidth * HISTORY_DAY };
}
export function historyTimeScroll(scale: HistoryTimeScale, anchor: HistoryTimeAnchor) {
  const maximum = Math.max(0, scale.width - scale.viewportWidth);
  if (anchor.atEnd) return maximum;
  let left = scale.padding + (anchor.centerTime - scale.firstTime) / HISTORY_DAY * scale.dayWidth - scale.viewportWidth / 2;
  // At the five-date bound, align on civil days (at most half a day of
  // centering adjustment). No value or source date is interpolated.
  if (scale.atMaximum) left = Math.round(left / scale.dayWidth) * scale.dayWidth;
  return clamp(left, 0, maximum);
}
export function historyVisiblePeriod(scale: HistoryTimeScale, left: number) {
  if (!scale.first || !scale.last) return null;
  // DOM scroll offsets/scrollWidth can round fractional SVG pixels. Include
  // edge dates within one raster pixel, like the plot's stroke padding.
  const tolerance = 1 / scale.dayWidth;
  const start = clamp(Math.ceil(left / scale.dayWidth - tolerance), 0, scale.spanDays);
  const end = clamp(Math.floor((left + scale.plotWidth) / scale.dayWidth + tolerance), start, scale.spanDays);
  const date = (day: number) => new Date(scale.firstTime + day * HISTORY_DAY).toISOString().slice(0, 10);
  return { first: date(start), last: date(end), dates: end - start + 1 };
}

// Calendar labels only, never observations, financial rows or CSV contents.
export function historyAxisDates(scale: HistoryTimeScale, left: number) {
  const period = historyVisiblePeriod(scale, left);
  if (!period) return [];
  const span = Math.round((civilTime(period.last) - civilTime(period.first)) / HISTORY_DAY);
  const count = Math.min(6, span + 1);
  return [...new Set(Array.from({ length: count }, (_, i) =>
    Math.round(i * span / Math.max(1, count - 1))))].map(day => {
      const date = new Date(civilTime(period.first) + day * HISTORY_DAY).toISOString().slice(0, 10);
      return { date, x: historyTimeX(scale, date) };
    });
}
