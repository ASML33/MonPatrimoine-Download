import type { ChartContract, ChartPoint } from "./chart-core";
import type { HistoricalObservation, HistoricalSource } from "./historical-observations";

export type ContractCorrection = {
  kind: "approved_contract_correction"; version: 1; businessDate: string; contractId: string;
  baselineCaptureId: string; replacesSourceId: string; provenance: string; confirmedOn: string;
  grossEur: number; netEur: number; contributionsEur: number; cashEur: number;
  holdings: Array<{ assetId: string; presence: "present" | "absent"; quantity: number | null; totalValueEur: number | null; sourceObjectivePercent: number | null }>;
};
function finite(value: unknown): value is number { return typeof value === "number" && Number.isFinite(value); }
function parse(source: HistoricalSource): ContractCorrection {
  const p = source.payload as unknown as ContractCorrection;
  if (p.version !== 1 || p.businessDate !== source.business_date || !p.contractId || !p.baselineCaptureId || !p.replacesSourceId
    || !p.provenance?.trim() || !/^\d{4}-\d{2}-\d{2}$/.test(p.confirmedOn ?? "")
    || ![p.grossEur, p.netEur, p.contributionsEur, p.cashEur].every(finite) || p.grossEur < 0 || p.netEur < 0 || p.netEur > p.grossEur || p.contributionsEur < 0
    || !Array.isArray(p.holdings) || new Set(p.holdings.map(h => h.assetId)).size !== p.holdings.length
    || p.holdings.some(h => !h.assetId || !["present", "absent"].includes(h.presence)
      || (h.presence === "present" ? !finite(h.quantity) || h.quantity <= 0 || !finite(h.totalValueEur) || h.totalValueEur < 0 : h.quantity !== null || h.totalValueEur !== null)
      || (h.sourceObjectivePercent !== null && (!finite(h.sourceObjectivePercent) || h.sourceObjectivePercent < 0 || h.sourceObjectivePercent > 100))))
    throw new Error("Correction historique approuvée incohérente.");
  return p;
}

// Append-only evidence overlays one selected contract/day, never current data.
// A replacement chain must start at the exact selected source and cannot fork.
export function applyApprovedContractCorrections(points: ChartPoint[], contracts: readonly ChartContract[], selected: readonly HistoricalObservation[], sources: readonly HistoricalSource[]) {
  const corrections = sources.filter(s => s.payload.kind === "approved_contract_correction").map(source => ({ source, value: parse(source) }));
  if (!corrections.length) return points;
  for (const { value } of corrections) {
    if (!points.some(p => p.date === value.businessDate) || !contracts.some(c => c.id === value.contractId)) continue;
    const row = selected.find(r => r.business_date === value.businessDate);
    if (!row || row.id !== value.baselineCaptureId || !row.result.report.contracts.some(c => c.id === value.contractId))
      throw new Error("La correction ne remplace pas la situation historique sélectionnée.");
  }
  return points.map(original => {
    if (!corrections.some(c => c.value.businessDate === original.date && contracts.some(contract => contract.id === c.value.contractId))) return original;
    const point = { ...original, values: { ...original.values }, quantities: { ...original.quantities }, cash: { ...original.cash }, contributions: { ...original.contributions },
      sourceNets: { ...original.sourceNets }, netKinds: { ...original.netKinds }, netReasons: { ...original.netReasons }, historicalUnitCosts: { ...original.historicalUnitCosts },
      provenanceByContract: { ...original.provenanceByContract }, declaredContractTotals: { ...original.declaredContractTotals } };
    for (const contract of contracts) {
      const candidates = corrections.filter(c => c.value.contractId === contract.id && c.value.businessDate === point.date);
      if (!candidates.length) continue;
      const row = selected.find(r => r.business_date === point.date)!;
      const sourceHash = (row.inputs as { sourceSha256?: string })?.sourceSha256;
      const roots = sources.filter(s => s.business_date === point.date && s.source_sha256 === sourceHash && s.payload.kind !== "approved_contract_correction");
      if (roots.length !== 1) throw new Error("Source remplacée absente ou ambiguë.");
      let predecessor = roots[0].id;
      const visited = new Set<string>();
      let last: typeof candidates[number] | undefined;
      while (true) {
        const successors = candidates.filter(c => c.value.replacesSourceId === predecessor);
        if (successors.length > 1) throw new Error("Corrections historiques concurrentes non arbitrées.");
        if (!successors.length) break;
        last = successors[0];
        if (visited.has(last.source.id)) throw new Error("Cycle de remplacement historique.");
        visited.add(last.source.id); predecessor = last.source.id;
      }
      if (!last || visited.size !== candidates.length) throw new Error("Correction historique non reliée à sa source.");
      const correction = last.value;
      const known = row.result.historicalInventory?.filter(h => h.contractId === contract.id) ?? [];
      if (known.length !== correction.holdings.length || known.some(h => !correction.holdings.some(c => c.assetId === h.assetId)))
        throw new Error("Périmètre des détentions historiques différent.");
      for (const holding of correction.holdings) {
        const key = `asset:${contract.id}:${holding.assetId}`;
        if (!contract.children.some(c => c.id === key)) throw new Error("Actif historique non identifié.");
        point.values[key] = holding.presence === "absent" ? 0 : holding.totalValueEur;
        point.quantities[key] = holding.presence === "absent" ? 0 : holding.quantity;
        point.historicalUnitCosts[key] = null;
      }
      point.values[`cash:${contract.id}`] = point.cash[`cash:${contract.id}`] = correction.cashEur;
      point.values[`contract:${contract.id}:gross`] = correction.grossEur;
      point.values[`contract:${contract.id}:net`] = point.sourceNets[contract.id] = correction.netEur;
      point.contributions[contract.id] = correction.contributionsEur;
      point.netKinds[contract.id] = "approximate";
      delete point.netReasons[contract.id];
      point.provenanceByContract[contract.id] = `${correction.provenance} · NET fourni manuellement · coûts historiques inconnus`;
      point.declaredContractTotals[contract.id] = { grossEur: correction.grossEur, componentSumEur: correction.cashEur + correction.holdings.reduce((sum,h) => sum + (h.totalValueEur ?? 0), 0), sourceId: last.source.id };
    }
    return point;
  });
}

// The daily-history view uses the same overlay as charts while retaining the
// original immutable observation in its secondary traces.
export function correctedHistoricalObservation(row: HistoricalObservation, sources: readonly HistoricalSource[]): HistoricalObservation {
  if (!sources.some(s => s.business_date === row.business_date && s.payload.kind === "approved_contract_correction")) return row;
  const contracts: ChartContract[] = row.result.report.contracts.map(c => ({ id: c.id, name: c.name, envelopeType: "", sourceKey: null, openedOn: null, isActive: true,
    grossEur: c.grossEur, netEur: c.netEstimatedEur, netKind: c.netKind ?? "unavailable", valuationDate: null, color: "", children: [
      { id: `cash:${c.id}`, kind: "cash", label: "Espèces", valueEur: null, color: "" },
      ...(row.result.historicalInventory ?? []).filter(h => h.contractId === c.id).map(h => ({ id: `asset:${c.id}:${h.assetId}`, kind: "asset" as const, assetId: h.assetId, label: h.name, valueEur: h.valueEur, color: "" })),
    ] }));
  const base: ChartPoint = { date: row.business_date, values: {}, cash: {}, contributions: {}, quantities: {}, netKinds: {}, employeeSavingsCombined: null, provenance: "" };
  const [point] = applyApprovedContractCorrections([base], contracts, [row], sources.filter(s => s.business_date === row.business_date));
  let difference = 0;
  const projected = row.result.report.contracts.map(c => {
    if (!point.declaredContractTotals?.[c.id]) return c;
    const gross = point.values[`contract:${c.id}:gross`]!;
    difference += gross - c.grossEur;
    return { ...c, grossEur: gross, netEstimatedEur: point.values[`contract:${c.id}:net`], legacyNetUsable: true,
      netKind: point.netKinds[c.id], fiscalWarnings: [point.provenanceByContract![c.id]], totalContributionsEur: point.contributions[c.id]! };
  });
  return { ...row, result: { ...row.result, report: { ...row.result.report, contracts: projected,
    summary: { ...row.result.report.summary, grossEur: row.result.report.summary.grossEur === null ? null : row.result.report.summary.grossEur + difference } } } };
}
