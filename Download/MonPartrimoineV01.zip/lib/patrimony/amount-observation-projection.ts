import {type DatedBalance} from "@/lib/cash/dated-balances";
import {selectHistoricalObservations,type HistoricalObservation,type HistoricalSource} from "./historical-observations";
import {selectLatestPositionSnapshots,parisDate,type CurrentPositionSnapshot} from "./current-valuation-core";
import {convertToEur,latestFxRatesByCurrency,type FxRateRecord} from "@/lib/fx/fx-core";
import type {ChartPoint,ChartContract} from "./chart-core";
type Position={id:string;contract_id:string;asset_id:string;metadata?:unknown};
// A newly attached monetary support has its own dated evidence, even before
// the first capture containing its contract. Add only actual observation days;
// never extend a current value over the intervening days or other contracts.
function initialAmountPoints(points:ChartPoint[],contracts:ChartContract[],sources:HistoricalSource[],positions:Position[],snapshots:CurrentPositionSnapshot[],rates:FxRateRecord[],now:string){
 const result=new Map(points.map(point=>[point.date,point]));
 const positionsById=new Map(positions.filter(p=>(p.metadata as {initial_amount?:{version?:unknown}}|null)?.initial_amount?.version===1).map(p=>[p.id,p]));
 const dates=new Map<string,CurrentPositionSnapshot[]>();
 for(const snapshot of snapshots){
  if(!positionsById.has(snapshot.position_id)||snapshot.market_value==null||typeof snapshot.market_value==='string'&&!snapshot.market_value.trim()||!Number.isFinite(Number(snapshot.market_value))||Number(snapshot.market_value)<0||!Number.isFinite(Date.parse(snapshot.valued_at))||Date.parse(snapshot.valued_at)>Date.parse(now))continue;
  const date=parisDate(snapshot.valued_at);dates.set(date,[...(dates.get(date)??[]),snapshot]);
 }
 for(const [date,rows]of dates){
  const original=result.get(date);
  let point=original;
  for(const snapshot of selectLatestPositionSnapshots(rows,now).values()){
   const p=positionsById.get(snapshot.position_id)!,c=contracts.find(c=>c.id===p.contract_id);
   const key=`asset:${p.contract_id}:${p.asset_id}`,grossKey=`contract:${p.contract_id}:gross`;
   if(!c||c.valuationAuthority==='global'||c.openedOn&&date<c.openedOn||!c.children.some(child=>child.id===key)
    ||original&&(grossKey in original.values||original.declaredContractTotals?.[c.id])
    ||sources.some(s=>s.business_date===date&&s.payload.kind==='approved_contract_correction'&&(s.payload as {contractId?:string}).contractId===c.id))continue; // Existing source authority, including an unknown total, wins.
   if(!point||point===original)point={...(original??{date,values:{},cash:{},contributions:{},quantities:{},netKinds:{},employeeSavingsCombined:null,provenance:'Observation monétaire datée · aucune capture générée'}),values:{...original?.values},cash:{...original?.cash},quantities:{...original?.quantities},historicalUnitCosts:{...original?.historicalUnitCosts},netKinds:{...original?.netKinds},netReasons:{...original?.netReasons},valuationSourceDates:{...original?.valuationSourceDates},provenanceByContract:{...original?.provenanceByContract},amountTrackedIds:[...(original?.amountTrackedIds??[])]};
   const value=convertToEur(snapshot.market_value,snapshot.currency_code,latestFxRatesByCurrency(rates,date).get(snapshot.currency_code)).amountEur;
   point.values[key]=value;point.quantities[key]=null;point.historicalUnitCosts![key]=null;
   point.valuationSourceDates![key]=date;point.amountTrackedIds=[...new Set([...(point.amountTrackedIds??[]),key])];
   point.values[grossKey]=c.children.length&&c.children.every(child=>typeof point!.values[child.id]==='number'&&Number.isFinite(point!.values[child.id]))
    ?c.children.reduce((sum,child)=>sum+point!.values[child.id]!,0):null;
   point.valuationSourceDates![`contract:${c.id}`]=point.values[grossKey]===null?null:date;
   point.values[`contract:${c.id}:net`]=null;point.netKinds[c.id]='unavailable';
   point.netReasons![c.id]='NET à qualifier selon les flux et les fiscalités datés existants.';
   point.provenanceByContract![c.id]='Valeur totale datée du support ; versement distinct, sans quantité ni PRU. Captures sources conservées.';
  }
  if(point&&point!==original)result.set(date,point);
 }
 return [...result.values()].sort((a,b)=>a.date.localeCompare(b.date));
}
// Project explicit monetary evidence over eligible native captures only. Original
// captures, declared totals and prior authorities remain byte-for-byte untouched.
export function projectAmountObservations(points:ChartPoint[],contracts:ChartContract[],captures:HistoricalObservation[],sources:HistoricalSource[],positions:Position[],snapshots:CurrentPositionSnapshot[],rates:FxRateRecord[],now=new Date().toISOString(),_balances:DatedBalance[]=[],forwardOnly=false){
 // Kept in the call signature for existing callers; AV is valued from supports only.
 void _balances;
 const selected=new Map(selectHistoricalObservations(captures).map(g=>[g.date,g.selected]));
 return (forwardOnly?points:initialAmountPoints(points,contracts,sources,positions,snapshots,rates,now)).map(original=>{
  const capture=selected.get(original.date);if(capture?.result.engineVersion!=="patrimony-history-v1")return original;
  let point=original;
  for(const p of positions){
   const audit=(p.metadata as {amount_observation_audit?:unknown[]}|null)?.amount_observation_audit;
   if(!audit?.length)continue;
   const forward=audit as {operation?:string;date?:string}[];
   if((forwardOnly||contracts.some(c=>c.id===p.contract_id&&c.envelopeTypeCode==="assurance_vie")&&forward.every(e=>e.operation==="replace_forward"))&&!forward.some(e=>e.operation==="replace_forward"&&typeof e.date==="string"&&e.date<=original.date))continue;
   // Absence from this capture is not an unknown captured contract total.
   // Its native dated evidence is handled by the continuity projection.
   if(!capture.result.report.contracts.some(contract=>contract.id===p.contract_id))continue;
   const c=contracts.find(c=>c.id===p.contract_id),key=`asset:${p.contract_id}:${p.asset_id}`,grossKey=`contract:${p.contract_id}:gross`;
   const inputs=capture.inputs as {contracts?:{id:string;valuation_source?:string;metadata?:{knownLiquidationNetEur?:unknown}}[];positions?:{contract_id:string;asset_id:string;is_active?:boolean}[]}|undefined;
   if(!c||c.valuationAuthority==="global"||original.declaredContractTotals?.[c.id]||inputs?.contracts?.some(c=>c.id===p.contract_id&&c.metadata?.knownLiquidationNetEur!=null)||sources.some(s=>s.business_date===point.date&&s.payload.kind==="approved_contract_correction"&&(s.payload as {contractId?:string}).contractId===c.id))continue;
   const snapshot=selectLatestPositionSnapshots(snapshots.filter(s=>s.position_id===p.id&&parisDate(s.valued_at)<=original.date),original.date+"T23:59:59Z").get(p.id);
   const value=snapshot?convertToEur(snapshot.market_value,snapshot.currency_code,latestFxRatesByCurrency(rates,original.date).get(snapshot.currency_code)).amountEur:null;
   const before=point.values[key],gross=point.values[grossKey];
   const capturedContract=capture.result.report.contracts.find(contract=>contract.id===c.id);
   const capturedIncomplete=(capturedContract as {incompletePositions?:unknown}|undefined)?.incompletePositions;
   const completesNativeAv=c.envelopeTypeCode==='assurance_vie'&&gross==null
    &&forward.some(e=>e.operation==='replace_forward'&&typeof e.date==='string'&&e.date<=original.date)
    &&inputs?.contracts?.some(row=>row.id===c.id&&row.valuation_source==='positions')
    &&typeof capturedIncomplete==='number'&&capturedIncomplete>0&&c.children.length>0
    &&inputs.positions?.some(row=>row.contract_id===c.id&&row.asset_id===p.asset_id&&row.is_active!==false)
    &&inputs.positions?.filter(row=>row.contract_id===c.id&&row.is_active!==false).every(row=>c.children.some(child=>child.id===`asset:${c.id}:${row.asset_id}`))
    &&c.children.every(child=>child.kind==='asset'&&typeof(child.id===key?value:point.values[child.id])==='number'&&Number.isFinite(child.id===key?value:point.values[child.id]));
   const nextGross=value!==null&&typeof before==='number'&&typeof gross==='number'?gross-before+value
    :completesNativeAv?c.children.reduce((sum,child)=>sum+(child.id===key?value!:point.values[child.id]!),0):null;
   if(value===before&&!completesNativeAv)continue;
   if(point===original)point={...original,values:{...original.values},quantities:{...original.quantities},historicalUnitCosts:{...original.historicalUnitCosts},netKinds:{...original.netKinds},netReasons:{...original.netReasons},provenanceByContract:{...original.provenanceByContract},valuationSourceDates:{...original.valuationSourceDates}};
   point.values[key]=value;point.quantities[key]=null;point.historicalUnitCosts![key]=null;
   point.values[grossKey]=nextGross;
   point.values[`contract:${c.id}:net`]=null;point.netKinds[c.id]="unavailable";
   point.netReasons![c.id]="Valorisation totale corrigée ; NET selon les règles datées existantes.";
   point.valuationSourceDates![key]=snapshot?parisDate(snapshot.valued_at):null;
   point.provenanceByContract![c.id]="Valorisation totale datée du support ; capture source conservée.";
  }
  return point;
 });
}

/** A new manual AV action takes priority over prior read-only repair overlays,
 * only from its explicit date. Published/global authorities retain their guards. */
export function projectLifeInsuranceReplacements(points:ChartPoint[],contracts:ChartContract[],captures:HistoricalObservation[],sources:HistoricalSource[],positions:Position[],snapshots:CurrentPositionSnapshot[],rates:FxRateRecord[],now:string,balances:DatedBalance[]=[]){
 const av=contracts.filter(c=>c.envelopeTypeCode==="assurance_vie");
 const eligible=positions.filter(p=>av.some(c=>c.id===p.contract_id)&&Boolean((p.metadata as {av_amount_requests?:unknown}|null)?.av_amount_requests));
 return eligible.length?projectAmountObservations(points,av,captures,sources,eligible,snapshots,rates,now,balances,true):points;
}
