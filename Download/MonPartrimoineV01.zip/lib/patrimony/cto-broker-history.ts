import type { ChartContract, ChartPoint } from "./chart-core";
import type { HistoricalSource } from "./historical-observations";

export const CTO_BROKER_HISTORY_KIND = "approved_cto_broker_history";
type Holding = { assetId: string; quantity: number | null; valueEur: number | null; unitCostEur: number | null };
type Baseline = { holdings: Holding[]; cashEur: number | null; contributionsEur: number | null; netFlowsEur: number | null; holdingEvidence?: Record<string,unknown> };
type Fixing = { observedOn: string; nativePerEur: string; url: string };
type Acquisition = { id: string; assetId: string; date: string; quantity: string; basisUsd: string; commissionUsd: string; proceedsUsd: string; fx: Fixing | null };
type Valuation = { kind: "native_eur_total" | "dated_eur_unit" | "dated_usd_price" | "statement_usd_close"; value: string; source: string; fx?: Fixing; eurPerUsd?: string; fxPrecision?: number };
type Day = { date: string; baseline: Baseline; holdings: { assetId: string; quantity: string; costEur: string | null; valuation: Valuation }[]; cash: { eur: string; usd: string; fx: Fixing | null; method: "posted_ledger" | "reported_close" | "confirmed_continuation"; rounding?: { unroundedUsd: string; precision: 8 } }; depositsEur: string };
export type BrokerHistory = { kind: typeof CTO_BROKER_HISTORY_KIND; version: 1|2; priorVersions?:BrokerHistory[]; repair?:{requestId:string}; contractId: string; sourceSha256: string; from: string; statementThrough: string; through: string; continuation?: { through: string; confirmedAt: string; confirmationSha256: string; noOperations: true }; initialHoldingsZero: true; documentedStockSectionBuyOnly: true; quantitiesReconciledToOpeningAndClosing: true; cashIncludesDeposits: true; noFinancialReplay: true; policy: "reviewed_statement_precedes_contradicted_native_history"; acquisitions: Acquisition[]; days: Day[] };
type Evidence = { sourceId: string; sourceSha256: string; status: "applied" | "blocked"; reason?: string; native: Baseline; sourceNetEur: number | null; costMethod: "historical_reference_fx_estimate"; projectedSignature?: string };
type BrokerPoint = ChartPoint & { brokerHistoryEvidence?: Record<string, Evidence> };
export function appliedCtoBrokerEvidence(point: ChartPoint, contractId: string) {
  const evidence = (point as BrokerPoint).brokerHistoryEvidence?.[contractId];
  return evidence?.status === "applied" ? evidence : null;
}
const dayPattern = /^\d{4}-\d{2}-\d{2}$/;
const number = (v: string) => { if (!/^-?\d+(?:\.\d+)?$/.test(v) || !Number.isFinite(Number(v))) throw Error("Montant de preuve courtier invalide."); return Number(v); };
const same = (a: number | null | undefined, b: number | null | undefined) => a == null && b == null || a === b;
const near = (a: number, b: number) => Math.abs(a - b) < 1e-8;

export function brokerHistoryBaseline(point: ChartPoint, contract: ChartContract): Baseline {
  return { holdings: contract.children.filter(c => c.kind === "asset").map(c => ({ assetId: c.assetId!, quantity: point.quantities[c.id] ?? null, valueEur: point.values[c.id] ?? null, unitCostEur: point.historicalUnitCosts?.[c.id] ?? null })).sort((a,b) => a.assetId.localeCompare(b.assetId)), cashEur: point.cash[`cash:${contract.id}`] ?? null, contributionsEur: point.contributions[contract.id] ?? null, netFlowsEur: point.netCashFlows?.[contract.id] ?? null, holdingEvidence:Object.fromEntries(Object.entries(point.holdingObservationEvidence??{}).filter(([id])=>id.split(":")[1]===contract.id)) };
}
const canonical=(v:unknown):string=>JSON.stringify(v,(_k,x:unknown)=>x&&typeof x==="object"&&!Array.isArray(x)?Object.fromEntries(Object.entries(x).sort(([a],[b])=>a.localeCompare(b))):x);
const matches = (a: Baseline, b: Baseline) => a.holdings.length === b.holdings.length && a.holdings.every((h,i) => h.assetId === b.holdings[i].assetId && same(h.quantity,b.holdings[i].quantity) && same(h.valueEur,b.holdings[i].valueEur) && same(h.unitCostEur,b.holdings[i].unitCostEur)) && same(a.cashEur,b.cashEur) && same(a.contributionsEur,b.contributionsEur) && same(a.netFlowsEur,b.netFlowsEur)&&canonical(a.holdingEvidence??{})===canonical(b.holdingEvidence??{});

function rate(fx: Fixing, date: string) {
  const n = number(fx.nativePerEur), lag = (Date.parse(date) - Date.parse(fx.observedOn)) / 86400000, weekday = new Date(date + "T12:00Z").getUTCDay();
  if (!(n > 0) || !dayPattern.test(fx.observedOn) || lag < 0 || lag > (weekday === 0 ? 2 : weekday === 6 ? 1 : 0) || !/^https:\/\/(?:www\.)?(?:banque-france\.fr|ecb\.europa\.eu)\//.test(fx.url)) throw Error("Référence de change historique courtier invalide.");
  return n;
}
function validate(p: BrokerHistory) {
  if (![1,2].includes(p.version) || !/^[a-f0-9]{64}$/.test(p.sourceSha256) || !dayPattern.test(p.from) || !dayPattern.test(p.through) || p.from > p.through || p.initialHoldingsZero !== true || p.documentedStockSectionBuyOnly !== true || p.quantitiesReconciledToOpeningAndClosing !== true || p.cashIncludesDeposits !== true || p.noFinancialReplay !== true || p.policy !== "reviewed_statement_precedes_contradicted_native_history" || !p.days.length || p.days[0].date !== p.from || p.days.at(-1)!.date !== p.through) throw Error("Périmètre de preuve courtier invalide.");
  if(p.version===2&&(!p.repair?.requestId||p.priorVersions?.length!==1||p.priorVersions[0].version!==1||p.priorVersions[0].sourceSha256!==p.sourceSha256))throw Error('Reprise native courtier sans version source traçable.'); const ids = new Set<string>();
  if(!dayPattern.test(p.statementThrough)||p.statementThrough<p.from||p.statementThrough>p.through)throw Error("Période du relevé incohérente.");
  if(p.through>p.statementThrough&&(!p.continuation||p.continuation.noOperations!==true||p.continuation.through!==p.through||!/^[a-f0-9]{64}$/.test(p.continuation.confirmationSha256)||!Number.isFinite(Date.parse(p.continuation.confirmedAt))||new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Paris'}).format(new Date(p.continuation.confirmedAt))<p.through))throw Error("Prolongement sans confirmation datée du propriétaire.");
  for (const a of p.acquisitions) {
    if (ids.has(a.id) || !dayPattern.test(a.date) || a.date < p.from || a.date > p.statementThrough || !(number(a.quantity) > 0) || number(a.basisUsd) < 0 || number(a.commissionUsd) > 0 || !near(number(a.basisUsd), -number(a.proceedsUsd) - number(a.commissionUsd))) throw Error("Acquisition courtier incohérente ou dupliquée.");
    ids.add(a.id); if (a.fx) rate(a.fx,a.date);
  }
  for (let i=0;i<p.days.length;i++) if (!dayPattern.test(p.days[i].date) || i > 0 && Date.parse(p.days[i].date) - Date.parse(p.days[i-1].date) !== 86400000) throw Error("Dates de preuve courtier non contiguës.");
}

// Consultation only: no order, cash flow, current position or capture is written.
// A reviewed source has an explicit finite range and preserves its native input
// comparison; it cannot silently outlive a different observation or cash action.
export function projectCtoBrokerHistory(points: readonly ChartPoint[], contracts: readonly ChartContract[], sources: readonly HistoricalSource[]): ChartPoint[] {
  const approved = sources.filter(s => s.payload.kind === CTO_BROKER_HISTORY_KIND);
  if (!approved.length) return points as ChartPoint[];
  const result = new Map(points.map(p => [p.date,p])), covered = new Set<string>();
  for (const source of approved) {
    const p = source.payload as unknown as BrokerHistory, contract = contracts.find(c => c.id === p.contractId);
    if (!contract) continue;
    validate(p); if (contract.envelopeTypeCode !== "cto" || contract.valuationAuthority === "global" || source.source_sha256 !== p.sourceSha256 || source.business_date !== p.through) throw Error("Autorité courtier hors périmètre CTO.");
    for (const d of p.days) {
      const key = `${contract.id}:${d.date}`; if (covered.has(key)) throw Error("Preuves courtier concurrentes."); covered.add(key);
      const original = result.get(d.date); if (!original) continue;
      if(d.date>p.statementThrough){const close=p.days.find(day=>day.date===p.statementThrough);if(!close||d.cash.method!=="confirmed_continuation"||!same(number(d.cash.eur),number(close.cash.eur))||!same(number(d.cash.usd),number(close.cash.usd))||!same(number(d.depositsEur),number(close.depositsEur)))throw Error("Opération non documentée après la clôture du relevé.");}
      const already=(original as BrokerPoint).brokerHistoryEvidence?.[contract.id];
      if(already?.status==="applied"&&already.sourceId===source.id&&already.sourceSha256===p.sourceSha256&&already.projectedSignature===canonical(brokerHistoryBaseline(original,contract)))continue;
      const baseline = brokerHistoryBaseline(original,contract);
      const evidence: Evidence = { sourceId: source.id, sourceSha256: p.sourceSha256, status: "applied", native: baseline, sourceNetEur: original.sourceNets?.[contract.id] ?? original.values[`contract:${contract.id}:net`] ?? null, costMethod: "historical_reference_fx_estimate" };
      if (!matches(baseline,d.baseline)) {
        result.set(d.date,{ ...original, brokerHistoryEvidence: { ...(original as BrokerPoint).brokerHistoryEvidence,[contract.id]: { ...evidence,status:"blocked",reason:"Nouvelle observation ou état natif divergent ; preuve courtier non réappliquée." } } } as BrokerPoint); continue;
      }
      const children = contract.children.filter(c => c.kind === "asset"), seen = new Set<string>();
      const point: BrokerPoint = { ...original,values:{...original.values},quantities:{...original.quantities},historicalUnitCosts:{...original.historicalUnitCosts},cash:{...original.cash},contributions:{...original.contributions},netCashFlows:{...original.netCashFlows},sourceContributions:{...original.sourceContributions},sourceNetCashFlows:{...original.sourceNetCashFlows},netKinds:{...original.netKinds},netReasons:{...original.netReasons},provenanceByContract:{...original.provenanceByContract},cashProjectionBase:{...original.cashProjectionBase},cashNetProjection:{...original.cashNetProjection},declaredContractTotals:{...original.declaredContractTotals},brokerHistoryEvidence:{...(original as BrokerPoint).brokerHistoryEvidence,[contract.id]:evidence} };
      for (const h of d.holdings) {
        const child = children.find(c => c.assetId === h.assetId); if (!child || seen.has(h.assetId)) throw Error("Inventaire courtier incomplet ou dupliqué."); seen.add(h.assetId);
        const acquisitions = p.acquisitions.filter(a => a.assetId === h.assetId && a.date <= d.date), quantity = acquisitions.reduce((s,a) => s + number(a.quantity),0), costKnown = acquisitions.every(a => a.fx !== null), cost = costKnown ? acquisitions.reduce((s,a) => s + number(a.basisUsd) / rate(a.fx!,a.date),0) : null;
        if (!near(quantity,number(h.quantity)) || cost === null && h.costEur !== null || cost !== null && (h.costEur === null || !near(cost,number(h.costEur)))) throw Error("Coût ou quantité courtier non rapproché du journal d'acquisition.");
        point.quantities[child.id] = number(h.quantity); point.historicalUnitCosts![child.id] = quantity > 0 && cost !== null ? number(h.costEur!) / number(h.quantity) : null;
        const v = h.valuation; if (!v.source) throw Error("Provenance de valorisation courtier absente.");
        let value: number | null = null;
        if (quantity === 0) value = 0;
        else if (v.kind === "native_eur_total") { value=number(v.value); if (!same(value,original.values[child.id]) || !same(number(h.quantity),original.quantities[child.id])) throw Error("Valorisation native incompatible avec la quantité courtier."); }
        else if (v.kind === "dated_eur_unit") { const before = baseline.holdings.find(b => b.assetId === h.assetId)!; if (!(before.quantity! > 0) || before.valueEur === null || !near(number(v.value),before.valueEur / before.quantity!)) throw Error("Valeur unitaire EUR sans preuve datée correspondante."); value=number(h.quantity)*number(v.value); }
        else if (v.kind === "dated_usd_price") { value=v.fx?number(h.quantity)*number(v.value)/rate(v.fx,d.date):null; }
        else if (v.kind === "statement_usd_close") { if (d.date !== p.statementThrough || v.fxPrecision !== 5 || !v.eurPerUsd || !(number(v.eurPerUsd) > 0)) throw Error("Change de clôture non qualifié."); value=number(v.value)*number(v.eurPerUsd); }
        if (value === null ? v.kind !== "dated_usd_price" || v.fx !== undefined : !Number.isFinite(value) || value < 0) throw Error("Valorisation courtier invalide."); point.values[child.id]=value;
      }
      if (seen.size !== children.length) throw Error("Titre hors inventaire courtier ; rapprochement requis.");
      if(d.cash.rounding&&(d.cash.rounding.precision!==8||number(d.cash.usd)!==0||Math.abs(number(d.cash.rounding.unroundedUsd))>=.000000005))throw Error("Arrondi espèces courtier non qualifié.");
      const cashUsd=number(d.cash.usd), cash=number(d.cash.eur)+(cashUsd === 0 ? 0 : d.cash.fx ? cashUsd/rate(d.cash.fx,d.date) : NaN);
      point.cash[`cash:${contract.id}`]=Number.isFinite(cash)?cash:null; point.values[`cash:${contract.id}`]=point.cash[`cash:${contract.id}`];
      const deposits=number(d.depositsEur); if(deposits<0)throw Error("Cumul courtier invalide.");
      if (!same(point.contributions[contract.id],deposits)) point.sourceContributions![contract.id]=point.contributions[contract.id];
      if (!same(point.netCashFlows?.[contract.id],deposits)) point.sourceNetCashFlows![contract.id]=point.netCashFlows?.[contract.id] ?? null;
      point.contributions[contract.id]=deposits;point.netCashFlows![contract.id]=deposits;
      point.values[`contract:${contract.id}:gross`]=Number.isFinite(cash)&&children.every(c=>typeof point.values[c.id]==="number")?children.reduce((s,c)=>s+point.values[c.id]!,cash):null;
      point.values[`contract:${contract.id}:net`]=null;point.netKinds[contract.id]="calculated";
      // The archived NET stays in sourceNets/evidence as a comparison, never a
      // target allocated to holdings. Re-enter the existing native tax engine.
      delete point.cashProjectionBase![contract.id];delete point.cashNetProjection![contract.id];delete point.declaredContractTotals![contract.id];delete point.netReasons![contract.id];
      point.provenanceByContract![contract.id]=[original.provenanceByContract?.[contract.id],`Reconstruction courtier ${p.sourceSha256} · quantités et frais du relevé · coût EUR estimé aux références historiques d'acquisition · valorisations EUR datées conservées ou rebasées explicitement · espèces et cumul du journal courtier, aucun flux rejoué · NET global source conservé séparément pour comparaison.`].filter(Boolean).join(" · ");
      evidence.projectedSignature=canonical(brokerHistoryBaseline(point,contract));
      result.set(d.date,point);
    }
  }
  return [...result.values()];
}

// "Calculated" refers to the tax formula, not certainty of an indicative FX.
export function markCtoBrokerEstimates(points: readonly ChartPoint[]): ChartPoint[] {
  return points.map(p => { const ids=Object.entries((p as BrokerPoint).brokerHistoryEvidence ?? {}).filter(([,e])=>e.status==="applied").map(([id])=>id);if(!ids.length)return p;const netKinds={...p.netKinds};for(const id of ids)if(typeof p.values[`contract:${id}:net`]==="number")netKinds[id]="approximate";return{...p,netKinds}; });
}

