import { isContractInUserScope } from "@/lib/contracts/contract-scope";
import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";
import { requireRenderUser } from "@/lib/auth/render-context";
import { mapFiscalRuleRow, type FiscalRuleRow } from "@/lib/fiscal/fiscal-settings";
import { buildDailyHistory } from "@/lib/patrimony/daily-history-core";
import type { buildFunctionalLegacyHistory } from "@/lib/patrimony/legacy-import-core";
import type { PatrimonialReportRecords } from "@/lib/reports/patrimonial-report-core";
import { historyReadDiagnostic } from "@/lib/patrimony/history-read-diagnostics";

type ArchivedInputs = Omit<PatrimonialReportRecords, "fiscalRules" | "fiscalPreferences"> & {
  fiscalRules: FiscalRuleRow[];
  fiscalPreferences: Array<{ fiscal_regime_id: string; use_personal_rule: boolean }>;
};
export async function captureDailyPatrimony(businessDate: string, options: { requestedRevision?: boolean } = {}) {
  const client = createAdminClient();
  const claim = await client.rpc("claim_envelope_daily_capture", { requested_date: businessDate, requested_revision: options.requestedRevision ?? false });
  if (claim.error) throw new Error("Daily history unavailable");
  if (!claim.data) return "already_captured_or_running";
  const row = claim.data as { claim_token: string; captured_at: string; business_date: string; inputs: ArchivedInputs; envelope_capture_version?: number };
  try {
    // A new publication must carry the envelope snapshot from the SQL claim.
    // Old published archives remain readable by the historical replay path.
    if (!Array.isArray(row.inputs.envelopeFiscalities) && row.envelope_capture_version !== 0) throw new Error("Envelope capture dependency unavailable");
    if(row.inputs.fiscalConsultationPolicy!==undefined&&(row.inputs.fiscalConsultationPolicy!==2||!Array.isArray(row.inputs.envelopeFiscalities)))throw new Error('Capture policy dependency unavailable');
    const records = { ...row.inputs,
      fiscalRules: row.inputs.fiscalRules.map(mapFiscalRuleRow),
      fiscalPreferences: row.inputs.fiscalPreferences.map((p) => ({ fiscalRegimeId: p.fiscal_regime_id, usePersonalRule: p.use_personal_rule })) };
    // Shared annual rules cannot be reassigned arbitrarily to contract selections.
    const result = buildDailyHistory(records, row.captured_at, row.business_date);
    const publish = await client.rpc("publish_patrimonial_daily_capture", { requested_token: row.claim_token, requested_result: result });
    if (publish.error) throw new Error("Daily publication unavailable");
    return "published";
  } catch {
    await client.rpc("fail_patrimonial_daily_capture", { requested_token: row.claim_token });
    throw new Error("Daily capture failed");
  }
}

export const HISTORY_PAGE_SIZE = 20;
export async function readLiquidSavingsHistoryInputs() {
  const user=await requireRenderUser(),client=await createClient();
  const contracts: string[]=[], balances: import('@/lib/cash/dated-balances').DatedBalance[]=[];
  const size=500;
  for(let offset=0;;offset+=size){
    const result=await client.from('contracts').select('id,envelope_types!inner(code)').eq('user_id',user.id).eq('envelope_types.code','epargne_liquide').order('id').range(offset,offset+size-1);
    if(result.error)throw new Error('Contrats d’épargne liquide indisponibles');
    for(const row of result.data??[])if(isContractInUserScope(row.id))contracts.push(row.id);
    if((result.data?.length??0)<size)break;
  }
  if(!contracts.length)return {contracts,balances};
  for(let offset=0;;offset+=size){
    const result=await client.from('cash_balances').select('id,contract_id,amount,currency_code,as_of,updated_at,metadata').eq('user_id',user.id).in('contract_id',contracts).order('id').range(offset,offset+size-1);
    if(result.error)throw new Error('Soldes d’épargne liquide indisponibles');
    balances.push(...(result.data??[]));if((result.data?.length??0)<size)break;
  }
  return {contracts,balances};
}
export function historyPageNumber(value: string | undefined) {
  return value && /^[1-9][0-9]{0,4}$/.test(value) ? Number(value) : 1;
}

export function historyAnchor(value: string | undefined, now = new Date()) {
  const parsed = value ? new Date(value) : now;
  return Number.isFinite(parsed.getTime()) && parsed <= now ? parsed.toISOString() : now.toISOString();
}

export async function readDailyHistory(page?: number, until?: string) {
  const user = await requireRenderUser();
  const client = await createClient();
  const data: unknown[] = [];
  // Capture inputs/results are large. Bound each transfer without truncating
  // the complete chart history or changing the separate history-list page.
  const size = page === undefined ? 50 : HISTORY_PAGE_SIZE;
  const readPage = async (offset:number,withCount=false) => {
    const started = performance.now();
    let query = client.from("patrimonial_daily_captures").select("id,business_date,revision,captured_at,inputs,result",withCount?{count:"exact"}:undefined)
      .eq("user_id", user.id).eq("state", "published");
    if (until) query = query.lte("captured_at", until);
    const rows = await query.order("business_date", { ascending: false }).order("revision", { ascending: false }).order("id")
      .range(offset, offset + size - (page === undefined ? 1 : 0));
    if (rows.error) {
      console.warn("patrimony_history_read_failure", historyReadDiagnostic("daily", Math.floor(offset / size) + 1, size, performance.now() - started, rows));
      throw new Error("Historique quotidien indisponible ; aucune journée reconstituée.");
    }
    return rows;
  };
  const append = (rows:Awaited<ReturnType<typeof readPage>>) => {
    data.push(...(rows.data ?? []).map((row) => {
      const inputs = row.inputs as ArchivedInputs | undefined;
      if (row.result?.engineVersion !== "patrimony-history-v1" || !inputs?.contracts?.some((c) => !isContractInUserScope(c.id))) return row;
      return { ...row, result: buildDailyHistory({ ...inputs,
        fiscalRules: inputs.fiscalRules.map(mapFiscalRuleRow),
        fiscalPreferences: inputs.fiscalPreferences.map((p) => ({ fiscalRegimeId: p.fiscal_regime_id, usePersonalRule: p.use_personal_rule })) }, row.captured_at, row.business_date) };
    }));
  };
  const first = await readPage(page === undefined ? 0 : (page - 1) * size,page === undefined);
  append(first);
  if(page===undefined&&(first.data?.length??0)===size){
    if(typeof first.count==='number'){
      // Two bounded transfers at a time, keeping the existing order and the
      // same consultation cutoff. No persistent cache or discarded page.
      for(let offset=size;offset<first.count;offset+=size*2){
        const pages=await Promise.all([readPage(offset),...(offset+size<first.count?[readPage(offset+size)]:[])]);
        pages.forEach(append);
      }
    }else{
      let offset=size;
      while(true){const rows=await readPage(offset);append(rows);if((rows.data?.length??0)<size)break;offset+=size;}
    }
  }
  return data as Array<{ id: string; business_date: string; revision: number; captured_at: string; inputs?: unknown; result: ReturnType<typeof buildDailyHistory> | ReturnType<typeof buildFunctionalLegacyHistory> }>;
}

export async function readLegacyHistory(page?: number, until?: string) {
  const user = await requireRenderUser();
  const client = await createClient();
  const data: unknown[] = [];
  const size = page === undefined ? 500 : HISTORY_PAGE_SIZE;
  let offset = page === undefined ? 0 : (page - 1) * size;
  do {
    const started = performance.now();
    let query = client.from("patrimonial_legacy_sources").select("id,business_date,source_sha256,imported_at,payload")
      .eq("user_id", user.id);
    if (until) query = query.lte("imported_at", until);
    const rows = await query.order("business_date", { ascending: false }).order("id")
      .range(offset, offset + size - (page === undefined ? 1 : 0));
    if (rows.error) {
      console.warn("patrimony_history_read_failure", historyReadDiagnostic("legacy", Math.floor(offset / size) + 1, size, performance.now() - started, rows));
      throw new Error("Historique importé indisponible");
    }
    data.push(...(rows.data ?? []));
    if (page !== undefined || (rows.data?.length ?? 0) < size) break;
    offset += size;
  } while (true);
  return data as Array<{ id: string; business_date: string; source_sha256: string; imported_at: string; payload: {
    recalculatedGrossEur: number | null; originalComponentDifferenceEur: number | null;
    sourceValues?: Record<string, number | null>; derivedDisplayValues?: Record<string, unknown>; employeeSavings?: { scope: string; splitKnown: false };
    kind?: string; version?: number; businessDate?: string; sourceTimePrecision?: string; confirmedPositionValues?: unknown[];
    nativeUnitPriceProvided?: boolean; fxRateProvided?: boolean; currentValuationOverride?: boolean; automaticModePreserved?: boolean;
  } }>;
}
