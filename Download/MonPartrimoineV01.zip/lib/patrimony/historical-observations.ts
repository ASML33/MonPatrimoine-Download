import { applyApprovedContractCorrections } from "@/lib/patrimony/approved-contract-corrections";
import { applyApprovedGrossObservations } from "@/lib/patrimony/approved-gross-observations";
import { isContractInUserScope } from "@/lib/contracts/contract-scope";
import type { PatrimonialReport } from "@/lib/reports/patrimonial-report-core";
import type { ChartContract, ChartPoint, NetQuality } from "@/lib/patrimony/chart-core";
import { isDateInContractScope, sourcePrefix, stableColor } from "@/lib/patrimony/chart-core";
import { applyCapturedChartPoint } from "@/lib/patrimony/captured-chart-point";

export type HistoricalHolding = { assetId: string; contractId: string; symbol: string | null; name: string; presence: string; quantity: number | null; valueEur: number | null };
export type HistoricalContract = { id: string; name: string; grossEur: number; netEstimatedEur: number | null; legacyNetEur?: number | null; legacyNetUsable?: boolean; netKind?: NetQuality; fiscalWarnings: string[]; manualSituationAt?: string | null; totalContributionsEur?: number; netCashFlowsEur?: number; incompleteContributionFlows?: number; incompleteNetCashFlows?: number };
export type HistoricalObservation = {
  id: string; business_date: string; revision: number; captured_at: string; inputs?: unknown;
  result: { engineVersion: string; grossKind?: string; netKind?: string; historicalInventory?: HistoricalHolding[];
    report: { contracts: HistoricalContract[]; summary: { grossEur: number | null }; assets?: unknown[] };
    legacy?: { sourceTotalEur: number | null; sourceTotalDifferenceEur?: number | null; originalComponentDifferenceEur?: number | null; internalContractDifferencesEur?: { pea: number | null; cto: number | null } } };
};
export type HistoricalSource = { id: string; business_date: string; source_sha256?: string; imported_at?: string; payload: {
  sourceValues?: Record<string, unknown>; derivedDisplayValues?: Record<string, unknown>; kind?: string; version?: number;
  businessDate?: string; sourceTimePrecision?: string; confirmedPositionValues?: unknown[];
  nativeUnitPriceProvided?: boolean; fxRateProvided?: boolean; currentValuationOverride?: boolean; automaticModePreserved?: boolean;
} };
function record(value: unknown): Record<string, unknown> { return value !== null && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : {}; }
function number(value: unknown) { return typeof value === "number" && Number.isFinite(value) ? value : typeof value === "string" && value.trim() && Number.isFinite(Number(value)) ? Number(value) : null; }
function sourceHash(row: HistoricalObservation) { return record(row.inputs).sourceSha256; }
function approvedCsv(row: HistoricalObservation) {
  const policy = record(record(row.inputs).historicalSelection);
  return row.result.engineVersion === "patrimony-legacy-import-v1" && policy.version === 1 && policy.authority === "approved_csv_priority"
    && typeof policy.sourceSha256 === "string" && /^[a-f0-9]{64}$/.test(policy.sourceSha256) && policy.sourceSha256 === sourceHash(row);
}

// Authority is chosen before revisions. A later import never silently displaces a native capture.
export function selectHistoricalObservations<T extends HistoricalObservation>(rows: readonly T[]) {
  const grouped = new Map<string, T[]>();
  for (const original of rows) {
    const contracts = original.result.report.contracts.filter((c) => isContractInUserScope(c.id));
    // Presentation projection only: archived evidence is never rewritten. The
    // combined PEG/PER leaf has its own identity and is retained without allocation.
    const row = contracts.length === original.result.report.contracts.length ? original : {
      ...original, result: { ...original.result, report: { ...original.result.report, contracts,
        summary: { ...original.result.report.summary, grossEur: contracts.length ? contracts.reduce((sum, c) => sum + c.grossEur, 0) : null } } },
    };
    grouped.set(row.business_date, [...(grouped.get(row.business_date) ?? []), row]);
  }
  return [...grouped].sort(([a], [b]) => a.localeCompare(b)).map(([date, observations]) => {
    const approved = observations.filter(approvedCsv);
    if (approved.length > 1) throw new Error("Autorités historiques concurrentes ; rapprochement explicite nécessaire.");
    const native = observations.filter((row) => row.result.engineVersion === "patrimony-history-v1");
    const candidates = approved.length ? approved : native.length ? native : observations;
    if (!approved.length && !native.length && new Set(candidates.map(sourceHash)).size > 1) throw new Error("Sources historiques concurrentes non arbitrées.");
    const selected = [...candidates].sort((a, b) => b.revision - a.revision || b.captured_at.localeCompare(a.captured_at) || a.id.localeCompare(b.id))[0];
    return { date, selected, traces: observations.filter((row) => row.id !== selected.id), authority: approved.length ? "CSV prioritaire — décision explicite" : native.length ? "Capture native" : "Source legacy existante" };
  });
}

export function historicalNet(contract: HistoricalContract) {
  if (contract.legacyNetUsable === false) return null;
  return number(contract.netEstimatedEur) ?? number(contract.legacyNetEur);
}
export function historicalDate(date: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new Error("Date historique invalide");
  const [year, month, day] = date.split("-");
  return `${day}/${month}/${year}`;
}
export function historicalSourceFor(row: HistoricalObservation, sources: readonly HistoricalSource[]) {
  if (row.result.engineVersion === "patrimony-history-v1") return undefined;
  const candidates = sources.filter((source) => source.business_date === row.business_date && (!sourceHash(row) || source.source_sha256 === sourceHash(row)));
  if (candidates.length > 1 || (approvedCsv(row) && candidates.length !== 1)) throw new Error("Preuve historique absente ou concurrente.");
  return candidates[0];
}

type ConfirmedPositionValue = { assetId: string; contractId: string; marketValueEur: number; quantity: number | null };
export function datedPositionConfirmations(date: string, sources: readonly HistoricalSource[]) {
  const confirmations: ConfirmedPositionValue[] = [];
  const seen = new Set<string>();
  for (const source of sources.filter((item) => item.payload.kind === "user_position_valuation_confirmation" && item.business_date === date)) {
    const payload = source.payload;
    if (payload.version !== 1 || payload.businessDate !== date || payload.sourceTimePrecision !== "date"
      || payload.nativeUnitPriceProvided !== false || payload.fxRateProvided !== false
      || payload.currentValuationOverride !== false || payload.automaticModePreserved !== true
      || !Array.isArray(payload.confirmedPositionValues)) throw new Error("Confirmation de valorisation datée incohérente.");
    for (const value of payload.confirmedPositionValues) {
      const item = record(value);
      const marketValueEur = number(item.marketValueEur);
      const quantityKnown = item.quantityKnownFromThisSource === true;
      const quantity = quantityKnown ? number(item.quantity) : null;
      if (typeof item.assetId !== "string" || typeof item.contractId !== "string"
        || item.amountSemantics !== "total_position_value" || (item.quantityKnownFromThisSource !== false && !quantityKnown)
        || (quantityKnown && (quantity === null || quantity < 0))
        || marketValueEur === null || marketValueEur < 0) throw new Error("Confirmation de valorisation datée invalide.");
      const key = `${item.contractId}:${item.assetId}`;
      if (seen.has(key)) throw new Error("Confirmations de valorisation datées concurrentes.");
      seen.add(key);
      confirmations.push({ assetId: item.assetId, contractId: item.contractId, marketValueEur, quantity });
    }
  }
  return confirmations;
}

// A dated position-total confirmation may complete a captured observation, but
// it never fabricates a unit price, FX rate or quantity and never overrides a
// value already archived by the authoritative daily/legacy source.
export function applyDatedPositionConfirmations(point: ChartPoint, contracts: readonly ChartContract[], sources: readonly HistoricalSource[]) {
  const confirmations = datedPositionConfirmations(point.date, sources);
  if (!confirmations.length) return point;
  const touched = new Set<string>();
  for (const confirmation of confirmations) {
    const contract = contracts.find((item) => item.id === confirmation.contractId);
    const child = contract?.children.find((item) => item.kind === "asset" && item.assetId === confirmation.assetId);
    if (!contract || !child || point.values[child.id] !== null && point.values[child.id] !== undefined) continue;
    point.values[child.id] = confirmation.marketValueEur;
    if ((point.quantities[child.id] === null || point.quantities[child.id] === undefined) && confirmation.quantity !== null) point.quantities[child.id] = confirmation.quantity;
    touched.add(contract.id);
  }
  for (const contractId of touched) {
    const contract = contracts.find((item) => item.id === contractId);
    if (!contract || contract.valuationAuthority === "global" || point.values[`contract:${contractId}:gross`] !== null) continue;
    const positionValues = contract.children.filter((item) => item.kind === "asset").map((item) => point.values[item.id]);
    const cash = point.values[`cash:${contractId}`];
    if (positionValues.length && positionValues.every((value) => typeof value === "number") && typeof cash === "number")
      point.values[`contract:${contractId}:gross`] = positionValues.reduce<number>((sum, value) => sum + value!, 0) + cash;
  }
  for (const contractId of touched) (point.provenanceByContract ??= {})[contractId] = "Confirmation utilisateur datée";
  return point;
}

export function extendLegacyInventory(contracts: ChartContract[], rows: readonly HistoricalObservation[]) {
  const result = contracts.map((contract) => ({ ...contract, children: [...contract.children] }));
  for (const row of rows) for (const holding of row.result.historicalInventory ?? []) {
    const contract = result.find((item) => item.id === holding.contractId);
    const id = `asset:${holding.contractId}:${holding.assetId}`;
    if (!contract || contract.children.some((item) => item.id === id)) continue;
    contract.children.push({ id, kind: "asset", assetId: holding.assetId, symbol: holding.symbol, label: holding.name,
      valueEur: contract.valuationIncomplete ? null : 0, quantity: 0, quantified: true, color: stableColor(`asset:${holding.assetId}`), colorAutomatic: true });
  }
  return result;
}

export function buildHistoricalChartPoints(contracts: ChartContract[], rows: readonly HistoricalObservation[], sources: readonly HistoricalSource[],employeeSavingsManaged=false): ChartPoint[] {
  const selected = selectHistoricalObservations(rows);
  const points = selected.map(({ date, selected: row }) => {
    const point: ChartPoint = { date, values: {}, cash: {}, contributions: {}, netCashFlows: {}, quantities: {}, historicalUnitCosts: {}, sourceNets: {}, netReasons: {}, netKinds: {}, employeeSavingsCombined: null,
      provenance: row.result.engineVersion === "patrimony-legacy-import-v1" ? "Import historique" : "Capture quotidienne" };
    if (row.result.engineVersion === "patrimony-history-v1")
      return applyDatedPositionConfirmations(applyCapturedChartPoint(point, row.result.report as PatrimonialReport, contracts, row.inputs), contracts, sources);
    const evidence = historicalSourceFor(row, sources);
    const source = approvedCsv(row) ? evidence?.payload.derivedDisplayValues ?? evidence?.payload.sourceValues ?? {} : evidence?.payload.sourceValues ?? {};
    for (const contract of row.result.report.contracts) {
      if (!isContractInUserScope(contract.id)) continue;
      const metadata = contracts.find((item) => item.id === contract.id);
      if (metadata && !isDateInContractScope(date, metadata.openedOn)) continue;
      if (contract.name.includes("historique non ventilé")) point.employeeSavingsCombined = number(contract.grossEur);
      point.values[`contract:${contract.id}:gross`] = number(contract.grossEur);
      const sourceNet = historicalNet(contract);
      if (number(contract.legacyNetEur) !== null) point.sourceNets![contract.id] = number(contract.legacyNetEur);
      const property = metadata?.envelopeTypeCode === "immobilier";
      if (property) (point.sourcePropertyNets ??= {})[contract.id] = number(contract.netEstimatedEur) ?? number(contract.legacyNetEur);
      point.values[`contract:${contract.id}:net`] = property ? number(contract.grossEur) : sourceNet;
      point.netKinds[contract.id] = property && number(contract.grossEur) !== null ? "calculated" : contract.legacyNetUsable === false ? "unavailable" : contract.netKind ?? row.result.netKind as NetQuality ?? "unavailable";
      if (!property && sourceNet === null && contract.fiscalWarnings.length) point.netReasons![contract.id] = contract.fiscalWarnings.join(" ");
    }
    for (const contract of contracts) {
      if (!isDateInContractScope(date, contract.openedOn)) continue;
      const prefix = sourcePrefix(contract.sourceKey);
      const cashKey = contract.sourceKey === "livret_a" ? "Livret A" : contract.sourceKey === "ldds" ? "LDDS" : prefix ? `${prefix} Espèces` : null;
      if (cashKey) point.values[`cash:${contract.id}`] = point.cash[`cash:${contract.id}`] = number(source[cashKey]);
      if (prefix) {
        const contributions = number(source[`${prefix} Versé`]);
        point.contributions[contract.id] = contributions;
        // The qualified PEA/CTO legacy format has no withdrawal column and its
        // cumulative contribution is the dated net external-flow basis. A
        // future explicit net-flow field takes precedence without changing the
        // meaning of the displayed cumulative contributions.
        point.netCashFlows![contract.id] = number(source[`${prefix} Flux net`]) ?? contributions;
      }
      for (const child of contract.children.filter((item) => item.kind === "asset")) {
        const holding = row.result.historicalInventory?.find((item) => item.assetId === child.assetId && item.contractId === contract.id);
        if (holding) {
          point.values[child.id] = holding.presence === "absent" ? 0 : number(holding.valueEur);
          point.quantities[child.id] = holding.presence === "absent" ? 0 : number(holding.quantity);
        } else if (prefix && child.symbol) {
          const ticker = child.symbol.toUpperCase().split(/[.:]/).at(child.symbol.includes(":") ? -1 : 0);
          const key = Object.keys(source).find((name) => name.startsWith(`${prefix} `) && name.toUpperCase().includes(`:${ticker} `) && name.endsWith(" Valo"));
          point.values[child.id] = key ? number(source[key]) : null;
          point.quantities[child.id] = key ? number(source[key.replace(/ Valo$/, " Parts")]) : null;
        }
        point.historicalUnitCosts![child.id] = null;
      }
    }
    return applyDatedPositionConfirmations(point, contracts, sources);
  });
  const corrected=applyApprovedContractCorrections(points, contracts, selected.map(item => item.selected), sources);
  return employeeSavingsManaged?corrected:applyApprovedGrossObservations(corrected,contracts,sources,rows);
}
