import {approvedGrossObservations,type ApprovedGrossObservation} from "@/lib/patrimony/approved-gross-observations";
import type {HistoricalSource,HistoricalObservation} from "@/lib/patrimony/historical-observations";
import type {ManualSituation} from "@/lib/patrimony/manual-situation-core";
import type {ChartContract,ChartPoint} from "@/lib/patrimony/chart-core";
import {historyPointsForSelection} from "@/lib/patrimony/history-window";

export type ValuationRevision={version:1;submissionId:string;expectedToken:string;editedRef:string|null;supersedes:string[]};
export type EmployeeSavingsValue={ref:string;contractId:string;date:string;gross:string;net:string|null;provenance:string;recordedAt:string;precision:"date"|"evening"|"exact";version:number;manualRevision:boolean;supersedes:string[];sourceAt?:string;baselineCaptureId?:string|null;baselineSourceId?:string|null};
const refPattern=/^(manual|legacy):[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const decimal=(v:string|number)=>{const [whole,fraction=""]=String(v).split(".");return `${whole}.${fraction.replace(/0+$/,"").padEnd(2,"0")}`;};
export function employeeSavingsValues(manual:readonly ManualSituation[],sources:readonly HistoricalSource[],knownAt=new Date().toISOString()){
 const eligible=sources.filter(s=>!s.imported_at||Date.parse(s.imported_at)<=Date.parse(knownAt));
 approvedGrossObservations(eligible); // Validate the existing imported revision chains first.
 const raw:EmployeeSavingsValue[]=eligible.filter(s=>s.payload.kind==="approved_manual_gross_observation").map(source=>{const value=source.payload as unknown as ApprovedGrossObservation;return {ref:`legacy:${source.id}`,contractId:value.contractId,date:value.businessDate,gross:value.grossEur,net:value.netEur??null,provenance:value.provenance,recordedAt:value.recordedAt,precision:"date",version:1,manualRevision:false,supersedes:value.replacesSourceId?[`legacy:${value.replacesSourceId}`]:[],baselineCaptureId:value.baselineCaptureId,baselineSourceId:value.baselineSourceId};});
 for(const row of manual.filter(r=>Date.parse(r.recorded_at)<=Date.parse(knownAt))){
  const revision=row.valuation_revision;
  if(revision&&(revision.version!==1||!Array.isArray(revision.supersedes)||revision.supersedes.some(ref=>!refPattern.test(ref))||new Set(revision.supersedes).size!==revision.supersedes.length))throw Error("Révision de valorisation incohérente.");
  raw.push({ref:`manual:${row.id}`,contractId:row.contract_id,date:new Intl.DateTimeFormat("en-CA",{timeZone:"Europe/Paris"}).format(new Date(row.situated_at)),sourceAt:row.situated_at,gross:decimal(row.gross_eur),net:row.source_net_eur==null?null:decimal(row.source_net_eur),provenance:row.source,recordedAt:row.recorded_at,precision:row.source_time_precision??"exact",version:1,manualRevision:!!revision,supersedes:revision?.supersedes??[]});
 }
 const byRef=new Map(raw.map(r=>[r.ref,r])),replaced=new Set<string>();
 for(const row of raw)for(const ref of row.supersedes){const prior=byRef.get(ref);if(!prior||prior.contractId!==row.contractId||replaced.has(ref))throw Error("Remplacement concurrent ou source non reliée.");replaced.add(ref);}
 const visit=(row:EmployeeSavingsValue,path:Set<string>):number=>{if(path.has(row.ref))throw Error("Cycle de valorisation.");return 1+Math.max(0,...row.supersedes.map(ref=>visit(byRef.get(ref)!,new Set([...path,row.ref]))));};
 for(const row of raw)if(row.supersedes.length)row.version=visit(row,new Set());
 const candidates=raw.filter(r=>!replaced.has(r.ref)),effective:EmployeeSavingsValue[]=[];
 for(const row of candidates){
  const same=candidates.filter(c=>c.contractId===row.contractId&&c.date===row.date);
  if(same.length>1){if(same.some(c=>c.manualRevision||c.ref.startsWith("legacy:")))throw Error("Autorités individuelles concurrentes non arbitrées.");const latest=[...same].sort((a,b)=>Date.parse(b.sourceAt!)-Date.parse(a.sourceAt!)||Date.parse(b.recordedAt)-Date.parse(a.recordedAt)||b.ref.localeCompare(a.ref))[0];if(row!==latest)continue;}
  effective.push(row);
 }
 return {effective:effective.sort((a,b)=>a.date.localeCompare(b.date)||a.ref.localeCompare(b.ref)),archived:raw.filter(r=>!effective.includes(r)).sort((a,b)=>b.recordedAt.localeCompare(a.recordedAt))};
}
export function employeeSavingsValueAt(rows:readonly EmployeeSavingsValue[],contractId:string,date:string){
 return rows.filter(r=>r.contractId===contractId&&r.date<=date).sort((a,b)=>b.date.localeCompare(a.date)||b.recordedAt.localeCompare(a.recordedAt))[0]??null;
}
export function latestEmployeeSavingsValue(rows:readonly EmployeeSavingsValue[],contractId:string,at:string){
 const date=new Intl.DateTimeFormat("en-CA",{timeZone:"Europe/Paris"}).format(new Date(at));
 return employeeSavingsValueAt(rows.filter(r=>Date.parse(r.recordedAt)<=Date.parse(at)),contractId,date);
}
export function validateEmployeeSavingsValue(form:FormData,today:string){
 const date=String(form.get("effective_on")??""),amount=(name:string,required:boolean)=>{const value=String(form.get(name)??"").trim().replace(",",".");if(!value&&!required)return null;if(!/^\d{1,15}(?:\.\d{1,2})?$/.test(value)||!Number.isFinite(Number(value)))throw Error("Montant EUR positif ou nul requis, avec deux décimales au maximum.");const [whole,fraction=""]=value.split(".");return `${whole.replace(/^0+(?=\d)/,"")}.${fraction.padEnd(2,"0")}`;};
 if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||date>today)throw Error("Date civile valide, non future, requise.");
 const editedRef=String(form.get("edited_ref")??"");if(editedRef&&!refPattern.test(editedRef))throw Error("Observation invalide.");
 return {date,gross:amount("gross_eur",true)!,net:amount("net_eur",false),editedRef:editedRef||null};
}

// Inclusive source date, maintained until the next observation. These points are
// a read projection, never daily observations written back to the source ledger.
export function projectEmployeeSavingsValues(points:readonly ChartPoint[],contracts:readonly ChartContract[],effective:readonly EmployeeSavingsValue[],captures:readonly HistoricalObservation[],throughDate?:string):ChartPoint[]{
 const members=contracts.filter(c=>["peg","per_col"].includes(c.envelopeTypeCode??"")&&(c.sourceKey==="peg"||c.sourceKey==="per_col"));
 const declared=effective.filter(e=>members.some(c=>c.id===e.contractId)&&(e.manualRevision||e.ref.startsWith('legacy:'))&&(!throughDate||e.date<=throughDate));
 const dates=new Set([...points.map(p=>p.date),...declared.map(e=>e.date)]);
 const first=declared.map(e=>e.date).sort()[0];
 const financialEnd=historyPointsForSelection(points,contracts.map(c=>'contract:'+c.id).concat('employee-savings-combined'),contracts).at(-1)?.date;
 const end=[...declared.map(e=>e.date),...(financialEnd?[financialEnd]:[])].filter(d=>!throughDate||d<=throughDate).sort().at(-1);
 // Fill only between evidenced endpoints. The consultation date is a cap,
 // never a reason to append a valuation or a maintained-only terminal day.
 if(first&&end)for(let day=first;day<=end;day=new Date(Date.parse(day+'T12:00:00Z')+86400000).toISOString().slice(0,10))dates.add(day);
 return [...dates].sort().map(date=>{
  const original=points.find(p=>p.date===date)??{date,values:{},cash:{},contributions:{},quantities:{},netKinds:{},employeeSavingsCombined:null,provenance:"Observation individuelle déclarée"};
  let point=original;const applied:EmployeeSavingsValue[]=[];
  for(const c of members){
   const applicable=employeeSavingsValueAt(effective,c.id,date);if(!applicable||c.openedOn&&date<c.openedOn)continue;
   if(!applicable.manualRevision&&!applicable.ref.startsWith("legacy:"))continue;
   const laterCapture=captures.some(r=>{const item=r.result.report.contracts.find(x=>x.id===c.id);if(!item||r.business_date>date)return false;const sourceDate=item.manualSituationAt?.slice(0,10)??r.business_date;return sourceDate>applicable.date;});
   if(applicable.date!==date&&laterCapture)continue;
   if(point===original)point={...original,values:{...original.values},netKinds:{...original.netKinds},sourceNets:{...original.sourceNets},netReasons:{...original.netReasons},provenanceByContract:{...original.provenanceByContract},employeeSavingsEvidence:{...original.employeeSavingsEvidence}};
   point.values[`contract:${c.id}:gross`]=Number(applicable.gross);point.values[`contract:${c.id}:net`]=applicable.net===null?null:Number(applicable.net);point.netKinds[c.id]=applicable.net===null?"unavailable":"approximate";delete point.sourceNets![c.id];
   point.netReasons![c.id]=applicable.net===null?"NET non fourni pour cette observation ; aucun ancien NET ni calcul fiscal repris.":"NET déclaré par l’utilisateur ; non calculé ni certifié.";
   point.provenanceByContract![c.id]=`${applicable.provenance} · valeur du ${applicable.date}${date!==applicable.date?" · situation maintenue":""}`;point.employeeSavingsEvidence![c.id]=applicable;applied.push(applicable);
  }
  if(point.employeeSavingsCombined!==null&&(members.length===2&&members.every(c=>applied.some(e=>e.contractId===c.id))||applied.some(e=>e.manualRevision))){point.archivedEmployeeSavingsCombined=point.employeeSavingsCombined;point.employeeSavingsCombined=null;}
  return point;
 });
}
