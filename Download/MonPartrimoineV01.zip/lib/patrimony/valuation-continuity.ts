import { resolveCtoCost } from "@/lib/contracts/cto-documented-cost";
import { observationAt, positionHistory, type DatedPosition } from '@/lib/contracts/position-observations';
import { expandBalanceObservations, selectDatedBalances, type DatedBalance } from '@/lib/cash/dated-balances';
import { propertyHistory, propertyValue } from '@/lib/contracts/property-valuations';
import { isAmountTracked } from '@/lib/contracts/contract-gain';
import { parisLocalDateTimeToIso } from '@/lib/cash/cash-core';
import { convertToEur, latestFxRatesByCurrency, type FxRateRecord } from '@/lib/fx/fx-core';
import { employeeSavingsValueAt, type EmployeeSavingsValue } from './employee-savings-values';
import { parisDate, selectLatestPositionSnapshots, selectLatestUsablePrices, type CurrentPositionSnapshot, type CurrentValuationAsset, type CurrentValuationPrice } from './current-valuation-core';
import { historyValuationDate } from './history-window';
import { selectHistoricalObservations, type HistoricalObservation } from './historical-observations';
import type { ChartContract, ChartPoint } from './chart-core';

type Inputs = { positions: (DatedPosition & {is_active?:boolean})[]; snapshots: CurrentPositionSnapshot[]; balances: DatedBalance[]; assets: CurrentValuationAsset[]; prices: CurrentValuationPrice[]; rates: FxRateRecord[]; manual: EmployeeSavingsValue[]; blockedContractIds?: string[]; closedOnByContract?:Record<string,string>; captures?:readonly HistoricalObservation[] };
const known = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
const nextDay = (date: string) => new Date(Date.parse(date+'T12:00:00Z')+86400000).toISOString().slice(0,10);
const empty = (date: string): ChartPoint => ({date,values:{},cash:{},contributions:{},quantities:{},netKinds:{},employeeSavingsCombined:null,provenance:'Projection de consultation · aucune capture créée'});
type InventoryCheckpoint={captureId:string;date:string;complete:boolean;positions:Inputs['positions']};
function capturedInventories(captures:readonly HistoricalObservation[],now:string){
 const result=new Map<string,InventoryCheckpoint[]>();
 for(const {selected:capture} of selectHistoricalObservations(captures)){
  if(Date.parse(capture.captured_at)>Date.parse(now))continue;
  const inputs=capture.inputs as {positions?:Inputs['positions']}|undefined;
  const native=capture.result.engineVersion==='patrimony-history-v1'&&Array.isArray(inputs?.positions);
  for(const c of capture.result.report.contracts){
   const detail=c as typeof c&{incompletePositions?:number;incompleteCashBalances?:number};
   const checkpoints=result.get(c.id)??[];
   // A later legacy/unknown authority is a barrier, not permission to reuse an
   // older native inventory merely because a newer market price is available.
   checkpoints.push({captureId:capture.id,date:capture.business_date,complete:native&&known(c.grossEur)&&detail.incompletePositions===0&&detail.incompleteCashBalances===0,positions:native?inputs!.positions!.filter(p=>p.contract_id===c.id):[]});
   result.set(c.id,checkpoints);
  }
 }
 return result;
}
function capturedHolding(p:Inputs['positions'][number],checkpoint:InventoryCheckpoint|undefined,matchCurrent=true){
 if(!checkpoint?.complete||matchCurrent&&p.is_active===false)return null;
 const matches=checkpoint.positions.filter(row=>row.id===p.id&&row.asset_id===p.asset_id&&row.contract_id===p.contract_id);
 if(matches.length!==1)return null;
 const saved=matches[0],numeric=(v:unknown)=>v!==null&&v!==undefined&&String(v).trim()!==''&&Number.isFinite(Number(v));
 if(saved.is_active!==true||!numeric(saved.quantity)||Number(saved.quantity)<0||matchCurrent&&(!numeric(p.quantity)||Number(saved.quantity)!==Number(p.quantity)))return null;
 const sameCost=numeric(saved.average_cost_per_unit)&&Number(saved.average_cost_per_unit)>=0&&(!matchCurrent||saved.cost_currency_code===p.cost_currency_code&&numeric(p.average_cost_per_unit)&&Number(saved.average_cost_per_unit)===Number(p.average_cost_per_unit));
 return {effectiveOn:checkpoint.date,quantity:saved.quantity,unitCost:sameCost?saved.average_cost_per_unit:null,currency:saved.cost_currency_code,captured:true as const};
}

// Reuse the native dated selectors. This is a read model, never a new source:
// no current undated holding, source contract total or source NET is carried.
export function projectValuationContinuity(points: readonly ChartPoint[], contracts: readonly ChartContract[], inputs: Inputs, now: string): ChartPoint[] {
 const today=parisDate(now),result=new Map(points.map(p=>[p.date,p]));
 const inventories=capturedInventories(inputs.captures??[],now);
 const validSnapshots=inputs.snapshots.filter(s=>s.market_value!=null&&String(s.market_value).trim()!==''&&Number.isFinite(Number(s.market_value))&&Number(s.market_value)>=0&&Number.isFinite(Date.parse(s.valued_at))&&Date.parse(s.valued_at)<=Date.parse(now));
 const expandedBalances=expandBalanceObservations(inputs.balances);
 const positionDates=inputs.positions.flatMap(p=>positionHistory(p.metadata)?.entries.map(e=>e.effectiveOn)??propertyHistory(p.metadata)?.entries.map(e=>e.effectiveOn)??[]);
 const first=[...validSnapshots.map(s=>parisDate(s.valued_at)),...positionDates,...expandedBalances.map(b=>parisDate(b.as_of)),...inputs.manual.map(m=>m.date),...[...inventories.values()].flatMap(rows=>rows.map(r=>r.date))].filter(d=>d<=today).sort()[0];
 if(!first)return [...points];
 const histories=new Map(inputs.positions.map(p=>[p.id,positionHistory(p.metadata)]));
 for(let day=first;day<=today;day=nextDay(day)){
  const at=day===today?now:new Date(Date.parse(parisLocalDateTimeToIso(nextDay(day)+'T00:00'))-1).toISOString();
  const fx=latestFxRatesByCurrency(inputs.rates,day),snapshots=selectLatestPositionSnapshots(validSnapshots,at),prices=selectLatestUsablePrices(inputs.assets,inputs.prices,at);
  const balances=selectDatedBalances(inputs.balances,at);
  const original=result.get(day);let point=original;
  for(const c of contracts){
   const closedOn=inputs.closedOnByContract?.[c.id];
   if(closedOn?day>=closedOn:c.isActive===false||inputs.blockedContractIds?.includes(c.id))continue;
   if(c.openedOn&&day<c.openedOn)continue;
   const grossKey=`contract:${c.id}:gross`,netKey=`contract:${c.id}:net`;
   // Actual historical authorities, including explicit unknowns, always win.
   const authoritative=!!original&&grossKey in original.values;
   const values:Record<string,number|null>={},quantities:Record<string,number|null>={},costs:Record<string,number|null>={},dates:Record<string,string|null>={};
   let costConflict = false;
   const amounts:string[]=[],sourceDates:string[]=[],inventoryDates:string[]=[];
   const checkpoint=inventories.get(c.id)?.filter(r=>r.date<=day).at(-1);
   const manual=c.valuationAuthority==='global'?employeeSavingsValueAt(inputs.manual,c.id,day):null;
   if(c.valuationAuthority==='global'&&!manual)continue;
   if(manual)sourceDates.push(manual.date);
   else for(const child of c.children){
    values[child.id]=null;quantities[child.id]=null;costs[child.id]=null;dates[child.id]=null;
    if(child.kind==='cash'){
     const rows=balances.filter(b=>b.contract_id===c.id);
     if(!rows.length)continue;
     const converted=rows.map(b=>convertToEur(b.amount,b.currency_code,fx.get(b.currency_code)).amountEur);
     values[child.id]=converted.every(known)?converted.reduce((sum,v)=>sum+v,0):null;
     dates[child.id]=rows.map(b=>parisDate(b.as_of)).sort().at(-1)!;sourceDates.push(dates[child.id]!,...rows.flatMap(b=>b.currency_code!=='EUR'&&fx.has(b.currency_code)?[fx.get(b.currency_code)!.requested_on]:[]));continue;
    }
    const positions=inputs.positions.filter(p=>p.contract_id===c.id&&p.asset_id===child.assetId);
    // A complete dated inventory also proves that an old chart-only support
    // was no longer held. A new/changed current binding cannot use this absence.
    const absentBinding=positions.every(p=>{
     const h=histories.get(p.id),first=h?.entries.map(e=>e.effectiveOn).sort()[0];
     return p.is_active===false||!!(first&&day<first&&!h?.archived.some(a=>a.undatedPrevious)&&!h?.bindings.some(b=>!b.restore&&b.date<=day));
    });
    if(checkpoint?.complete&&absentBinding&&!checkpoint.positions.some(p=>p.asset_id===child.assetId&&p.is_active!==false)){
     values[child.id]=0;quantities[child.id]=0;dates[child.id]=checkpoint.date;sourceDates.push(checkpoint.date);inventoryDates.push(checkpoint.date);continue;
    }
    // Several bindings for one asset need an explicit inventory arbitration.
    if(positions.length!==1)continue;
    const p=positions[0],history=histories.get(p.id),firstNative=history?.entries.map(e=>e.effectiveOn).sort()[0];
    // A dated first change bounds the preceding captured state. Empty/deleted
    // histories and explicitly corrected capture bindings cannot revive it.
    const beforeFirst=!!(checkpoint&&firstNative&&day<firstNative&&checkpoint.date<firstNative&&!history?.bindings.some(b=>b.captureId===checkpoint.captureId&&!b.restore));
    const observation=history?observationAt(history.entries,day)??(beforeFirst?capturedHolding(p,checkpoint,false):null):capturedHolding(p,checkpoint);
    const property=propertyHistory(p.metadata);
    const snapshot=snapshots.get(p.id);
    const asset=inputs.assets.find(a=>a.id===child.assetId);
    const monetary=isAmountTracked(asset?.valuation_mode??'',!!(child.assetId&&prices.has(child.assetId)),!!history,snapshot?{}:null,p.metadata);
    if(property){
     const value=propertyValue(p.metadata,day,inputs.rates);
     if(!value.observation)continue;
     values[child.id]=value.amountEur;dates[child.id]=value.observation.effectiveOn;
    }else if(monetary){
     amounts.push(child.id);if(!snapshot)continue;
     values[child.id]=convertToEur(snapshot.market_value,snapshot.currency_code,fx.get(snapshot.currency_code)).amountEur;dates[child.id]=parisDate(snapshot.valued_at);
    }else if(observation){
     if('captured' in observation)inventoryDates.push(observation.effectiveOn);
     const quantity=Number(observation.quantity),price=child.assetId?prices.get(child.assetId):undefined;
     quantities[child.id]=quantity;
     const cost=resolveCtoCost({ metadata:p.metadata, observation, native:observation.unitCost, currency:observation.currency,
      day, quantity, legacyUnit:observation.unitCost===null?null:convertToEur(observation.unitCost,observation.currency,fx.get(observation.currency)).amountEur });
     costs[child.id]=quantity===0?0:cost.unit;
     costConflict ||= quantity>0 && cost.conflict;
     values[child.id]=quantity===0?0:price?convertToEur(quantity*Number(price.price),price.currency_code,fx.get(price.currency_code)).amountEur:null;
     dates[child.id]=[observation.effectiveOn,...(price?[parisDate(price.observed_at)]:[])].sort().at(-1)!;
    }
    if(dates[child.id]){
     // FX is another dated input to the EUR amount, not a new valuation.
     const currencies=[snapshot?.currency_code,observation?.currency,child.assetId?prices.get(child.assetId)?.currency_code:undefined];
     const fxDates=currencies.flatMap(code=>code&&code!=='EUR'&&fx.has(code)?[fx.get(code)!.requested_on]:[]);
     sourceDates.push(dates[child.id]!,...fxDates);
    }
   }
   if(!sourceDates.length)continue; // No evidence, including for an empty contract.
   const sourceDate=sourceDates.sort().at(-1)!;
   const gross=manual?Number(manual.gross):c.children.length&&c.children.every(ch=>known(values[ch.id]))?c.children.reduce((s,ch)=>s+values[ch.id]!,0):null;
   if(authoritative){
    // A capture repeating a manual situation remains the same source. Mark
    // its consultation extent only; do not replace any captured financial cell.
    if(manual&&known(gross)&&original!.values[grossKey]===gross&&original!.employeeSavingsEvidence?.[c.id]?.ref===manual.ref){
     if(point===original)point=structuredClone(original!);
     point!.continuityEvidence={...point!.continuityEvidence,[c.id]:{sourceDate,throughDate:day}};
    }
    continue;
   }
   // A newer incompatible capture/source stops an older native state. A new
   // dated state can resume it; a published unknown is never filled with zero.
   const barrier=[...points].filter(p=>p.date<=day&&grossKey in p.values&&(historyValuationDate(p,`contract:${c.id}`,contracts)??p.date)>sourceDate).sort((a,b)=>b.date.localeCompare(a.date))[0];
   if(barrier&&(barrier.declaredContractTotals?.[c.id]||barrier.values[grossKey]!==gross||manual&&barrier.values[netKey]!== (manual.net===null?null:Number(manual.net))||!manual&&c.children.some(ch=>barrier.values[ch.id]!==values[ch.id])))continue;
   point??=empty(day);
   if(point===original)point=structuredClone(original!);
   point.values={...point.values,...values,[grossKey]:known(gross)?gross:null,[netKey]:manual?.net!=null?Number(manual.net):null};
   point.quantities={...point.quantities,...quantities};point.historicalUnitCosts={...point.historicalUnitCosts,...costs};
   point.amountTrackedIds=[...new Set([...(point.amountTrackedIds??[]),...amounts])];
   for(const child of c.children.filter(ch=>ch.kind==='cash'))point.cash[child.id]=values[child.id];
   point.valuationSourceDates={...point.valuationSourceDates,...dates,[`contract:${c.id}`]:sourceDate};
   point.continuityEvidence={...point.continuityEvidence,[c.id]:{sourceDate,throughDate:day}};
   point.netKinds[c.id]=manual?.net!=null?'approximate':'unavailable';
   if(costConflict)point.netReasons={...point.netReasons,[c.id]:"Les preuves de coût CTO se contredisent."};
   if(manual)point.employeeSavingsEvidence={...point.employeeSavingsEvidence,[c.id]:manual};
   point.provenanceByContract={...point.provenanceByContract,[c.id]:`Dernières données connues du ${sourceDate} prolongées au ${day} · projection de consultation, aucune nouvelle observation.${inventoryDates.length?` Quantités documentées par la capture du ${inventoryDates.sort().at(-1)} ; cours et espèces sélectionnés séparément à la date évaluée.`:''} NET soumis aux règles applicables à cette date.`};
  }
  if(point)result.set(day,point);
 }
 return [...result.values()].sort((a,b)=>a.date.localeCompare(b.date));
}
