import { resolveCtoCost } from "@/lib/contracts/cto-documented-cost";
import { positionHistory, type DatedPosition, type PositionBinding } from "@/lib/contracts/position-observations";
import { selectLatestUsablePrices, parisDate } from "./current-valuation-core";
import { latestFxRatesByCurrency, convertToEur, type FxRateRecord } from "@/lib/fx/fx-core";
import { selectHistoricalObservations, type HistoricalObservation, type HistoricalSource } from "./historical-observations";
import type { ChartPoint, ChartContract } from "./chart-core";
import type { PatrimonialReportRecords } from "@/lib/reports/patrimonial-report-core";
export function qualifiedObservation(binding: PositionBinding, capture: HistoricalObservation, assetId: string, metadata?:unknown) {
    const e = binding.observation;
    if (!e)
        return { quantity: null, cost: null, value: null, price: null, fx: [], reason: "Observation déplacée : détention non démontrée à cette date." };
    const inputs = capture.inputs as Partial<PatrimonialReportRecords> | undefined;
    const rates = latestFxRatesByCurrency([...(inputs?.currentFxRates ?? []), ...(inputs?.historicalFxRates ?? [])], binding.date);
    const prices = (inputs?.prices ?? []).filter(p => parisDate(p.observed_at) <= binding.date);
    const price = selectLatestUsablePrices(inputs?.assets ?? [], prices, capture.captured_at).get(assetId) ?? null;
    const quantity = Number(e.quantity), unitCost = e.unitCost === null ? null : Number(e.unitCost);
    const value = quantity === 0 ? 0 : price ? convertToEur(quantity * Number(price.price), price.currency_code, rates.get(price.currency_code)).amountEur : null;
    const proof = resolveCtoCost({ metadata: metadata ?? inputs?.positions?.find(p => p.asset_id === assetId)?.metadata,
      observation: e, native: e.unitCost, currency: e.currency, day: binding.date, quantity,
      legacyUnit: unitCost === null ? null : convertToEur(unitCost, e.currency, rates.get(e.currency)).amountEur });
    const cost = quantity === 0 ? 0 : proof.unit;
    const reason = [value === null ? "Cours historique ou FX de valorisation qualifié absent." : null,
      proof.conflict ? "Les preuves de coût CTO se contredisent." : cost === null ? "PRU historique ou FX de coût qualifié absent." : null].filter(Boolean).join(" ");
    const fx = [...new Set([e.currency, price?.currency_code])].flatMap(c => c && c !== "EUR" && rates.has(c) ? [rates.get(c)!] : []) as FxRateRecord[];
    return { quantity, cost, value, price, fx, reason };
}
export function projectPositionObservations(points: ChartPoint[], contracts: ChartContract[], captures: HistoricalObservation[], sources: HistoricalSource[], positions: DatedPosition[]) {
    const selected = new Map(selectHistoricalObservations(captures).map(g => [g.date, g.selected]));
    return points.map(original => {
        const capture = selected.get(original.date);
        if (!capture || capture.result.engineVersion !== "patrimony-history-v1")
            return original;
        const point = { ...original, values: { ...original.values }, quantities: { ...original.quantities }, historicalUnitCosts: { ...original.historicalUnitCosts }, netKinds: { ...original.netKinds }, netReasons: { ...original.netReasons }, provenanceByContract: { ...original.provenanceByContract }, holdingObservationEvidence: { ...original.holdingObservationEvidence } };
        for (const position of positions) {
            const h = positionHistory(position.metadata);
            const binding = h?.bindings.filter(b => b.captureId === capture.id).at(-1);
            if (!binding || binding.restore)
                continue;
            const archivedInputs = capture.inputs as Partial<PatrimonialReportRecords> | undefined;
            const sourceNet = archivedInputs?.contracts?.some(c => c.id === position.contract_id && c.metadata?.knownLiquidationNetEur != null);
            const contract = contracts.find(c => c.id === position.contract_id);
            if (sourceNet || !contract || contract.valuationAuthority === "global" || point.declaredContractTotals?.[contract.id] || sources.some(s => s.business_date === point.date && s.payload.kind === "approved_contract_correction" && (s.payload as {
                contractId?: string;
            }).contractId === contract.id))
                continue;
            const key = `asset:${position.contract_id}:${position.asset_id}`, before = point.values[key], grossKey = `contract:${position.contract_id}:gross`, gross = point.values[grossKey];
            const result = qualifiedObservation(binding, capture, position.asset_id,position.metadata);
            point.values[key] = result.value;
            point.quantities[key] = result.quantity;
            point.historicalUnitCosts[key] = result.cost;
            point.values[grossKey] = typeof gross === "number" && typeof before === "number" && result.value !== null ? gross - before + result.value : null;
            point.values[`contract:${position.contract_id}:net`] = null;
            point.netKinds[position.contract_id] = "unavailable";
            point.netReasons[position.contract_id] = result.reason || "NET à recalculer selon les règles datées existantes.";
            point.provenanceByContract[position.contract_id] = `${original.provenanceByContract?.[position.contract_id] ?? "Capture native"} · Situation de détention corrigée, source conservée. ${result.reason}`;
            point.holdingObservationEvidence[key] = { ...binding, ...result };
        }
        return Object.keys(point.holdingObservationEvidence).length ? point : original;
    });
}
