import { chartValue, historicalHoldingState, visibleHistoricalLegend, type ChartContract, type ChartMode, type ChartPoint } from "./chart-core";
import { orderPatrimonySeries } from "./history-policy";

type SeriesIdentity = { id: string; label: string };
type LegendEntry = { serie: SeriesIdentity & { color: string }; index: number };
type LegendRow = { point: ChartPoint; activeIds: string[]; values: (number | null)[] };

// Bottom to top, independent of mode, amounts, selected date and visibility.
// The same identities therefore keep their neighbours in BRUT and NET.
export function canonicalHistorySeries<T extends SeriesIdentity>(series: readonly T[], contracts: ChartContract[], byEnvelope = false): T[] {
  if (byEnvelope) return orderPatrimonySeries(series, contracts);
  const euroFunds = new Set(contracts.flatMap(contract => contract.children.filter(child => child.euroFund).map(child => child.id)));
  const rank = (id: string) => id.startsWith("cash:") ? 0 : euroFunds.has(id) ? 1 : id.startsWith("contract:") ? 3 : 2;
  return [...series].sort((a, b) => rank(a.id) - rank(b.id) || a.id.localeCompare(b.id, "en"));
}

// Keep the numerical selection untouched. Unknown held positions are legend
// entries only: they never become a zero or a synthetic stacked band.
export function presentedHistoryLegend<T extends LegendEntry>(entries: T[], row: LegendRow, contracts: ChartContract[], mode: ChartMode): T[] {
  const known = new Set(visibleHistoricalLegend(entries, row.point, contracts, mode).filter(entry => row.activeIds.includes(entry.serie.id)));
  return entries.filter(entry => known.has(entry) || unavailableHistoryEntry(entry, row, contracts, mode));
}

export function unavailableHistoryEntry(entry: LegendEntry, row: LegendRow, contracts: ChartContract[], mode: ChartMode) {
  return mode === "net"
    && (row.activeIds.includes(entry.serie.id) || entry.serie.id.startsWith("asset:") || entry.serie.id.startsWith("cash:"))
    && ["held", "unquantified"].includes(historicalHoldingState(row.point, entry.serie.id, contracts))
    && chartValue(row.point, entry.serie.id, mode) === null;
}

// PNG keeps the screen's summit-to-base legend, including unknown positions.
// A window containing both known and unknown dates is explicitly identified.
export function historyExportLegend<T extends LegendEntry>(entries: T[], rows: LegendRow[], contracts: ChartContract[], mode: ChartMode) {
  return entries.flatMap(entry => {
    const shown = rows.filter(row => presentedHistoryLegend([entry], row, contracts, mode).length);
    if (!shown.length) return [];
    const missing = shown.filter(row => unavailableHistoryEntry(entry, row, contracts, mode)).length;
    const suffix = missing ? missing === shown.length ? " — Indisponible" : " — Indisponible à certaines dates" : "";
    return [{ ...entry.serie, label: entry.serie.label + suffix }];
  });
}
