import {chartGeography} from "@/lib/geography/chart-geography";
import { resolveExposureHistory } from "@/lib/assets/exposure-history";
import { chartValue, historicalSelectionIds, resolveSelection, historicalHoldingState, stableColor, type ChartContract, type ChartMode, type ChartPoint, type PatrimonyChartData } from "@/lib/patrimony/chart-core";
import { distinctAutomaticColors, exposureWeightTotal } from "@/lib/patrimony/distribution-core";
import type { DistributionExplanation } from "@/lib/patrimony/distribution-core";
import { parisDate } from "@/lib/patrimony/current-valuation-core";

type Selection = Record<string, "global" | string[]>;
export function selectedValuationDates(contracts: ChartContract[], selection: Selection) {
  return [...new Set(contracts.flatMap((contract) => {
    const selected = selection[contract.id];
    const values = selected === "global" ? contract.valuationDates ?? (contract.valuationDate ? [contract.valuationDate] : [])
      : Array.isArray(selected) ? contract.children.filter((child) => selected.includes(child.id)).flatMap((child) => child.valuedAt ? [child.valuedAt] : []) : [];
    return values.filter((value) => Number.isFinite(Date.parse(value))).map(parisDate);
  }))].sort();
}
export type ChartSlice = { id: string; name: string; amount: number | null; color: string; cashOutsideSecurities?: boolean; unspecified?: boolean };

export function chartColors(contracts: ChartContract[]) {
  return new Map(distinctAutomaticColors(contracts.flatMap((contract) => [
    { id: `contract:${contract.id}`, color: contract.color, automatic: contract.colorAutomatic === true },
    ...contract.children.map((child) => ({ id: child.id, color: child.color, automatic: child.colorAutomatic === true })),
  ])).map((row) => [row.id, row.color]));
}

export function compositionSlices(contracts: ChartContract[], selection: Selection, mode: ChartMode): ChartSlice[] {
  const colors = chartColors(contracts);
  return contracts.flatMap((contract) => {
    const selected = selection[contract.id];
    if (selected === "global") return [{ id: `contract:${contract.id}`, name: contract.name, amount: contract.valuationIncomplete ? null : mode === "net" ? contract.netEur : contract.grossEur, color: colors.get(`contract:${contract.id}`)! }];
    return Array.isArray(selected) ? contract.children.filter((child) => selected.includes(child.id) && !(child.quantified && child.quantity === 0)).map((child) => ({ id: child.id, name: child.label, amount: child.valueEur, color: colors.get(child.id)!, cashOutsideSecurities: child.kind === "cash" })) : [];
  });
}

export function historicalCompositionSlices(contracts: ChartContract[], contract: ChartContract, point: ChartPoint) {
  const colors = chartColors(contracts);
  const assets = contract.children.filter((child) => child.kind === "asset");
  if (assets.some((child) => historicalHoldingState(point, child.id, contracts) === "unknown")) {
    return { slices: [] as ChartSlice[], unavailable: "Composition indisponible : une quantité historique est inconnue ; aucune détention n’est déduite." };
  }
  const slices: ChartSlice[] = assets.filter((child) => historicalHoldingState(point, child.id, contracts) === "held")
    .map((child) => ({ id: child.id, name: child.label, amount: point.values[child.id] ?? null, color: colors.get(child.id)! }));
  for (const child of contract.children.filter((child) => child.kind === "cash")) {
    slices.push({ id: child.id, name: child.label, amount: point.cash[child.id] ?? null, color: child.color, cashOutsideSecurities: true });
  }
  return { slices, unavailable: null };
}

export function historicalPatrimonyComposition(contracts: ChartContract[], selection: Selection, mode: ChartMode, point: ChartPoint) {
  const colors = chartColors(contracts);
  const ids = historicalSelectionIds(point, resolveSelection(contracts, selection), contracts);
  const missing: string[] = [];
  const slices: ChartSlice[] = [];
  for (const id of ids) {
    if (historicalHoldingState(point, id, contracts) === "absent") continue;
    const contract = contracts.find(c => c.id === id.split(":")[1]);
    const child = contract?.children.find(c => c.id === id);
    const name = id === "employee-savings-combined" ? "PEG + PER COL — historique non ventilé" : child?.label ?? contract?.name ?? id;
    const value = id === "employee-savings-combined" ? mode === "gross" ? point.employeeSavingsCombined : null
      : child?.kind === "cash" ? point.cash[id] : chartValue(point, id, mode);
    if (historicalHoldingState(point,id,contracts) === "unknown" || value == null || !Number.isFinite(value)) { missing.push(name); continue; }
    slices.push({id,name,amount:value,color:colors.get(id) ?? stableColor(id),cashOutsideSecurities:child?.kind === "cash"});
  }
  return {slices, missing, coverageNote: missing.length ? `Couverture partielle : ${missing.join(" ; ")} indisponible(s). Pourcentages sur le sous-total connu ; total complet indisponible.` : "Pourcentages sur les valeurs documentées de la sélection à cette date."};
}

export function exposureSlices(data: PatrimonyChartData, selection: Selection, dimension: "sector" | "geography", _mode: ChartMode, point: ChartPoint | null = null): { slices: ChartSlice[]; unavailable: string | null; trace?: string[]; details?: DistributionExplanation[]; coverageNote?: string } {
  if(dimension==="geography" && data.geographyReferences)return chartGeography(data,selection,point);
  if (data.exposureUnavailable) return { slices: [], unavailable: "Répartitions indisponibles : la lecture des référentiels ou expositions a échoué." };
  const amounts = new Map<string, ChartSlice>();
  const trace: string[] = [], missing: string[] = [];
  const details: DistributionExplanation[] = [];
  const add = (id: string, name: string, amount: number) => {
    const row = amounts.get(id);
    amounts.set(id, { id, name, amount: (row?.amount ?? 0) + amount, color: stableColor(id) });
  };
  const ids = point ? historicalSelectionIds(point,resolveSelection(data.contracts,selection),data.contracts) : resolveSelection(data.contracts,selection);
  if (point && ids.includes("employee-savings-combined")) {
    add(`${dimension}:unallocated`, "Non spécifié", point.employeeSavingsCombined!);
    trace.push("PEG + PER COL : montant commun documenté, sans ventilation sectorielle/géographique.");
    if(point.employeeSavingsCombined!>0)details.push({id:"employee-savings-combined",name:"PEG + PER COL",reason:"Montant commun documenté, sans ventilation qualifiée ; compté une seule fois.",inDonut:true});
  }
  for (const contract of data.contracts.filter(c => selection[c.id])) {
    const selected = selection[contract.id];
    if (point && historicalHoldingState(point,`contract:${contract.id}`,data.contracts) === "absent") continue;
    if (selected === "global" && !ids.includes(`contract:${contract.id}`)) continue;
    const candidates = contract.children.filter(child => selected === "global" || selected.includes(child.id));
    let knownAssets = 0, assetMissing = false;
    for (const child of candidates.filter(c => c.kind === "asset")) {
      const holding = point ? historicalHoldingState(point,child.id,data.contracts) : child.quantified && child.quantity === 0 ? "absent" : "held";
      if (holding === "absent") continue;
      const value = point ? point.values[child.id] : child.valueEur;
      if (holding === "unknown" || value == null || !Number.isFinite(value)) { assetMissing = true; details.push({id:child.id,name:child.label,reason:holding==="unknown"?"Détention historique inconnue ; aucun montant attribué à cet actif.":"Valorisation inconnue ; aucun montant attribué à cet actif.",inDonut:false}); if (selected !== "global") missing.push(`${child.label} : ${holding === "unknown" ? "détention est inconnue" : "valorisation de titre manque"}`); continue; }
      if (value < 0) return { slices: [], unavailable: "Répartition indisponible : une valorisation négative ne permet pas un donut." };
      let rows;
      if (point) {
        try {
          const resolved=resolveExposureHistory(data.exposures,child.assetId!,dimension,point.date);
          rows=resolved.rows;
          if(rows.length)trace.push(`${child.label} : ${resolved.method==="exact"?"capture présente conservée":resolved.method==="backfill"?"reprise historique autorisée":"continuité autorisée"} · données ${resolved.sourceDate ?? "date inconnue"} · effet ${rows[0].effectiveFrom ?? "non documenté"}`);
        } catch(error) {return {slices:[],unavailable:error instanceof Error?error.message:"Répartition historique ambiguë"};}
      } else rows=data.exposures.filter(row=>row.assetId===child.assetId && row.dimension===dimension && row.stage!=="draft" && row.stage!=="scheduled" && !row.snapshotDate && row.isCurrent!==false);
      const weight=exposureWeightTotal(rows.map(row=>row.weight));
      if (!Number.isFinite(weight) || weight > 100.000001 || rows.some(row=>row.weight<0)) return {slices:[],unavailable:"Répartition indisponible : les pondérations sont incohérentes."};
      knownAssets += value;
      for (const row of rows) add(row.unallocated ? `${dimension}:unallocated` : `${dimension}:${row.referenceId ?? row.name}`, row.unallocated ? "Non spécifié" : row.name, value*row.weight/100);
      if (weight < 100) add(`${dimension}:unallocated`,"Non spécifié",value*(100-weight)/100);
      if(value>0&&weight<100)details.push({id:child.id,name:`${contract.name} · ${child.label}`,reason:weight===0?"Aucune répartition qualifiée applicable à cette date.":"Répartition partielle : part non ventilée conservée dans Non spécifié.",inDonut:true});
      for(const row of rows.filter(row=>row.unallocated&&value*row.weight/100>0))details.push({id:child.id,name:`${contract.name} · ${child.label}`,reason:`Catégorie Non spécifié explicitement publiée ; données ${row.dataDate??"date inconnue"} · ${row.source??"source non spécifiée"}.`,inDonut:true});
    }
    if (selected === "global") {
      const cashValues=candidates.filter(c=>c.kind==="cash").map(c=>point?point.cash[c.id]:c.valueEur);
      const gross=point?point.values[`contract:${contract.id}:gross`]:contract.valuationIncomplete?null:contract.grossEur;
      // A documented contract total can retain its unallocated remainder without
      // manufacturing holdings. Unknown cash cannot be subtracted as zero.
      if (gross == null || cashValues.some(v=>v==null || !Number.isFinite(v))) {
        missing.push(`${contract.name} : valorisation ou solde espèces inconnu`);
        details.push({id:contract.id,name:contract.name,reason:"Valorisation ou espèces inconnues ; couverture financière non quantifiable.",inDonut:false});
      } else {
        const remainder=gross-cashValues.reduce<number>((sum,v)=>sum+v!,0)-knownAssets;
        // Source-declared totals may differ from their exact components by a cent.
        // Exposure weighting keeps component amounts; never invent an adjustment.
        if (assetMissing || !candidates.some(c=>c.kind==="asset")) {
          if (remainder < -.005) return {slices:[],unavailable:"Répartition indisponible : la valorisation et les composants sont incohérents."};
          if (remainder > .005) {add(`${dimension}:unallocated`,"Non spécifié",remainder);details.push({id:contract.id,name:contract.name,reason:"Reliquat BRUT documenté sans ventilation qualifiée ; aucune détention déduite.",inDonut:true});}
          if (assetMissing) trace.push(`${contract.name} : total BRUT documenté, détail de détention/valorisation incomplet ; solde non ventilé.`);
        }
      }
    }
  }
  const universe=[...new Set([...data.exposures.filter(row=>row.dimension===dimension).map(row=>`${dimension}:${row.referenceId ?? row.name}`),`${dimension}:unallocated`])];
  const colors=new Map(distinctAutomaticColors(universe.map(id=>({id,color:stableColor(id),automatic:true}))).map(row=>[row.id,row.color]));
  const slices=[...amounts.values()].map(row=>({...row,color:colors.get(row.id)!}));
  const coverageNote=missing.length?`Couverture partielle : ${missing.join(" ; ")}. Pourcentages sur la base BRUT connue hors espèces ; couverture totale non quantifiable.`:"Base BRUT historique documentée, hors espèces. Valeurs connues sans exposition : Non spécifié.";
  return {slices,unavailable:!slices.length && missing.length?`Répartition indisponible : ${missing.join(" ; ")}.`:null,trace,coverageNote,details};
}
