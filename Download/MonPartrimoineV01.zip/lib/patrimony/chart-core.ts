import {envelopeNetMode,commonTaxConfiguration,prefersEnvelopeEstimate} from '@/lib/fiscal/envelope-policy';
import {calculateEnvelopeTax,selectEnvelopeFiscalities,type EnvelopeFiscality} from '@/lib/fiscal/envelope-tax-core';
import type { PositionObservation,PositionBinding } from "@/lib/contracts/position-observations";
import type { qualifiedObservation } from "./position-observation-projection";
import type { PatrimonialReport, ReportExposureDistribution } from "@/lib/reports/patrimonial-report-core";
import { calculateFiscalEstimate, type FiscalRule } from "@/lib/fiscal/fiscal-core";

import {frozenHistoricalBinding,type FiscalSelection} from '@/lib/fiscal/contract-fiscal';
export type ChartMode = "gross" | "net";
export type ChartChild = { id: string; kind: "asset" | "cash"; euroFund?: boolean; label: string; valueEur: number | null; assetId?: string; symbol?: string | null; isin?:string|null; color: string; colorAutomatic?: boolean; valuedAt?: string | null; quantified?: boolean; quantity?: number | null };
export type NetQuality = "calculated" | "approximate" | "legacy_estimate" | "unavailable";
export type ChartContract = { id: string; name: string; envelopeType: string; envelopeTypeCode?: string; sourceKey: string | null; openedOn: string | null; closedOn?: string | null; isActive: boolean; grossEur: number; netEur: number | null; netKind: NetQuality; valuationDate: string | null; valuationAuthority?: "global" | "positions"; valuationDates?: string[]; color: string; colorAutomatic?: boolean; valuationIncomplete?: boolean; children: ChartChild[] };
export type ChartPoint = { displayedContributions?:Record<string,number|null>; contributionCorrectionEvidence?:Record<string,{id:string;date:string;amount:string}>; initialCashEvidence?: Record<string, import("./initial-cash-period").InitialCashEvidence>; continuityEvidence?:Record<string,{sourceDate:string;throughDate:string}>; amountReconciliationEvidence?:Record<string,{amount:string;currency:string;valuedAt:string}>; sourceNetDates?:Record<string,string|null>; titleNets?:Record<string,number|null>;titleNetReasons?:Record<string,string>; valuationSourceDates?:Record<string,string|null>; amountTrackedIds?:string[]; fiscalSelections?:Record<string,FiscalSelection>; employeeSavingsEvidence?:Record<string,import("./employee-savings-values").EmployeeSavingsValue>; manualGrossEvidence?:Record<string,import("./approved-gross-observations").GrossObservationEvidence>; archivedEmployeeSavingsCombined?:number; propertyEvidence?:Record<string,{sourceContractId:string;positionId:string;observation:import("@/lib/contracts/property-valuations").PropertyObservation|null;contractSource:boolean}>; cashNetProjection?: Record<string, { sourceNetEur: number; sourceGrossEur: number; sourceCashEur: number; deltaEur: number; effectiveNetEur: number; fiscalRuleVersion: number; historicalCostsKnown: boolean }>; holdingObservationEvidence?:Record<string,PositionBinding&ReturnType<typeof qualifiedObservation>>; cashProjectionBase?: Record<string, { cashEur: number; grossEur: number | null; netEur?: number | null; netKind?: NetQuality; holdingsFingerprint?: string; provenance?: string }>; declaredContractTotals?: Record<string, { grossEur: number; componentSumEur: number; sourceId: string }>; date: string; values: Record<string, number | null>; cash: Record<string, number | null>; contributions: Record<string, number | null>; netCashFlows?: Record<string, number | null>; sourceContributions?: Record<string, number | null>; sourceNetCashFlows?: Record<string, number | null>; sourceNets?: Record<string, number | null>; netReasons?: Record<string, string>; quantities: Record<string, number | null>; historicalUnitCosts?: Record<string, number | null>; sourcePropertyNets?: Record<string, number | null>; provenanceByContract?: Record<string, string>; netKinds: Record<string, NetQuality>; employeeSavingsCombined: number | null; provenance: string };
export type ExposureRow = import("@/lib/assets/exposure-history").DatedExposure;
export type PatrimonyChartData = { navigationExcludedContractIds?:string[]; geographyReferences?:{countries:import("@/lib/geography/mixed-geography").CountryReference[];regions:{code:string;name:string}[]}; geographicLocations?:{contracts:Record<string,unknown>;assets:Record<string,unknown>}; propertyObservations?:{contractId:string;positionId:string;assetId:string;observation:import("@/lib/contracts/property-valuations").PropertyObservation}[]; holdingObservations?:{contractId:string;assetId:string;observation:PositionObservation}[]; cashOperations?:{contractId:string;currency:string;date:string;kind:string;amount:number;delta:number;order:number;revision:string;legacyMode?:string|null}[]; positionValuations?:{contractId:string;assetId:string;amount:number|null;currency:string;valuedAt:string}[]; assetPrices?:{assetId:string;price:number;currency:string;observedAt:string;obtainedAt:string|null;source:string}[]; fxRates?:{currency:string;requestedOn:string|null;observedOn:string|null;eurPerUnit:number;source:string|null;obtainedAt:string|null}[]; cashFlows?:DatedCashFlow[]; historyRows?:{contractId:string;rows:unknown[][]}[]; generatedAt?:string; historyEvidence?:import("./history-csv").HistoryEvidence[]; contracts: ChartContract[]; points: ChartPoint[]; exposures: ExposureRow[]; exposureUnavailable?: boolean; initialScope: "total" | "outside-real-estate"; latestDate: string | null };

export function hasContractDistributions(contract: Pick<ChartContract, "envelopeTypeCode"> | null) {
  return !["immobilier", "epargne_liquide", "peg", "per_col"].includes(contract?.envelopeTypeCode ?? "");
}

export function showsHistoricalContributions(contract: Pick<ChartContract, "envelopeTypeCode"> | null) {
  return Boolean(contract) && contract?.envelopeTypeCode !== "epargne_liquide";
}

export function isSecuritiesEnvelopeType(code: string | undefined) {
  return ["pea", "cto", "pea_pme", "compte_titres"].includes(code ?? "");
}

export function isQuantifiedAssetType(code: string) {
  return ["stock", "etf", "fund", "bond"].includes(code);
}

export function historyGesture(dx: number, dy: number) {
  if (Math.max(Math.abs(dx), Math.abs(dy)) < 8) return "tap";
  return Math.abs(dx) > Math.abs(dy) * 1.2 ? "horizontal" : "vertical";
}

export function historyKeyboardScroll(key: string, left: number, pageWidth: number, maximum: number) {
  const next = key === "Home" ? 0 : key === "End" ? maximum
    : key === "ArrowLeft" ? left - pageWidth / 4 : key === "ArrowRight" ? left + pageWidth / 4
      : key === "PageUp" ? left - pageWidth : key === "PageDown" ? left + pageWidth : null;
  return next === null ? null : Math.max(0, Math.min(maximum, next));
}

const COLORS = ["#d6a84f", "#5b9bd5", "#70ad47", "#8064a2", "#ed7d31", "#46b8b0", "#c55a72", "#9e7b5b", "#7f8c8d", "#a5a5a5"];
export function stableColor(key: string) {
  let hash = 0;
  for (const char of key) hash = (hash * 31 + char.charCodeAt(0)) | 0;
  return COLORS[Math.abs(hash) % COLORS.length];
}

export type TooltipPlacement = { mode: "left" | "right" | "panel"; left: number };
export function tooltipPlacement(pointX: number, visibleLeft: number, visibleRight: number, tooltipWidth: number, gap = 16): TooltipPlacement {
  const inset = 8;
  // A selected date can leave the viewport after fullscreen/resize or a drag.
  // Anchor its detail to the visible bounds, never to an offscreen coordinate.
  pointX = Math.min(visibleRight - inset, Math.max(visibleLeft + inset, pointX));
  if (pointX + gap + tooltipWidth <= visibleRight - inset) return { mode: "right", left: pointX + gap };
  if (pointX - gap - tooltipWidth >= visibleLeft + inset) return { mode: "left", left: pointX - gap - tooltipWidth };
  return { mode: "panel", left: visibleLeft + inset };
}

export function verticalDomain(maximum: number, zoom: number, offset: number) {
  const safeMaximum = Math.max(1, maximum);
  const safeZoom = Math.min(12, Math.max(1, zoom));
  const span = safeMaximum / safeZoom;
  const min = Math.min(Math.max(0, offset), Math.max(0, safeMaximum - span));
  return { min, max: min + span, span, zoom: safeZoom };
}

export type HistoricalGain = { status: "complete" | "incomplete" | "unavailable"; amount: number | null; percentage: number | null };
export function historicalGain(values: Record<string, number | null>, quantities: Record<string, number | null>, costs: Record<string, number | null>, ids: string[]): HistoricalGain {
  let amount = 0, basis = 0, covered = 0, missing = 0;
  for (const id of ids) {
    const value = values[id], quantity = quantities[id], unitCost = costs[id];
    if (typeof value !== "number" || typeof quantity !== "number" || typeof unitCost !== "number" || quantity < 0 || unitCost < 0) { missing += 1; continue; }
    const cost = quantity * unitCost;
    amount += value - cost;
    basis += cost;
    covered += 1;
  }
  if (!covered) return { status: "unavailable", amount: null, percentage: null };
  return { status: missing ? "incomplete" : "complete", amount, percentage: basis > 0 ? amount / basis * 100 : null };
}

export type HistoricalContractGain = HistoricalGain & { missing: "contract_value" | "net_cash_flows" | "total_contributions" | "zero_contributions" | null };
export function historicalContractGain(contractValue: number | null | undefined, netCashFlows: number | null | undefined, totalContributions: number | null | undefined): HistoricalContractGain {
  if (typeof contractValue !== "number" || !Number.isFinite(contractValue))
    return { status: "unavailable", amount: null, percentage: null, missing: "contract_value" };
  if (typeof netCashFlows !== "number" || !Number.isFinite(netCashFlows))
    return { status: "unavailable", amount: null, percentage: null, missing: "net_cash_flows" };
  const amount = contractValue - netCashFlows;
  if (typeof totalContributions !== "number" || !Number.isFinite(totalContributions) || totalContributions < 0)
    return { status: "incomplete", amount, percentage: null, missing: "total_contributions" };
  if (totalContributions === 0)
    return { status: "complete", amount, percentage: null, missing: "zero_contributions" };
  return { status: "complete", amount, percentage: amount / totalContributions * 100, missing: null };
}

export type DatedCashFlow = {
  reconciled?: boolean;
  contractId: string;
  kind: "contribution" | "withdrawal";
  occurredOn: string;
  amountEur: number | null;
  amount?: number | null;
  currency?: string;
  fxRate?: number | null;
  fxRateDate?: string | null;
  fxStatus?: string | null;
};

export type CurrentCashFlowTotals = {
  id: string;
  totalContributionsEur: number;
  netCashFlowsEur: number;
  incompleteContributionFlows: number;
  incompleteNetCashFlows: number;
};

export type HistoricalNetContext = { envelopeTypeId?:string; fiscalAssignments?:unknown;
  id: string;
  fiscalRegimeId: string | null;
  fiscalStartedOn: string | null;
  fiscalHistoryComplete: boolean;
  socialContributionsPaidEur: number | null;
  usePersonalRule: boolean;
  knownLiquidationNetEur: number | null;
  knownLiquidationNetAsOf: string | null;
};

function sameMoney(left: number, right: number) {
  return Math.abs(left - right) < 0.005;
}

// Historical observations remain immutable evidence. When the current ledger
// is complete and reconciles exactly with the current aggregates, project that
// dated ledger over every observation so a retroactive create/update/delete is
// reflected from its effective civil date without rewriting the capture.
export function projectDatedCashFlows(
  points: readonly ChartPoint[],
  totals: readonly CurrentCashFlowTotals[],
  flows: readonly DatedCashFlow[],
  changes: readonly {contractId:string;kind:"contribution"|"withdrawal";occurredOn:string;emptyLedgerQualified:boolean;emptyLedgerQualifiedDates?:readonly string[]}[] = [],
) {
  const totalsByContract = new Map(totals.map((item) => [item.id, item]));
  const flowsByContract = new Map<string, DatedCashFlow[]>();
  for (const flow of flows) flowsByContract.set(flow.contractId, [...(flowsByContract.get(flow.contractId) ?? []), flow]);
  for (const change of changes) if (!flowsByContract.has(change.contractId)) flowsByContract.set(change.contractId, []);
  const emptyKnownAt=(id:string,date:string)=>changes.some(c=>c.contractId===id&&(c.emptyLedgerQualified||c.emptyLedgerQualifiedDates?.includes(date)));
  const authoritative = new Set<string>();
  for (const [contractId, contractFlows] of flowsByContract) {
    const current = totalsByContract.get(contractId);
    if (!contractFlows.length && !changes.some(c=>c.contractId===contractId&&(c.emptyLedgerQualified||c.emptyLedgerQualifiedDates?.length))) continue;
    if (!current || current.incompleteContributionFlows || current.incompleteNetCashFlows || contractFlows.some((flow) => flow.amountEur === null)) continue;
    const contributions = contractFlows.filter((flow) => flow.kind === "contribution").reduce((sum, flow) => sum + flow.amountEur!, 0);
    const withdrawals = contractFlows.filter((flow) => flow.kind === "withdrawal").reduce((sum, flow) => sum + flow.amountEur!, 0);
    if (sameMoney(contributions, current.totalContributionsEur) && sameMoney(contributions - withdrawals, current.netCashFlowsEur)) authoritative.add(contractId);
  }
  return points.map((original) => {
    const point: ChartPoint = { ...original, values: { ...original.values }, netKinds: { ...original.netKinds }, netReasons: { ...original.netReasons }, sourceNets: { ...original.sourceNets }, contributions: { ...original.contributions }, netCashFlows: { ...original.netCashFlows }, sourceContributions: { ...original.sourceContributions }, sourceNetCashFlows: { ...original.sourceNetCashFlows }, provenanceByContract: { ...original.provenanceByContract } };
    for (const [contractId, contractFlows] of flowsByContract) {
      if (authoritative.has(contractId) && (contractFlows.length || emptyKnownAt(contractId,point.date))) continue;
      const changed = [...contractFlows.filter(flow => flow.reconciled && flow.occurredOn <= point.date),...changes.filter(c=>c.contractId===contractId&&c.occurredOn<=point.date)];
      if (!changed.length) continue;
      if (changed.some(flow => flow.kind === "contribution")) {
        if (typeof original.contributions[contractId] === "number") point.sourceContributions![contractId] = original.contributions[contractId]!;
        point.contributions[contractId] = null;
      }
      if (typeof original.netCashFlows?.[contractId] === "number") point.sourceNetCashFlows![contractId] = original.netCashFlows[contractId]!;
      point.netCashFlows![contractId] = null;
      const key = `contract:${contractId}:net`;
      if (typeof original.values[key] === "number") point.sourceNets![contractId] = original.values[key]!;
      point.values[key] = null;
      point.netKinds[contractId] = "unavailable";
      point.netReasons![contractId] = "Flux rapproché : cumul EUR non réconciliable ou conversion en attente.";
      const evidence = "Flux rapproché daté · cumul source conservé, montant consulté inconnu";
      if (!point.provenanceByContract![contractId]?.includes(evidence)) point.provenanceByContract![contractId] = [point.provenanceByContract![contractId], evidence].filter(Boolean).join(" · ");
    }
    for (const contractId of authoritative) {
      if (!flowsByContract.get(contractId)?.length && (!emptyKnownAt(contractId,point.date)||!changes.some(c=>c.contractId===contractId&&c.occurredOn<=point.date))) continue;
      const dated = (flowsByContract.get(contractId) ?? []).filter((flow) => flow.occurredOn <= point.date);
      const contributions = dated.filter((flow) => flow.kind === "contribution").reduce((sum, flow) => sum + flow.amountEur!, 0);
      const withdrawals = dated.filter((flow) => flow.kind === "withdrawal").reduce((sum, flow) => sum + flow.amountEur!, 0);
      const sourceContribution = original.contributions[contractId];
      const sourceNet = original.netCashFlows?.[contractId];
      if (sourceContribution !== undefined && sourceContribution !== null && !sameMoney(sourceContribution, contributions)) point.sourceContributions![contractId] = sourceContribution;
      if (sourceNet !== undefined && sourceNet !== null && !sameMoney(sourceNet, contributions - withdrawals)) point.sourceNetCashFlows![contractId] = sourceNet;
      point.contributions[contractId] = contributions;
      point.netCashFlows![contractId] = contributions - withdrawals;
      if (point.sourceContributions![contractId] !== undefined || point.sourceNetCashFlows![contractId] !== undefined) {
        const evidence = "Flux datés recalculés · cumul source archivé conservé";
        const prior = point.provenanceByContract![contractId];
        if (!prior?.includes(evidence)) point.provenanceByContract![contractId] = [prior, evidence].filter(Boolean).join(" · ");
      }
    }
    return point;
  });
}

function historicalUnrealizedGain(point: ChartPoint, contract: ChartContract) {
  if (point.initialCashEvidence?.[contract.id]) return 0;
  const positions = contract.children.filter((child) => child.kind === "asset");
  if (!positions.length) return null;
  let gain = 0;
  for (const child of positions) {
    const quantity = point.quantities[child.id];
    if (quantity === 0) continue;
    const value = point.values[child.id];
    const unitCost = point.historicalUnitCosts?.[child.id];
    if (typeof quantity !== "number" || quantity < 0 || typeof value !== "number" || typeof unitCost !== "number" || unitCost < 0) return null;
    gain += value - quantity * unitCost;
  }
  return gain;
}

// Evidence comparison only: never computes a historical quantity, price or PRU.
export function historicalHoldingsFingerprint(point: ChartPoint, contract: ChartContract) {
  return JSON.stringify(contract.children.filter(c => c.kind === "asset").map(c =>
    [c.id, point.values[c.id] ?? null, point.quantities[c.id] ?? null, point.historicalUnitCosts?.[c.id] ?? null]
  ).sort((a,b) => String(a[0]).localeCompare(String(b[0]))));
}

function appendProvenance(point: ChartPoint, contractId: string, value: string) {
  const previous = point.provenanceByContract?.[contractId];
  (point.provenanceByContract ??= {})[contractId] = previous ? `${previous} · ${value}` : value;
}

// Missing historical nets are completed only from dated values and a verified
// rule applicable on that date. Current positions, prices and PRU never enter
// this projection. A source net already present always remains authoritative.
export function projectHistoricalNets(
  points: readonly ChartPoint[],
  contracts: readonly ChartContract[],
  contexts: readonly HistoricalNetContext[],
  rules: readonly FiscalRule[],
  userId: string,
  envelopeFiscalities?:readonly EnvelopeFiscality[],
) {
  const contextsById = new Map(contexts.map((context) => [context.id, context]));
  return points.map((original) => {
    const point: ChartPoint = { ...original, values: { ...original.values }, netKinds: { ...original.netKinds },
      netReasons: { ...original.netReasons }, provenanceByContract: { ...original.provenanceByContract }, cashNetProjection: { ...original.cashNetProjection }, titleNets:Object.fromEntries(contracts.filter(c=>c.envelopeTypeCode==='cto').flatMap(c=>c.children.filter(a=>a.kind==='asset').map(a=>[a.id,null]))),titleNetReasons:{} };
    for (const contract of contracts) {
      const key = `contract:${contract.id}:net`;
      if (envelopeFiscalities===undefined&&(point.manualGrossEvidence?.[contract.id]||point.employeeSavingsEvidence?.[contract.id])) continue;
      if(envelopeFiscalities===undefined&&contract.valuationAuthority==="global"&&["peg","per_col"].includes(contract.envelopeTypeCode??""))continue;
      if(envelopeFiscalities!==undefined){
        const context=contextsById.get(contract.id),gross=point.values[`contract:${contract.id}:gross`];
        const mode=envelopeNetMode(contract.envelopeTypeCode??'');
        if(mode==='absent'){point.values[key]=null;point.netKinds[contract.id]='unavailable';point.netReasons![contract.id]='BRUT uniquement : NET volontairement absent. [REF-NET-ABSENT]';continue;}
        if(mode==='gross'){point.values[key]=typeof gross==='number'?gross:null;point.netKinds[contract.id]=typeof gross==='number'?'calculated':'unavailable';if(typeof gross==='number')delete point.netReasons![contract.id];continue;}
        if(mode==='manual'){if(!(point.employeeSavingsEvidence?.[contract.id]||typeof point.sourceNets?.[contract.id]==='number')||typeof point.values[key]!=='number'){point.values[key]=null;point.netKinds[contract.id]='unavailable';point.netReasons![contract.id]='NET manuel qualifié à sa source et sa date requis. [REF-NET-MANUAL]';}continue;}
        if(contract.envelopeTypeCode==='cto'&&context){
          const detail=calculateEnvelopeTax(envelopeFiscalities,rules,context.envelopeTypeId??'',{calculationDate:point.date,envelopeCode:'cto',positions:contract.children.filter(c=>c.kind==='asset').map(c=>({id:c.id,grossEur:point.quantities[c.id]===0?0:point.values[c.id]??null,unrealizedGainEur:historicalUnrealizedGain(point,{...contract,children:[c]})})),openedOn:contract.openedOn,fiscalStartedOn:context.fiscalStartedOn,grossEur:gross??NaN,unrealizedGainEur:null,netCashFlowsEur:null,interestGainEur:null,socialContributionsPaidEur:0,historyComplete:context.fiscalHistoryComplete});
          for(const child of contract.children.filter(c=>c.kind==='asset')){
            const value=detail.positions?.find(p=>p.id===child.id);
            point.titleNets![child.id]=value?.netEstimatedEur??null;
            if(value?.netEstimatedEur==null)point.titleNetReasons![child.id]=value?.warnings.join(' ')||detail.warnings.join(' ')||'Détail NET non calculable. [REF-TITLE-DATA]';
          }
        }
        const estimateFirst=prefersEnvelopeEstimate(contract.envelopeTypeCode??'');
        if(!estimateFirst&&(point.manualGrossEvidence?.[contract.id]||point.employeeSavingsEvidence?.[contract.id]||(typeof point.sourceNets?.[contract.id]==='number'&&typeof point.values[key]==='number'&&point.cashProjectionBase?.[contract.id]?.netKind!=='calculated')||typeof point.sourcePropertyNets?.[contract.id]==='number'||(typeof point.values[key]==='number'&&point.netKinds[contract.id]!=='calculated')))continue;
        point.values[key]=null;point.netKinds[contract.id]='unavailable';
        if(!context||typeof gross!=='number'){point.netReasons![contract.id]=contract.openedOn&&point.date<contract.openedOn?'Date étudiée antérieure à l’ouverture du contrat. [REF-DATA]':'Valorisation BRUT datée ou contexte contractuel absent. [REF-DATA]';continue;}
        // Preserve the existing dated zero-gain capital qualification. The
        // confirmation date does not authorize extending it into the future.
        const contribution=point.contributions[contract.id],netFlow=point.netCashFlows?.[contract.id];
        if(!estimateFirst&&context.knownLiquidationNetEur!==null&&context.knownLiquidationNetAsOf!==null
          &&point.date<=context.knownLiquidationNetAsOf&&typeof contribution==='number'&&typeof netFlow==='number'
          &&sameMoney(gross,contribution)&&sameMoney(gross,netFlow)){
          point.values[key]=gross;point.netKinds[contract.id]='calculated';delete point.netReasons![contract.id];
          appendProvenance(point,contract.id,`Capital daté sans gain · net contractuel confirmé au ${context.knownLiquidationNetAsOf}`);continue;
        }
        const base=point.cashProjectionBase?.[contract.id];
        if(!estimateFirst&&base&&['legacy_estimate','approximate'].includes(base.netKind??'')){
          const selection=selectEnvelopeFiscalities(envelopeFiscalities,context.envelopeTypeId??'',point.date);
          const models=selection.rows.map(p=>p.mode==='calculated'?rules.find(r=>r.id===p.rule_id):undefined);
          let cashIndependent=false;try{cashIndependent=!selection.reason&&selection.rows.length>0&&selection.rows.every((p,i)=>{const c=commonTaxConfiguration(p.configuration,contract.envelopeTypeCode??'');const r=models[i];return c?[c.irBase,c.psBase].every(b=>b==='none'||b==='positive_unrealized_gain'):!!r&&[r.irBaseType,r.psBaseType].every(b=>b==='none'||b==='positive_unrealized_gain');});}catch{cashIndependent=false;}
          const cash=point.cash[`cash:${contract.id}`],delta=typeof cash==='number'?cash-base.cashEur:NaN;
          const assets=contract.children.filter(c=>c.kind==='asset');
          const qualified=assets.length>0&&assets.every(c=>typeof point.quantities[c.id]==='number'&&point.quantities[c.id]!>=0&&(point.quantities[c.id]===0||typeof point.values[c.id]==='number'&&point.values[c.id]!>=0));
          const corrected=Object.keys(point.holdingObservationEvidence??{}).some(k=>k.split(':')[1]===contract.id);
          const net=typeof base.netEur==='number'?base.netEur+delta:NaN;
          if(cashIndependent&&qualified&&!corrected&&typeof base.grossEur==='number'&&Number.isFinite(delta)&&Math.abs(gross-base.grossEur-delta)<1e-8&&base.holdingsFingerprint===historicalHoldingsFingerprint(point,contract)&&Number.isFinite(net)&&net>=0&&net<=gross){
            point.values[key]=net;point.netKinds[contract.id]='approximate';delete point.netReasons![contract.id];
            point.cashNetProjection![contract.id]={sourceNetEur:base.netEur!,sourceGrossEur:base.grossEur,sourceCashEur:base.cashEur,deltaEur:delta,effectiveNetEur:net,fiscalRuleVersion:models[0]?.versionNumber??selection.rows[0].revision,historicalCostsKnown:historicalUnrealizedGain(point,contract)!==null};
            appendProvenance(point,contract.id,'NET source conservé, ajusté uniquement du delta espèces qualifié ; aucun nouvel impôt appliqué au NET source.');
          }else point.netReasons![contract.id]='NET source non projetable après correction : conditions historiques insuffisantes. [REF-DATA]';
          continue;
        }
        const result=calculateEnvelopeTax(envelopeFiscalities,rules,context.envelopeTypeId??'',{calculationDate:point.date,envelopeCode:contract.envelopeTypeCode,positions:contract.children.filter(c=>c.kind==='asset').map(c=>({id:c.id,grossEur:point.quantities[c.id]===0?0:point.values[c.id]??null,unrealizedGainEur:historicalUnrealizedGain(point,{...contract,children:[c]})})),openedOn:contract.openedOn,fiscalStartedOn:context.fiscalStartedOn,grossEur:gross,unrealizedGainEur:historicalUnrealizedGain(point,contract),netCashFlowsEur:point.netCashFlows?.[contract.id]??null,interestGainEur:null,socialContributionsPaidEur:context.socialContributionsPaidEur,historyComplete:context.fiscalHistoryComplete});
        point.values[key]=result.netEstimatedEur;point.netKinds[contract.id]=result.status==='complete'?'calculated':'unavailable';
        if(result.status==='complete'){delete point.netReasons![contract.id];appendProvenance(point,contract.id,'NET consulté recalculé selon les fiscalités de l’enveloppe ; capture publiée conservée.');}else point.netReasons![contract.id]=result.warnings.join(' ');
        continue;
      }
      if (typeof point.values[key] === "number") continue;
      delete point.cashNetProjection![contract.id];
      const gross = point.values[`contract:${contract.id}:gross`];
      if (typeof gross !== "number") {
        point.netReasons![contract.id] ??= "Valorisation brute historique absente.";
        continue;
      }
      const context = contextsById.get(contract.id);
      if (!context) {
        point.netReasons![contract.id] ??= "Contexte fiscal historique indisponible.";
        continue;
      }
      const contribution = point.contributions[contract.id];
      const netCashFlow = point.netCashFlows?.[contract.id];
      const confirmedCapital = context.knownLiquidationNetEur !== null
        && context.knownLiquidationNetAsOf !== null && point.date <= context.knownLiquidationNetAsOf
        && typeof contribution === "number" && typeof netCashFlow === "number"
        && sameMoney(gross, contribution) && sameMoney(gross, netCashFlow);
      if (confirmedCapital) {
        point.values[key] = gross;
        point.netKinds[contract.id] = "calculated";
        delete point.netReasons![contract.id];
        appendProvenance(point, contract.id, `Capital daté sans gain · net contractuel confirmé au ${context.knownLiquidationNetAsOf}`);
        continue;
      }
      const archived=point.fiscalSelections?.[contract.id];
      const binding=frozenHistoricalBinding(rules,context.fiscalAssignments,point.date,userId,{regimeId:context.fiscalRegimeId,usePersonalRule:context.usePersonalRule,context:{fiscalStartedOn:context.fiscalStartedOn,historyComplete:context.fiscalHistoryComplete,socialContributionsPaidEur:context.socialContributionsPaidEur}});
      const fiscalContext=archived?.context??binding.context;
      const rule=archived?rules.find(r=>r.id===archived.ruleId)??null:binding.rule;
      if (!rule) {
        point.netReasons![contract.id] = "Aucune règle fiscale vérifiée n’est applicable à cette date.";
        continue;
      }
      const unrealizedGainEur = historicalUnrealizedGain(point, contract);
      const result = calculateFiscalEstimate(rule, {
        calculationDate: point.date,
        fiscalStartedOn: fiscalContext.fiscalStartedOn,
        grossEur: gross,
        unrealizedGainEur,
        netCashFlowsEur: typeof netCashFlow === "number" ? netCashFlow : null,
        interestGainEur: null,
        socialContributionsPaidEur: fiscalContext.socialContributionsPaidEur,
        historyComplete: fiscalContext.historyComplete,
      });
      const providedSourceNet = ["legacy_estimate", "approximate"].includes(point.cashProjectionBase?.[contract.id]?.netKind ?? "");
      if (result.netEstimatedEur === null || providedSourceNet) {
        const base = point.cashProjectionBase?.[contract.id];
        const cash = point.cash[`cash:${contract.id}`];
        const delta = typeof cash === "number" && base ? cash - base.cashEur : NaN;
        const cashIndependent = [rule.irBaseType, rule.psBaseType].every(type => type === "none" || type === "positive_unrealized_gain");
        const assets = contract.children.filter(child => child.kind === "asset");
        const holdingsQualified = assets.length > 0 && assets.every(child => {
          const quantity = point.quantities[child.id], value = point.values[child.id];
          return typeof quantity === "number" && Number.isFinite(quantity) && quantity >= 0
            && (quantity === 0 || (typeof value === "number" && Number.isFinite(value) && value >= 0));
        });
        const holdingsCorrected = Object.keys(point.holdingObservationEvidence ?? {}).some(key => key.split(":")[1] === contract.id);
        // Only a selected, usable source NET may be shifted. A legacy trace
        // rejected by its authority is not a baseline. This is not a tax estimate.
        if (cashIndependent && holdingsQualified && base && typeof base.netEur === "number"
          && base.netKind && base.netKind !== "unavailable" && typeof base.grossEur === "number"
          && Number.isFinite(delta) && Math.abs(gross - base.grossEur - delta) < 0.00000001
          && !holdingsCorrected && base.holdingsFingerprint === historicalHoldingsFingerprint(point,contract)) {
          const effectiveNet = base.netEur + delta;
          if (Number.isFinite(effectiveNet) && effectiveNet >= 0 && effectiveNet <= gross) {
            point.values[key] = effectiveNet;
            point.netKinds[contract.id] = "approximate";
            point.cashNetProjection![contract.id] = {sourceNetEur:base.netEur,sourceGrossEur:base.grossEur,sourceCashEur:base.cashEur,deltaEur:delta,effectiveNetEur:effectiveNet,fiscalRuleVersion:rule.versionNumber,historicalCostsKnown:unrealizedGainEur !== null};
            delete point.netReasons![contract.id];
            appendProvenance(point,contract.id,`NET dérivé du NET source ${base.netEur.toFixed(2)} EUR par delta espèces ${delta.toFixed(2)} EUR ; source BRUT ${base.grossEur.toFixed(2)} EUR / espèces ${base.cashEur.toFixed(2)} EUR conservée ; assiette des titres inchangée (règle v${rule.versionNumber}), ${unrealizedGainEur === null ? "coûts historiques toujours inconnus" : "coûts archivés inchangés"}`);
            continue;
          }
        }
      }
      if (result.netEstimatedEur === null) {
        const needsUnrealized = rule.irBaseType === "positive_unrealized_gain" || rule.psBaseType === "positive_unrealized_gain";
        const needsPlanGain = rule.irBaseType === "positive_plan_gain" || rule.psBaseType === "positive_plan_gain";
        point.netReasons![contract.id] = needsUnrealized && unrealizedGainEur === null
          ? "Coûts d’acquisition historiques absents : plus-value fiscale du contrat non calculable."
          : needsPlanGain && typeof netCashFlow !== "number"
            ? "Flux nets historiques absents : base fiscale du contrat non calculable."
            : needsPlanGain && !context.fiscalHistoryComplete
              ? "Complétude de l’historique fiscal non confirmée à cette date."
              : result.warnings.join(" ") || "Net fiscal historique non calculable.";
        continue;
      }
      point.values[key] = result.netEstimatedEur;
      point.netKinds[contract.id] = "calculated";
      delete point.netReasons![contract.id];
      appendProvenance(point, contract.id, `Net estimé par règle fiscale v${rule.versionNumber} · référence ${rule.id}`);
    }
    if (point.employeeSavingsCombined !== null) {
      for (const contract of contracts.filter((item) => item.sourceKey === "peg" || item.sourceKey === "per_col"))
        point.netReasons![contract.id] = "Historique commun PEG/PER non ventilé : aucune assiette nette individuelle documentée.";
    }
    return point;
  });
}

export function sourcePrefix(sourceKey: string | null) {
  if (sourceKey === "pea") return "PEA";
  if (sourceKey === "cto") return "CTO";
  return null;
}

export function resolveSelection(contracts: ChartContract[], selection: Record<string, "global" | string[]>) {
  const ids: string[] = [];
  for (const contract of contracts) {
    const selected = selection[contract.id];
    if (selected === "global") ids.push(`contract:${contract.id}`);
    else if (Array.isArray(selected)) ids.push(...selected.filter((id) => contract.children.some((child) => child.id === id)));
  }
  return [...new Set(ids)];
}

export function selectionForScope(contracts: ChartContract[], scope: "total" | "outside-real-estate") {
  return Object.fromEntries(contracts.filter((contract) => scope === "total" || contract.envelopeType !== "Immobilier").map((contract) => [contract.id, "global" as const]));
}

export function selectionForContract(contract: ChartContract, points: ChartPoint[] = []) {
  // A current position is not evidence of historical detail. Manual estimates
  // and global situations must use their archived contract observations.
  const hasContractOnlyHistory = points.some((point) => point.values[`contract:${contract.id}:gross`] != null
    && !contract.children.some((child) => child.kind === "asset" && point.values[child.id] != null));
  const hasAssetDetail = contract.valuationAuthority !== "global" && contract.children.some((child) => child.kind === "asset"
    && (isSecuritiesEnvelopeType(contract.envelopeTypeCode) || sourcePrefix(contract.sourceKey) !== null || (!hasContractOnlyHistory && child.quantified === true && points.some((point) => point.values[child.id] != null))));
  return { [contract.id]: hasAssetDetail ? contract.children.map((child) => child.id) : "global" as const };
}

export function quantifiedChild(contracts: ChartContract[], id: string) {
  return contracts.some((contract) => contract.children.some((child) => child.id === id && child.kind === "asset"
    && (child.quantified === true || isSecuritiesEnvelopeType(contract.envelopeTypeCode) || sourcePrefix(contract.sourceKey) !== null)));
}

export function historicalHoldingState(point: ChartPoint, id: string, contracts: ChartContract[]) {
  if (id === "employee-savings-combined") return point.employeeSavingsCombined == null ? "absent" : "unquantified";
  const contract = contracts.find((item) => item.id === id.split(":")[1]);
  if (contract && !isDateInContractScope(point.date, contract.openedOn)) return "absent";
  if (id.startsWith("asset:") && contract && point.initialCashEvidence?.[contract.id]) return "absent";
  if(point.propertyEvidence?.[id]?.observation?.kind==="end")return "absent";
  if (point.amountTrackedIds?.includes(id) || !quantifiedChild(contracts, id)) return "unquantified";
  const quantity = point.quantities[id];
  return typeof quantity !== "number" || !Number.isFinite(quantity) || quantity < 0 ? "unknown" : quantity > 0 ? "held" : "absent";
}

// A source-common observation replaces the selected individual contracts only
// at that date. Series identities remain stable across gross/net and transitions.
export function historicalSelectionIds(point: ChartPoint, ids: string[], contracts: ChartContract[]) {
  const employees = contracts.filter(c => c.sourceKey === "peg" || c.sourceKey === "per_col").map(c => `contract:${c.id}`);
  // A fixed employee-savings chart explicitly requests the common series as
  // context, never as that contract's individual value. Global selections keep
  // requiring both members unless this common identity was explicitly selected.
  const explicitCommonContext = ids.includes("employee-savings-combined") && employees.some(id => ids.includes(id));
  const common = point.employeeSavingsCombined != null && (explicitCommonContext || (employees.length === 2 && employees.every(id => ids.includes(id))));
  return common ? [...ids.filter(id => !employees.includes(id) && id !== "employee-savings-combined"), "employee-savings-combined"]
    : ids.filter(id => id !== "employee-savings-combined" || point.employeeSavingsCombined != null);
}

export function historicalSeriesIds(points: ChartPoint[], ids: string[], contracts: ChartContract[]) {
  return [...new Set(points.flatMap(point => historicalSelectionIds(point, ids, contracts)))];
}

// Inactivity does not erase proven history or establish a closure date.
export function contractsWithHistory(contracts: ChartContract[], points: ChartPoint[], fixedId: string | null = null) {
  return contracts.filter(c => c.isActive || c.id === fixedId || points.some(p =>
    Object.entries(p.values).some(([key,value]) => key.split(":")[1] === c.id && typeof value === "number" && Number.isFinite(value))
    || Object.entries(p.quantities).some(([key,value]) => key.split(":")[1] === c.id && typeof value === "number" && value > 0)
    || p.cash[`cash:${c.id}`] != null
    || ((c.sourceKey === "peg" || c.sourceKey === "per_col") && p.employeeSavingsCombined != null)));
}

export function visibleHistoricalSeries(ids: string[], points: ChartPoint[], contracts: ChartContract[]) {
  return ids.filter((id) => !quantifiedChild(contracts, id) || points.some((point) => historicalHoldingState(point, id, contracts) === "held"));
}

export function visibleHistoricalLegend<T extends { serie: { id: string } }>(series: T[], point: ChartPoint, contracts: ChartContract[],mode?:ChartMode) {
  const active=historicalSelectionIds(point,series.map(s=>s.serie.id),contracts);
  return series.filter(({ serie }) => active.includes(serie.id)&&["held", "unquantified"].includes(historicalHoldingState(point, serie.id, contracts))&&(!mode||(serie.id==='employee-savings-combined'?mode==='gross'&&point.employeeSavingsCombined!==null:chartValue(point,serie.id,mode)!==null)));
}

export function isDetailed(selection: Record<string, "global" | string[]>) {
  return Object.values(selection).some(Array.isArray);
}

export function lastAvailableWindow(points: ChartPoint[], days = 30) {
  return points.length <= days ? points : points.slice(-days);
}

export function chartValue(point: ChartPoint, id: string, mode: ChartMode) {
  if(mode==="net"&&point.titleNets&&id in point.titleNets)return point.titleNets[id]??null;
  const key = id.startsWith("contract:") ? `${id}:${mode}` : id;
  return point.values[key] ?? null;
}

// Full detailed selections count the declared contract once. Partial selections
// and sources without a declaration keep the exact component sum.
export function historicalSelectionTotal(point: ChartPoint, ids: string[], values: Array<number | null>, contracts: ChartContract[], mode: ChartMode) {
  let total = values.reduce<number>((sum, value) => sum + (value ?? 0), 0);
  if (mode !== "gross") return total;
  for (const [contractId, declaration] of Object.entries(point.declaredContractTotals ?? {})) {
    if (ids.includes(`contract:${contractId}`)) continue;
    const contract = contracts.find(c => c.id === contractId);
    const children = contract?.children.filter(c => c.kind === "cash" || historicalHoldingState(point, c.id, contracts) !== "absent") ?? [];
    if (!children.length || !children.every(c => ids.includes(c.id))) continue;
    const indexes = ids.flatMap((id,index) => id.split(":")[1] === contractId ? [index] : []);
    if (indexes.some(index => values[index] === null)) continue;
    total += declaration.grossEur - indexes.reduce((sum,index) => sum + (values[index] ?? 0), 0);
  }
  return total;
}

export function initialContractChartMode(contract: ChartContract, points: ChartPoint[]): ChartMode {
  return points.some((point) => chartValue(point, `contract:${contract.id}`, "net") !== null) ? "net" : "gross";
}

// A combined legacy observation replaces the individual PEG/PER observations.
// Native captures may instead contain both individual values: never add both
// representations or turn a missing member into a known zero.
export function employeeSavingsHistoryValue(point: ChartPoint, employeeIds: string[]) {
  if (point.employeeSavingsCombined !== null) return point.employeeSavingsCombined;
  const values = employeeIds.map((id) => chartValue(point, id, "gross"));
  return values.length === 2 && values.every((value) => value !== null) ? values.reduce<number>((sum, value) => sum + value!, 0) : null;
}

export function isDateInContractScope(date: string, openedOn: string | null) {
  return openedOn === null || date >= openedOn;
}

export function netQualityLabel(kind: NetQuality) {
  if (kind === "calculated") return "Net calculé";
  if (kind === "approximate") return "Net approximatif";
  if (kind === "legacy_estimate") return "Estimation legacy — hors moteur actuel";
  return "Net indisponible";
}

export function netQualitySummary(kinds: NetQuality[], complete: boolean) {
  const details = [kinds.includes("approximate") ? "contient un net approximatif" : null, kinds.includes("legacy_estimate") ? "contient une estimation legacy hors moteur actuel" : null].filter(Boolean);
  if (!complete || kinds.includes("unavailable")) return ["Net indisponible", ...details].join(" · ");
  return netQualityLabel(kinds.includes("legacy_estimate") ? "legacy_estimate" : kinds.includes("approximate") ? "approximate" : "calculated");
}

export function pointsForFixedContract(points: ChartPoint[], contract: ChartContract | null) {
  if (!contract) return [];
  const employee=["peg","per_col"].includes(contract.envelopeTypeCode??"");
  return points.filter((point) => isDateInContractScope(point.date, contract.openedOn)
    && (Object.keys(point.values).some((key) => key.includes(contract.id)) || (!employee&&point.contributions[contract.id] !== undefined)
      || ((contract.sourceKey === "peg" || contract.sourceKey === "per_col") && point.employeeSavingsCombined !== null)));
}

export function currentExposureDistribution(report: PatrimonialReport, dimension: "sector" | "geography") {
  return dimension === "sector" ? report.exposures.sectors : report.exposures.geography.countries;
}

export function withUnallocated(distribution: ReportExposureDistribution) {
  const missing = Math.max(0, distribution.denominatorEur - distribution.items.reduce((sum, item) => sum + item.amountEur, 0));
  return missing > .005 ? [...distribution.items, { id: "unallocated", name: "Non spécifié", amountEur: missing, percentage: distribution.denominatorEur ? missing / distribution.denominatorEur * 100 : null, dataDates: [], sources: [] }] : distribution.items;
}
