import { acquisitionUnitEur, acquisitionTotalEur } from "@/lib/contracts/cto-acquisition-input";
import { resolveCtoCost } from "@/lib/contracts/cto-documented-cost";
import { positionHistory, observationAt } from "@/lib/contracts/position-observations";
import type { PatrimonialReport } from "@/lib/reports/patrimonial-report-core";
import type { ChartContract, ChartPoint } from "@/lib/patrimony/chart-core";
import { isDateInContractScope, stableColor } from "@/lib/patrimony/chart-core";
import { convertToEur, latestFxRatesByCurrency, type FxRateRecord } from "@/lib/fx/fx-core";
import { parisDateFromIso } from "@/lib/cash/cash-core";

type ArchivedPosition = { metadata?:unknown; contract_id?: unknown; asset_id?: unknown; quantity?: unknown; average_cost_per_unit?: unknown; cost_currency_code?: unknown; is_active?: unknown };
function record(value: unknown): Record<string, unknown> { return value !== null && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : {}; }
function archivedAcquisitionCost(inputs: unknown, contractId: string, assetId: string, date: string) {
  const archived = record(inputs);
  const positions = Array.isArray(archived.positions) ? archived.positions as ArchivedPosition[] : [];
  const rates = [
    ...(Array.isArray(archived.currentFxRates) ? archived.currentFxRates : []),
    ...(Array.isArray(archived.historicalFxRates) ? archived.historicalFxRates : []),
  ] as FxRateRecord[];
  const byCurrency = latestFxRatesByCurrency(rates, date);
  const relevant = positions.filter((position) => position.contract_id === contractId && position.asset_id === assetId && position.is_active !== false);
  if (!relevant.length) return null;
  let total = 0;
  for (const original of relevant) {
    const ledger=positionHistory(original.metadata);const e=ledger?observationAt(ledger.entries,date):null;
    if(ledger&&!e)return null;
    const position=e?{...original,quantity:e.quantity,average_cost_per_unit:e.unitCost,cost_currency_code:e.currency}:original;
    if(position.quantity==null||position.average_cost_per_unit==null)return null;
    const quantity = Number(position.quantity), unitCost = Number(position.average_cost_per_unit);
    const currency = typeof position.cost_currency_code === "string" ? position.cost_currency_code : "";
    if (!Number.isFinite(quantity) || quantity < 0 || !Number.isFinite(unitCost) || unitCost < 0 || !currency) return null;
    const cost = resolveCtoCost({metadata:original.metadata, observation:e, native:position.average_cost_per_unit as string|number,
      currency, day:date, quantity, legacyUnit:convertToEur(unitCost,currency,byCurrency.get(currency)).amountEur});
    const acquired = acquisitionUnitEur(original.metadata, position.average_cost_per_unit as string | number, currency, date);
    const archivedCost = acquired === undefined ? convertToEur(quantity * unitCost, currency, byCurrency.get(currency)).amountEur :
      acquisitionTotalEur(original.metadata, position.average_cost_per_unit as string | number, currency, date, quantity) ?? null;
    const amount = cost.documented ? cost.total : archivedCost;
    if (amount === null) return null;
    total += amount;
  }
  return total;
}

export function extendHistoricalInventory(contracts: ChartContract[], captures: Array<{ report: PatrimonialReport }>) {
  const result = contracts.map((contract) => ({ ...contract, children: [...contract.children] }));
  for (const capture of captures) for (const asset of capture.report.assets ?? []) {
    for (const holding of asset.holdings ?? []) {
      const contract = result.find((item) => item.id === holding.contractId);
      const id = `asset:${holding.contractId}:${asset.id}`;
      if (!contract || contract.children.some((child) => child.id === id)) continue;
      contract.children.push({ id, kind: "asset", assetId: asset.id, symbol: asset.symbol,
        label: asset.name, valueEur: contract.valuationIncomplete ? null : 0,
        color: asset.color ?? stableColor(`asset:${asset.id}`),
        colorAutomatic: asset.color === null || asset.colorOrigin === "automatic" });
    }
  }
  return result;
}

// Only data archived with this capture may populate a historical child. The
// current holdings/PRU must never be used to fill missing historical values.
export function applyCapturedChartPoint(point: ChartPoint, report: PatrimonialReport, contracts: ChartContract[], inputs?: unknown) {
  for (const contract of report.contracts) {
    if(contract.fiscalSelection)(point.fiscalSelections??={})[contract.id]=contract.fiscalSelection;
    const metadata = contracts.find((item) => item.id === contract.id);
    if (!metadata || !isDateInContractScope(point.date, metadata.openedOn)) continue;
    // A capture copying a dated manual situation is not a new observation.
    if (contract.manualSituationAt) for (const id of [`contract:${contract.id}`, ...metadata.children.map(c => c.id)])
      (point.valuationSourceDates ??= {})[id] = parisDateFromIso(contract.manualSituationAt);
    point.values[`contract:${contract.id}:gross`] = contract.incompletePositions || contract.incompleteCashBalances ? null : contract.grossEur;
    point.values[`contract:${contract.id}:net`] = contract.netEstimatedEur;
    point.netKinds[contract.id] = contract.netKind ?? "unavailable";
    // A calculated-quality NET can still be an explicit contract source, not
    // a tax estimate. Qualify it from the exact copied inputs, never its label
    // or a warning string. Subsequent holding/cash corrections clear the NET.
    const archivedInputs = record(inputs);
    const archivedContract = (Array.isArray(archivedInputs.contracts) ? archivedInputs.contracts : [])
      .map(record).find(row => row.id === contract.id);
    const sourceNet = record(archivedContract?.metadata).knownLiquidationNetEur;
    if ((typeof sourceNet === "number" || typeof sourceNet === "string" && sourceNet.trim() !== "")
      && Number.isFinite(Number(sourceNet)) && Number(sourceNet) >= 0
      && (Number(sourceNet) === contract.netEstimatedEur || metadata.envelopeTypeCode==='assurance_vie'&&archivedInputs.fiscalConsultationPolicy===2)
      && point.values[`contract:${contract.id}:gross`] !== null)
      { (point.sourceNets ??= {})[contract.id] = Number(sourceNet);
        const sourceDate=record(archivedContract?.metadata).knownLiquidationNetAsOf;
        (point.sourceNetDates??={})[contract.id]=typeof sourceDate==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(sourceDate)?sourceDate:null;
      }
    if (contract.netEstimatedEur === null && contract.fiscalWarnings?.length)
      (point.netReasons ??= {})[contract.id] = contract.fiscalWarnings.join(" ");
    if (metadata.envelopeTypeCode === "immobilier") {
      (point.sourcePropertyNets ??= {})[contract.id] = contract.netEstimatedEur;
      point.values[`contract:${contract.id}:net`] = point.values[`contract:${contract.id}:gross`];
      point.netKinds[contract.id] = point.values[`contract:${contract.id}:gross`] === null ? "unavailable" : "calculated";
    }
    point.cash[`cash:${contract.id}`] = contract.incompleteCashBalances ? null : contract.cashEur;
    point.values[`cash:${contract.id}`] = point.cash[`cash:${contract.id}`];
    point.contributions[contract.id] = contract.incompleteContributionFlows || contract.contractGain?.missing==="total_contributions" || contract.contractGain?.missing==="net_cash_flows" ? null : contract.totalContributionsEur;
    (point.netCashFlows ??= {})[contract.id] = contract.incompleteNetCashFlows || contract.contractGain?.missing==="net_cash_flows" ? null : contract.netCashFlowsEur;
    for (const child of metadata.children.filter((item) => item.kind === "asset")) {
      const holdings = report.assets?.find((asset) => asset.id === child.assetId)?.holdings.filter((holding) => holding.contractId === contract.id) ?? [];
      // A complete archived inventory proves absence; a missing inventory does not.
      const absent = Array.isArray(report.assets) && !holdings.length && contract.incompletePositions === 0;
      const value = absent ? 0 : holdings.length && holdings.every((holding) => holding.valueEur !== null) ? holdings.reduce((sum, holding) => sum + holding.valueEur!, 0) : null;
      const amountTracked=holdings.some(h=>h.valueSemantics==="total_amount");
      if(amountTracked)point.amountTrackedIds=[...(point.amountTrackedIds??[]),child.id];
      const quantity = amountTracked?null:absent ? 0 : holdings.length && holdings.every(h=>h.quantity!==null) ? holdings.reduce((sum, holding) => sum + holding.quantity!, 0) : null;
      const reportedCost = holdings.length && holdings.every((holding) => holding.acquisitionCostEur !== null) ? holdings.reduce((sum, holding) => sum + holding.acquisitionCostEur!, 0) : null;
      const cost = amountTracked?null:absent ? 0 : reportedCost ?? archivedAcquisitionCost(inputs, contract.id, child.assetId!, point.date);
      point.values[child.id] = value;
      point.quantities[child.id] = quantity;
      (point.historicalUnitCosts ??= {})[child.id] = absent ? 0 : quantity !== null && quantity > 0 && cost !== null ? cost / quantity : null;
    }
  }
  return point;
}
