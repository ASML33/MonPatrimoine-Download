import { formatMoney } from "@/lib/cash/money";
import { downloadPrivate } from "@/lib/exports/download";
export type HistoryExport = {
 plotTop?:number;plotBottom?:number;document?:boolean;verticalLegend?:boolean;scope:string;markup:string;left:number;visibleWidth:number;chartHeight:number;mode:"gross"|"net";
 dates:{date:string;x:number}[];series:{label:string;color:string;dashed?:boolean;line?:boolean}[];coverage:string;limits:string[];
 background:string;foreground:string;muted:string;maximum:number;
};
export const xml=(s:string)=>s.replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;");
export function exportDateTicks(dates:HistoryExport["dates"],left:number,width:number,count=6){
 const visible=dates.filter(d=>d.x>=left&&d.x<=left+width);
 if(visible.length<=count)return visible;
 return [...new Set(Array.from({length:count},(_,i)=>Math.round(i*(visible.length-1)/(count-1))))].map(i=>visible[i]);
}
export function wrapExportText(text:string,characters:number){
 const lines:string[]=[];let line="";
 for(const word of text.split(/\s+/)){if(line&&line.length+word.length+1>characters){lines.push(line);line="";}let remaining=word;while(remaining.length>characters){if(line){lines.push(line);line="";}lines.push(remaining.slice(0,characters));remaining=remaining.slice(characters);}line+=(line?" ":"")+remaining;}if(line)lines.push(line);return lines;
}
export function historyExportSvg(m:HistoryExport){
 const scale=m.document?1.7:1;
 const scopeLines=wrapExportText("Périmètre : "+m.scope,Math.floor(135/scale));
 const w=1600,plotX=150,plotY=120*scale+scopeLines.length*25*scale,plotW=1390,plotH=460;
 const ticks=exportDateTicks(m.dates,m.left,m.visibleWidth,m.document?5:6);
 const period=ticks.length?`${ticks[0].date} — ${ticks.at(-1)!.date}`:"Aucune observation dans la fenêtre";
 const columns=m.verticalLegend?1:3;
 const legend=m.series.map(s=>({...s,lines:wrapExportText(s.label,Math.floor((m.verticalLegend?130:40)/scale))}));
 let legendY=plotY+460+60*scale;const legendRows:string[]=[];
 for(let i=0;i<legend.length;i+=columns){const group=legend.slice(i,i+columns),rowHeight=Math.max(...group.map(s=>s.lines.length))*24*scale+22*scale;
  group.forEach((s,j)=>{const x=65+j*510;legendRows.push((s.dashed||s.line)?`<line x1="${x}" x2="${x+20}" y1="${legendY-7}" y2="${legendY-7}" stroke="${xml(s.color)}" stroke-width="3"${s.dashed?' stroke-dasharray="5 3"':''}/>`:`<rect x="${x}" y="${legendY-15}" width="16" height="16" fill="${xml(s.color)}"/>`);s.lines.forEach((line,n)=>legendRows.push(`<text x="${x+26}" y="${legendY+n*24*scale}" font-size="${18*scale}">${xml(line)}</text>`));});legendY+=rowHeight;
 }
 const notes=[m.coverage,...m.limits].flatMap(text=>wrapExportText(text,Math.floor(140/scale)));const noteY=legendY+20*scale;
 const height=noteY+notes.length*24*scale+36*scale;
 const dateLabel=(d:string)=>d.split("-").reverse().join("/");
 const money=(value:number)=>formatMoney(value,"EUR");
 return `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${height}" viewBox="0 0 ${w} ${height}"><rect width="100%" height="100%" fill="${xml(m.background)}"/><g fill="${xml(m.foreground)}" font-family="Arial, sans-serif"><text x="65" y="${45*scale}" font-size="${28*scale}" font-weight="bold">Historique patrimonial · ${m.mode==="gross"?"BRUT":"NET"} · EUR</text><text x="65" y="${80*scale}" font-size="${20*scale}">Fenêtre visible : ${xml(period)} · Europe/Paris</text>${scopeLines.map((line,i)=>`<text x="65" y="${108*scale+i*25*scale}" font-size="${18*scale}">${xml(line)}</text>`).join("")}<svg x="${plotX}" y="${plotY}" width="${plotW}" height="${plotH}" viewBox="${m.left} 0 ${m.visibleWidth} ${m.chartHeight}" preserveAspectRatio="none" overflow="hidden">${m.markup}</svg>${[0,.25,.5,.75,1].map(t=>`<text x="135" text-anchor="end" y="${plotY+plotH*(1-((m.plotBottom??36)+t*(m.chartHeight-(m.plotTop??36)-(m.plotBottom??36)))/m.chartHeight)+6}" font-size="${17*scale}" fill="${xml(m.muted)}">${money(m.maximum*t)}</text>`).join("")}${ticks.map((d,i)=>`<text x="${plotX+(d.x-m.left)/m.visibleWidth*plotW}" y="${plotY+plotH+26*scale}" text-anchor="${i===0?"start":i===ticks.length-1?"end":"middle"}" font-size="${17*scale}">${dateLabel(d.date)}</text>`).join("")}${legendRows.join("")}${notes.map((line,i)=>`<text x="65" y="${noteY+i*24*scale}" font-size="${17*scale}" fill="${xml(m.muted)}">${xml(line)}</text>`).join("")}</g></svg>`;
}
export async function svgPng(svg:string,mime:"image/png"|"image/jpeg"="image/png"){
 const url=URL.createObjectURL(new Blob([svg],{type:"image/svg+xml;charset=utf-8"}));
 try{const image=new Image();image.src=url;await image.decode();const canvas=document.createElement("canvas");canvas.width=image.width*2;canvas.height=image.height*2;const context=canvas.getContext("2d");if(!context)throw new Error("Canvas indisponible");context.fillStyle="#ffffff";context.fillRect(0,0,canvas.width,canvas.height);context.drawImage(image,0,0,canvas.width,canvas.height);const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error("Image indisponible")),mime,.97));return {bytes:new Uint8Array(await blob.arrayBuffer()),width:canvas.width,height:canvas.height,type:mime==="image/jpeg"?"jpg" as const:"png" as const};}finally{URL.revokeObjectURL(url);}
}

export async function downloadHistoryPng(model:HistoryExport){
 const image=await svgPng(historyExportSvg(model));const dates=exportDateTicks(model.dates,model.left,model.visibleWidth);
 downloadPrivate(image.bytes,`monpatrimoine-historique-${model.mode}-${dates[0]?.date??"vide"}-${dates.at(-1)?.date??"vide"}.png`,"image/png");
}
