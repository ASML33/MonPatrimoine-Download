const allowedCodes = new Set(["42501", "57014", "42P01", "PGRST001", "PGRST002", "PGRST003", "PGRST106", "PGRST116", "PGRST205", "PGRST301", "PGRST302"]);

// Never copy upstream messages, details, hints, URLs, identities or Auth data.
export function historyReadDiagnostic(kind: "daily" | "legacy", page: number, size: number, elapsedMs: number, result: {status?: number; error: unknown}) {
  const candidate = result.error && typeof result.error === "object" && "code" in result.error ? result.error.code : null;
  const status = typeof result.status === "number" && Number.isInteger(result.status) && (result.status === 0 || result.status >= 400 && result.status <= 599) ? result.status : null;
  return {kind, page, size, elapsedMs:Math.max(0, Math.round(elapsedMs)),
    status, code:typeof candidate === "string" && allowedCodes.has(candidate) ? candidate : "unknown",
    timestamp:new Date().toISOString(),
  };
}
