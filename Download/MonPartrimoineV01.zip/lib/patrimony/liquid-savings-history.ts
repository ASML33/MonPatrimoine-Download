import { liquidSavingsTotalAt, type DatedBalance } from '@/lib/cash/dated-balances';
import type { HistoricalObservation } from './historical-observations';

// Read projection only: source captures and approved corrections remain intact.
export function projectLiquidSavingsObservation(row:HistoricalObservation,ids:readonly string[],balances:readonly DatedBalance[]):HistoricalObservation {
  let delta=0,changed=false;
  const contracts=row.result.report.contracts.map(contract=>{
    if(!ids.includes(contract.id))return contract;
    const amount=liquidSavingsTotalAt(balances,contract.id,row.business_date);
    if(amount===null)return contract;
    if(!Number.isFinite(contract.grossEur))throw new Error('Base historique indisponible pour la correction');
    delta+=amount-contract.grossEur;changed=true;
    return {...contract,grossEur:amount,netEstimatedEur:amount,legacyNetUsable:true,netKind:'calculated' as const,fiscalWarnings:[...contract.fiscalWarnings,'Solde total EUR daté projeté ; capture et source précédentes conservées.']};
  });
  if(!changed)return row;
  const summary=row.result.report.summary;
  return {...row,result:{...row.result,report:{...row.result.report,contracts,summary:{...summary,grossEur:summary.grossEur===null?null:summary.grossEur+delta}}}};
}
