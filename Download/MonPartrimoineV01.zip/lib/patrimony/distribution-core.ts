import { formatMoney } from "@/lib/cash/money";
export type DistributionItem = { id: string; amount: number | null };
// Presentation evidence only: an unknown financial amount is never a slice.
export type DistributionExplanation = { id: string; name: string; reason: string; inDonut: boolean };

// Compensated addition prevents a complete decimal publication (100.00%)
// producing a spurious residual through binary addition. No cutoff is applied.
export function exposureWeightTotal(weights: number[]) {
  let total = 0, correction = 0;
  for (const weight of weights) {
    const adjusted = weight - correction, next = total + adjusted;
    correction = (next - total) - adjusted;
    total = next;
  }
  return total;
}

export function distributionPercentageLabel(value: number | null, positive = false) {
  if (value === null) return "Indisponible";
  if (positive && value < .005) return "< 0,01 %";
  return new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 2 }).format(value) + " %";
}

export function distributionAmountLabel(value: number | null) {
  if (value === null) return "Indisponible";
  if (value > 0 && value < .005) return "< 0,01 €";
  return formatMoney(value, "EUR");
}

type DisplaySlice = { id: string; name: string; amount: number | null; unspecified?: boolean; dataDates?: string[]; sources?: string[] };
// Presentation only: technical categories and their provenance remain intact
// in the underlying result. Each input contributes once to the displayed part.
export function groupUnspecifiedSlices<T extends DisplaySlice>(items: T[]): T[] {
  const unspecified = items.filter(item => item.unspecified || item.id === "unallocated" || item.id.endsWith(":unallocated"));
  if (!unspecified.length) return items;
  const merged = { ...unspecified[0], id: "display:unspecified", name: "Non spécifié", unspecified: true,
    amount: unspecified.some(item => item.amount === null) ? null : unspecified.reduce((sum,item) => sum + item.amount!, 0),
    ...(unspecified.some(item => item.dataDates) ? {dataDates:[...new Set(unspecified.flatMap(item => item.dataDates ?? []))].sort()} : {}),
    ...(unspecified.some(item => item.sources) ? {sources:[...new Set(unspecified.flatMap(item => item.sources ?? []))]} : {}),
  } as T;
  return items.flatMap(item => unspecified.includes(item) ? item === unspecified[0] ? [merged] : [] : [item]);
}

// Largest remainders in hundredths of a percent. Ties use stable identities,
// so input ordering and aliases cannot change the rounding allocation.
export function roundedPercentages(items: DistributionItem[]): Map<string, number> | null {
  if (!items.length || items.some((item) => item.amount === null || !Number.isFinite(item.amount) || item.amount < 0)) return null;
  const total = items.reduce((sum, item) => sum + item.amount!, 0);
  if (total <= 0 || !Number.isFinite(total)) return null;
  const rows = items.map((item) => {
    const exact = item.amount! / total * 10000;
    return { id: item.id, units: Math.floor(exact), remainder: exact - Math.floor(exact), positive: item.amount! > 0 };
  });
  const remaining = 10000 - rows.reduce((sum, row) => sum + row.units, 0);
  const ranked = rows.filter((row) => row.positive).sort((a, b) => b.remainder - a.remainder || a.id.localeCompare(b.id, "en"));
  for (let index = 0; index < remaining; index++) ranked[index % ranked.length].units++;
  return new Map(rows.map((row) => [row.id, row.units / 100]));
}

export type ColoredItem = { id: string; color: string; automatic?: boolean };
const PALETTE = ["#D6A84F", "#5B9BD5", "#70AD47", "#8064A2", "#ED7D31", "#46B8B0", "#C55A72", "#9E7B5B", "#7F8C8D", "#A5A5A5"];

export function distinctAutomaticColors<T extends ColoredItem>(items: T[]): T[] {
  // User/legacy colors are protected. Only colors
  // known to be generated for this rendering are eligible for replacement.
  const used = new Set(items.filter((item) => !item.automatic).map((item) => item.color.toUpperCase()));
  const assigned = new Map<string, string>();
  for (const item of items.filter((item) => item.automatic).sort((a, b) => a.id.localeCompare(b.id, "en"))) {
    let color = item.color.toUpperCase();
    let index = 0;
    while (used.has(color)) {
      color = index < PALETTE.length ? PALETTE[index] : `#${((index * 2654435761) >>> 0).toString(16).padStart(6, "0").slice(-6).toUpperCase()}`;
      index++;
    }
    used.add(color);
    assigned.set(item.id, color);
  }
  return items.map((item) => ({ ...item, color: assigned.get(item.id) ?? item.color }));
}

export function distributionState(items: DistributionItem[]): string | null {
  if (items.some((item) => item.amount === null || !Number.isFinite(item.amount))) return "Répartition indisponible : une valorisation indispensable manque.";
  if (items.some((item) => item.amount! < 0)) return "Répartition indisponible : des valeurs négatives ne peuvent pas être représentées en donut.";
  if (!items.length || items.every((item) => item.amount === 0)) return "Aucune répartition : le total de cette sélection est nul ou indisponible.";
  return null;
}

export function historyPercentages(series: Array<{ id: string }>, values: Array<number | null>) {
  return roundedPercentages(series.flatMap((item, index) => item.id.startsWith("cash:") ? [] : [{ id: item.id, amount: values[index] }]));
}

// Tooltip-only NET shares. The caller supplies the actually displayed known
// series, including cash when selected; this never changes financial totals.
export function knownNetHistoryPercentages(items: DistributionItem[]) {
  const known = items.filter((item): item is { id: string; amount: number } =>
    typeof item.amount === 'number' && Number.isFinite(item.amount));
  const total = known.reduce((sum, item) => sum + item.amount, 0);
  if (!known.length || total <= 0 || !Number.isFinite(total)) return null;
  if (known.every(item => item.amount >= 0)) return roundedPercentages(known);
  const percentages = known.map(item => [item.id, item.amount / total * 100] as const);
  return percentages.every(([, value]) => Number.isFinite(value)) ? new Map(percentages) : null;
}

// Shared sector geometry for the interactive donut and private document export.
export function donutArcs<T extends {id:string;amount:number|null}>(slices:T[]){
 const total=slices.reduce((sum,item)=>sum+item.amount!,0);const n=(v:number)=>Number(v.toFixed(6));
 return slices.map((slice,index)=>{
  const start=-90+slices.slice(0,index).reduce((sum,item)=>sum+item.amount!/total*360,0),span=slice.amount!/total*360,end=start+span;
  const point=(degree:number)=>{const rad=degree*Math.PI/180;return [n(50+40*Math.cos(rad)),n(50+40*Math.sin(rad))];};
  const [x1,y1]=point(start),[x2,y2]=point(end),middle=(start+span/2)*Math.PI/180;
  return {...slice,path:span>=359.999999?"M 50 10 A 40 40 0 1 1 50 90 A 40 40 0 1 1 50 10 Z":`M 50 50 L ${x1} ${y1} A 40 40 0 ${span>180?1:0} 1 ${x2} ${y2} Z`,dx:n(Math.cos(middle)*3),dy:n(Math.sin(middle)*3)};
 });
}
