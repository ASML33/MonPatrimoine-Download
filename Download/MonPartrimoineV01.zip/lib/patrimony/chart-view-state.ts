import type { ChartContract, ChartMode, ChartPoint } from './chart-core';

// Choices only, held by the existing session wrapper. No financial values/storage.
export type ChartViewState = {
  selectedDate: string | null;
  historyLegendClosed?: boolean;
  selection: Record<string, 'global' | string[]>;
  requestedMode: ChartMode;
  globalCtoNet: boolean;
  geographyRegions: boolean;
};

export function restoreChartSelection(selection: ChartViewState['selection'], contracts: Pick<ChartContract, 'id' | 'children'>[]) {
  return Object.fromEntries(Object.entries(selection).flatMap(([id, selected]) => {
    const contract = contracts.find(c => c.id === id);
    if (!contract) return [];
    return [[id, selected === 'global' ? selected : selected.filter(child => contract.children.some(c => c.id === child))]];
  })) as ChartViewState['selection'];
}

// A missing selected date must never fall back silently to the latest one.
export function selectedHistoryPoint(points: ChartPoint[], selectedDate: string | null) {
  return selectedDate ? points.find(p => p.date === selectedDate) ?? null : points.at(-1) ?? null;
}
