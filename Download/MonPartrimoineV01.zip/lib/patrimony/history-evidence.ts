import { positionHistory,observationAt } from "@/lib/contracts/position-observations";
import type { HistoryEvidence } from "./history-csv";
import type { ChartContract,ChartPoint } from "./chart-core";
import { selectHistoricalObservations,type HistoricalObservation,type HistoricalSource } from "./historical-observations";
import { selectDatedBalances } from "@/lib/cash/dated-balances";
import { convertToEur,latestFxRatesByCurrency } from "@/lib/fx/fx-core";
import { selectLatestPositionSnapshots,selectLatestUsablePrices } from "./current-valuation-core";
import { appliedCtoBrokerEvidence } from "./cto-broker-history";
import type { PatrimonialReportRecords } from "@/lib/reports/patrimonial-report-core";
const fxProof=(r:import("@/lib/fx/fx-core").FxRateRecord|undefined)=>r?{currency:r.currency_code,requestedOn:r.requested_on,observedOn:r.observed_on,eurPerUnit:r.eur_per_unit,source:r.source,obtainedAt:r.obtained_at??null}:null;
const finite=(v:unknown)=>v!==null&&v!==undefined&&v!==""&&Number.isFinite(Number(v))?Number(v):null;
// Whitelisted archived inputs only. Never send capture payloads to the browser.
export function historyEvidence(points:ChartPoint[],contracts:ChartContract[],observations:HistoricalObservation[],sources:HistoricalSource[]):HistoryEvidence[]{
 const selected=new Map(selectHistoricalObservations(observations).map(x=>[x.date,x.selected]));
 return points.flatMap(point=>{
  const row=selected.get(point.date);if(!row)return [];
  const inputs=row.inputs as Partial<PatrimonialReportRecords>|undefined;
  const native=row.result.engineVersion==="patrimony-history-v1";
  const prices=selectLatestUsablePrices(inputs?.assets??[],inputs?.prices??[],row.captured_at);
  const snapshots=selectLatestPositionSnapshots(inputs?.positionSnapshots??[],row.captured_at);
  const fx=latestFxRatesByCurrency([...(inputs?.currentFxRates??[]),...(inputs?.historicalFxRates??[])],point.date);
  return contracts.flatMap(contract=>{
   // A read projection can share a calendar day with somebody else's capture.
   // That capture is not evidence for the newly introduced contract.
   if((point.continuityEvidence?.[contract.id]||point.amountTrackedIds?.some(id=>id.split(':')[1]===contract.id))&&!row.result.report.contracts.some(c=>c.id===contract.id))return [];
   if(!Object.keys(point.values).some(k=>k.includes(contract.id))&& !((contract.sourceKey==="peg"||contract.sourceKey==="per_col")&&point.employeeSavingsCombined!==null))return [];
   const declared=point.declaredContractTotals?.[contract.id];
   const sourceHash=(row.inputs as {sourceSha256?:string})?.sourceSha256;
   const roots=sources.filter(s=>s.business_date===point.date&&s.source_sha256===sourceHash&&s.payload.kind!=="approved_contract_correction"&&s.payload.kind!=="user_position_valuation_confirmation");
   const source=declared?sources.find(s=>s.id===declared.sourceId):roots.length===1?roots[0]:undefined;
   const proof:HistoryEvidence={date:point.date,contractId:contract.id,captureId:row.id,revision:row.revision,capturedAt:row.captured_at,sourceTime:null,timePrecision:"date",sourceId:source?.id??null};
   const broker=contract.envelopeTypeCode==='cto'?appliedCtoBrokerEvidence(point,contract.id):null;
   if(broker){
    // The capture is an archived comparison, not evidence for the corrected
    // native cost/quote. Do not export its contradicted PRU or cash as current.
    const reconciled:HistoryEvidence={...proof,sourceId:broker.sourceId,detailStatus:`Reconstruction courtier ${broker.sourceSha256} ; coût EUR estimé aux références historiques ; capture conservée pour comparaison, anciens PRU/cours natifs non attribués à la reconstruction.`};
    return [reconciled,...contract.children.filter(c=>c.kind==='asset').map(child=>({...reconciled,assetId:child.assetId,quantityNative:point.quantities[child.id]??null,unitCostNative:null,priceNative:null,valueNative:point.values[child.id]??null,valueCurrency:'EUR'}))];
   }
   if(native&&!declared){proof.sourceTime=row.captured_at;proof.timePrecision="capture";}
   if(declared){proof.cash=[{id:source?.id??declared.sourceId,amount:point.cash[`cash:${contract.id}`]!,currency:"EUR",eur:point.cash[`cash:${contract.id}`]!,asOf:point.date,fx:null}];proof.detailStatus="Correction manuelle datée : coûts, cours natifs et FX historiques inconnus.";}
   else if(native&&!point.cashProjectionBase?.[contract.id]){
    const balances=selectDatedBalances(inputs?.cashBalances??[],row.captured_at).filter(b=>b.contract_id===contract.id);
    const details=balances.map(b=>({id:b.id,amount:Number(b.amount),currency:b.currency_code,eur:convertToEur(b.amount,b.currency_code,fx.get(b.currency_code)).amountEur,asOf:b.as_of,fx:b.currency_code==="EUR"?null:fxProof(fx.get(b.currency_code))}));
    const sum=details.length&&details.every(b=>b.eur!==null)?details.reduce((s,b)=>s+b.eur!,0):null;
    if(sum!==null&&typeof point.cash[`cash:${contract.id}`]==="number"&&Math.abs(sum-point.cash[`cash:${contract.id}`]!)<.000001)proof.cash=details;
   }else if(point.cashProjectionBase?.[contract.id])proof.detailStatus="Solde EUR corrigé selon le lecteur daté ; ancienne ventilation native archivée non présentée comme effective.";
   const result=[proof];
   for(const child of contract.children.filter(c=>c.kind==="asset")){
    const asset=(inputs?.assets??[]).find(a=>a.id===child.assetId) as (PatrimonialReportRecords["assets"][number]&{isin?:string})|undefined;
    const item:HistoryEvidence={...proof,assetId:child.assetId,isin:asset?.isin??null,cash:undefined};
    const pe=point.propertyEvidence?.[child.id];
    if(pe){item.property=pe;item.quantityNative=undefined;item.unitCostNative=null;item.valueNative=pe.observation?.origin==="manual"&&pe.observation.kind==="valuation"?Number(pe.observation.amount):point.values[child.id]??null;item.valueCurrency=pe.observation?.origin==="manual"?pe.observation.currency:"EUR";item.detailStatus=`Valeur totale immobilière, contrat source ${pe.sourceContractId}; quantité/PRU/cours non applicables`;result.push(item);continue;}
    const reconciled=point.amountReconciliationEvidence?.[child.id];
    if(reconciled){item.quantityNative=null;item.unitCostNative=null;item.priceNative=null;item.valueNative=Number(reconciled.amount);item.valueCurrency=reconciled.currency;item.sourceTime=reconciled.valuedAt;item.timePrecision="date";item.fx=reconciled.currency!=="EUR"&&fx.has(reconciled.currency)?[fxProof(fx.get(reconciled.currency))]:[];item.detailStatus="Valorisation totale source conservée ; quantité, PRU et prix d’essai non applicables. Capture originale distincte.";result.push(item);continue;}
    const replacement=point.holdingObservationEvidence?.[child.id];
    if(replacement){const e=replacement.observation;item.observation=e??undefined;item.correctionId=replacement.correctionId;item.unitCostNative=e?.unitCost==null?null:Number(e.unitCost);item.costCurrency=e?.currency;item.quantityNative=replacement.quantity;item.priceNative=replacement.price?Number(replacement.price.price):null;item.priceCurrency=replacement.price?.currency_code;item.priceAt=replacement.price?.observed_at;item.priceSource=replacement.price?.source_name;item.valueNative=replacement.price&&replacement.quantity!==null?replacement.quantity*Number(replacement.price.price):null;item.valueCurrency=replacement.price?.currency_code;item.fx=replacement.fx.map(f=>fxProof(f));item.detailStatus=replacement.reason||"Observation confirmée, capture source conservée";result.push(item);continue;}

    if(native&&!declared&&!(point.provenanceByContract?.[contract.id]??"").includes("Confirmation utilisateur")){
     const positions=(inputs?.positions??[]).filter(p=>p.contract_id===contract.id&&p.asset_id===child.assetId);
     const position=positions.length===1?positions[0]:undefined;const price=prices.get(child.assetId!);
     if(position){const h=positionHistory(position.metadata);item.observation=h?observationAt(h.entries,point.date)??undefined:undefined;item.unitCostNative=item.observation?finite(item.observation.unitCost):h?null:finite(position.average_cost_per_unit);item.costCurrency=item.observation?.currency??(h?undefined:position.cost_currency_code);item.quantityNative=item.observation?finite(item.observation.quantity):h?null:finite(position.quantity);}
     if(price){item.priceNative=finite(price.price);item.priceCurrency=price.currency_code;item.priceAt=price.observed_at;item.priceSource=price.source_name;}
     const archivedSnapshot=position&&!positionHistory(position.metadata)?snapshots.get(position.id):undefined;
     const value=archivedSnapshot?finite(archivedSnapshot.market_value):position&&price&&item.quantityNative!==null?Number(item.quantityNative)*Number(price.price):null;
     const currency=archivedSnapshot?.currency_code??price?.currency_code;
     if(value!==null&&currency){const eur=convertToEur(value,currency,fx.get(currency)).amountEur;if(eur!==null&&typeof point.values[child.id]==="number"&&Math.abs(eur-point.values[child.id]!)<.000001){item.valueNative=value;item.valueCurrency=currency;}}
     item.fx=[...new Set([item.costCurrency,item.priceCurrency,item.valueCurrency])].flatMap(c=>c&&c!=="EUR"&&fx.has(c)?[fxProof(fx.get(c))!]:[]);
    }
    result.push(item);
   }
   return result;
  });
 });
}
