import { historicalSelectionIds,chartValue,historicalSelectionTotal,historicalHoldingState,netQualitySummary,type ChartContract,type ChartPoint,type ChartMode,type NetQuality } from "./chart-core";
export type HistorySeries={id:string;label:string;color:string};
// Expand only the real-estate contract's presentation. The stored selection,
// values, CSV and other envelope types keep their existing authority.
export function historyPresentationIds(contract:ChartContract|null,ids:string[]){
 if(contract?.envelopeTypeCode!=="immobilier"||!ids.includes(`contract:${contract.id}`))return ids;
 const children=contract.children.map(child=>child.id);
 return children.length?[...ids.filter(id=>id!==`contract:${contract.id}`),...children]:ids;
}
export function historicalRows(points:ChartPoint[],series:HistorySeries[],contracts:ChartContract[],mode:ChartMode,selectedIds:string[]=series.map(item=>item.id)){
  const propertyStarts=new Map(contracts.filter(c=>c.envelopeTypeCode==="immobilier").flatMap(c=>c.children.filter(ch=>ch.kind==="asset").map(ch=>{
    const first=points.filter(p=>p.values[ch.id]!=null||p.propertyEvidence?.[ch.id]?.observation?.kind==="valuation").map(p=>p.date).sort()[0];
    return [ch.id,first] as const;
  })));
  return points.map((point) => {
    // No current property value is projected before its first documented
    // presence. Later missing financial observations remain unknown.
    const activeIds = historicalSelectionIds(point, selectedIds, contracts).filter(id=>!propertyStarts.get(id)||point.date>=propertyStarts.get(id)!);
    const values = series.map((item) => {
      const holding = historicalHoldingState(point, item.id, contracts);
      return !activeIds.includes(item.id) || holding === "absent" ? 0 : holding === "unknown" ? null : item.id === "employee-savings-combined" ? mode === "gross" ? point.employeeSavingsCombined : null : chartValue(point, item.id, mode);
    });
    const qualities = mode === "net" ? series.flatMap((item) => (item.id.startsWith("contract:") || item.id === "employee-savings-combined") && activeIds.includes(item.id) && historicalHoldingState(point,item.id,contracts) !== "absent" ? [item.id === "employee-savings-combined" ? "unavailable" as NetQuality : point.netKinds[item.id.slice(9)] ?? "unavailable" as NetQuality] : point.titleNets && item.id in point.titleNets && activeIds.includes(item.id) ? [chartValue(point,item.id,"net")===null ? "unavailable" as NetQuality : "calculated" as NetQuality] : []) : [];
    const hasKnownValues = series.some((item,index) => activeIds.includes(item.id) && historicalHoldingState(point,item.id,contracts) !== "absent" && values[index] !== null);
    const valid = activeIds.length > 0 && hasKnownValues && values.every((value) => value !== null) && !activeIds.some((id) => historicalHoldingState(point, id, contracts) === "unknown");
    const netReasons = mode === "net" ? [...new Set([...(activeIds.includes("employee-savings-combined") ? ["NET commun PEG/PER indisponible : source non ventilée."] : []), ...series.flatMap((item, index) => item.id.startsWith("contract:") && values[index] === null
      ? [point.netReasons?.[item.id.slice(9)] ?? "Net historique non calculable avec les données disponibles."] : point.titleNets && item.id in point.titleNets && values[index]===null ? [point.titleNetReasons?.[item.id]??"Détail NET du titre indisponible. [REF-TITLE-DATA]"] : [])])] : [];
    return { point, activeIds, values, valid, hasKnownValues, total: historicalSelectionTotal(point, series.map(item => item.id), values, contracts, mode), quality: netQualitySummary(qualities, valid), netReasons };
  });}

export function historyDisplayTotal(row: ReturnType<typeof historicalRows>[number], displayedSum = row.total) {
  return { label: row.hasKnownValues ? "Total" : "Total indisponible", value: row.hasKnownValues ? displayedSum : null };
}

export function stackedHistoryPaths(rows:ReturnType<typeof historicalRows>,series:HistorySeries[],contracts:ChartContract[],x:(index:number)=>number,y:(value:number)=>number,mode:ChartMode="gross"){
  // A known NET band may be stacked even when another series is unknown.
  // This predicate only controls drawing; source values and completeness stay intact.
  const documented=(row:ReturnType<typeof historicalRows>[number],index:number)=>row.activeIds.includes(series[index].id)
    && historicalHoldingState(row.point,series[index].id,contracts)!=="absent"
    && historicalHoldingState(row.point,series[index].id,contracts)!=="unknown"
    && typeof row.values[index]==="number" && Number.isFinite(row.values[index]);
  return series.map((serie, seriesIndex) => {
    const segments: string[] = [], upperSegments: string[] = [], isolatedPoints: Array<[number,number]> = []; let top: Array<[number,number]> = [], bottom: Array<[number,number]> = [];
    const flush = () => { if (top.length) { if(top.length===1)isolatedPoints.push(top[0]); upperSegments.push(`M ${top.map(([a,b]) => `${a} ${b}`).join(" L ")}`); segments.push(`M ${top.map(([a,b]) => `${a} ${b}`).join(" L ")} L ${bottom.reverse().map(([a,b]) => `${a} ${b}`).join(" L ")} Z`); } top=[]; bottom=[]; };
    rows.forEach((row, index) => {
      // A partial sum must not look like a falling complete portfolio. Its
      // known components remain available in the tooltip/table, without a
      // monetary stack or an invented zero baseline on this date.
      if (!row.valid && mode!=="net") { flush(); return; }
      const previous=rows[index-1];
      if(mode==="net"){
        if(!documented(row,seriesIndex)){flush();return;}
      }
      const gap=previous ? Date.parse(row.point.date+'T12:00:00Z')-Date.parse(previous.point.date+'T12:00:00Z')>86400000*1.5 : false;
      const holding=row.activeIds.includes(serie.id)?historicalHoldingState(row.point,serie.id,contracts):'absent',value=row.values[seriesIndex];
      if(value===null||holding==='absent'||holding==='unknown'||gap){flush();if(value===null||holding==='absent'||holding==='unknown')return;}
      const low=mode==="net" ? row.values.slice(0,seriesIndex).reduce<number>((sum,v,i)=>documented(row,i)?sum+v!:sum,0) : row.values.slice(0,seriesIndex).reduce<number>((sum,v)=>sum+(v??0),0),high=low+value;
      // One dated vertex per boundary, shared by fill and contour. Source
      // provenance must not insert an extra vertex at the same abscissa.
      // An entering/reappearing lower band is not extended into the past:
      // the approved unfilled wedge remains below the known upper bands.
      // This band's own unknowns, absence and calendar gaps break it above.
      top.push([x(index),y(high)]);bottom.push([x(index),y(low)]);
    });flush();
    return { ...serie, path: segments.join(" "), upperPath: upperSegments.join(" "), isolatedPoints };
  });}
