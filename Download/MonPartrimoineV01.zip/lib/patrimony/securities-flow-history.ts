import { selectHistoricalObservations, type HistoricalObservation } from "./historical-observations";
import { convertToEur } from "@/lib/fx/fx-core";
import { parisDateFromIso } from "@/lib/cash/cash-core";
import type { ChartPoint } from "./chart-core";
import type { PatrimonialReportRecords } from "@/lib/reports/patrimonial-report-core";
export function securitiesFlowHistory(balances:readonly {contract_id:string;metadata?:unknown}[],points:readonly ChartPoint[],daily:readonly HistoricalObservation[]) {
  type Change={id:string;date:string;kind:"contribution"|"withdrawal"};
  const groups=new Map<string,Map<string,Change>>();
  for(const b of balances){
    const journal=(b.metadata as {securities_cash_actions?:{flowChanges?:Change[]}}|undefined)?.securities_cash_actions;
    if(!journal?.flowChanges)continue;
    const group=groups.get(b.contract_id)??new Map<string,Change>();
    for(const c of journal.flowChanges){if(!c.id||!/^\d{4}-\d{2}-\d{2}$/.test(c.date)||!['contribution','withdrawal'].includes(c.kind))throw Error('Preuve de flux daté invalide');group.set(`${c.id}:${c.date}:${c.kind}`,c);}
    groups.set(b.contract_id,group);
  }
  if(!groups.size)return[];
  const selected=selectHistoricalObservations([...daily]).map(s=>s.selected).sort((a,b)=>b.business_date.localeCompare(a.business_date));
  return [...groups].flatMap(([contractId,group])=>{
    const changes=[...group.values()],ids=new Set(changes.map(c=>c.id)),first=changes.map(c=>c.date).sort()[0];
    let qualified=true,foreignBaseline=false;
    const qualifiedDates:string[]=[];
    // An empty current ledger is a known zero only if retained sources agree
    // with fully identified managed flows. Missing legacy operations or FX
    // remain unknown; deleting the last action must not resurrect a source sum.
    for(const p of points){
      if(!(contractId in p.contributions)&&!(`contract:${contractId}:gross`in p.values))continue;
      const contributions=p.contributions[contractId],net=p.netCashFlows?.[contractId];
      if(typeof contributions!=='number'||typeof net!=='number'){if(p.date>=first)qualified=false;continue;}
      if(Math.abs(contributions)<1e-8&&Math.abs(net)<1e-8){qualifiedDates.push(p.date);continue;}
      const cap=selected.find(c=>c.business_date<=p.date&&c.result?.report?.contracts?.some(r=>r.id===contractId));
      const input=cap?.inputs as Partial<PatrimonialReportRecords>|undefined;
      if(!input||!Array.isArray(input.cashFlows)){qualified=false;foreignBaseline=true;continue;}
      const rates=[...(input.historicalFxRates??[]),...(input.currentFxRates??[])];
      let sum=0,flowNet=0,pointQualified=true;
      for(const flow of input.cashFlows){
        if((flow.destination_contract_id??flow.source_contract_id)!==contractId||!['contribution','withdrawal'].includes(flow.kind)||parisDateFromIso(flow.occurred_at)>p.date)continue;
        if(!ids.has(flow.id!)){pointQualified=false;foreignBaseline=true;break;}
        const amount=convertToEur(flow.amount,flow.currency_code,rates.find(r=>r.id===flow.fx_rate_id)).amountEur;
        if(amount===null){pointQualified=false;break;}
        if(flow.kind==='contribution')sum+=amount;
        flowNet+=(flow.kind==='contribution'?1:-1)*amount;
      }
      if(!pointQualified){qualified=false;continue;}
      if(Math.abs(sum-contributions)>1e-6||Math.abs(flowNet-net)>1e-6){qualified=false;foreignBaseline=true;continue;}
      qualifiedDates.push(p.date);
    }
    return changes.map(c=>({contractId,kind:c.kind,occurredOn:c.date,emptyLedgerQualified:qualified&&!foreignBaseline,emptyLedgerQualifiedDates:foreignBaseline?[]:qualifiedDates}));
  });
}
