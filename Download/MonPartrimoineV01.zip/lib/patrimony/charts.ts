import {markAcquisitionEstimates} from "@/lib/contracts/cto-acquisition-input";
import { projectContributionCorrections } from "@/lib/cash/contribution-corrections";
import {projectReconciledAmountCaptures} from "./reconciled-amount-projection";
import {reconciledCashLink} from "@/lib/cash/flow-cash";
import { securitiesFlowHistory } from "./securities-flow-history";
import { securitiesActions } from "@/lib/cash/securities-actions";
import {projectInitialCashPeriods} from "./initial-cash-period";
import {projectConfirmedAmountPeriods} from "./confirmed-amount-period";
import {projectAmountObservations,projectLifeInsuranceReplacements} from "./amount-observation-projection";
import {projectValuationContinuity} from "./valuation-continuity";
import {projectCtoHistoricalFxRecovery} from "./cto-historical-fx-recovery";
import {projectCtoBrokerHistory,markCtoBrokerEstimates} from "./cto-broker-history";
import {markCtoBrokerNativeEstimates} from "@/lib/contracts/cto-broker-basis";
import {readEnvelopeFiscalities} from '@/lib/fiscal/envelopes';
import {locationHistory} from "@/lib/geography/location-history";
import {propertyHistory,propertyMembers,propertyReplacedBy,projectPropertyHistory,type PropertyObservation} from "@/lib/contracts/property-valuations";
import { isContractInUserScope } from "@/lib/contracts/contract-scope";
import { positionHistory } from "@/lib/contracts/position-observations";
import { projectPositionObservations } from "./position-observation-projection";
import { historyEvidence } from "./history-evidence";
import { historyPointsForSelection } from "./history-window";
import { selectExposureObservations } from "@/lib/patrimony/exposure-observations";
import { currentExposurePublications, publicationExposureRows, type ExposurePublication, type RawPublishedExposure } from "@/lib/assets/exposure-history";
import { readStoredFxRates } from "@/lib/fx/stored-fx-rates";
import {employeeSavingsValues,projectEmployeeSavingsValues} from "@/lib/patrimony/employee-savings-values";
import type {ManualSituation} from "@/lib/patrimony/manual-situation-core";
import { projectDatedCashBalances } from "@/lib/patrimony/cash-balance-projection";
import { selectDatedBalances, type DatedBalance } from "@/lib/cash/dated-balances";
import { contractsWithHistory } from "./chart-core";
import "server-only";
import { createClient } from "@/lib/supabase/server";
import { requireRenderUser } from "@/lib/auth/render-context";
import { getCurrentPatrimonialReport } from "@/lib/reports/patrimonial-report";
import { extendHistoricalInventory } from "@/lib/patrimony/captured-chart-point";
import { buildHistoricalChartPoints, extendLegacyInventory, selectHistoricalObservations } from "@/lib/patrimony/historical-observations";
import type { PatrimonialReport } from "@/lib/reports/patrimonial-report-core";
import { readDailyHistory, readLegacyHistory } from "@/lib/patrimony/daily-history";
import { convertToEur, type FxRateRecord } from "@/lib/fx/fx-core";
import { mapFiscalRuleRow, type FiscalRuleRow } from "@/lib/fiscal/fiscal-settings";
import { countryDisplayName } from "@/lib/assets/country-display";
import { parisDateFromIso } from "@/lib/cash/cash-core";
import { isQuantifiedAssetType, isSecuritiesEnvelopeType, pointsForFixedContract, projectDatedCashFlows, projectHistoricalNets, stableColor, type ChartContract, type ChartPoint, type DatedCashFlow, type ExposureRow, type HistoricalNetContext, type PatrimonyChartData } from "@/lib/patrimony/chart-core";

export async function getPatrimonyChartData(initialScope: "total" | "outside-real-estate" = "total", fixedContractId: string | null = null, prepared?: {report:PatrimonialReport;generatedAt:string}, propertyOverride?:{positionId:string;contractId?:string;assetId?:string;entries:PropertyObservation[]}, includeReplaced = false): Promise<PatrimonyChartData> {
  const generatedAt=prepared?.generatedAt??new Date().toISOString();
  const user = await requireRenderUser();
  const client = await createClient();
  const [report, daily, legacy, mapsResult, contractsResult, assetsResult, flowsResult, fiscalRulesResult, fiscalPreferencesResult, balancesResult, holdingRows, manualRows, amountSnapshots, envelopeFiscalities] = await Promise.all([
    prepared?.report??getCurrentPatrimonialReport(generatedAt), readDailyHistory(undefined,generatedAt), readLegacyHistory(undefined,generatedAt),
    client.from("patrimonial_legacy_account_maps").select("source_key,contract_id").eq("user_id", user.id),
    client.from("contracts").select("id,envelope_type_id,name,display_name,color,color_origin,opened_on,closed_on,is_active,valuation_source,fiscal_assignments,fiscal_regime_id,fiscal_started_on,fiscal_history_complete,social_contributions_paid_eur,metadata,envelope_types(code,label)").eq("user_id", user.id),
    client.from("assets").select("id,name,symbol,asset_type_code,valuation_mode,isin,color,color_origin,metadata"),
    client.from("cash_flows").select("id,kind,destination_contract_id,source_contract_id,amount,currency_code,occurred_at,fx_rate_id,fx_status").eq("user_id", user.id).in("kind", ["contribution", "withdrawal"]),
    client.from("fiscal_rules").select("id,rule_name,calculation_mode,fiscal_regime_id,owner_user_id,version_number,valid_from,age_threshold_months,ir_rate_before,ir_rate_after,ps_rate_before,ps_rate_after,ir_base_type,ps_base_type,ir_allowance_amount,ir_allowance_scope,status,description,source,source_title,verified_on").eq("active", true).eq("status", "verified").not("fiscal_regime_id", "is", null),
    client.from("user_fiscal_regime_preferences").select("fiscal_regime_id,use_personal_rule").eq("user_id", user.id),
    client.from("cash_balances").select("id,contract_id,amount::text,currency_code,as_of,updated_at,metadata").eq("user_id", user.id),
    client.from("positions").select("id,contract_id,asset_id,quantity,average_cost_per_unit,cost_currency_code,is_active,metadata").eq("user_id",user.id),
    client.from("contract_manual_situations").select("*").eq("user_id",user.id),
    client.from("position_snapshots").select("position_id,market_value,currency_code,valued_at").eq("user_id",user.id),
    readEnvelopeFiscalities(),
  ]);
  if (mapsResult.error || contractsResult.error || assetsResult.error || flowsResult.error || fiscalRulesResult.error || fiscalPreferencesResult.error) throw new Error("Graphiques patrimoniaux indisponibles");
  const sourceByContract = new Map((mapsResult.data ?? []).map((row) => [row.contract_id, row.source_key]));
  const typeByContract = new Map((contractsResult.data ?? []).map((row) => {
    const relation = row.envelope_types as { code: string; label: string } | { code: string; label: string }[] | null;
    return [row.id, Array.isArray(relation) ? relation[0] : relation];
  }));
  const lifeInsuranceIds=new Set((contractsResult.data??[]).filter(c=>typeByContract.get(c.id)?.code==='assurance_vie').map(c=>c.id));
  const nativeBalances=(balancesResult.data??[]).filter(b=>!lifeInsuranceIds.has(b.contract_id));
  const assetTypes = new Map((assetsResult.data ?? []).map((row) => [row.id, row.asset_type_code]));
  const assetsByContract = new Map<string, ChartContract["children"]>();
  for (const asset of report.assets) for (const holding of asset.holdings) {
    const children = assetsByContract.get(holding.contractId) ?? [];
    children.push({ id: `asset:${holding.contractId}:${asset.id}`, kind: "asset", assetId: asset.id, symbol: asset.symbol, label: asset.name, valueEur: holding.valueEur, quantity: holding.quantity, quantified: holding.valueSemantics !== "total_amount" && isQuantifiedAssetType(assetTypes.get(asset.id) ?? ""), color: asset.color ?? stableColor(`asset:${asset.id}`), colorAutomatic: asset.color === null || asset.colorOrigin === "automatic", valuedAt: asset.priceObservedAt });
    assetsByContract.set(holding.contractId, children);
  }
  const reportById = new Map(report.contracts.map((contract) => [contract.id, contract]));
  const contractRows = (contractsResult.data ?? []).filter(row=>isContractInUserScope(row.id));
  const currentContracts: ChartContract[] = contractRows.map((row) => {
    const contract = reportById.get(row.id);
    const children = assetsByContract.get(row.id) ?? [];
    const displayName = row.display_name?.trim() || row.name;
    const sourceKey = sourceByContract.get(row.id) ?? null;
    if (contract && !lifeInsuranceIds.has(row.id) && (contract.cashEur || isSecuritiesEnvelopeType(typeByContract.get(row.id)?.code) || sourceKey === "livret_a" || sourceKey === "ldds")) children.unshift({ id: `cash:${row.id}`, kind: "cash", label: `Espèces · ${displayName}`, valueEur: contract.cashEur, color: "#ef4444" });
    return { id: row.id, name: displayName, envelopeType: typeByContract.get(row.id)?.label ?? contract?.envelopeTypeLabel ?? "Autre", envelopeTypeCode: typeByContract.get(row.id)?.code, sourceKey: sourceByContract.get(row.id) ?? null, openedOn: row.opened_on, closedOn: row.closed_on, isActive: row.is_active, grossEur: contract?.grossEur ?? 0, netEur: contract?.netEstimatedEur ?? null, netKind: contract?.netKind ?? "unavailable", valuationDate: contract?.manualSituationAt ?? null, valuationAuthority: contract?.manualSituationAt ? "global" : "positions", valuationDates: [...children.flatMap((child) => child.valuedAt ? [child.valuedAt] : []), ...(contract?.manualSituationAt ? [contract.manualSituationAt] : [])], color: row.color ?? stableColor(`contract:${row.id}`), colorAutomatic: row.color === null || row.color_origin === "automatic", valuationIncomplete: !contract || contract.incompletePositions > 0 || contract.incompleteCashBalances > 0, children };
  });
  const contracts = extendLegacyInventory(extendHistoricalInventory(currentContracts, daily.flatMap((row) => row.result.engineVersion === "patrimony-history-v1" ? [{ report: row.result.report as PatrimonialReport }] : [])), daily);
  for(const contract of contracts)if(contract.envelopeTypeCode==="assurance_vie")contract.children=contract.children.filter(child=>child.kind!=="cash");
  const assetMetadata = new Map((assetsResult.data ?? []).map((row) => [row.id, row]));
  for (const contract of contracts) for (const child of contract.children) {
    const asset = child.assetId ? assetMetadata.get(child.assetId) : undefined;
    if (asset) {child.quantified = child.quantified !== false && isQuantifiedAssetType(asset.asset_type_code);child.isin=asset.isin;child.euroFund=asset.asset_type_code === "fund" && asset.valuation_mode === "manual";}
    if (asset?.color) { child.color = asset.color; child.colorAutomatic = asset.color_origin === "automatic"; }
  }
  if (balancesResult.error) throw new Error("Soldes historiques indisponibles");
  const authoritativeCaptureIds = new Set(selectHistoricalObservations(daily).map(group => group.selected.id));
  const archivedBalances = daily.flatMap(row => {
    const inputs = row.inputs as { cashBalances?: DatedBalance[]; currentFxRates?: FxRateRecord[] } | undefined;
    return selectDatedBalances((inputs?.cashBalances ?? []).filter(b=>!lifeInsuranceIds.has(b.contract_id)), row.captured_at).map(balance => ({ ...balance, snapshotDate: row.business_date, snapshotAt: row.captured_at, authoritative: authoritativeCaptureIds.has(row.id), fxRates: inputs?.currentFxRates ?? [] }));
  });
  if(holdingRows.error)throw Error("Observations de détention indisponibles");
  for(const p of holdingRows.data??[]){
    if(!positionHistory(p.metadata)&&!propertyHistory(p.metadata))continue;const contract=contracts.find(c=>c.id===p.contract_id);if(!contract||contract.children.some(c=>c.assetId===p.asset_id))continue;
    const asset=assetMetadata.get(p.asset_id);contract.children.push({id:`asset:${p.contract_id}:${p.asset_id}`,assetId:p.asset_id,euroFund:asset?.asset_type_code === "fund" && asset?.valuation_mode === "manual",kind:"asset",label:asset?.name??"Actif historique",symbol:asset?.symbol??null,quantity:0,valueEur:0,quantified:isQuantifiedAssetType(asset?.asset_type_code??""),color:asset?.color??stableColor(`asset:${p.asset_id}`)});
  }

  if(manualRows.error)throw Error("Observations individuelles indisponibles");
  const individual=employeeSavingsValues((manualRows.data??[]) as ManualSituation[],legacy,generatedAt).effective;
  if(amountSnapshots.error)throw Error("Valorisations totales indisponibles");
  const initialCashCurrencies=legacy.flatMap(s=>{const p=s.payload as unknown as {kind?:string;currency?:unknown};return p.kind==='approved_initial_cash_period'&&typeof p.currency==='string'?[p.currency]:[];});
  // Read stored prices only; no provider call or capture. Undated holdings are
  // deliberately excluded from reconstruction by the native selector below.
  const continuityAssetIds=[...new Set((holdingRows.data??[]).map(p=>p.asset_id))];
  const continuityPrices=continuityAssetIds.length?await client.from('asset_prices').select('asset_id,origin,price,currency_code,observed_at,obtained_at').in('asset_id',continuityAssetIds).lte('observed_at',generatedAt):{data:[],error:null};
  if(continuityPrices.error)throw Error('Cours datés pour la continuité indisponibles');
  const continuityRates=await readStoredFxRates(client,[...(nativeBalances).map(b=>b.currency_code),...archivedBalances.map(b=>b.currency_code),...(amountSnapshots.data??[]).map(s=>s.currency_code),...initialCashCurrencies,...(continuityPrices.data??[]).map(p=>p.currency_code),...(holdingRows.data??[]).map(p=>p.cost_currency_code),...(holdingRows.data??[]).flatMap(p=>[...(propertyHistory(p.metadata)?.entries.map(e=>e.currency)??[]),...(positionHistory(p.metadata)?.entries.map(e=>e.currency)??[])])],parisDateFromIso(generatedAt));
  const basePoints: ChartPoint[] = projectDatedCashBalances(projectEmployeeSavingsValues(buildHistoricalChartPoints(contracts,daily,legacy,true),contracts,individual,daily,parisDateFromIso(generatedAt)), contracts, nativeBalances, archivedBalances, continuityRates);
  const monetaryPoints=projectAmountObservations(projectPositionObservations(basePoints,contracts,daily,legacy,holdingRows.data??[]),contracts,daily,legacy,holdingRows.data??[],amountSnapshots.data??[],continuityRates,generatedAt,nativeBalances);
  const reconciledSources=projectConfirmedAmountPeriods(projectInitialCashPeriods(projectReconciledAmountCaptures(monetaryPoints,contracts,daily,legacy,holdingRows.data??[]),contracts,legacy,continuityRates,generatedAt),contracts,legacy,holdingRows.data??[],continuityRates,generatedAt);
  const reconciledPoints=projectLifeInsuranceReplacements(reconciledSources,contracts,daily,legacy,holdingRows.data??[],amountSnapshots.data??[],continuityRates,generatedAt,nativeBalances);
  const fxRecoveredPoints=projectCtoHistoricalFxRecovery(reconciledPoints,contracts,daily,legacy);
  const sourcePoints=projectValuationContinuity(fxRecoveredPoints,contracts.map(c=>({...c,valuationAuthority:contractRows.find(r=>r.id===c.id)?.valuation_source==='manual_situation'?'global':c.valuationAuthority})),{
    positions:holdingRows.data??[],snapshots:amountSnapshots.data??[],balances:nativeBalances,assets:[...assetMetadata.values()],prices:continuityPrices.data??[],rates:continuityRates,manual:individual,
    blockedContractIds:contractRows.filter(r=>r.closed_on).map(r=>r.id),
    closedOnByContract:Object.fromEntries(contractRows.flatMap(r=>r.closed_on?[[r.id,r.closed_on]]:[])),captures:daily,
  },generatedAt);
  const assetIds = [...new Set(contracts.flatMap(contract => contract.children.flatMap(child => child.assetId ? [child.assetId] : [])))];
  const rateIds = [...new Set((flowsResult.data ?? []).flatMap((flow) => flow.fx_rate_id ? [flow.fx_rate_id] : []))];
  const flowRatesResult = rateIds.length
    ? await client.from("fx_rates").select("id,currency_code,requested_on,observed_on,eur_per_unit,source,obtained_at").in("id", rateIds)
    : { data: [] as FxRateRecord[], error: null };
  if (flowRatesResult.error) throw new Error("Graphiques patrimoniaux indisponibles");
  const flowRates = new Map(((flowRatesResult.data ?? []) as FxRateRecord[]).flatMap((rate) => rate.id ? [[rate.id, rate] as const] : []));
  const datedFlows: DatedCashFlow[] = (flowsResult.data ?? []).flatMap((flow) => {
    const contractId = flow.kind === "contribution" ? flow.destination_contract_id : flow.source_contract_id;
    if (!contractId) return [];
    const rate = flow.fx_rate_id ? flowRates.get(flow.fx_rate_id) : null;
    return [{ contractId, kind: flow.kind, occurredOn: parisDateFromIso(flow.occurred_at), amount: Number(flow.amount), currency: flow.currency_code, amountEur: convertToEur(flow.amount, flow.currency_code, rate).amountEur, fxRate: rate?.eur_per_unit == null ? null : Number(rate.eur_per_unit), fxRateDate: rate?.observed_on ?? rate?.requested_on ?? null, fxStatus: flow.fx_status ?? (flow.currency_code === "EUR" ? "same_currency" : rate ? "archived_rate" : "missing_rate"), reconciled: (nativeBalances).some(balance => reconciledCashLink(balance.metadata, flow.id)) }];
  });
  const pointsWithFlows = projectDatedCashFlows(sourcePoints, report.contracts.map((contract) => ({
    id: contract.id,
    totalContributionsEur: contract.totalContributionsEur,
    netCashFlowsEur: contract.netCashFlowsEur,
    incompleteContributionFlows: contract.incompleteContributionFlows,
    incompleteNetCashFlows: contract.incompleteNetCashFlows,
  })), datedFlows, securitiesFlowHistory(nativeBalances,sourcePoints,daily));
  const preferenceByRegime = new Map((fiscalPreferencesResult.data ?? []).map((item) => [item.fiscal_regime_id, item.use_personal_rule]));
  const contexts: HistoricalNetContext[] = contractRows.map((row) => {
    const metadata = row.metadata && typeof row.metadata === "object" && !Array.isArray(row.metadata) ? row.metadata as Record<string, unknown> : {};
    const knownNet = Number(metadata.knownLiquidationNetEur);
    const knownAsOf = typeof metadata.knownLiquidationNetAsOf === "string" && /^\d{4}-\d{2}-\d{2}$/.test(metadata.knownLiquidationNetAsOf) ? metadata.knownLiquidationNetAsOf : null;
    return { id: row.id, envelopeTypeId:row.envelope_type_id, fiscalAssignments:row.fiscal_assignments, fiscalRegimeId: row.fiscal_regime_id, fiscalStartedOn: row.fiscal_started_on,
      fiscalHistoryComplete: row.fiscal_history_complete === true,
      socialContributionsPaidEur: row.social_contributions_paid_eur === null ? null : Number(row.social_contributions_paid_eur),
      usePersonalRule: row.fiscal_regime_id ? preferenceByRegime.get(row.fiscal_regime_id) === true : false,
      knownLiquidationNetEur: Number.isFinite(knownNet) ? knownNet : null, knownLiquidationNetAsOf: knownAsOf };
  });
  const brokerPoints = projectCtoBrokerHistory(pointsWithFlows, contracts, legacy);
  const fiscalPoints = markCtoBrokerEstimates(projectHistoricalNets(brokerPoints, contracts, contexts,
    ((fiscalRulesResult.data ?? []) as FiscalRuleRow[]).map(mapFiscalRuleRow), user.id, envelopeFiscalities));
  const propertyPositions=(holdingRows.data??[]).map(p=>propertyOverride&&propertyOverride.positionId===p.id?{...p,metadata:{...p.metadata,property_valuations:{...propertyHistory(p.metadata),version:1,entries:propertyOverride.entries,archived:[]}}}:p);
  if(propertyOverride?.assetId&&propertyOverride.contractId&&!propertyPositions.some(p=>p.id===propertyOverride.positionId)){propertyPositions.push({id:propertyOverride.positionId,contract_id:propertyOverride.contractId,asset_id:propertyOverride.assetId,is_active:true,quantity:1,average_cost_per_unit:null,cost_currency_code:"EUR",metadata:{property_valuations:{version:1,entries:propertyOverride.entries,archived:[]}}});}
  for(const p of propertyPositions){const c=contracts.find(c=>c.id===p.contract_id);if(c&&!c.children.some(ch=>ch.assetId===p.asset_id)){const a=assetMetadata.get(p.asset_id);c.children.push({id:`asset:${p.contract_id}:${p.asset_id}`,assetId:p.asset_id,kind:"asset",label:a?.name??"Bien immobilier",symbol:null,color:a?.color??stableColor(`asset:${p.asset_id}`),quantified:false,valueEur:null});}}
  const overrideCurrencies=propertyOverride?.entries.map(e=>e.currency)??[];
  const propertyRates=overrideCurrencies.some(code=>code!=="EUR"&&!continuityRates.some(rate=>rate.currency_code===code))?[...continuityRates,...await readStoredFxRates(client,overrideCurrencies,parisDateFromIso(generatedAt))]:continuityRates;
  const nativeProjectedPoints=projectPropertyHistory(markAcquisitionEstimates(markCtoBrokerNativeEstimates(fiscalPoints,holdingRows.data??[]),holdingRows.data??[]),contracts,contractRows.map(c=>({contractId:c.id,members:propertyMembers(c.metadata)})),propertyPositions,propertyRates);
  const projectedPoints=projectContributionCorrections(nativeProjectedPoints,contractRows.map(c=>({id:c.id,envelopeCode:typeByContract.get(c.id)?.code??"",metadata:c.metadata})),(flowsResult.data??[]).flatMap(f=>{const contractId=f.kind==="contribution"?f.destination_contract_id:f.source_contract_id;if(!contractId)return[];return[{id:f.id,contractId,kind:f.kind,date:parisDateFromIso(f.occurred_at),amountEur:convertToEur(f.amount,f.currency_code,f.fx_rate_id?flowRates.get(f.fx_rate_id):null).amountEur}];}));
  const replaced=new Set(contractRows.filter(c=>propertyReplacedBy(c.metadata)).map(c=>c.id));
  const effectiveContracts=contracts.filter(c=>includeReplaced||!replaced.has(c.id)||fixedContractId===c.id);
  const points=historyPointsForSelection(projectedPoints,effectiveContracts.map(c=>`contract:${c.id}`).concat('employee-savings-combined'),contracts);
  let exposures: ExposureRow[] = [];
  let exposureUnavailable = false;
  if (assetIds.length) {
    const [rawResult, sectorsResult, countriesResult, versionsResult] = await Promise.all([
      client.rpc("effective_asset_exposures", { requested_assets: assetIds }), client.from("effective_sectors").select("id,name,code"), client.from("exposure_countries").select("id,name,code"), client.from("asset_exposure_versions").select("*").eq("owner_user_id", user.id).in("asset_id",assetIds),
    ]);
    exposureUnavailable = Boolean(rawResult.error || sectorsResult.error || countriesResult.error || versionsResult.error);
    if (!exposureUnavailable) {
      const names = new Map([...((sectorsResult.data ?? []).map((x) => [x.id, x.name]) as [string,string][]), ...((countriesResult.data ?? []).map((x) => [x.id, countryDisplayName(x.name)]) as [string,string][])]);
      const unknown = new Set([...sectorsResult.data ?? [], ...countriesResult.data ?? []].filter((row) => row.code === "unspecified").map((row) => row.id));
      const headers=(versionsResult.data ?? []) as ExposurePublication[];
      const currentIds=new Set(currentExposurePublications(headers,parisDateFromIso(generatedAt)).map(version=>version.id));
      const versions=publicationExposureRows(headers,names,unknown,parisDateFromIso(generatedAt)).map(row=>({...row,isCurrent:currentIds.has(row.versionId!)}));
      // Keep existing exposure proof per asset/dimension, independently of missing financial inputs.
      const exposureCaptures=selectExposureObservations(daily);
      const captured=exposureCaptures.flatMap(({capture:row,assetId,dimension})=>{
        const inputs=row.inputs as {exposures?:RawPublishedExposure[];sectors?:{id:string;name:string}[];countries?:{id:string;name:string;code?:string}[]}|undefined;
        const capturedNames=new Map([...names,...(inputs?.sectors ?? []).map(x=>[x.id,x.name] as const),...(inputs?.countries ?? []).map(x=>[x.id,countryDisplayName(x.name)] as const)]);
        return (inputs?.exposures ?? []).filter(e=>e.stage==="effective" && e.asset_id===assetId && e.dimension===dimension).map(e=>({assetId:e.asset_id,dimension:e.dimension,referenceId:e.reference_id,name:capturedNames.get(e.reference_id)??"Non spécifié",weight:Number(e.weight_percent),dataDate:e.data_date,source:e.source,unallocated:unknown.has(e.reference_id),snapshotDate:row.business_date,versionId:`capture:${row.id}`}));
      });
      exposures=[...versions,...captured];

    }
  }
  const [geoCountries,geoRegions]=await Promise.all([client.from("exposure_countries").select("id,name,code,region_code"),client.from("geographic_regions").select("code,name")]);
  exposureUnavailable ||= Boolean(geoCountries.error||geoRegions.error);
  const geographyReferences={countries:(geoCountries.data??[]).map(c=>({...c,name:countryDisplayName(c.name)})),regions:geoRegions.data??[]};
  const publicLocation=(metadata:unknown)=>{const h=locationHistory(metadata);return h?{geographic_location:{version:1,entries:h.entries,archived:[]}}:{};};
  const geographicLocations={contracts:Object.fromEntries(contractRows.map(c=>[c.id,publicLocation(c.metadata)])),assets:Object.fromEntries((assetsResult.data??[]).map(a=>[a.id,publicLocation(a.metadata)]))};
  const fixed=contracts.find(item=>item.id===fixedContractId)??null;
  const scopedPoints = fixedContractId ? historyPointsForSelection(pointsForFixedContract(points, fixed),[`contract:${fixedContractId}`,...(fixed?.sourceKey==='peg'||fixed?.sourceKey==='per_col'?['employee-savings-combined']:[])],contracts) : points;
  const positionById = new Map((holdingRows.data ?? []).filter(p=>isContractInUserScope(p.contract_id)).map(position => [position.id, position]));
  return { ...(includeReplaced?{navigationExcludedContractIds:[...replaced]}:{}),geographyReferences,geographicLocations,propertyObservations:propertyPositions.filter(p=>isContractInUserScope(p.contract_id)).flatMap(p=>(propertyHistory(p.metadata)?.entries??[]).map(observation=>({contractId:p.contract_id,positionId:p.id,assetId:p.asset_id,observation}))),holdingObservations:(holdingRows.data??[]).filter(p=>isContractInUserScope(p.contract_id)).flatMap(p=>(positionHistory(p.metadata)?.entries??[]).map(observation=>({contractId:p.contract_id,assetId:p.asset_id,observation}))),cashOperations:nativeBalances.filter(b=>isContractInUserScope(b.contract_id)).flatMap(balance=>securitiesActions(balance.metadata).map(action=>({contractId:balance.contract_id,currency:balance.currency_code,date:action.date,kind:action.kind,amount:Number(action.amount),delta:Number(action.delta),order:action.order,revision:action.revision,legacyMode:action.legacyMode})).filter(action=>Number.isFinite(action.amount)&&Number.isFinite(action.delta))),positionValuations:(amountSnapshots.data??[]).flatMap(snapshot=>{const position=positionById.get(snapshot.position_id);return position?[{contractId:position.contract_id,assetId:position.asset_id,amount:Number.isFinite(Number(snapshot.market_value))?Number(snapshot.market_value):null,currency:snapshot.currency_code,valuedAt:snapshot.valued_at}]:[]}),assetPrices:(continuityPrices.data??[]).flatMap(price=>Number.isFinite(Number(price.price))?[{assetId:price.asset_id,price:Number(price.price),currency:price.currency_code,observedAt:price.observed_at,obtainedAt:price.obtained_at,source:price.origin}]:[]),fxRates:[...continuityRates,...flowRates.values()].flatMap(rate=>Number.isFinite(Number(rate.eur_per_unit))?[{currency:rate.currency_code,requestedOn:rate.requested_on??null,observedOn:rate.observed_on??null,eurPerUnit:Number(rate.eur_per_unit),source:rate.source??null,obtainedAt:rate.obtained_at??null}]:[]),cashFlows:datedFlows.filter(f=>isContractInUserScope(f.contractId)),generatedAt, historyEvidence:historyEvidence(scopedPoints,contracts,daily,legacy), contracts: contractsWithHistory(effectiveContracts, scopedPoints, fixedContractId), points: scopedPoints, exposures, exposureUnavailable, initialScope, latestDate: scopedPoints.at(-1)?.date ?? null };
}
