import {buildPatrimonialReport,type PatrimonialReportRecords} from "@/lib/reports/patrimonial-report-core";
import {applyCapturedChartPoint} from "./captured-chart-point";
import {selectHistoricalObservations,type HistoricalObservation,type HistoricalSource} from "./historical-observations";
import type {ChartPoint,ChartContract} from "./chart-core";
import {parisDate} from "./current-valuation-core";
type Position={id:string;contract_id:string;asset_id:string;metadata?:unknown};
const object=(v:unknown):Record<string,unknown>=>v&&typeof v==="object"&&!Array.isArray(v)?v as Record<string,unknown>:{};
const canonical=(v:unknown):string=>JSON.stringify(v&&typeof v==="object"?Array.isArray(v)?v.map(x=>JSON.parse(canonical(x))):Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b)).map(([k,x])=>[k,JSON.parse(canonical(x))])):v??null);
const instant=(a:unknown,b:unknown)=>typeof a==="string"&&typeof b==="string"&&Number.isFinite(Date.parse(a))&&Date.parse(a)===Date.parse(b);

// Exact reconciliation receipt only: never mutate an archived capture or infer
// a position/date from today's total. Unrelated authorities and rows are retained.
export function projectReconciledAmountCaptures(points:ChartPoint[],contracts:ChartContract[],captures:HistoricalObservation[],sources:HistoricalSource[],positions:Position[]){
 const selected=new Map(selectHistoricalObservations(captures).map(g=>[g.date,g.selected]));
 return points.map(original=>{
  const capture=selected.get(original.date);if(capture?.result.engineVersion!=="patrimony-history-v1")return original;
  let point=original;
  for(const position of positions){
   const proof=object(object(position.metadata).abeille_test_repair),price=object(proof.removedTestPrice),flow=object(proof.removedTestFlow),native=object(proof.nativePosition),snapshot=object(proof.snapshot);
   if(!/^[a-f0-9]{64}$/.test(String(proof.sourceArchiveSha256))||price.asset_id!==position.asset_id||price.origin!=="manual"||flow.destination_contract_id!==position.contract_id||flow.kind!=="contribution"||!proof.priorHistory||!price.id||!flow.id)continue;
   const contract=contracts.find(c=>c.id===position.contract_id);
   if(!contract||contract.valuationAuthority==="global"||original.declaredContractTotals?.[contract.id]||sources.some(s=>s.business_date===point.date&&s.payload.kind==="approved_contract_correction"&&(s.payload as {contractId?:string}).contractId===contract.id))continue;
   const inputs=capture.inputs as PatrimonialReportRecords|undefined;
   if(!inputs?.positions||!inputs.prices||!inputs.cashFlows||!inputs.positionSnapshots)continue;
   const archived=inputs.positions.find(p=>p.id===position.id),asset=inputs.assets.find(a=>a.id===position.asset_id);
   const prices=inputs.prices.map(p=>object(p)),capturedPrice=prices.find(p=>p.id===price.id),capturedFlow=inputs.cashFlows.find(f=>f.id===flow.id);
   if(!archived||asset?.asset_type_code!=="fund"||asset.valuation_mode!=="manual"||inputs.positions.filter(p=>p.asset_id===position.asset_id).length!==1||canonical(object(archived.metadata).position_observations)!==canonical(proof.priorHistory))continue;
   if(!capturedPrice||prices.some(p=>p.asset_id===position.asset_id&&p.id!==price.id)||Number(capturedPrice.price)!==Number(price.price)||capturedPrice.currency_code!==price.currency_code||!instant(capturedPrice.observed_at,price.observed_at))continue;
   if(!capturedFlow||Number(capturedFlow.amount)!==Number(flow.amount)||capturedFlow.currency_code!==flow.currency_code||!instant(capturedFlow.occurred_at,flow.occurred_at))continue;
   if(snapshot.position_id!==position.id||!inputs.positionSnapshots.some(s=>s.position_id===position.id&&Number(s.market_value)===Number(snapshot.market_value)&&s.currency_code===snapshot.currency_code&&instant(s.valued_at,snapshot.valued_at)))continue;
   if(!Number.isFinite(Number(native.quantity))||native.average_cost_per_unit!==null||typeof native.cost_currency_code!=="string")continue;
   const metadata={...object(archived.metadata)};delete metadata.position_observations;
   const clean={...inputs,positions:inputs.positions.map(p=>p.id===position.id?{...p,quantity:Number(native.quantity),average_cost_per_unit:null,cost_currency_code:String(native.cost_currency_code),metadata}:p),prices:inputs.prices.filter(p=>object(p).id!==price.id),cashFlows:inputs.cashFlows.filter(f=>f.id!==flow.id)};
   const report=buildPatrimonialReport(clean,capture.captured_at,capture.business_date);
   const target=report.contracts.find(c=>c.id===contract.id);if(!target||target.incompletePositions||target.incompleteCashBalances)continue;
   const projected=applyCapturedChartPoint({date:original.date,values:{},cash:{},contributions:{},quantities:{},netKinds:{},employeeSavingsCombined:null,provenance:original.provenance},{...report,contracts:[target]},[contract],clean);
   const key=`asset:${position.contract_id}:${position.asset_id}`;
   point={...point,amountReconciliationEvidence:{...point.amountReconciliationEvidence,[key]:{amount:String(snapshot.market_value),currency:String(snapshot.currency_code),valuedAt:String(snapshot.valued_at)}},values:{...point.values,[key]:projected.values[key],[`contract:${contract.id}:gross`]:projected.values[`contract:${contract.id}:gross`],[`contract:${contract.id}:net`]:projected.values[`contract:${contract.id}:net`]},quantities:{...point.quantities,[key]:null},historicalUnitCosts:{...point.historicalUnitCosts,[key]:null},contributions:{...point.contributions,[contract.id]:projected.contributions[contract.id]},netCashFlows:{...point.netCashFlows,[contract.id]:projected.netCashFlows?.[contract.id]??null},netKinds:{...point.netKinds,[contract.id]:projected.netKinds[contract.id]},sourceNets:{...point.sourceNets,...projected.sourceNets},sourceNetDates:{...point.sourceNetDates,...projected.sourceNetDates},netReasons:{...point.netReasons},amountTrackedIds:[...new Set([...(point.amountTrackedIds??[]),key])],valuationSourceDates:{...point.valuationSourceDates,[key]:parisDate(String(snapshot.valued_at))},provenanceByContract:{...point.provenanceByContract,[contract.id]:"Sources d’essai réconciliées en consultation ; capture originale conservée, valorisation monétaire source documentée."}};
   if(projected.netReasons?.[contract.id])point.netReasons![contract.id]=projected.netReasons[contract.id];else delete point.netReasons![contract.id];
  }
  return point;
 });
}
