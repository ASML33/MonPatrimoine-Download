import type { ChartContract, ChartPoint } from "./chart-core";
import type { HistoricalSource } from "./historical-observations";
import { convertToEur, latestFxRatesByCurrency, type FxRateRecord } from "@/lib/fx/fx-core";
import { parisDate } from "./current-valuation-core";

export type ConfirmedAmountPeriod = {
  kind: "confirmed_position_amount_period"; version: 1; contractId: string; positionId: string; assetId: string;
  from: string; through: string; amount: string; currency: string; confirmedOn: string; provenance: string;
};
type Position = { id: string; contract_id: string; asset_id: string };
const day = (d: string) => /^\d{4}-\d{2}-\d{2}$/.test(d) && Number.isFinite(Date.parse(d)) && new Date(d).toISOString().slice(0, 10) === d;
const uuid = (id: string) => /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(id);
const next = (d: string) => new Date(Date.parse(d + "T12:00:00Z") + 86400000).toISOString().slice(0, 10);

// Bounded user evidence, never a current valuation or a fabricated capture.
// A known or explicitly unknown historical contract authority keeps priority.
export function projectConfirmedAmountPeriods(points: readonly ChartPoint[], contracts: readonly ChartContract[], sources: readonly HistoricalSource[], positions: readonly Position[], rates: readonly FxRateRecord[], now: string): ChartPoint[] {
  const periods = sources.filter(s => s.payload.kind === "confirmed_position_amount_period" && (!s.imported_at || Date.parse(s.imported_at) <= Date.parse(now))).map(source => {
    const p = source.payload as unknown as ConfirmedAmountPeriod;
    if (p.version !== 1 || !day(p.from) || !day(p.through) || !day(p.confirmedOn) || p.from > p.through || p.from !== source.business_date
      || p.through > p.confirmedOn || p.confirmedOn > parisDate(now) || ![p.contractId, p.positionId, p.assetId].every(uuid)
      || !/^\d{1,16}(?:\.\d{1,8})?$/.test(p.amount) || !Number.isFinite(Number(p.amount)) || !/^[A-Z]{3}$/.test(p.currency) || !p.provenance?.trim())
      throw Error("Preuve historique de montant invalide.");
    const c = contracts.find(c => c.id === p.contractId);
    const bindings = positions.filter(row => row.contract_id === p.contractId && row.asset_id === p.assetId);
    if (!c || c.envelopeTypeCode !== "assurance_vie" || c.valuationAuthority === "global" || c.openedOn && p.from < c.openedOn
      || bindings.length !== 1 || bindings[0].id !== p.positionId || !c.children.some(child => child.assetId === p.assetId && child.kind === "asset" && child.quantified === false))
      throw Error("Preuve historique incompatible avec le support en montant.");
    return p;
  });
  for (const p of periods) if (periods.some(q => q !== p && q.positionId === p.positionId && q.from <= p.through && q.through >= p.from))
    throw Error("Preuves historiques de montant concurrentes.");
  if (!periods.length) return points as ChartPoint[];
  const authorities = new Map(points.map(point => [point.date, point]));
  const result = new Map(authorities);
  for (const p of periods) for (let date = p.from; date <= p.through; date = next(date)) {
    const original = result.get(date), grossKey = `contract:${p.contractId}:gross`, key = `asset:${p.contractId}:${p.assetId}`;
    const authority = authorities.get(date);
    if (authority && (grossKey in authority.values || key in authority.values)) continue;
    const c = contracts.find(c => c.id === p.contractId)!;
    const point: ChartPoint = original ? structuredClone(original) : { date, values: {}, cash: {}, quantities: {}, contributions: {}, netKinds: {}, employeeSavingsCombined: null, provenance: p.provenance };
    const amount = convertToEur(p.amount, p.currency, latestFxRatesByCurrency([...rates], date).get(p.currency)).amountEur;
    point.values[key] = amount;
    point.quantities[key] = null;
    point.historicalUnitCosts = { ...point.historicalUnitCosts, [key]: null };
    point.amountTrackedIds = [...new Set([...(point.amountTrackedIds ?? []), key])];
    const values = c.children.map(child => point.values[child.id]);
    point.values[grossKey] = values.every(v => typeof v === "number" && Number.isFinite(v)) ? values.reduce<number>((sum, v) => sum + v!, 0) : null;
    point.values[`contract:${p.contractId}:net`] = null;
    point.netKinds[p.contractId] = "unavailable";
    point.valuationSourceDates = { ...point.valuationSourceDates, [key]: p.from, [`contract:${p.contractId}`]: p.from };
    point.continuityEvidence = { ...point.continuityEvidence, [p.contractId]: { sourceDate: p.from, throughDate: date } };
    point.provenanceByContract = { ...point.provenanceByContract, [p.contractId]: `${p.provenance} · montant du support confirmé du ${p.from} au ${p.through} · aucune quantité, PRU, espèce ou nouveau versement créé` };
    result.set(date, point);
  }
  return [...result.values()].sort((a, b) => a.date.localeCompare(b.date));
}
