export type LegacyDay = { businessDate: string; sourceValues: Record<string, unknown>; recalculatedGrossEur: number | null; legacyNetKind: "legacy_estimate"; employeeSavings: { scope: string; splitKnown: false } };
export type LegacySource = { sourceSha256: string; days: LegacyDay[]; mappingRequired: string[] };
export type LegacyMapping = { sourceKey: string; contractId?: string; openedOn?: string; name: string; envelopeTypeId: string; confirmed: boolean };
export type FunctionalLegacyMapping = { sourceKey: string; contractId: string; name: string };
export type FunctionalLegacyContract = {
  id: string;
  name: string;
  grossEur: number;
  netEstimatedEur: number | null;
  netKind?: "calculated" | "legacy_estimate" | "unavailable";
  legacyNetEur: number | null;
  manualSituationAt: null;
  manualSituationPrecision?: null;
  fiscalWarnings: string[];
  provenance: string;
};
function canonical(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, item]) => [key, canonical(item)]));
  return value;
}
export function planLegacyImport(source: LegacySource, mappings: LegacyMapping[], existing: Array<{ id: string; name: string }>, archived: Array<{ source_sha256: string; business_date: string; payload?: unknown }>) {
  if (!/^[a-f0-9]{64}$/.test(source.sourceSha256)) throw new Error("Invalid source fingerprint");
  if (new Set(source.days.map((d) => d.businessDate)).size !== source.days.length) throw new Error("Duplicate dates");
  const known = new Set(existing.map((c) => c.id));
  const ids = mappings.flatMap((m) => m.contractId ? [m.contractId] : []);
  if (new Set(ids).size !== ids.length) throw new Error("One existing contract mapped twice");
  const conflicts: string[] = [];
  const accounts = source.mappingRequired.flatMap((key) => {
    const entries = mappings.filter((m) => m.sourceKey === key);
    const mapping = entries[0];
    if (entries.length !== 1 || !mapping?.confirmed) { conflicts.push(`${key}: explicit reconciliation required`); return []; }
    if (mapping.contractId && !known.has(mapping.contractId)) { conflicts.push(`${key}: UUID unavailable`); return []; }
    if (!mapping.contractId && existing.some((c) => c.name.trim().toLocaleLowerCase("fr") === mapping.name.trim().toLocaleLowerCase("fr"))) { conflicts.push(`${key}: existing account requires explicit UUID`); return []; }
    if (!mapping.contractId && !mapping.openedOn) { conflicts.push(`${key}: opening date missing`); return []; }
    if (mapping.openedOn && (!/^\d{4}-\d{2}-\d{2}$/.test(mapping.openedOn) || new Date(mapping.openedOn).toISOString().slice(0, 10) !== mapping.openedOn)) throw new Error("Invalid opening date");
    if (!/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(mapping.envelopeTypeId) || !mapping.name.trim()) throw new Error("Invalid mapped account");
    return [{ ...mapping, operation: mapping.contractId ? "preserve_or_update" : "create" }];
  });
  const days = source.days.filter((day) => {
    const previous = archived.filter((r) => r.business_date === day.businessDate);
    if (previous.some((r) => r.source_sha256 !== source.sourceSha256)) { conflicts.push(`${day.businessDate}: different source already archived`); return false; }
    if (previous.some((r) => r.payload !== undefined && JSON.stringify(canonical(r.payload)) !== JSON.stringify(canonical(day)))) { conflicts.push(`${day.businessDate}: source extraction changed; explicit revision required`); return false; }
    return !previous.length;
  });
  return { accounts, days, conflicts, currentHoldingsChanged: false, flowsCreated: 0,
    note: "Historical evidence only; cumulative contributions are not dated flows; PEG/PER combined history is not a third live account." };
}

const SOURCE_VALUE_KEYS: Record<string, { gross: string; legacyNet?: string }> = {
  pea: { gross: "PEA Brut", legacyNet: "PEA Net" },
  cto: { gross: "CTO Brut", legacyNet: "CTO Net" },
  assurance_vie: { gross: "Assurance Vie" },
  ldds: { gross: "LDDS" },
  livret_a: { gross: "Livret A" },
};

function finiteNumber(value: unknown) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}

export function buildFunctionalLegacyHistory(day: LegacyDay & { sourceTotalDifferenceEur?: number | null; originalComponentDifferenceEur?: number | null; internalContractDifferencesEur?: { pea: number | null; cto: number | null }; realEstate?: { houseEur: number; apartmentEur: number; provenance: string }; ctoCoverage?: { state: string } }, mappings: FunctionalLegacyMapping[]) {
  const byKey = new Map(mappings.map((mapping) => [mapping.sourceKey, mapping]));
  const contracts: FunctionalLegacyContract[] = [];
  const append = (sourceKey: string, gross: number | null, legacyNet: number | null = null, provenance = "legacy_workbook") => {
    const mapping = byKey.get(sourceKey);
    if (!mapping || gross === null) return;
    const exempt = sourceKey === "livret_a" || sourceKey === "ldds";
    contracts.push({ id: mapping.contractId, name: mapping.name, grossEur: gross,
      netEstimatedEur: exempt ? gross : null, netKind: exempt ? "calculated" : legacyNet === null ? "unavailable" : "legacy_estimate", legacyNetEur: legacyNet, manualSituationAt: null,
      fiscalWarnings: exempt ? ["Produit exonéré identifié : net historique égal au brut connu."] : legacyNet === null ? ["Net historique non recalculé."] : ["Net historique estimé par l’ancien outil."],
      provenance });
  };
  for (const [sourceKey, keys] of Object.entries(SOURCE_VALUE_KEYS)) {
    if (sourceKey === "cto" && day.ctoCoverage?.state === "not_yet_open") continue;
    append(sourceKey, finiteNumber(day.sourceValues[keys.gross]), keys.legacyNet ? finiteNumber(day.sourceValues[keys.legacyNet]) : null);
  }
  const group = byKey.get("peg_per_history");
  const employeeSavings = finiteNumber(day.sourceValues["PEE Brut"]);
  if (group && employeeSavings !== null) contracts.push({ id: group.contractId, name: group.name,
    grossEur: employeeSavings, netEstimatedEur: null, legacyNetEur: null,
    manualSituationAt: null, fiscalWarnings: ["Historique PEG + PER COL non ventilé."], provenance: "legacy_workbook_combined" });
  if (day.realEstate) {
    append("house", finiteNumber(day.realEstate.houseEur), null, day.realEstate.provenance);
    append("apartment", finiteNumber(day.realEstate.apartmentEur), null, day.realEstate.provenance);
  }
  return {
    engineVersion: "patrimony-legacy-import-v1", businessDate: day.businessDate,
    capturedAt: `${day.businessDate}T23:59:59+02:00`,
    grossKind: day.recalculatedGrossEur === null ? "partial" : "complete", netKind: "legacy_estimate",
    report: { summary: { grossEur: day.recalculatedGrossEur }, contracts, assets: [] },
    legacy: { sourceTotalEur: finiteNumber(day.sourceValues.Total),
      sourceTotalDifferenceEur: day.sourceTotalDifferenceEur ?? null,
      originalComponentDifferenceEur: day.originalComponentDifferenceEur ?? null,
      internalContractDifferencesEur: day.internalContractDifferencesEur ?? { pea: null, cto: null },
      reliability: "legacy_partial", currentFiscalRulesApplied: false },
  };
}
