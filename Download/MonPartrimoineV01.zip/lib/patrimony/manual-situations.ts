import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { ManualSituation, ManualSimulation } from "@/lib/patrimony/manual-situation-core";
import {employeeSavingsValues} from "@/lib/patrimony/employee-savings-values";
import type {HistoricalSource} from "@/lib/patrimony/historical-observations";

export async function readManualSituations(client: Awaited<ReturnType<typeof createClient>>, userId: string,knownAt=new Date().toISOString(), selected?: readonly string[]) {
  const tables = ["contract_manual_situations", "contract_manual_simulations"] as const;
  const results = await Promise.all(tables.map((table) => {const query=client.from(table).select("*").eq("user_id", userId);return selected?query.in("contract_id",[...selected]):query;}));
  for (let i = 0; i < results.length; i++) {
    const error = results[i].error;
    if (error && !(["PGRST205", "42P01"].includes(error.code) && error.message.includes(tables[i]))) {
      throw new Error("Manual situations unavailable");
    }
  }
  if (results.every((result) => result.error)) return { available: false, manualSituations: [], manualSimulations: [] };
  if (results.some((result) => result.error)) throw new Error("Manual schema is partially available");
  const sources:HistoricalSource[]=[];
  for(let offset=0;;offset+=500){let query=client.from("patrimonial_legacy_sources").select("id,business_date,imported_at,payload").eq("user_id",userId).contains("payload",{kind:"approved_manual_gross_observation"}).order("id").range(offset,offset+499);if(selected)query=query.in("payload->>contractId",[...selected]);const result=await query;if(result.error)throw Error("Observations individuelles indisponibles");sources.push(...result.data);if(result.data.length<500)break;}
  const manualSituations=(results[0].data??[]) as ManualSituation[];
  const history=employeeSavingsValues(manualSituations,sources,knownAt);
  return { available: true, manualSituations, manualSimulations: (results[1].data ?? []) as ManualSimulation[],employeeSavingsValuations:history.effective,employeeSavingsArchives:history.archived };
}
