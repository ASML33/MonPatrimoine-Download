import { liquidSavingsTotalAt, selectDatedBalances, type DatedBalance } from "@/lib/cash/dated-balances";
import { convertToEur, latestFxRatesByCurrency, type FxRateRecord } from "@/lib/fx/fx-core";
import { historicalHoldingsFingerprint, type ChartContract, type ChartPoint } from "@/lib/patrimony/chart-core";

export type ArchivedBalance = DatedBalance & { snapshotDate: string; snapshotAt: string; authoritative?: boolean; fxRates?: FxRateRecord[] };
const parisDay = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Paris" });
// A newly recorded native history is not evidence that older captures were
// invalid. Check effective dates of both retained AND retired native proofs:
// moving/deleting an old observation must still retire its old date.
function beforeNativeProof(row: DatedBalance, date: string) {
  const dates: unknown[] = [row.as_of];
  const meta = row.metadata as Record<string, unknown> | undefined;
  if (meta && typeof meta === "object") {
    const history = meta.cash_balance_observations as { entries?: { asOf?: unknown }[]; archived?: { entries?: { asOf?: unknown }[] }[] } | undefined;
    for (const entry of history?.entries ?? []) dates.push(entry.asOf);
    for (const version of history?.archived ?? []) for (const entry of version.entries ?? []) dates.push(entry.asOf);
    if (Array.isArray(meta.cash_balance_corrections)) for (const correction of meta.cash_balance_corrections) {
      if (!correction || typeof correction !== "object" || !correction.submitted?.asOf) return false;
      dates.push(correction.submitted.asOf);
      if (correction.previous) dates.push(correction.previous.asOf);
    }
    if (meta.flow_cash_links && typeof meta.flow_cash_links === "object") for (const value of Object.values(meta.flow_cash_links)) {
      const link = value as { beforeEntries?: { asOf?: unknown }[]; afterEntries?: { asOf?: unknown }[] };
      if (!Array.isArray(link?.beforeEntries) || !Array.isArray(link?.afterEntries)) return false;
      for (const entry of [...link.beforeEntries, ...link.afterEntries]) dates.push(entry.asOf);
    }
  }
  return dates.every(value => typeof value === "string" && Number.isFinite(Date.parse(value)) && parisDay.format(new Date(value)) > date);
}
export function projectDatedCashBalances(points: readonly ChartPoint[], contracts: readonly ChartContract[], current: readonly DatedBalance[], archived: readonly ArchivedBalance[], rates: readonly FxRateRecord[]) {
  return points.map(original => {
    const applicable = selectDatedBalances(current, original.date);
    const point: ChartPoint = { ...original, cashProjectionBase: { ...original.cashProjectionBase }, values: { ...original.values }, quantities: { ...original.quantities }, cash: { ...original.cash }, netKinds: { ...original.netKinds }, sourceNets: { ...original.sourceNets }, netReasons: { ...original.netReasons }, provenanceByContract: { ...original.provenanceByContract } };
    const fx = latestFxRatesByCurrency([...rates], original.date);
    for (const contract of contracts) {
      const liquidTotal=contract.envelopeTypeCode === "epargne_liquide" ? liquidSavingsTotalAt(current,contract.id,original.date) : null;
      if (liquidTotal !== null) {
        const cashKey=`cash:${contract.id}`,grossKey=`contract:${contract.id}:gross`,netKey=`contract:${contract.id}:net`;
        if(typeof original.cash[cashKey]==='number') point.cashProjectionBase![contract.id] ??= {cashEur:original.cash[cashKey]!,grossEur:original.values[grossKey] ?? null,netEur:original.values[netKey] ?? null,netKind:original.netKinds[contract.id],provenance:original.provenanceByContract?.[contract.id]};
        for(const child of contract.children.filter(c=>c.kind==='asset')) { delete point.values[child.id]; delete point.quantities[child.id]; }
        point.cash[cashKey]=point.values[cashKey]=point.values[grossKey]=point.values[netKey]=liquidTotal;
        point.netKinds[contract.id]='calculated';delete point.netReasons![contract.id];
        point.declaredContractTotals={...point.declaredContractTotals};delete point.declaredContractTotals[contract.id];
        point.provenanceByContract![contract.id]='Solde total EUR daté · source historique conservée';
        continue;
      }
      if (contract.valuationAuthority === "global" || point.declaredContractTotals?.[contract.id]) continue;
      // Liquid savings are a cash-only total. Keep each archived source before
      // the first applicable native observation; overlay the dated native set
      // from its effect, rather than requiring a native split for every old CSV.
      if (contract.envelopeTypeCode === "epargne_liquide" && !contract.children.some(c => c.kind === "asset")) {
        const rows = current.filter(r => r.contract_id === contract.id);
        const selected = applicable.filter(r => r.contract_id === contract.id);
        const dated = rows.some(r => r.metadata && typeof r.metadata === "object" && "cash_balance_observations" in r.metadata);
        if (!dated || !selected.length) continue;
        const total = selected.reduce<number | null>((sum,r) => {
          const value = convertToEur(r.amount,r.currency_code,fx.get(r.currency_code)).amountEur;
          return sum === null || value === null ? null : sum + value;
        },0);
        const cashKey = `cash:${contract.id}`, grossKey = `contract:${contract.id}:gross`, netKey = `contract:${contract.id}:net`;
        point.cash[cashKey] = point.values[cashKey] = point.values[grossKey] = total;
        if (typeof original.values[netKey] === "number") point.sourceNets![contract.id] ??= original.values[netKey];
        // Existing liquid-savings policy is NET = known BRUT, including zero.
        point.values[netKey] = total;
        point.netKinds[contract.id] = total === null ? "unavailable" : "calculated";
        if (total === null) point.netReasons![contract.id] = "Conversion du solde daté indisponible.";
        else delete point.netReasons![contract.id];
        point.provenanceByContract![contract.id] = "Solde absolu daté · source historique conservée avant sa date d’effet";
        continue;
      }
      const key = `cash:${contract.id}`;
      const base = original.cashProjectionBase?.[contract.id];
      const before = base?.cashEur ?? original.cash[key];
      if (typeof before !== "number") continue; // Unknown is not a zero baseline.
      let delta = 0;
      let changed = false;
      let incomplete = false;
      const linkedCorrection = current.some(row => row.contract_id === contract.id && row.metadata && typeof row.metadata === "object" && Array.isArray((row.metadata as Record<string, unknown>).cash_balance_corrections));
      if (linkedCorrection) {
        const nativeRows = current.filter(row => row.contract_id === contract.id);
        if (nativeRows.every(row => beforeNativeProof(row, original.date))) continue;
        // Currency corrections preserve identities but may empty the source.
        // Compare complete, qualified native sets once, never add source+target deltas twice.
        const captured = selectDatedBalances(archived.filter(row => row.contract_id === contract.id && row.snapshotDate === original.date && row.authoritative !== false), original.date);
        // First journal adoption must retain the EUR legacy baseline already
        // qualified by the non-journal path below. A CSV date has no native
        // cash input of its own; a later flow does not retire that older proof.
        // No currency split, unknown amount or earlier observation is inferred.
        if (!captured.length && original.provenance === "Import historique" && nativeRows.length === 1
          && nativeRows[0].currency_code === "EUR"
          && (nativeRows[0].metadata as { securities_cash_actions?: { version?: number; known?: boolean } })?.securities_cash_actions?.version === 1
          && (nativeRows[0].metadata as { securities_cash_actions?: { known?: boolean } })?.securities_cash_actions?.known === true) {
          const old = archived.filter(version => version.id === nativeRows[0].id && version.contract_id === contract.id
            && version.currency_code === "EUR" && Number(version.amount) === before
            && parisDay.format(new Date(version.as_of)) <= original.date)
            .sort((a,b) => b.snapshotAt.localeCompare(a.snapshotAt))[0];
          if (old) captured.push(...selectDatedBalances([old], original.date));
        }
        const selected = applicable.filter(row => row.contract_id === contract.id);
        // A later observation of one currency cannot erase an older captured
        // component of that same identity while another currency is corrected.
        for (const old of captured) if (!selected.some(row => row.id === old.id && row.currency_code === old.currency_code)
          && nativeRows.some(row => row.id === old.id && row.currency_code === old.currency_code && beforeNativeProof(row, original.date))) selected.push(old);
        const capturedTotal = captured.reduce<number | null>((sum,row) => {
          const rate = row.fxRates === undefined ? fx : latestFxRatesByCurrency(row.fxRates, original.date);
          const value = convertToEur(row.amount,row.currency_code,rate.get(row.currency_code)).amountEur;
          return sum === null || value === null ? null : sum + value;
        }, captured.length ? 0 : null);
        changed = true;
        if (capturedTotal === null || Math.abs(capturedTotal-before)>0.000001 || !selected.length) incomplete = true;
        else {
          const total = selected.reduce<number | null>((sum,row) => {
            const old = captured.find(item => item.currency_code === row.currency_code);
            const available = old?.fxRates === undefined ? fx : latestFxRatesByCurrency(old.fxRates,original.date);
            const value = convertToEur(row.amount,row.currency_code,available.get(row.currency_code)).amountEur;
            return sum === null || value === null ? null : sum + value;
          },0);
          if (total === null) incomplete = true;
          else { delta = total-before; if (Math.abs(delta)<0.00000001) changed=false; }
        }
      } else {
      // A moved observation cannot remain effective solely because a capture
      // still contains its former day. Unknown cash is not an inferred zero.
      const applicableIds = new Set(applicable.filter(b => b.contract_id === contract.id).map(b => b.id));
      for (const row of current.filter(b => b.contract_id === contract.id && !applicableIds.has(b.id))) {
        if (beforeNativeProof(row, original.date)) continue;
        if (row.metadata && typeof row.metadata === "object" && "cash_balance_observations" in row.metadata
          && archived.some(old => old.id === row.id && old.contract_id === row.contract_id && old.snapshotDate === original.date)) {
          changed = true;
          incomplete = true;
        }
      }
      for (const row of applicable.filter(b => b.contract_id === contract.id)) {
        const candidates = archived.filter(old => old.id === row.id && old.contract_id === row.contract_id && old.snapshotDate === original.date && old.authoritative !== false);
        // Some legacy dates have only an authoritative EUR cash total. Match a
        // single known EUR observation exactly; never infer a multidevice split.
        const legacyCandidates = candidates.length ? [] : archived.filter(old => old.id === row.id && old.contract_id === row.contract_id && old.currency_code === "EUR" && row.currency_code === "EUR" && Number(old.amount) === before && new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Paris" }).format(new Date(old.as_of)) <= original.date);
        const old = [...(candidates.length ? candidates : legacyCandidates)].sort((a,b) => b.snapshotAt.localeCompare(a.snapshotAt))[0];
        if (!old) {
          const knownVersions = archived.filter(version => version.id === row.id && version.contract_id === row.contract_id);
          if (knownVersions.some(version => Number(version.amount) !== Number(row.amount) || version.currency_code !== row.currency_code || version.as_of !== row.as_of)) {
            changed = true;
            incomplete = true;
          }
          continue;
        }
        if (Number(old.amount) === Number(row.amount) && old.currency_code === row.currency_code) continue;
        changed = true;
        const capturedFx = old.fxRates === undefined ? fx : latestFxRatesByCurrency(old.fxRates, original.date);
        const oldEur = convertToEur(old.amount, old.currency_code, capturedFx.get(old.currency_code)).amountEur;
        const newRate = row.currency_code === old.currency_code ? capturedFx.get(row.currency_code) : fx.get(row.currency_code);
        const newEur = convertToEur(row.amount, row.currency_code, newRate).amountEur;
        if (oldEur === null || newEur === null) incomplete = true;
        else delta += newEur - oldEur;
      }
      }
      if (!changed) continue;
      const total = incomplete ? null : before + delta;
      const grossKey = `contract:${contract.id}:gross`;
      const netKey = `contract:${contract.id}:net`;
      const gross = base ? base.grossEur : original.values[grossKey];
      if (total !== null && total === original.cash[key] && typeof gross === "number" && original.values[grossKey] === gross + delta) continue;
      point.cashProjectionBase![contract.id] = base ?? { cashEur: before, grossEur: typeof gross === "number" ? gross : null, netEur: typeof original.values[netKey] === "number" ? original.values[netKey] : null, netKind: original.netKinds[contract.id], holdingsFingerprint: historicalHoldingsFingerprint(original,contract), provenance: original.provenanceByContract?.[contract.id] };
      point.cash[key] = point.values[key] = total;
      point.values[grossKey] = !incomplete && typeof gross === "number" ? gross + delta : null;
      if (typeof original.values[netKey] === "number") point.sourceNets![contract.id] ??= original.values[netKey];
      // A captured net describes the old gross. The existing fiscal projector
      // may estimate again using archived costs/dated flows, or qualify a cash-only
      // source NET projection with unchanged holdings and cash-independent bases.
      point.values[netKey] = null;
      point.netKinds[contract.id] = "unavailable";
      point.netReasons![contract.id] = incomplete ? "Base ou change historique des espèces indisponible." : "NET de la capture conservé ; estimation sur le solde corrigé à qualifier.";
      point.provenanceByContract![contract.id] = [point.cashProjectionBase![contract.id].provenance, `Correction de solde absolu datée projetée ; capture source conservée${incomplete ? " ; conversion EUR incomplète" : ""}`].filter(Boolean).join(" · ");
    }
    return point;
  });
}
