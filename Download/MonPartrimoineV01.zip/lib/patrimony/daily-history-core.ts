import { isContractInUserScope } from "@/lib/contracts/contract-scope";
import { buildPatrimonialReport, type PatrimonialReportRecords } from "@/lib/reports/patrimonial-report-core";
import {employeeSavingsValues} from "@/lib/patrimony/employee-savings-values";
import {contractFiscalBinding} from '@/lib/fiscal/contract-fiscal';
export const HISTORY_ENGINE_VERSION = "patrimony-history-v1";

export function buildDailyHistory(records: PatrimonialReportRecords, capturedAt: string, businessDate: string) {
  // No reconstruction: caller passes copied inputs from the capture's MVCC snapshot.
  if(records.envelopeFiscalities!==undefined){const report=buildPatrimonialReport({...records,...records.employeeSavingsSources?{employeeSavingsValuations:employeeSavingsValues(records.manualSituations??[],records.employeeSavingsSources,capturedAt).effective}:{}},capturedAt,businessDate);return {engineVersion:HISTORY_ENGINE_VERSION,businessDate,capturedAt,report,grossKind:report.contracts.some(c=>c.incompletePositions||c.incompleteCashBalances)?'partial':'complete',netKind:report.summary.netKind??'unavailable'};}
  const bindings=new Map(records.contracts.map(c=>[c.id,contractFiscalBinding(records.fiscalRules??[],c.fiscal_assignments,businessDate,records.userId??'',{regimeId:c.fiscal_regime_id??null,usePersonalRule:records.fiscalPreferences?.some(p=>p.fiscalRegimeId===c.fiscal_regime_id&&p.usePersonalRule)??false,context:{fiscalStartedOn:c.fiscal_started_on??null,historyComplete:c.fiscal_history_complete===true,socialContributionsPaidEur:c.social_contributions_paid_eur==null?null:Number(c.social_contributions_paid_eur)}})]));
  const sharedRuleIds=new Set([...bindings.values()].filter(b=>b.rule?.irAllowanceScope==='household_annual').map(b=>b.rule!.id));
  const report = buildPatrimonialReport({ ...records,...records.employeeSavingsSources?{employeeSavingsValuations:employeeSavingsValues(records.manualSituations??[],records.employeeSavingsSources,capturedAt).effective}:{}, fiscalRules: records.fiscalRules?.filter((r) => !sharedRuleIds.has(r.id)) }, capturedAt, businessDate);
  for (const original of records.contracts) {
    const binding=bindings.get(original.id)!;
    if (!binding.rule || !sharedRuleIds.has(binding.rule.id)) continue;
    const contract = report.contracts.find((c) => c.id === original.id);
    if (contract && original.valuation_source !== "manual_situation") {
      contract.netEstimatedEur = null;
      if(original.fiscal_assignments)contract.fiscalSelection={ruleId:binding.rule.id,regimeId:binding.regimeId,assignmentId:binding.assignment?.id??null,assignmentDate:binding.assignment?.date??null,origin:binding.origin,context:binding.context};
      contract.netKind = "unavailable";
      contract.fiscalWarnings = ["Règle annuelle partagée : additivité non prise en charge par l’historique."];
      report.summary.netEstimatedEur = null;
      report.summary.netKind = "unavailable";
      report.summary.grossNetDifferenceEur = null;
    }
  }
  return { engineVersion: HISTORY_ENGINE_VERSION, businessDate, capturedAt, report,
    grossKind: report.contracts.some((c) => c.incompletePositions || c.incompleteCashBalances) ? "partial" : "complete",
    netKind: report.summary.netKind ?? "unavailable" };
}

export function selectHistoricalContracts(result: ReturnType<typeof buildDailyHistory>, selectedIds: string[]) {
  // Contract leaves only. Never add an envelope aggregate to its own children.
  const selected = new Set(selectedIds.filter(isContractInUserScope));
  const contracts = result.report.contracts.filter((c) => selected.has(c.id));
  const shared = contracts.some((c) => c.fiscalNonAdditive === true);
  const complete = contracts.length > 0 && contracts.length === selected.size && !shared && contracts.every((c) => c.netEstimatedEur !== null);
  return { contracts, grossEur: contracts.length ? contracts.reduce((sum, c) => sum + c.grossEur, 0) : null,
    netEstimatedEur: complete ? contracts.reduce((sum, c) => sum + c.netEstimatedEur!, 0) : null,
    netKind: !complete ? "unavailable" : contracts.some((c) => c.netKind === "approximate") ? "approximate" : "calculated",
    reason: shared ? "Additivité fiscale non garantie pour cette sélection." : null };
}

export function selectHistoricalAssets(result: ReturnType<typeof buildDailyHistory>, selectedIds: string[]) {
  const selected = new Set(selectedIds);
  const assets = result.report.assets.filter((asset) => selected.has(asset.id));
  return { assets, grossEur: assets.length ? assets.reduce((sum, a) => sum + (a.valueEur ?? 0), 0) : null,
    grossKind: assets.length !== selected.size || assets.some((a) => a.valueEur === null) ? "partial" : "complete",
    netEstimatedEur: null, reason: "La fiscalité du contrat n’est pas répartie entre ses actifs." };
}
