import { parisBusinessDate as parisDate } from "@/lib/dates/business-date";
import { latestFxRatesByCurrency, type FxRateRecord } from "@/lib/fx/fx-core";

export const STALE_THRESHOLD_DAYS = 7;

export type CurrentValuationAsset = {
  id: string;
  valuation_mode: string;
};

export type CurrentValuationPrice = {
  asset_id: string;
  origin: "automatic" | "manual";
  price: number | string;
  currency_code: string;
  observed_at: string;
  obtained_at?: string;
  source_name?: string | null;
};

export type CurrentPositionSnapshot = {
  position_id: string;
  market_value: number | string;
  currency_code: string;
  valued_at: string;
};

function validTimestamp(value: string) {
  const timestamp = Date.parse(value);
  return Number.isFinite(timestamp) ? timestamp : null;
}

export { parisBusinessDate as parisDate } from "@/lib/dates/business-date";

export function selectLatestUsablePrices<T extends CurrentValuationPrice>(
  assets: CurrentValuationAsset[],
  prices: T[],
  now = new Date().toISOString(),
) {
  const assetById = new Map(assets.map((asset) => [asset.id, asset]));
  const latest = new Map<string, T>();
  const nowTimestamp = Date.parse(now);
  for (const price of prices) {
    const asset = assetById.get(price.asset_id);
    const observedTimestamp = validTimestamp(price.observed_at);
    if (!asset || observedTimestamp === null || observedTimestamp > nowTimestamp || Number(price.price) <= 0) continue;
    const expectedOrigin = asset.valuation_mode === "manual" ? "manual" : "automatic";
    if (price.origin !== expectedOrigin) continue;
    const existing = latest.get(price.asset_id);
    if (!existing) {
      latest.set(price.asset_id, price);
      continue;
    }
    const existingObserved = Date.parse(existing.observed_at);
    const existingObtained = validTimestamp(existing.obtained_at ?? "") ?? 0;
    const candidateObtained = validTimestamp(price.obtained_at ?? "") ?? 0;
    if (observedTimestamp > existingObserved
      || (observedTimestamp === existingObserved && candidateObtained > existingObtained)) {
      latest.set(price.asset_id, price);
    }
  }
  return latest;
}

export function selectLatestPositionSnapshots<T extends CurrentPositionSnapshot>(
  snapshots: T[],
  now = new Date().toISOString(),
) {
  const latest = new Map<string, T>();
  const nowTimestamp = Date.parse(now);
  for (const snapshot of snapshots) {
    const timestamp = validTimestamp(snapshot.valued_at);
    if (timestamp === null || timestamp > nowTimestamp || Number(snapshot.market_value) < 0) continue;
    const existing = latest.get(snapshot.position_id);
    if (!existing || timestamp > Date.parse(existing.valued_at)) latest.set(snapshot.position_id, snapshot);
  }
  return latest;
}

export function selectLatestFxRates(rates: FxRateRecord[], now = new Date().toISOString()) {
  return latestFxRatesByCurrency(rates, parisDate(now));
}

export function freshnessAgeDays(value: string, now = new Date().toISOString()) {
  const timestamp = validTimestamp(value);
  const nowTimestamp = validTimestamp(now);
  if (timestamp === null || nowTimestamp === null) return null;
  return Math.max(0, Math.floor((nowTimestamp - timestamp) / 86_400_000));
}

export function isStale(value: string, now = new Date().toISOString(), thresholdDays = STALE_THRESHOLD_DAYS) {
  const ageDays = freshnessAgeDays(value, now);
  return ageDays !== null && ageDays > thresholdDays;
}
