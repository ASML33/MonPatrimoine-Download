export const MANUAL_NET_NOTICE = "Net approximatif — IR supposé exonéré, PS sur la plus-value fiscale renseignée. Compartiments et particularités fiscales historiques non pris en compte.";

export type ManualSituation = {
  valuation_revision?: import("./employee-savings-values").ValuationRevision | null;
  id: string; contract_id: string; situated_at: string; recorded_at: string;
  source_time_precision?: "exact" | "date" | "evening";
  gross_eur: number | string; fiscal_gain_eur: number | string | null;
  source_net_eur: number | string | null; source: string;
};
export type ManualSimulation = {
  id: string; contract_id: string; version: number; effective_from: string;
  ps_rate: number | string; created_at: string;
};

export function manualEstimate(situation: ManualSituation | null, simulation: ManualSimulation | null) {
  const rawGross = situation === null ? null : Number(situation.gross_eur);
  const gross = rawGross !== null && Number.isFinite(rawGross) && rawGross >= 0 ? rawGross : null;
  const gain = situation?.fiscal_gain_eur == null ? null : Number(situation.fiscal_gain_eur);
  const rate = simulation === null ? null : Number(simulation.ps_rate);
  const valid = gross !== null && Number.isFinite(gross) && gross >= 0 && gain !== null
    && Number.isFinite(gain) && rate !== null && Number.isFinite(rate) && rate >= 0 && rate <= 1;
  return {
    grossEur: gross, fiscalGainEur: gain, psRate: rate,
    psEur: valid ? Math.max(gain!, 0) * rate! : null,
    netEstimatedEur: valid ? gross! - Math.max(gain!, 0) * rate! : null,
    netKind: valid ? "approximate" as const : "unavailable" as const,
    sourceNetEur: situation?.source_net_eur == null ? null : Number(situation.source_net_eur),
    notice: MANUAL_NET_NOTICE,
    reason: valid ? null : "Situation brute, plus-value fiscale ou configuration personnelle manquante.",
  };
}

export function selectManualSituation(rows: ManualSituation[], contractId: string, at: string) {
  return rows.filter((row) => row.contract_id === contractId && Date.parse(row.situated_at) <= Date.parse(at) && Date.parse(row.recorded_at) <= Date.parse(at))
    .sort((a, b) => Date.parse(b.situated_at) - Date.parse(a.situated_at) || Date.parse(b.recorded_at) - Date.parse(a.recorded_at))[0] ?? null;
}

export function selectManualSimulation(rows: ManualSimulation[], contractId: string, date: string, knownAt: string) {
  return rows.filter((row) => row.contract_id === contractId && row.effective_from <= date && Date.parse(row.created_at) <= Date.parse(knownAt))
    .sort((a, b) => b.effective_from.localeCompare(a.effective_from) || b.version - a.version)[0] ?? null;
}

export function validateManualSituation(form: FormData) {
  const number = (name: string, signed = false) => {
    const text = String(form.get(name) ?? "").trim().replace(",", ".");
    if (!text) return null;
    if (!(signed ? /^-?\d+(?:\.\d{1,8})?$/ : /^\d+(?:\.\d{1,8})?$/).test(text)) throw new Error("Montant invalide.");
    const value = Number(text);
    if (!Number.isFinite(value)) throw new Error("Montant invalide.");
    return value;
  };
  const gross = number("gross_eur");
  const gain = number("fiscal_gain_eur", true);
  const sourceNet = number("source_net_eur");
  const rate = number("ps_percent");
  if (gross === null || (rate !== null && rate > 100)) throw new Error("Brut et taux valides requis.");
  if (form.get("confirm") !== "on") throw new Error("Confirmez la situation et l’hypothèse personnelle.");
  return { gross, gain, sourceNet, rate: rate === null ? null : Number((rate / 100).toFixed(10)) };
}
