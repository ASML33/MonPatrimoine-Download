import type { ChartContract, ChartPoint } from "./chart-core";
import { selectHistoricalObservations, type HistoricalObservation, type HistoricalSource } from "./historical-observations";
import { latestFxRatesByCurrency, type FxRateRecord } from "@/lib/fx/fx-core";
import { parisDate } from "./current-valuation-core";

export const CTO_FX_RECOVERY_KIND = "approved_cto_historical_fx_recovery";
const object = (v: unknown): Record<string, unknown> => v !== null && typeof v === "object" && !Array.isArray(v) ? v as Record<string, unknown> : {};
const numeric = (v: unknown) => v !== null && v !== undefined && String(v).trim() !== "" && Number.isFinite(Number(v)) ? Number(v) : null;
const records = (v: unknown) => Array.isArray(v) ? v.map(object) : [];
const canonical = (v: unknown) => JSON.stringify(v, (_key,value: unknown) => value !== null && typeof value === "object" && !Array.isArray(value)
  ? Object.fromEntries(Object.entries(value).sort(([a],[b]) => a.localeCompare(b,"en"))) : value);

// Exact archived inputs, not today's position, quote, PRU or FX. The approval
// binds the native capture and cannot silently survive a different revision.
export function ctoFxCaptureBinding(capture: HistoricalObservation, contractId: string) {
  const positions = records(object(capture.inputs).positions).filter(p => p.contract_id === contractId).map(p => ({
    id: p.id, assetId: p.asset_id, quantity: numeric(p.quantity), cost: numeric(p.average_cost_per_unit), currency: p.cost_currency_code, active: p.is_active,
  })).sort((a,b) => String(a.id).localeCompare(String(b.id)));
  return {
    contractId, captureId: capture.id, businessDate: capture.business_date,
    revision: capture.revision, capturedAt: capture.captured_at,
    positions,
    quotes: records(capture.result.report.assets).filter(a => positions.some(p => p.assetId === a.id)).map(a => ({
      assetId: a.id, price: numeric(a.currentPrice), currency: a.priceCurrencyCode, observedAt: a.priceObservedAt, obtainedAt: a.priceObtainedAt, valueEur: numeric(a.valueEur),
    })).sort((a,b) => String(a.assetId).localeCompare(String(b.assetId))),
  };
}

export type CtoFxRecovery = {
  kind: typeof CTO_FX_RECOVERY_KIND; version: 1; contractId: string; businessDate: string;
  currentValuationOverride: false; baseline: ReturnType<typeof ctoFxCaptureBinding>;
  rate: { source: "ecb"; base: "EUR"; currency: "USD"; unit: 1; nativePerEur: string; eurPerUnit: string; observedOn: string; url: string; retrievedAt: string };
};

// An approved, user-scoped source row supplies a missing reference only. No
// capture, position, flow, receipt, FX history or fiscal declaration is changed.
export function projectCtoHistoricalFxRecovery(points: readonly ChartPoint[], contracts: readonly ChartContract[], captures: readonly HistoricalObservation[], sources: readonly HistoricalSource[]): ChartPoint[] {
  const approvals = sources.filter(s => s.payload.kind === CTO_FX_RECOVERY_KIND);
  if (!approvals.length) return points as ChartPoint[];
  const selected = new Map(selectHistoricalObservations(captures).map(g => [g.date, g.selected]));
  const result = new Map(points.map(point => [point.date, point]));
  const seen = new Set<string>();
  for (const source of approvals) {
    const p = source.payload as unknown as CtoFxRecovery, c = contracts.find(c => c.id === p.contractId);
    if (!c) continue;
    const fail = () => { throw Error("Référence FX historique CTO incompatible avec ses preuves datées."); };
    const capture = captures.find(capture => capture.id === p.baseline?.captureId && capture.business_date === source.business_date);
    const authority = selected.get(source.business_date), previous = result.get(source.business_date), r = p.rate;
    const key = `${p.contractId}:${source.business_date}`;
    if (seen.has(key)) fail(); seen.add(key);
    if (p.version !== 1 || p.businessDate !== source.business_date || p.currentValuationOverride !== false
      || c.envelopeTypeCode !== "cto" || c.valuationAuthority === "global" || !capture || !previous
      || capture.result.engineVersion !== "patrimony-history-v1"
      || canonical(p.baseline) !== canonical(ctoFxCaptureBinding(capture,p.contractId))
      || !r || r.source !== "ecb" || r.base !== "EUR" || r.currency !== "USD" || r.unit !== 1
      || !/^\d{4}-\d{2}-\d{2}$/.test(r.observedOn) || r.observedOn > p.businessDate
      || !Number.isFinite(Date.parse(r.retrievedAt)) || !/^https:\/\/(?:www\.)?(?:ecb\.europa\.eu|banque-france\.fr)\//.test(r.url)
      || !(Number(r.nativePerEur) > 0) || !(Number(r.eurPerUnit) > 0)
      || Math.abs(Number(r.nativePerEur)*Number(r.eurPerUnit)-1) > 1e-12) fail();
    const day = new Date(p.businessDate+"T12:00Z").getUTCDay(), lag = (Date.parse(p.businessDate)-Date.parse(r.observedOn))/86400000;
    if (lag !== (day === 6 ? 1 : day === 0 ? 2 : 0)) fail();
    const grossKey = `contract:${c.id}:gross`;
    // Known authorities and later independent corrections remain untouched.
    // A different selected capture does not inherit this old capture's proof.
    if (authority?.id !== capture!.id || authority.revision !== capture!.revision) continue;
    if (typeof previous!.values[grossKey] === "number") continue;
    if (Object.keys(previous!.holdingObservationEvidence ?? {}).some(id => id.split(":")[1] === c.id)) continue;
    const binding = p.baseline, held = binding.positions.filter(position => position.active === true && position.quantity !== null && position.quantity > 0);
    // A later added/removed title does not redefine this dated inventory.
    // Proven absence is harmless; an uncovered holding keeps native unknowns.
    if (held.some(position => !c.children.some(child => child.assetId === position.assetId))
      || c.children.some(child => child.kind === "asset" && previous!.quantities[child.id] !== 0 && !held.some(position => position.assetId === child.assetId))) continue;
    if (held.some(position => previous!.quantities[c.children.find(child => child.assetId === position.assetId)!.id] !== position.quantity)) fail();
    const capturedContract = object(capture!.result.report.contracts.find(item => item.id === c.id));
    if (!held.length || numeric(capturedContract.incompletePositions) !== held.length
      || numeric(capturedContract.incompleteCashBalances) !== 0) fail();
    const capturedInputs = object(capture!.inputs);
    const capturedFx = latestFxRatesByCurrency([...records(capturedInputs.currentFxRates),...records(capturedInputs.historicalFxRates)] as FxRateRecord[],p.businessDate);
    if (capturedFx.has(r.currency)) fail();
    const values = { ...previous!.values };
    for (const child of c.children) {
      if (child.kind === "cash") { if (!Number.isFinite(previous!.cash[child.id])) fail(); values[child.id] = previous!.cash[child.id]; continue; }
      if (previous!.quantities[child.id] === 0) { values[child.id] = 0; continue; }
      const positions = binding.positions.filter(position => position.assetId === child.assetId && position.active === true);
      if (positions.length !== 1) fail();
      const position = positions[0], quotes = binding.quotes.filter(q => q.assetId === child.assetId);
      if (position.quantity === null || position.quantity < 0 || previous!.quantities[child.id] !== position.quantity
        || position.cost === null || position.cost < 0 || position.currency !== "EUR" || previous!.historicalUnitCosts?.[child.id] !== position.cost
        || previous!.values[child.id] != null || quotes.length !== 1) fail();
      const quote = quotes[0];
      if (quote.valueEur !== null || quote.price === null || quote.price < 0 || quote.currency !== r.currency || typeof quote.observedAt !== "string" || typeof quote.obtainedAt !== "string"
        || !Number.isFinite(Date.parse(quote.observedAt)) || !Number.isFinite(Date.parse(quote.obtainedAt))
        || parisDate(quote.observedAt as string) > p.businessDate || Date.parse(quote.obtainedAt as string) > Date.parse(capture!.captured_at)) fail();
      values[child.id] = position.quantity! * quote.price! * Number(r.eurPerUnit);
    }
    if (!c.children.length || !c.children.every(child => typeof values[child.id] === "number" && Number.isFinite(values[child.id]))) fail();
    values[grossKey] = c.children.reduce((sum,child) => sum + values[child.id]!,0);
    result.set(p.businessDate, { ...previous!, values, provenanceByContract: { ...previous!.provenanceByContract,
      [c.id]: [previous!.provenanceByContract?.[c.id],`FX historique BCE récupéré : 1 EUR = ${r.nativePerEur} USD, référence du ${r.observedOn} · ${r.url} · obtenu ${r.retrievedAt} · preuve ${source.id} liée à la capture ${capture!.id} intacte`].filter(Boolean).join(" · ") } });
  }
  return [...result.values()];
}
