import "server-only";

import { createAdminClient } from "@/lib/supabase/admin";

export async function resolveNicknameToAuthEmail(nickname: string) {
  const admin = createAdminClient();
  const { data: profile, error: profileError } = await admin
    .from("profiles")
    .select("auth_user_id")
    .eq("nickname", nickname)
    .maybeSingle();

  if (profileError) throw new Error("Authentication lookup failed.");
  if (!profile) return null;

  const { data, error } = await admin.auth.admin.getUserById(
    profile.auth_user_id,
  );
  if (error) throw new Error("Authentication lookup failed.");

  return data.user.email?.toLowerCase() ?? null;
}
