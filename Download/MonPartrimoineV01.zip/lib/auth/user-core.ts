import { isAuthSessionMissingError, type User } from "@supabase/supabase-js";

export type AuthUserReader = () => Promise<{
  data: { user: User | null };
  error: unknown;
}>;

export class AuthenticationRequiredError extends Error {
  constructor() {
    super("Authentication required.");
    this.name = "AuthenticationRequiredError";
  }
}

export function createUserAuth(readUser: AuthUserReader) {
  async function getCurrentUser(): Promise<User | null> {
    const { data, error } = await readUser();

    if (error) {
      if (isAuthSessionMissingError(error)) {
        return null;
      }

      throw error;
    }

    if (!data.user) {
      throw new Error("Supabase Auth returned no user without an error.");
    }

    return data.user;
  }

  async function requireUser(): Promise<User> {
    const user = await getCurrentUser();

    if (!user) {
      throw new AuthenticationRequiredError();
    }

    return user;
  }

  return { getCurrentUser, requireUser };
}
