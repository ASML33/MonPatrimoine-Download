type ProtectedUser = { id: string };

type ProtectedRouteDecision = {
  status: 200 | 401 | 403 | 503;
  body:
    | { authenticated: true; authorized: true }
    | { error: "authentication_required" | "forbidden" | "service_unavailable" };
};

export async function evaluateProtectedRoute(
  loadUser: () => Promise<ProtectedUser | null>,
  expectedUserId: string,
): Promise<ProtectedRouteDecision> {
  try {
    const user = await loadUser();

    if (!user) {
      return { status: 401, body: { error: "authentication_required" } };
    }

    if (user.id !== expectedUserId) {
      return { status: 403, body: { error: "forbidden" } };
    }

    return {
      status: 200,
      body: { authenticated: true, authorized: true },
    };
  } catch {
    return { status: 503, body: { error: "service_unavailable" } };
  }
}
