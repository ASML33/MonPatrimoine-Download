import "server-only";

import { createUserAuth } from "@/lib/auth/user-core";
import { createClient } from "@/lib/supabase/server";

export { AuthenticationRequiredError } from "@/lib/auth/user-core";

export class ApplicationAccessDeniedError extends Error {
  constructor() {
    super("Application access denied.");
    this.name = "ApplicationAccessDeniedError";
  }
}

const productionUserAuth = createUserAuth(async () => {
  const supabase = await createClient();
  const result = await supabase.auth.getUser();
  if (result.error || !result.data.user) return result;
  const { data, error } = await supabase.rpc("is_authorized_user");
  if (error) throw new Error("Application access could not be verified.");
  if (data !== true) throw new ApplicationAccessDeniedError();
  return result;
});

export async function getCurrentUser() {
  return productionUserAuth.getCurrentUser();
}

export async function requireUser() {
  return productionUserAuth.requireUser();
}
