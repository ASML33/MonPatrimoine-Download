import "server-only";

import { cache } from "react";
import { createCurrentProfileReader } from "@/lib/auth/profile-core";
import { AuthenticationRequiredError, getCurrentUser } from "@/lib/auth/user";
import { asSettingsRecord, type ProfileSettingsDocuments } from "@/lib/settings/settings-core";
import { createClient } from "@/lib/supabase/server";
import { sharedNavigationRead } from "@/lib/navigation/read-scope";

// React owns this cache for one server render. Mutations keep their uncached
// Auth/profile readers, including checks performed after changing a session.
const getRenderUser = cache(() => sharedNavigationRead("render-user", getCurrentUser));

export async function requireRenderUser() {
  const user = await getRenderUser();
  if (!user) throw new AuthenticationRequiredError();
  return user;
}

export const getPageProfile = cache(async (includeStrategy = false) => {
  let documents: ProfileSettingsDocuments = {
    preferences: {}, interface_preferences: {}, strategy_parameters: {},
  };
  const current = await createCurrentProfileReader(getRenderUser, async (userId) => {
    const supabase = await createClient();
    const query = includeStrategy
      ? supabase.from("profiles").select("id, auth_user_id, nickname, email, role, is_active, preferences, interface_preferences, strategy_parameters")
      : supabase.from("profiles").select("id, auth_user_id, nickname, email, role, is_active, preferences, interface_preferences");
    const { data, error } = await query
      .eq("auth_user_id", userId)
      .maybeSingle();
    if (!data || error) return { data, error };
    const row: Record<string, unknown> = data;
    const { preferences, interface_preferences, strategy_parameters, ...identity } = row;
    documents = {
      preferences: asSettingsRecord(preferences),
      interface_preferences: asSettingsRecord(interface_preferences),
      strategy_parameters: asSettingsRecord(strategy_parameters),
    };
    return { data: identity, error };
  })();
  return { current, documents };
});
