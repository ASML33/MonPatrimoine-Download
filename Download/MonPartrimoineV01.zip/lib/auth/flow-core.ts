export const INVALID_CREDENTIALS_MESSAGE =
  "Identifiant ou mot de passe incorrect.";
export const RECOVERY_RESPONSE_MESSAGE =
  "Si un compte correspondant existe, un e-mail de récupération a été envoyé.";
export const AUTH_SERVICE_ERROR_MESSAGE =
  "Le service d’authentification est momentanément indisponible.";

export type AuthActionState = {
  status: "idle" | "error" | "success";
  message?: string;
};

export function normalizeIdentifier(value: string) {
  return value.trim().toLowerCase();
}

export function getIdentifierKind(identifier: string): "email" | "nickname" {
  return identifier.includes("@") ? "email" : "nickname";
}

type LoginDependencies = {
  resolveNickname: (nickname: string) => Promise<string | null>;
  signIn: (email: string, password: string) => Promise<boolean>;
  hasProfile: () => Promise<boolean>;
  signOut: () => Promise<void>;
};

export async function authenticateWithIdentifier(
  rawIdentifier: string,
  password: string,
  dependencies: LoginDependencies,
) {
  const identifier = normalizeIdentifier(rawIdentifier);
  if (!identifier || !password) return false;

  const resolvedEmail =
    getIdentifierKind(identifier) === "email"
      ? identifier
      : await dependencies.resolveNickname(identifier);

  // Keep unknown identifiers on the same Auth path as invalid passwords.
  const email = resolvedEmail ?? "unknown-login@invalid.local";
  if (!(await dependencies.signIn(email.toLowerCase(), password))) return false;

  if (!(await dependencies.hasProfile())) {
    await dependencies.signOut();
    return false;
  }

  return true;
}

type RecoveryDependencies = {
  resolveNickname: (nickname: string) => Promise<string | null>;
  requestReset: (email: string) => Promise<void>;
};

export async function requestRecoveryWithIdentifier(
  rawIdentifier: string,
  dependencies: RecoveryDependencies,
) {
  const identifier = normalizeIdentifier(rawIdentifier);
  const resolvedEmail =
    identifier && getIdentifierKind(identifier) === "email"
      ? identifier
      : identifier
        ? await dependencies.resolveNickname(identifier)
        : null;

  await dependencies.requestReset(
    (resolvedEmail ?? "unknown-recovery@invalid.local").toLowerCase(),
  );
}

export async function performLogout(signOut: () => Promise<unknown>) {
  await signOut();
}

export function needsLogin(userPresent: boolean) {
  return !userPresent;
}
