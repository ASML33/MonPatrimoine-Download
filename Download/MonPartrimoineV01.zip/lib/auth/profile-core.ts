export type CurrentProfile = {
  id: string;
  auth_user_id: string;
  nickname: string;
  email: string;
  role: "user" | "admin";
  is_active: boolean;
};

export type CurrentProfileResult =
  | { status: "unauthenticated" }
  | { status: "profile_missing" }
  | {
      status: "active" | "inactive";
      profile: CurrentProfile;
      nonCanonicalFields: ("nickname" | "email")[];
    };

export class CurrentProfileError extends Error {
  constructor() {
    super("Current profile could not be loaded.");
    this.name = "CurrentProfileError";
  }
}

function isProfile(value: unknown): value is CurrentProfile {
  if (typeof value !== "object" || value === null) return false;
  const profile = value as Record<string, unknown>;
  return (
    typeof profile.id === "string" &&
    typeof profile.auth_user_id === "string" &&
    typeof profile.nickname === "string" &&
    typeof profile.email === "string" &&
    (profile.role === "user" || profile.role === "admin") &&
    typeof profile.is_active === "boolean"
  );
}

export function createCurrentProfileReader(
  readUser: () => Promise<{ id: string } | null>,
  readProfile: (authUserId: string) => Promise<{ data: unknown; error: unknown }>,
) {
  return async function getCurrentProfile(): Promise<CurrentProfileResult> {
    try {
      const user = await readUser();
      if (!user) return { status: "unauthenticated" };

      const { data, error } = await readProfile(user.id);
      if (error) throw new CurrentProfileError();
      if (data === null) return { status: "profile_missing" };
      if (!isProfile(data) || data.auth_user_id !== user.id) {
        throw new CurrentProfileError();
      }

      // Report legacy casing without concealing or rewriting stored values.
      const nonCanonicalFields: ("nickname" | "email")[] = [];
      for (const field of ["nickname", "email"] as const) {
        if (data[field] !== data[field].toLowerCase()) {
          nonCanonicalFields.push(field);
        }
      }

      return {
        status: data.is_active ? "active" : "inactive",
        profile: data,
        nonCanonicalFields,
      };
    } catch {
      // Do not forward Auth/PostgREST errors or attach their sensitive payloads.
      throw new CurrentProfileError();
    }
  };
}
