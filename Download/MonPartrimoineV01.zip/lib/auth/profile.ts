import "server-only";

import { createCurrentProfileReader } from "@/lib/auth/profile-core";
import { getCurrentUser } from "@/lib/auth/user";
import { createClient } from "@/lib/supabase/server";

export { CurrentProfileError } from "@/lib/auth/profile-core";
export type { CurrentProfile, CurrentProfileResult } from "@/lib/auth/profile-core";

export const getCurrentProfile = createCurrentProfileReader(
  getCurrentUser,
  async (authUserId) => {
    const supabase = await createClient();
    return supabase
      .from("profiles")
      .select("id, auth_user_id, nickname, email, role, is_active")
      .eq("auth_user_id", authUserId)
      .maybeSingle();
  },
);
