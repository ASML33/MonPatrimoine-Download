import "server-only";

export function isStructuredPdf(bytes: Buffer) {
  // Inspect structural markers and the final cross-reference pointer without
  // rendering pages, inflating streams or executing any embedded content.
  const text = bytes.toString("latin1");
  if (!/^%PDF-(?:1\.[0-7]|2\.0)(?:\r|\n)/.test(text)) return false;

  const ending = text.slice(-1024).match(
    /(?:\r\n?|\n)startxref[\t \r\n]+([0-9]{1,7})[\t \r\n]+%%EOF[\x00\t\n\f\r ]*$/,
  );
  if (!ending || ending.index === undefined) return false;
  const offset = Number(ending[1]);
  const pointer = Math.max(0, text.length - 1024) + ending.index;
  if (offset < 9 || offset >= pointer) return false;

  const xref = text.slice(offset, Math.min(offset + 128, pointer));
  if (/^xref[\t \r\n]+\d+[\t ]+[1-9]\d*[\t ]*(?:\r\n?|\n)\d{10} \d{5} [fn][\t ]*(?:\r|\n)/.test(xref)) {
    const trailer = text.lastIndexOf("trailer", pointer);
    if (trailer <= offset) return false;
    const dictionary = text.slice(trailer + "trailer".length, pointer).trim();
    return dictionary.startsWith("<<") && dictionary.endsWith(">>") &&
      /\/Size[\t \r\n]+\d+/.test(dictionary) &&
      /(?:\/Root[\t \r\n]+\d+[\t \r\n]+\d+[\t \r\n]+R\b|\/Prev[\t \r\n]+\d+)/.test(dictionary);
  }

  const object = text.slice(offset, Math.min(offset + 8192, pointer));
  if (!/^\d+[\t ]+\d+[\t ]+obj[\s]*<</.test(object)) return false;
  const stream = object.search(/(?:\r\n?|\n)stream(?:\r\n?|\n)/);
  if (stream < 0) return false;
  const dictionary = object.slice(0, stream);
  return /\/Type[\t \r\n]*\/XRef\b/.test(dictionary) &&
    /\/W[\t \r\n]*\[/.test(dictionary) &&
    /\/Size[\t \r\n]+\d+/.test(dictionary) &&
    /(?:\/Root[\t \r\n]+\d+[\t \r\n]+\d+[\t \r\n]+R\b|\/Prev[\t \r\n]+\d+)/.test(dictionary) &&
    /(?:\r\n?|\n)endstream[\t \r\n]+endobj[\t \r\n]*$/.test(text.slice(offset + stream, pointer));
}
