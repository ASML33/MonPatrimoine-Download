import "server-only";

import { createHash } from "node:crypto";
import JSZip from "jszip";
import { DOCUMENT_MAX_NAME_BYTES, documentExtension, type DocumentExtension } from "./contracts";
import { isStructuredPdf } from "./pdf";

export const isUuid = (value: string) =>
  /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(value);

export function validateDocumentName(value: string) {
  const name = value.trim().normalize("NFC");
  if (
    !name || /[<>:"/\\|?*\p{Cc}\p{Cf}\p{Zl}\p{Zp}\uFFFD]/u.test(value) ||
    /^(?:con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])\s*\./i.test(name) ||
    Buffer.byteLength(name, "utf8") > DOCUMENT_MAX_NAME_BYTES
  ) return null;
  return name;
}

function isText(bytes: Buffer) {
  const bom = bytes.readUInt8(0) * 256 + (bytes[1] ?? 0);
  const encoding = bom === 0xfffe ? "utf-16le" : bom === 0xfeff ? "utf-16be" : "utf-8";
  try {
    const text = new TextDecoder(encoding, { fatal: true }).decode(bytes);
    return text.length > 0 && !/[\x00-\x08\x0B\x0E-\x1F\x7F-\x9F]/u.test(text);
  } catch {
    return false;
  }
}

const officeParts = {
  docx: "word/document.xml",
  xlsx: "xl/workbook.xml",
  pptx: "ppt/presentation.xml",
};

function boundedZip(bytes: Buffer) {
  if (bytes.length < 22 || bytes.readUInt32LE(0) !== 0x04034b50) return false;
  // Bound the number of entries before JSZip builds its in-memory directory.
  const end = bytes.lastIndexOf(Buffer.from([0x50, 0x4b, 0x05, 0x06]));
  if (end < Math.max(0, bytes.length - 65557) || end > bytes.length - 22 ||
      end + 22 + bytes.readUInt16LE(end + 20) !== bytes.length || bytes.readUInt32LE(end + 4) !== 0) return false;

  const entries = bytes.readUInt16LE(end + 10);
  let offset = bytes.readUInt32LE(end + 16);
  if (entries < 3 || entries > 4096 || bytes.readUInt16LE(end + 8) !== entries ||
      offset + bytes.readUInt32LE(end + 12) !== end) return false;

  for (let index = 0; index < entries; index++) {
    if (offset + 46 > end || bytes.readUInt32LE(offset) !== 0x02014b50) return false;
    offset += 46 + bytes.readUInt16LE(offset + 28) + bytes.readUInt16LE(offset + 30) + bytes.readUInt16LE(offset + 32);
  }
  return offset === end;
}

export async function isValidDocument(bytes: Buffer, extension: DocumentExtension) {
  if (!bytes.length) return false;
  if (extension === "pdf") return isStructuredPdf(bytes);
  if (extension === "txt" || extension === "md" || extension === "csv") return isText(bytes);
  if (!boundedZip(bytes)) return false;

  try {
    // Check the Office container's directory without expanding its streams.
    const archive = await JSZip.loadAsync(bytes);
    return Boolean(archive.file("[Content_Types].xml") && archive.file("_rels/.rels") && archive.file(officeParts[extension])) &&
      !archive.file(/(?:^|\/)(?:vbaProject\.bin|vbaData\.xml)$/i).length;
  } catch {
    return false;
  }
}

export function makeDocumentKey(uploadId: string, name: string, bytes: Buffer) {
  const digest = createHash("sha256").update(bytes).digest("hex");
  return [uploadId, digest, Buffer.from(name).toString("base64url")].join(".");
}

export function documentFromKey(key: string) {
  const [uploadId, digest, encoded, ...extra] = key.split(".");
  if (
    extra.length || !isUuid(uploadId) || !/^[a-f0-9]{64}$/.test(digest ?? "") ||
    !/^[A-Za-z0-9_-]{1,340}$/.test(encoded ?? "")
  ) return null;
  const decoded = Buffer.from(encoded, "base64url").toString("utf8");
  const name = validateDocumentName(decoded);
  const extension = name && documentExtension(name);
  return name && extension && Buffer.from(name).toString("base64url") === encoded ? { name, extension } : null;
}

export function documentAttachment(name: string) {
  const fallback = name.normalize("NFKD").replace(/\p{M}/gu, "").replace(/[^a-zA-Z0-9._ -]/g, "_");
  const encoded = encodeURIComponent(name).replace(/['()*]/g, (char) =>
    "%" + char.charCodeAt(0).toString(16).toUpperCase(),
  );
  return `attachment; filename="${fallback}"; filename*=UTF-8''${encoded}`;
}
