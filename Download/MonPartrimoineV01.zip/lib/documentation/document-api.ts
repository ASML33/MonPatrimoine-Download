import "server-only";

import { DOCUMENT_FORMAT_LABELS, DOCUMENT_MAX_BYTES, DOCUMENT_MIME_TYPES, documentExtension, type LibraryDocument } from "./contracts";
import { documentAttachment, documentFromKey, isUuid, isValidDocument, makeDocumentKey, validateDocumentName } from "./file";

export type DocumentStore = {
  list: (owner: string) => Promise<LibraryDocument[]>;
  upload: (path: string, bytes: Buffer, contentType: string) => Promise<void>;
  download: (path: string) => Promise<Blob | null>;
  remove: (path: string) => Promise<void>;
};

type Dependencies = {
  authorize: () => Promise<{ owner: string } | { status: 401 | 403 }>;
  store: () => DocumentStore;
};

const privateHeaders = {
  "Cache-Control": "private, no-store",
  "X-Content-Type-Options": "nosniff",
  Vary: "Cookie",
};

function failure(status: number, message: string) {
  return Response.json({ error: message }, { status, headers: privateHeaders });
}

class UploadTooLarge extends Error {}

async function readDocument(request: Request) {
  const declaredSize = request.headers.get("content-length");
  if (declaredSize !== null && Number(declaredSize) > DOCUMENT_MAX_BYTES) throw new UploadTooLarge();
  if (!request.body) return Buffer.alloc(0);

  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let length = 0;
  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) return Buffer.concat(chunks, length);
      length += value.byteLength;
      if (length > DOCUMENT_MAX_BYTES) {
        await reader.cancel().catch(() => {});
        throw new UploadTooLarge();
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
}

function uploadedName(header: string | null) {
  try {
    return header ? validateDocumentName(decodeURIComponent(header)) : null;
  } catch {
    return null;
  }
}

function isSameOrigin(request: Request, url: URL) {
  // Next can construct Request.url with the internal server hostname.
  const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host") ?? url.host;
  const scheme = request.headers.get("x-forwarded-proto") ?? url.protocol.slice(0, -1);
  const httpHost = host.split(",")[0].trim().toLowerCase();
  const protocol = scheme.split(",")[0].trim().toLowerCase();
  return request.headers.get("origin") === `${protocol}://${httpHost}`;
}

export function createDocumentApi({ authorize, store }: Dependencies) {
  return async function handle(request: Request) {
    try {
      const access = await authorize();
      if ("status" in access) {
        return access.status === 401
          ? failure(401, "Connectez-vous pour accéder à la documentation.")
          : failure(403, "Accès à la documentation refusé.");
      }
      const owner = access.owner;
      if (!isUuid(owner)) return failure(503, "Impossible de vérifier votre accès.");

      const url = new URL(request.url);
      if (request.method !== "GET" && !isSameOrigin(request, url)) {
        return failure(403, "Origine de la requête refusée.");
      }

      if (request.method === "POST") {
        const name = uploadedName(request.headers.get("x-document-name"));
        const uploadId = request.headers.get("x-upload-id") ?? "";
        if (!name) return failure(400, "Nom de fichier invalide. Limite de 255 octets en UTF-8.");
        if (!isUuid(uploadId)) return failure(400, "Identifiant d’envoi invalide.");
        const extension = documentExtension(name);
        if (!extension) return failure(415, `Formats acceptés : ${DOCUMENT_FORMAT_LABELS}.`);
        const contentType = DOCUMENT_MIME_TYPES[extension];
        if (request.headers.get("content-type")?.split(";")[0].trim().toLowerCase() !== contentType) {
          return failure(415, "Le type annoncé ne correspond pas à l'extension du fichier.");
        }
        const bytes = await readDocument(request);
        if (!await isValidDocument(bytes, extension)) {
          return failure(422, `Le fichier est vide ou son contenu ne correspond pas au format ${extension.toUpperCase()}.`);
        }
        const key = makeDocumentKey(uploadId, name, bytes);
        await store().upload(`${owner}/${key}`, bytes, contentType);
        return Response.json({ key }, { status: 201, headers: privateHeaders });
      }

      const key = url.searchParams.get("document");
      if (request.method === "GET" && key === null) {
        const documents = await store().list(owner);
        return Response.json({ documents }, { headers: privateHeaders });
      }

      const document = key && documentFromKey(key);
      if (!document) return failure(404, "Document introuvable.");
      const path = `${owner}/${key}`;

      if (request.method === "DELETE") {
        await store().remove(path);
        return new Response(null, { status: 204, headers: privateHeaders });
      }

      const bytes = await store().download(path);
      if (!bytes) return failure(404, "Document introuvable.");
      if (bytes.size > DOCUMENT_MAX_BYTES) return failure(503, "Le fichier dépasse la limite de téléchargement.");
      return new Response(bytes, {
        headers: {
          ...privateHeaders,
          "Content-Type": DOCUMENT_MIME_TYPES[document.extension],
          "Content-Length": String(bytes.size),
          "Content-Disposition": documentAttachment(document.name),
        },
      });
    } catch (error) {
      if (error instanceof UploadTooLarge) return failure(413, "La taille maximale est de 4 Mio par fichier.");
      return failure(503, "Documentation temporairement indisponible. Réessayez.");
    }
  };
}
