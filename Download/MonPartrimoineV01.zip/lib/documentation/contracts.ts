export const DOCUMENTS_ENDPOINT = "/api/documentation";
export const DOCUMENT_MAX_BYTES = 4 * 1024 * 1024;
export const DOCUMENT_MAX_NAME_BYTES = 255;

export const DOCUMENT_MIME_TYPES = {
  pdf: "application/pdf",
  txt: "text/plain",
  md: "text/markdown",
  csv: "text/csv",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
} as const;

export type DocumentExtension = keyof typeof DOCUMENT_MIME_TYPES;
export const DOCUMENT_ACCEPT = Object.keys(DOCUMENT_MIME_TYPES).map(extension => `.${extension}`).join(",");
export const DOCUMENT_FORMAT_LABELS = Object.keys(DOCUMENT_MIME_TYPES).map(extension => extension.toUpperCase()).join(", ");

export function documentExtension(name: string): DocumentExtension | null {
  const dot = name.lastIndexOf(".");
  if (dot <= 0) return null;
  const extension = name.slice(dot + 1).toLowerCase();
  return Object.hasOwn(DOCUMENT_MIME_TYPES, extension) ? extension as DocumentExtension : null;
}

export type LibraryDocument = {
  key: string;
  name: string;
  size: number;
  createdAt: string;
};
