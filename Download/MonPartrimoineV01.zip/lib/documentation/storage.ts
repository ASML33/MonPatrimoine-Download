import "server-only";

import { StorageApiError } from "@supabase/supabase-js";
import { createAdminClient } from "@/lib/supabase/admin";
import { DOCUMENT_MAX_BYTES, type LibraryDocument } from "./contracts";
import type { DocumentStore } from "./document-api";
import { documentFromKey } from "./file";

const BUCKET = "monpatrimoine-documentation";
const PAGE_SIZE = 100;

function missingObject(error: unknown) {
  return error instanceof StorageApiError &&
    (error.status === 404 || error.statusCode === "404" || error.statusCode === "NoSuchKey");
}

export function createDocumentStore(
  bucket = createAdminClient().storage.from(BUCKET),
): DocumentStore {
  return {
    async list(owner) {
      const documents = new Map<string, LibraryDocument>();
      for (let offset = 0; ; offset += PAGE_SIZE) {
        const { data, error } = await bucket.list(owner, {
          limit: PAGE_SIZE, offset, sortBy: { column: "name", order: "asc" },
        });
        if (error) throw error;
        for (const entry of data) {
          const document = documentFromKey(entry.name);
          const size = entry.metadata?.size;
          if (!document || !entry.id || !entry.created_at ||
              typeof size !== "number" || !Number.isInteger(size) || size < 1 ||
              size > DOCUMENT_MAX_BYTES || !Number.isFinite(Date.parse(entry.created_at))) {
            continue;
          }
          documents.set(entry.name, { key: entry.name, name: document.name, size, createdAt: entry.created_at });
        }
        if (data.length < PAGE_SIZE) break;
      }
      return [...documents.values()].sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
    },

    async upload(path, bytes, contentType) {
      const { error } = await bucket.upload(path, bytes, {
        contentType, cacheControl: "0", upsert: false,
      });
      if (!error) return;

      // A lost success response and a simultaneous repeat reach the same key.
      // That key includes the validated name and the digest of the exact bytes.
      const existing = await bucket.exists(path);
      if (!existing.data || existing.error) throw error;
    },

    async download(path) {
      const { data, error } = await bucket.download(path);
      if (!error) return data;
      if (missingObject(error)) return null;
      throw error;
    },

    async remove(path) {
      const { error } = await bucket.remove([path]);
      if (error && !missingObject(error)) throw error;
    },
  };
}
