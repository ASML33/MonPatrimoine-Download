
import { type createDriveConnection, type DriveActor, validActor } from "./google-drive-core";
import { parisBackupDate, publicationId, type Workbook, XlsxPublicationError } from "./xlsx-publication";

type RecipeConfig = {
  origin: string;
  ownerUserId: string;
  isEnabled?: () => boolean;
  resolveFixture?: (request: Request) => { date: string; variant: number } | null;
  publish: (input: { actor: DriveActor; operation: string; date: string; accessToken: () => Promise<string>; generate: () => Promise<Workbook> }) => Promise<object>;
  getActor: () => Promise<DriveActor | null>;
  getConnection: () => Pick<ReturnType<typeof createDriveConnection>, "accessToken"> | null;
  generateSyntheticWorkbook: (date: string, variant: number) => Promise<Workbook>;
  now?: () => Date;
};

const errors = {
  busy: [409, "Une opération est en cours. Réessayer avec sa référence."],
  conflict: [409, "Opération, contenu ou date incompatible. Aucun écrasement effectué."],
  invalid: [422, "Classeur de recette invalide."],
  destination: [403, "Dossier de recette ou preuve de propriété non conforme."],
  integrity: [422, "La relecture du fichier diffère du classeur envoyé."],
  unconfirmed: [503, "Résultat non confirmé. Reprendre avec la même référence."],
  auth: [401, "Connexion Google Drive expirée ou révoquée."],
  permission: [403, "Permissions Google Drive insuffisantes."],
  rate_limit: [429, "Quota Google Drive atteint. Réessayer avec la même référence."],
  timeout: [504, "Délai Google Drive dépassé. Reprendre avec la même référence."],
  unavailable: [503, "Publication indisponible. Reprendre avec la même référence."],
  cleanup_pending: [503, "Nouveau fichier vérifié. Remplacement ou rotation à reprendre avec la même référence."],
} as const;

function reply(body: object, status: number) {
  return Response.json(body, { status, headers: {
    "Cache-Control": "private, no-store", "Referrer-Policy": "no-referrer", "X-Content-Type-Options": "nosniff",
  } });
}

async function hasEmptyBody(request: Request) {
  const length = request.headers.get("content-length");
  if (length !== null && length !== "0") return false;
  if (request.body === null) return true;
  const reader = request.body.getReader();
  try {
    for (;;) {
      const next = await reader.read();
      if (next.done) return true;
      if (next.value.byteLength) {
        await reader.cancel();
        return false;
      }
    }
  } finally {
    reader.releaseLock();
  }
}

/** Owner-only endpoint for synthetic workbooks. The route supplies the durable coordinator. */
export function createManualXlsxRecipeHandler(config: RecipeConfig) {
  const url = new URL(config.origin);
  if (url.origin !== config.origin || url.username || url.password
    || !(url.protocol === "https:" || (url.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname)))) {
    throw new XlsxPublicationError("destination");
  }
  return async (request: Request) => {
    if (config.isEnabled && !config.isEnabled()) return reply({}, 404);
    if (request.method !== "POST" || new URL(request.url).origin !== config.origin
      || request.headers.get("origin") !== config.origin || request.headers.get("sec-fetch-site") === "cross-site") {
      return reply({ error: "Requête refusée." }, 403);
    }
    const operation = request.headers.get("idempotency-key") ?? "";
    if (!publicationId.test(operation)) return reply({ error: "Requête invalide." }, 400);
    const fixture = config.resolveFixture
      ? config.resolveFixture(request)
      : { date: parisBackupDate(config.now?.() ?? new Date()), variant: 0 };
    if (!fixture) return reply({ code: "invalid" }, 400);
    try {
      const actor = await config.getActor();
      if (!validActor(actor) || actor.userId !== config.ownerUserId) return reply({ error: "Session propriétaire requise." }, 403);
      if (!await hasEmptyBody(request)) return reply({ error: "Requête invalide." }, 400);
      const connection = config.getConnection();
      if (!connection) throw new XlsxPublicationError("unavailable", {operation:"OAuth configuration"});
      const result = await config.publish({
        actor, operation, date: fixture.date, accessToken: () => connection.accessToken(actor),
        generate: () => config.generateSyntheticWorkbook(fixture.date, fixture.variant),
      });
      return reply(result, 200);
    } catch (error) {
      const code = error instanceof XlsxPublicationError ? error.code : "unavailable";
      const [status, message] = errors[code];
      const diagnostic = error instanceof XlsxPublicationError ? error.diagnostic : {operation:"internal error"};
      return reply({ code, error: message, diagnostic }, status);
    }
  };
}
