import { xml2js, type Element } from "xml-js";
import type JSZip from "jszip";
import type { PatrimonialXlsxProjection } from "../exports/patrimonial-xlsx-model";
import { civilDay } from "../exports/patrimonial-xlsx-values";

const spreadsheet = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
const officeRelationships = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

function requireXlsx(condition: unknown): asserts condition {
  if (!condition) throw new Error("Lecture indépendante du classeur XLSX non conforme");
}

function children(node: Element, name: string) {
  return (node.elements ?? []).filter(e => e.type === "element" && e.name === name);
}

function only(node: Element, name: string) {
  const found = children(node, name);
  requireXlsx(found.length === 1);
  return found[0];
}

function text(node: Element) {
  requireXlsx(node.elements?.length === 1 && node.elements[0].type === "text");
  return String(node.elements[0].text);
}

async function xml(zip: JSZip, path: string, root: string) {
  const file = zip.file(path);
  requireXlsx(file);
  return only(xml2js(await file.async("string"), { compact: false }) as Element, root);
}

function coordinates(cell: Element, row: number, maxColumn: number) {
  const match = /^([A-Z]{1,3})([1-9]\d*)$/.exec(String(cell.attributes?.r));
  requireXlsx(match && Number(match[2]) === row);
  let column = 0;
  for (const char of match[1]) column = 26 * column + char.charCodeAt(0) - 64;
  requireXlsx(column <= maxColumn);
  return column - 1;
}

function readLabel(cell: Element | undefined, label: string) {
  requireXlsx(cell?.attributes?.t === "inlineStr");
  const value = text(only(only(cell, "is"), "t")).replace(/_x005F_(?=x[0-9a-f]{4}_)/gi, "_");
  requireXlsx(value === label);
}

function readNumber(cell: Element | undefined, value: number, style: string | undefined) {
  requireXlsx(cell?.attributes?.t === "n" && cell.attributes.s === style);
  const raw = text(only(cell, "v"));
  requireXlsx(/^-?\d+(?:\.\d+)?(?:e[+-]?\d+)?$/i.test(raw) && Number(raw) === value);
}

export async function inspectFinancialWorkbook(zip: JSZip, expected: PatrimonialXlsxProjection) {
  const workbook = await xml(zip, "xl/workbook.xml", "workbook");
  requireXlsx(workbook.attributes?.xmlns === spreadsheet && only(workbook, "workbookPr").attributes?.date1904 === "0");
  const sheets = children(only(workbook, "sheets"), "sheet");
  requireXlsx(sheets.length === expected.years.length);
  const rels = children(await xml(zip, "xl/_rels/workbook.xml.rels", "Relationships"), "Relationship");
  const root = children(await xml(zip, "_rels/.rels", "Relationships"), "Relationship");
  requireXlsx(root.length === 1 && root[0].attributes?.Target === "xl/workbook.xml"
    && root[0].attributes.Type === officeRelationships + "/officeDocument");
  const stylesRel = rels.filter(x => x.attributes?.Type === officeRelationships + "/styles");
  requireXlsx(rels.length === sheets.length + 1 && stylesRel.length === 1 && stylesRel[0].attributes?.Target === "styles.xml");
  const styles = await xml(zip, "xl/styles.xml", "styleSheet");
  requireXlsx(styles.attributes?.xmlns === spreadsheet);
  const formats = new Map(children(only(styles, "numFmts"), "numFmt").map(f => [f.attributes?.numFmtId, f.attributes?.formatCode]));
  const cellFormats = children(only(styles, "cellXfs"), "xf");
  requireXlsx(cellFormats[0]?.attributes?.numFmtId === "0"
    && formats.get(cellFormats[1]?.attributes?.numFmtId) === "dd/mm/yyyy"
    && formats.get(cellFormats[2]?.attributes?.numFmtId) === '#,##0.00 "€"');

  const coverage = { dates: 0, known: 0, unavailable: 0, unverified: 0, absent: 0, zeros: 0 };
  for (const [i, year] of expected.years.entries()) {
    const attrs = sheets[i].attributes;
    requireXlsx(attrs?.name === year.year && typeof attrs["r:id"] === "string");
    const relation = rels.filter(r => r.attributes?.Id === attrs["r:id"]);
    const target = relation[0]?.attributes?.Target;
    requireXlsx(relation.length === 1 && relation[0].attributes?.Type === officeRelationships + "/worksheet"
      && target === "worksheets/sheet" + (i + 1) + ".xml");
    const sheet = await xml(zip, "xl/" + target, "worksheet");
    requireXlsx(sheet.attributes?.xmlns === spreadsheet);
    const rows = children(only(sheet, "sheetData"), "row");
    requireXlsx(rows.length === expected.rows.length + 1);
    coverage.dates += year.days.length;
    for (const [index, row] of rows.entries()) {
      const number = index + 1;
      requireXlsx(row.attributes?.r === String(number));
      const cells = new Map<number, Element>();
      for (const item of children(row, "c")) {
        const column = coordinates(item, number, year.days.length + 1);
        requireXlsx(!cells.has(column));
        cells.set(column, item);
      }
      readLabel(cells.get(0), index === 0 ? "Contrat · Actif · Indicateur" : expected.rows[index - 1].label);
      for (const [column, day] of year.days.entries()) {
        const cell = cells.get(column + 1);
        if (index === 0) {
          readNumber(cell, civilDay(day.date), "1");
          continue;
        }
        const value = day.cells[index - 1];
        if (value.kind === "value") {
          readNumber(cell, value.value, expected.rows[index - 1].format === "eur" ? "2" : undefined);
          coverage.known++;
          if (value.value === 0) coverage.zeros++;
        } else {
          coverage[value.kind]++;
          if (value.kind === "absent") requireXlsx(!cell);
          else readLabel(cell, "?");
        }
      }
    }
  }
  return coverage;
}
