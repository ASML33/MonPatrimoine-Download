import { expandBalanceObservations, selectDatedBalances, type DatedBalance } from "../cash/dated-balances";
import { isContractInUserScope } from "../contracts/contract-scope";
import { resolveCtoCost } from "../contracts/cto-documented-cost";
import { historicalPruDisplay } from "../contracts/historical-pru-display";
import { observationAt, positionHistory, type PositionObservation } from "../contracts/position-observations";
import { parisBusinessDate } from "../dates/business-date";
import { convertToEur } from "../fx/fx-core";
import {
  selectLatestFxRates, selectLatestPositionSnapshots, selectLatestUsablePrices,
} from "../patrimony/current-valuation-core";
import { buildDailyHistory } from "../patrimony/daily-history-core";
import { datedPositionConfirmations, historicalSourceFor, selectHistoricalObservations, type HistoricalObservation, type HistoricalSource } from "../patrimony/historical-observations";
import { applyApprovedContractCorrections } from "../patrimony/approved-contract-corrections";
import { approvedGrossObservations } from "../patrimony/approved-gross-observations";
import { employeeSavingsValues } from "../patrimony/employee-savings-values";
import { selectManualSituation, type ManualSituation } from "../patrimony/manual-situation-core";
import type { ChartContract, ChartPoint } from "../patrimony/chart-core";
import type { CellEvidence, PatrimonialHistory } from "../exports/patrimonial-xlsx-model";
import type { PatrimonialReport, PatrimonialReportRecords, ReportAssetHolding } from "../reports/patrimonial-report-core";

type Contract = PatrimonialHistory["contracts"][number];
type Series = PatrimonialHistory["series"][number];
type Observation = PatrimonialHistory["days"][number]["observations"][number];
type Position = PatrimonialReportRecords["positions"][number] & { is_active?: boolean };
type SourceTime = { seriesId: string; kind: string; observedAt: string; obtainedAt: string | null };
export type FrozenFinancialDay = {
  native?: import("../exports/contract-json").NativeDay;
  date: string; capturedAt: string; authority: string;
  contracts: Contract[]; series: Series[]; observations: Observation[]; sourceTimes: SourceTime[];
  closedContracts: string[]; openedContracts: Array<{ id: string; openedOn: string }>;
  reconciledContracts?: number;
};

const unavailable = { kind: "unavailable" } as const;
const absent = { kind: "absent" } as const;
const dayPattern = /^\d{4}-\d{2}-\d{2}$/;
const cashEnvelopes = new Set(["epargne_liquide", "compte_bancaire", "compte_courant", "livret", "cash"]);
const isCash = (code: string) => cashEnvelopes.has(code);
const financial = (id: string, code: string) => isContractInUserScope(id) && code !== "immobilier";
const byId = (a: { id: string }, b: { id: string }) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0;
const isKnownAt = (date: string | null | undefined, cutoff: string) =>
  !date || (Number.isFinite(Date.parse(date)) && Date.parse(date) <= Date.parse(cutoff));

function cell(value: number | string | null | undefined): CellEvidence {
  if (typeof value === "number" && Number.isFinite(value)) return { kind: "value", value };
  if (typeof value === "string" && /^-?\d+(?:\.\d+)?$/.test(value) && Number.isFinite(Number(value))) return { kind: "value", value };
  return unavailable;
}

function blankDay(date: string, capturedAt: string, authority: string): FrozenFinancialDay {
  return { date, capturedAt, authority, contracts: [], series: [], observations: [], sourceTimes: [], closedContracts: [], openedContracts: [] };
}

function record(day: FrozenFinancialDay, series: Series, evidence: Observation["evidence"]) {
  day.series.push(series);
  day.observations.push({ seriesId: series.id, evidence });
}

function recordSimple(day: FrozenFinancialDay, contractId: string, kind: "cash" | "contract-total", evidence: CellEvidence) {
  record(day, { id: `${kind}:${contractId}`, contractId, kind }, evidence);
}

function historicalPru(holding: ReportAssetHolding, position: Position | undefined, envelope: string, day: FrozenFinancialDay) {
  if (holding.valueSemantics === "total_amount" || holding.quantity === null || holding.quantity <= 0) return unavailable;
  // Archived EUR unit costs are already denominated in EUR. Other currencies
  // need a dated acquisition proof (the latest valuation FX is never used).
  if (!position) return holding.costCurrencyCode === "EUR" ? cell(holding.nativeUnitCost?.amount ?? holding.averageCostPerUnit) : unavailable;
  const history = positionHistory(position.metadata);
  const observation = history ? observationAt(history.entries.filter(e => isKnownAt(e.recordedAt, day.capturedAt)), day.date) : null;
  if (history && !observation) return unavailable;
  const quantity = observation?.quantity ?? position.quantity;
  if (Number(quantity) !== holding.quantity) return unavailable;
  const native = observation ? observation.unitCost : position.average_cost_per_unit;
  const currency = observation?.currency ?? position.cost_currency_code;
  if (!["cto", "compte_titres"].includes(envelope)) return currency === "EUR" ? cell(native) : unavailable;
  const args = { metadata: position.metadata, native, currency, day: day.date, quantity: holding.quantity };
  const cost = resolveCtoCost({ ...args, observation, legacyUnit: currency === "EUR" && native !== null ? Number(native) : null });
  return cell(historicalPruDisplay(cost, args)?.unitEur);
}

function addTime(day: FrozenFinancialDay, seriesId: string, kind: string, observedAt: string | null | undefined, obtainedAt?: string | null, cutoff = day.capturedAt) {
  if (observedAt && isKnownAt(observedAt, cutoff) && isKnownAt(obtainedAt, cutoff)) {
    day.sourceTimes.push({ seriesId, kind, observedAt, obtainedAt: obtainedAt ?? null });
  }
}

export function qualifyFinancialInputs(records: PatrimonialReportRecords, date: string, capturedAt: string): PatrimonialReportRecords {
  const envelopes = new Map(records.envelopeTypes.map(t => [t.id, t.code]));
  const contracts = records.contracts.filter(c => financial(c.id, envelopes.get(c.envelope_type_id) ?? "") && (!c.opened_on || c.opened_on <= date));
  const active = new Set(contracts.filter(c => c.is_active !== false && (!c.closed_on || c.closed_on > date)).map(c => c.id));
  const positions = (records.positions as Position[]).filter(p => active.has(p.contract_id) && p.is_active !== false);
  const assetIds = new Set(positions.map(p => p.asset_id));
  const assets = records.assets.filter(a => assetIds.has(a.id) && a.asset_type_code !== "real_estate");
  const filteredAssets = new Set(assets.map(a => a.id));
  const balances = expandBalanceObservations(records.cashBalances).filter(b =>
    active.has(b.contract_id) && isKnownAt(b.updated_at, capturedAt) && isKnownAt(b.as_of, capturedAt));
  // selectDatedBalances must not expand a second time or resurrect a later revision.
  const cashBalances = balances.map(b => {
    const metadata = { ...(b.metadata as Record<string, unknown> | undefined) };
    delete metadata.cash_balance_observations;
    return { ...b, metadata };
  });
  return {
    ...records, contracts: contracts.filter(c => active.has(c.id)), assets, cashBalances,
    positions: positions.filter(p => filteredAssets.has(p.asset_id)).map(p => {
      const history = positionHistory(p.metadata);
      return history ? { ...p, metadata: { ...(p.metadata as object), position_observations: {
        ...history, entries: history.entries.filter(entry => isKnownAt(entry.recordedAt, capturedAt)),
      } } } : p;
    }),
    prices: records.prices.filter(p => filteredAssets.has(p.asset_id) && isKnownAt(p.observed_at, capturedAt) && isKnownAt(p.obtained_at, capturedAt)),
    currentFxRates: records.currentFxRates.filter(f => f.observed_on <= date && f.requested_on <= date && isKnownAt(f.obtained_at, capturedAt)),
  };
}

export function projectNativeFinancialDay(
  report: PatrimonialReport, records: PatrimonialReportRecords, date: string, capturedAt: string, authority: string,
): FrozenFinancialDay {
  const day = blankDay(date, capturedAt, authority);
  const qualified = qualifyFinancialInputs(records, date, capturedAt);
  const envelopes = new Map(records.envelopeTypes.map(t => [t.id, t.code]));
  const originalContracts = new Map(records.contracts.filter(c => financial(c.id, envelopes.get(c.envelope_type_id) ?? "")).map(c => [c.id, c]));
  const positions = new Map((qualified.positions as Position[]).map(p => [p.id, p]));
  const rawAssets = new Map(records.assets.map(a => [a.id, a]));
  day.native = { assets: [], cash: [], events: [] };
  const prices = selectLatestUsablePrices(qualified.assets, qualified.prices, capturedAt);
  const snapshots = selectLatestPositionSnapshots(qualified.positionSnapshots, capturedAt);
  const rates = selectLatestFxRates(qualified.currentFxRates, capturedAt);
  const balances = selectDatedBalances(qualified.cashBalances, capturedAt);
  for (const contract of [...originalContracts.values()].sort(byId)) {
    const envelope = envelopes.get(contract.envelope_type_id);
    if (!envelope) continue; // Unknown type cannot prove that the contract is financial.
    day.contracts.push({ id: contract.id, label: contract.display_name?.trim() || contract.name, envelope });
    if (contract.opened_on && dayPattern.test(contract.opened_on)) day.openedContracts.push({ id: contract.id, openedOn: contract.opened_on });
    if (contract.closed_on && dayPattern.test(contract.closed_on) && contract.closed_on <= date) day.closedContracts.push(contract.id);
  }
  for (const flow of records.cashFlows) {
    if (!isKnownAt(flow.occurred_at, capturedAt)) continue;
    for (const contractId of new Set([flow.source_contract_id, flow.destination_contract_id])) {
      if (!contractId || !day.contracts.some(c => c.id === contractId)) continue;
      day.native.events.push({ id: flow.id, contractId, date: parisBusinessDate(new Date(flow.occurred_at)), occurredAt: flow.occurred_at, sens: flow.source_contract_id===flow.destination_contract_id ? 'interne' : flow.destination_contract_id===contractId ? 'entree' : 'sortie', kind: flow.kind,
        amount: convertToEur(flow.amount, flow.currency_code, records.historicalFxRates.find(rate => rate.id === flow.fx_rate_id && rate.observed_on <= parisBusinessDate(new Date(flow.occurred_at)) && rate.requested_on <= parisBusinessDate(new Date(flow.occurred_at)) && isKnownAt(rate.obtained_at,capturedAt))).amountEur, currency: 'EUR', sourceCurrency: flow.currency_code });
    }
  }
  const contractSeries = new Map(day.contracts.map(c => [c.id, c]));

  for (const asset of [...report.assets].sort(byId)) {
    if (rawAssets.get(asset.id)?.asset_type_code === "real_estate") continue;
    for (const holding of [...asset.holdings].sort((a, b) => a.contractId.localeCompare(b.contractId))) {
      const contract = contractSeries.get(holding.contractId);
      if (!contract || holding.valueSemantics === "total_property" || day.closedContracts.includes(contract.id)) continue;
      const id = `asset:${contract.id}:${asset.id}`;
      day.native.assets.push({ seriesId: id, nativePru: null, currency: 'EUR' });
      const position = positions.get(holding.positionId);
      const snapshot = snapshots.get(holding.positionId);
      const price = prices.get(asset.id);
      const source = holding.valueSemantics === "total_amount" || !price ? snapshot : price;
      const metadata = position?.metadata;
      const h = metadata ? positionHistory(metadata) : null;
      const holdingObservation = h ? observationAt(h.entries.filter(e => isKnownAt(e.recordedAt, capturedAt)), date) : null;
      // An archived result is used verbatim for amounts and quantities. It may
      // contain a subtotal but a holding value is either proven or null.
      record(day, { id, kind: "asset", contractId: contract.id, assetId: asset.id, label: asset.name }, {
        kind: "asset", quantity: cell(holding.quantity), historicalPruEur: historicalPru(holding, position, contract.envelope, day),
        grossEur: cell(holding.valueEur),
      });
      if (holdingObservation) addTime(day, id, "holding", holdingObservation.effectiveOn, holdingObservation.recordedAt);
      const sourceAmount = source && ("observed_at" in source
        ? holding.quantity !== null ? holding.quantity * Number(source.price) : null
        : source.market_value);
      if (holding.valueEur !== null && source && sourceAmount !== null && sourceAmount !== undefined) {
        const rate = rates.get(source.currency_code);
        const confirmed = convertToEur(sourceAmount, source.currency_code, rate).amountEur;
        if (confirmed === null || Math.abs(confirmed - holding.valueEur) > 0.000001) continue;
        if ("observed_at" in source) addTime(day, id, "price", source.observed_at, source.obtained_at);
        else addTime(day, id, "valuation", source.valued_at);
        if (source.currency_code !== "EUR" && rate) addTime(day, id, "fx", rate.observed_on, rate.obtained_at);
      }
    }
  }
  // A quantity of zero in an explicit dated holding entry is a position exit.
  // An omitted holding or an undated inactive flag is insufficient.
  for (const position of [...(records.positions as Position[])].sort(byId)) {
    const contract = contractSeries.get(position.contract_id), asset = rawAssets.get(position.asset_id);
    if (!contract || !asset || asset.asset_type_code === "real_estate") continue;
    const h = positionHistory(position.metadata);
    const observation = h ? observationAt(h.entries.filter(e => isKnownAt(e.recordedAt, capturedAt)), date) : null;
    const id = `asset:${contract.id}:${asset.id}`;
    if (observation && Number(observation.quantity) === 0 && !day.series.some(s => s.id === id)) {
      record(day, { id, kind: "asset", contractId: contract.id, assetId: asset.id, label: asset.display_name || asset.name }, absent);
      addTime(day, id, "exit", observation.effectiveOn, observation.recordedAt);
    }
  }
  for (const balance of balances) {
    if (!day.contracts.some(c => c.id === balance.contract_id)) continue;
    day.native.cash.push({ contractId: balance.contract_id, currency: 'EUR', sourceCurrency: balance.currency_code, amount: convertToEur(balance.amount, balance.currency_code, rates.get(balance.currency_code)).amountEur, observedAt: balance.as_of });
  }
  for (const result of [...report.contracts].sort(byId)) {
    const contract = contractSeries.get(result.id);
    if (!contract || day.closedContracts.includes(result.id)) continue;
    const rows = contract.envelope === "assurance_vie" ? [] : balances.filter(b => b.contract_id === result.id);
    const details = day.series.some(s => s.kind === "asset" && s.contractId === result.id);
    const manual = originalContracts.get(result.id)?.valuation_source === "manual_situation";
    if (isCash(contract.envelope) || (!details && !manual && rows.length)) {
      const known = rows.length && !result.incompleteCashBalances;
      recordSimple(day, result.id, "cash", known ? cell(result.cashEur) : unavailable);
    } else if (manual && !details) {
      recordSimple(day, result.id, "contract-total",
        !result.incompletePositions && result.manualSituationAt ? cell(result.grossEur) : unavailable);
      addTime(day, `contract-total:${result.id}`, "manual", result.manualSituationAt);
    } else if (rows.length && contract.envelope !== "assurance_vie" && !manual) {
      recordSimple(day, result.id, "cash", result.incompleteCashBalances ? unavailable : cell(result.cashEur));
    } else if (!details) {
      recordSimple(day, result.id, "contract-total", unavailable);
    }
    if (day.series.some(s => s.id === `cash:${result.id}`)) {
      for (const row of rows) {
        addTime(day, `cash:${result.id}`, "cash", row.as_of, row.updated_at);
        const rate = rates.get(row.currency_code);
        if (row.currency_code !== "EUR" && rate && convertToEur(row.amount, row.currency_code, rate).amountEur !== null) {
          addTime(day, `cash:${result.id}`, "fx", rate.observed_on, rate.obtained_at);
        }
      }
    }
  }
  day.reconciledContracts = reconcileNativeGross(day, report);
  return day;
}

function reconcileNativeGross(day: FrozenFinancialDay, report: PatrimonialReport) {
  const observations = new Map(day.observations.map(o => [o.seriesId, o.evidence]));
  const components = new Map<string, CellEvidence[]>();
  for (const row of day.series) {
    if (row.kind === "employee-savings-total") continue;
    const evidence = observations.get(row.id);
    if (!evidence || evidence.kind === "absent") continue;
    const items = components.get(row.contractId) ?? [];
    items.push(evidence.kind === "asset" ? evidence.grossEur : evidence);
    components.set(row.contractId, items);
  }
  let count = 0;
  for (const contract of report.contracts) {
    const items = components.get(contract.id) ?? [];
    if (contract.incompletePositions !== 0 || contract.incompleteCashBalances !== 0
      || !items.length || !items.every(x => x.kind === "value")) continue;
    const gross = items.reduce((total, item) => total + Number(item.value), 0);
    const precision = Math.max(0.01, Math.abs(contract.grossEur) * 1e-12);
    if (!Number.isFinite(contract.grossEur) || Math.abs(gross - contract.grossEur) > precision) {
      throw new Error("Valorisation brute du contrat incohérente avec ses composants XLSX");
    }
    count++;
  }
  return count;
}

export function captureFinancialDay(records: PatrimonialReportRecords, date: string, capturedAt: string) {
  const qualified = qualifyFinancialInputs(records, date, capturedAt);
  return projectNativeFinancialDay(buildDailyHistory(qualified, capturedAt, date).report, records, date, capturedAt, "snapshot");
}

type LegacyIdentity = Record<string, { label: string; envelope: string; openedOn?: string | null; closedOn?: string | null; valuationSource?: string }>;
type LegacyAsset = Record<string, { label: string; type: string }>;
type DatedInput = {
  date: string; cutoff: string; sources: HistoricalSource[]; assets: LegacyAsset;
  positions?: Array<{ contractId: string; assetId: string; entry: PositionObservation }>;
  balances?: DatedBalance[]; manual?: ManualSituation[]; manualSources?: HistoricalSource[];
};

function upsertEvidence(day: FrozenFinancialDay, series: Series, evidence: Observation["evidence"]) {
  if (!day.series.some(s => s.id === series.id)) day.series.push(series);
  day.observations = day.observations.filter(o => o.seriesId !== series.id);
  day.observations.push({ seriesId: series.id, evidence });
}

function applyDatedEvidence(day: FrozenFinancialDay, rows: HistoricalObservation[], row: HistoricalObservation | undefined,
  known: LegacyIdentity, { sources, assets, cutoff, balances = [], positions = [], manual = [], manualSources = [] }: DatedInput) {
  const date = day.date;
  function ensureContract(id: string) {
    const item = known[id];
    if (!item || !financial(id, item.envelope) || (item.openedOn && item.openedOn > date)
      || (item.closedOn && item.closedOn <= date)) return null;
    if (!day.contracts.some(c => c.id === id)) day.contracts.push({ id, label: item.label, envelope: item.envelope });
    return item;
  }
  function setSimple(contractId: string, kind: "cash" | "contract-total", amount: number | string | null) {
    upsertEvidence(day, { id: `${kind}:${contractId}`, kind, contractId }, cell(amount));
  }
  function setHolding(contractId: string, assetId: string, quantity: number | null, gross: number | null, retired: boolean, replacing: boolean) {
    const contract = ensureContract(contractId), asset = assets[assetId];
    if (!contract || !asset || asset.type === "real_estate") return;
    const id = `asset:${contractId}:${assetId}`;
    const before = day.observations.find(o => o.seriesId === id)?.evidence;
    if (before?.kind === "absent" && !replacing) return;
    const original = before?.kind === "asset" && !replacing ? before : null;
    upsertEvidence(day, { id, kind: "asset", contractId, assetId, label: asset.label }, retired ? absent : {
      kind: "asset", quantity: original?.quantity.kind === "value" ? original.quantity : cell(quantity),
      grossEur: original?.grossEur.kind === "value" ? original.grossEur : cell(gross),
      historicalPruEur: original?.historicalPruEur ?? unavailable,
    });
  }

  const inventory = row?.result.historicalInventory ?? [];
  if (row?.result.engineVersion === "patrimony-legacy-import-v1") {
    for (const saved of inventory) {
      if (saved.presence !== "present" && saved.presence !== "absent") continue;
      setHolding(saved.contractId, saved.assetId, saved.quantity, saved.valueEur, saved.presence === "absent", false);
    }
  }
  if (row && sources.some(s => s.payload.kind === "approved_contract_correction")) {
    const candidates: ChartContract[] = row.result.report.contracts.filter(c => known[c.id] && financial(c.id, known[c.id].envelope)).map(c => ({
      id: c.id, name: c.name, envelopeType: known[c.id].envelope, sourceKey: null, openedOn: null, isActive: true,
      grossEur: c.grossEur, netEur: null, netKind: "unavailable", valuationDate: null, color: "",
      children: inventory.filter(h => h.contractId === c.id).map(h => ({
        id: `asset:${h.contractId}:${h.assetId}`, kind: "asset", assetId: h.assetId, label: h.name, valueEur: null, color: "",
      })),
    }));
    const empty: ChartPoint = { date, values: {}, cash: {}, contributions: {}, quantities: {}, netKinds: {}, employeeSavingsCombined: null, provenance:"" };
    // Only the validated explicit correction is applied to this one date.
    const [corrected] = applyApprovedContractCorrections([empty], candidates, [row], sources);
    for (const h of inventory) {
      if (!corrected.declaredContractTotals?.[h.contractId]) continue;
      const id = `asset:${h.contractId}:${h.assetId}`;
      const quantity = corrected.quantities[id] ?? null;
      setHolding(h.contractId, h.assetId, quantity, corrected.values[id] ?? null, quantity === 0, true);
      addTime(day, id, "approved_correction", date, sources.find(s => s.id === corrected.declaredContractTotals?.[h.contractId]?.sourceId)?.imported_at, cutoff);
    }
    for (const id of Object.keys(corrected.declaredContractTotals ?? {})) {
      setSimple(id, "cash", corrected.cash[`cash:${id}`] ?? null);
    }
  }
  for (const h of datedPositionConfirmations(date, sources)) {
    setHolding(h.contractId, h.assetId, h.quantity, h.marketValueEur, false, false);
    const receipt = sources.find(s => s.payload.kind === "user_position_valuation_confirmation"
      && s.payload.confirmedPositionValues?.some(v => typeof v === "object" && v !== null
        && "assetId" in v && v.assetId === h.assetId && "contractId" in v && v.contractId === h.contractId));
    if (receipt) addTime(day, `asset:${h.contractId}:${h.assetId}`, "dated_confirmation", date, receipt.imported_at, cutoff);
  }

  const uniquePositions = new Set<string>();
  for (const { contractId, assetId, entry } of positions) {
    if (!dayPattern.test(entry.effectiveOn) || entry.effectiveOn > date || !isKnownAt(entry.recordedAt, cutoff)) continue;
    const id = `asset:${contractId}:${assetId}`;
    if (uniquePositions.has(id)) throw new Error("Détentions historiques datées concurrentes");
    uniquePositions.add(id);
    const amount = Number(entry.quantity);
    if (!Number.isFinite(amount) || amount < 0) throw new Error("Quantité historique invalide");
    const original = day.observations.find(o => o.seriesId === id)?.evidence;
    if (original?.kind === "absent" || original?.kind === "asset" && original.quantity.kind === "value") continue;
    if (amount === 0 && original?.kind === "asset" && original.grossEur.kind === "value" && Number(original.grossEur.value) !== 0) {
      throw new Error("Valorisation d'actif incompatible avec la sortie datée");
    }
    setHolding(contractId, assetId, amount, null, amount === 0, false);
    const added = day.observations.find(o => o.seriesId === id)?.evidence;
    if (added?.kind === "asset" && amount > 0 && entry.currency === "EUR" && added.historicalPruEur.kind !== "value") {
      added.historicalPruEur = cell(entry.unitCost);
    }
    if (added) addTime(day, id, "dated_holding", entry.effectiveOn, entry.recordedAt, cutoff);
  }

  const knownBalances = expandBalanceObservations(balances).filter(b => isKnownAt(b.updated_at, cutoff) && isKnownAt(b.as_of, cutoff))
    .map(b => {
      const metadata = { ...(b.metadata as Record<string, unknown> | undefined) };
      delete metadata.cash_balance_observations;
      return { ...b, metadata };
    });
  const activeBalances = selectDatedBalances(knownBalances, date);
  const exactBalances = activeBalances.filter(b => parisBusinessDate(b.as_of) === date);
  for (const contractId of new Set(exactBalances.map(b => b.contract_id))) {
    const contract = ensureContract(contractId);
    if (!contract || !isCash(contract.envelope)) continue;
    const id = `cash:${contractId}`;
    if (day.observations.some(o => o.seriesId === id && o.evidence.kind === "value")) continue;
    const original = activeBalances.filter(b => b.contract_id === contractId);
    const exact = exactBalances.filter(b => b.contract_id === contractId);
    const one = original.length === 1 && exact.length === 1 && exact[0].currency_code === "EUR";
    setSimple(contractId, "cash", one ? exact[0].amount : null);
    for (const b of exact) addTime(day, id, "dated_cash", b.as_of, b.updated_at, cutoff);
  }

  const gross = approvedGrossObservations(sources);
  const savings = employeeSavingsValues(manual.filter(m => ["peg","per_col"].includes(known[m.contract_id]?.envelope)), manualSources, cutoff)
    .effective.filter(e => e.date === date && e.ref.startsWith("manual:"));
  const combined = day.series.find(s => s.kind === "employee-savings-total");
  const hasCombinedAmount = combined?.kind === "employee-savings-total"
    && day.observations.some(o => o.seriesId === combined.id && o.evidence.kind === "value");
  const split = hasCombinedAmount && combined.members.every(id => gross.some(g => g.value.contractId === id)
    || known[id]?.valuationSource === "manual_situation" && savings.some(e => e.contractId === id));
  if (split) day.observations = day.observations.filter(o => o.seriesId !== combined.id);
  for (const { value } of gross) {
    if (hasCombinedAmount && combined.members.includes(value.contractId) && !split) continue;
    const item = ensureContract(value.contractId);
    if (item?.envelope !== value.sourceKey) throw new Error("Identité de l’épargne salariale incohérente");
    if (value.baselineCaptureId && !rows.some(r => r.id === value.baselineCaptureId)
      || value.baselineSourceId && !sources.some(s => s.id === value.baselineSourceId)) throw new Error("Preuve de valorisation d’origine absente");
    setSimple(value.contractId, "contract-total", value.grossEur);
    addTime(day, `contract-total:${value.contractId}`, "approved_manual", date, value.recordedAt, cutoff);
  }
  for (const id of new Set(manual.map(row => row.contract_id))) {
    const contract = ensureContract(id);
    if (contract?.valuationSource !== "manual_situation" || (hasCombinedAmount
      && combined.members.includes(id) && !split)) continue;
    if (day.observations.some(o => o.seriesId === `contract-total:${id}` && o.evidence.kind === "value")) continue;
    const selected = ["peg","per_col"].includes(contract.envelope)
      ? savings.find(s => s.contractId === id)
      : selectManualSituation(manual.filter(row => parisBusinessDate(row.situated_at) === date), id, cutoff);
    if (!selected) continue;
    if ("gross" in selected) {
      setSimple(id, "contract-total", selected.gross);
      addTime(day, `contract-total:${id}`, "dated_manual", selected.sourceAt ?? date, selected.recordedAt, cutoff);
    } else {
      setSimple(id, "contract-total", selected.gross_eur);
      addTime(day, `contract-total:${id}`, "dated_manual", selected.situated_at, selected.recorded_at, cutoff);
    }
  }
  const holdings = new Set(day.series.flatMap(s => s.kind === "asset" && day.observations.some(o => o.seriesId === s.id
    && o.evidence.kind === "asset" && o.evidence.grossEur.kind === "value")
    ? [s.contractId] : []));
  const detailedCash = new Set(day.series.flatMap(s => s.kind === "cash" && day.observations.some(o => o.seriesId === s.id && o.evidence.kind === "value") ? [s.contractId] : []));
  const seriesById = new Map(day.series.map(s => [s.id, s]));
  day.observations = day.observations.flatMap(o => {
    const s = seriesById.get(o.seriesId);
    if (s && s.kind !== "employee-savings-total" && hasCombinedAmount && combined.members.includes(s.contractId) && !split) {
      if (o.evidence.kind === "asset") return [{ ...o, evidence: { ...o.evidence, grossEur: unavailable } }];
      return o.evidence.kind === "absent" ? [o] : [];
    }
    return s?.kind === "contract-total" && (holdings.has(s.contractId) || detailedCash.has(s.contractId)) ? [] : [o];
  });
  return day;
}

export function projectArchivedFinancialDay(rows: HistoricalObservation[], known: LegacyIdentity,
  options?: DatedInput) {
  const selected = selectHistoricalObservations(rows);
  if (selected.length > 1 || (!selected.length && !options)) throw new Error("Autorité historique XLSX ambiguë");
  const row = selected[0]?.selected;
  const date = selected[0]?.date ?? options!.date;
  const authority = selected[0]?.authority ?? "observations datées";
  const day = row?.result.engineVersion === "patrimony-history-v1"
    ? projectNativeFinancialDay(row.result.report as PatrimonialReport, row.inputs as PatrimonialReportRecords, date, row.captured_at, authority)
    : blankDay(date, row?.captured_at ?? options!.cutoff, authority);
  if (row && row.result.engineVersion !== "patrimony-history-v1" && row.result.engineVersion !== "patrimony-legacy-import-v1") {
    throw new Error("Source historique XLSX non reconnue");
  }
  const legacyContracts = row?.result.engineVersion === "patrimony-legacy-import-v1" ? row.result.report.contracts : [];
  for (const item of [...legacyContracts].sort(byId)) {
    const provenance = (item as { provenance?: string }).provenance;
    if (provenance === "legacy_workbook_combined") {
      const peg = Object.entries(known).filter(([, c]) => c.envelope === "peg");
      const per = Object.entries(known).filter(([, c]) => c.envelope === "per_col");
      if (peg.length !== 1 || per.length !== 1) throw new Error("Identités PEG/PER COL non qualifiées");
      const members = [peg[0][0], per[0][0]] as const;
      record(day, { id: "employee-savings-total:" + members.join(":"), kind: "employee-savings-total", members }, cell(item.grossEur));
      for (const [id, definition] of [...peg, ...per]) {
        if (!day.contracts.some(c => c.id === id)) day.contracts.push({ id, ...definition });
      }
    } else {
      const c = known[item.id];
      if (!c || !financial(item.id, c.envelope)) continue;
      if (!day.contracts.some(saved => saved.id === item.id)) day.contracts.push({ id: item.id, ...c });
      recordSimple(day, item.id, isCash(c.envelope) ? "cash" : "contract-total", cell(item.grossEur));
    }
  }
  if (!options) return day;
  // The historical seed can use explicit contract boundary dates available
  // at initialization, even when an older capture has no contract inventory.
  for (const [id, contract] of Object.entries(known)) {
    if (!financial(id, contract.envelope)) continue;
    if (contract.openedOn && dayPattern.test(contract.openedOn) && !day.openedContracts.some(c => c.id === id)) {
      day.openedContracts.push({ id, openedOn: contract.openedOn });
    }
    if (contract.closedOn && dayPattern.test(contract.closedOn) && contract.closedOn <= date && !day.closedContracts.includes(id)) {
      day.closedContracts.push(id);
    }
  }
  // Sources admitted after the historical observation are retained with their
  // receipt date for the initial import. This import never runs on frozen days.
  if (row && authority.startsWith("CSV prioritaire")) historicalSourceFor(row, options.sources);
  applyDatedEvidence(day, rows, row, known, options);
  const outsideContract = new Set([...day.closedContracts, ...day.openedContracts.filter(c => date < c.openedOn).map(c => c.id)]);
  const outsideSeries = new Set(day.series.flatMap(s => s.kind !== "employee-savings-total" && outsideContract.has(s.contractId) ? [s.id] : []));
  day.observations = day.observations.filter(o => {
    if (!outsideSeries.has(o.seriesId)) return true;
    const e = o.evidence;
    const cells = e.kind === "asset" ? [e.quantity, e.historicalPruEur, e.grossEur] : [e];
    if (cells.some(c => c.kind === "value" && Number(c.value) !== 0)) {
      throw new Error("Observation financière incompatible avec les dates du contrat");
    }
    return false;
  });
  return day;
}

export function assembleFinancialHistory(previous: FrozenFinancialDay[], current: FrozenFinancialDay): PatrimonialHistory {
  const contracts = new Map<string, Contract>(), series = new Map<string, Series>();
  const days = [...previous].sort((a, b) => a.date.localeCompare(b.date));
  for (const day of [...days, current]) {
    for (const contract of day.contracts) if (!contracts.has(contract.id)) contracts.set(contract.id, contract);
    for (const row of day.series) if (!series.has(row.id)) series.set(row.id, row);
  }
  const effective = [...days.filter(d => d.date < current.date), current];
  return { backupDate: current.date, contracts: [...contracts.values()], series: [...series.values()], days: effective.map(day => {
    const evidence = new Map(day.observations.map(row => [row.seriesId, row]));
    for (const row of series.values()) {
      if (row.kind !== "employee-savings-total" && !evidence.has(row.id) && (
        day.closedContracts.includes(row.contractId) ||
        day.openedContracts.some(c => c.id === row.contractId && day.date < c.openedOn)
      )) evidence.set(row.id, { seriesId: row.id, evidence: absent });
    }
    return { date: day.date, observations: [...evidence.values()] };
  }) };
}
