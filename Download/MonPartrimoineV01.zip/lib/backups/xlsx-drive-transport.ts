
import { createHash, randomUUID } from "node:crypto";
import { DriveError } from "./google-drive-core";
import { patrimonialXlsxFilename } from "../exports/patrimonial-xlsx-values";
import { PATRIMONIAL_XLSX_MIME } from "../exports/patrimonial-xlsx";
import {
  MAX_XLSX_UPLOAD, publicationId, XLSX_RECIPE_FAMILY, XlsxPublicationError, type Intent, type XlsxDrive,
} from "./xlsx-publication";

export const XLSX_RECIPE_FOLDER = "MonPatrimoine — Recette XLSX";
export const XLSX_FINANCIAL_FOLDER = "MonPatrimoine — Sauvegardes";
export const XLSX_FINANCIAL_FAMILY = "mp-patrimoine-xlsx-financier-v1";
const folderMime = "application/vnd.google-apps.folder";
const fields = "id,name,mimeType,parents,appProperties,trashed,shared,ownedByMe,driveId,capabilities(canAddChildren,canRename,canTrash)";
const safeId = /^[A-Za-z0-9_-]{5,160}$/;
export const financialArchiveReference = /^[0-9a-f]{64}$/;

type FinancialArchive = { reference: string; name: string; date: string };

type DriveFile = {
  id: string; name: string; mimeType: string; parents?: string[]; appProperties?: Record<string, string>;
  trashed: boolean; shared: boolean; ownedByMe: boolean; driveId?: string;
  capabilities?: { canAddChildren?: boolean; canRename?: boolean; canTrash?: boolean };
};
export type Config = { folderId: string; technicalFolderId: string; accessToken: () => Promise<string>; request?: typeof fetch; beforeMutation?: () => Promise<number>; financial?: boolean; expectedParentId?: string; expectedInstallation?: string; selected?: boolean; fixedDestination?: boolean };

function stageName(intent: Pick<Intent, "operation">) { return ".monpatrimoine-xlsx-en-cours-" + intent.operation; }

function tags(intent: Pick<Intent, "operation" | "date" | "sha256">, phase: "stage" | "final", family: string) {
  return { mpXlsx: family, mpPhase: phase, mpDate: intent.date, mpOperation: intent.operation, mpSha256: intent.sha256 };
}

function apiFailure(status: number, diagnostic?: XlsxPublicationError["diagnostic"]) {
  if (status === 401) return new XlsxPublicationError("auth");
  if (status === 403) return new XlsxPublicationError("permission");
  if (status === 429) return new XlsxPublicationError("rate_limit");
  if (status === 408 || status === 504) return new XlsxPublicationError("timeout");
  return new XlsxPublicationError("unavailable", diagnostic);
}

type Connection = Omit<Config, "folderId">;

export function createRequests({ accessToken, request = fetch, beforeMutation }: Connection) {
  async function call(path: string, options: RequestInit = {}, upload = false) {
    const resource = path.split("?")[0];
    const operation = (options.method ?? "GET") + " " + (resource === "files" || resource === "files/root" || resource === "files/generateIds" ? resource : "file-metadata");
    let token: string;
    try {
      token = await accessToken();
    } catch (error) {
      if (error instanceof XlsxPublicationError) throw error;
      console.warn("XLSX Drive OAuth", { code: error instanceof DriveError ? error.code : "unknown" });
      throw new XlsxPublicationError(error instanceof DriveError && error.code === "reconnect_required" ? "auth" : "unavailable", {operation:"OAuth", reason:error instanceof DriveError ? error.code : undefined});
    }
    if (!token) throw new XlsxPublicationError("auth");
    const timeout = options.method && options.method !== "GET" && beforeMutation ? await beforeMutation() : 12_000;
    try {
      const response = await request("https://www.googleapis.com/" + (upload ? "upload/" : "") + "drive/v3/" + path, {
        ...options, headers: { ...options.headers, Authorization: "Bearer " + token },
        cache: "no-store", redirect: "error", signal: AbortSignal.timeout(timeout),
      });
      if (!response.ok && response.status !== 404 && response.status !== 409) {
        const payload = await response.clone().json().catch(() => null) as { error?: { errors?: { reason?: string }[] } } | null;
        const candidate = payload?.error?.errors?.[0]?.reason;
        const reason = candidate && /^[A-Za-z][A-Za-z0-9_-]{0,48}$/.test(candidate) ? candidate : undefined;
        console.warn("XLSX Drive response", { operation, status: response.status, reason });
        throw apiFailure(response.status, { operation, upstream: response.status, reason });
      }
      return response;
    } catch (error) {
      if (error instanceof XlsxPublicationError) throw error;
      console.warn("XLSX Drive transport", { operation, timeout: error instanceof Error && ["AbortError", "TimeoutError"].includes(error.name) });
      throw new XlsxPublicationError(error instanceof Error && ["AbortError", "TimeoutError"].includes(error.name) ? "timeout" : "unavailable", {operation});
    }
  }

  async function readJson<T>(response: Response): Promise<T> {
    if (!response.ok) throw apiFailure(response.status);
    return response.json() as Promise<T>;
  }

  return { call, readJson };
}

async function getMyDriveRoot(config: Connection) {
  const { call, readJson } = createRequests(config);
  const root = await call("files/root?fields=id");
  if (root.ok) return (await readJson<{ id: string }>(root)).id;
  if (root.status !== 404) throw apiFailure(root.status);
  // drive.file can expose an application folder without exposing the root resource.
  // The technical folder was created at the default root by this same OAuth app.
  const reference = await call("files/" + config.technicalFolderId + "?fields=" + encodeURIComponent(fields));
  if (!reference.ok) throw apiFailure(reference.status, { operation: "Read technical folder metadata", upstream: reference.status });
  const technical = await readJson<DriveFile>(reference);
  if (technical.id !== config.technicalFolderId || technical.mimeType !== folderMime
    || technical.appProperties?.mpApp !== "monpatrimoine-backup-v1" || technical.appProperties.mpKind !== "folder"
    || technical.ownedByMe !== true || technical.shared !== false || technical.trashed !== false
    || technical.driveId || technical.parents?.length !== 1) {
    throw new XlsxPublicationError("destination");
  }
  return technical.parents[0];
}

export function createXlsxDriveTransport({ folderId, technicalFolderId, accessToken, request = fetch, beforeMutation, financial = false, expectedParentId, expectedInstallation, selected = false, fixedDestination = false }: Config): XlsxDrive & {
  listFinancialArchives(): Promise<FinancialArchive[]>;
  cleanupLegacyFinancialArchives(dates: string[], replaced: string[], secured: number[]): Promise<void>;
  downloadFinancialArchive(reference: string): Promise<{ name: string; bytes: Buffer } | null>;
} {
  if (!safeId.test(folderId) || !safeId.test(technicalFolderId)
    || (!selected && financial !== (folderId === technicalFolderId))
    || (selected && (!financial || folderId === technicalFolderId))
    || (financial && (!expectedParentId || !safeId.test(expectedParentId) || expectedParentId === folderId || (!selected && !expectedInstallation)))) {
    throw new XlsxPublicationError("destination");
  }

  const { call, readJson } = createRequests({ technicalFolderId, accessToken, request, beforeMutation });
  const family = financial ? XLSX_FINANCIAL_FAMILY : XLSX_RECIPE_FAMILY;

  async function get(id: string, folderCheck = false) {
    if (!safeId.test(id) || (!folderCheck && (id === technicalFolderId || id === folderId))) throw new XlsxPublicationError("destination");
    const response = await call("files/" + id + "?fields=" + encodeURIComponent(fields));
    if (response.status === 404) return null;
    const file = await readJson<DriveFile>(response);
    if (file.id !== id) throw new XlsxPublicationError("destination");
    return file;
  }

  async function checkFolder() {
    const folder = await get(folderId, true);
    const folderMarker = selected ? !!folder && !folder.appProperties?.mpXlsx && !folder.appProperties?.mpApp : financial
      ? (folder?.name === "MonPatrimoine - Sauvegardes" || folder?.name === "MonPatrimoine — Sauvegardes")
        && folder.appProperties?.mpApp === "monpatrimoine-backup-v1" && folder.appProperties.mpKind === "folder"
        && folder.appProperties.mpInstallation === expectedInstallation && !folder.appProperties.mpXlsx
      : (folder?.name === XLSX_RECIPE_FOLDER || folder?.name === "MonPatrimoine - Recette XLSX")
        && folder.appProperties?.mpXlsx === XLSX_RECIPE_FAMILY && !folder.appProperties.mpApp;
    if (!folder || !folderMarker || (fixedDestination && folder.name !== XLSX_FINANCIAL_FOLDER) || folder.mimeType !== folderMime
      || folder.trashed !== false || folder.ownedByMe !== true || folder.shared !== false || folder.driveId
      || folder.parents?.includes(technicalFolderId) || folder.capabilities?.canAddChildren !== true) {
      throw new XlsxPublicationError("destination");
    }
    // Reject destinations inside the technical tree, even through an intermediate folder.
    // A recipe folder is provisioned directly under the authenticated owner's My Drive root.
    const root = financial ? expectedParentId! : await getMyDriveRoot({ technicalFolderId, accessToken, request });
    if (!safeId.test(root) || root === technicalFolderId || folder.parents?.length !== 1 || folder.parents[0] !== root) {
      throw new XlsxPublicationError("destination");
    }
    const permissions = await readJson<{ permissions?: { type: string; role: string }[]; nextPageToken?: string }>(
      await call("files/" + folderId + "/permissions?fields=nextPageToken,permissions(type,role)"),
    );
    if (permissions.nextPageToken || permissions.permissions?.length !== 1
      || permissions.permissions[0].type !== "user" || permissions.permissions[0].role !== "owner") {
      throw new XlsxPublicationError("destination");
    }
  }

  function checkFile(file: DriveFile, intent: Pick<Intent, "operation" | "date" | "sha256">) {
    const phase = file.appProperties?.mpPhase;
    if ((phase !== "stage" && phase !== "final") || file.mimeType !== PATRIMONIAL_XLSX_MIME || file.shared !== false
      || file.ownedByMe !== true || file.driveId || file.appProperties?.mpApp
      || file.parents?.length !== 1 || file.parents[0] !== folderId
      || file.name !== (phase === "stage" ? stageName(intent) : patrimonialXlsxFilename(intent.date))
      || Object.entries(tags(intent, phase, family)).some(([key, value]) => file.appProperties?.[key] !== value)) {
      throw new XlsxPublicationError("destination");
    }
    return phase;
  }

  async function inspect(intent: Intent) {
    const file = await get(intent.id);
    if (!file) return "missing" as const;
    const phase = checkFile(file, intent);
    return file.trashed === true ? "trashed" as const : phase;
  }

  async function patch(id: string, values: object) {
    const response = await call("files/" + id + "?fields=id", {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(values),
    });
    if (!response.ok) throw apiFailure(response.status);
  }

  async function listFiles<T extends { id: string }>(fileFields: string, filter = "") {
    const files: T[] = [];
    const query = new URLSearchParams({
      q: "'" + folderId + "' in parents and trashed = false and appProperties has { key='mpXlsx' and value='" + family + "' }" + filter,
      fields: "nextPageToken,incompleteSearch,files(" + fileFields + ")", pageSize: "100",
    });
    for (let page = 0; page < 30; page++) {
      const result = await readJson<{ nextPageToken?: string; incompleteSearch?: boolean; files: T[] }>(
        await call("files?" + query),
      );
      if (result.incompleteSearch || !Array.isArray(result.files) || result.files.some(file => !safeId.test(file.id))) {
        throw new XlsxPublicationError("destination");
      }
      files.push(...result.files);
      if (!result.nextPageToken) return files;
      query.set("pageToken", result.nextPageToken);
    }
    throw new XlsxPublicationError("destination");
  }

  async function readMedia(id: string, limit: number) {
    const response = await call("files/" + id + "?alt=media");
    if (response.status === 404) return null;
    if (!response.ok) throw apiFailure(response.status);
    const reader = response.body?.getReader();
    if (!reader) throw new XlsxPublicationError("integrity");
    const chunks: Uint8Array[] = [];
    let size = 0;
    try {
      for (;;) {
        const part = await reader.read();
        if (part.done) break;
        size += part.value.length;
        if (size > limit || size > MAX_XLSX_UPLOAD) {
          await reader.cancel();
          throw new XlsxPublicationError("integrity");
        }
        chunks.push(part.value);
      }
    } catch (error) {
      if (error instanceof XlsxPublicationError) throw error;
      throw new XlsxPublicationError(error instanceof Error && ["AbortError", "TimeoutError"].includes(error.name)
        ? "timeout" : "unconfirmed");
    } finally {
      reader.releaseLock();
    }
    return Buffer.concat(chunks);
  }

  function financialArchive(file: DriveFile) {
    const { mpDate, mpOperation, mpSha256 } = file.appProperties ?? {};
    if (file.trashed !== false || !mpDate || !mpOperation || !publicationId.test(mpOperation)
      || !mpSha256 || !financialArchiveReference.test(mpSha256)) return null;
    try {
      if (checkFile(file, { date: mpDate, operation: mpOperation, sha256: mpSha256 }) !== "final") return null;
    } catch (error) {
      if (error instanceof RangeError || (error instanceof XlsxPublicationError && error.code === "destination")) return null;
      throw error;
    }
    // Resolve this opaque reference only inside the currently authorized Drive folder.
    const reference = createHash("sha256").update(file.id + ":" + mpSha256).digest("hex");
    return { file, sha256: mpSha256, view: { reference, name: file.name, date: mpDate } };
  }

  async function financialArchives() {
    if (!financial) throw new XlsxPublicationError("destination");
    const files = await listFiles<DriveFile>(fields, " and appProperties has { key='mpPhase' and value='final' }");
    return files.flatMap(file => {
      const archive = financialArchive(file);
      return archive ? [archive] : [];
    });
  }

  return {
    checkFolder,
    async list() {
      return (await listFiles("id")).map(file => file.id);
    },
    async listFinancialArchives() {
      return (await financialArchives()).map(archive => archive.view).sort((a, b) => b.date.localeCompare(a.date));
    },
    async cleanupLegacyFinancialArchives(dates, replaced, secured) {
      await checkFolder();
      const entries=await financialArchives();
      const keep=[...new Set([...dates,...entries.map(e=>e.view.date)])].sort().reverse().slice(0,5);
      const december=new Map<number,string>();
      for(const date of [...dates,...entries.map(e=>e.view.date)].sort())
        if(date.slice(5,7)==="12")december.set(Number(date.slice(0,4)),date);
      for(const entry of entries) {
        const date=entry.view.date,year=Number(date.slice(0,4));
        const pinned=date===december.get(year)&&!secured.includes(year)&&!replaced.includes(date);
        if(pinned || (!replaced.includes(date)&&keep.includes(date)))continue;
        await checkFolder();
        const file=await get(entry.file.id);
        if(!file||file.trashed)continue;
        if(financialArchive(file)?.view.reference!==entry.view.reference||file.capabilities?.canTrash!==true)throw new XlsxPublicationError("destination");
        await patch(file.id,{trashed:true});
        if((await get(file.id))?.trashed!==true)throw new XlsxPublicationError("unconfirmed");
      }
    },
    async downloadFinancialArchive(reference) {
      if (!financialArchiveReference.test(reference)) return null;
      const entry = (await financialArchives()).find(archive => archive.view.reference === reference);
      if (!entry) return null;

      const id = entry.file.id;
      async function currentFile() {
        const file = await get(id);
        return file && financialArchive(file)?.view.reference === reference;
      }
      if (!await currentFile()) return null;
      const bytes = await readMedia(id, MAX_XLSX_UPLOAD);
      if (!bytes || !await currentFile()) return null;
      if (!bytes.length || createHash("sha256").update(bytes).digest("hex") !== entry.sha256) {
        throw new XlsxPublicationError("integrity");
      }
      return { name: entry.view.name, bytes };
    },
    async reserve() {
      const id = (await readJson<{ ids?: string[] }>(await call("files/generateIds?count=1&space=drive&type=files"))).ids?.[0];
      if (!id || !safeId.test(id) || id === technicalFolderId || id === folderId) throw new XlsxPublicationError("destination");
      return id;
    },
    async upload(intent, bytes) {
      await checkFolder();
      const metadata = { id: intent.id, name: stageName(intent), parents: [folderId], mimeType: PATRIMONIAL_XLSX_MIME, appProperties: tags(intent, "stage", family) };
      const boundary = "mp_" + randomUUID();
      const prefix = "--" + boundary + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" + JSON.stringify(metadata)
        + "\r\n--" + boundary + "\r\nContent-Type: " + PATRIMONIAL_XLSX_MIME + "\r\n\r\n";
      const body = Buffer.concat([Buffer.from(prefix), bytes, Buffer.from("\r\n--" + boundary + "--\r\n")]);
      const response = await call("files?uploadType=multipart&fields=id", {
        method: "POST", headers: { "Content-Type": "multipart/related; boundary=" + boundary }, body,
      }, true);
      if (!response.ok && response.status !== 409) throw apiFailure(response.status);
    },
    inspect,
    async read(intent) {
      const phase = await inspect(intent);
      if (phase !== "stage" && phase !== "final") throw new XlsxPublicationError("unconfirmed");
      const bytes = await readMedia(intent.id, intent.size);
      if (!bytes) throw apiFailure(404);
      return bytes;
    },
    async promote(intent) {
      await checkFolder();
      const file = await get(intent.id);
      if (!file || file.trashed || checkFile(file, intent) !== "stage" || file.capabilities?.canRename !== true) {
        throw new XlsxPublicationError("destination");
      }
      try { await patch(intent.id, { name: patrimonialXlsxFilename(intent.date), appProperties: tags(intent, "final", family) }); }
      catch (error) {
        if (await inspect(intent) !== "final") throw error;
      }
    },
    async trash(intent) {
      await checkFolder();
      const file = await get(intent.id);
      if (!file || checkFile(file, intent) !== "final") throw new XlsxPublicationError("destination");
      if (file.trashed === true) return;
      if (file.capabilities?.canTrash !== true) throw new XlsxPublicationError("permission");
      try { await patch(intent.id, { trashed: true }); }
      catch (error) {
        if (await inspect(intent) !== "trashed") throw error;
      }
      if (await inspect(intent) !== "trashed") throw new XlsxPublicationError("unconfirmed");
    },
  };
}

export function financialDriveFolders(accessToken: () => Promise<string>, request = fetch) {
  const connection = { accessToken, request, technicalFolderId: "" };
  const { call, readJson } = createRequests(connection);
  const selected = (f: DriveFile) => safeId.test(f.id) && typeof f.name === "string"
    && f.mimeType === folderMime && f.ownedByMe === true && f.shared === false && f.trashed === false
    && !f.driveId && !f.appProperties?.mpApp && !f.appProperties?.mpXlsx
    && f.parents?.length === 1 && safeId.test(f.parents[0]) && f.capabilities?.canAddChildren === true;
  async function listRoot() {
    const folders: { id: string; parent: string }[] = [];
    const query = new URLSearchParams({
      q: "'root' in parents and trashed = false and mimeType = '" + folderMime + "' and name = '" + XLSX_FINANCIAL_FOLDER + "'",
      fields: "nextPageToken,incompleteSearch,files(" + fields + ")", pageSize: "100", spaces: "drive",
    });
    for (let page = 0; page < 10; page++) {
      const result = await readJson<{ nextPageToken?: string; incompleteSearch?: boolean; files?: DriveFile[] }>(await call("files?" + query));
      if (result.incompleteSearch || !Array.isArray(result.files)) throw new XlsxPublicationError("unavailable");
      for (const folder of result.files) {
        if (folder.name !== XLSX_FINANCIAL_FOLDER || folder.mimeType !== folderMime || folder.trashed !== false
          || !safeId.test(folder.id) || folder.parents?.length !== 1 || !safeId.test(folder.parents[0])) {
          throw new XlsxPublicationError("destination");
        }
        folders.push({ id: folder.id, parent: folder.parents[0] });
      }
      if (!result.nextPageToken) return folders;
      query.set("pageToken", result.nextPageToken);
    }
    throw new XlsxPublicationError("unavailable");
  }
  return {
    async identity() {
      const { user } = await readJson<{ user?: { permissionId?: string; emailAddress?: string; displayName?: string } }>(
        await call("about?fields=user(permissionId,emailAddress,displayName)"),
      );
      if (!user?.permissionId || typeof user.permissionId !== "string") throw new XlsxPublicationError("auth");
      return { key: createHash("sha256").update(user.permissionId).digest("hex"), label: user.emailAddress || user.displayName || "Compte Google connecté" };
    },
    listRoot,
    async read(id: string, technicalFolderId: string) {
      if (!safeId.test(id) || id === technicalFolderId) throw new XlsxPublicationError("destination");
      const response = await call("files/" + id + "?fields=" + encodeURIComponent(fields));
      if (response.status === 404) throw new XlsxPublicationError("destination");
      const folder = await readJson<DriveFile>(response);
      if (folder.id !== id || folder.name !== XLSX_FINANCIAL_FOLDER || !selected(folder)) throw new XlsxPublicationError("destination");
      const parent = folder.parents![0];
      if (parent === technicalFolderId) throw new XlsxPublicationError("destination");
      await createXlsxDriveTransport({
        folderId: id, technicalFolderId, expectedParentId: parent, financial: true, selected: true, accessToken, request,
      }).checkFolder();
      return { id, parent, name: folder.name };
    },
  };
}

/** Discover only folders marked by this app. Do not adopt any name-only match. */
export async function findXlsxRecipeFolder(config: Connection) {
  const { call, readJson } = createRequests(config);
  const query = new URLSearchParams({
    q: "trashed = false and mimeType = '" + folderMime
      + "' and appProperties has { key='mpXlsx' and value='" + XLSX_RECIPE_FAMILY + "' }",
    fields: "nextPageToken,incompleteSearch,files(id)", pageSize: "100", corpora: "user",
  });
  const result = await readJson<{ nextPageToken?: string; incompleteSearch?: boolean; files?: { id: string }[] }>(
    await call("files?" + query),
  );
  if (result.nextPageToken || result.incompleteSearch || !Array.isArray(result.files) || result.files.length > 1) {
    throw new XlsxPublicationError("destination");
  }
  const folderId = result.files[0]?.id;
  if (!folderId) {
    if (result.files.length) throw new XlsxPublicationError("destination");
    return null;
  }
  await createXlsxDriveTransport({ ...config, folderId }).checkFolder();
  return folderId;
}

export async function prepareXlsxRecipeFolder(config: Connection, reservedId?: string) {
  const existing = await findXlsxRecipeFolder(config);
  if (existing) return { status: "isolated", folderId: existing };
  const { call, readJson } = createRequests(config);
  if (!reservedId) {
    const { ids } = await readJson<{ ids?: string[] }>(await call("files/generateIds?count=1&space=drive&type=files"));
    const id = ids?.[0];
    if (!id || !safeId.test(id) || id === config.technicalFolderId) throw new XlsxPublicationError("destination");
    return { status: "reserved", reservation: id };
  }
  if (!safeId.test(reservedId) || reservedId === config.technicalFolderId) throw new XlsxPublicationError("destination");
  const root = await getMyDriveRoot(config);
  if (!safeId.test(root) || root === config.technicalFolderId || root === reservedId) {
    throw new XlsxPublicationError("destination");
  }
  const created = await call("files?fields=id", {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      id: reservedId, name: XLSX_RECIPE_FOLDER, mimeType: folderMime,
      appProperties: { mpXlsx: XLSX_RECIPE_FAMILY },
    }),
  });
  // A repeated create cannot overwrite an existing ID. Validate it before returning.
  if (created.status !== 409 && (await readJson<{ id: string }>(created)).id !== reservedId) {
    throw new XlsxPublicationError("unconfirmed");
  }
  await createXlsxDriveTransport({ ...config, folderId: reservedId }).checkFolder();
  return { status: "isolated", folderId: reservedId };
}
