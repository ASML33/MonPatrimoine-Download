import {createFinancialBatchDrive} from "./financial-batch-drive";
import {listPublishedFinancialBatches,verifiedBatchInventory,downloadBatchReference} from "./financial-batch-inventory";
import "server-only";
import { createAdminClient } from "../supabase/admin";
import { getDriveConnection } from "./google-drive";
import { DriveError } from "./google-drive-core";
import { createXlsxDriveTransport, financialDriveFolders, XLSX_FINANCIAL_FOLDER } from "./xlsx-drive-transport";
import { XlsxPublicationError } from "./xlsx-publication";

const noTechnicalFolder = "no_technical_folder";
type Destination = {
  status: string; folder: string | null; parent: string | null; account: string | null;
  technical: string | null; enabled: boolean;
};

async function destination(owner: string, selection?: { id: string; parent: string; account: string }) {
  const { data, error } = await createAdminClient().rpc("xlsx_financial_destination", {
    p_owner: owner, p_folder: selection?.id, p_parent: selection?.parent, p_account: selection?.account,
  }).abortSignal(AbortSignal.timeout(8000));
  if (error) throw new XlsxPublicationError(error.code === "42501" || error.code === "22023" ? "destination" : "unavailable");
  if (!data || typeof data.status !== "string") throw new XlsxPublicationError("unconfirmed");
  return data as Destination;
}

export function financialDriveToken(owner: string) {
  const connection = getDriveConnection();
  if (!connection) throw new XlsxPublicationError("auth");
  let token: Promise<string> | undefined;
  return () => token ??= connection.accessTokenForPrincipal(owner).catch(error => {
    throw new XlsxPublicationError(error instanceof DriveError && error.code === "reconnect_required" ? "auth" : "unavailable");
  });
}

export function publicationDriveConfig(claim: Record<string, unknown>) {
  const folderId = typeof claim.folder === "string" ? claim.folder : "";
  const technicalFolderId = typeof claim.technicalFolder === "string" ? claim.technicalFolder : noTechnicalFolder;
  if (folderId !== technicalFolderId && typeof claim.driveAccount === "string" && typeof claim.driveParent === "string") {
    return { folderId, technicalFolderId, expectedParentId: claim.driveParent, selected: true, account: claim.driveAccount };
  }
  if (folderId !== process.env.XLSX_FINANCIAL_FOLDER_ID || folderId !== technicalFolderId
    || typeof claim.installation !== "string" || !process.env.XLSX_FINANCIAL_PARENT_ID
    || (claim.driveParent != null && claim.driveParent !== process.env.XLSX_FINANCIAL_PARENT_ID)) {
    throw new XlsxPublicationError("destination");
  }
  return { folderId, technicalFolderId, expectedParentId: process.env.XLSX_FINANCIAL_PARENT_ID,
    expectedInstallation: claim.installation, selected: false,
    account: typeof claim.driveAccount === "string" ? claim.driveAccount : null };
}

async function resolveFinancialDestination(owner: string, accessToken: () => Promise<string>) {
  const folders = financialDriveFolders(accessToken);
  const [cfg, account, matches] = await Promise.all([destination(owner), folders.identity(), folders.listRoot()]);
  const registered = cfg.enabled && cfg.account === account.key
    ? matches.find(folder => folder.id === cfg.folder && folder.parent === cfg.parent)
    : undefined;
  const candidate = registered ?? (matches.length === 1 ? matches[0] : undefined);
  if (!candidate) return { account, candidate: null };

  const technicalId = cfg.technical ?? noTechnicalFolder;
  let drive: ReturnType<typeof createXlsxDriveTransport>;
  let config: Parameters<typeof createXlsxDriveTransport>[0];
  try {
    if (candidate.id === technicalId) {
      if (candidate.id !== process.env.XLSX_FINANCIAL_FOLDER_ID
        || candidate.parent !== process.env.XLSX_FINANCIAL_PARENT_ID) {
        throw new XlsxPublicationError("destination");
      }
      const root = await createAdminClient().rpc("application_backup_drive_store", {
        operation: "root", actor: owner, args: {},
      }).abortSignal(AbortSignal.timeout(8000));
      if (root.error) throw new XlsxPublicationError("unavailable");
      drive = createXlsxDriveTransport(config = {
        accessToken, folderId: candidate.id, technicalFolderId: technicalId, financial: true,
        fixedDestination: true, expectedParentId: candidate.parent, expectedInstallation: root.data?.installation,
      });
      await drive.checkFolder();
    } else {
      const actual = await folders.read(candidate.id, technicalId);
      if (actual.parent !== candidate.parent) throw new XlsxPublicationError("destination");
      drive = createXlsxDriveTransport(config = { accessToken, folderId: actual.id, technicalFolderId: technicalId,
        financial: true, fixedDestination: true, expectedParentId: actual.parent, selected: true });
    }
  } catch (error) {
    if (error instanceof XlsxPublicationError && ["destination", "permission"].includes(error.code)) {
      return { account, candidate: null };
    }
    throw error;
  }
  return { account, candidate, registered: !!registered, drive, config };
}

export async function financialDestinationView(owner: string) {
  const { account, candidate, drive,config } = await resolveFinancialDestination(owner, financialDriveToken(owner));
  if(!drive||!config||!candidate)return {account:account.label,active:null,archives:null};
  const batches=await listPublishedFinancialBatches(owner,candidate.id);
  const batchDrive=createFinancialBatchDrive(config,()=>drive.checkFolder());
  const inventory=await verifiedBatchInventory(batches,batchDrive);
  // Existing verified XLSX remain readable until the first complete multi-file publication.
  const legacy=batches.some(b=>b.complete)?[]:await drive.listFinancialArchives();
  return { account:account.label,active:{name:XLSX_FINANCIAL_FOLDER},
    archives:inventory.files.length||batches.some(b=>b.complete)?inventory.files:legacy,
    batchReference:inventory.reference };
}
export async function downloadFinancialArchive(owner: string, reference: string) {
  const { drive,config,candidate } = await resolveFinancialDestination(owner, financialDriveToken(owner));
  if (!drive||!config||!candidate) throw new XlsxPublicationError("destination");
  const batches=await listPublishedFinancialBatches(owner,candidate.id);
  const file=await downloadBatchReference(batches,reference,createFinancialBatchDrive(config,()=>drive.checkFolder()));
  return file??drive.downloadFinancialArchive(reference);
}

export async function ensureFinancialDestination(owner: string, accessToken: () => Promise<string>) {
  const { account, candidate, registered } = await resolveFinancialDestination(owner, accessToken);
  // drive.file does not establish absence, even for a first connection.
  if (!candidate) throw new XlsxPublicationError("destination");
  if (!registered) {
    const result = await destination(owner, { ...candidate, account: account.key });
    if (result.status === "busy") throw new XlsxPublicationError("busy");
    if (result.status !== "saved") throw new XlsxPublicationError("unconfirmed");
  }
  return { folder: candidate.id, parent: candidate.parent, account: account.key };
}
