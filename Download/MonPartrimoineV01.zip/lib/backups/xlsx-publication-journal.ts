
import { isAbsolute, join } from "node:path";
import { createRequire } from "node:module";
import { XlsxPublicationError, type Intent, type Journal } from "./xlsx-publication";

type Statement = {
  run(...args: string[]): unknown;
  get(...args: string[]): Record<string, unknown> | undefined;
  all(...args: string[]): Record<string, unknown>[];
};
type Database = { exec(sql: string): void; prepare(sql: string): Statement; close(): void };
const { DatabaseSync } = createRequire(import.meta.url)("node:sqlite") as {
  DatabaseSync: new (filename: string) => Database;
};

/** Single-host recipe journal. The OS releases the separate lock transaction when its process exits. */
export function openXlsxJournal(directory: string, scope: string) {
  if (!isAbsolute(directory) || !scope) throw new XlsxPublicationError("destination");
  const mutex = new DatabaseSync(join(directory, "xlsx-publication.lock.sqlite"));
  try {
    const database = new DatabaseSync(join(directory, "xlsx-publication.sqlite"));
    try {
      database.exec("PRAGMA synchronous=FULL; PRAGMA busy_timeout=2500");
      database.exec(
        "CREATE TABLE IF NOT EXISTS publication_scope (singleton INTEGER PRIMARY KEY CHECK(singleton=1), value TEXT NOT NULL);"
        + "CREATE TABLE IF NOT EXISTS publication_intents (operation TEXT PRIMARY KEY, payload TEXT NOT NULL);"
        + "CREATE TABLE IF NOT EXISTS publication_events (operation TEXT NOT NULL, outcome TEXT NOT NULL, at TEXT NOT NULL);",
      );
      database.prepare("INSERT OR IGNORE INTO publication_scope VALUES(1, ?)").run(scope);
      if (database.prepare("SELECT value FROM publication_scope WHERE singleton=1").get()?.value !== scope) {
        throw new XlsxPublicationError("destination");
      }
      const journal: Journal = {
        async exclusive(callback) {
          try { mutex.exec("BEGIN IMMEDIATE"); }
          catch (error) {
            if (error instanceof Error && "errcode" in error && [5, 6].includes(Number(error.errcode))) {
              throw new XlsxPublicationError("busy");
            }
            throw error;
          }
          try { return await callback(); }
          finally { mutex.exec("ROLLBACK"); }
        },
        list() {
          return database.prepare("SELECT payload FROM publication_intents ORDER BY rowid").all()
            .map(row => JSON.parse(String(row.payload)) as Intent);
        },
        save(intent) {
          database.exec("BEGIN IMMEDIATE");
          try {
            database.prepare("INSERT INTO publication_intents VALUES(?, ?) ON CONFLICT(operation) DO UPDATE SET payload=excluded.payload")
              .run(intent.operation, JSON.stringify(intent));
            this.event(intent.operation, intent.state);
            database.exec("COMMIT");
          } catch (error) {
            database.exec("ROLLBACK");
            throw error;
          }
        },
        event(operation, code) {
          database.prepare("INSERT INTO publication_events VALUES(?, ?, ?)").run(operation, code, new Date().toISOString());
        },
      };
      return { journal, close() { try { database.close(); } finally { mutex.close(); } } };
    } catch (error) {
      database.close();
      throw error;
    }
  } catch (error) {
    mutex.close();
    throw error;
  }
}
