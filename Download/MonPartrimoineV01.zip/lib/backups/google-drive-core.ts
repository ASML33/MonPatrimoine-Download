import { createCipheriv, createDecipheriv, createHash, randomBytes, randomUUID } from "node:crypto";

export const DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.file";
export const DRIVE_ORIGIN = "https://example.invalid";
export const DRIVE_CALLBACK_PATH = "/api/backups/google-drive/oauth/callback";
export type DriveActor = { userId: string; sessionId: string };
export type DriveConfig = { clientId: string; clientSecret: string; encryptionKey: string };
export type DriveStatus = "not_configured" | "not_connected" | "connected" | "needs_check" | "reconnect_required" | "unavailable";
export type DriveView = { status: DriveStatus; verifiedAt: string | null };
export type DriveRecord = { revision: number; cipher: string | null; status: string; verified_at: string | null; expires_at: string | null };
export type DriveStore = (operation: string, actor: string, args?: Record<string, unknown>) => Promise<unknown>;
type Tokens = { accessToken: string; refreshToken: string; expiresAt: number; scope: string };
type Dependencies = { store: DriveStore; fetch: typeof fetch; now?: () => number; sleep?: (ms: number) => Promise<void> };

export class DriveError extends Error {
  readonly code: "unavailable" | "reconnect_required" | "invalid_state" | "scope_rejected" | "consent_denied";
  constructor(code: DriveError["code"]) { super(code); this.name = "DriveError"; this.code = code; }
}
export function digest(value: string) { return createHash("sha256").update(value).digest("hex"); }
function key(config: DriveConfig) {
  if (!/^[A-Za-z0-9+/]{43}=$/.test(config.encryptionKey)) throw new DriveError("unavailable");
  const bytes = Buffer.from(config.encryptionKey, "base64");
  if (bytes.length !== 32) throw new DriveError("unavailable");
  return bytes;
}
export function seal(value: unknown, context: string, config: DriveConfig) {
  const iv = randomBytes(12), cipher = createCipheriv("aes-256-gcm", key(config), iv);
  cipher.setAAD(Buffer.from(context));
  return Buffer.concat([iv, cipher.update(JSON.stringify(value), "utf8"), cipher.final(), cipher.getAuthTag()]).toString("base64");
}
export function unseal(value: string, context: string, config: DriveConfig): unknown {
  try {
    if (value.length > 32768) throw new Error();
    const bytes = Buffer.from(value, "base64");
    if (bytes.length < 29) throw new Error();
    const decipher = createDecipheriv("aes-256-gcm", key(config), bytes.subarray(0, 12));
    decipher.setAAD(Buffer.from(context)); decipher.setAuthTag(bytes.subarray(-16));
    return JSON.parse(Buffer.concat([decipher.update(bytes.subarray(12, -16)), decipher.final()]).toString("utf8"));
  } catch { throw new DriveError("unavailable"); }
}
function record(value: unknown): DriveRecord {
  const row = value as DriveRecord | null;
  if (!row || !Number.isSafeInteger(row.revision) || row.revision < 0 || typeof row.status !== "string") throw new DriveError("unavailable");
  return row;
}
function tokens(value: unknown): Tokens {
  const t = value as Tokens | null;
  if (!t || typeof t.accessToken !== "string" || !t.accessToken || typeof t.refreshToken !== "string" || !t.refreshToken || !Number.isFinite(t.expiresAt) || t.scope !== DRIVE_SCOPE) throw new DriveError("unavailable");
  return t;
}
export function validActor(actor: DriveActor | null): actor is DriveActor {
  return !!actor && /^[0-9a-f-]{36}$/i.test(actor.userId) && /^[0-9a-f-]{36}$/i.test(actor.sessionId);
}

export function getDriveOrigin() {
  const configured = process.env.GOOGLE_DRIVE_OAUTH_ORIGIN;
  if (configured === undefined) return DRIVE_ORIGIN;
  const value = configured.trim();
  if (!/^https?:\/\/[^/?#\\\s@]+\/?$/i.test(value)) return null;
  try {
    const url = new URL(value);
    const loopback = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
    return url.protocol === "https:" || (url.protocol === "http:" && loopback) ? url.origin : null;
  } catch {
    return null;
  }
}

export function acceptsPost(request: Request, origin: string) {
  return request.method === "POST" && new URL(request.url).origin === origin && request.headers.get("origin") === origin && request.headers.get("sec-fetch-site") !== "cross-site";
}
export function createDriveConnection(config: DriveConfig, deps: Dependencies) {
  key(config);
  const origin = getDriveOrigin();
  if (!config.clientId || !config.clientSecret || !origin) throw new DriveError("unavailable");
  const callback = origin + DRIVE_CALLBACK_PATH;
  const now = deps.now ?? Date.now;
  const sleep = deps.sleep ?? ((ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms)));
  const context = (userId: string) => `monpatrimoine:drive:v1:${config.clientId}:${userId}`;
  const session = (actor: DriveActor) => digest(`${actor.userId}:${actor.sessionId}`);
  async function store(op: string, actor: DriveActor, args: Record<string, unknown> = {}) {
    if (!validActor(actor)) throw new DriveError("unavailable");
    try { return await deps.store(op, actor.userId, args); } catch { throw new DriveError("unavailable"); }
  }
  async function tokenRequest(body: Record<string, string>, refresh: boolean) {
    for (let attempt = 0; attempt < (refresh ? 2 : 1); attempt++) {
      try {
        const response = await deps.fetch("https://oauth2.googleapis.com/token", {
          method: "POST", cache: "no-store", redirect: "error", signal: AbortSignal.timeout(10000),
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: new URLSearchParams({ ...body, client_id: config.clientId, client_secret: config.clientSecret }),
        });
        if ((response.status === 429 || response.status >= 500) && refresh && attempt === 0) {
          const wait = response.headers.get("retry-after");
          // Do not retry sooner than Google's requested delay; long delays fail closed.
          if (wait && (!/^\d+$/.test(wait) || Number(wait) > 2)) throw new DriveError("unavailable");
          await response.body?.cancel(); await sleep(wait ? Number(wait) * 1000 : 250); continue;
        }
        const data = await response.json() as Record<string, unknown>;
        if (!response.ok) {
          if (data.error === "invalid_grant") throw new DriveError("reconnect_required");
          throw new DriveError("unavailable");
        }
        if ((!refresh && data.scope !== DRIVE_SCOPE) || (refresh && data.scope !== undefined && data.scope !== DRIVE_SCOPE)) throw new DriveError("scope_rejected");
        if (data.token_type !== "Bearer" || typeof data.access_token !== "string" || !data.access_token || data.access_token.length > 8192 || typeof data.expires_in !== "number" || !Number.isFinite(data.expires_in) || data.expires_in < 1 || data.expires_in > 86400) throw new DriveError("unavailable");
        if (data.refresh_token !== undefined && (typeof data.refresh_token !== "string" || !data.refresh_token || data.refresh_token.length > 8192)) throw new DriveError("unavailable");
        return data;
      } catch (error) {
        if (error instanceof DriveError) throw error;
        // A lost authorization-code response is ambiguous: never replay the code.
        if (refresh && attempt === 0) { await sleep(250); continue; }
        throw new DriveError("unavailable");
      }
    }
    throw new DriveError("unavailable");
  }
  async function verify(accessToken: string) {
    try {
      const r = await deps.fetch("https://www.googleapis.com/drive/v3/about?fields=kind,user(permissionId)", { cache: "no-store", redirect: "error", signal: AbortSignal.timeout(10000), headers: { Authorization: `Bearer ${accessToken}` } });
      if (r.status === 401) throw new DriveError("reconnect_required");
      if (!r.ok) throw new DriveError("unavailable");
      const about = await r.json() as { kind?: unknown; user?: { permissionId?: unknown } };
      if (about.kind !== "drive#about") throw new DriveError("unavailable");
      return typeof about.user?.permissionId === "string" ? about.user.permissionId : null;
    } catch (error) { if (error instanceof DriveError) throw error; throw new DriveError("unavailable"); }
  }
  // Only trusted server entry points may resolve a principal without a browser.
  // The existing store RPC independently rechecks the active application principal.
  async function accessTokenForPrincipal(userId: string, check = false): Promise<string> {
    if (!/^[0-9a-f-]{36}$/i.test(userId)) throw new DriveError("unavailable");
    const principalStore = async (op: string, args: Record<string, unknown> = {}) => {
      try { return await deps.store(op, userId, args); } catch { throw new DriveError("unavailable"); }
    };
      const row = record(await principalStore("load"));
      if (!row.cipher || row.status !== "connected") throw new DriveError("reconnect_required");
      let current = tokens(unseal(row.cipher, context(userId), config));
      if (!check && current.expiresAt > now() + 60000) return current.accessToken;
      const lease = randomUUID();
      if (await principalStore("claim", { revision: row.revision, lease }) !== true) throw new DriveError("unavailable");
      try {
        // The explicit POST check exercises renewal too; normal server callers
        // keep a valid token until the renewal margin is reached.
        if (check || current.expiresAt <= now() + 60000) {
          const r = await tokenRequest({ refresh_token: current.refreshToken, grant_type: "refresh_token" }, true);
          current = { accessToken: r.access_token as string, refreshToken: (r.refresh_token as string | undefined) ?? current.refreshToken, expiresAt: now() + (r.expires_in as number) * 1000, scope: DRIVE_SCOPE };
        }
        await verify(current.accessToken);
        if (await principalStore("refresh", { revision: row.revision, lease, cipher: seal(current, context(userId), config), expires_at: new Date(current.expiresAt).toISOString() }) !== true) throw new DriveError("unavailable");
        return current.accessToken;
      } catch (error) {
        const reconnect = error instanceof DriveError && ["reconnect_required", "scope_rejected"].includes(error.code);
        await principalStore("release", { revision: row.revision, lease, reconnect });
        throw error instanceof DriveError ? error : new DriveError("unavailable");
      }
  }
  return {
    async status(actor: DriveActor): Promise<DriveView> {
      const row = record(await store("load", actor));
      // A changed client/key must not make an unreadable old credential appear connected.
      if (row.cipher) tokens(unseal(row.cipher, context(actor.userId), config));
      const status: DriveStatus = row.status === "reconnect_required" ? "reconnect_required"
        : !row.cipher ? "not_connected" : row.status !== "connected" || !row.verified_at ? "unavailable"
          : !row.expires_at || Date.parse(row.expires_at) <= now() + 60000 ? "needs_check" : "connected";
      return { status, verifiedAt: row.verified_at };
    },
    async start(actor: DriveActor) {
      const state = randomBytes(32).toString("base64url"), verifier = randomBytes(48).toString("base64url");
      const stateHash = digest(state);
      await store("begin", actor, { state_hash: stateHash, session_hash: session(actor), verifier: seal({ verifier }, `${context(actor.userId)}:state:${stateHash}`, config) });
      const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
      url.search = new URLSearchParams({ client_id: config.clientId, redirect_uri: callback, response_type: "code", scope: DRIVE_SCOPE, access_type: "offline", prompt: "select_account consent", include_granted_scopes: "false", state, code_challenge: digestToChallenge(verifier), code_challenge_method: "S256" }).toString();
      return url.toString();
    },
    async finish(actor: DriveActor, params: URLSearchParams) {
      const state = params.get("state");
      if (!state || !/^[A-Za-z0-9_-]{43}$/.test(state) || ["state", "code", "error"].some((p) => params.getAll(p).length > 1)) throw new DriveError("invalid_state");
      const stateHash = digest(state);
      const used = await store("consume", actor, { state_hash: stateHash, session_hash: session(actor) }) as { verifier?: unknown; revision?: unknown } | null;
      if (!used || typeof used.verifier !== "string" || !Number.isSafeInteger(used.revision)) throw new DriveError("invalid_state");
      // Consumption is atomic and happens for consent denial too.
      if (params.has("error")) throw new DriveError(params.get("error") === "access_denied" ? "consent_denied" : "unavailable");
      const code = params.get("code");
      if (!code || code.length > 8192) throw new DriveError("invalid_state");
      const secret = unseal(used.verifier, `${context(actor.userId)}:state:${stateHash}`, config) as { verifier?: unknown };
      if (typeof secret.verifier !== "string") throw new DriveError("invalid_state");
      const response = await tokenRequest({ code, redirect_uri: callback, code_verifier: secret.verifier, grant_type: "authorization_code" }, false);
      const old = record(await store("load", actor));
      if (old.revision !== used.revision) throw new DriveError("invalid_state");
      const accessToken = response.access_token as string;
      const identity = await verify(accessToken);
      let refreshToken = response.refresh_token as string | undefined;
      if (!refreshToken && identity && old.status === "connected" && old.cipher) {
        const previous = tokens(unseal(old.cipher, context(actor.userId), config));
        const previousIdentity = await verify(previous.accessToken).catch(() => null);
        if (identity === previousIdentity) refreshToken = previous.refreshToken;
      }
      if (!refreshToken) throw new DriveError("reconnect_required");
      const fresh: Tokens = { accessToken, refreshToken, expiresAt: now() + (response.expires_in as number) * 1000, scope: DRIVE_SCOPE };
      if (await store("connect", actor, { revision: used.revision, cipher: seal(fresh, context(actor.userId), config), expires_at: new Date(fresh.expiresAt).toISOString() }) !== true) throw new DriveError("invalid_state");
    },
    // Server-only caller receives the access token; UI and route handlers never serialize it.
    async accessToken(actor: DriveActor, check = false): Promise<string> {
      if (!validActor(actor)) throw new DriveError("unavailable");
      return accessTokenForPrincipal(actor.userId, check);
    },
    accessTokenForPrincipal,
  };
}
function digestToChallenge(verifier: string) { return createHash("sha256").update(verifier).digest("base64url"); }
