import 'server-only';
export function readArchiveKey(){
 const raw=process.env.APPLICATION_BACKUP_ENCRYPTION_KEY??'';
 const key=Buffer.from(raw,'base64');
 if(key.length!==32||key.toString('base64')!==raw||key.equals(Buffer.from(process.env.GOOGLE_DRIVE_TOKEN_ENCRYPTION_KEY??'','base64')))return null;
 return key;
}
