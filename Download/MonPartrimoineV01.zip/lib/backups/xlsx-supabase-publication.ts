import { publicationId, validateWorkbook, verifiedRead, XlsxPublicationError, type Intent, type Workbook, type XlsxDrive } from "./xlsx-publication";

type Action = "claim" | "guard" | "reserve" | "stage" | "verify" | "trash_next" | "trash_confirm" | "finish" | "release";
type Reply = Record<string, unknown>;
export type XlsxRpc = (action: Action, revision: string | null, details: Record<string, string | number | boolean>) => Promise<Reply>;
type Mutations = Pick<XlsxDrive, "upload" | "promote" | "trash">;
type Drive = Omit<XlsxDrive, keyof Mutations | "list"> & Mutations;

const driveId = /^[A-Za-z0-9_-]{5,160}$/;
const sha256 = /^[0-9a-f]{64}$/;
const dateFormat = /^\d{4}-\d{2}-\d{2}$/;
function status(result: Reply, expected: string) {
  if (result.status !== expected) throw new XlsxPublicationError("unconfirmed");
}
function fileId(value: unknown): string {
  if (typeof value !== "string" || !driveId.test(value)) throw new XlsxPublicationError("unconfirmed");
  return value;
}

export function createSupabaseXlsxPublisher(
  rpc: XlsxRpc, createDrive: (beforeMutation: () => Promise<number>) => Drive,
) {
  return async (
    operation: string, date: string, generate: () => Promise<Workbook>,
    inspect?: Parameters<typeof validateWorkbook>[2],
  ) => {
    if (!publicationId.test(operation) || !dateFormat.test(date)) throw new XlsxPublicationError("invalid");
    const { bytes, size, sha256: checksum } = await validateWorkbook(await generate(), date, inspect);
    const claim = await rpc("claim", null, { business_date: date, byte_size: size, sha256: checksum });
    if (claim.status === "busy") throw new XlsxPublicationError("busy");
    if (claim.status === "completed") {
      if (claim.phase !== "verified" && claim.phase !== "retired") throw new XlsxPublicationError("conflict");
      return { status: claim.phase === "retired" ? "retired" : "already_published", date, size, sha256: checksum };
    }
    status(claim, "claimed");
    if (typeof claim.revision !== "string" || !/^[1-9][0-9]{0,18}$/.test(claim.revision)) {
      throw new XlsxPublicationError("unconfirmed");
    }
    const command = (action: Action, details = {}) => rpc(action, claim.revision as string, details);
    try {
      const drive = createDrive(async () => {
        const guard = await command("guard");
        status(guard, "authorized");
        const expires = typeof guard.lease_until === "string" ? Date.parse(guard.lease_until) : NaN;
        const timeout = Math.min(12_000, expires - Date.now() - 5_000);
        if (!Number.isFinite(timeout) || timeout < 1_000) throw new XlsxPublicationError("busy");
        return timeout;
      });
      await drive.checkFolder();
      let id = claim.drive_file_id;
      if (claim.phase === "pending" && id === null) {
        id = await drive.reserve();
        const reserved = await command("reserve", { drive_file_id: fileId(id) });
        status(reserved, "reserved");
        if (reserved.drive_file_id !== id) throw new XlsxPublicationError("unconfirmed");
      } else if (!["reserved", "staged", "verified"].includes(String(claim.phase))) {
        throw new XlsxPublicationError("unconfirmed");
      }
      const intent: Intent = { operation, id: fileId(id), date, size, sha256: checksum, state: "staging", replaced: 0, rotated: 0 };
      const proof = { drive_file_id: intent.id, byte_size: size, sha256: checksum };
      let phase = await drive.inspect(intent);
      if (claim.phase === "pending" || claim.phase === "reserved") {
        if (phase === "missing") {
          try { await drive.upload(intent, bytes); }
          catch (error) {
            if (await drive.inspect(intent) !== "stage") throw error;
          }
          phase = await drive.inspect(intent);
        }
        if (phase !== "stage") throw new XlsxPublicationError("unconfirmed");
        await verifiedRead(drive, intent);
        status(await command("stage", proof), "staged");
      }
      // Confirm the verified bytes while the new file still has its temporary
      // name. A lost or refused SQL confirmation must leave the old file alone.
      if (phase !== "stage" && phase !== "final") throw new XlsxPublicationError("unconfirmed");
      if (claim.phase !== "pending" && claim.phase !== "reserved") await verifiedRead(drive, intent);
      status(await command("verify", proof), "verified");
      // SQL selects only pending retirement intents of this verified publication.
      // The Drive transport checks the target's parent, family and exact marker before PATCH.
      for (let count = 0; count < 100; count++) {
        try {
          const target = await command("trash_next");
          if (target.status === "none") {
            // The sync client must never see two managed files with the same final name.
            if (phase === "stage") await drive.promote(intent);
            if (await drive.inspect(intent) !== "final") throw new XlsxPublicationError("unconfirmed");
            await verifiedRead(drive, intent);
            status(await command("finish"), "completed");
            return { status: "published", date, size, sha256: checksum };
          }
          status(target, "planned");
          if (typeof target.target_id !== "string" || !publicationId.test(target.target_id)
            || target.target_id === operation || target.drive_file_id === intent.id
            || typeof target.business_date !== "string" || !dateFormat.test(target.business_date)
            || typeof target.sha256 !== "string" || !sha256.test(target.sha256)
            || !Number.isSafeInteger(target.byte_size) || Number(target.byte_size) < 1) {
            throw new XlsxPublicationError("unconfirmed");
          }
          const retiring: Intent = {
            ...intent, operation: target.target_id, id: fileId(target.drive_file_id),
            date: target.business_date, sha256: target.sha256, size: Number(target.byte_size), state: "done",
          };
          await drive.trash(retiring);
          status(await command("trash_confirm", { target_id: retiring.operation, drive_file_id: retiring.id, trashed: true }), "retired");
        } catch {
          throw new XlsxPublicationError("cleanup_pending");
        }
      }
      throw new XlsxPublicationError("cleanup_pending");
    } finally {
      // Release never clears the active operation. The same key must resume a partial publication.
      await command("release").catch(() => {});
    }
  };
}
