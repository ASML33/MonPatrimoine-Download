import { createHash, randomUUID } from "node:crypto";
import { createRequests, type Config } from "./xlsx-drive-transport";
import { XlsxPublicationError } from "./xlsx-publication";

export const BATCH_FAMILY = "mp-financial-batch-v1";
export type BatchFile = {
  key: string; name: string; mime: string; sha256: string; size: number; id: string;
  contractId?: string; contractLabel?: string; year?: number; archive: boolean;
};
export type Batch = { operation: string; date: string; capturedAt: string; files: BatchFile[]; complete: boolean };
export const batchReference = (file: BatchFile) => createHash("sha256").update(file.id + ":" + file.sha256).digest("hex");
const limit = 5 * 1024 * 1024;
const safe = /^[A-Za-z0-9_-]{5,160}$/;
export function createFinancialBatchDrive(config: Config, checkFolder: () => Promise<void>) {
  const { call, readJson } = createRequests(config);
  function properties(batch: Batch, file: BatchFile, phase: string) {
    return { mpBatch: BATCH_FAMILY, mpOperation: batch.operation, mpPhase: phase, mpSha256: file.sha256,
      mpDate: batch.date, mpArchive: file.archive ? "yes" : "no", mpKey: file.key };
  }
  const stage = (b: Batch, f: BatchFile) => ".mp-batch-" + b.operation + "-" + f.key;
  const held = (b: Batch, f: BatchFile) => ".mp-previous-" + b.operation + "-" + f.key;
  async function inspect(batch: Batch, file: BatchFile) {
    if (!safe.test(file.id)) throw new XlsxPublicationError("destination");
    const response = await call("files/" + file.id + "?fields=id,name,mimeType,parents,appProperties,trashed,shared,ownedByMe,driveId");
    if (response.status === 404) return null;
    const record = await readJson<{ id: string; name: string; mimeType: string; parents: string[]; appProperties: Record<string, string>; trashed: boolean; shared: boolean; ownedByMe: boolean; driveId?: string }>(response);
    const phase = record.appProperties?.mpPhase;
    if (!["stage", "final", "held"].includes(phase) || record.id !== file.id || record.mimeType !== file.mime || record.shared !== false || record.ownedByMe !== true
      || record.driveId || record.parents?.length !== 1 || record.parents[0] !== config.folderId
      || record.name !== (phase === "stage" ? stage(batch, file) : phase === "held" ? held(batch, file) : file.name)
      || Object.entries(properties(batch, file, phase)).some(([key, value]) => record.appProperties[key] !== value)) throw new XlsxPublicationError("destination");
    return record;
  }
  async function patch(batch: Batch, file: BatchFile, phase: "final" | "held") {
    await checkFolder();
    const record = await inspect(batch, file);
    if (!record || record.trashed) throw new XlsxPublicationError("unconfirmed");
    const response = await call("files/" + file.id, { method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: phase === "held" ? held(batch, file) : file.name, appProperties: properties(batch, file, phase) }) });
    if (!response.ok) throw new XlsxPublicationError("unconfirmed");
  }
  const read = async (batch: Batch, file: BatchFile) => {
    await checkFolder();
    const record = await inspect(batch, file);
    if (!record || record.trashed) throw new XlsxPublicationError("unconfirmed");
    const response = await call("files/" + file.id + "?alt=media");
    if (!response.ok || !response.body) throw new XlsxPublicationError("unconfirmed");
    const reader = response.body.getReader(), chunks: Uint8Array[] = [];
    let size = 0;
    try {
      for (;;) {
        const part = await reader.read();
        if (part.done) break;
        size += part.value.length;
        if (size > file.size || size > limit) { await reader.cancel(); throw new XlsxPublicationError("integrity"); }
        chunks.push(part.value);
      }
    } finally { reader.releaseLock(); }
    const bytes = Buffer.concat(chunks);
    if (bytes.length !== file.size || createHash("sha256").update(bytes).digest("hex") !== file.sha256) throw new XlsxPublicationError("integrity");
    const after = await inspect(batch, file);
    if (!after || after.trashed) throw new XlsxPublicationError("unconfirmed");
    return bytes;
  };
  return {
    read,
    async exists(batch: Batch, file: BatchFile) {
      const record = await inspect(batch, file);
      return !!record && !record.trashed && ["final", "held"].includes(record.appProperties.mpPhase);
    },
    async reserve() {
      const result = await readJson<{ ids: string[] }>(await call("files/generateIds?count=1&space=drive&type=files"));
      if (!result.ids?.[0] || !safe.test(result.ids[0])) throw new XlsxPublicationError("unconfirmed");
      return result.ids[0];
    },
    async stage(batch: Batch, file: BatchFile, bytes: Uint8Array) {
      await checkFolder();
      if (await inspect(batch, file)) { await read(batch, file); return; }
      const boundary = "mp_" + randomUUID();
      const metadata = { id: file.id, name: stage(batch, file), parents: [config.folderId], mimeType: file.mime, appProperties: properties(batch, file, "stage") };
      const body = Buffer.concat([Buffer.from("--" + boundary + "\r\nContent-Type: application/json\r\n\r\n" + JSON.stringify(metadata)
        + "\r\n--" + boundary + "\r\nContent-Type: " + file.mime + "\r\n\r\n"), bytes, Buffer.from("\r\n--" + boundary + "--\r\n")]);
      const response = await call("files?uploadType=multipart&fields=id", { method: "POST",
        headers: { "Content-Type": "multipart/related; boundary=" + boundary }, body }, true);
      if (!response.ok && response.status !== 409) throw new XlsxPublicationError("unconfirmed");
      await read(batch, file);
    },
    hold: (b: Batch, f: BatchFile) => patch(b, f, "held"),
    promote: (b: Batch, f: BatchFile) => patch(b, f, "final"),
    async trash(batch: Batch, file: BatchFile) {
      if (file.archive) throw new XlsxPublicationError("destination");
      await checkFolder();
      const record = await inspect(batch, file);
      if (!record || record.trashed) return;
      const response = await call("files/" + file.id, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ trashed: true }) });
      if (!response.ok) throw new XlsxPublicationError("unconfirmed");
      if (!(await inspect(batch, file))?.trashed) throw new XlsxPublicationError("unconfirmed");
    },
  };
}
