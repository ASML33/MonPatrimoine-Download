
import { createHash } from "node:crypto";
import JSZip from "jszip";
import { patrimonialXlsxFilename } from "../exports/patrimonial-xlsx-values";
import { PATRIMONIAL_XLSX_MIME } from "../exports/patrimonial-xlsx";

export const XLSX_RECIPE_FAMILY = "mp-patrimoine-xlsx-recette-v1";
export const MAX_XLSX_UPLOAD = 5 * 1024 * 1024;
export const publicationId = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;

type Code = "busy" | "conflict" | "invalid" | "destination" | "integrity" | "unconfirmed"
  | "auth" | "permission" | "rate_limit" | "timeout" | "unavailable" | "cleanup_pending";

export class XlsxPublicationError extends Error {
  readonly code: Code;
  readonly diagnostic?: { operation: string; upstream?: number; reason?: string };
  constructor(code: Code, diagnostic?: XlsxPublicationError["diagnostic"]) {
    super(code);
    this.code = code;
    this.diagnostic = diagnostic;
  }
}

export type Workbook = { filename: string; mimeType: string; bytes: Uint8Array };
export type Intent = {
  operation: string;
  id: string;
  date: string;
  size: number;
  sha256: string;
  state: "staging" | "committing" | "done" | "retired" | "rejected";
  replaced: number;
  rotated: number;
};
export type Journal = {
  exclusive<T>(callback: () => Promise<T>): Promise<T>;
  list(): Intent[];
  save(intent: Intent): void;
  event(operation: string, code: string): void;
};
export type XlsxDrive = {
  checkFolder(): Promise<void>;
  list(): Promise<string[]>;
  reserve(): Promise<string>;
  upload(intent: Intent, bytes: Uint8Array): Promise<void>;
  inspect(intent: Intent): Promise<"stage" | "final" | "trashed" | "missing">;
  read(intent: Intent): Promise<Uint8Array>;
  promote(intent: Intent): Promise<void>;
  trash(intent: Intent): Promise<void>;
};

const paris = new Intl.DateTimeFormat("fr-FR", {
  timeZone: "Europe/Paris", year: "numeric", month: "2-digit", day: "2-digit",
});

export function parisBackupDate(now: Date): string {
  const parts = paris.formatToParts(now);
  return ["year", "month", "day"].map(type => parts.find(part => part.type === type)?.value).join("-");
}

function digest(bytes: Uint8Array) {
  return createHash("sha256").update(bytes).digest("hex");
}

export async function validateWorkbook(workbook: Workbook, date: string, inspect?: (zip: JSZip) => Promise<void>) {
  if (workbook.filename !== patrimonialXlsxFilename(date) || workbook.mimeType !== PATRIMONIAL_XLSX_MIME
    || !(workbook.bytes instanceof Uint8Array) || !workbook.bytes.length || workbook.bytes.length > MAX_XLSX_UPLOAD) {
    throw new XlsxPublicationError("invalid");
  }
  // This boundary only accepts workbooks supplied by the trusted server-side generator.
  // Snapshot the bytes before asynchronous validation and upload.
  const bytes = Buffer.from(workbook.bytes);
  try {
    const zip = await JSZip.loadAsync(bytes, { checkCRC32: true });
    const fixed = ["[Content_Types].xml", "_rels/.rels", "xl/workbook.xml", "xl/_rels/workbook.xml.rels", "xl/styles.xml"];
    const names = Object.keys(zip.files);
    const sheets = names.filter(name => /^xl\/worksheets\/sheet[1-9]\d*\.xml$/.test(name));
    if (!sheets.length || names.length !== sheets.length + fixed.length || fixed.some(name => !zip.file(name))) throw Error();
    let xmlSize = 0;
    for (const name of [...fixed, ...sheets]) {
      const entry = zip.file(name);
      if (!entry || entry.unsafeOriginalName !== name) throw Error();
      const xml = await entry.async("string");
      xmlSize += Buffer.byteLength(xml);
      if (xmlSize > 32 * 1024 * 1024 || !xml.startsWith("<?xml ")
        || /<!DOCTYPE|<!ENTITY|TargetMode\s*=\s*["']External|<(?:\w+:)?(?:f|hyperlink|externalReference)\b|macroEnabled|vbaProject/i.test(xml)) throw Error();
    }
    const workbookXml = await zip.file("xl/workbook.xml")!.async("string");
    const relationships = await zip.file("xl/_rels/workbook.xml.rels")!.async("string");
    if ((workbookXml.match(/<sheet name="\d{4}"/g) ?? []).length !== sheets.length
      || sheets.some(name => !relationships.includes('Target="' + name.slice(3) + '"'))) throw Error();
    await inspect?.(zip);
  } catch {
    throw new XlsxPublicationError("invalid");
  }
  return { bytes, size: bytes.length, sha256: digest(bytes) };
}

export async function verifiedRead(drive: Pick<XlsxDrive, "read">, intent: Intent) {
  const bytes = await drive.read(intent);
  if (bytes.length !== intent.size || digest(bytes) !== intent.sha256) throw new XlsxPublicationError("integrity");
}

function result(intent: Intent) {
  return {
    status: intent.state === "retired" ? "retired" : "published",
    date: intent.date, sha256: intent.sha256, size: intent.size, replaced: intent.replaced, rotated: intent.rotated,
  } as const;
}

export function createXlsxPublisher(drive: XlsxDrive, journal: Journal, now = () => new Date()) {
  async function confirmScope() {
    await drive.checkFolder();
    const known = new Map(journal.list().map(row => [row.id, row]));
    for (const id of await drive.list()) {
      const row = known.get(id);
      if (!row || (row.state === "retired" && await drive.inspect(row) !== "trashed")) {
        throw new XlsxPublicationError("destination");
      }
    }
  }

  async function finish(intent: Intent) {
    if (await drive.inspect(intent) === "stage") await drive.promote(intent);
    if (await drive.inspect(intent) !== "final") throw new XlsxPublicationError("unconfirmed");
    await verifiedRead(drive, intent);
    const old = journal.list().filter(row => row.state === "done" && row.operation !== intent.operation);
    const dates = [...new Set([intent.date, ...old.map(row => row.date)])].sort().slice(-5);
    const retiring = old.filter(row => row.date === intent.date || !dates.includes(row.date));
    try {
      for (const row of retiring) {
        await drive.trash(row);
        // Persist retirement and its counters atomically, including after lost Drive responses.
        journal.save({ ...row, state: "retired" });
      }
    } catch (error) {
      journal.event(intent.operation, "cleanup_" + (error instanceof XlsxPublicationError ? error.code : "unavailable"));
      throw new XlsxPublicationError("cleanup_pending");
    }
    // Counter totals were frozen before the first cleanup call so retries give the same receipt.
    const done = { ...intent, state: "done" } as const;
    journal.save(done);
    return result(done);
  }

  return async function publish(operation: string, generate: (date: string) => Promise<Workbook>) {
    if (!publicationId.test(operation)) throw new XlsxPublicationError("invalid");
    return journal.exclusive(async () => {
      try {
        const records = journal.list();
        let intent = records.find(row => row.operation === operation);
        if (intent?.state === "retired") return result(intent);
        if (intent?.state === "rejected") throw new XlsxPublicationError("conflict");
        if (records.some(row => row.operation !== operation && ["staging", "committing"].includes(row.state))) {
          throw new XlsxPublicationError("busy");
        }
        const date = intent?.date ?? parisBackupDate(now());
        const previous = records.filter(row => row.state === "done");
        const dates = [...new Set([date, ...previous.map(row => row.date)])].sort().slice(-5);
        if (!dates.includes(date)) throw new XlsxPublicationError("conflict");
        // A failure to generate or validate cannot cause a Drive write.
        const workbook = intent?.state === "committing" || intent?.state === "done"
          ? null : await validateWorkbook(await generate(date), date);
        if (intent && workbook && (intent.size !== workbook.size || intent.sha256 !== workbook.sha256)) {
          throw new XlsxPublicationError("conflict");
        }
        await confirmScope();
        if (intent?.state === "done") {
          if (await drive.inspect(intent) !== "final") throw new XlsxPublicationError("unconfirmed");
          await verifiedRead(drive, intent);
          return result(intent);
        }
        if (intent?.state === "committing") return await finish(intent);
        if (!workbook) throw new XlsxPublicationError("invalid");
        if (!intent) {
          intent = {
            operation, date, id: await drive.reserve(), size: workbook.size, sha256: workbook.sha256, state: "staging",
            replaced: previous.filter(row => row.date === date).length,
            rotated: previous.filter(row => !dates.includes(row.date)).length,
          };
          journal.save(intent);
        }
        let stage = await drive.inspect(intent);
        if (stage === "missing") {
          try { await drive.upload(intent, workbook.bytes); }
          catch (error) {
            stage = await drive.inspect(intent);
            if (stage === "missing") throw error;
          }
          stage = await drive.inspect(intent);
        }
        if (stage !== "stage") throw new XlsxPublicationError("unconfirmed");
        try { await verifiedRead(drive, intent); }
        catch (error) {
          if (error instanceof XlsxPublicationError && error.code === "integrity") {
            journal.save({ ...intent, state: "rejected" });
          }
          throw error;
        }
        const committing = { ...intent, state: "committing" } as const;
        journal.save(committing);
        return await finish(committing);
      } catch (error) {
        const failure = error instanceof XlsxPublicationError ? error : new XlsxPublicationError("unavailable");
        journal.event(operation, failure.code);
        throw failure;
      }
    });
  };
}
