import { XlsxPublicationError } from "./xlsx-publication";

export function financialJson(data: unknown, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "private, no-store" } });
}

export async function validFinancialPost(request: Request, origin: string | undefined) {
  if (!origin || request.method !== "POST" || request.headers.get("origin") !== origin
    || new URL(request.url).origin !== origin || request.headers.get("sec-fetch-site") === "cross-site") return false;
  const length = request.headers.get("content-length");
  if (length !== null && length !== "0") return false;
  if (!request.body) return true;
  const reader = request.body.getReader();
  try {
    for (;;) {
      const chunk = await reader.read();
      if (chunk.done) return true;
      if (chunk.value.byteLength > 0) { await reader.cancel(); return false; }
    }
  } finally { reader.releaseLock(); }
}

const failures = {
  auth: [503, "Connexion Google Drive indisponible. Vérifiez la connexion, puis reprenez la sauvegarde."],
  permission: [403, "Google Drive refuse l’accès au dossier de sauvegarde."],
  destination: [403, "Le dossier de sauvegarde ou son autorisation n’a pas été validé."],
  conflict: [409, "La reprise ne correspond pas à la sauvegarde en attente."],
  busy: [409, "Une sauvegarde est en cours. Réessayez après sa fin."],
  invalid: [422, "Le classeur ne peut pas être produit avec les données ou les dimensions disponibles."],
  integrity: [422, "La relecture du fichier diffère du classeur attendu."],
  rate_limit: [429, "Google Drive limite temporairement les appels. Reprenez la sauvegarde plus tard."],
  timeout: [503, "Le délai a été dépassé. Reprenez la sauvegarde."],
  unconfirmed: [503, "La publication reste à confirmer. Reprenez la sauvegarde."],
  unavailable: [503, "La sauvegarde est temporairement indisponible."],
  cleanup_pending: [503, "Le fichier a été vérifié. Reprenez la sauvegarde pour terminer la rotation."],
} as const;

export function financialError(error: unknown) {
  const code = error instanceof XlsxPublicationError ? error.code : "unavailable";
  const [status, message] = failures[code];
  return financialJson({ code, message }, status);
}
