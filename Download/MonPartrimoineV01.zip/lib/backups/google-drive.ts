import "server-only";

import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { createDriveConnection, type DriveActor, type DriveView, validActor } from "./google-drive-core";

export async function getDriveActor(): Promise<DriveActor | null> {
  try {
    const client = await createClient();
    const { data: user, error } = await client.auth.getUser();
    if (error || !user.user) return null;
    const { data: allowed, error: denied } = await client.rpc("is_authorized_user");
    if (denied || allowed !== true) return null;
    const { data: verified, error: claimsError } = await client.auth.getClaims();
    if (claimsError || verified?.claims.sub !== user.user.id || typeof verified.claims.session_id !== "string") return null;
    const actor = { userId: user.user.id, sessionId: verified.claims.session_id };
    return validActor(actor) ? actor : null;
  } catch { return null; }
}

export function getDriveConnection() {
  const clientId = process.env.GOOGLE_DRIVE_CLIENT_ID?.trim();
  const clientSecret = process.env.GOOGLE_DRIVE_CLIENT_SECRET?.trim();
  const encryptionKey = process.env.GOOGLE_DRIVE_TOKEN_ENCRYPTION_KEY?.trim();
  if (!clientId || !clientSecret || !encryptionKey) return null;
  return createDriveConnection({ clientId, clientSecret, encryptionKey }, {
    fetch,
    async store(operation, actor, args = {}) {
      const { data, error } = await createAdminClient().rpc("google_drive_connection_store", { operation, actor, args });
      if (error) throw new Error("Drive unavailable");
      return data;
    },
  });
}

export async function getDriveConnectionView(): Promise<DriveView> {
  // No configuration values or encrypted records are ever passed to React.
  try {
    const actor = await getDriveActor();
    if (!actor) return { status: "unavailable", verifiedAt: null };
    const connection = getDriveConnection();
    if (!connection) return { status: "not_configured", verifiedAt: null };
    return await connection.status(actor);
  } catch { return { status: "unavailable", verifiedAt: null }; }
}

export async function getGoogleDriveAccessToken(): Promise<string> {
  const actor = await getDriveActor();
  const connection = getDriveConnection();
  if (!actor || !connection) throw new Error("Drive unavailable");
  return connection.accessToken(actor);
}
