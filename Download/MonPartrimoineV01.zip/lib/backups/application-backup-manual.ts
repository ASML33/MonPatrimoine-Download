import 'server-only';
import {createAdminClient} from '@/lib/supabase/admin';
import {getDriveActor,getGoogleDriveAccessToken,getDriveConnectionView} from './google-drive';
import {createApplicationBackupServer} from './application-backup-server';
import {createDriveArchiveStore} from './drive-archive-store.mjs';
import {readArchiveKey} from './archive-key';
export async function createManualBackupService(){
 const actor=await getDriveActor();
 if(!actor||process.env.APPLICATION_BACKUP_ENABLED!=='true')return null;
 const key=readArchiveKey();if(!key)return null;
 if(!['connected','needs_check'].includes((await getDriveConnectionView()).status))return null;
 async function metadata(operation:string,args:Record<string,unknown>){
  const {data,error}=await createAdminClient().rpc('application_backup_drive_store',{operation,actor:actor!.userId,args});
  if(error)throw Error('Backup metadata unavailable');return data;
 }
 const store=createDriveArchiveStore({accessToken:getGoogleDriveAccessToken,metadata,key});
 return {store,core:createApplicationBackupServer({key,store}),load:(id:string)=>metadata('load',{operation_id:id})};
}
