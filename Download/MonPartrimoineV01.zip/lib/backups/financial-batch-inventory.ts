
import { createAdminClient } from "../supabase/admin";
import { type PublishedBatch } from "./financial-batch";
import { batchReference, type createFinancialBatchDrive } from "./financial-batch-drive";
import { XlsxPublicationError } from "./xlsx-publication";
export async function listPublishedFinancialBatches(owner: string, folder: string): Promise<PublishedBatch[]> {
 const {data,error}=await createAdminClient().rpc("financial_batch_store",{
  p_owner:owner,p_folder:folder,p_operation:null,p_action:"list",p_token:null,
 }).abortSignal(AbortSignal.timeout(8000));
 if(error)throw new XlsxPublicationError(error.code==="42501"?"destination":"unavailable");
 if(!data||!Array.isArray(data.batches))throw new XlsxPublicationError("unconfirmed");
 return data.batches as PublishedBatch[];
}
export type Attachment = {reference:string;name:string;date:string;capturedAt:string;contractId?:string;contractLabel?:string;year?:number;archive:boolean;kind:"xlsx"|"json"};
export async function verifiedBatchInventory(batches: PublishedBatch[],drive:Pick<ReturnType<typeof createFinancialBatchDrive>,"exists">) {
 const latest=batches.filter(b=>b.complete&&!b.retired).sort((a,b)=>b.date.localeCompare(a.date)||b.capturedAt.localeCompare(a.capturedAt))[0];
 const entries=batches.filter(b=>b.complete).flatMap(batch=>batch.files.filter(file=>file.archive||batch.operation===latest?.operation).map(file=>({batch,file})));
 const files:Attachment[]=[];
 for(const {batch,file} of entries)if(await drive.exists(batch,file))files.push({
  reference:batchReference(file),name:file.name,date:batch.date,capturedAt:batch.capturedAt,contractId:file.contractId,
  contractLabel:file.contractLabel,year:file.year,archive:file.archive,kind:file.mime==="application/json"?"json":"xlsx",
 });
 return {files,reference:latest?{date:latest.date,capturedAt:latest.capturedAt}:null};
}
export async function downloadBatchReference(batches:PublishedBatch[],reference:string,drive:Pick<ReturnType<typeof createFinancialBatchDrive>,"exists"|"read">) {
 for(const batch of batches.filter(b=>b.complete))for(const file of batch.files.filter(f=>f.archive||!batch.retired)) {
  if(batchReference(file)!==reference)continue;
  if(!await drive.exists(batch,file))return null;
  return {name:file.name,mime:file.mime,bytes:await drive.read(batch,file)};
 }
 return null;
}
