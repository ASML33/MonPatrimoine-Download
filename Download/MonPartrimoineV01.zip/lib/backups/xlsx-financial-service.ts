import "server-only";
import JSZip from "jszip";
import { randomUUID } from "node:crypto";
import { setTimeout as wait } from "node:timers/promises";
import { createAdminClient } from "../supabase/admin";
import { mapFiscalRuleRow, type FiscalRuleRow } from "../fiscal/fiscal-settings";
import { PATRIMONIAL_XLSX_MIME, serializePatrimonialXlsx } from "../exports/patrimonial-xlsx";
import { projectPatrimonialHistory } from "../exports/patrimonial-xlsx-model";
import type { PatrimonialReportRecords } from "../reports/patrimonial-report-core";
import type { HistoricalObservation } from "../patrimony/historical-observations";
import { createXlsxDriveTransport } from "./xlsx-drive-transport";
import { ensureFinancialDestination, financialDriveToken, publicationDriveConfig } from "./xlsx-financial-destination";
import {
  assembleFinancialHistory, captureFinancialDay, projectArchivedFinancialDay, type FrozenFinancialDay,
} from "./xlsx-financial-history";
import { publicationId, XlsxPublicationError } from "./xlsx-publication";
import { publishFinancialBatch, jsonContent } from "./financial-batch";
import { createFinancialBatchDrive } from "./financial-batch-drive";
import { contractHistories } from "../exports/contract-json";
import { inspectFinancialWorkbook } from "./xlsx-financial-verification";

const uuid = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
type Action = "claim" | "prepare" | "read_days" | "finish" | "failure" | "seed_lease" | "seed_read" | "seed_insert" | "seed_release";
type Result = { status: string; [key: string]: unknown };
type RawSnapshot = Omit<PatrimonialReportRecords, "fiscalRules" | "fiscalPreferences"> & {
  fiscalRules: FiscalRuleRow[];
  fiscalPreferences: { fiscal_regime_id: string; use_personal_rule: boolean }[];
};

function financialStore(owner: string) {
  if (!uuid.test(owner)) throw new XlsxPublicationError("destination");
  const client = createAdminClient();
  return async (action: Action, params: { operation?: string; date?: string; mode?: string; payload?: unknown } = {}) => {
    const { data, error } = await client.rpc("xlsx_financial_store", {
      p_owner: owner, p_action: action, p_operation: params.operation, p_mode: params.mode,
      p_date: params.date, p_payload: params.payload,
    }).abortSignal(AbortSignal.timeout(8_000));
    if (error) throw new XlsxPublicationError(error.code === "42501" ? "destination" : error.code === "22023" ? "conflict" : "unavailable");
    if (!data || typeof data.status !== "string") throw new XlsxPublicationError("unconfirmed");
    return data as Result;
  };
}

// Each batch owns a short SQL lease. Every committed day advances the
// existing immutable seed cursor, including across browser or function loss.
export async function initializeFinancialXlsx(owner: string, budgetMs: number, maxDays: number) {
  const store = financialStore(owner);
  const operation = randomUUID();
  const claim = await store("seed_lease", { operation });
  if (claim.status === "seeded") return { status: "seeded", imported: 0 } as const;
  if (claim.status === "busy") throw new XlsxPublicationError("busy");
  if (claim.status !== "leased") throw new XlsxPublicationError("unconfirmed");
  const deadline = Date.now() + budgetMs;
  let imported = 0;
  try {
    while (Date.now() < deadline && imported < maxDays) {
      const result = await seedFinancialXlsxDay(store, operation);
      if (result.status === "seeded") return { status: "seeded", imported } as const;
      imported++;
    }
    return { status: "initializing", imported } as const;
  } finally {
    await store("seed_release", { operation }).catch(() => {});
  }
}

async function seedFinancialXlsxDay(store: ReturnType<typeof financialStore>, operation: string) {
  const source = await store("seed_read", { operation });
  if (source.status === "seeded") return { status: "seeded" };
  if (source.status !== "source" || typeof source.date !== "string" || !Array.isArray(source.captures)
    || typeof source.cutoff !== "string" || !Array.isArray(source.sources)) {
    throw new XlsxPublicationError("unconfirmed");
  }
  type Seed = NonNullable<Parameters<typeof projectArchivedFinancialDay>[2]>;
  const day = projectArchivedFinancialDay(source.captures as HistoricalObservation[],
    source.identities as Parameters<typeof projectArchivedFinancialDay>[1], {
      date: source.date, cutoff: source.cutoff, sources: source.sources as Seed["sources"], assets: source.assets as Seed["assets"],
      positions: source.positionEvidence as Seed["positions"], balances: source.balanceEvidence as Seed["balances"],
      manual: source.manualEvidence as Seed["manual"], manualSources: source.manualSources as Seed["manualSources"],
    });
  if (day.date !== source.date) throw new XlsxPublicationError("integrity");
  const inserted = await store("seed_insert", { operation, date: day.date, payload: day });
  if (inserted.status !== "seeded_day") throw new XlsxPublicationError("unconfirmed");
  return { status: inserted.status, date: day.date };
}

export async function publishFinancialXlsx(owner: string, mode: "manual" | "automatic", date: string,
  requestedOperation?: string, stillScheduled?: () => boolean) {
  const deadline = Date.now() + 55_000;
  const attempt = async () => {
    for (;;) {
      if (stillScheduled && !stillScheduled()) throw new XlsxPublicationError("timeout");
      try { return await publishOneFinancialXlsx(owner, mode, date, deadline, requestedOperation); }
      catch (error) {
        if (!stillScheduled || !(error instanceof XlsxPublicationError) || error.code !== "busy"
          || deadline - Date.now() <= 20_000) throw error;
        await wait(2_000);
      }
    }
  };
  const first = await attempt();
  if (mode === "automatic" && typeof first.date === "string"
    && (first.date < date || ("capturedMode" in first && first.capturedMode === "manual"))) {
    // Reconcile a pending operation in its original mode and date before
    // taking the automatic snapshot, within the same function budget.
    console.info("xlsx_financial_reconciled", { date: first.date, status: first.status });
    if (deadline - Date.now() < 5_000) throw new XlsxPublicationError("timeout");
    return attempt();
  }
  return first;
}

async function publishOneFinancialXlsx(owner: string, mode: "manual" | "automatic", date: string, deadline: number, requestedOperation?: string) {
  const injectedOperation = mode === "manual" ? requestedOperation : undefined;
  if (mode === "manual" && !publicationId.test(injectedOperation ?? "")) {
    throw new XlsxPublicationError("destination");
  }
  const accessToken = financialDriveToken(owner);
  const binding = await ensureFinancialDestination(owner, accessToken);
  const store = financialStore(owner);
  const claim = await store("claim", { mode, date, operation: injectedOperation });
  if (claim.status === "busy") throw new XlsxPublicationError("busy");
  if (claim.status === "already_published" || claim.status === "cancelled") return { status: claim.status, date: claim.date };
  if (claim.status !== "claimed" || typeof claim.operation !== "string" || !publicationId.test(claim.operation)
    || typeof claim.date !== "string" || typeof claim.capturedAt !== "string"
    || (claim.mode !== "manual" && claim.mode !== "automatic")) throw new XlsxPublicationError("destination");

  const operation = claim.operation, businessDate = claim.date;
  function budget() {
    const remaining = deadline - Date.now();
    if (remaining < 1_000) throw new XlsxPublicationError("timeout");
    return remaining;
  }
  try {
    const { account, ...driveConfig } = publicationDriveConfig(claim);
    if (account !== binding.account || driveConfig.folderId !== binding.folder
      || driveConfig.expectedParentId !== binding.parent) throw new XlsxPublicationError("destination");
    await createXlsxDriveTransport({ ...driveConfig, financial: true, fixedDestination: true, accessToken }).checkFolder();
    const days: FrozenFinancialDay[] = [];
    let cursor: string | undefined;
    for (;;) {
      budget();
      const portion = await store("read_days", { operation, date: cursor });
      if (portion.status !== "days" || !Array.isArray(portion.days)) throw new XlsxPublicationError("unconfirmed");
      const next = portion.days as FrozenFinancialDay[];
      days.push(...next);
      if (next.length < 32) break;
      const last = next.at(-1)!.date;
      if (last === cursor || days.length > 36525) throw new XlsxPublicationError("invalid");
      cursor = last;
    }
    let current = claim.prepared as FrozenFinancialDay | null;
    if (!current) {
      const raw = claim.source as RawSnapshot;
      const records: PatrimonialReportRecords = {
        ...raw, fiscalRules: raw.fiscalRules.map(mapFiscalRuleRow),
        fiscalPreferences: raw.fiscalPreferences.map(p => ({ fiscalRegimeId: p.fiscal_regime_id, usePersonalRule: p.use_personal_rule })),
      };
      current = captureFinancialDay(records, businessDate, claim.capturedAt);
      const sameDate = days.find(d => d.date === businessDate);
      if (sameDate) {
        for (const contract of sameDate.contracts) if (!current.contracts.some(c => c.id === contract.id)) current.contracts.push(contract);
        current.series = [...sameDate.series, ...current.series.filter(s => !sameDate.series.some(old => s.id === old.id))];
      }
      const prepared = await store("prepare", { operation, payload: current });
      if (prepared.status !== "prepared") throw new XlsxPublicationError("unconfirmed");
      current = prepared.day as FrozenFinancialDay;
    }
    const history = assembleFinancialHistory(days, current);
    const partial = history.days.some(d => d.observations.length < history.series.length ||
      d.observations.some(o => o.evidence.kind === "unavailable" || o.evidence.kind === "unverified" ||
        o.evidence.kind === "asset" && [o.evidence.quantity, o.evidence.historicalPruEur, o.evidence.grossEur]
          .some(c => c.kind === "unavailable" || c.kind === "unverified")));
    let projection: ReturnType<typeof projectPatrimonialHistory>;
    try { projection = projectPatrimonialHistory(history); }
    catch { throw new XlsxPublicationError("invalid"); }
    const scope = {
      contracts: history.contracts.length,
      assets: new Set(history.series.flatMap(s => s.kind === "asset" ? [s.assetId] : [])).size,
      rows: projection.rows.length,
      firstDate: history.days[0]?.date,
      lastDate: businessDate,
      initializedDates: days.length,
      reconciledContractDays: days.filter(day => day.date < businessDate)
        .reduce((count, day) => count + (day.reconciledContracts ?? 0), current.reconciledContracts ?? 0),
    };
    let coverage: (typeof scope & Awaited<ReturnType<typeof inspectFinancialWorkbook>>) | undefined;
    const client = createAdminClient();
    let leaseToken = "";
    const batchStore = async (action: string, token: string, payload?: unknown) => {
      leaseToken = token;
      const { data, error } = await client.rpc("financial_batch_store", {
        p_owner: owner, p_folder: driveConfig.folderId, p_operation: operation, p_action: action, p_token: token, p_payload: payload,
      }).abortSignal(AbortSignal.timeout(action === "release" ? 2_000 : Math.min(8_000,budget())));
      if(error)throw new XlsxPublicationError(error.code==="42501"?"destination":"unavailable");
      if(!data||typeof data!=="object")throw new XlsxPublicationError("unconfirmed");
      return data as Record<string,unknown>;
    };
    const config = {...driveConfig, financial:true, fixedDestination:true, accessToken,
      beforeMutation:async()=>{await batchStore("guard",leaseToken);return budget();}};
    const folder = createXlsxDriveTransport(config);
    const published = await publishFinancialBatch({operation,date:businessDate,capturedAt:claim.capturedAt,
      store:batchStore,drive:createFinancialBatchDrive(config,()=>folder.checkFolder()),
      legacyDecember:async(year)=>{
        const last=(await folder.listFinancialArchives()).filter(f=>f.date.startsWith(year+"-12")).sort((a,b)=>b.date.localeCompare(a.date))[0];
        if(!last)return null;
        const file=await folder.downloadFinancialArchive(last.reference);
        if(!file)throw new XlsxPublicationError("unconfirmed");
        return {key:"archive-"+year+"-xlsx",name:"ARCHIVE_"+year+"_Patrimoine.xlsx",mime:PATRIMONIAL_XLSX_MIME,bytes:file.bytes,archive:true,year};
      },
      cleanupLegacy:async(batches)=>folder.cleanupLegacyFinancialArchives(
        batches.filter(b=>!b.retired).map(b=>b.date),batches.filter(b=>!b.retired).map(b=>b.date),
        batches.flatMap(b=>b.securedDecember===undefined?[]:[b.securedDecember])),
      generate:async()=>{
        const bytes=await serializePatrimonialXlsx(projection);
        coverage={...scope,...await inspectFinancialWorkbook(await JSZip.loadAsync(bytes),projection)};
        const documents=contractHistories([...days.filter(d=>d.date!==businessDate),current!],operation,claim.capturedAt as string,businessDate);
        return [{key:"xlsx",name:projection.filename,mime:PATRIMONIAL_XLSX_MIME,bytes,archive:false},
          ...documents.map(doc=>jsonContent(doc,businessDate))];
      }});
    return { ...published, operation, partial, coverage, capturedMode: claim.mode };
  } catch (error) {
    const code = error instanceof XlsxPublicationError ? error.code : "unavailable";
    await store("failure", { operation, payload: { code } }).catch(() => {});
    throw new XlsxPublicationError(code);
  }
}
