import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";
// Reuse the verified getUser + principal RPC + verified session claims guard.
// No Google connection/credential operation is called by this identity helper.
import { getDriveActor as getVerifiedSessionActor } from "./google-drive";
import { createApplicationBackupService } from "./application-backup-core.mjs";
import { rpcBackupError } from "./backup-errors.mjs";

type Confirmation = { reference: string; archiveSha256: string; contentDigest: string; verified: true; kind: "local-test" | "google-drive" };
export type BackupStore = {
  save(bytes: Buffer): Promise<string> | string;
  read(reference: string): Promise<Buffer> | Buffer;
  confirm(backup: Omit<Confirmation, "kind" | "verified">): Promise<Confirmation> | Confirmation;
};

// Trusted server supplies its dedicated archive key and verified transport.
// The manual route composes this factory only when explicitly configured.
export function createApplicationBackupServer({ key, store }: { key: Buffer; store: BackupStore }) {
  return createApplicationBackupService({
    getActor: getVerifiedSessionActor,
    key,
    store,
    async rpc(operation: string, actor: { userId: string; sessionId: string }, args: Record<string, unknown>) {
      const { data, error } = await createAdminClient().rpc("application_backup_server", { operation, actor, args });
      if (error) throw rpcBackupError(operation,error.code);
      return data;
    },
  });
}
