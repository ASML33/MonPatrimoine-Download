import { timingSafeEqual } from "node:crypto";
import { parisBusinessDate } from "../dates/business-date";

const parisClock = new Intl.DateTimeFormat("en-GB", {
  timeZone: "Europe/Paris", hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23",
});

export function automatedFinancialWindow(now: Date) {
  // At 03:00 on the spring transition, one minute before 03:00 Paris
  // would be 01:59. Check the corresponding UTC instant at the top of the hour.
  const parts = parisClock.formatToParts(now);
  const part = (type: string) => Number(parts.find(p => p.type === type)?.value);
  const hour = part("hour"), minute = part("minute"), second = part("second");
  if (minute > 15 || (minute === 15 && (second > 0 || now.getMilliseconds() > 0))) return null;
  const previousHour = new Date(now.getTime() - (minute * 60 + second + 1) * 1000);
  if (hour !== 2 && !(hour === 3 && parisClock.format(previousHour).startsWith("01:59:"))) return null;
  return parisBusinessDate(now);
}

export function authorizedFinancialScheduler(header: string | null, secret: string | undefined) {
  if (!secret || secret.length < 32 || !header?.startsWith("Bearer ")) return false;
  const got = Buffer.from(header.slice(7)), expected = Buffer.from(secret);
  return got.length === expected.length && timingSafeEqual(got, expected);
}

export function scheduledFinancialDate(now: Date, scheduledAt: string | null) {
  if (!scheduledAt) return null;
  const intended = new Date(scheduledAt);
  if (!Number.isFinite(intended.getTime()) || intended > now) return null;
  const date = automatedFinancialWindow(now);
  return date && automatedFinancialWindow(intended) === date ? date : null;
}
