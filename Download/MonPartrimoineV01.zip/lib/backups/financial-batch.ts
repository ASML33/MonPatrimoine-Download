
import { createHash, randomUUID } from "node:crypto";
import { annualContractArchive, contractJsonName, validateContractJson, type ContractJson } from "../exports/contract-json";
import { batchReference, type Batch, type BatchFile, type createFinancialBatchDrive } from "./financial-batch-drive";
import { XlsxPublicationError } from "./xlsx-publication";
export type PublishedBatch = Batch & { retired?: boolean; cleaned?: boolean; securedDecember?: number; warnings?: string[] };
type Contents = { key: string; name: string; mime: string; bytes: Uint8Array; contractId?: string; contractLabel?: string; year?: number; archive: boolean };
export type BatchPlan = { batch: PublishedBatch; contents: Record<string,string> };
export type BatchStore = (action: string, token: string, payload?: unknown) => Promise<Record<string,unknown>>;
export type BatchDrive = Pick<ReturnType<typeof createFinancialBatchDrive>, "reserve" | "stage" | "read" | "promote" | "exists" | "trash">;
const hash = (bytes: Uint8Array) => createHash("sha256").update(bytes).digest("hex");
export const jsonMime = "application/json";
export function jsonContent(doc: ContractJson, date: string, year?: number): Contents {
  validateContractJson(doc);
  return {key: (year ? "archive-" + year + "-" : "contract-") + doc.contrat.reference,
    name:contractJsonName(doc.contrat,date,year),mime:jsonMime,bytes:Buffer.from(JSON.stringify(doc,null,2)+"\n"),
    contractId:doc.contrat.id,contractLabel:doc.contrat.libelle,archive:year!==undefined,year};
}
// Keep each phase bounded, and drain every started file before releasing the lease.
// Independent Drive objects may progress together; SQL visibility still commits once.
async function batchFiles<T>(files: readonly T[], action: (file: T) => Promise<void>) {
  for (let index = 0; index < files.length; index += 3) {
    const results = await Promise.allSettled(files.slice(index, index + 3).map(action));
    const failure = results.find((result): result is PromiseRejectedResult => result.status === 'rejected');
    if (failure) throw failure.reason;
  }
}
export async function publishFinancialBatch(args: {
  operation: string; date: string; capturedAt: string; store: BatchStore; drive: BatchDrive;
  generate: () => Promise<Contents[]>;
  legacyDecember?: (year: number) => Promise<Contents | null>;
  cleanupLegacy?: (batches: PublishedBatch[]) => Promise<void>;
}) {
  const {operation,date,capturedAt,store,drive} = args, token=randomUUID();
  const leased=await store("lease",token);
  if(leased.status!=="leased")throw new XlsxPublicationError("busy");
  try {
    let plan=leased.plan as BatchPlan | null;
    if(!plan) {
      const all = (await store("list",token)).batches as PublishedBatch[];
      const files=await args.generate(),warnings:string[]=[];
      let securedDecember:number|undefined;
      if(date.slice(5,7)==="01") {
        const year=Number(date.slice(0,4))-1;
        const secured=all.some(b=>b.securedDecember===year);
        if(!secured) {
          const december=all.filter(b=>b.complete&&!b.retired&&b.date.startsWith(year+"-12"))
            .sort((a,b)=>b.date.localeCompare(a.date)||b.capturedAt.localeCompare(a.capturedAt))[0];
          if(!december) {
            const legacy=await args.legacyDecember?.(year);
            if(legacy){files.push(legacy);securedDecember=year;warnings.push("Décembre "+year+" : seul le XLSX historique était disponible ; aucun JSON annuel fabriqué.");}
            else warnings.push("Aucun lot complet de décembre "+year+" disponible : aucune archive fabriquée.");
          }
          else if(!(await Promise.all(december.files.filter(f=>!f.archive).map(file=>drive.exists(december,file)))).every(Boolean)) {
            warnings.push("Le dernier lot publié de décembre "+year+" est incomplet dans Drive : aucune archive fabriquée ; protection conservée.");
          } else {
            for(const file of december.files.filter(f=>!f.archive)) {
              const bytes=await drive.read(december,file);
              if(file.mime===jsonMime) {
                const doc=annualContractArchive(JSON.parse(Buffer.from(bytes).toString("utf8")),year);
                if(doc)files.push(jsonContent(doc,date,year));
              } else files.push({key:"archive-"+year+"-xlsx",name:"ARCHIVE_"+year+"_Patrimoine.xlsx",mime:file.mime,bytes,archive:true,year});
            }
            securedDecember=year;
          }
        } else securedDecember=year;
      }
      const descriptors:BatchFile[]=[];
      const contents:Record<string,string>={};
      if(new Set(files.map(file=>file.key)).size!==files.length || files.some(file=>file.bytes.length>5*1024*1024))throw new XlsxPublicationError("invalid");
      await batchFiles(files.map((file,index)=>({file,index})), async ({file,index}) => {
        const {bytes,...metadata}=file;
        descriptors[index]={...metadata,id:await drive.reserve(),size:bytes.length,sha256:hash(bytes)};
        contents[file.key]=Buffer.from(bytes).toString("base64");
      });
      plan={batch:{operation,date,capturedAt,files:descriptors,complete:false,securedDecember,warnings},contents};
      const saved=await store("prepare",token,plan);
      plan=saved.plan as BatchPlan;
    }
    if(plan.batch.operation!==operation||plan.batch.date!==date||plan.batch.capturedAt!==capturedAt)throw new XlsxPublicationError("integrity");
    if(!leased.complete) {
      // Reserve and persist all bytes before the first write; retries never regenerate a subset.
      await batchFiles(plan.batch.files, async file => {
        await store("guard",token);
        const bytes=Buffer.from(plan!.contents[file.key],"base64");
        if(hash(bytes)!==file.sha256||bytes.length!==file.size)throw new XlsxPublicationError("integrity");
        await drive.stage(plan!.batch,file,bytes);
      });
      await batchFiles(plan.batch.files, async file => {
        await store("guard",token);
        await drive.promote(plan!.batch,file);
        await drive.read(plan!.batch,file); // independent Drive SHA-256 readback after final naming
      });
      await store("commit",token);
    }
    await store("retire",token);
    const batches=(await store("list",token)).batches as PublishedBatch[];
    try {
      for(const retired of batches.filter(b=>b.retired&&!b.cleaned)) {
        await batchFiles(retired.files.filter(f=>!f.archive), async file => {
          await store("guard",token);
          await drive.trash(retired,file);
        });
        await store("cleaned",token,{operation:retired.operation});
      }
    await args.cleanupLegacy?.(batches);
    await store("finish",token);
    } catch {throw new XlsxPublicationError("cleanup_pending");}
    return {status:leased.complete?"already_published":"published",date,operation,
      sha256:plan.batch.files.find(f=>f.key==="xlsx")!.sha256,warnings:plan.batch.warnings??[]};
  } finally {await store("release",token).catch(()=>{});}
}
export function proposedBatchFiles(batches: PublishedBatch[], selected: readonly string[]) {
  const latest=batches.filter(b=>b.complete&&!b.retired).sort((a,b)=>b.date.localeCompare(a.date)||b.capturedAt.localeCompare(a.capturedAt))[0];
  if(!latest)return {latest:null,files:[],missing:[...selected]};
  const ids=new Set(selected);
  const current=latest.files.filter(f=>!f.archive&&(f.key==="xlsx"||!!f.contractId&&ids.has(f.contractId)));
  const archives=batches.filter(b=>b.complete).flatMap(batch=>batch.files.filter(f=>f.archive&&f.contractId&&ids.has(f.contractId)).map(file=>({batch,file})))
    .sort((a,b)=>a.file.contractId!.localeCompare(b.file.contractId!)||(b.file.year??0)-(a.file.year??0));
  return {latest,files:[...current.map(file=>({batch:latest,file})),...archives],
    missing:selected.filter(id=>!current.some(f=>f.contractId===id))};
}
export { batchReference };
