import 'server-only';
import {createAdminClient} from '@/lib/supabase/admin';
import {getDriveConnection} from './google-drive';
import {readArchiveKey} from './archive-key';
import {createDriveArchiveStore} from './drive-archive-store.mjs';
import {createBackupAutomation,BACKUP_SCHEDULE_LABEL} from './backup-automation-core.mjs';
import {rpcBackupError} from './backup-errors.mjs';

async function rpc(operation:string,args:Record<string,unknown>={}){
 const {data,error}=await createAdminClient().rpc('application_backup_automation',{operation,args});
 if(error)throw rpcBackupError(operation,error.code);return data;
}

export async function createScheduledBackupService(){
 if(process.env.APPLICATION_BACKUP_ENABLED!=='true'||process.env.APPLICATION_BACKUP_AUTOMATION_ENABLED!=='true')return null;
 const key=readArchiveKey(),connection=getDriveConnection();if(!key||!connection)return null;
 return createBackupAutomation({key,rpc,createTransport:async(context:{userId:string;operationId:string},lease:string)=>{
  const guard=()=>rpc('guard',{lease,run_id:context.operationId});
  async function metadata(operation:string,args:Record<string,unknown>){
   await guard();
   if(['trash_load','trash_confirm'].includes(operation))return rpc(operation,{...args,lease,run_id:context.operationId});
   const {data,error}=await createAdminClient().rpc('application_backup_drive_store',{operation,actor:context.userId,args:{...args,...(['reserve','verify'].includes(operation)?{automation_lease:lease}:{})}});
   if(error)throw rpcBackupError(operation,error.code);return data;
  }
  const store=createDriveArchiveStore({key,metadata,beforeWrite:guard,accessToken:()=>connection.accessTokenForPrincipal(context.userId)});
  return {store,load:(operationId:string)=>metadata('load',{operation_id:operationId})};
 }});
}

// Invoked only behind the existing manual route's verified Auth + CSRF guard.
export async function getBackupAutomationView(allowScheduledBackups=true){
 const enabled=allowScheduledBackups&&process.env.APPLICATION_BACKUP_AUTOMATION_ENABLED==='true';
 let configured=false;
 try{const key=readArchiveKey();configured=!!key&&!!getDriveConnection()&&!!process.env.CRON_SECRET?.trim()&&process.env.APPLICATION_BACKUP_ENABLED==='true';key?.fill(0);}catch{/* Presence only, no credentials returned. */}
 try{const view=await rpc('view');return {enabled,configured,status:'available',schedule:BACKUP_SCHEDULE_LABEL,lastSuccess:view.lastSuccess,lastFailure:view.lastFailure,current:view.current,retainedDaily:view.retainedDaily,retainedMonthly:view.retainedMonthly,cleanupPending:view.cleanupPending,cleanupFailed:view.cleanupFailed};}
 catch{return {enabled,configured,status:'unavailable',schedule:BACKUP_SCHEDULE_LABEL};}
}
