import { acceptsPost, getDriveOrigin, DriveError, type DriveActor, type createDriveConnection, validActor } from "./google-drive-core";

type Dependencies = {
  actor: () => Promise<DriveActor | null>;
  connection: () => ReturnType<typeof createDriveConnection> | null;
};
const headers = { "Cache-Control": "private, no-store, max-age=0", "Referrer-Policy": "no-referrer", "X-Content-Type-Options": "nosniff" };
function back(origin: string, result: string) { return new Response(null, { status: 303, headers: { ...headers, Location: `${origin}/settings?drive=${result}#google-drive` } }); }
export function createDriveHandlers(deps: Dependencies) {
  return {
    async start(request: Request) {
      const origin = getDriveOrigin();
      if (!origin || !acceptsPost(request, origin)) return new Response(null, { status: 403, headers });
      try {
        const actor = await deps.actor();
        if (!validActor(actor)) return new Response(null, { status: 403, headers });
        const connection = deps.connection();
        if (!connection) return back(origin, "unavailable");
        return new Response(null, { status: 303, headers: { ...headers, Location: await connection.start(actor) } });
      } catch { return back(origin, "unavailable"); }
    },
    async callback(request: Request) {
      // Never propagate a callback URL, provider error or code to the redirect.
      if (request.method !== "GET") return new Response(null, { status: 405, headers });
      const origin = getDriveOrigin();
      if (!origin) return new Response(null, { status: 403, headers });
      if (new URL(request.url).origin !== origin) return back(origin, "unavailable");
      try {
        const actor = await deps.actor();
        if (!validActor(actor)) return back(origin, "unavailable");
        const connection = deps.connection();
        if (!connection) return back(origin, "unavailable");
        await connection.finish(actor, new URL(request.url).searchParams);
        return back(origin, "connected");
      } catch (error) {
        return back(origin, error instanceof DriveError && error.code === "consent_denied" ? "cancelled" : "unavailable");
      }
    },
    async check(request: Request) {
      const origin = getDriveOrigin();
      if (!origin || !acceptsPost(request, origin)) return new Response(null, { status: 403, headers });
      try {
        const actor = await deps.actor();
        if (!validActor(actor)) return new Response(null, { status: 403, headers });
        const connection = deps.connection();
        if (!connection) return back(origin, "unavailable");
        await connection.accessToken(actor, true);
        return back(origin, "checked");
      } catch { return back(origin, "unavailable"); }
    },
  };
}
