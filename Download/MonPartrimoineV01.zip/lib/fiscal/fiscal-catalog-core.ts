import type {FiscalRule} from './fiscal-core';
export type ConfiguredEnvelopeType={id:string;code:string;label:string;is_active:boolean;is_standard:boolean;configuration_revision:number;default_fiscal_regime_id:string|null;default_fiscal_rule_id:string|null};
export type ConfiguredFiscalRegime={id:string;code:string;label:string;description:string;envelope_type_id:string;calculation_kind:string;status:string;owner_user_id:string|null;is_active:boolean;configuration_revision:number};
export type FiscalCatalog={types:ConfiguredEnvelopeType[];regimes:ConfiguredFiscalRegime[];rules:FiscalRule[];allowed:{envelope_type_id:string;fiscal_regime_id:string;is_active:boolean}[]};
export type FiscalCatalogAvailability={status:'available';data:FiscalCatalog}|{status:'unavailable'};
export function envelopeCapabilities(code:string){
 if(code==='peg')return 'Valorisation totale déclarée : Date, BRUT et NET ; un historique, aucun donut. Aucun calcul fiscal automatique.';
 if(code==='per_col')return 'Valorisation totale déclarée : Date et BRUT ; aucun NET dans la fiche, aucun donut. Aucun calcul fiscal automatique.';
 if(code==='immobilier')return 'Estimations totales immobilières datées ; convention BRUT = NET conservée. Aucun donut.';
 if(code==='epargne_liquide')return 'Soldes natifs datés, consultation EUR ; convention NET = BRUT sans calcul fiscal ; ni positions ni donuts dans la fiche.';
 return 'Parcours de positions et espèces, prix/FX qualifiés et historique disponible. Aucun comportement spécialisé déduit du libellé ; NET disponible seulement selon les fiscalités de l’enveloppe et des données suffisantes.';
}
export function compatibleFiscalRegimes(catalog:FiscalCatalog,typeId:string,includeId?:string|null){return catalog.regimes.filter(r=>r.id===includeId||(r.is_active&&catalog.allowed.some(a=>a.envelope_type_id===typeId&&a.fiscal_regime_id===r.id&&a.is_active)));}
