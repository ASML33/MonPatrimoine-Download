export type ReferenceDiagnosticId = 'REF-AUTH' | 'REF-CATALOG' | 'REF-USAGES-READ' | 'REF-USAGES-SCHEMA' | 'REF-USAGES-PARTIAL' | 'REF-PROTECTED' | 'REF-COVERAGE' | 'REF-CONFLICT' | 'REF-VALIDATION' | 'REF-SQL-DEPENDENCY' | 'REF-RESTORE-IDENTITY' | 'REF-PERIOD' | 'REF-COMBINATION' | 'REF-DATA' | 'REF-NET-MODE' | 'REF-NET-ABSENT' | 'REF-NET-MANUAL';
const sources = new Set(['management','mutation','authorization', 'catalogue', 'historical-json', 'contracts', 'fiscal_rules', 'target_allocations', 'user_fiscal_regime_preferences', 'patrimonial_daily_captures', 'property_consolidations']);
const codes = new Set(['P7200','P7201','P7202','P7203','P7204','P7101','P7102','P7103','40001','23514','23505','42883','PGRST202','42501', '42703', '42P01', '57014', 'PGRST001', 'PGRST002', 'PGRST003', 'PGRST100', 'PGRST106', 'PGRST116', 'PGRST205', 'PGRST301', 'PGRST302', 'inactive', 'unauthenticated', 'profile_missing', 'unknown-json-shape', 'row-limit', 'missing-count', 'invalid-row', 'inconsistent-page']);

// Never serialize upstream messages, details, URLs, JWTs, identities or source JSON.
export function referenceDiagnostic(id: ReferenceDiagnosticId, source: string, error?: unknown, page?: number) {
  const value = error !== null && typeof error === 'object' ? error as Record<string, unknown> : {};
  const code = typeof value.code === 'string' && codes.has(value.code) ? value.code : value.name === 'TimeoutError' ? 'timeout' : 'unknown';
  const status = typeof value.status === 'number' && Number.isInteger(value.status) && value.status >= 400 && value.status <= 599 ? value.status : null;
  return { id, source: sources.has(source) ? source : 'unknown', code, status,
    page: typeof page === 'number' && Number.isInteger(page) && page >= 1 && page <= 50 ? page : null,
    timestamp: new Date().toISOString() };
}

export function logReferenceDiagnostic(id: ReferenceDiagnosticId, source: string, error?: unknown, page?: number) {
  console.warn('references_read_failure', referenceDiagnostic(id, source, error, page));
}
