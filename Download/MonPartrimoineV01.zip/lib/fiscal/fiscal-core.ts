export const FISCAL_BASE_TYPES = [
  "none",
  "positive_unrealized_gain",
  "positive_plan_gain",
  "positive_interest_gain",
  "gross",
] as const;

export type FiscalBaseType = (typeof FISCAL_BASE_TYPES)[number];

export type FiscalRule = {
  name?: string;
  calculationMode?: 'calculated'|'manual';
  id: string;
  fiscalRegimeId: string;
  ownerUserId: string | null;
  versionNumber: number;
  effectiveFrom: string;
  ageThresholdMonths: number | null;
  irRateBefore: number | null;
  irRateAfter: number | null;
  psRateBefore: number | null;
  psRateAfter: number | null;
  irBaseType: FiscalBaseType;
  psBaseType: FiscalBaseType;
  irAllowanceAmount: number | null;
  irAllowanceScope: "contract" | "household_annual" | null;
  status: "draft" | "verified" | "retired";
  description: string;
  source: string;
  sourceTitle: string;
  verifiedOn: string;
};

export type FiscalCalculationInput = {
  calculationDate: string;
  fiscalStartedOn: string | null;
  grossEur: number;
  unrealizedGainEur: number | null;
  netCashFlowsEur: number | null;
  interestGainEur: number | null;
  socialContributionsPaidEur: number | null;
  historyComplete: boolean;
  annualAllowanceRemainingEur?: number | null;
};

export type FiscalCalculation = {
  status: "complete" | "incomplete";
  ruleId: string;
  ruleVersion: number;
  irBaseEur: number | null;
  psBaseEur: number | null;
  irEur: number | null;
  psEur: number | null;
  totalTaxEur: number | null;
  netEstimatedEur: number | null;
  allowanceUsedEur: number;
  warnings: string[];
};

function validDate(value: string | null) {
  return value !== null && /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(`${value}T00:00:00Z`));
}

export function completedMonths(start: string, end: string) {
  if (!validDate(start) || !validDate(end) || start > end) return null;
  const [sy, sm, sd] = start.split("-").map(Number);
  const [ey, em, ed] = end.split("-").map(Number);
  return (ey - sy) * 12 + (em - sm) - (ed < sd ? 1 : 0);
}

// Calendar boundary matching completedMonths, including leap days/month ends.
export function fiscalThresholdDate(start: string | null, months: number | null) {
  if (!validDate(start) || months === null || !Number.isInteger(months) || months < 0) return null;
  const [year, month, day] = start!.split("-").map(Number);
  const target = new Date(`${start}T00:00:00Z`);
  target.setUTCDate(1);
  target.setUTCFullYear(year, month - 1 + months, 1);
  const lastDay = new Date(target.getTime());
  lastDay.setUTCMonth(lastDay.getUTCMonth() + 1, 0);
  if (day <= lastDay.getUTCDate()) target.setUTCDate(day);
  else target.setUTCMonth(target.getUTCMonth() + 1, 1);
  return target.toISOString().slice(0, 10);
}

export function fiscalRuleApplication(rule: FiscalRule, start: string | null, calculationDate: string) {
  const age = start ? completedMonths(start, calculationDate) : null;
  const ageKnown = rule.ageThresholdMonths === null || age !== null;
  const after = rule.ageThresholdMonths !== null && age !== null && age >= rule.ageThresholdMonths;
  return {
    thresholdDate: fiscalThresholdDate(start, rule.ageThresholdMonths),
    irRate: ageKnown ? (after ? rule.irRateAfter : rule.irRateBefore) : null,
    psRate: ageKnown ? (after ? rule.psRateAfter : rule.psRateBefore) : null,
    personal: rule.ownerUserId !== null,
  };
}

export function selectEffectiveFiscalRule(
  rules: FiscalRule[],
  fiscalRegimeId: string,
  calculationDate: string,
  usePersonal: boolean,
  userId: string,
) {
  const matchingScope = (ownerUserId: string | null) => rules
    .filter((rule) => rule.fiscalRegimeId === fiscalRegimeId
      && rule.ownerUserId === ownerUserId
      && rule.status === "verified"
      && rule.effectiveFrom <= calculationDate)
    .sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom) || b.versionNumber - a.versionNumber)[0] ?? null;
  return usePersonal ? matchingScope(userId) ?? matchingScope(null) : matchingScope(null);
}

function incomplete(rule: FiscalRule, warnings: string[]): FiscalCalculation {
  return {
    status: "incomplete", ruleId: rule.id, ruleVersion: rule.versionNumber,
    irBaseEur: null, psBaseEur: null, irEur: null, psEur: null,
    totalTaxEur: null, netEstimatedEur: null, allowanceUsedEur: 0, warnings,
  };
}

// Each executable operation carries its own readable expression. Settings and
// exports render these same definitions; they do not maintain another formula.
export const FISCAL_BASE_OPERATIONS:Record<FiscalBaseType,{expression:string;calculate:(input:FiscalCalculationInput)=>number|null}>={
 none:{expression:'0',calculate:()=>0},
 gross:{expression:'max(0, BRUT)',calculate:i=>Math.max(0,i.grossEur)},
 positive_unrealized_gain:{expression:'max(0, plus-value latente qualifiée des positions)',calculate:i=>i.unrealizedGainEur===null?null:Math.max(0,i.unrealizedGainEur)},
 positive_interest_gain:{expression:'max(0, intérêts documentés)',calculate:i=>i.interestGainEur===null?null:Math.max(0,i.interestGainEur)},
 positive_plan_gain:{expression:'max(0, BRUT − flux externes nets datés)',calculate:i=>!i.historyComplete||i.netCashFlowsEur===null?null:Math.max(0,i.grossEur-i.netCashFlowsEur)},
};
export const FISCAL_AMOUNT_OPERATIONS={
 irBase:{expression:'Assiette IR = max(0, base IR − abattement disponible)',calculate:(base:number,allowance:number)=>Math.max(0,base-allowance)},
 ir:{expression:'IR = assiette IR × taux IR',calculate:(base:number,rate:number)=>base*rate},
 ps:{expression:'PS = max(0, assiette PS × taux PS − PS déjà acquittés)',calculate:(base:number,rate:number,paid:number)=>Math.max(0,base*rate-paid)},
 net:{expression:'NET = BRUT − IR − PS',calculate:(gross:number,ir:number,ps:number)=>gross-(ir+ps)},
};
const baseFor=(type:FiscalBaseType,input:FiscalCalculationInput)=>FISCAL_BASE_OPERATIONS[type].calculate(input);

export function calculateFiscalEstimate(rule: FiscalRule, input: FiscalCalculationInput): FiscalCalculation {
  if(rule.calculationMode==='manual')return incomplete(rule,['Régime manuel : aucun NET calculé.']);
  if (!validDate(input.calculationDate) || rule.effectiveFrom > input.calculationDate) {
    return incomplete(rule, ["Aucune version fiscale applicable à la date du calcul."]);
  }
  let afterThreshold = false;
  if (rule.ageThresholdMonths !== null) {
    if (!input.fiscalStartedOn) return incomplete(rule, ["La date fiscale du contrat est manquante."]);
    const age = completedMonths(input.fiscalStartedOn, input.calculationDate);
    if (age === null) return incomplete(rule, ["La date fiscale du contrat est incohérente."]);
    afterThreshold = age >= rule.ageThresholdMonths;
  }
  const irRate = afterThreshold ? rule.irRateAfter : rule.irRateBefore;
  const psRate = afterThreshold ? rule.psRateAfter : rule.psRateBefore;
  if (irRate === null || psRate === null) return incomplete(rule, ["Les taux IR ou PS applicables sont incomplets."]);
  // Application convention: a blank PS field contributes zero to the estimate.
  // Keep the stored/context value intact; all other required evidence still applies.
  const rawIrBase = baseFor(rule.irBaseType, input);
  const rawPsBase = baseFor(rule.psBaseType, input);
  if (rawIrBase === null || rawPsBase === null) {
    return incomplete(rule, ["La base taxable ne peut pas être établie avec l’historique disponible."]);
  }
  let allowanceUsedEur = 0;
  if (rule.irAllowanceAmount) {
    if (rule.irAllowanceScope === "household_annual" && input.annualAllowanceRemainingEur == null) {
      return incomplete(rule, ["L’abattement annuel partagé du foyer n’est pas renseigné."]);
    }
    const available = rule.irAllowanceScope === "household_annual"
      ? Math.min(rule.irAllowanceAmount, input.annualAllowanceRemainingEur ?? 0)
      : rule.irAllowanceAmount;
    allowanceUsedEur = Math.min(rawIrBase, available);
  }
  const irBaseEur = FISCAL_AMOUNT_OPERATIONS.irBase.calculate(rawIrBase,allowanceUsedEur);
  const psBaseEur = rawPsBase;
  const irEur = FISCAL_AMOUNT_OPERATIONS.ir.calculate(irBaseEur,irRate);
  const psEur = FISCAL_AMOUNT_OPERATIONS.ps.calculate(psBaseEur,psRate,input.socialContributionsPaidEur??0);
  const totalTaxEur = irEur + psEur;
  return {
    status: "complete", ruleId: rule.id, ruleVersion: rule.versionNumber,
    irBaseEur, psBaseEur, irEur, psEur, totalTaxEur,
    netEstimatedEur: FISCAL_AMOUNT_OPERATIONS.net.calculate(input.grossEur,irEur,psEur),
    allowanceUsedEur,
    warnings: [],
  };
}

export function calculateFiscalPortfolio(
  items: Array<{ id: string; rule: FiscalRule; input: FiscalCalculationInput }>,
) {
  const allowanceRemaining = new Map<string, number>();
  return items.map((item) => {
    const key = `${item.rule.id}:${item.input.calculationDate.slice(0, 4)}`;
    const configured = item.rule.irAllowanceAmount ?? 0;
    const remaining = allowanceRemaining.has(key) ? allowanceRemaining.get(key)! : configured;
    const result = calculateFiscalEstimate(item.rule, {
      ...item.input,
      annualAllowanceRemainingEur: item.rule.irAllowanceScope === "household_annual" ? remaining : item.input.annualAllowanceRemainingEur,
    });
    if (item.rule.irAllowanceScope === "household_annual") allowanceRemaining.set(key, Math.max(0, remaining - result.allowanceUsedEur));
    return { id: item.id, ...result };
  });
}
