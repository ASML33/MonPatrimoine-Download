import {FISCAL_BASE_TYPES,type FiscalBaseType} from '@/lib/fiscal/fiscal-core';

export const ESTIMATE_CONVENTION='Estimation hors abattements fiscaux.';
export function envelopeNetMode(code:string){
 if(code==='epargne_liquide'||code==='immobilier')return 'gross' as const;
 if(code==='per_col')return 'absent' as const;
 if(code==='peg')return 'manual' as const;
 return 'calculated' as const;
}
export function envelopeModeLabel(code:string){
 const mode=envelopeNetMode(code);
 return mode==='gross'?'NET = BRUT · convention applicative, aucun calcul fiscal':mode==='absent'?'BRUT uniquement · NET volontairement absent':mode==='manual'?'BRUT et NET manuels · source et date requises':'NET calculé · '+(code==='cto'?'titre par titre, sans compensation':'au contrat');
}
export type FiscalTier={fromMonths:number;ir:number;ps:number};
export type CommonTaxConfiguration={version:2;scope:'contract'|'position';irBase:FiscalBaseType;psBase:FiscalBaseType;tiers:FiscalTier[];psPaid:'contract'|'not_applicable';remarks:string};
// Same finite operations as the historical engine; no expression evaluator.
export function commonTaxConfiguration(value:Record<string,unknown>,code:string):CommonTaxConfiguration|null{
 if(value.version!==2)return null;
 if(Object.keys(value).some(k=>!['label','mode','starts_on','ends_on','version','scope','irBase','psBase','tiers','psPaid','remarks'].includes(k)))throw Error('Paramètre exclu du socle. [REF-COMBINATION]');
 const {scope,irBase,psBase,tiers,psPaid,remarks}=value;
 if(scope!==(code==='cto'?'position':'contract'))throw Error('Portée non prise en charge. [REF-COMBINATION]');
 if(!FISCAL_BASE_TYPES.includes(irBase as FiscalBaseType)||!FISCAL_BASE_TYPES.includes(psBase as FiscalBaseType))throw Error('Assiette non prise en charge. [REF-COMBINATION]');
 if(!['contract','not_applicable'].includes(String(psPaid))||typeof remarks!=='string'||remarks.length>2000)throw Error('Paramètres invalides. [REF-COMBINATION]');
 if(scope==='position'&&(!['none','positive_unrealized_gain'].includes(String(irBase))||!['none','positive_unrealized_gain'].includes(String(psBase))||psPaid!=='not_applicable'))throw Error('Les titres utilisent uniquement leur plus-value positive, sans crédit contractuel. [REF-COMBINATION]');
 if(!Array.isArray(tiers)||!tiers.length||tiers.length>12)throw Error('Paliers incomplets. [REF-COMBINATION]');
 let previous=-1;
 for(const t of tiers){
  if(!t||Object.keys(t).some(k=>!['fromMonths','ir','ps'].includes(k))||!Number.isInteger(t.fromMonths)||t.fromMonths<0||t.fromMonths>1200||t.fromMonths<=previous||!Number.isFinite(t.ir)||!Number.isFinite(t.ps)||t.ir<0||t.ir>1||t.ps<0||t.ps>1)throw Error('Paliers numériques strictement ordonnés requis. [REF-COMBINATION]');
  previous=t.fromMonths;
 }
 if(tiers[0].fromMonths!==0)throw Error('Le premier palier commence à zéro mois. [REF-COMBINATION]');
 if(tiers.some(t=>t.ps>0)&&!['none','positive_unrealized_gain'].includes(String(psBase))&&psPaid!=='contract')throw Error('Le modèle exige les PS déjà acquittés du contrat. [REF-COMBINATION]');
 return {version:2,scope:scope as CommonTaxConfiguration['scope'],irBase:irBase as FiscalBaseType,psBase:psBase as FiscalBaseType,tiers,psPaid:psPaid as CommonTaxConfiguration['psPaid'],remarks};
}

// The NET provenance remains independent of a common fiscal definition.
export const prefersEnvelopeEstimate=(code:string)=>code==='assurance_vie';
export function zeroTaxConfiguration(label='Sans prélèvement configuré'){return {label,mode:'calculated' as const,starts_on:null,ends_on:null,version:2 as const,scope:'contract' as const,irBase:'none' as const,psBase:'none' as const,tiers:[{fromMonths:0,ir:0,ps:0}],psPaid:'not_applicable' as const,remarks:'Définition fiscale explicite ; provenance du NET conservée selon l’enveloppe.'};}
