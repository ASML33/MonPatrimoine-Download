import {selectEffectiveFiscalRule,type FiscalRule} from '@/lib/fiscal/fiscal-core';

export type FiscalSelection={ruleId:string|null;regimeId:string|null;assignmentId:string|null;assignmentDate:string|null;origin:string;context:FiscalContext};
export type FiscalContext={fiscalStartedOn:string|null;historyComplete:boolean;socialContributionsPaidEur:number|null};
export type FiscalAssignment={id:string;date:string;regimeId:string;ruleId:string|null;name:string;context:FiscalContext;recordedAt:string;supersedes:string|null;submissionId:string};
export type FiscalAssignmentHistory={version:1;baseline:{regimeId:string|null;ruleIds:string[];usePersonalRule:boolean;context:FiscalContext;recordedAt:string;origin:'migration_freeze'|'new_contract'};entries:FiscalAssignment[]};
export function fiscalAssignmentHistory(value:unknown):FiscalAssignmentHistory|null{
 if(value==null)return null;
 const h=value as FiscalAssignmentHistory;
 if(h.version!==1||!h.baseline||!Array.isArray(h.baseline.ruleIds)||!Array.isArray(h.entries))throw Error('Affectations fiscales indisponibles : historique invalide.');
 return h;
}
export function effectiveFiscalAssignments(h:FiscalAssignmentHistory){
 const replaced=new Set(h.entries.map(e=>e.supersedes).filter(Boolean));
 const entries=h.entries.filter(e=>!replaced.has(e.id));
 if(new Set(entries.map(e=>e.date)).size!==entries.length)throw Error('Affectations fiscales concurrentes ambiguës.');
 return entries.sort((a,b)=>a.date.localeCompare(b.date));
}
export function contractFiscalBinding(rules:readonly FiscalRule[],history:unknown,date:string,userId:string,legacy:{regimeId:string|null;usePersonalRule:boolean;context:FiscalContext}){
 const h=fiscalAssignmentHistory(history);
 if(!h)return {rule:legacy.regimeId?selectEffectiveFiscalRule([...rules],legacy.regimeId,date,legacy.usePersonalRule,userId):null,regimeId:legacy.regimeId,context:legacy.context,assignment:null,origin:'legacy' as const};
 const entry=effectiveFiscalAssignments(h).filter(e=>e.date<=date).at(-1);
 if(entry){const rule=rules.find(r=>r.id===entry.ruleId&&r.fiscalRegimeId===entry.regimeId&&r.effectiveFrom<=date&&(r.ownerUserId===null||r.ownerUserId===userId))??null;
 return {rule,regimeId:entry.regimeId,context:entry.context,assignment:entry,origin:'dated' as const};}
 const b=h.baseline;
 return {rule:b.regimeId?selectEffectiveFiscalRule(rules.filter(r=>b.ruleIds.includes(r.id)),b.regimeId,date,b.usePersonalRule,userId):null,regimeId:b.regimeId,context:b.context,assignment:null,origin:'baseline' as const};
}
// Existing published values use only the frozen legacy selection. An assignment
// never retrospectively qualifies or recalculates an already published hole.
export function frozenHistoricalBinding(rules:readonly FiscalRule[],history:unknown,date:string,userId:string,legacy:Parameters<typeof contractFiscalBinding>[4]){
 const h=fiscalAssignmentHistory(history);
 return contractFiscalBinding(rules,h?{...h,entries:[]}:null,date,userId,legacy);
}
export function validateFiscalVersionName(name:string,date:string){
 const valid=/^\d{4}-\d{2}-\d{2}$/.test(date)&&date>='0001-01-01'&&!Number.isNaN(Date.parse(date))&&new Date(date+'T00:00:00Z').toISOString().slice(0,10)===date;
 if(!valid||!name.startsWith(date.replaceAll('-','.')+' — ')||name.slice(13).trim().length<1||name.length>160)throw Error('Le nom doit commencer par la date d’effet AAAA.MM.JJ — suivie du nom du régime.');
 return name.trim();
}
