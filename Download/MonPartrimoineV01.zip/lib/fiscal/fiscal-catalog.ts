import 'server-only';
import {createClient} from '@/lib/supabase/server';
import {mapFiscalRuleRow,type FiscalRuleRow} from './fiscal-settings';
import type {FiscalCatalog,FiscalCatalogAvailability} from './fiscal-catalog-core';
export async function getFiscalCatalog(onFailure?:(error:unknown)=>void):Promise<FiscalCatalog>{
 const client=await createClient();const result=await client.rpc('get_envelope_fiscal_catalog');
 if(result.error||!result.data){onFailure?.(result.error);throw Error('Catalogue fiscal indisponible.');}
 const raw=result.data as Omit<FiscalCatalog,'rules'>&{rules:FiscalRuleRow[]};
 if(!Array.isArray(raw.types)||!Array.isArray(raw.rules)||!Array.isArray(raw.regimes)||!Array.isArray(raw.allowed))throw Error('Catalogue fiscal indisponible.');
 return {...raw,rules:raw.rules.map(mapFiscalRuleRow)};
}
export async function getFiscalCatalogAvailability(onFailure?:(error:unknown)=>void):Promise<FiscalCatalogAvailability>{try{return {status:'available',data:await getFiscalCatalog(onFailure)};}catch(error){onFailure?.(error);return {status:'unavailable'};}}
