import { parisBusinessDate } from "@/lib/dates/business-date";
import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { FiscalRule } from "./fiscal-core";
import type { FiscalRegime, FiscalSettingsAvailability, FiscalSettingsData } from "./fiscal-settings-core";

class FiscalSettingsReadError extends Error {
  readonly schemaMissing: boolean;
  constructor(schemaMissing: boolean) {
    super("Fiscal settings unavailable");
    this.schemaMissing = schemaMissing;
  }
}

export type FiscalRuleRow = {
  rule_name?:string; calculation_mode?:'calculated'|'manual';
  id: string; fiscal_regime_id: string; owner_user_id: string | null; version_number: number;
  valid_from: string; age_threshold_months: number | null;
  ir_rate_before: number | null; ir_rate_after: number | null; ps_rate_before: number | null; ps_rate_after: number | null;
  ir_base_type: FiscalRule["irBaseType"]; ps_base_type: FiscalRule["psBaseType"];
  ir_allowance_amount: number | null; ir_allowance_scope: FiscalRule["irAllowanceScope"];
  status: FiscalRule["status"]; description: string; source: string; source_title: string; verified_on: string;
};

export function mapFiscalRuleRow(row: FiscalRuleRow): FiscalRule {
  return {
    ...(row.rule_name?{name:row.rule_name}:{}),...(row.calculation_mode?{calculationMode:row.calculation_mode}:{}),
    id: row.id, fiscalRegimeId: row.fiscal_regime_id, ownerUserId: row.owner_user_id,
    versionNumber: Number(row.version_number), effectiveFrom: row.valid_from,
    ageThresholdMonths: row.age_threshold_months === null ? null : Number(row.age_threshold_months),
    irRateBefore: row.ir_rate_before === null ? null : Number(row.ir_rate_before),
    irRateAfter: row.ir_rate_after === null ? null : Number(row.ir_rate_after),
    psRateBefore: row.ps_rate_before === null ? null : Number(row.ps_rate_before),
    psRateAfter: row.ps_rate_after === null ? null : Number(row.ps_rate_after),
    irBaseType: row.ir_base_type, psBaseType: row.ps_base_type,
    irAllowanceAmount: row.ir_allowance_amount === null ? null : Number(row.ir_allowance_amount),
    irAllowanceScope: row.ir_allowance_scope, status: row.status,
    description: row.description, source: row.source, sourceTitle: row.source_title, verifiedOn: row.verified_on,
  };
}

function latest(rows: FiscalRule[], owner: string | null) {
  const today = parisBusinessDate();
  return rows.filter((item) => item.ownerUserId === owner && item.status === "verified" && item.effectiveFrom <= today)
    .sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom) || b.versionNumber - a.versionNumber)[0] ?? null;
}

export async function getFiscalSettings(userId: string, canManageCommon: boolean): Promise<FiscalSettingsData> {
  const supabase = await createClient();
  const [regimesResult, rulesResult, preferencesResult] = await Promise.all([
    supabase.from("fiscal_regimes").select("id,code,envelope_type_id,label,description,calculation_kind,status,is_active").order("label"),
    supabase.from("fiscal_rules").select("id,fiscal_regime_id,owner_user_id,version_number,valid_from,age_threshold_months,ir_rate_before,ir_rate_after,ps_rate_before,ps_rate_after,ir_base_type,ps_base_type,ir_allowance_amount,ir_allowance_scope,status,description,source,source_title,verified_on").eq("active", true).not("fiscal_regime_id", "is", null),
    supabase.from("user_fiscal_regime_preferences").select("fiscal_regime_id,use_personal_rule").eq("user_id", userId),
  ]);
  const failures = [
    { table: "fiscal_regimes", error: regimesResult.error },
    { table: "fiscal_rules", error: rulesResult.error },
    { table: "user_fiscal_regime_preferences", error: preferencesResult.error },
  ].filter((result) => result.error);
  if (failures.length) {
    // Only object identifiers and error codes enter logs, never response bodies.
    console.error("[fiscal-settings] read unavailable", failures.map(({ table, error }) => ({ table, code: error?.code })));
    const schemaMissing = failures.every(({ table, error }) =>
      (error?.code === "PGRST205" && error.message.includes(`public.${table}`))
      || (table === "fiscal_rules" && error?.code === "42703" && error.message.includes("fiscal_rules.fiscal_regime_id")));
    throw new FiscalSettingsReadError(schemaMissing);
  }
  const rules = (rulesResult.data as FiscalRuleRow[]).map(mapFiscalRuleRow);
  const preferences = new Map((preferencesResult.data ?? []).map((item) => [item.fiscal_regime_id, item.use_personal_rule]));
  return {
    canManageCommon,
    regimes: (regimesResult.data ?? []).map((row): FiscalSettingsData["regimes"][number] => {
      const regime: FiscalRegime = {
        id: row.id, code: row.code, envelopeTypeId: row.envelope_type_id, label: row.label,
        description: row.description, calculationKind: row.calculation_kind,
        status: row.status, isActive: row.is_active,
      };
      const scoped = rules.filter((item) => item.fiscalRegimeId === row.id);
      return { ...regime, commonRule: latest(scoped, null), personalRule: latest(scoped, userId), usePersonalRule: preferences.get(row.id) === true };
    }),
  };
}

export async function getFiscalSettingsAvailability(userId: string, canManageCommon: boolean): Promise<FiscalSettingsAvailability> {
  try {
    return { status: "available", data: await getFiscalSettings(userId, canManageCommon) };
  } catch (error) {
    return { status: "unavailable", reason: error instanceof FiscalSettingsReadError && error.schemaMissing ? "schema_missing" : "read_failed" };
  }
}
