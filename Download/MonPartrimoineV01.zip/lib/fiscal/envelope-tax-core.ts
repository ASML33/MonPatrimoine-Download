import {calculateFiscalEstimate,completedMonths,fiscalRuleApplication,type FiscalRule,type FiscalCalculationInput,type FiscalCalculation} from '@/lib/fiscal/fiscal-core';
import {commonTaxConfiguration,envelopeNetMode} from '@/lib/fiscal/envelope-policy';
export type EnvelopeFiscality={id:string;envelope_type_id:string;rule_id:string|null;label:string;mode:'calculated'|'manual'|'unsupported'|'none';starts_on:string|null;ends_on:string|null;transition_on:string|null;supersedes_id:string|null;revision:number;adopted:boolean;note:string;configuration:Record<string,unknown>;protection?:'used'|'unused'|'insufficient'};
export type EnvelopeTaxComponent=FiscalCalculation&ReturnType<typeof fiscalRuleApplication>&{label:string;periodId:string};
const civilDate=(date:string)=>/^\d{4}-\d{2}-\d{2}$/.test(date)&&Number.isFinite(Date.parse(date))&&new Date(date).toISOString().slice(0,10)===date;
export function selectEnvelopeFiscalities(rows:readonly EnvelopeFiscality[],typeId:string,date:string,policy:'bounds'|'legacy'='bounds'){
 if(!civilDate(date))return {rows:[],reason:'Date de calcul invalide. [REF-PERIOD]'};
 const own=rows.filter(r=>r.envelope_type_id===typeId);
 if(own.some(r=>[r.starts_on,r.ends_on,...policy==='legacy'?[r.transition_on]:[]].some(d=>d!==null&&!civilDate(d))||(r.starts_on&&r.ends_on&&r.starts_on>r.ends_on)))return {rows:[],reason:'Période fiscale incohérente. [REF-PERIOD]'};
 const inBounds=(r:EnvelopeFiscality)=>(!r.starts_on||date>=r.starts_on)&&(!r.ends_on||date<=r.ends_on);
 // A descendant replaces its lineage only inside its own business bounds.
 // Traverse through inactive intermediate versions; complementary roots coexist.
 const descendants=(id:string,seen=new Set<string>()):EnvelopeFiscality[]=>{
  if(seen.has(id))throw Error('Filiation fiscale cyclique. [REF-PERIOD]');
  const next=new Set(seen).add(id);
  return own.filter(n=>n.supersedes_id===id).flatMap(n=>[n,...descendants(n.id,next)]);
 };
 let selected:EnvelopeFiscality[];
 try{selected=policy==='legacy'?own.filter(r=>(!r.transition_on||date>=r.transition_on)&&inBounds(r)&&!own.some(n=>n.supersedes_id===r.id&&n.transition_on&&n.transition_on<=date)):own.filter(r=>inBounds(r)&&!descendants(r.id).some(inBounds));}
 catch{return {rows:[],reason:'Filiation fiscale incohérente. [REF-PERIOD]'};}
 return {rows:selected,reason:selected.length?null:'Aucune fiscalité applicable à cette date ; absence de règle ≠ exonération. [REF-DATA]'};
}
export type EnvelopePositionTax={id:string;netEstimatedEur:number|null;irEur:number|null;psEur:number|null;warnings:string[]};
export type TaxPosition={id:string;grossEur:number|null;unrealizedGainEur:number|null};
export type EnvelopeTaxInput=FiscalCalculationInput&{openedOn?:string|null;envelopeCode?:string;periodPolicy?:'bounds'|'legacy';positions?:TaxPosition[]};
function executable(period:EnvelopeFiscality,rules:readonly FiscalRule[],input:EnvelopeTaxInput){
 const config=commonTaxConfiguration(period.configuration,input.envelopeCode??'custom');
 let rule=rules.find(r=>r.id===period.rule_id);
 if(config){
  const age=input.fiscalStartedOn?completedMonths(input.fiscalStartedOn,input.calculationDate):null;
  if(config.tiers.length>1&&age===null)throw Error('Ancienneté propre au contrat inconnue. [REF-DATA]');
  const tier=config.tiers.filter(t=>t.fromMonths<=(age??0)).at(-1)!;
  rule={id:period.id,fiscalRegimeId:period.envelope_type_id,ownerUserId:'configuration',versionNumber:period.revision,effectiveFrom:period.starts_on??'0001-01-01',ageThresholdMonths:null,irRateBefore:tier.ir,psRateBefore:tier.ps,irRateAfter:null,psRateAfter:null,irBaseType:config.irBase,psBaseType:config.psBase,irAllowanceAmount:null,irAllowanceScope:null,status:'verified',description:config.remarks,source:'',sourceTitle:'Estimation patrimoniale configurée',verifiedOn:'',calculationMode:'calculated'};
 }
 if(!rule)throw Error('Version fiscale manquante. [REF-DATA]');
 if(!['none','gross','positive_unrealized_gain','positive_plan_gain','positive_interest_gain'].includes(rule.irBaseType)||!['none','gross','positive_unrealized_gain','positive_plan_gain','positive_interest_gain'].includes(rule.psBaseType)||rule.calculationMode==='manual')throw Error('Modèle fiscal non pris en charge. [REF-COMBINATION]');
 // New estimates ignore archived allowances, without changing immutable models.
 return {period,config,rule:{...rule,effectiveFrom:period.starts_on??'0001-01-01',irAllowanceAmount:null,irAllowanceScope:null}};
}
export function calculateEnvelopeTax(periods:readonly EnvelopeFiscality[],rules:readonly FiscalRule[],typeId:string,input:EnvelopeTaxInput){
 const selected=selectEnvelopeFiscalities(periods,typeId,input.calculationDate,input.periodPolicy);
 let positions:EnvelopePositionTax[]=[];
 const fail=(reason:string)=>({status:'incomplete' as const,netEstimatedEur:null,totalTaxEur:null,irEur:null,psEur:null,components:[] as EnvelopeTaxComponent[],positions,periodIds:selected.rows.map(r=>r.id),warnings:[reason]});
 const mode=envelopeNetMode(input.envelopeCode??'');
 if(mode==='gross')return {status:'complete' as const,netEstimatedEur:input.grossEur,totalTaxEur:0,irEur:0,psEur:0,components:[] as EnvelopeTaxComponent[],periodIds:[],warnings:[] as string[]};
 if(mode==='absent')return fail('NET volontairement absent : BRUT uniquement. [REF-NET-ABSENT]');
 if(mode==='manual')return fail('NET manuel qualifié à sa source et sa date requis. [REF-NET-MANUAL]');
 if(input.openedOn&&input.calculationDate<input.openedOn)return fail('Date étudiée antérieure à l’ouverture du contrat. [REF-DATA]');
 if(selected.reason)return fail(selected.reason);
 const blocked=selected.rows.find(r=>r.mode!=='calculated');
 if(blocked)return fail((blocked.note||'Aucun calcul fiscal configuré.')+(blocked.mode==='unsupported'?' [REF-COMBINATION]':' [REF-NET-MODE]'));
 try{
  const applied=selected.rows.map(p=>executable(p,rules,input));
  const charges={ir:0,ps:0};
  for(const {rule:r}of applied){const metadata=fiscalRuleApplication(r,input.fiscalStartedOn,input.calculationDate);
   if(metadata.irRate===null||metadata.psRate===null)throw Error('Taux ou ancienneté inconnus. [REF-DATA]');
   if(metadata.irRate>0&&r.irBaseType!=='none')charges.ir++;
   if(metadata.psRate>0&&r.psBaseType!=='none')charges.ps++;
  }
  if(charges.ir>1||charges.ps>1)throw Error('Composantes prélevant le même canal : combinaison ambiguë. [REF-COMBINATION]');
  const titleScope=input.envelopeCode==='cto';
  if(titleScope&&(!input.positions||new Set(input.positions.map(p=>p.id)).size!==input.positions.length))throw Error('Positions absentes ou dupliquées. [REF-DATA]');
  const positionCalculations=titleScope?input.positions!.map(p=>({position:p,values:applied.map(({rule})=>calculateFiscalEstimate(rule,{...input,grossEur:p.grossEur??NaN,unrealizedGainEur:p.unrealizedGainEur,netCashFlowsEur:null,socialContributionsPaidEur:0}))})):[];
  if(titleScope){
   if(applied.some(({rule})=>![rule.irBaseType,rule.psBaseType].every(b=>['none','positive_unrealized_gain'].includes(b))))throw Error('Assiette non prise en charge titre par titre. [REF-COMBINATION]');
   positions=positionCalculations.map(({position:p,values})=>{
    const complete=p.grossEur!==null&&p.unrealizedGainEur!==null&&Number.isFinite(p.grossEur)&&Number.isFinite(p.unrealizedGainEur)&&values.every(v=>v.status==='complete');
    const ir=complete?values.reduce((n,v)=>n+v.irEur!,0):null,ps=complete?values.reduce((n,v)=>n+v.psEur!,0):null;
    return {id:p.id,netEstimatedEur:complete?p.grossEur!-ir!-ps!:null,irEur:ir,psEur:ps,warnings:complete?[]:['Coût, valorisation ou FX du titre inconnu. [REF-TITLE-DATA]']};
   });
   if(positions.some(p=>p.netEstimatedEur===null))throw Error('Coût, valorisation ou FX d’un titre inconnu : NET complet indisponible. [REF-DATA]');
  }
  if(!Number.isFinite(input.grossEur))throw Error('Valorisation complète du contrat inconnue. [REF-DATA]');
  const components=applied.map(({period,rule,config},index)=>{
   const values=titleScope?positionCalculations.map(p=>p.values[index]):[calculateFiscalEstimate(rule,{...input,socialContributionsPaidEur:config?.psPaid==='not_applicable'?0:input.socialContributionsPaidEur})];
   if(values.some(c=>c.status!=='complete'))throw Error(values.flatMap(c=>c.warnings).join(' ')+' [REF-DATA]');
   const ir=values.reduce((n,c)=>n+c.irEur!,0),ps=values.reduce((n,c)=>n+c.psEur!,0);
   return {status:'complete' as const,ruleId:rule.id,ruleVersion:rule.versionNumber,irBaseEur:values.reduce((n,c)=>n+c.irBaseEur!,0),psBaseEur:values.reduce((n,c)=>n+c.psBaseEur!,0),irEur:ir,psEur:ps,totalTaxEur:ir+ps,netEstimatedEur:input.grossEur-ir-ps,allowanceUsedEur:0,warnings:[],...fiscalRuleApplication(rule,input.fiscalStartedOn,input.calculationDate),label:period.label,periodId:period.id};
  });
  const irEur=components.reduce((n,c)=>n+c.irEur,0),psEur=components.reduce((n,c)=>n+c.psEur,0);
  return {status:'complete' as const,netEstimatedEur:input.grossEur-irEur-psEur,totalTaxEur:irEur+psEur,irEur,psEur,components,positions,periodIds:selected.rows.map(r=>r.id),warnings:[] as string[]};
 }catch(error){return fail(error instanceof Error?error.message:'Configuration non prise en charge. [REF-COMBINATION]');}
}
