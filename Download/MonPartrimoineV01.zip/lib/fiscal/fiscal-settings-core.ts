import type { FiscalBaseType, FiscalRule } from "./fiscal-core";

export type FiscalRegime = {
  id: string;
  code: string;
  envelopeTypeId: string;
  label: string;
  description: string;
  calculationKind: string;
  status: "verified" | "limited" | "pending_verification" | "unsupported";
  isActive: boolean;
};

export type FiscalSettingsData = {
  regimes: Array<FiscalRegime & {
    commonRule: FiscalRule | null;
    personalRule: FiscalRule | null;
    usePersonalRule: boolean;
  }>;
  canManageCommon: boolean;
};

export type FiscalActionState = { status: "idle" | "success" | "error"; message?: string };

export type FiscalSettingsAvailability =
  | { status: "available"; data: FiscalSettingsData }
  | { status: "unavailable"; reason: "schema_missing" | "read_failed" };

export function fiscalBaseLabel(value: FiscalBaseType) {
  return ({
    none: "Aucune base taxable",
    positive_unrealized_gain: "Plus-value latente positive",
    positive_plan_gain: "Gain positif du plan",
    positive_interest_gain: "Intérêts positifs",
    gross: "Valeur brute",
  } as const)[value];
}

export function fiscalStatusLabel(value: FiscalRegime["status"]) {
  return ({ verified: "Vérifié", limited: "Couverture limitée", pending_verification: "À vérifier", unsupported: "Non pris en charge" } as const)[value];
}
