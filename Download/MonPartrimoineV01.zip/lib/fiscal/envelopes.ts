import 'server-only';
import {visibleContracts} from '@/lib/contracts/contract-scope';
import {createClient} from '@/lib/supabase/server';
import {mapFiscalRuleRow} from './fiscal-settings';
import type {FiscalRuleRow} from './fiscal-settings';
import type {FiscalCatalog} from './fiscal-catalog-core';
import type {EnvelopeFiscality} from './envelope-tax-core';
import {logReferenceDiagnostic} from './reference-diagnostics';
export type EnvelopesData={catalog:FiscalCatalog;fiscalities:EnvelopeFiscality[];counts:Record<string,number>;contracts?:{id:string;envelope_type_id:string;name:string;display_name:string|null;is_active:boolean}[]};
export async function readEnvelopes():Promise<EnvelopesData|null>{
 const c=await createClient();const {data,error}=await c.rpc('get_envelopes');
 if(error||data?.version!==2||!Array.isArray(data.fiscalities)){logReferenceDiagnostic('REF-SQL-DEPENDENCY','management',error);return null;}
 const linked=await c.from('contracts').select('id,envelope_type_id,name,display_name,is_active,metadata');
 if(linked.error){logReferenceDiagnostic('REF-SQL-DEPENDENCY','management',linked.error);return null;}
 const contracts=visibleContracts(linked.data??[]).map(({id,envelope_type_id,name,display_name,is_active})=>({id,envelope_type_id,name,display_name,is_active})).sort((a,b)=>(a.display_name?.trim()||a.name).localeCompare(b.display_name?.trim()||b.name,'fr'));
 return {contracts,catalog:{types:data.types,regimes:data.regimes,rules:(data.rules as FiscalRuleRow[]).map(mapFiscalRuleRow),allowed:data.allowed},fiscalities:data.fiscalities,counts:Object.fromEntries(data.types.map((t:{id:string})=>[t.id,contracts.filter(c=>c.envelope_type_id===t.id).length]))};
}
export async function readEnvelopeFiscalities():Promise<EnvelopeFiscality[]>{
 const c=await createClient();const result=await c.from('envelope_fiscalities').select('*');
 if(result.error){logReferenceDiagnostic('REF-SQL-DEPENDENCY','management',result.error);return [];}
 return result.data??[];
}
