import 'server-only';
import { getPageProfile } from '@/lib/auth/render-context';
import { createClient } from '@/lib/supabase/server';
import { getFiscalCatalogAvailability } from './fiscal-catalog';
import { collectReferenceUsage, referenceCatalogValid, type ReferenceSource, type ReferenceUsage } from './reference-usage-core';
import type { FiscalCatalogAvailability } from './fiscal-catalog-core';
import { logReferenceDiagnostic } from './reference-diagnostics';

export type LegacyFiscalReference = { id: string; rule_name: string; valid_from: string };
export type ReferenceView = { catalog: FiscalCatalogAvailability; usage: ReferenceUsage; legacy: LegacyFiscalReference[]; diagnostic?: string };
const selections = {
  contracts: 'id,envelope_type_id,fiscal_regime_id,fiscal_assignments',
  fiscal_rules: 'id,envelope_type_id,supersedes_id,parameters,fiscal_regime_id,rule_name,valid_from',
  target_allocations: 'id,target_envelope_type_id',
  user_fiscal_regime_preferences: 'fiscal_regime_id',
  patrimonial_daily_captures: 'id,inputContracts:inputs->contracts,inputRules:inputs->fiscalRules,inputTypes:inputs->envelopeTypes,resultContracts:result->report->contracts',
  property_consolidations: 'id,before_image,after_image',
} as const;

export async function readReferenceView(): Promise<ReferenceView> {
  // Auth is verified by the existing principal reader before any catalogue/data read.
  // This reader deliberately uses only the session client; no privileged fallback.
  let current: Awaited<ReturnType<typeof getPageProfile>>['current'];
  try { ({ current } = await getPageProfile()); }
  catch (error) { logReferenceDiagnostic('REF-AUTH', 'authorization', error); throw Error('Consultation indisponible. Référence REF-AUTH.'); }
  if (current.status !== 'active') { logReferenceDiagnostic('REF-AUTH', 'authorization', { code: current.status }); throw Error('Consultation non autorisée. Référence REF-AUTH.'); }
  let catalogFailure: unknown;
  const catalog = await getFiscalCatalogAvailability(error => { catalogFailure ??= error; });
  const usage: ReferenceUsage = { reasons: {}, limits: [] };
  if (catalog.status !== 'available') { logReferenceDiagnostic('REF-CATALOG', 'catalogue', catalogFailure); return { catalog, diagnostic: 'REF-CATALOG', usage: { ...usage, limits: ['Catalogue indisponible : comptages non établis.'] }, legacy: [] }; }
  if (!referenceCatalogValid(catalog.data)) { logReferenceDiagnostic('REF-USAGES-SCHEMA', 'catalogue', { code: 'unknown-json-shape' }); return { catalog: { status: 'unavailable' }, diagnostic: 'REF-USAGES-SCHEMA', usage: { ...usage, limits: ['Format du catalogue inconnu.'] }, legacy: [] }; }
  let client: Awaited<ReturnType<typeof createClient>>;
  try { client = await createClient(); }
  catch (error) { logReferenceDiagnostic('REF-USAGES-READ', 'authorization', error); return { catalog, usage: { ...usage, limits: ['Usages indisponibles. Référence REF-USAGES-READ.'] }, legacy: [] }; }
  const sources = await Promise.all(Object.entries(selections).map(async ([table, columns]): Promise<ReferenceSource> => {
    const rows: Record<string, unknown>[] = [];
    // Bounded pagination: no truncated query may masquerade as zero usage.
    try {
      for (let offset = 0; offset < 5000; offset += 100) {
        let query = client.from(table).select(columns, { count: 'exact' });
        if (table !== 'fiscal_rules') query = query.eq('user_id', current.profile.auth_user_id);
        query = query.order(table === 'user_fiscal_regime_preferences' ? 'fiscal_regime_id' : 'id');
        const { data, error, count } = await query.range(offset, offset + 99);
        if (error) { logReferenceDiagnostic('REF-USAGES-READ', table, error, offset / 100 + 1); return { table, rows, complete: false }; }
        if (!Array.isArray(data) || data.some(r => r === null || typeof r !== 'object' || Array.isArray(r))) { logReferenceDiagnostic('REF-USAGES-SCHEMA', table, { code: 'invalid-row' }, offset / 100 + 1); return { table, rows, complete: false }; }
        rows.push(...data as unknown as Record<string, unknown>[]);
        if (count === null || !Number.isInteger(count) || count > 5000 || rows.length > count) { logReferenceDiagnostic('REF-USAGES-PARTIAL', table, { code: count === null || !Number.isInteger(count) ? 'missing-count' : count > 5000 ? 'row-limit' : 'inconsistent-page' }, offset / 100 + 1); return { table, rows, complete: false }; }
        if (rows.length === count) return { table, rows, complete: true };
        if (!data.length) { logReferenceDiagnostic('REF-USAGES-PARTIAL', table, { code: 'inconsistent-page' }, offset / 100 + 1); return { table, rows, complete: false }; }
      }
    } catch (error) { logReferenceDiagnostic('REF-USAGES-READ', table, error); }
    return { table, rows, complete: false };
  }));
  const result = collectReferenceUsage(catalog.data, sources);
  if (result.limits.some(l => /inconnu/.test(l))) { logReferenceDiagnostic('REF-USAGES-SCHEMA', 'historical-json', { code: 'unknown-json-shape' }); result.limits.push('Certains formats historiques ne sont pas interprétés. Référence REF-USAGES-SCHEMA.'); }
  if (sources.some(s => !s.complete)) result.limits.push('Le relevé des usages est partiel. Référence REF-USAGES-PARTIAL.');
  result.limits.push('Lectures paginées sans snapshot commun : modifications concurrentes possibles.', 'Sources importées, références indirectes par positions/observations et archives externes non inventoriées exhaustivement. Ces compteurs ne prouvent jamais une absence de référence et ne permettent aucune suppression.');
  const legacy = (sources.find(s => s.table === 'fiscal_rules')?.rows ?? [])
    .filter(r => r.fiscal_regime_id === null && typeof r.id === 'string' && typeof r.rule_name === 'string' && typeof r.valid_from === 'string') as LegacyFiscalReference[];
  return { catalog, usage: result, legacy };
}
