import type { FiscalCatalog } from './fiscal-catalog-core';

export type UsageCategory = 'configuration' | 'business' | 'history';
export type UsageReason = { category: UsageCategory; reason: string; count: number };
export type ReferenceUsage = { reasons: Record<string, UsageReason[]>; limits: string[] };
export type ReferenceSource = { table: string; rows: Record<string, unknown>[]; complete: boolean };
const object = (v: unknown): Record<string, unknown> | null => v !== null && typeof v === 'object' && !Array.isArray(v) ? v as Record<string, unknown> : null;

export function referenceCatalogValid(catalog: FiscalCatalog): boolean {
  const strings = (row: unknown, keys: string[]) => { const r = object(row); return r !== null && keys.every(k => typeof r[k] === 'string'); };
  const numbers = (row: unknown, keys: string[]) => { const r = object(row); return r !== null && keys.every(k => r[k] === null || (typeof r[k] === 'number' && Number.isFinite(r[k]))); };
  return catalog.types.every(t => strings(t, ['id', 'code', 'label']) && typeof t.is_active === 'boolean' && typeof t.is_standard === 'boolean') &&
    catalog.regimes.every(r => strings(r, ['id', 'code', 'label', 'description', 'envelope_type_id', 'calculation_kind', 'status']) && typeof r.is_active === 'boolean') &&
    catalog.rules.every(r => strings(r, ['id', 'fiscalRegimeId', 'effectiveFrom', 'irBaseType', 'psBaseType', 'status', 'source', 'sourceTitle', 'description', 'verifiedOn']) && Number.isInteger(r.versionNumber) && (r.name === undefined || typeof r.name === 'string') && numbers(r, ['ageThresholdMonths', 'irRateBefore', 'irRateAfter', 'psRateBefore', 'psRateAfter', 'irAllowanceAmount'])) &&
    catalog.allowed.every(a => strings(a, ['envelope_type_id', 'fiscal_regime_id']) && typeof a.is_active === 'boolean');
}

// Counts are distinct source records per reason, never a deletion permission.
// No names, amounts or complete source JSON are returned to the UI.
export function collectReferenceUsage(catalog: FiscalCatalog, sources: ReferenceSource[]): ReferenceUsage {
  const counts = new Map<string, Set<string>>();
  const limits = new Set<string>();
  const add = (id: unknown, category: UsageCategory, reason: string, record: string) => {
    if (id === null || id === undefined) return;
    if (typeof id !== 'string' || !id) { limits.add('Une référence présente possède un format inconnu.'); return; }
    const key = JSON.stringify([id, category, reason]);
    const records = counts.get(key) ?? new Set<string>(); records.add(record); counts.set(key, records);
  };
  for (const t of catalog.types) {
    add(t.default_fiscal_regime_id, 'configuration', 'Défaut de création d’un type', t.id);
    add(t.default_fiscal_rule_id, 'configuration', 'Version proposée à la création', t.id);
  }
  for (const r of catalog.regimes) add(r.envelope_type_id, 'configuration', 'Type d’origine d’un régime', r.id);
  for (const a of catalog.allowed) {
    const key = `${a.envelope_type_id}:${a.fiscal_regime_id}`;
    add(a.envelope_type_id, 'configuration', `Compatibilité ${a.is_active ? 'active' : 'inactive'}`, key);
    add(a.fiscal_regime_id, 'configuration', `Compatibilité ${a.is_active ? 'active' : 'inactive'}`, key);
  }
  for (const r of catalog.rules) add(r.fiscalRegimeId, 'configuration', 'Version conservée du régime', r.id);

  function ledger(value: unknown, record: string) {
    if (value == null) return; // Older archived contracts predate the ledger.
    const h = object(value), b = object(h?.baseline);
    if (!h || h.version !== 1 || !b || !(b.regimeId === null || typeof b.regimeId === 'string') || !Array.isArray(b.ruleIds) || !Array.isArray(h.entries)) {
      limits.add('Un registre d’affectations a un format inconnu ; couverture incomplète.'); return;
    }
    add(b.regimeId, 'history', 'Contexte initial figé', record);
    for (const id of b.ruleIds) add(id, 'history', 'Versions du contexte initial figé', record);
    for (const raw of h.entries) {
      const e = object(raw);
      if (!e || typeof e.id !== 'string' || typeof e.date !== 'string' || typeof e.regimeId !== 'string' || !('ruleId' in e)) {
        limits.add('Une affectation historique a un format inconnu.'); continue;
      }
      const reason = 'Affectations conservées, futures ou remplacées comprises';
      add(e.regimeId, 'history', reason, `${record}:${e.id}`);
      add(e.ruleId, 'history', reason, `${record}:${e.id}`);
    }
  }
  function contract(value: unknown, record: string, archived: boolean) {
    const c = object(value);
    if (!c || typeof c.id !== 'string' || typeof c.envelope_type_id !== 'string') {
      limits.add('Une copie de contrat a un format inconnu.'); return;
    }
    add(c.envelope_type_id, archived ? 'history' : 'business', archived ? 'Contrat copié dans une preuve' : 'Contrats, inactifs et clos compris', record);
    add(c.fiscal_regime_id, archived ? 'history' : 'business', archived ? 'Régime copié dans une preuve' : 'Référence directe de régime conservée sur le contrat', record);
    ledger(c.fiscal_assignments, record);
  }
  function array(value: unknown, label: string, visit: (v: unknown, index: number) => void) {
    if (!Array.isArray(value)) { limits.add(`${label} : format absent ou inconnu.`); return; }
    value.forEach(visit);
  }
  for (const source of sources) {
    if (!source.complete) limits.add(`${source.table} : lecture partielle ou indisponible.`);
    for (const row of source.rows) {
      const record = `${source.table}:${String(row.id ?? '')}`;
      switch (source.table) {
        case 'contracts': contract(row, record, false); break;
        case 'fiscal_rules':
          add(row.envelope_type_id, 'configuration', 'Référence fiscale au type', record);
          add(row.supersedes_id, 'configuration', 'Version précédente conservée', record);
          if (row.parameters != null && !object(row.parameters)) limits.add('Paramètres de provenance au format inconnu.');
          add(object(row.parameters)?.templateRuleId, 'configuration', 'Modèle d’une version dérivée', record); break;
        case 'target_allocations': add(row.target_envelope_type_id, 'business', 'Objectif rattaché au type', record); break;
        case 'user_fiscal_regime_preferences': add(row.fiscal_regime_id, 'configuration', 'Préférence fiscale conservée', record); break;
        case 'patrimonial_daily_captures': {
          array(row.inputContracts, 'Contrats des captures', (c, i) => contract(c, `${record}:contract:${i}`, true));
          array(row.inputRules, 'Règles des captures', (v) => {
            const r = object(v);
            if (!r || typeof r.id !== 'string') { limits.add('Une copie de règle a un format inconnu.'); return; }
            add(r.id, 'history', 'Copie de provenance dans une capture, sans preuve de calcul', record);
            add(r.fiscal_regime_id, 'history', 'Régime copié dans une capture', record);
            add(r.envelope_type_id, 'history', 'Type d’une règle copiée', record);
            add(r.supersedes_id, 'history', 'Prédécesseur d’une règle copiée', record);
            add(object(r.parameters)?.templateRuleId, 'history', 'Modèle d’une règle copiée', record);
          });
          array(row.inputTypes, 'Types des captures', (v) => {
            const t = object(v); if (!t || typeof t.id !== 'string') limits.add('Une copie de type a un format inconnu.');
            else {
              add(t.id, 'history', 'Type copié dans une capture', record);
              add(t.default_fiscal_regime_id, 'history', 'Défaut de régime copié dans une capture', record);
              add(t.default_fiscal_rule_id, 'history', 'Défaut de version copié dans une capture', record);
            }
          });
          array(row.resultContracts, 'Résultats des captures', (v) => {
            const c = object(v); if (!c) { limits.add('Résultat de contrat inconnu.'); return; }
            add(c.envelopeTypeId, 'history', 'Type conservé dans un résultat', record);
            const detail = object(c.fiscalDetail);
            const knownCalculation = detail !== null && typeof detail.ruleId === 'string' && ['complete', 'incomplete'].includes(String(detail.status));
            if (c.fiscalDetail != null && !knownCalculation) limits.add('Détail de calcul fiscal archivé au format inconnu.');
            if (knownCalculation) add(detail.ruleId, 'history', 'Référence d’un calcul fiscal archivé', record);
            // Old results have no fiscalSelection: a version number alone is not an UUID.
            if (c.fiscalSelection === undefined) return;
            const s = object(c.fiscalSelection);
            if (!s || !('ruleId' in s) || !('regimeId' in s)) { limits.add('Sélection fiscale archivée inconnue.'); return; }
            const reason = knownCalculation ? 'Référence d’un calcul fiscal archivé' : 'Sélection archivée, calcul non attesté';
            add(s.ruleId, 'history', reason, record); add(s.regimeId, 'history', reason, record);
          }); break;
        }
        case 'property_consolidations': {
          const before = object(row.before_image), after = object(row.after_image);
          array(before?.before, 'Avant-images de regroupement', (v, i) => contract(object(v)?.contract, `${record}:before:${i}`, true));
          array(after?.contracts, 'Après-images de regroupement', (v, i) => contract(v, `${record}:after:${i}`, true)); break;
        }
      }
    }
  }
  const reasons: ReferenceUsage['reasons'] = {};
  for (const [key, records] of counts) {
    const [id, category, reason] = JSON.parse(key) as [string, UsageCategory, string];
    (reasons[id] ??= []).push({ category, reason, count: records.size });
  }
  return { reasons, limits: [...limits] };
}

export function referenceModelSupported(rule: { calculationMode?: string; irBaseType: string; psBaseType: string }) {
  return (rule.calculationMode === undefined || ['calculated', 'manual'].includes(rule.calculationMode)) &&
    [rule.irBaseType, rule.psBaseType].every(b => ['none', 'gross', 'positive_unrealized_gain', 'positive_plan_gain', 'positive_interest_gain'].includes(b));
}
