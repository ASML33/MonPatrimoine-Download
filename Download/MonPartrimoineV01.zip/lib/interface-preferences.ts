import "server-only";

import { requireUser } from "@/lib/auth/user";
import { createClient } from "@/lib/supabase/server";

export type InterfacePreferences = Record<string, unknown>;

function asInterfacePreferences(value: unknown): InterfacePreferences {
  return typeof value === "object" && value !== null && !Array.isArray(value)
    ? value as InterfacePreferences
    : {};
}

export async function getCurrentInterfacePreferences() {
  const user = await requireUser();
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("profiles")
    .select("interface_preferences")
    .eq("auth_user_id", user.id)
    .single();

  if (error) throw new Error("Interface preferences could not be loaded.");
  return asInterfacePreferences(data.interface_preferences);
}

export async function updateCurrentInterfacePreferences(
  patch: InterfacePreferences,
) {
  const user = await requireUser();
  const supabase = await createClient();
  const current = await getCurrentInterfacePreferences();
  const { error } = await supabase
    .from("profiles")
    .update({ interface_preferences: { ...current, ...patch } })
    .eq("auth_user_id", user.id);

  if (error) throw new Error("Interface preferences could not be updated.");
}
