export const AI_PROVIDER_OPTIONS = [
  { value: "openai", label: "OpenAI" },
  { value: "anthropic", label: "Anthropic" },
  { value: "google", label: "Google" },
] as const;

export type AiProvider = (typeof AI_PROVIDER_OPTIONS)[number]["value"];
export type AiConfigurationStatus =
  | "not_configured"
  | "configured"
  | "invalid";

export type AiConfiguration = {
  provider: AiProvider;
  status: AiConfigurationStatus;
};

export function isAiProvider(value: unknown): value is AiProvider {
  return AI_PROVIDER_OPTIONS.some((provider) => provider.value === value);
}

export function isAiConfigurationStatus(
  value: unknown,
): value is AiConfigurationStatus {
  return value === "not_configured" || value === "configured" || value === "invalid";
}

export function readAiConfiguration(value: unknown): AiConfiguration {
  const record = typeof value === "object" && value !== null
    ? value as Record<string, unknown>
    : {};
  return {
    provider: isAiProvider(record.provider) ? record.provider : "openai",
    status: isAiConfigurationStatus(record.status)
      ? record.status
      : "not_configured",
  };
}

export function mergeAiSettingsMetadata(
  current: unknown,
  configuration: AiConfiguration,
) {
  const record = typeof current === "object" && current !== null && !Array.isArray(current)
    ? current as Record<string, unknown>
    : {};
  return {
    ...record,
    provider: configuration.provider,
    status: configuration.status,
  };
}
