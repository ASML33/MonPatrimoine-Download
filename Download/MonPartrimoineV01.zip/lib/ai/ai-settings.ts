import "server-only";

import { readAiConfiguration } from "@/lib/ai/ai-settings-core";
import { requireRenderUser } from "@/lib/auth/render-context";
import { createClient } from "@/lib/supabase/server";

export async function getCurrentAiConfiguration() {
  await requireRenderUser();
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("get_ai_configuration").single();
  if (error) throw new Error("AI configuration could not be loaded.");
  return readAiConfiguration(data);
}
