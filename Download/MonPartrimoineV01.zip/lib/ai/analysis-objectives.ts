import type { AnalysisContext, AnalysisFact } from './analysis-core';
import { AnalysisError } from './analysis-core';
import type { PatrimonialReport } from '@/lib/reports/patrimonial-report-core';
import { objectiveStatus, assetObjectiveScopeNotice, assetObjectiveReason } from '@/lib/objectives/objective-core';
import { assetObjectiveComparison } from '@/lib/objectives/asset-objective-core';

export type AnalysisObjective = { kind: 'envelope_type' | 'contract' | 'asset'; targetId: string; targetPercent: number; targetLabel?: string; scopeContractId?: string | null; assetIdentity?: {name:string;symbol:string|null;isin?:string|null} };
export function addAnalysisObjectives(context: AnalysisContext, report: PatrimonialReport, targets: AnalysisObjective[], scope: 'all' | 'selection', closed: { id: string; envelopeTypeId?: string | null }[] = []) {
  const add = (subject: string, label: string, value: number | null, detail: string, unit='%', status: AnalysisFact['status']=value===null?'unknown':'known') => context.facts.push({id:`F${context.facts.length+1}`,subject,label,value,unit,status,dates:[],detail});
  const info = (subject: string, label: string, detail: string) => add(subject,label,null,detail,'information','known');
  const contractIds = [...report.contracts.map(contract => contract.id), ...closed.map(contract => contract.id)];
  const envelopeTypeIds = [...new Set([...report.allocations.envelopeTypes.map(type => type.id),
    ...closed.flatMap(contract => contract.envelopeTypeId ? [contract.envelopeTypeId] : [])])];
  const selected = targets.filter(target => {
    if (target.kind === 'contract') return contractIds.includes(target.targetId);
    if (target.kind === 'envelope_type') return envelopeTypeIds.includes(target.targetId);
    return !!target.scopeContractId && contractIds.includes(target.scopeContractId);
  });
  const kinds = ['envelope_type','contract','asset'] as const;
  if(selected.some(t=>!kinds.includes(t.kind)||!Number.isFinite(t.targetPercent)||(t.targetPercent!==-1&&(t.targetPercent<0||t.targetPercent>100))||(t.targetPercent===-1&&t.kind!=='asset'))) throw new AnalysisError('unavailable');
  info('Objectifs','Périmètre des objectifs d’allocation','Types et contrats : cibles globales par dimension inchangées ; base monétaire BRUT/NET non enregistrée. Titres : cibles relatives à un contrat, rattachement explicite conservé lorsqu’il est enregistré. Les cibles sans contrat restent dans Stratégie. Ne jamais comparer une cible de titre au poids global/financier. Base descriptive des titres : BRUT complet du contrat, espèces incluses ; les exclusions du pilotage restent valorisées et ne réduisent pas cette base. Une valeur incomplète ou nulle rend le poids indisponible. Écart = poids actuel moins cible, en points : positif = surpondération, négatif = sous-pondération. '+(scope==='selection'?'Sélection partielle : cibles globales non renormalisées et cibles de titres non réaffectées ; aucun contrat absent ajouté.':'Patrimoine disponible complet sélectionné.'));
  if(!selected.length) info('Objectifs','Objectifs d’allocation non renseignés','Aucune cible applicable à la sélection.');
  for(const kind of ['envelope_type','contract'] as const) {
    const rows=selected.filter(t=>t.kind===kind),total=rows.reduce((s,t)=>s+Math.max(0,t.targetPercent),0);
    info('Objectifs',`État de la dimension ${kind}`,`${objectiveStatus(total)} ; total des cibles positives : ${total} %. Cibles de la sélection conservées sans renormalisation ; absence de date d’effet enregistrée.`);
    for(const row of rows) {
      const i = (kind === 'contract' ? contractIds : envelopeTypeIds).indexOf(row.targetId);
      const subject = `${kind === 'contract' ? 'C' : 'E'}${i + 1}`;
      const typeLabel = row.targetLabel ?? report.allocations.envelopeTypes[i]?.name ?? 'type non libellé';
      add(subject,'Objectif d’allocation global',row.targetPercent,`${kind==='envelope_type'?`Type : ${typeLabel}. `:''}Pourcentage cible global de cette dimension, pas un objectif de cours. Aucun recalcul sur sélection partielle ni renormalisation.`);
    }
  }
  const assetTargets=selected.filter(t=>t.kind==='asset');
  info('Objectifs','Règles des cibles de titres',assetObjectiveScopeNotice);
  for(const [ci,c] of report.contracts.entries()) {
    const total=assetTargets.filter(t=>t.scopeContractId===c.id).reduce((s,t)=>s+Math.max(0,t.targetPercent),0);
    info(`C${ci+1}`,'État des cibles de titres du contrat',`${objectiveStatus(total)} ; total positif ${total} %. Aucune renormalisation ; exclusions conservées dans la base.`);
  }
  const targetOnly = [...new Set(assetTargets.filter(t=>!report.assets.some(a=>a.id===t.targetId)).map(t=>t.targetId))];
  const assets=[...report.assets,...targetOnly.map(id=>({id,holdings:[] as {contractId:string}[]}))];
  for(const [i,asset] of assets.entries()) {
    const alias=`A${i+1}`,rows=assetTargets.filter(t=>t.targetId===asset.id);
    if(i>=report.assets.length) {
      const identity=rows.find(r=>r.assetIdentity)?.assetIdentity;
      if(identity)info(alias,'Identité publique',[identity.name,identity.symbol,identity.isin].filter(Boolean).join(' · '));
      info(alias,'Titre ciblé sans détention établie','Cible conservée, sans valeur ni cours supposé. L’absence de détention valorisée ne constitue pas une preuve de valeur nulle.');
    }
    if(!rows.length) add(alias,'Cible de titre absente',null,'Cible absente, pas zéro.');
    for(const row of rows) {
      const subject = `${alias} / C${contractIds.indexOf(row.scopeContractId!) + 1}`;
      if (row.targetPercent === -1) info(subject,'Exclusion du pilotage','L’actif reste valorisé et visible. Pas de comparaison à une cible ni de renormalisation du dénominateur.');
      else add(subject,'Cible du titre dans le contrat',row.targetPercent,'Cible du contrat indiqué.');
    }
    for(const contractId of new Set([...asset.holdings.map(h=>h.contractId),...rows.flatMap(r=>r.scopeContractId&&report.contracts.some(c=>c.id===r.scopeContractId)?[r.scopeContractId]:[])])) {
      const ci=report.contracts.findIndex(c=>c.id===contractId);if(ci<0) continue;
      const subject=`${alias} / C${ci+1}`,row=rows.find(r=>r.scopeContractId===contractId);
      const comparison=assetObjectiveComparison(report,asset.id,contractId,row?{percent:row.targetPercent,scopeContractId:row.scopeContractId}:null);
      add(subject,'Base du poids actuel dans le contrat',comparison.denominatorEur,'BRUT du seul contrat, espèces incluses ; règles de périmètre ci-dessus.','EUR');
      add(subject,'Poids actuel du titre dans le contrat',comparison.currentPercent,'Valeur détenue dans ce contrat / sa base, sans renormalisation.');
      add(subject,'Écart à la cible du contrat',comparison.deltaPoints,comparison.reason?assetObjectiveReason(comparison.reason):'Actuel − cible, en points.','points');
    }
  }
}
