import "server-only";

import type { AiProvider } from "./ai-settings-core";
import { aiExposureJsonSchema } from "@/lib/assets/exposure-ai-core";

type ProviderRequest = {
  provider: AiProvider;
  apiKey: string;
  model: string;
  prompt: string;
};

function readOpenAiText(value: unknown) {
  const root = value as { output?: Array<{ content?: Array<{ type?: string; text?: string }> }> };
  return root.output?.flatMap((item) => item.content ?? []).find((item) => item.type === "output_text")?.text;
}

async function fetchJson(url: string, init: RequestInit) {
  const response = await fetch(url, { ...init, cache: "no-store", signal: AbortSignal.timeout(45_000) });
  if (!response.ok) throw new Error("AI_PROVIDER_REQUEST_FAILED");
  return response.json() as Promise<unknown>;
}

export async function requestExposureProposal({ provider, apiKey, model, prompt }: ProviderRequest) {
  const schema = aiExposureJsonSchema();
  if (provider === "openai") {
    const data = await fetchJson("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        input: prompt,
        store: false,
        text: { format: { type: "json_schema", name: "asset_exposure_proposal", strict: true, schema } },
      }),
    });
    const text = readOpenAiText(data);
    if (!text) throw new Error("AI_PROVIDER_RESPONSE_INVALID");
    return text;
  }
  if (provider === "anthropic") {
    const data = await fetchJson("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": apiKey, "anthropic-version": "2023-06-01", "Content-Type": "application/json" },
      body: JSON.stringify({ model, max_tokens: 4096, messages: [{ role: "user", content: prompt }] }),
    }) as { content?: Array<{ type?: string; text?: string }> };
    const text = data.content?.find((item) => item.type === "text")?.text;
    if (!text) throw new Error("AI_PROVIDER_RESPONSE_INVALID");
    return text;
  }
  const data = await fetchJson(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
    method: "POST",
    headers: { "x-goog-api-key": apiKey, "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: { responseMimeType: "application/json", responseSchema: schema },
    }),
  }) as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> };
  const text = data.candidates?.[0]?.content?.parts?.find((part) => part.text)?.text;
  if (!text) throw new Error("AI_PROVIDER_RESPONSE_INVALID");
  return text;
}

export function getConfiguredAiModel(provider: AiProvider) {
  const names: Record<AiProvider, string> = {
    openai: "MONPATRIMOINE_OPENAI_MODEL",
    anthropic: "MONPATRIMOINE_ANTHROPIC_MODEL",
    google: "MONPATRIMOINE_GOOGLE_MODEL",
  };
  return process.env[names[provider]]?.trim() || null;
}
