import 'server-only';
import { createClient } from '@/lib/supabase/server';
import { requireUser, AuthenticationRequiredError } from '@/lib/auth/user';
import { visibleContracts, isContractInUserScope } from '@/lib/contracts/contract-scope';
import { getCurrentReportSnapshot } from '@/lib/reports/patrimonial-report';
import { createAnalysisService } from './analysis-service';
import { readSharedObjective } from './input-history';
import { AnalysisError } from './analysis-core';

export async function getAnalysisContractChoices(userId: string) {
  const client = await createClient();
  const result = await client.from('contracts').select('id,name,display_name,metadata,is_active,closed_on,envelope_type_id,envelope_types(code)').eq('user_id', userId).order('name');
  if (result.error) throw new Error('ANALYSIS_CATALOG_UNAVAILABLE');
  return visibleContracts(result.data ?? []).map(row => { const relation = row.envelope_types as { code: string } | { code: string }[] | null; return { id: row.id, label: `${row.display_name?.trim() ? row.display_name : row.name}${row.closed_on ? ' (clôturé)' : !row.is_active ? ' (inactif)' : ''}`, isActive: row.is_active, closedOn: row.closed_on, envelopeTypeId: row.envelope_type_id, typeCode: Array.isArray(relation) ? relation[0]?.code ?? null : relation?.code ?? null }; });
}
export const analysisService = createAnalysisService({
  requireUser: async () => {
    try { return await requireUser(); }
    catch (error) { if (error instanceof AuthenticationRequiredError) throw new AnalysisError('auth'); throw error; }
  },
  fiscalRegimeLabels: async(ids) => {
    if (!ids.length) return {};
    const client = await createClient();
    const {data,error} = await client.from('fiscal_regimes').select('id,label').in('id',[...ids]);
    if (error) throw new AnalysisError('unavailable');
    return Object.fromEntries((data ?? []).map(row => [row.id,row.label]));
  },
  revisions: async(userId)=>{
    const client=await createClient();
    const [profile,allocation]=await Promise.all([client.from('profiles').select('preferences').eq('auth_user_id',userId).single(),client.rpc('get_target_allocation_revision')]);
    if(profile.error || allocation.error) throw new AnalysisError('unavailable');
    const revision=Number(allocation.data);if(!Number.isSafeInteger(revision)||revision<0)throw new AnalysisError('unavailable');
    return {objective:readSharedObjective(profile.data.preferences).revision,allocation:revision};
  },
  signingKey: () => process.env.MONPATRIMOINE_AI_CONTEXT_SIGNING_KEY ?? '',
  catalog: getAnalysisContractChoices,
  snapshot: getCurrentReportSnapshot,
  objectives: async (userId) => {
    const client = await createClient();
    const {data,error} = await client.from('target_allocations').select('target_kind,target_envelope_type_id,target_contract_id,target_asset_id,target_percent,scope_contract_id').eq('user_id',userId);
    if(error) throw new Error('ANALYSIS_OBJECTIVES_UNAVAILABLE');
    const rows=(data ?? []).filter(row=>(!row.target_contract_id||isContractInUserScope(row.target_contract_id))&&(!row.scope_contract_id||isContractInUserScope(row.scope_contract_id))).map(row => ({kind:row.target_kind, targetId:row.target_envelope_type_id ?? row.target_contract_id ?? row.target_asset_id, targetPercent:Number(row.target_percent),scopeContractId:row.scope_contract_id}));
    const ids=[...new Set(rows.filter(r=>r.kind==='asset').map(r=>r.targetId))];
    const typeIds=[...new Set(rows.filter(r=>r.kind==='envelope_type').map(r=>r.targetId))];
    const types=typeIds.length?await client.from('envelope_types').select('id,label').in('id',typeIds):{data:[],error:null};
    const identities=ids.length?await client.from('assets').select('id,name,symbol,isin,asset_type_code,valuation_mode').eq('owner_user_id',userId).in('id',ids):{data:[],error:null};
    if(identities.error || types.error)throw new Error('ANALYSIS_OBJECTIVES_UNAVAILABLE');
    return rows.map(row=>{const a=identities.data?.find(a=>a.id===row.targetId);return {...row,targetLabel:types.data?.find(t=>t.id===row.targetId)?.label,assetIdentity:a?.valuation_mode==='market_price'&&['stock','etf','fund','bond','crypto'].includes(a.asset_type_code)?{name:a.name,symbol:a.symbol,isin:a.isin}:undefined};});
  },
});
