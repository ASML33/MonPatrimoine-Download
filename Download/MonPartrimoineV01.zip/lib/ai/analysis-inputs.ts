export type AnalysisInputs = { question: string; additionalInformation: string };
export const MAX_ANALYSIS_INPUT_LENGTH = 10_000;
export const MAX_ADDITIONAL_INFORMATION_LENGTH = MAX_ANALYSIS_INPUT_LENGTH;
export const ANALYSIS_INPUT_ERROR = 'Objectif général et Question(s) sont limités à 10 000 caractères chacun, espaces et retours à la ligne compris. Votre saisie est conservée.';
// Match textarea UTF-16 counting, treating CRLF as one line break without rewriting stored text.
export const analysisInputLength = (text: string) => text.replace(/\r\n/g, '\n').length;
// Keep whitespace and empty strings: these are the values the user chose to save.
export function validateAnalysisInputs(question: unknown, additionalInformation: unknown): AnalysisInputs {
  if (typeof question !== 'string' || typeof additionalInformation !== 'string' || analysisInputLength(question) > MAX_ANALYSIS_INPUT_LENGTH || analysisInputLength(additionalInformation) > MAX_ADDITIONAL_INFORMATION_LENGTH || /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(question + additionalInformation)) {
    throw new Error(ANALYSIS_INPUT_ERROR);
  }
  return { question, additionalInformation };
}
