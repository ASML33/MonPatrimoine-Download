import 'server-only';
import { requireUser } from '@/lib/auth/user';
import { createClient } from '@/lib/supabase/server';
import { ANALYSIS_INPUT_ERROR } from './analysis-inputs';
import { InputHistoryError, isAnalysisInputField, isHistoryId, validateHistoryText, type AnalysisInputEntry } from './input-history';

export async function changeInputHistory(operation: 'save' | 'delete', field: unknown, id: unknown, text?: unknown, confirmed = false): Promise<AnalysisInputEntry | null> {
  await requireUser();
  if (field!=='question') throw new InputHistoryError('Utilisez l’objectif général partagé. (OBJ-OBSOLETE-WRITER)');
  if (!isAnalysisInputField(field) || !isHistoryId(id) || operation === 'delete' && !confirmed) throw new InputHistoryError('Demande d’historique invalide.');
  let content: string | null = null;
  if (operation === 'save') {
    try { content = validateHistoryText(field, text); }
    catch { throw new InputHistoryError('Saisissez un texte non vide. '+ANALYSIS_INPUT_ERROR); }
  }
  const client = await createClient();
  const { data, error } = await client.rpc('change_ai_input_history', {
    requested_operation: operation, requested_field: field, requested_entry: id, requested_text: content, deletion_confirmed: operation === 'delete' && confirmed,
  });
  if (error) throw new InputHistoryError(operation === 'save' ? 'L’enregistrement n’a pas pu être confirmé. Votre saisie est conservée. Rechargez l’historique avant de réessayer.' : 'La suppression n’a pas pu être confirmée. L’entrée reste affichée ; réessayez après rechargement.');
  return operation === 'save' ? data as AnalysisInputEntry : null;
}

export async function changeSharedObjectiveHistory(operation: 'save' | 'delete', id: unknown, text: unknown, expectedRevision: unknown, confirmed = false): Promise<{entry: AnalysisInputEntry | null; revision: number}> {
  await requireUser();
  if (!isHistoryId(id) || !Number.isSafeInteger(expectedRevision) || (expectedRevision as number)<0 || operation==='delete' && !confirmed) throw new InputHistoryError('Rechargez l’objectif avant de réessayer. (OBJ-REQUEST)');
  let content: string | null = null;
  if (operation==='save') {
    try {content=validateHistoryText('additionalInformation',text);}
    catch {throw new InputHistoryError(ANALYSIS_INPUT_ERROR+' (OBJ-TEXT)');}
  }
  const client=await createClient();
  const {data,error}=await client.rpc('change_shared_objective_history',{requested_operation:operation,requested_entry:id,requested_text:content,expected_revision:expectedRevision,deletion_confirmed:operation==='delete' && confirmed});
  if(error) throw new InputHistoryError(error.code==='40001'?'L’objectif a été modifié depuis une autre page. Votre saisie est conservée ; rechargez avant de réessayer. (OBJ-CONFLICT)':'Enregistrement de l’objectif non confirmé. Votre saisie est conservée ; rechargez avant de réessayer. (OBJ-WRITE)');
  return data as {entry:AnalysisInputEntry|null;revision:number};
}

export async function renameInputHistory(field:unknown,id:unknown,title:unknown,previousTitle:unknown):Promise<AnalysisInputEntry>{
 await requireUser();
 if(!isAnalysisInputField(field)||!isHistoryId(id)||typeof title!=='string'||!title.trim()||Array.from(title.trim()).length>200||previousTitle!==null&&typeof previousTitle!=='string')throw new InputHistoryError('Saisissez un titre non vide de 200 caractères maximum.');
 const client=await createClient();const {data,error}=await client.rpc('rename_analysis_input_history',{requested_field:field,requested_entry:id,requested_title:title.trim(),expected_title:previousTitle});
 if(error||!data)throw new InputHistoryError('Renommage non confirmé. Votre saisie est conservée ; rechargez si le titre a changé ailleurs.');
 return data as AnalysisInputEntry;
}
