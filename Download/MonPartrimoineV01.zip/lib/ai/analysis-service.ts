import { ANALYSIS_INPUT_ERROR, validateAnalysisInputs } from './analysis-inputs';
import { createHmac, timingSafeEqual } from 'node:crypto';
import { AnalysisError, buildAnalysisPrompt, normalizeSelection, packAnalysisContext, unpackAnalysisContext, utf8Length, MAX_ANALYSIS_TOKEN_BYTES, type AnalysisContext } from './analysis-core';
import { projectAnalysisContext, type AnalysisAlias } from './analysis-context';
import { addAnalysisObjectives, type AnalysisObjective } from './analysis-objectives';
import { configuredReport, configuredReportRecords, reportContractIds, type ReportSnapshot } from '@/lib/reports/report-configuration';
import { selectLatestPositionSnapshots } from '@/lib/patrimony/current-valuation-core';

export type AnalysisContractChoice = { id: string; label: string; isActive?: boolean; closedOn?: string | null; typeCode?: string | null; envelopeTypeId?: string | null };
export type PreparedAnalysis = { id: string; expiresAt: string; context: AnalysisContext; aliases: AnalysisAlias[]; prompt: string };
type Discarded = { expires: number; discarded: true };
type Payload = { owner: string; selection: string[]; prepared: PreparedAnalysis; expires: number };
type Dependencies = {
  requireUser: () => Promise<{ id: string }>;
  catalog: (userId: string) => Promise<AnalysisContractChoice[]>;
  snapshot: (selected: readonly string[]) => Promise<ReportSnapshot>;
  objectives?: (userId: string, selected: readonly string[]) => Promise<AnalysisObjective[]>;
  fiscalRegimeLabels?: (ids: readonly string[]) => Promise<Record<string, string>>;
  revisions?: (userId: string) => Promise<{objective:number;allocation:number}>;
  signingKey: () => string;
  now?: () => number; id?: () => string;
};
export const ANALYSIS_TTL_MS = 2 * 60 * 60_000;
// Context integrity is portable; signatures do not encrypt browser-visible data.
// Discard remains per instance; integrity and expiry are portable between instances.
export function createAnalysisService(deps: Dependencies) {
  const entries = new Map<string, Discarded>(), now = deps.now ?? Date.now;
  const key = () => {
    const raw = deps.signingKey();
    if (!/^[A-Za-z0-9+/]{43}=$/.test(raw) || Buffer.from(raw, 'base64').length !== 32) throw new AnalysisError('signing_configuration');
    return Buffer.from(raw, 'base64');
  };
  const mac = (value: string) => createHmac('sha256', key()).update(value).digest('base64url');
  const ownerTag = (id: string) => mac('owner:' + id);
  const sweep = () => { for (const [id, entry] of entries) if (entry.expires <= now()) entries.delete(id); };
  const assertCurrent = (id: string, expires: number) => { if (expires <= now() || entries.get(id)?.discarded) throw new AnalysisError('expired'); };
  const sign = (payload: Payload) => {
    const body = Buffer.from(JSON.stringify({ ...payload, prepared: { ...payload.prepared, context: packAnalysisContext(payload.prepared.context) } })).toString('base64url');
    if (body.length + 44 > MAX_ANALYSIS_TOKEN_BYTES) throw new AnalysisError('transport_limit');
    return body + '.' + mac('context:v1:' + body);
  };
  const verify = (token: unknown): Payload => {
    if (typeof token !== 'string') throw new AnalysisError('expired');
    if (utf8Length(token) > MAX_ANALYSIS_TOKEN_BYTES) throw new AnalysisError('transport_limit');
    const [body, signature, extra] = token.split('.');
    const expected = mac('context:v1:' + body);
    if (extra !== undefined || !signature || !/^[A-Za-z0-9_-]{43}$/.test(signature) || !timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) throw new AnalysisError('expired');
    try {
      const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
      payload.prepared.context = unpackAnalysisContext(payload.prepared.context);
      return payload as Payload;
    } catch { throw new AnalysisError('expired'); }
  };
  async function authorize(selection: unknown) {
    const user = await deps.requireUser(); if (!user?.id) throw new AnalysisError('auth');
    const ids = normalizeSelection(selection), catalog = await deps.catalog(user.id);
    if (ids.some(id => !catalog.some(c => c.id === id))) throw new AnalysisError('selection');
    return { user, ids, catalog };
  }
  async function lookup(id: unknown, selection: unknown, question?: string) {
    const { user, ids } = await authorize(selection); sweep();
    const payload = verify(id);
    if (payload.owner !== ownerTag(user.id)) throw new AnalysisError('expired');
    assertCurrent(payload.prepared.context.snapshot_id, payload.expires);
    if (JSON.stringify(ids) !== JSON.stringify(payload.selection) || (question !== undefined && question !== (payload.prepared.context.question ?? ''))) throw new AnalysisError('selection');
    payload.prepared.prompt = buildAnalysisPrompt(payload.prepared.context);
    return payload;
  }
  return {
    async prepare(selection: unknown, question = '', scopeMode: 'all' | 'selection' = 'selection', additionalInformation = '', expectedObjectiveRevision?: number): Promise<PreparedAnalysis> {
      try { validateAnalysisInputs(question, additionalInformation); } catch { throw new AnalysisError('input'); }
      const { user, ids, catalog } = await authorize(selection);
      const inputRevision=await deps.revisions?.(user.id);
      if(inputRevision && expectedObjectiveRevision!==inputRevision.objective) throw new AnalysisError('shared_conflict');
      const activeIds = ids.filter(id => catalog.find(contract => contract.id === id)?.isActive !== false);
      const closedChoices = ids.flatMap(id => { const contract = catalog.find(item => item.id === id); return contract && contract.isActive === false ? [contract] : []; });
      const snapshot = await deps.snapshot(activeIds);
      if (activeIds.some(id => !snapshot.records.contracts.some(c => c.id === id))) throw new AnalysisError('selection');
      if (!['all', 'selection'].includes(scopeMode)) throw new AnalysisError('selection');
      if (scopeMode === 'all' && JSON.stringify(ids) !== JSON.stringify((await deps.catalog(user.id)).map(c => c.id).sort())) throw new AnalysisError('selection');
      const report = configuredReport(snapshot, activeIds);
      if (report.contracts.length !== activeIds.length) throw new AnalysisError('selection');
      const id = deps.id?.() ?? crypto.randomUUID();
      const types = Object.fromEntries(snapshot.records.contracts.map(c => [c.id, snapshot.records.envelopeTypes.find(t => t.id === c.envelope_type_id)?.code ?? '']));
      const records = configuredReportRecords(snapshot, ids);
      const latest = selectLatestPositionSnapshots(records.positionSnapshots, snapshot.generatedAt);
      const dates: Record<string, string[]> = {};
      for (const position of records.positions) {
        const date = latest.get(position.id)?.valued_at;
        if (date) { (dates[position.asset_id] ??= []).push(date); (dates[position.contract_id] ??= []).push(date); }
      }
      const cashDates = records.cashBalances.reduce((all, balance) => {
        if (typeof balance.as_of === 'string') (all[balance.contract_id] ??= []).push(balance.as_of);
        return all;
      }, {} as Record<string, string[]>);
      const projected = projectAnalysisContext(report, id, types, dates, Object.fromEntries(records.assets.filter(a => a.valuation_mode === 'market_price' && ['stock', 'etf', 'fund', 'bond', 'crypto'].includes(a.asset_type_code)).map(a => [a.id, { name: a.name, symbol: a.symbol, isin: a.isin }])), Object.fromEntries(records.assets.map(a => [a.id,a.asset_type_code])), records.cashBalances.map(balance => balance.contract_id), cashDates);
      const tileById = new Map(records.contracts.map(contract => [contract.id, contract.dashboard_tile_name]));
      projected.context.scope = projected.context.scope.map((contract, index) => {
        const label = tileById.get(report.contracts[index].id);
        const tile = label === null ? "Hors tuile" : label?.trim();
        return tile ? { ...contract, tile } : contract;
      });
      for (const choice of closedChoices) {
        const alias = `C${projected.context.scope.length + 1}`;
        projected.context.scope.push({ alias, type: choice.typeCode ?? 'closed_history', name: choice.label });
        projected.aliases.push({ alias, label: choice.label });
        projected.context.facts.push({ id: `F${projected.context.facts.length + 1}`, subject: alias, label: 'Valorisation actuelle', value: null, unit: 'EUR', status: 'unknown', dates: [], detail: 'Contrat inactif ou clôturé ; aucune valeur actuelle n’est substituée. Consulter uniquement l’historique joint.' });
      }
      projected.context.contract_value_dates = report.contracts.flatMap((contract, index) => {
        const balances = records.cashBalances.filter(balance => balance.contract_id === contract.id);
        // For liquid savings the shared report defines gross as cash only. A
        // single EUR observation establishes its date without an FX inference.
        if (types[contract.id] === 'epargne_liquide' && contract.manualSituationAt === undefined && balances.length === 1 && balances[0].currency_code === 'EUR' && typeof balances[0].as_of === 'string' && /^\d{4}-\d{2}-\d{2}(?:T[\d:.+Z-]+)?$/.test(balances[0].as_of) && Number(balances[0].amount) === contract.grossEur && !contract.valuationUnavailable) return [{ alias: projected.context.scope[index].alias, date: balances[0].as_of }];
        // Employee-savings values are explicit dated contract totals.
        if (['peg', 'per_col'].includes(types[contract.id]) && records.employeeSavingsValuations && contract.manualSituationAt && /^\d{4}-\d{2}-\d{2}(?:T[\d:.+Z-]+)?$/.test(contract.manualSituationAt)) return [{ alias: projected.context.scope[index].alias, date: contract.manualSituationAt }];
        return [];
      });
      const regimeIds = report.contracts.map(c => {
        const raw = records.contracts.find(row => row.id === c.id);
        return c.fiscalSelection ? c.fiscalSelection.regimeId : raw?.fiscal_regime_id ?? null;
      });
      const declaredRegimeIds = report.contracts.map(c => records.contracts.find(row => row.id === c.id)?.fiscal_regime_id ?? null);
      const fiscalLabels = await deps.fiscalRegimeLabels?.([...new Set([...regimeIds, ...declaredRegimeIds].filter((value): value is string => !!value))]) ?? {};
      report.contracts.forEach((contract, index) => {
        const raw = records.contracts.find(row => row.id === contract.id)!;
        projected.context.scope[index].name = raw.display_name?.trim() ? raw.display_name : raw.name;
        projected.aliases[index].label = projected.context.scope[index].name!;
        const regime = regimeIds[index] ? fiscalLabels[regimeIds[index]!] : undefined;
        const declaredRegime = declaredRegimeIds[index] ? fiscalLabels[declaredRegimeIds[index]!] : undefined;
        const date = contract.fiscalSelection ? contract.fiscalSelection.context.fiscalStartedOn : raw.fiscal_started_on ?? null;
        const rule = records.fiscalRules?.find(r => r.id === contract.fiscalSelection?.ruleId);
        const fiscalContext = contract.fiscalSelection?.context;
        const complete = fiscalContext ? fiscalContext.historyComplete : raw.fiscal_history_complete;
        const paid = fiscalContext ? fiscalContext.socialContributionsPaidEur : raw.social_contributions_paid_eur;
        const detail = [typeof complete === 'boolean' ? `Historique fiscal considéré complet par le moteur : ${complete ? 'oui' : 'non'}.` : 'Complétude fiscale non renseignée.', rule?.name ? `Règle appliquée : ${rule.name}.` : 'Règle fiscale détaillée non disponible.', regime ? `Régime renseigné : ${regime}.` : 'Régime fiscal appliqué non identifié.', declaredRegime ? `Régime enregistré : ${declaredRegime}.` : 'Régime enregistré non disponible.', date ? `Date fiscale : ${date}.` : 'Date fiscale inconnue.', `Qualité NET : ${contract.netKind ?? 'unavailable'}.`, 'Informations partielles ; ne pas déduire une fiscalité complète.'].join(' ');
        projected.context.facts.push({id:`F${projected.context.facts.length+1}`,subject:`C${index+1}`,label:'Fiscalité : éléments disponibles',value:null,unit:'information',status:regime?'known':'partial',dates:date?[date]:[],detail});
        const paidNumber = paid == null || String(paid).trim() === '' ? null : Number(paid);
        projected.context.facts.push({id:`F${projected.context.facts.length+1}`,subject:`C${index+1}`,label:'Prélèvements sociaux déjà payés',value:paidNumber !== null && Number.isFinite(paidNumber) ? paidNumber : null,unit:'EUR',status:paidNumber !== null && Number.isFinite(paidNumber) ? 'known' : 'unknown',dates:[],detail:'Montant renseigné, distinct du NET estimé ; aucun calcul fiscal ajouté.'});
      });
      projected.context.question = question; projected.context.additional_information = additionalInformation; projected.context.scope_mode = scopeMode; projected.context.prepared_at = new Date(now()).toISOString();
      const financialIds = reportContractIds({ ...snapshot, records }, 'outside-real-estate');
      const financial = financialIds.length ? configuredReport(snapshot, financialIds) : null;
      const financialFact = financial ? projectAnalysisContext(financial, id, types, dates).context.facts[0] : null;
      projected.context.facts.push({ id: `F${projected.context.facts.length + 1}`, subject: 'Périmètre financier sélectionné', label: 'Brut connu hors immobilier', value: financialFact?.value ?? null, unit: 'EUR', status: financialFact?.status ?? 'unknown', dates: [], detail: 'Sous-périmètre hors immobilier selon les types canoniques ; ne prouve pas la disponibilité des liquidités. Espèces incluses, non additives.' });
      const targets=await deps.objectives?.(user.id, ids) ?? [];
      addAnalysisObjectives(projected.context, report, targets, scopeMode, closedChoices);
      if(inputRevision){
        const after=await deps.revisions!(user.id);
        if(after.objective!==inputRevision.objective || after.allocation!==inputRevision.allocation) throw new AnalysisError('shared_conflict');
        projected.context.input_revision=inputRevision;
      }
      const prompt = buildAnalysisPrompt(projected.context), expires = now() + ANALYSIS_TTL_MS;
      const prepared: PreparedAnalysis = { id, expiresAt: new Date(expires).toISOString(), ...projected, prompt };
      sweep();
      prepared.id = sign({ owner: ownerTag(user.id), selection: ids, prepared: { ...prepared, id: '', aliases: [], prompt: '' }, expires });
      return prepared;
    },
    async manualPrompt(id: unknown, selection: unknown, question?: string) {
      const entry = await lookup(id, selection, question);
      if(deps.revisions){
        const {user}=await authorize(selection);const current=await deps.revisions(user.id),previous=entry.prepared.context.input_revision;
        if(!previous || current.objective!==previous.objective || current.allocation!==previous.allocation) throw new AnalysisError('shared_conflict');
      }
      return entry.prepared.prompt;
    },
    async discard(id: unknown) {
      const user = await deps.requireUser();
      const payload = verify(id);
      if (payload.owner === ownerTag(user.id)) { sweep(); if (entries.size < 256) entries.set(payload.prepared.context.snapshot_id, { expires: payload.expires, discarded: true }); }

    },
  };
}
export function analysisErrorMessage(error: unknown): string {
  const code = error instanceof AnalysisError ? error.code : 'unavailable';
  const messages: Record<string, string> = {
    input: ANALYSIS_INPUT_ERROR,
    history_period: 'Choisissez une période valide : les deux dates personnalisées doivent être présentes et la date de début ne peut pas suivre la date de fin.',
    signing_configuration: 'La clé serveur dédiée à la signature IA doit être configurée avant utilisation ; elle assure l’intégrité du parcours manuel.',
    auth: 'Connectez-vous avec le compte autorisé.', selection: 'Sélection invalide ou modifiée. Préparez à nouveau la photographie.',
    expired: 'Cette préparation est altérée, expirée ou indisponible. Préparez-la à nouveau.',
    preparation_limit: 'Le volume de cette photographie dépasse la limite de préparation (512 Kio de contexte ou 256 Kio de prompt). Aucun contrat n’a été ignoré ni contenu tronqué. Votre saisie est conservée.',
    shared_conflict: 'L’objectif général ou la répartition a changé. Rechargez les textes puis préparez une nouvelle photographie. Votre saisie est conservée. (OBJ-CONTEXT-STALE)',
    transport_limit: 'Le contexte dépasse la limite de transport signé (384 Kio). Votre sélection et vos textes sont conservés.',
  };
  return messages[code] ?? 'Analyse momentanément indisponible. Votre photographie et son prompt restent consultables ; aucune donnée modifiée.';
}
