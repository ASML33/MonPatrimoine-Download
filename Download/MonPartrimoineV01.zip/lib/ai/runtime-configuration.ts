import "server-only";

import { isAiProvider, type AiProvider } from "./ai-settings-core";
import { createAdminClient } from "@/lib/supabase/admin";

export type AiRuntimeConfiguration = { provider: AiProvider; apiKey: string };

export async function getAiRuntimeConfiguration(): Promise<AiRuntimeConfiguration> {
  const admin = createAdminClient();
  const { data, error } = await admin.rpc("get_ai_runtime_configuration").single();
  const record = data as { provider?: unknown; api_key?: unknown } | null;
  if (error || !record || !isAiProvider(record.provider) || typeof record.api_key !== "string" || !record.api_key) {
    throw new Error("AI_RUNTIME_CONFIGURATION_UNAVAILABLE");
  }
  return { provider: record.provider, apiKey: record.api_key };
}
