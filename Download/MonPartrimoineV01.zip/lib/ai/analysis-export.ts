import { formatMoney } from '../cash/money';
import type { AnalysisContext, AnalysisFact } from './analysis-core';

// Standalone, whitelisted export: no signed transport or technical account IDs.
const cell = (value: string) => value.replace(/[\r\n]+/g, ' ').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/[\\`*_{}[\]()#+!|]/g, '\\$&');
export function analysisFactValue(f: AnalysisFact): string {
  if(f.value === null) return f.unit === 'information' ? (f.status === 'unknown' ? 'Non renseigné' : 'Information') : 'Inconnu';
  if (/^[A-Z]{3}$/.test(f.unit) && !/PRU|Cours/.test(f.label)) {
    return formatMoney(f.value, f.unit, "code").replace(/\u00a0/g, " ");
  }
  const digits = f.unit === '%' || f.unit === 'points' ? 2 : 6;
  const n = new Intl.NumberFormat('fr-FR',{minimumFractionDigits:digits === 2 ? 2 : 0,maximumFractionDigits:digits}).format(f.value);
  const threshold = digits === 2 ? .005 : .0000005, minimum = digits === 2 ? '0,01' : '0,000001';
  return (f.value !== 0 && Math.abs(f.value) < threshold ? (f.value < 0 ? '> -' : '< ') + minimum : n) + ' ' + f.unit;
}
const verbatim = (text: string) => {
  const fence = '`'.repeat(Math.max(3, ...Array.from(text.matchAll(/`+/g), match => match[0].length + 1)));
  return [fence + 'text', text, fence].join('\n');
};
export function analysisMarkdown(context: AnalysisContext): string {
  const summaryValue = (fact: AnalysisFact | undefined) => !fact ? 'Inconnu' : analysisFactValue(fact) + (fact.value !== null && fact.status === 'partial' ? ' (partiel : brut connu seulement)' : '');
  const table = (facts: AnalysisFact[]) => [
    '| Référence | Sujet | Indicateur | Valeur | Qualité | Dates sources / récupération | Limites |',
    '| --- | --- | --- | --- | --- | --- | --- |',
    ...facts.map(f => `| ${f.id} | ${cell(f.subject)} | ${cell(f.label)} | ${cell(analysisFactValue(f))} | ${f.status} | ${cell(f.dates.join(', ') || 'Non précisée')} | ${cell(f.detail)} |`), '',
  ];
  const contractFacts = context.facts.filter(f => /^C\d+$/.test(f.subject));
  const assetFacts = context.facts.filter(f => /^A\d+(?: \/ C\d+)?$/.test(f.subject));
  const summaryFacts = context.facts.filter(f => f.subject.startsWith('Périmètre'));
  const otherFacts = context.facts.filter(f => !contractFacts.includes(f) && !assetFacts.includes(f) && !summaryFacts.includes(f));
  return [
    '# Photographie patrimoniale — MonPatrimoine', '',
    `Préparation : ${context.prepared_at ?? context.generated_at} ; photographie calculée : ${context.generated_at} (instants ISO, affichage applicatif Europe/Paris). Devise : EUR.`, '',
    context.scope_mode === 'all' ? 'Périmètre : tous les contrats disponibles sélectionnés explicitement.' : 'Périmètre : sélection partielle. Les poids ont pour dénominateur le brut connu de cette seule sélection, jamais le patrimoine global.', '',
    'Contrats sélectionnés : ' + context.scope.map(c => `${cell(c.name ?? 'Nom non disponible')} — ${c.alias} (${c.type})`).join(', '), '',
    '## Noms exacts des contrats sélectionnés', '', ...context.scope.flatMap(c => [c.alias, '', verbatim(c.name ?? 'Nom non disponible'), '']),
    '## Situation et objectifs', '', context.additional_information ? verbatim(context.additional_information) : 'Non renseigné.', '',
    'Déclarations de l’utilisateur, non vérifiées par le moteur patrimonial.', '',
    '## Question(s)', '', context.question ? verbatim(context.question) : 'Analyser la stratégie, la répartition, les concentrations et les limites du périmètre.', '',
    '## Synthèse des totaux et du périmètre', '', ...table(summaryFacts),
    'Les contrats, actifs et espèces sont des composants du total, pas des montants à additionner.', '',
    '## Contrats', '',
    '| Contrat | Type canonique | Valeur brute EUR | Poids d’allocation | Références |',
    '| --- | --- | --- | --- | --- |',
    ...context.scope.map(c => {
      const value = contractFacts.find(f => f.subject === c.alias && f.label === 'Valorisation brute connue');
      const weight = contractFacts.find(f => f.subject === c.alias && f.label === 'Poids du contrat dans le brut connu');
      return `| ${cell(c.name ?? "Nom non disponible")} (${c.alias}) | ${cell(c.type)} | ${cell(summaryValue(value))} | ${cell(summaryValue(weight))} | ${[value?.id,weight?.id].filter(Boolean).join(', ')} |`;
    }), '',
    'Les poids des contrats reprennent l’allocation du Rapport : arrondi au centième par plus forts restes pour totaliser 100 % lorsque les composants couvrent le brut. Le ratio individuel peut différer de 0,01 point. Les actifs utilisent le ratio sur le brut connu de la sélection, sans ajustement. Les faits conservent les valeurs de calcul, la présentation seule est arrondie.', '',
    ...table(contractFacts),
    '## Actifs et rattachement aux contrats', '', ...table(assetFacts),
    '## Allocations, expositions, couverture et dates complémentaires', '', ...table(otherFacts),
    '## Objectifs de titres : lecture', '', 'Les cibles de titres concernent leur contrat d’application, pas le patrimoine global. Le contrat enregistré définit la base de comparaison ; les anciennes cibles sans rattachement restent non affectées, avec écart indisponible. Les poids actuels A… / C… utilisent la valeur BRUT du seul contrat, espèces incluses ; ce ne sont pas les poids globaux. Aucun contrat hors sélection ajouté, aucune cible renormalisée. Une association explicite est nécessaire pour comparer une ancienne cible non affectée.', '',
    '## Lecture et limites', '',
    'Les composants (contrats, actifs, espèces, sous-périmètre financier) ne s’additionnent pas au total. Espèces ne signifie pas ensemble des liquidités disponibles : disponibilité des livrets et contrats, horizon et besoins restent à établir. Hors immobilier ne signifie pas immédiatement mobilisable.', '',
    'Inconnu ne signifie pas zéro. Couverture partielle et dates sources limitent les conclusions. Aucune information externe récente ajoutée à cette photographie. Une analyse externe peut rechercher des sources séparément, sans modifier ces valeurs figées. Les ratios de gain ne sont pas annualisés.', '',
    'Ce document reste lisible après expiration de la préparation applicative. Ce n’est pas une archive de sauvegarde ou de restauration. Document privé, sans lien public ni envoi automatique.', '',
  ].join('\n');
}
