import { validateAnalysisInputs, type AnalysisInputs } from './analysis-inputs';

export type AnalysisInputField = keyof AnalysisInputs;
export type AnalysisInputEntry = { id: string; recordedAt: string; text: string; title?: string; origin?: 'strategy_transition' };
export type AnalysisInputHistories = Record<AnalysisInputField, AnalysisInputEntry[]>;
export class InputHistoryError extends Error {}
export const emptyInputHistories = (): AnalysisInputHistories => ({ question: [], additionalInformation: [] });
export const isAnalysisInputField = (field: unknown): field is AnalysisInputField => field === 'question' || field === 'additionalInformation';
export const isHistoryId = (id: unknown): id is string => typeof id === 'string' && /^[\da-f]{8}(?:-[\da-f]{4}){3}-[\da-f]{12}$/i.test(id);

export function validateHistoryText(field: AnalysisInputField, text: unknown): string {
  if (typeof text !== 'string' || field === 'question' && !text.trim()) throw new Error('Saisissez un texte non vide avant de l’enregistrer.');
  validateAnalysisInputs(field === 'question' ? text : '', field === 'additionalInformation' ? text : '');
  return text; // Whitespace, including newlines, belongs to the saved text.
}
export function readInputHistories(preferences: unknown): AnalysisInputHistories {
  const root = preferences && typeof preferences === 'object' ? preferences as Record<string, unknown> : {};
  const value = root.ai_photograph as { historyVersion?: unknown; histories?: AnalysisInputHistories; question?: unknown; additionalInformation?: unknown } | undefined;
  if (!value) return emptyInputHistories();
  if (value.historyVersion !== 1) {
    if ([value.question, value.additionalInformation].some(t => typeof t === 'string' && t.trim())) throw new Error('La reprise des textes IA doit être appliquée avant de charger leurs historiques.');
    return emptyInputHistories();
  }
  const result = emptyInputHistories();
  for (const field of ['question', 'additionalInformation'] as const) {
    const entries = value.histories?.[field];
    if (!Array.isArray(entries)) throw new Error('Historique IA indisponible. Aucun texte enregistré n’a été supprimé.');
    const seen = new Set<string>();
    result[field] = entries.map(entry => {
      if (!entry || !isHistoryId(entry.id) || seen.has(entry.id) || typeof entry.recordedAt !== 'string' || !Number.isFinite(Date.parse(entry.recordedAt))) throw new Error('Historique IA invalide.');
      validateHistoryText(field, entry.text); seen.add(entry.id);
      return { id: entry.id, recordedAt: entry.recordedAt, text: entry.text, ...(typeof entry.title==='string' && entry.title.trim()?{title:entry.title}:{}), ...(entry.origin === 'strategy_transition' ? {origin: entry.origin} : {}) };
    }).sort((a, b) => Date.parse(b.recordedAt) - Date.parse(a.recordedAt));
  }
  return result;
}
export function latestAnalysisInputs(histories: AnalysisInputHistories): AnalysisInputs {
  return { question: histories.question[0]?.text ?? '', additionalInformation: histories.additionalInformation[0]?.text ?? '' };
}
export function inputHistoryDate(value: string) {
  const date = new Date(value);
  const day = new Intl.DateTimeFormat('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Europe/Paris' }).format(date);
  const time = new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit', hourCycle: 'h23', timeZone: 'Europe/Paris' }).format(date);
  return day.charAt(0).toUpperCase() + day.slice(1) + ' - ' + time;
}

export const GENERAL_OBJECTIVE_LABEL = 'Contexte patrimonial et objectifs';
export const GENERAL_OBJECTIVE_HELP = 'Décrivez votre situation actuelle, vos projets et vos objectifs patrimoniaux. Précisez les échéances, les besoins de liquidités et les contraintes qui comptent pour vous.';
export type SharedObjective = { value: string; entries: AnalysisInputEntry[]; revision: number };
export function readSharedObjective(preferences: unknown): SharedObjective {
  const root = preferences && typeof preferences === 'object' ? preferences as Record<string, unknown> : {};
  const doc = root.ai_photograph as {sharedObjectiveVersion?:unknown;sharedObjectiveRevision?:unknown} | undefined;
  if (doc?.sharedObjectiveVersion !== 1 || !Number.isSafeInteger(doc.sharedObjectiveRevision) || (doc.sharedObjectiveRevision as number) < 0) throw new InputHistoryError('La transition de l’objectif général doit être appliquée. (OBJ-TRANSITION)');
  const entries = readInputHistories(preferences).additionalInformation;
  return {value:entries[0]?.text ?? '',entries,revision:doc.sharedObjectiveRevision as number};
}
