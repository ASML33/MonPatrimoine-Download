import type { PatrimonialReport } from '@/lib/reports/patrimonial-report-core';
import { reportContractGross } from '@/lib/reports/patrimonial-report-core';
import { reportGain } from '@/lib/reports/report-configuration';
import { ANALYSIS_ENVELOPE_TYPE_LABELS, type AnalysisContext, type AnalysisFact } from './analysis-core';

export type AnalysisAlias = { alias: string; label: string };
const projectedContractGross = (c: PatrimonialReport['contracts'][number]) => {
  const gross = reportContractGross(c);
  return gross === 0 && (c.incompletePositions || c.incompleteCashBalances) ? null : gross;
};
const datesOnly = (dates: (string | null | undefined)[]) => [...new Set(dates.filter((s): s is string => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}(?:T[\d:.+Z-]+)?$/.test(s)))].sort();
// Explicit projection: no spread of records, metadata, sources, notes or identifiers.
export function projectAnalysisContext(report: PatrimonialReport, snapshotId: string, typeCodes: Record<string, string>, sourceDates: Record<string, string[]> = {}, publicAssets: Record<string, { name: string; symbol: string | null; isin?: string | null }> = {}, assetTypes: Record<string,string> = {}, cashBalanceContractIds: readonly string[] = [], cashBalanceDates: Record<string, string[]> = {}) {
  const facts: AnalysisFact[] = [], aliases: AnalysisAlias[] = [];
  const holdingCosts: NonNullable<AnalysisContext["holding_costs"]> = [];
  const add = (subject: string, label: string, value: number | null, unit: AnalysisFact['unit'], status: AnalysisFact['status'], dates: string[] = [], detail = '') => {
    const finite = value === null || !Number.isFinite(value) ? null : value;
    facts.push({ id: `F${facts.length + 1}`, subject, label, value: finite, unit, status: finite === null && unit !== 'information' ? 'unknown' : status, dates, detail });
  };
  const incomplete = report.contracts.some(c => c.incompletePositions || c.incompleteCashBalances || reportContractGross(c) === null);
  add('Périmètre', 'Valorisation brute connue, espèces incluses', incomplete && report.summary.grossEur === 0 ? null : report.summary.grossEur, 'EUR', incomplete ? 'partial' : 'known', [], 'Ne pas additionner ce montant aux contrats ou aux actifs qui le composent.');
  const cashIncomplete = report.contracts.some(c => c.incompleteCashBalances);
  add('Périmètre', 'Espèces connues', cashIncomplete && report.summary.cashEur === 0 ? null : report.summary.cashEur, 'EUR', cashIncomplete ? 'partial' : 'known');
  add('Périmètre', 'Plus-values latentes connues des titres', report.summary.valuedUnrealizedPositions ? report.summary.unrealizedGainEur : null, 'EUR', report.summary.incompleteUnrealizedPositions ? 'partial' : 'known', [], 'Distinctes du gain du contrat ; les supports en montant sans flux propres ne sont pas des titres à PRU.');
  const scope = report.contracts.map((c, i) => {
    const alias = `C${i + 1}`; aliases.push({ alias, label: c.name });
    const dates = datesOnly([c.manualSituationAt, ...(sourceDates[c.id] ?? [])]);
    const value = projectedContractGross(c);
    add(alias, 'Valorisation brute connue', value, 'EUR', c.incompletePositions || c.incompleteCashBalances ? 'partial' : 'known', dates, c.manualSituationPrecision ? `Précision de la situation : ${c.manualSituationPrecision}.` : 'Dates des observations disponibles ; récupération distincte dans les faits de dates.');
    add(alias, 'Espèces connues', c.incompleteCashBalances && c.cashEur === 0 ? null : c.cashEur, 'EUR', c.incompleteCashBalances ? 'partial' : 'known');
    const gain = reportGain(c);
    add(alias, 'Gain du contrat', gain.amount, 'EUR', 'known', dates, gain.missing ? `Limite : ${gain.missing}` : 'Valorisation + retraits externes − versements externes.');
    add(alias, 'Ratio du gain sur versements', gain.percentage, '%', 'known', dates, 'Ratio non annualisé.');
    // Only expose a denominator when the shared gain proves it usable (including explicit zero).
    add(alias, 'Base du ratio : versements bruts', gain.percentage !== null || gain.missing === 'zero_contributions' ? c.totalContributionsEur : null, 'EUR', 'known', [], 'Base inconnue ou non exploitable si le ratio ne peut être établi.');
    add(alias, 'Latentes connues des titres', c.valuedUnrealizedPositions ? c.unrealizedGainEur : null, 'EUR', c.incompleteUnrealizedPositions ? 'partial' : 'known');
    const code = typeCodes[c.id], recognized = Object.hasOwn(ANALYSIS_ENVELOPE_TYPE_LABELS, code), type = recognized ? code : 'inconnu';
    add(alias, 'Nature du contrat', null, 'information', recognized ? 'known' : 'unknown', [], `${recognized ? `${type} — ${ANALYSIS_ENVELOPE_TYPE_LABELS[type]}` : 'Type d’enveloppe non reconnu ou non renseigné'}. Disponibilité et blocage non renseignés ; ne pas les déduire du solde espèces.`);
    if (type === 'immobilier') add(alias, 'Usage immobilier', null, 'information', 'unknown', [], 'Usage non renseigné dans les données structurées disponibles.');
    return { alias, type, name: c.name };
  });
  for (const [i, asset] of report.assets.entries()) {
    const alias = `A${i + 1}`; aliases.push({ alias, label: asset.name });
    const identity = publicAssets[asset.id];
    const kind = assetTypes[asset.id];
    const assetLabels: Record<string,string> = {stock:'Action',etf:'ETF',fund:'Fonds',bond:'Obligation',crypto:'Cryptoactif',real_estate:'Bien immobilier'};
    add(alias, 'Nature du placement', null, 'information', kind && assetLabels[kind] ? 'known' : 'unknown', [], kind && assetLabels[kind] ? `${kind} — ${assetLabels[kind]}` : 'Nature non renseignée.');
    if(kind === 'real_estate') add(alias,'Usage immobilier',null,'information','unknown',[],'Usage non renseigné dans les données structurées disponibles.');
    for (const holding of asset.holdings) {
      const contractIndex = report.contracts.findIndex(c => c.id === holding.contractId);
      if(contractIndex >= 0) {
        const subject = `${alias} / C${contractIndex + 1}`;
        add(subject, 'Valeur détenue dans le contrat', holding.valueEur, 'EUR', 'known', [], 'Composante de la valeur de l’actif et du contrat, non additive aux totaux.');
        if (!holding.valueSemantics) {
          add(subject, 'Quantité détenue dans le contrat', holding.quantity, 'unités', 'known');
          if (/^[A-Z]{3}$/.test(holding.costCurrencyCode)) add(subject, 'PRU natif dans le contrat', holding.averageCostPerUnit, holding.costCurrencyCode, 'known', [], 'Devise native du PRU ; conversion EUR distincte, inconnue si non qualifiée.');
          if (holding.nativeUnitCost && /^[A-Z]{3}$/.test(holding.costCurrencyCode)) {
            const asOf = datesOnly([holding.nativeUnitCost.asOf])[0];
            const historicalAsOf = datesOnly([holding.ctoHistoricalCostAsOf])[0];
            holdingCosts.push({ subject, native: { montant: holding.nativeUnitCost.amount, devise: holding.costCurrencyCode, ...(asOf ? { as_of: asOf } : {}) },
              ...(holding.ctoHistoricalCostKind && holding.acquisitionCostEur !== null ? { historical: { montant: holding.acquisitionCostEur, devise: "EUR", statut: holding.ctoHistoricalCostKind, ...(historicalAsOf ? { as_of: historicalAsOf } : {}) } } : {}),
              ...(holding.costCurrencyCode !== "EUR" && holding.ctoDisplayUnitEur != null ? { display: { montant: holding.ctoDisplayUnitEur, devise: "EUR" } } : {}) });
          }
          add(subject, 'Coût d’acquisition EUR dans le contrat', holding.acquisitionCostEur, 'EUR', 'known', [], 'Coût calculé par le Rapport, inconnu si non qualifié.');
        }
      }
    }
    if (!identity) add(alias, 'Nom du support', null, 'information', 'known', [], asset.name);
    if (identity) {
      add(alias, 'Identité publique', null, 'information', 'known', [], [identity.name, identity.symbol, identity.isin].filter(Boolean).join(' · '));
      const currency=asset.priceCurrencyCode && /^[A-Z]{3}$/.test(asset.priceCurrencyCode)?asset.priceCurrencyCode:null;
      if(currency) add(alias,'Cours enregistré (devise native)',asset.currentPrice,currency,'known',datesOnly([asset.priceObservedAt]),'Cours figé de la photographie, pas un cours externe récent ni un objectif de cours.');
      add(alias,'Cours enregistré converti en EUR',asset.currentPriceEur ?? (currency==='EUR'?asset.currentPrice:null),'EUR','known',datesOnly([asset.priceObservedAt]),'Conversion de la photographie ; inconnue si le FX manque.');
    }
    if (asset.holdings.every(h => !h.valueSemantics)) {
      add(alias, 'Quantité', asset.quantity, 'unités', 'known');
      add(alias, 'PRU converti en EUR', asset.averageCostPerUnitEur ?? null, 'EUR', 'known');
      add(alias, 'Plus-value latente des titres', asset.unrealizedGainEur, 'EUR', asset.holdings.some(h => h.unrealizedGainEur === null) ? 'partial' : 'known');
    }
    add(alias, 'Valorisation connue de l’actif (composante, non additive aux contrats)', asset.valueEur, 'EUR', asset.holdings.some(h => h.valueEur === null) ? 'partial' : 'known', datesOnly([asset.priceObservedAt, ...(sourceDates[asset.id] ?? [])]));
    add(alias, 'Poids dans le brut connu', asset.valueEur === null || report.summary.grossEur <= 0 ? null : asset.portfolioPercentage, '%', incomplete || asset.holdings.some(h => h.valueEur === null) ? 'partial' : 'known', [], incomplete ? 'Ratio de la part connue sur le seul brut connu de la sélection, lui-même partiel ; ce n’est pas un poids sur le patrimoine complet.' : 'Ratio exact valeur de l’actif / brut connu de la sélection ; pas d’ajustement à 100 %.');
    if (asset.holdings.some(h => h.valueSemantics === 'total_amount')) add(alias, 'Suivi en montant', null, 'information', 'known', [], 'Quantité/PRU non requis. Gain propre indisponible : flux et arbitrages non attribués au support.');
  }
  for (const [i, allocation] of report.allocations.envelopeTypes.entries()) {
    const alias = `E${i + 1}`; aliases.push({ alias, label: allocation.name });
    const members = report.contracts.filter(c => c.envelopeTypeId === allocation.id);
    const hasKnown = members.some(c => projectedContractGross(c) !== null);
    const partial = incomplete || members.some(c => c.incompletePositions || c.incompleteCashBalances || projectedContractGross(c) === null);
    add(alias, 'Allocation par type : montant connu', hasKnown ? allocation.amountEur : null, 'EUR', partial ? 'partial' : 'known');
    add(alias, 'Allocation par type : poids du brut connu', hasKnown && report.summary.grossEur > 0 ? allocation.percentage : null, '%', partial ? 'partial' : 'known', [], incomplete ? 'Part connue sur le seul brut connu de la sélection, lui-même partiel.' : 'Poids sur le brut connu de la sélection.');
  }
  report.contracts.forEach((contract, index) => {
    const allocation = report.allocations.contracts.find(item => item.id === contract.id);
    const known = projectedContractGross(contract);
    const partial = incomplete || !!contract.incompletePositions || !!contract.incompleteCashBalances;
    const value = known === null || report.summary.grossEur <= 0 ? null : allocation?.percentage ?? null;
    add(`C${index + 1}`, 'Poids du contrat dans le brut connu', value, '%', partial ? 'partial' : 'known', [], incomplete
      ? 'Part connue sur le seul brut connu de la sélection, lui-même partiel ; ce n’est pas un poids sur le patrimoine complet.'
      : 'Poids d’allocation du Rapport sur le brut connu : plus forts restes au centième si les composants couvrent le brut ; sinon ratio.');
  });
  for (const [dimension, distribution] of Object.entries({ secteurs: report.exposures.sectors, activités: report.exposures.activities, pays: report.exposures.geography.countries, régions: report.exposures.geography.regions, thèmes: report.exposures.themes })) {
    add(dimension, 'Couverture du brut connu', distribution.coveragePercentage, '%', distribution.incompleteAssetIds.length ? 'partial' : 'known', [], dimension === 'thèmes' ? 'Thèmes chevauchants : leurs poids ne s’additionnent pas comme une partition.' : 'Non spécifié conserve le poids non attribué.');
    // Reference labels may be user-defined. Aliases avoid transmitting free text.
    distribution.items.forEach((item, i) => {
      const alias = `${dimension}-${i + 1}`; aliases.push({ alias, label: item.name });
      add(alias, `${dimension} : poids dans le brut connu`, item.percentage, '%', distribution.incompleteAssetIds.length ? 'partial' : 'known', datesOnly(item.dataDates), item.unspecified ? 'Non spécifié.' : `Catégorie d’exposition : ${item.name}`);
    });
  }
  // Identity-based provenance only. Bare flow dates do not describe a usable flow.
  const dateFacts = new Set<string>();
  for (const item of report.quality.freshness) {
    if(item.kind === 'flow') continue;
    const ai = report.assets.findIndex(a => a.id === item.assetId);
    const ci = report.contracts.findIndex(c => c.id === item.contractId);
    const currency = item.currencyCode && /^[A-Z]{3}$/.test(item.currencyCode) ? item.currencyCode : null;
    const subject = ai >= 0 ? `A${ai + 1}${ci >= 0 ? ` / C${ci + 1}` : ''}` : ci >= 0 ? `C${ci + 1}${currency ? ` / ${currency}` : ''}` : item.kind === 'fx' && currency ? `FX ${currency}/EUR` : null;
    if(!subject) continue; // Never export an uninterpretable technical date.
    const dimension = ['sector','activity','country','region'].includes(item.dimension ?? '') ? ` / ${item.dimension}` : '';
    for(const [label,date] of [['date source',item.observedAt],['date de récupération',item.obtainedAt]] as const) {
      const dates = datesOnly([date]);
      // A missing retrieval timestamp is not a missing financial observation.
      if(label === 'date de récupération' && !dates.length) continue;
      const title = `${item.kind}${dimension} : ${label}`;
      const key = JSON.stringify([subject,title,dates,item.stale]);
      if(dateFacts.has(key)) continue;
      dateFacts.add(key);
      add(subject,title,null,'information',dates.length ? 'known' : 'unknown',dates,label === 'date de récupération' ? 'Instant technique distinct de la date source.' : item.stale ? 'Source ancienne selon le seuil applicatif.' : 'Date source ; inconnue si absente.');
    }
  }
  for (const warning of report.quality.warnings) add('Qualité', warning.code, null, 'information', 'partial', [], 'Limite signalée par le moteur du Rapport.');
  const context: AnalysisContext = { version: 1, snapshot_id: snapshotId, generated_at: report.meta.generatedAt, time_zone: 'Europe/Paris', currency: 'EUR', scope, facts,
    asset_names: report.assets.map((asset, index) => ({ alias: `A${index + 1}`, name: asset.name })),
    holding_costs: holdingCosts,
    contribution_totals: scope.flatMap(({ alias }, index) => {
      const total = report.contracts[index].contributionTotal;
      if (!total) return [];
      const asOf = datesOnly([total.asOf])[0];
      return [{ alias, value: { montant: total.amountEur, devise: "EUR", amount_status: total.status, ...(asOf ? { as_of: asOf } : {}) } }];
    }),
    cash_balance_contracts: scope.filter((contract, index) => cashBalanceContractIds.includes(report.contracts[index].id)).map(contract => contract.alias),
    cash_balance_dates: scope.flatMap((contract, index) => {
      const dates = [...new Set((cashBalanceDates[report.contracts[index].id] ?? []).filter(date => /^\d{4}-\d{2}-\d{2}(?:T[\d:.+Z-]+)?$/.test(date)))].sort();
      return dates.length ? [{ alias: contract.alias, dates }] : [];
    }),
  };
  return { context, aliases };
}
