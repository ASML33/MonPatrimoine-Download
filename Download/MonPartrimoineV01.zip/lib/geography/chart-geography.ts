import { formatMoney } from "@/lib/cash/money";
import {parisDate} from "@/lib/patrimony/current-valuation-core";
import {mixedGeography,type GeoContract} from "@/lib/geography/mixed-geography";
import {resolveExposureHistory} from "@/lib/assets/exposure-history";
import {resolveSelection,historicalSelectionIds,historicalHoldingState,stableColor,type PatrimonyChartData,type ChartPoint} from "@/lib/patrimony/chart-core";
import {distinctAutomaticColors} from "@/lib/patrimony/distribution-core";
export function chartGeography(data:PatrimonyChartData,selection:Record<string,"global"|string[]>,point:ChartPoint|null,regional=false){
 if(data.exposureUnavailable||!data.geographyReferences)return {slices:[],unavailable:"Répartition géographique indisponible : référentiels ou expositions non lus."};
 try{
  const ids=point?historicalSelectionIds(point,resolveSelection(data.contracts,selection),data.contracts):resolveSelection(data.contracts,selection),date=point?.date??(data.generatedAt?parisDate(data.generatedAt):data.latestDate!);
  const trace:string[]=[];
  const contracts:GeoContract[]=data.contracts.filter(c=>selection[c.id]).flatMap(c=>{
   const global=selection[c.id]==="global";
   if(global&&!ids.includes(`contract:${c.id}`)||point&&historicalHoldingState(point,`contract:${c.id}`,data.contracts)==="absent")return [];
   const candidates=c.children.filter(child=>global||(selection[c.id] as string[]).includes(child.id));
   const cash=c.children.filter(ch=>ch.kind==="cash").map(ch=>point?point.cash[ch.id]:ch.valueEur);
   return [{id:c.id,name:c.name,global,liquid:c.envelopeTypeCode==="epargne_liquide",metadata:data.geographicLocations?.contracts[c.id],gross:point?point.values[`contract:${c.id}:gross`]??null:c.valuationIncomplete?null:c.grossEur,cash:cash.some(v=>v==null)?null:cash.reduce<number>((s,v)=>s+v!,0),parts:candidates.flatMap(ch=>{
    if(ch.kind==="cash"&&c.envelopeTypeCode!=="epargne_liquide"||point&&historicalHoldingState(point,ch.id,data.contracts)==="absent")return [];
    const resolved=ch.assetId?(point?resolveExposureHistory(data.exposures,ch.assetId,"geography",point.date):{rows:data.exposures.filter(e=>e.assetId===ch.assetId&&e.dimension==="geography"&&!e.snapshotDate&&e.isCurrent!==false&&e.stage!=="draft"&&e.stage!=="scheduled"),method:"current",sourceDate:null}):{rows:[],method:"unavailable",sourceDate:null};
    if(resolved.rows.length)trace.push(`${ch.label} : ${resolved.method==="exact"?"capture présente conservée":resolved.method==="backfill"?"reprise historique autorisée":"exposition effective"} · données ${resolved.sourceDate??"date inconnue"}`);
    return [{id:ch.id,name:ch.label,value:point?(ch.kind==="cash"?point.cash[ch.id]:point.values[ch.id])??null:ch.valueEur,unknownHolding:Boolean(point&&historicalHoldingState(point,ch.id,data.contracts)==="unknown"),property:c.envelopeTypeCode==="immobilier",capital:ch.kind==="cash",metadata:ch.assetId?data.geographicLocations?.assets[ch.assetId]:undefined,exposures:resolved.rows}];
   })}];
  });
  const result=mixedGeography(contracts,data.geographyReferences.countries,data.geographyReferences.regions,date,point&&ids.includes("employee-savings-combined")?point.employeeSavingsCombined:null),distribution=regional?result.regions:result.countries;
  const universe=[...new Set([...(regional?data.geographyReferences.regions.map(r=>r.code):data.geographyReferences.countries.map(c=>c.id)),"unallocated"])].map(id=>({id:`geography:${regional?"region:":""}${id}`,color:stableColor(`geography:${regional?"region:":""}${id}`),automatic:true}));
  const colors=new Map(distinctAutomaticColors(universe).map(r=>[r.id,r.color]));
  return {slices:distribution.items.map(r=>{const id=`geography:${regional?"region:":""}${r.id}`;return {id,name:r.name,amount:r.amountEur,color:colors.get(id)!,unspecified:r.unspecified};}),unavailable:!distribution.items.length?"Aucune contribution géographique valorisée disponible.":null,trace:[...trace,...result.trace],details:result.details,coverageNote:`Base BRUT connue : ${formatMoney(distribution.denominatorEur,"EUR")}. ${distribution.financialIncomplete?"Couverture financière incomplète ; pourcentages sur le sous-total connu, couverture totale non quantifiable.":`Couverture géographique nommée : ${distribution.coveragePercentage?.toFixed(2)??"indisponible"} %.`} Espèces des comptes à titres exclues ; capital d’épargne liquide inclus. Non spécifié conserve les parts publiées ainsi que les montants sans ventilation ; leurs provenances restent distinctes.`,distribution};
 }catch(error){return {slices:[],unavailable:error instanceof Error?error.message:"Répartition géographique ambiguë"};}
}
