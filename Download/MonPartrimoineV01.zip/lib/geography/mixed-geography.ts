import {locationAt} from "@/lib/geography/location-history";
import {exposureWeightTotal,type DistributionExplanation} from "@/lib/patrimony/distribution-core";
export type CountryReference={id:string;name:string;code?:string;region_code:string};
export type GeoExposure={referenceId?:string;name:string;weight:number;dataDate?:string|null;source?:string|null;unallocated?:boolean};
export type GeoPart={id:string;name:string;value:number|null;unknownHolding?:boolean;property?:boolean;capital?:boolean;metadata?:unknown;exposures:GeoExposure[]};
export type GeoContract={id:string;name:string;gross:number|null;cash:number|null;liquid:boolean;global:boolean;metadata?:unknown;parts:GeoPart[]};
export type GeoItem={id:string;name:string;amountEur:number;percentage:number|null;dataDates:string[];sources:string[];unspecified?:boolean};
export type GeoDistribution={denominatorEur:number;coveredEur:number;coveragePercentage:number|null;items:GeoItem[];incompleteAssetIds:string[];financialIncomplete:boolean};
export const MIXED_GEOGRAPHY_HELP="Exposition des placements et localisation des autres biens";

// One ledger feeds countries and derived regions. Containers never add their
// full amount on top of components; financial absence differs from no country.
export function mixedGeography(contracts:GeoContract[],countries:CountryReference[],regions:{code:string;name:string}[],date:string,common?:number|null){
 const ledger:{id:string;amount:number;source:string;date:string|null;known:boolean}[]=[],missing:string[]=[],unlocated:string[]=[],trace:string[]=[];
 const details:DistributionExplanation[]=[];
 const explain=(id:string,name:string,reason:string,inDonut:boolean)=>details.push({id,name,reason,inDonut});
 const byId=new Map(countries.map(c=>[c.id,c]));
 const add=(id:string|null,amount:number,source:string,dataDate:string|null)=>{if(amount<0||!Number.isFinite(amount))throw Error("Répartition indisponible : valorisation négative ou incohérente.");const c=id?byId.get(id):null;ledger.push({id:c?.id??"unallocated",amount,source,date:dataDate,known:Boolean(c&&c.code!=="unspecified")});};
 const locate=(part:GeoPart,metadata:unknown)=>{const e=locationAt(metadata,date);if(!e?.countryId){unlocated.push(part.id);if(part.value!>0)explain(part.id,part.name,e?"Localisation explicitement non spécifiée sur cet intervalle.":"Aucune localisation applicable à cette date.",true);}add(e?.countryId??null,part.value!,e?`${e.source} · ${e.origin==="confirmed_history"?"reprise historique confirmée":"effet "+e.effectiveOn} · enregistré ${e.recordedAt}`:"Localisation non spécifiée",e?.effectiveOn??null);if(e)trace.push(`${part.name} : ${e.source} · ${e.origin==="confirmed_history"?"tout l’historique documenté, date d’observation passée inconnue":"effet "+e.effectiveOn}`);};
 if(common!=null){add(null,common,"PEG + PER COL — historique commun non ventilé",date);if(common>0)explain("employee-savings-combined","PEG + PER COL","Montant commun documenté, sans ventilation géographique qualifiée ; compté une seule fois.",true);trace.push("PEG + PER COL : contribution commune unique, géographie non spécifiée sans ventilation qualifiée.");}
 for(const c of contracts){
  let known=0,unknown=false;
  for(const p of c.parts){
   if(p.value==null||p.unknownHolding){if(!c.global)missing.push(p.name);explain(p.id,p.name,p.unknownHolding?"Détention historique inconnue ; aucun montant attribué à cet actif.":"Valorisation inconnue ; aucun montant attribué à cet actif.",false);unknown=true;continue;}
   known+=p.value;
   if(p.property||p.capital){locate(p,p.capital?c.metadata:p.metadata);continue;}
   const weight=exposureWeightTotal(p.exposures.map(r=>r.weight));
   if(!Number.isFinite(weight)||weight>100.000001||p.exposures.some(r=>r.weight<0))throw Error("Pondérations géographiques incohérentes");
   for(const r of p.exposures)add(r.unallocated&&byId.get(r.referenceId??"")?.code!=="unspecified"?null:r.referenceId??null,p.value*r.weight/100,r.source??"Exposition publiée",r.dataDate??null);
   if(weight<100)add(null,p.value*(100-weight)/100,"Exposition non spécifiée",null);
   const unmapped=p.exposures.some(r=>r.weight>0&&!byId.has(r.referenceId??""));
   if(p.value>0&&(weight<100||unmapped||p.exposures.some(r=>r.weight>0&&r.unallocated&&byId.get(r.referenceId??"")?.code!=="unspecified")))explain(p.id,p.name,unmapped?"Référence géographique absente du catalogue lu ; sa part reste Non spécifié.":weight===0?"Aucune répartition géographique qualifiée applicable.":"Répartition géographique partielle : seule la part sans source est Non spécifié.",true);
   for(const r of p.exposures.filter(r=>byId.get(r.referenceId??"")?.code==="unspecified"&&p.value!*r.weight/100>0))explain(p.id,`${c.name} · ${p.name}`,`Catégorie Non spécifié explicitement publiée ; données ${r.dataDate??"date inconnue"} · ${r.source??"source non spécifiée"}.`,true);
   if(weight<100||p.exposures.some(r=>r.unallocated||byId.get(r.referenceId??"")?.code==="unspecified"))unlocated.push(p.id);
  }
  if(c.global){
   if(c.gross==null||(!c.liquid&&c.cash==null)){missing.push(c.name);explain(c.id,c.name,c.gross==null?"Total BRUT inconnu ; couverture financière non quantifiable.":"Solde espèces inconnu : impossible de qualifier le reliquat hors espèces.",false);continue;}
   const remainder=c.gross-(c.liquid?0:c.cash!)-known;
   if(!unknown&&c.parts.some(p=>!p.capital)&&Math.abs(remainder)<=.010001){if(Math.abs(remainder)>.000001)trace.push(`${c.name} : écart total/composants d’un centime conservé sans répartition géographique fictive`);continue;}
   if(remainder<-.005){missing.push(`${c.name} : composants supérieurs au total déclaré`);explain(c.id,c.name,"Composants supérieurs au total déclaré ; couverture financière non quantifiable.",false);continue;}
   // A qualified total covers the value of unidentified components, without
   // attributing the missing securities to a contract's country.
   if(remainder>.005){const part={id:c.id,name:c.name,value:remainder,exposures:[]};if(!c.parts.length||c.liquid&&c.parts.every(p=>p.capital||p.value!=null))locate(part,c.metadata);else {add(null,remainder,"Reliquat BRUT documenté non ventilé",null);unlocated.push(c.id);explain(c.id,c.name,"Reliquat BRUT documenté non ventilé ; aucune détention individuelle déduite.",true);}}
   if(unknown&&c.gross!=null)trace.push(`${c.name} : total qualifié, détail financier incomplet conservé sans détention inventée`);
  }
 }
 const denominator=ledger.reduce((s,r)=>s+r.amount,0),covered=ledger.reduce((s,r)=>s+(r.known?r.amount:0),0);
 const distribution=(regional:boolean):GeoDistribution=>{
  const rows=new Map<string,GeoItem>();
  for(const r of ledger){const country=byId.get(r.id),id=r.id==="unallocated"?"unallocated":regional?country!.region_code:r.id;const name=id==="unallocated"?"Non spécifié":regional?regions.find(x=>x.code===id)?.name??"Non spécifié":country!.name;
   const old=rows.get(id)??{id,name,amountEur:0,percentage:null,dataDates:[],sources:[],unspecified:id==="unallocated"||id==="unspecified"||country?.code==="unspecified"};old.amountEur+=r.amount;if(r.date&&!old.dataDates.includes(r.date))old.dataDates.push(r.date);if(!old.sources.includes(r.source))old.sources.push(r.source);rows.set(id,old);
  }
  const coverage=regional?ledger.reduce((s,r)=>s+(r.known&&byId.get(r.id)?.region_code!=="unspecified"?r.amount:0),0):covered;
  return {denominatorEur:denominator,coveredEur:coverage,coveragePercentage:missing.length?null:denominator>0?coverage/denominator*100:null,items:[...rows.values()].map(r=>({...r,percentage:denominator>0?r.amountEur/denominator*100:null})).sort((a,b)=>b.amountEur-a.amountEur||a.id.localeCompare(b.id)),incompleteAssetIds:[...new Set([...unlocated,...missing])],financialIncomplete:missing.length>0};
 };
 return {countries:distribution(false),regions:distribution(true),trace,details};
}
