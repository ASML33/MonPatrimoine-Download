export type LocationEntry = {id:string;version:number;countryId:string|null;effectiveOn:string|null;origin:"dated"|"confirmed_history";source:string;recordedAt:string};
export type LocationHistory = {version:1;entries:LocationEntry[];archived:LocationEntry[]};
export function locationHistory(metadata:unknown):LocationHistory|null {
 const h=(metadata as {geographic_location?:LocationHistory}|null)?.geographic_location;
 if(!h)return null;
 if(h.version!==1||!Array.isArray(h.entries)||!Array.isArray(h.archived))throw Error("Historique de localisation illisible");
 const days=new Set<string>();
 for(const e of h.entries){const day=e.effectiveOn??"history";if(days.has(day)||!e.id||!Number.isInteger(e.version)||e.version<1||!(e.effectiveOn?/^\d{4}-\d{2}-\d{2}$/.test(e.effectiveOn):e.origin==="confirmed_history"))throw Error("Localisations concurrentes ambiguës");days.add(day);}
 return {version:1,entries:h.entries,archived:h.archived};
}
export function locationAt(metadata:unknown,date:string):LocationEntry|null {
 return locationHistory(metadata)?.entries.filter(e=>e.effectiveOn===null||e.effectiveOn<=date).sort((a,b)=>(b.effectiveOn??"").localeCompare(a.effectiveOn??""))[0]??null;
}
// Only applicable evidence enters a frozen report, never archives or receipts.
export function locationSnapshot(metadata:unknown,date:string){const e=locationAt(metadata,date);return e?{geographic_location:{version:1,entries:[e],archived:[]}}:{};}
