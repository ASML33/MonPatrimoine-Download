import type { NavigationSessionStore } from './session-store';

type Events = Pick<EventTarget, 'addEventListener' | 'removeEventListener'>;
type WindowEvents = Events & { setInterval(handler: () => void, ms: number): number; clearInterval(id: number): void };
type DocumentEvents = Events & { readonly visibilityState: string };

// Focus and the periodic check share the same lightweight, coalesced validation.
// Mutation/navigation boundaries still invalidate; authentication stays in the store.
export function bindNavigationFreshness(store: Pick<NavigationSessionStore, 'check' | 'expire' | 'invalidate'>, win: WindowEvents, doc: DocumentEvents) {
  const check = () => { if (doc.visibilityState === 'visible') void store.check(); };
  const invalidate = () => store.invalidate(false);
  win.addEventListener('focus', check);
  win.addEventListener('pageshow', check);
  doc.addEventListener('visibilitychange', check);
  win.addEventListener('popstate', invalidate);
  win.addEventListener('pagehide', invalidate);
  const timer = win.setInterval(() => { store.expire(); check(); }, 15000);
  return () => {
    win.clearInterval(timer);
    win.removeEventListener('focus', check);
    win.removeEventListener('pageshow', check);
    doc.removeEventListener('visibilitychange', check);
    win.removeEventListener('popstate', invalidate);
    win.removeEventListener('pagehide', invalidate);
  };
}
