import { contractsWithHistory, pointsForFixedContract, type PatrimonyChartData } from '@/lib/patrimony/chart-core';
import { historyPointsForSelection } from '@/lib/patrimony/history-window';

export type NavigationChartData = PatrimonyChartData & { navigationExcludedContractIds?: string[] };
export function navigationChartSelection(data: NavigationChartData, fixedId: string|null, initialScope: 'total'|'outside-real-estate'): PatrimonyChartData {
  const excluded=new Set(data.navigationExcludedContractIds??[]);
  const catalog=data.contracts.filter(c=>!excluded.has(c.id)||c.id===fixedId);
  const base=historyPointsForSelection(data.points,catalog.map(c=>`contract:${c.id}`).concat('employee-savings-combined'),data.contracts);
  const fixed=catalog.find(c=>c.id===fixedId)??null;
  const points=fixedId?historyPointsForSelection(pointsForFixedContract(base,fixed),[`contract:${fixedId}`,...(fixed?.sourceKey==='peg'||fixed?.sourceKey==='per_col'?['employee-savings-combined']:[])],data.contracts):base;
  const dates=new Set(points.map(p=>p.date));
  return {...data,contracts:contractsWithHistory(catalog,points,fixedId),points,initialScope,latestDate:points.at(-1)?.date??null,historyEvidence:data.historyEvidence?.filter(e=>dates.has(e.date))};
}
