import { AsyncLocalStorage } from 'node:async_hooks';

// One load only, never a cross-request/server cache. Large historical payloads
// are deliberately excluded. Mutations, Auth and version checks are never memoized.
type Scope = { responses: Map<string, Promise<Response>>; values: Map<string, Promise<unknown>> };
const scope = new AsyncLocalStorage<Scope>();
const tables = new Set(['contracts','positions','assets','cash_flows','cash_balances','position_snapshots','asset_prices','fx_rates','fiscal_rules','user_fiscal_regime_preferences','envelope_fiscalities','envelope_types','contract_manual_situations','contract_manual_simulations','effective_sectors','sector_activities','exposure_countries','geographic_regions','themes']);
const readRpcs = new Set(['effective_asset_exposures','effective_asset_theme_exposures']);

export async function withNavigationReadScope<T>(work: () => Promise<T>): Promise<T> {
  if (scope.getStore()) return work();
  const current: Scope = { responses: new Map(), values: new Map() };
  try { return await scope.run(current, work); }
  finally { current.responses.clear(); current.values.clear(); }
}

export function sharedNavigationRead<T>(key: string, read: () => Promise<T>): Promise<T> {
  const current = scope.getStore();
  if (!current) return read();
  const existing = current.values.get(key) as Promise<T> | undefined;
  if (existing) return existing;
  const pending = read().catch(error => { current.values.delete(key); throw error; });
  current.values.set(key, pending);
  return pending;
}

export function navigationReadFetch(transport: typeof fetch): typeof fetch {
  return async (input, init) => {
    const current = scope.getStore();
    if (!current || typeof input !== 'string' || init?.signal) return transport(input, init);
    const url = new URL(input), method = (init?.method ?? 'GET').toUpperCase();
    const name = url.pathname.split('/').at(-1)!;
    const eligible = (method === 'GET' && url.pathname.startsWith('/rest/v1/') && tables.has(name))
      || (method === 'POST' && url.pathname.includes('/rest/v1/rpc/') && readRpcs.has(name) && typeof init?.body === 'string');
    if (!eligible) return transport(input, init);
    const headers = [...new Headers(init?.headers)].sort(([a],[b]) => a.localeCompare(b));
    const key = JSON.stringify([method,input,headers,init?.body ?? null]);
    let pending = current.responses.get(key);
    if (!pending) {
      pending = transport(input, init).then(response => {
        if (!response.ok) current.responses.delete(key);
        return response;
      }).catch(error => { current.responses.delete(key); throw error; });
      current.responses.set(key, pending);
    }
    return (await pending).clone();
  };
}
