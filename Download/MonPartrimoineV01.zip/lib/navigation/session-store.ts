import type { PatrimonyChartData } from '@/lib/patrimony/chart-core';

export type NavigationStamp = { owner: string; session: string; revision: string; day: string; expiresAt: number; checkedAt: number };
export type NavigationIdentity = Pick<NavigationStamp,'owner'|'session'|'expiresAt'|'checkedAt'>;
export type NavigationReply = { stamp: NavigationStamp; data?: PatrimonyChartData; unchanged?: boolean; changed?: boolean };
export type NavigationTransport = (known: NavigationStamp | null, check: boolean, signal: AbortSignal) => Promise<NavigationReply>;
export class SupersededNavigation extends Error {}
export class ExpiredNavigation extends Error {}
export class ChangedNavigationIdentity extends Error {}
type Notice = 'invalidate'|'session-ended';
type Snapshot = { epoch: number; status: 'empty'|'loading'|'ready'|'error'; data: PatrimonyChartData|null; stamp: NavigationStamp|null; error: string|null };
const equal = (a: NavigationStamp,b: NavigationStamp) => a.owner===b.owner&&a.session===b.session&&a.day===b.day&&a.revision===b.revision;

// Exactly one shared model in RAM; no browser storage, per-route LRU or global server cache.
export class NavigationSessionStore {
  private state: Snapshot = { epoch:0,status:'empty',data:null,stamp:null,error:null };
  private cached: { data: PatrimonyChartData; stamp: NavigationStamp }|null = null;
  private pending: { owner:string; expected:string; controller:AbortController; promise:Promise<PatrimonyChartData> }|null = null;
  private checking: Promise<void>|null = null;
  private listeners = new Set<() => void>();
  private deadline = 0;
  private identity: NavigationIdentity|null = null;
  private watchedStamp: NavigationStamp|null = null;
  private ended = false;
  private transport: NavigationTransport;
  private now: () => number;
  private broadcast: (notice?:Notice, session?:string) => void;
  constructor(transport: NavigationTransport, now = () => Date.now(), broadcast: (notice?:Notice, session?:string) => void = () => {}) {
    this.transport=transport;this.now=now;this.broadcast=broadcast;
  }
  getSnapshot = () => this.state;
  subscribe = (listener: () => void) => { this.listeners.add(listener); return () => { this.listeners.delete(listener); }; };
  hasConsumers = () => this.listeners.size > 0;
  setBroadcaster(notify: (notice?:Notice, session?:string) => void) { this.broadcast=notify; }
  bindIdentity(identity: NavigationStamp|null) {
    const previous=this.identity??this.cached?.stamp;
    if(!identity||(previous&&(previous.owner!==identity.owner||previous.session!==identity.session)))this.clear(true);
    this.identity=identity;
    if(!identity)return;
    this.ended=false;
    if(this.watchedStamp&&identity.checkedAt<this.watchedStamp.checkedAt)return;
    if(this.watchedStamp&&!equal(this.watchedStamp,identity))this.invalidate(true,true);
    this.watchedStamp=identity;
  }
  private emit(patch: Partial<Snapshot>) { this.state={...this.state,...patch};this.listeners.forEach(listener=>listener()); }
  private valid(stamp: NavigationStamp,owner: string) {
    return stamp.owner===owner && /^[a-f0-9]{64}$/.test(stamp.session) && /^[a-f0-9]{64}$/.test(stamp.revision)
      && /^\d{4}-\d{2}-\d{2}$/.test(stamp.day) && Number.isFinite(stamp.checkedAt) && stamp.expiresAt>stamp.checkedAt;
  }
  invalidate(notify = false, discard = false) {
    this.pending?.controller.abort();this.pending=null;this.checking=null;
    if(discard){this.cached=null;this.deadline=0;}
    this.emit({epoch:this.state.epoch+1,status:'empty',data:null,stamp:null,error:null});
    if(notify)this.broadcast('invalidate');
  }
  clear = (notify=false) => { this.identity=null;this.watchedStamp=null;this.invalidate(notify,true); };
  endSession(notify=false, expectedSession?:string) {
    const session=this.identity?.session??this.watchedStamp?.session??this.cached?.stamp.session;
    // A delayed 401 from an old tab must not end a newly authenticated session.
    if(expectedSession&&session&&expectedSession!==session)return;
    this.ended=true;this.pending?.controller.abort();this.pending=null;this.checking=null;
    this.cached=null;this.watchedStamp=null;this.identity=null;this.deadline=0;
    this.emit({epoch:this.state.epoch+1,status:'error',data:null,stamp:null,error:'Session indisponible. Rechargez la page pour vous reconnecter.'});
    if(notify)this.broadcast(session?'session-ended':'invalidate',session);
  }
  expire() { if(this.cached && this.now()>=this.deadline)this.clear(true); }
  read(owner: string,expected: string): Promise<PatrimonyChartData> {
    if(this.ended)return Promise.reject(new ExpiredNavigation());
    if(this.watchedStamp?.owner===owner)expected=this.watchedStamp.session+':'+this.watchedStamp.revision;
    if(this.pending?.owner===owner&&this.pending.expected===expected)return this.pending.promise;
    if(this.pending || (this.cached&&this.cached.stamp.owner!==owner))this.invalidate(false,this.cached?.stamp.owner!==owner);
    const epoch=this.state.epoch, controller=new AbortController(), old=this.cached;
    this.emit({status:'loading',data:null,stamp:null,error:null});
    const promise=(async()=>{
      try {
        const reply=await Promise.resolve().then(()=>this.transport(old?.stamp??null,false,controller.signal));
        if(epoch!==this.state.epoch||controller.signal.aborted)throw new SupersededNavigation();
        if(reply.stamp.owner!==owner)throw new ChangedNavigationIdentity();
        if(!this.valid(reply.stamp,owner))throw new ExpiredNavigation();
        const data=reply.data??(reply.unchanged&&old&&equal(old.stamp,reply.stamp)?old.data:null);
        if(!data||!Array.isArray(data.points)||!Array.isArray(data.contracts))throw Error('Historique indisponible');
        this.deadline=this.now()+reply.stamp.expiresAt-reply.stamp.checkedAt;
        this.cached={data,stamp:reply.stamp};
        this.identity=reply.stamp;
        this.watchedStamp=reply.stamp;
        this.emit({status:'ready',data,stamp:reply.stamp,error:null});
        if(old&&!equal(old.stamp,reply.stamp))this.broadcast();
        return data;
      }catch(error){
        if(epoch!==this.state.epoch||controller.signal.aborted)throw new SupersededNavigation();
        this.cached=null;this.deadline=0;
        this.emit({status:'error',data:null,stamp:null,error:'Historique indisponible. Réessayez pour relire les données.'});
        if(error instanceof ExpiredNavigation)this.endSession(true);
        throw error;
      }finally{if(this.pending?.controller===controller)this.pending=null;}
    })();
    this.pending={owner,expected,controller,promise};
    return promise;
  }
  // Visible-tab checks use the same endpoint but never rebuild the history.
  check(): Promise<void> {
    this.expire();
    if(this.checking)return this.checking;
    if(this.pending||!this.watchedStamp||!this.hasConsumers())return Promise.resolve();
    const epoch=this.state.epoch,old=this.watchedStamp,controller=new AbortController();
    const checking=(async()=>{
      try{
        const reply=await Promise.resolve().then(()=>this.transport(old,true,controller.signal));
        if(epoch!==this.state.epoch)return;
        if(reply.stamp.owner!==old.owner)throw new ChangedNavigationIdentity();
        if(!this.valid(reply.stamp,old.owner))throw new ExpiredNavigation();
        this.watchedStamp=reply.stamp;
        if(!equal(old,reply.stamp)){this.invalidate(true,true);return;}
        this.deadline=this.now()+reply.stamp.expiresAt-reply.stamp.checkedAt;
        if(this.cached)this.cached={data:this.cached.data,stamp:reply.stamp};
        if(this.state.status==='error')this.invalidate();
      }catch(error){
        if(epoch!==this.state.epoch)return;
        if(error instanceof ExpiredNavigation){this.endSession(true);return;}
        if(error instanceof ChangedNavigationIdentity)this.clear();
        this.cached=null;this.deadline=0;
        this.emit({status:'error',data:null,stamp:null,error:'Vérification des données impossible. Réessayez.'});
      }
    })().finally(()=>{if(this.checking===checking)this.checking=null;});
    this.checking=checking;return checking;
  }
}
