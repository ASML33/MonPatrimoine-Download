import 'server-only';
import { cache } from 'react';
import { createHash } from 'node:crypto';
import { createClient } from '@/lib/supabase/server';
import { parisBusinessDate } from '@/lib/dates/business-date';
import type { NavigationIdentity, NavigationStamp } from './session-store';

export class NavigationAccessError extends Error {}

// The caller must already have passed the active-profile/authorized-user gate.
export async function readNavigationIdentity(owner: string): Promise<NavigationIdentity> {
  const client = await createClient();
  const { data: identity, error: identityError } = await client.auth.getClaims();
  const claims = identity?.claims;
  const checkedAt = Date.now();
  if (identityError || claims?.sub !== owner || typeof claims.session_id !== 'string'
    || typeof claims.exp !== 'number' || claims.exp * 1000 <= checkedAt) throw new NavigationAccessError('Session indisponible');
  return {owner,session:createHash('sha256').update(owner + ':' + claims.session_id).digest('hex'),expiresAt:claims.exp*1000,checkedAt};
}

export async function readNavigationStamp(owner: string): Promise<NavigationStamp> {
  const identity=await readNavigationIdentity(owner);
  const client=await createClient();
  const result = await client.rpc('patrimony_navigation_revision');
  if (result.error || typeof result.data !== 'string' || !/^[a-f0-9]{64}$/.test(result.data)) throw Error('Révision de navigation indisponible');
  const day = parisBusinessDate(new Date().toISOString());
  const revision = createHash('sha256').update(['navigation-v1',process.env.VERCEL_GIT_COMMIT_SHA ?? 'local',day,result.data].join(':')).digest('hex');
  if(identity.expiresAt<=Date.now())throw new NavigationAccessError('Session expirée');
  return {...identity,revision,day,checkedAt:Date.now()};
}

export const sameNavigationStamp = (a: NavigationStamp, b: NavigationStamp) =>
  a.owner === b.owner && a.session === b.session && a.revision === b.revision && a.day === b.day;

// React render-local only. The API intentionally uses the uncached reader twice.
export const getPageNavigationStamp = cache(readNavigationStamp);
