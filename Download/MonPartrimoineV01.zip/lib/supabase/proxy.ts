import { clearAuthCookiesAtScopes, createServerClient, type SetAllCookies } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

import {
  evaluateClaims,
  proxyAuthFailurePayload,
} from "@/lib/supabase/proxy-claims";
import { createAuthDiagnostics } from "@/lib/supabase/proxy-diagnostics";
import { getSupabasePublicConfig } from "@/lib/supabase/env";

const AUTH_UNAVAILABLE_PATH = "/auth/unavailable";

export async function updateSession(request: NextRequest) {
  // This public page reads no session or private data and must work during an
  // Auth outage. No other route bypasses the existing Proxy checks.
  if (request.nextUrl.pathname === AUTH_UNAVAILABLE_PATH) return NextResponse.next();

  const supabaseHeaders = new Headers();
  let supabaseResponse = NextResponse.next({
    request,
  });

  const setAll: SetAllCookies = (cookiesToSet, headers) => {
    cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
    const previousCookies = supabaseResponse.cookies.getAll();
    Object.entries(headers).forEach(([name, value]) => supabaseHeaders.set(name, value));
    supabaseResponse = NextResponse.next({ request });

    // Preserve earlier writes when Supabase calls setAll more than once.
    previousCookies.forEach((cookie) => supabaseResponse.cookies.set(cookie));
    cookiesToSet.forEach(({ name, value, options }) =>
      supabaseResponse.cookies.set(name, value, options),
    );
    supabaseHeaders.forEach((value, name) => supabaseResponse.headers.set(name, value));
  };

  const diagnostics = createAuthDiagnostics(fetch);

  function withSessionChanges(response: NextResponse) {
    supabaseResponse.cookies.getAll().forEach((cookie) =>
      response.cookies.set(cookie),
    );
    supabaseHeaders.forEach((value, name) =>
      response.headers.set(name, value),
    );
    response.headers.set("Cache-Control", "private, no-store");
    return response;
  }

  function unavailable(status: 500 | 503) {
    if (request.method === "GET" || request.method === "HEAD") {
      const destination = request.nextUrl.clone();
      destination.pathname = AUTH_UNAVAILABLE_PATH;
      destination.search = "";
      // NextResponse.rewrite also preserves Next's RSC navigation protocol.
      return withSessionChanges(NextResponse.rewrite(destination, { status }));
    }
    // Never replay a mutation or send HTML as a Server Action result.
    return withSessionChanges(NextResponse.json(proxyAuthFailurePayload(), { status }));
  }

  try {
    diagnostics.state.phase = "configuration";
    const { url, publishableKey } = getSupabasePublicConfig();
    // Explicitly keep the installed SDK's default project-scoped cookie key.
    const storageKey = `sb-${new URL(url).hostname.split(".")[0]}-auth-token`;
    const supabase = createServerClient(url, publishableKey, {
      auth: { storageKey },
      global: { fetch: diagnostics.fetch },
      cookies: { getAll: () => request.cookies.getAll(), setAll },
    });
    diagnostics.state.phase = "claims";
    let evaluation = await evaluateClaims(() => supabase.auth.getClaims());
    const diagnostic = diagnostics.snapshot();

    // A failure fetching verification keys is not evidence of a dead session.
    if (evaluation.outcome === "invalid_session" && diagnostic.phase === "jwks" && diagnostic.transport !== "none") {
      evaluation = { outcome: "internal_error", errorType: "auth_api" };
    }
    if (evaluation.outcome === "internal_error" && (diagnostic.transport === "network" || diagnostic.transport === "timeout")) {
      evaluation = { outcome: "transient_error", errorType: "retryable_fetch" };
    }
    if (evaluation.outcome === "success" || evaluation.outcome === "missing_session") {
      if (evaluation.errorType === "missing_session" && diagnostic.transport === "http") diagnostics.report(evaluation);
      return supabaseResponse;
    }

    diagnostics.report(evaluation);
    if (evaluation.outcome === "invalid_session") {
      // Expire only this browser's session cookies, including chunks. No
      // signOut/refresh request, global revocation, or deletion of PKCE state.
      for (const key of [storageKey, `${storageKey}-user`]) {
        await clearAuthCookiesAtScopes({
          storageKey: key,
          scopes: [{ path: "/" }],
          getAll: () => request.cookies.getAll(),
          setAll,
        });
      }
      const login = request.nextUrl.clone();
      login.pathname = "/login";
      login.search = "";
      return withSessionChanges(NextResponse.redirect(login, 303));
    }
    return unavailable(evaluation.outcome === "transient_error" ? 503 : 500);
  } catch {
    diagnostics.report({ outcome: "internal_error", errorType: "unexpected" });
    return unavailable(500);
  }
}
