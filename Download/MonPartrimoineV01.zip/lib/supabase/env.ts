export type SupabasePublicConfigInput = {
  url: string | undefined;
  publishableKey: string | undefined;
};

export type SupabasePublicConfig = {
  url: string;
  publishableKey: string;
};

type SupabaseConfigurationErrorCode =
  | "missing_url"
  | "invalid_url"
  | "invalid_protocol"
  | "missing_publishable_key";

const errorMessages: Record<SupabaseConfigurationErrorCode, string> = {
  missing_url: "Supabase public URL is missing.",
  invalid_url: "Supabase public URL is invalid.",
  invalid_protocol: "Supabase public URL protocol is invalid.",
  missing_publishable_key: "Supabase publishable key is missing.",
};

export class SupabaseConfigurationError extends Error {
  readonly code: SupabaseConfigurationErrorCode;

  constructor(code: SupabaseConfigurationErrorCode) {
    super(errorMessages[code]);
    this.name = "SupabaseConfigurationError";
    this.code = code;
  }
}

export function validateSupabasePublicConfig(
  input: SupabasePublicConfigInput,
): SupabasePublicConfig {
  const url = input.url?.trim();
  if (!url) {
    throw new SupabaseConfigurationError("missing_url");
  }

  let parsedUrl: URL;
  try {
    parsedUrl = new URL(url);
  } catch {
    throw new SupabaseConfigurationError("invalid_url");
  }

  if (parsedUrl.protocol !== "http:" && parsedUrl.protocol !== "https:") {
    throw new SupabaseConfigurationError("invalid_protocol");
  }

  const publishableKey = input.publishableKey?.trim();
  if (!publishableKey) {
    throw new SupabaseConfigurationError("missing_publishable_key");
  }

  return { url, publishableKey };
}

export function getSupabasePublicConfig(): SupabasePublicConfig {
  return validateSupabasePublicConfig({
    url: process.env.NEXT_PUBLIC_SUPABASE_URL,
    publishableKey: process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY,
  });
}
