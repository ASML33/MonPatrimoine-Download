import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

import { getSupabasePublicConfig } from "@/lib/supabase/env";
import { navigationReadFetch } from "@/lib/navigation/read-scope";

export async function createClient() {
  const cookieStore = await cookies();
  const { url, publishableKey } = getSupabasePublicConfig();

  return createServerClient(
    url,
    publishableKey,
    {
      global: { fetch: navigationReadFetch(fetch) },
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options),
            );
          } catch {
            // Server Components cannot write cookies during rendering.
            // Session refresh will be handled by the future proxy.
          }
        },
      },
    },
  );
}
