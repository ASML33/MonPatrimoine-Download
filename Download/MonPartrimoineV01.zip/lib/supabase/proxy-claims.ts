import {
  isAuthError,
  isAuthRetryableFetchError,
  isAuthSessionMissingError,
} from "@supabase/supabase-js";

type ClaimsResult = {
  data: unknown;
  error: unknown;
};

export type ClaimsOutcome =
  | "success"
  | "missing_session"
  | "invalid_session"
  | "transient_error"
  | "internal_error";

export type ClaimsEvaluation = {
  outcome: ClaimsOutcome;
  errorType?: "missing_session" | "invalid_session" | "retryable_fetch" | "timeout" | "auth_api" | "unexpected";
};

export const invalidSessionCodes: ReadonlySet<string> = new Set([
  "invalid_jwt", "bad_jwt", "session_not_found", "session_expired",
  "refresh_token_not_found", "refresh_token_already_used", "user_not_found", "user_banned",
]);

export function classifyClaimsError(error: unknown): ClaimsEvaluation {
  if (isAuthSessionMissingError(error)) return { outcome: "missing_session", errorType: "missing_session" };
  if (isAuthRetryableFetchError(error)) return { outcome: "transient_error", errorType: "retryable_fetch" };
  if (isAuthError(error)) {
    if (error.code && invalidSessionCodes.has(error.code) && error.status && error.status >= 400 && error.status < 500) {
      return { outcome: "invalid_session", errorType: "invalid_session" };
    }
    if (error.code === "request_timeout" || error.status === 429 || (error.status && error.status >= 500 && error.status <= 599)) {
      return { outcome: "transient_error", errorType: "auth_api" };
    }
    return { outcome: "internal_error", errorType: "auth_api" };
  }
  if (error instanceof Error && (error.name === "TimeoutError" || error.name === "AbortError")) {
    return { outcome: "transient_error", errorType: "timeout" };
  }
  return { outcome: "internal_error", errorType: "unexpected" };
}

export async function evaluateClaims(
  readClaims: () => Promise<ClaimsResult>,
): Promise<ClaimsEvaluation> {
  try {
    const { data, error } = await readClaims();

    if (error) return classifyClaimsError(error);
    if (data === null) return { outcome: "missing_session" };
    // getClaims must return verified claims, never merely a stored session.
    if (typeof data === "object" && data && "claims" in data) {
      const claims = data.claims;
      if (typeof claims === "object" && claims && "sub" in claims && typeof claims.sub === "string" && claims.sub) {
        return { outcome: "success" };
      }
    }
    return { outcome: "internal_error", errorType: "unexpected" };
  } catch (error) {
    return classifyClaimsError(error);
  }
}

export function proxyAuthFailurePayload() {
  return { error: "La connexion est indisponible. Réessayez dans quelques instants." };
}
