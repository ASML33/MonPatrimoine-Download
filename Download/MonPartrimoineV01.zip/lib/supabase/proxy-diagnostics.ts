import { invalidSessionCodes, type ClaimsEvaluation } from "@/lib/supabase/proxy-claims";

type AuthPhase = "claims" | "refresh" | "jwks" | "user" | "configuration";
type TransportFailure = "none" | "network" | "timeout" | "http";

export function createAuthDiagnostics(fetcher: typeof fetch) {
  const state: { phase: AuthPhase; transport: TransportFailure; httpStatus?: number } = {
    phase: "claims", transport: "none",
  };
  const observedFetch: typeof fetch = async (input, init) => {
    const url = new URL(input instanceof Request ? input.url : input);
    state.phase = url.pathname.endsWith("/.well-known/jwks.json") ? "jwks"
      : url.pathname.endsWith("/token") && url.searchParams.get("grant_type") === "refresh_token" ? "refresh"
      : url.pathname.endsWith("/user") ? "user" : "claims";
    state.transport = "none";
    delete state.httpStatus;
    try {
      const response = await fetcher(input, init);
      state.httpStatus = response.status;
      if (!response.ok) {
        state.transport = "http";
        // The SDK can warn with the whole refresh error. Keep the codes it
        // needs, but never let an upstream message enter those logs.
        const body = await response.json().catch(() => null);
        const candidate = body?.code ?? body?.error_code;
        const code = typeof candidate === "string" && (invalidSessionCodes.has(candidate) || candidate === "request_timeout")
          ? candidate : "unexpected_failure";
        return Response.json({ code, message: "Authentication request failed." }, {
          status: response.status,
          headers: { "X-Supabase-Api-Version": "2024-01-01" },
        });
      }
      return response;
    } catch (error) {
      state.transport = error instanceof Error && (error.name === "TimeoutError" || error.name === "AbortError") ? "timeout" : "network";
      // The SDK may also log a failed refresh's network error. Do not retain
      // the original message/cause, which can contain a URL or credentials.
      if (state.transport === "timeout") throw new DOMException("Authentication request timed out.", "TimeoutError");
      throw new TypeError("Authentication network request failed.");
    }
  };
  return {
    fetch: observedFetch,
    state,
    snapshot: () => ({ ...state }),
    report(evaluation: ClaimsEvaluation) {
      // Only fixed categories and numeric status: never error.name/message,
      // URLs, request headers, cookie values or provider response bodies.
      console.warn("auth_proxy_failure", {
        category: evaluation.outcome,
        errorType: evaluation.errorType ?? "unexpected",
        phase: state.phase,
        transport: state.transport,
        ...(state.httpStatus ? { httpStatus: state.httpStatus } : {}),
        timestamp: new Date().toISOString(),
      });
    },
  };
}
