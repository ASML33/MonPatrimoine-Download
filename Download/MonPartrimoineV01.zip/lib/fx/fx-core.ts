export type FxRateRecord = {
  id?: string;
  currency_code: string;
  requested_on: string;
  observed_on: string;
  eur_per_unit: number | string;
  source: "ecb" | "frankfurter" | "manual";
  obtained_at?: string;
};

export type FxConversion = {
  amountEur: number | null;
  rate: FxRateRecord | null;
};

export function latestFxRatesByCurrency(rates: FxRateRecord[], asOf: string) {
  const latest = new Map<string, FxRateRecord>();
  for (const rate of rates) {
    if (rate.requested_on > asOf || rate.observed_on > asOf || !Number.isFinite(Number(rate.eur_per_unit)) || Number(rate.eur_per_unit) <= 0) continue;
    const existing = latest.get(rate.currency_code);
    if (!existing || rate.requested_on > existing.requested_on
        || (rate.requested_on === existing.requested_on && (rate.obtained_at ?? "") > (existing.obtained_at ?? ""))) {
      latest.set(rate.currency_code, rate);
    }
  }
  return latest;
}

export function convertToEur(amount: number | string, currencyCode: string, rate?: FxRateRecord | null): FxConversion {
  const nativeAmount = Number(amount);
  if (!Number.isFinite(nativeAmount)) return { amountEur: null, rate: null };
  if (nativeAmount === 0) return { amountEur: 0, rate: currencyCode === "EUR" ? null : rate ?? null };
  if (currencyCode === "EUR") return { amountEur: nativeAmount, rate: null };
  if (!rate || rate.currency_code !== currencyCode || !Number.isFinite(Number(rate.eur_per_unit)) || Number(rate.eur_per_unit) <= 0) return { amountEur: null, rate: null };
  const value = nativeAmount * Number(rate.eur_per_unit);
  return Number.isFinite(value) ? { amountEur: value, rate } : { amountEur: null, rate: null };
}
