import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";
import { parseEcbRateCsv, ecbCsvRow } from "./ecb-provider";

// One provider, one HTTP call per slot. The ordinary two-provider resolver is
// deliberately not nested here. Its shared quota/backoff ledger is honored SQL-side.
export const CTO_FX_ATTEMPT_MS = 2_500;
export const CTO_FX_TOTAL_MS = 14_000;
type Client = { rpc(name: string, args: Record<string, unknown>): PromiseLike<{data: unknown; error: {message?: string;code?:string} | null}> };
type Preparation = { state: "preparing" | "ready" | "committed"; claim?: string | null; currency: string; date: string; result?: string; fx?: {method?: string} };
export async function prepareAcquisitionFx(client: Client, owner: string, params: Record<string, unknown>): Promise<Preparation> {
  const until = Date.now() + CTO_FX_TOTAL_MS;
  const prepare = async () => {
    const result = await client.rpc("prepare_cto_acquisition_action", params);
    if (result.error) throw Error(result.error.code==="40001"?"La position ou cette demande a changé. Rechargez sans sauvegarde partielle.":"Enregistrement refusé : vérifiez la date, la quantité, le montant, la devise et vos droits. Le brouillon est conservé.");
    return result.data as Preparation;
  };
  let prepared = await prepare();
  while (prepared.state === "preparing" && !prepared.claim && Date.now() < until) {
    await new Promise(resolve => setTimeout(resolve, 150));
    prepared = await prepare();
  }
  if (prepared.state !== "preparing") return prepared;
  if (!prepared.claim) throw Error("Une saisie identique est encore en cours. Le brouillon est conservé.");
  const admin = createAdminClient();
  const work = async (operation: string, details: Record<string, unknown> = {}) => {
    const result = await admin.rpc("cto_acquisition_fx_worker", {requested_owner: owner, requested_request: params.requested_request, requested_claim: prepared.claim, operation, details}).abortSignal(AbortSignal.timeout(Math.max(1, until-Date.now())));
    if (result.error) throw Error("Préparation du change interrompue. Réessayez avec le même brouillon.");
    return result.data as {allowed?: boolean; attempt?: number; fx?: Preparation["fx"]};
  };
  for (let slot = 0; slot < 3; slot++) {
    const taken = await work("take");
    if (!taken.allowed) break;
    const controller = new AbortController();
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      const timeout = new Promise<never>((_, reject) => { timer = setTimeout(() => {controller.abort(); reject(Error("timeout"));}, Math.min(CTO_FX_ATTEMPT_MS, Math.max(1,until-Date.now()-1000))); });
      const request = async () => {
        const series = `D.${prepared.currency}.EUR.SP00.A`;
        const response = await fetch(`https://data-api.ecb.europa.eu/service/data/EXR/${series}?endPeriod=${prepared.date}&lastNObservations=1&format=csvdata`, {headers:{Accept:"text/csv"}, signal:controller.signal, cache:"no-store", redirect:"error"});
        if (!response.ok || response.status===204) {
          const retry = response.headers.get("retry-after");
          const seconds = retry && /^\d+$/.test(retry) ? Number(retry) : retry ? Math.max(0,(Date.parse(retry)-Date.now())/1000) : 3600;
          return {error: response.status===429?"quota_exceeded":response.status===404||response.status===204?"not_covered":"temporary_failure", retrySeconds:Number.isFinite(seconds)?seconds:3600} as const;
        }
        const text = await response.text(), row = ecbCsvRow(text);
        const quote = parseEcbRateCsv(text,prepared.currency,prepared.date);
        if (quote.status!=="success" || !row || row.FREQ!=="D" || row.UNIT_MULT!=="0" || ![series,`EXR.${series}`].includes(row.KEY) || !Number.isFinite(Number(row.OBS_VALUE)) || Number(row.OBS_VALUE)<=0) return {error:"invalid_response"} as const;
        return {quote} as const;
      };
      const result = await Promise.race([request(),timeout]);
      if ("error" in result) await work("failure",{code:result.error,retrySeconds:"retrySeconds" in result?result.retrySeconds:undefined});
      else {
        const q=result.quote;
        const saved = await admin.rpc("record_automatic_fx_rate", {requested_currency:q.currencyCode, requested_date:q.requestedOn, requested_observed_on:q.observedOn, requested_eur_per_unit:q.eurPerUnit, requested_source:q.source, requested_metadata:{...q.metadata,base:q.currencyCode,quote:"EUR",direction:"EUR_per_native_unit",unitMultiplier:"0"}}).abortSignal(AbortSignal.timeout(Math.max(1,until-Date.now())));
        if (saved.error || !saved.data) throw Error("FX_STORAGE");
        const done=await work("finish",{rateId:saved.data});
        return {...prepared,state:"ready",fx:done.fx};
      }
    } catch (error) {
      await work("failure",{code:error instanceof Error && error.message==="timeout"?"timeout":"temporary_failure"});
    } finally { if(timer)clearTimeout(timer); }
    if (slot<2) await new Promise(resolve => setTimeout(resolve,slot===0?150:300));
  }
  const done=await work("finish");
  return {...prepared,state:"ready",fx:done.fx};
}
