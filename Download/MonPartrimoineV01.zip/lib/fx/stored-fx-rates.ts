import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { FxRateRecord } from "@/lib/fx/fx-core";

// Persisted reference observations only: this reader never contacts a provider.
export async function readStoredFxRates(client: SupabaseClient, currencies: readonly string[], until: string) {
  const codes = [...new Set(currencies.filter(code => code !== "EUR"))];
  if (!codes.length) return [] as FxRateRecord[];
  const result: FxRateRecord[] = [];
  const size = 500;
  for (let offset = 0; ; offset += size) {
    const rows = await client.from("fx_rates").select("id,currency_code,requested_on,observed_on,eur_per_unit,source,obtained_at")
      .in("currency_code", codes).lte("requested_on", until).order("requested_on", { ascending: false }).order("obtained_at", { ascending: false }).order("id").range(offset, offset + size - 1);
    if (rows.error) throw new Error("Change enregistré indisponible");
    result.push(...(rows.data ?? []) as FxRateRecord[]);
    if ((rows.data?.length ?? 0) < size) break;
  }
  return result;
}
