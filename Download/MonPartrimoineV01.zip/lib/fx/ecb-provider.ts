import "server-only";

import { decimalRate, type FxProvider, type FxRateResult } from "./fx-provider";

type Fetcher = typeof fetch;

function csvFields(line: string) {
  const fields: string[] = [];
  let current = "";
  let quoted = false;
  for (let index = 0; index < line.length; index += 1) {
    const character = line[index];
    if (character === '"') {
      if (quoted && line[index + 1] === '"') { current += '"'; index += 1; }
      else quoted = !quoted;
    } else if (character === "," && !quoted) {
      fields.push(current);
      current = "";
    } else current += character;
  }
  fields.push(current);
  return fields;
}

export function ecbCsvRow(csv: string): Record<string,string> | null {
  const lines = csv.trim().split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return null;
  const headers = csvFields(lines[0]);
  const values = csvFields(lines.at(-1)!);
  const row = Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""]));
  return row;
}

export function parseEcbRateCsv(csv: string, currencyCode: string, requestedOn: string): FxRateResult {
  const row=ecbCsvRow(csv);
  if(!row)return {status:"error",code:"not_covered"};
  const unitsPerEuro = Number(row.OBS_VALUE);
  const eurPerUnit = decimalRate(1 / unitsPerEuro);
  if (row.CURRENCY !== currencyCode || row.CURRENCY_DENOM !== "EUR" || !eurPerUnit
      || !/^\d{4}-\d{2}-\d{2}$/.test(row.TIME_PERIOD) || row.TIME_PERIOD > requestedOn) {
    return { status: "error", code: "invalid_response" };
  }
  return {
    status: "success",
    currencyCode,
    requestedOn,
    observedOn: row.TIME_PERIOD,
    eurPerUnit,
    source: "ecb",
    metadata: { seriesKey: row.KEY },
  };
}

export function createEcbFxProvider(fetcher: Fetcher = fetch): FxProvider {
  return {
    source: "ecb",
    async getRate({ currencyCode, requestedOn }) {
      const series = `D.${currencyCode}.EUR.SP00.A`;
      const url = `https://data-api.ecb.europa.eu/service/data/EXR/${series}?endPeriod=${requestedOn}&lastNObservations=1&format=csvdata`;
      try {
        const response = await fetcher(url, { headers: { Accept: "text/csv" }, signal: AbortSignal.timeout(8_000), cache: "no-store" });
        if (response.status === 404 || response.status === 204) return { status: "error", code: "not_covered" };
        if (response.status === 429) return { status: "error", code: "quota_exceeded" };
        if (!response.ok) return { status: "error", code: "temporary_failure" };
        return parseEcbRateCsv(await response.text(), currencyCode, requestedOn);
      } catch {
        return { status: "error", code: "temporary_failure" };
      }
    },
  };
}
