export type FxRateRequest = {
  currencyCode: string;
  requestedOn: string;
};

export type FxRateQuote = {
  status: "success";
  currencyCode: string;
  requestedOn: string;
  observedOn: string;
  eurPerUnit: string;
  source: "ecb" | "frankfurter";
  metadata: Record<string, unknown>;
};

export type FxRateFailure = {
  status: "error";
  code: "not_covered" | "temporary_failure" | "quota_exceeded" | "invalid_response";
};

export type FxRateResult = FxRateQuote | FxRateFailure;

export interface FxProvider {
  readonly source: "ecb" | "frankfurter";
  getRate(request: FxRateRequest): Promise<FxRateResult>;
}

export type FxProviderAttempt = { source: FxProvider["source"]; result: FxRateResult };
export type FxProviderChainResult =
  | { status: "resolved"; quote: FxRateQuote; attempts: FxProviderAttempt[] }
  | { status: "pending" | "manual_required"; attempts: FxProviderAttempt[] };

export async function requestFxRateFromProviders(providers: FxProvider[], request: FxRateRequest): Promise<FxProviderChainResult> {
  const attempts: FxProviderAttempt[] = [];
  let temporaryFailure = false;
  for (const provider of providers) {
    let result: FxRateResult;
    try { result = await provider.getRate(request); }
    catch { result = { status: "error", code: "temporary_failure" }; }
    if (result.status === "success" && !isUsableFxQuote(result, request)) result = { status: "error", code: "invalid_response" };
    attempts.push({ source: provider.source, result });
    if (result.status === "success") return { status: "resolved", quote: result, attempts };
    temporaryFailure ||= result.code !== "not_covered";
  }
  return { status: temporaryFailure ? "pending" : "manual_required", attempts };
}

export function decimalRate(value: number) {
  if (!Number.isFinite(value) || value <= 0) return null;
  return value.toFixed(12).replace(/0+$/, "").replace(/\.$/, "");
}

export function isUsableFxQuote(result: FxRateResult, request: FxRateRequest): result is FxRateQuote {
  return result.status === "success"
    && result.currencyCode === request.currencyCode
    && result.requestedOn === request.requestedOn
    && /^\d{1,16}(?:\.\d{1,12})?$/.test(result.eurPerUnit)
    && Number(result.eurPerUnit) > 0
    && /^\d{4}-\d{2}-\d{2}$/.test(result.observedOn)
    && result.observedOn <= request.requestedOn;
}
