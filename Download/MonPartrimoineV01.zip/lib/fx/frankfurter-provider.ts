import "server-only";

import { decimalRate, type FxProvider, type FxRateResult } from "./fx-provider";

type Fetcher = typeof fetch;
type ProviderRow = { key?: unknown; date?: unknown; excluded?: unknown };

export function parseFrankfurterRate(payload: unknown, currencyCode: string, requestedOn: string): FxRateResult {
  if (!payload || typeof payload !== "object") return { status: "error", code: "invalid_response" };
  const row = payload as { base?: unknown; quote?: unknown; rate?: unknown; date?: unknown; providers?: unknown };
  const rate = decimalRate(Number(row.rate));
  if (row.base !== currencyCode || row.quote !== "EUR" || !rate || !Array.isArray(row.providers)) {
    return { status: "error", code: "invalid_response" };
  }
  const contributors = (row.providers as ProviderRow[]).filter((provider) => provider.excluded !== true
    && typeof provider.key === "string" && typeof provider.date === "string" && provider.date <= requestedOn);
  const observedOn = contributors.map((provider) => String(provider.date)).sort().at(-1);
  if (!observedOn || !/^\d{4}-\d{2}-\d{2}$/.test(observedOn)) return { status: "error", code: "invalid_response" };
  return {
    status: "success",
    currencyCode,
    requestedOn,
    observedOn,
    eurPerUnit: rate,
    source: "frankfurter",
    metadata: { contributors: [...new Set(contributors.map((provider) => String(provider.key)))].sort() },
  };
}

export function createFrankfurterFxProvider(fetcher: Fetcher = fetch): FxProvider {
  return {
    source: "frankfurter",
    async getRate({ currencyCode, requestedOn }) {
      const url = `https://api.frankfurter.dev/v2/rate/${currencyCode.toLowerCase()}/eur?date=${requestedOn}&expand=providers`;
      try {
        const response = await fetcher(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(8_000), cache: "no-store" });
        if (response.status === 404 || response.status === 422) return { status: "error", code: "not_covered" };
        if (response.status === 429) return { status: "error", code: "quota_exceeded" };
        if (!response.ok) return { status: "error", code: "temporary_failure" };
        return parseFrankfurterRate(await response.json(), currencyCode, requestedOn);
      } catch {
        return { status: "error", code: "temporary_failure" };
      }
    },
  };
}
