import "server-only";

import { createAdminClient } from "@/lib/supabase/admin";
import { createEcbFxProvider } from "./ecb-provider";
import { createFrankfurterFxProvider } from "./frankfurter-provider";
import { requestFxRateFromProviders, type FxProvider, type FxRateQuote } from "./fx-provider";

type AdminClient = ReturnType<typeof createAdminClient>;
type CachedRate = { id: string; currency_code: string; requested_on: string; observed_on: string; eur_per_unit: string; source: "ecb" | "frankfurter" | "manual"; provider_metadata: Record<string, unknown>; obtained_at: string };
type Attempt = { provider: "ecb" | "frankfurter"; status: "unsupported" | "temporary_failure"; failure_count: number; retry_after: string };

export type FxResolution =
  | { status: "resolved"; rateId: string | null; currencyCode: string; requestedOn: string; observedOn: string; eurPerUnit: string; source: "identity" | "ecb" | "frankfurter" | "manual" }
  | { status: "pending" | "manual_required"; currencyCode: string; requestedOn: string };

function fromCached(rate: CachedRate): FxResolution {
  return { status: "resolved", rateId: rate.id, currencyCode: rate.currency_code, requestedOn: rate.requested_on, observedOn: rate.observed_on, eurPerUnit: String(rate.eur_per_unit), source: rate.source };
}

function retryAfter(status: Attempt["status"], failureCount: number) {
  const milliseconds = status === "unsupported" ? 30 * 86_400_000 : Math.min(3_600_000, 60_000 * 2 ** Math.min(failureCount, 5));
  return new Date(Date.now() + milliseconds).toISOString();
}

async function recordQuote(admin: AdminClient, quote: FxRateQuote) {
  const saved = await admin.rpc("record_automatic_fx_rate", {
    requested_currency: quote.currencyCode,
    requested_date: quote.requestedOn,
    requested_observed_on: quote.observedOn,
    requested_eur_per_unit: quote.eurPerUnit,
    requested_source: quote.source,
    requested_metadata: quote.metadata,
  });
  if (saved.error || typeof saved.data !== "string") throw new Error("FX_RATE_SAVE_FAILED");
  return saved.data;
}

export async function resolveFxRate(
  currencyCode: string,
  requestedOn: string,
  options: { admin?: AdminClient; providers?: FxProvider[] } = {},
): Promise<FxResolution> {
  if (currencyCode === "EUR") return { status: "resolved", rateId: null, currencyCode, requestedOn, observedOn: requestedOn, eurPerUnit: "1", source: "identity" };
  const admin = options.admin ?? createAdminClient();
  const cached = await admin.from("fx_rates").select("id,currency_code,requested_on,observed_on,eur_per_unit,source,provider_metadata,obtained_at")
    .eq("currency_code", currencyCode).eq("requested_on", requestedOn).order("source").order("obtained_at", { ascending: false });
  if (cached.error) throw new Error("FX_RATE_CACHE_UNAVAILABLE");
  const cachedRates = (cached.data ?? []) as CachedRate[];
  const cachedAutomatic = cachedRates.find((rate) => rate.source !== "manual");
  if (cachedAutomatic) return fromCached(cachedAutomatic);
  const cachedManual = cachedRates.find((rate) => rate.source === "manual");
  if (cachedManual) return fromCached(cachedManual);

  const attemptsResult = await admin.from("fx_provider_attempts").select("provider,status,failure_count,retry_after")
    .eq("currency_code", currencyCode).eq("requested_on", requestedOn);
  if (attemptsResult.error) throw new Error("FX_RATE_CACHE_UNAVAILABLE");
  const attempts = new Map(((attemptsResult.data ?? []) as Attempt[]).map((attempt) => [attempt.provider, attempt]));
  const providers = options.providers ?? [createEcbFxProvider(), createFrankfurterFxProvider()];
  let cachedTemporaryFailure = false;
  const eligibleProviders: FxProvider[] = [];
  for (const provider of providers) {
    const previous = attempts.get(provider.source);
    if (previous && Date.parse(previous.retry_after) > Date.now()) {
      cachedTemporaryFailure ||= previous.status === "temporary_failure";
      continue;
    }
    eligibleProviders.push(provider);
  }
  const chain = await requestFxRateFromProviders(eligibleProviders, { currencyCode, requestedOn });
  for (const attempt of chain.attempts) {
    if (attempt.result.status === "success") continue;
    const previous = attempts.get(attempt.source);
    const status: Attempt["status"] = attempt.result.code === "not_covered" ? "unsupported" : "temporary_failure";
    const failureCount = Math.min(100, (previous?.failure_count ?? 0) + 1);
    await admin.from("fx_provider_attempts").upsert({ currency_code: currencyCode, requested_on: requestedOn, provider: attempt.source, status, failure_count: failureCount, retry_after: retryAfter(status, failureCount), updated_at: new Date().toISOString() }, { onConflict: "currency_code,requested_on,provider" });
  }
  if (chain.status === "resolved") {
    const rateId = await recordQuote(admin, chain.quote);
    await admin.from("fx_provider_attempts").delete().eq("currency_code", currencyCode).eq("requested_on", requestedOn).eq("provider", chain.quote.source);
    return { status: "resolved", rateId, currencyCode, requestedOn, observedOn: chain.quote.observedOn, eurPerUnit: chain.quote.eurPerUnit, source: chain.quote.source };
  }
  if (!cachedTemporaryFailure && chain.status === "manual_required"
      && (eligibleProviders.length > 0 || providers.every((provider) => attempts.get(provider.source)?.status === "unsupported"))) {
    return { status: "manual_required", currencyCode, requestedOn };
  }
  return { status: "pending", currencyCode, requestedOn };
}
