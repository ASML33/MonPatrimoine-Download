import { percentage, reportContractGross, type PatrimonialReport } from '@/lib/reports/patrimonial-report-core';

// A holding proves ownership, never the intended scope of an old allocation target.
// Explicit persisted scope is required for a comparison; legacy targets stay unassigned.
export function assetObjectiveComparison(report: PatrimonialReport, assetId: string, contractId: string, target: { percent: number; scopeContractId?: string | null } | null) {
  const contract = report.contracts.find(c=>c.id===contractId);
  const holdings = report.assets.find(a=>a.id===assetId)?.holdings.filter(h=>h.contractId===contractId) ?? [];
  const value = holdings.length && holdings.every(h=>h.valueEur!==null) ? holdings.reduce((s,h)=>s+h.valueEur!,0) : null;
  const gross = contract ? reportContractGross(contract) : null;
  const denominator = contract && !contract.incompletePositions && !contract.incompleteCashBalances ? gross : null;
  const currentPercent = value!==null && denominator!==null ? percentage(value,denominator) : null;
  const reason = !target ? 'target_missing' : target.percent===-1 ? 'excluded' : !target.scopeContractId ? 'scope_missing' : target.scopeContractId!==contractId ? 'different_scope' : !contract ? 'scope_outside_selection' : !holdings.length ? 'holding_missing' : denominator===0 ? 'zero_denominator' : currentPercent===null ? 'valuation_unknown' : null;
  return { valueEur:value, denominatorEur:denominator, currentPercent, targetPercent:target?.percent ?? null, deltaPoints:reason===null ? currentPercent!-target!.percent : null, reason };
}
