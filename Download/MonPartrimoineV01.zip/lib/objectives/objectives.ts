import { isContractInUserScope, visibleContracts } from "@/lib/contracts/contract-scope";
import "server-only";
import {getCurrentReportSnapshot} from '@/lib/reports/patrimonial-report';
import {configuredReport,reportContractIds} from '@/lib/reports/report-configuration';
import {assetObjectiveComparison} from './asset-objective-core';
import type {AssetObjectiveScope} from './objective-core';
import { createClient } from "@/lib/supabase/server";
import { contractObjectiveOptions, type ObjectiveDimension, type ObjectiveKind, type ObjectiveValue } from "./objective-core";

type AllocationRow = {
  target_kind: ObjectiveKind;
  scope_contract_id: string | null;
  target_envelope_type_id: string | null;
  target_contract_id: string | null;
  target_asset_id: string | null;
  target_percent: number | string;
};

function targetId(row: AllocationRow) {
  return row.target_envelope_type_id ?? row.target_contract_id ?? row.target_asset_id;
}

export async function getObjectives(userId: string) {
  const supabase = await createClient();
  const [allocations, envelopeTypes, contracts, assets, positions, revision, snapshot] = await Promise.all([
    supabase.from("target_allocations")
      .select("target_kind,target_envelope_type_id,target_contract_id,target_asset_id,target_percent,scope_contract_id")
      .eq("user_id", userId),
    supabase.from("envelope_types").select("id,label,is_active").order("label"),
    supabase.from("contracts").select("id,name,is_active,show_on_dashboard,metadata").eq("user_id", userId).order("name"),
    supabase.from("assets").select("id,name,symbol,is_active").eq("owner_user_id", userId).order("name"),
    supabase.from("positions").select("contract_id,asset_id,is_active").eq("user_id", userId).eq("is_active", true),
    supabase.rpc("get_target_allocation_revision"),
    getCurrentReportSnapshot().catch(()=>null),
  ]);
  if (allocations.error || envelopeTypes.error || contracts.error || assets.error || positions.error || revision.error) throw new Error("Objectives unavailable");
  const rows = ((allocations.data ?? []) as AllocationRow[]).filter((row) => (!row.target_contract_id || isContractInUserScope(row.target_contract_id)) && (!row.scope_contract_id || isContractInUserScope(row.scope_contract_id)));
  const selected = new Set(rows.flatMap((row) => targetId(row) ?? []));
  const values = (kind: ObjectiveKind): ObjectiveValue[] => rows.filter((row) => row.target_kind === kind && !row.scope_contract_id).flatMap((row) => {
    const id = targetId(row);
    return id ? [{ targetId: id, targetPercent: Number(row.target_percent) }] : [];
  });
  const dimension = (kind: ObjectiveKind, label: string, options: ObjectiveDimension["options"]): ObjectiveDimension => {
    const current = values(kind);
    return { kind, label, options, values: current, total: current.reduce((sum, row) => sum + (row.targetPercent > 0 ? row.targetPercent : 0), 0) };
  };
  const report = snapshot ? configuredReport(snapshot,reportContractIds(snapshot,'all')) : null;
  const assetOptions = (assets.data ?? []).filter(a=>a.is_active||selected.has(a.id)).map(a=>({id:a.id,label:`${a.name}${a.symbol?` (${a.symbol})`:''}`,isActive:a.is_active}));
  const assetScopes: AssetObjectiveScope[] = visibleContracts(contracts.data ?? []).map(c=>{
    const options = contractObjectiveOptions(assetOptions, positions.data ?? [], c.id);
    const scoped=rows.filter(r=>r.target_kind==='asset'&&r.scope_contract_id===c.id);
    const values=scoped.map(r=>({targetId:r.target_asset_id!,targetPercent:Number(r.target_percent)}));
    return {contractId:c.id,label:c.name,dimension:{kind:'asset',label:`Titres · ${c.name}`,options,values,total:values.reduce((s,v)=>s+Math.max(0,v.targetPercent),0)},comparisons:Object.fromEntries(options.map(a=>{
      const t=scoped.find(v=>v.target_asset_id===a.id)??rows.find(v=>v.target_kind==='asset'&&v.target_asset_id===a.id&&!v.scope_contract_id);const result=report?assetObjectiveComparison(report,a.id,c.id,t?{percent:Number(t.target_percent),scopeContractId:t.scope_contract_id}:null):null;
      return [a.id,{currentPercent:result?.currentPercent??null,denominatorEur:result?.denominatorEur??null,deltaPoints:result?.deltaPoints??null,reason:result?.reason??'valuation_unknown'}];
    }))};
  });
  return {
    assetScopes,
    revision: Number(revision.data ?? 0),
    dimensions: [
      dimension("envelope_type", "Types d’enveloppe", (envelopeTypes.data ?? []).filter((row) => row.is_active || selected.has(row.id)).map((row) => ({ id: row.id, label: row.label, isActive: row.is_active }))),
      dimension("contract", "Contrats", visibleContracts(contracts.data ?? []).map((row) => ({ id: row.id, label: `${row.name}${!row.is_active ? " (inactif)" : ""}`, isActive: row.is_active }))),
      dimension("asset", "Actifs", (assets.data ?? []).filter((row) => row.is_active || selected.has(row.id)).map((row) => ({ id: row.id, label: `${row.name}${row.symbol ? ` (${row.symbol})` : ""}`, isActive: row.is_active }))),
    ] satisfies ObjectiveDimension[],
  };
}
