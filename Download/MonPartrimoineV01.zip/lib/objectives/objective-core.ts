export type ObjectiveKind = "envelope_type" | "contract" | "asset";
export type ObjectiveActionState = { status: "idle" | "success" | "error"; message?: string; revision?: number; targetId?: string; row?: number };
export type ObjectiveOption = { id: string; label: string; isActive: boolean };
export type ObjectiveValue = { targetId: string; targetPercent: number };
export type ObjectiveHolding = { contract_id: string; asset_id: string; is_active: boolean };

export function contractObjectiveOptions(options: ObjectiveOption[], holdings: ObjectiveHolding[], contractId: string) {
  const attached = new Set(holdings.filter(p => p.contract_id === contractId && p.is_active).map(p => p.asset_id));
  return options.filter(a => a.isActive && attached.has(a.id));
}
export type AssetObjectiveScope = { contractId: string; label: string; dimension: ObjectiveDimension; comparisons: Record<string, { currentPercent: number | null; denominatorEur: number | null; deltaPoints: number | null; reason?: string | null }> };
export type ObjectiveDimension = {
  kind: ObjectiveKind;
  label: string;
  options: ObjectiveOption[];
  values: ObjectiveValue[];
  total: number;
};

export function isObjectiveKind(value: string): value is ObjectiveKind {
  return value === "envelope_type" || value === "contract" || value === "asset";
}

export function objectiveStatus(total: number) {
  return total === 100 ? "Complet" : "Brouillon incomplet";
}

// IDs come from PostgreSQL uuid columns, including seeded IDs and newer UUID
// versions. UUID version/variant bits do not establish ownership or availability.
export function isObjectiveId(value: string) {
  return /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(value);
}

export class ObjectiveFormError extends Error {
  targetId: string;
  row: number;
  constructor(message: string, targetId: string, row: number) {
    super(message);
    this.targetId = targetId;
    this.row = row;
  }
}

export function objectiveFormMessage(state: ObjectiveActionState, dimension: ObjectiveDimension) {
  const label = dimension.options.find(option => option.id === state.targetId)?.label;
  return state.row ? `Ligne ${state.row}${label ? ` (${label})` : ""} : ${state.message}` : state.message;
}

export function parseObjectiveForm(form: FormData, kind: ObjectiveKind): ObjectiveValue[] {
  const values: ObjectiveValue[] = [];
  const seen = new Set<string>();
  let row = 0;
  for (const [name, rawValue] of form.entries()) {
    if (!name.startsWith("target_")) continue;
    row++;
    const targetId = name.slice(7);
    const invalid = (message: string): never => { throw new ObjectiveFormError(message, targetId, row); };
    if (!isObjectiveId(targetId)) invalid("L’identifiant de cette ligne est invalide. Rechargez la page puis réessayez.");
    if (seen.has(targetId.toLowerCase())) invalid("Cette ligne est envoyée plusieurs fois. Rechargez la page puis réessayez.");
    seen.add(targetId.toLowerCase());
    if (typeof rawValue !== "string") invalid("Saisissez un pourcentage, pas un fichier.");
    const raw = String(rawValue).trim().replace(",", ".");
    if (!raw) continue;
    if (!/^-?\d{1,3}(?:\.\d{1,2})?$/.test(raw)) invalid("Saisissez un pourcentage valide, avec deux décimales maximum.");
    const targetPercent = Number(raw);
    if (!(targetPercent > 0 && targetPercent <= 100) && !(targetPercent === -1 && kind === "asset")) {
      invalid(kind === "asset" ? "La cible doit être strictement positive et inférieure ou égale à 100, ou valoir -1 pour une exclusion. Laissez le champ vide pour retirer la cible." : "La cible doit être strictement positive et inférieure ou égale à 100. Laissez le champ vide pour retirer la cible.");
    }
    values.push({ targetId, targetPercent });
  }
  const total = values.reduce((sum, value) => sum + (value.targetPercent > 0 ? value.targetPercent : 0), 0);
  if (Math.round(total * 100) / 100 > 100) throw new Error("Le total d’une dimension ne peut pas dépasser 100 %.");
  return values;
}

export function objectiveError(code?: string) {
  if (code === "40001" || code === "40P01") return "Les objectifs ont été modifiés simultanément. Rechargez la page puis réessayez.";
  if (code === "23505") return "Une cible existe déjà pour ce titre et ce contrat. Aucune cible n’a été remplacée.";
  if (code === "23514" || code === "22023") return "Objectifs invalides : vérifiez les valeurs et leur total.";
  if (code === "42501" || code === "PGRST116") return "Une cible n’est plus accessible.";
  return "Enregistrement impossible. Rechargez la page puis réessayez.";
}

export const assetObjectiveScopeNotice = 'Chaque cible de titre se rapporte au contrat choisi, sur son BRUT complet, espèces incluses. Les anciennes cibles restent non affectées jusqu’à votre décision explicite. Les exclusions globales -1 doivent être retirées explicitement avant la création de cibles par contrat.';

export function assetObjectiveReason(reason: string | null | undefined) {
  const messages: Record<string,string> = {
    target_missing:'Cible absente ou non applicable.', scope_missing:'Cible sans contrat : association explicite nécessaire.',
    excluded:'Exclu du pilotage ; valeur conservée dans la base.', different_scope:'Cible d’un autre contrat.',
    scope_outside_selection:'Contrat hors sélection.', holding_missing:'Détention non établie : aucune valeur nulle supposée.',
    zero_denominator:'BRUT nul : ratio indéterminé.', valuation_unknown:'Détention ou BRUT complet inconnu.',
  };
  return reason ? messages[reason] ?? 'Comparaison indisponible.' : '';
}
