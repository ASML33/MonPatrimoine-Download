import {propertyHistory,propertyValue} from "@/lib/contracts/property-valuations";
import { selectDatedBalances } from "@/lib/cash/dated-balances";
import { visibleContracts } from "@/lib/contracts/contract-scope";
import { selectManualSituation, type ManualSituation } from "@/lib/patrimony/manual-situation-core";
import {
  selectLatestFxRates,
  selectLatestPositionSnapshots,
  selectLatestUsablePrices,
} from "@/lib/patrimony/current-valuation-core";

type ContractRecord = { valuation_source?: string; envelope_type_code?: string; id: string; name: string; display_name?: string | null; currency_code: string; dashboard_tile_name?: string | null };
type PositionRecord = { metadata?:unknown; id: string; contract_id: string; asset_id: string; quantity: number | string };
type PositionSnapshotRecord = { position_id: string; market_value: number | string; currency_code: string; valued_at: string };
type CashBalanceRecord = { contract_id: string; amount: number | string; currency_code: string; as_of: string; metadata?: unknown; updated_at?: string };
type AssetRecord = { id: string; asset_type_code: string; valuation_mode: string; currency_code: string };
type AssetPriceRecord = { asset_id: string; origin: "automatic" | "manual"; price: number | string; currency_code: string; observed_at: string; obtained_at?: string };
type FxRateRecord = { currency_code: string; requested_on: string; observed_on: string; eur_per_unit: number | string; source: "ecb" | "frankfurter" | "manual"; obtained_at?: string };

export type CurrencyValue = { currency: string; amount: number };
type ReportContractSummary = { valuationUnavailable?: boolean; id: string; grossEur: number; netEstimatedEur: number | null; netKind?: "calculated" | "approximate" | "unavailable"; incompletePositions: number; incompleteCashBalances: number;manualSituationAt?:string|null };
export type DashboardProperty = {positionId:string;assetId:string;name:string;valueEur:number|null};
export type DashboardContract = { properties?:DashboardProperty[]; id: string; name: string; envelopeTypeCode: string; values: CurrencyValue[]; grossFallback: boolean; approximate: boolean; incompletePositions: number; incompleteCashBalances: number; isEmpty: boolean;valueDate?:string|null };
export type DashboardGroup = { key: string; label: string; contracts: DashboardContract[]; values: CurrencyValue[]; grossFallback: boolean; approximate: boolean };
export type DashboardData = {
  contracts: DashboardContract[];
  groups: DashboardGroup[];
  activeContractCount: number;
  total: CurrencyValue[];
  outsideRealEstate: CurrencyValue[];
  hasRealEstate: boolean;
  lastUpdated: string | null;
  incompletePositions: number;
  incompleteCashBalances: number;
  totalGrossFallback: boolean;
  totalApproximate: boolean;
  outsideRealEstateGrossFallback: boolean;
  outsideRealEstateApproximate: boolean;
};
export type DashboardRecords = {
  manualSituations?: ManualSituation[];
  contracts: ContractRecord[];
  positions: PositionRecord[];
  positionSnapshots: PositionSnapshotRecord[];
  assetPrices: AssetPriceRecord[];
  cashBalances: CashBalanceRecord[];
  assets: AssetRecord[];
  fxRates?: FxRateRecord[];
  reportContracts?: ReportContractSummary[];
  reportAssets?:{id:string;name:string}[];
};

function addValue(target: Map<string, number>, currency: string, amount: number) {
  target.set(currency, (target.get(currency) ?? 0) + amount);
}

function valuesFromMap(values: Map<string, number>, includeZero = false): CurrencyValue[] {
  return [...values.entries()]
    .filter(([, amount]) => (includeZero ? amount >= 0 : amount > 0))
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([currency, amount]) => ({ currency, amount }));
}

function newest(current: string | null, candidate: string) {
  return current === null || Date.parse(candidate) > Date.parse(current) ? candidate : current;
}

export function buildDashboardData(records: DashboardRecords, now = new Date().toISOString()): DashboardData {
  records = { ...records, contracts: visibleContracts(records.contracts), reportContracts: records.reportContracts ? visibleContracts(records.reportContracts) : undefined };
  const contractsById = new Map(records.contracts.map((contract) => [contract.id, contract]));
  const assets = new Map(records.assets.map((item) => [item.id, item.asset_type_code]));
  const positions = new Map(records.positions.map((item) => [item.id, item]));
  const latestSnapshots = selectLatestPositionSnapshots(records.positionSnapshots, now);
  const latestPrices = selectLatestUsablePrices(records.assets, records.assetPrices, now);
  const latestFxRates = selectLatestFxRates(records.fxRates ?? [], now);
  const contractValues = new Map<string, Map<string, number>>();
  const totals = new Map<string, number>();
  const outsideRealEstate = new Map<string, number>();
  const positionCounts = new Map<string, number>();
  const cashCounts = new Map<string, number>();
  const incompleteByContract = new Map<string, number>();
  const incompleteCashByContract = new Map<string, number>();
  const propertyDetails = new Map<string, DashboardProperty[]>();
  let hasRealEstate = false;
  let lastUpdated: string | null = null;
  let incompletePositions = 0;
  let incompleteCashBalances = 0;

  if (records.contracts.length) totals.set("EUR", 0);
  const eurAmount = (amount: number, currency: string) => currency === "EUR"
    ? amount
    : latestFxRates.has(currency) ? amount * Number(latestFxRates.get(currency)!.eur_per_unit) : null;
  const recordValue = (contractId: string, amount: number) => {
    if (!Number.isFinite(amount) || amount <= 0) return;
    const values = contractValues.get(contractId) ?? new Map<string, number>();
    addValue(values, "EUR", amount);
    contractValues.set(contractId, values);
    addValue(totals, "EUR", amount);
  };

  const manualIds = new Set(records.contracts.filter((c) => c.valuation_source === "manual_situation" && c.envelope_type_code !== "epargne_liquide").map((c) => c.id));
  for (const position of positions.values()) {
    if (contractsById.get(position.contract_id)?.envelope_type_code === "epargne_liquide") continue;
    if (manualIds.has(position.contract_id)) continue;
    if (!contractsById.has(position.contract_id)) continue;
    positionCounts.set(position.contract_id, (positionCounts.get(position.contract_id) ?? 0) + 1);
    const price = latestPrices.get(position.asset_id);
    const snapshot = latestSnapshots.get(position.id);
    const quantity = Number(position.quantity);
    const pv=propertyHistory(position.metadata)?propertyValue(position.metadata,now,records.fxRates??[]):null;
    if(pv?.ended)continue;
    const nativeAmount = pv?Number(pv.observation?.amount):price&&assets.get(position.asset_id)!=="real_estate" ? quantity * Number(price.price) : Number(snapshot?.market_value);
    const currency = pv?pv.observation?.currency:price?.currency_code ?? snapshot?.currency_code;
    const valuedAt = pv?pv.observation?.effectiveOn:price?.observed_at ?? snapshot?.valued_at;
    const amount = pv?pv.amountEur:currency ? eurAmount(nativeAmount, currency) : null;
    if(contractsById.get(position.contract_id)?.envelope_type_code==="immobilier"&&assets.get(position.asset_id)==="real_estate"){
      const rows=propertyDetails.get(position.contract_id)??[];
      rows.push({positionId:position.id,assetId:position.asset_id,name:records.reportAssets?.find(a=>a.id===position.asset_id)?.name??position.asset_id,valueEur:currency&&valuedAt&&amount!==null&&Number.isFinite(amount)&&nativeAmount>=0?amount:null});
      propertyDetails.set(position.contract_id,rows);
    }
    if (!currency || !valuedAt || amount === null || !Number.isFinite(amount) || nativeAmount < 0) {
      incompletePositions += 1;
      incompleteByContract.set(position.contract_id, (incompleteByContract.get(position.contract_id) ?? 0) + 1);
      continue;
    }
    recordValue(position.contract_id, amount);
    if (assets.get(position.asset_id) === "real_estate") hasRealEstate = true;
    else addValue(outsideRealEstate, "EUR", amount);
    lastUpdated = newest(lastUpdated, valuedAt);
  }

  for (const balance of selectDatedBalances(records.cashBalances, now)) {
    if (manualIds.has(balance.contract_id)) continue;
    if (!contractsById.has(balance.contract_id)) continue;
    cashCounts.set(balance.contract_id, (cashCounts.get(balance.contract_id) ?? 0) + 1);
    const amount = Number(balance.amount);
    if (!Number.isFinite(amount) || amount <= 0) continue;
    const converted = eurAmount(amount, balance.currency_code);
    if (converted === null || !Number.isFinite(converted)) {
      incompleteCashBalances += 1;
      incompleteCashByContract.set(balance.contract_id, (incompleteCashByContract.get(balance.contract_id) ?? 0) + 1);
      continue;
    }
    recordValue(balance.contract_id, converted);
    addValue(outsideRealEstate, "EUR", converted);
    lastUpdated = newest(lastUpdated, balance.as_of);
  }

  const reportById = new Map((records.reportContracts ?? []).map((contract) => [contract.id, contract]));
  for (const id of manualIds) {
    positionCounts.set(id, 1);
    const shared = reportById.get(id);
    if (shared) {
      if (shared.incompletePositions) { incompletePositions+=shared.incompletePositions; incompleteByContract.set(id,shared.incompletePositions); }
      if (shared.incompleteCashBalances) { incompleteCashBalances+=shared.incompleteCashBalances; incompleteCashByContract.set(id,shared.incompleteCashBalances); }
      if (shared.manualSituationAt) lastUpdated=newest(lastUpdated,shared.manualSituationAt);
      continue;
    }
    const situation = selectManualSituation(records.manualSituations ?? [], id, now);
    if (!situation) { incompletePositions++; incompleteByContract.set(id, 1); continue; }
    recordValue(id, Number(situation.gross_eur));
    addValue(outsideRealEstate, "EUR", Number(situation.gross_eur));
    lastUpdated = newest(lastUpdated, situation.situated_at);
  }
  const visibleRecords = records.contracts.filter((contract) => Boolean(contract.dashboard_tile_name?.trim()));
  const contracts = visibleRecords.map((contract) => {
    const values = valuesFromMap(contractValues.get(contract.id) ?? new Map());
    const report = reportById.get(contract.id);
    const employeeGross = ["peg","per_col"].includes(contract.envelope_type_code??"");
    const displayed = employeeGross ? report?.grossEur : report?.netEstimatedEur ?? report?.grossEur;
    return {
      id: contract.id,
      name: contract.display_name?.trim() || contract.name,
      envelopeTypeCode: contract.envelope_type_code ?? "other",
      ...(contract.envelope_type_code==="immobilier"?{properties:(propertyDetails.get(contract.id)??[]).sort((a,b)=>compareDisplayNames({id:a.positionId,name:a.name},{id:b.positionId,name:b.name}))}:{}),
      values: report?.valuationUnavailable||employeeGross&&report?.manualSituationAt===null?[]:report && Number.isFinite(displayed) ? [{ currency: "EUR", amount: Number(displayed) }] : values.length ? values : [{ currency: "EUR", amount: 0 }],
      grossFallback: report ? employeeGross || report.netEstimatedEur === null : false,
      approximate: !employeeGross && report?.netEstimatedEur !== null && report?.netKind === "approximate",
      ...(report?.manualSituationAt?{valueDate:report.manualSituationAt}:{}),
      incompletePositions: incompleteByContract.get(contract.id) ?? 0,
      incompleteCashBalances: incompleteCashByContract.get(contract.id) ?? 0,
      isEmpty: (positionCounts.get(contract.id) ?? 0) === 0 && (cashCounts.get(contract.id) ?? 0) === 0,
    };
  });
  const tileNames = [...new Set(visibleRecords.map((contract) => contract.dashboard_tile_name!.trim()))];
  const groups = tileNames.map((label) => {
    const ids = new Set(visibleRecords.filter((contract) => contract.dashboard_tile_name!.trim() === label).map((contract) => contract.id));
    const children = contracts.filter((contract) => ids.has(contract.id)).sort(compareDisplayNames);
    const grossFallback = children.some((contract) => contract.grossFallback);
    const amount = children.reduce((sum, contract) => {
      const report = reportById.get(contract.id);
      return sum + (grossFallback && report ? report.grossEur : contract.values[0]?.amount ?? 0);
    }, 0);
    return { key: `tile-${label}`, label, contracts: children,
      values: children.length && children.every(c=>reportById.get(c.id)?.valuationUnavailable) ? [] : [{ currency: "EUR", amount }],
      grossFallback, approximate: !grossFallback && children.some((contract) => contract.approximate) };
  }).sort(compareTileLabels);
  const reportContracts = records.reportContracts ?? [];
  const summarize = (items: ReportContractSummary[]) => {
    const grossFallback = items.some((item) => item.netEstimatedEur === null);
    const amount = grossFallback ? items.reduce((sum, item) => sum + item.grossEur, 0) : items.reduce((sum, item) => sum + item.netEstimatedEur!, 0);
    return { values: items.length && items.every(item=>item.valuationUnavailable) ? [] : [{ currency: "EUR", amount }], grossFallback, approximate: !grossFallback && items.some((item) => item.netKind === "approximate") };
  };
  const totalSummary = reportContracts.length ? summarize(reportContracts) : { values: valuesFromMap(totals, true), grossFallback: false, approximate: false };
  const outsideItems = reportContracts.filter((item) => records.contracts.find((contract) => contract.id === item.id)?.envelope_type_code !== "immobilier");
  const outsideSummary = reportContracts.length ? summarize(outsideItems) : { values: valuesFromMap(outsideRealEstate, hasRealEstate), grossFallback: false, approximate: false };
  if (hasRealEstate && !outsideRealEstate.has("EUR")) outsideRealEstate.set("EUR", 0);
  return { contracts, groups, activeContractCount: records.contracts.length, total: totalSummary.values, outsideRealEstate: outsideSummary.values, hasRealEstate: records.contracts.some((contract) => contract.envelope_type_code === "immobilier") || hasRealEstate, lastUpdated, incompletePositions, incompleteCashBalances,
    totalGrossFallback: totalSummary.grossFallback, totalApproximate: totalSummary.approximate,
    outsideRealEstateGrossFallback: outsideSummary.grossFallback, outsideRealEstateApproximate: outsideSummary.approximate };
}
import { compareDisplayNames, compareTileLabels } from "@/lib/ui/display-order";
