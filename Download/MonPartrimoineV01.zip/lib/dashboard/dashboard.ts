import { CONTRACT_COLUMNS } from "@/lib/contracts/contract-columns";
import {propertyHistory} from "@/lib/contracts/property-valuations";
import { readManualSituations } from "@/lib/patrimony/manual-situations";
import "server-only";

import { buildDashboardData } from "@/lib/dashboard/dashboard-core";
import { requireRenderUser } from "@/lib/auth/render-context";
import { createClient } from "@/lib/supabase/server";
import { getCurrentPatrimonialReport } from "@/lib/reports/patrimonial-report";

export async function getCurrentDashboard() {
  const user = await requireRenderUser();
  const supabase = await createClient();
  const [contractsResult, positionsResult, snapshotsResult, cashResult, report] = await Promise.all([
    supabase.from("contracts").select(`${CONTRACT_COLUMNS},envelope_types(code)`)
      .eq("user_id", user.id).eq("is_active", true),
    supabase.from("positions").select("id,contract_id,asset_id,quantity,metadata").eq("user_id", user.id).eq("is_active", true),
    supabase.from("position_snapshots").select("position_id,market_value,currency_code,valued_at").eq("user_id", user.id).order("valued_at", { ascending: false }),
    supabase.from("cash_balances").select("id,contract_id,amount,currency_code,as_of,metadata,updated_at").eq("user_id", user.id),
    getCurrentPatrimonialReport(),
  ]);
  if ([contractsResult, positionsResult, snapshotsResult, cashResult].some((result) => result.error)) throw new Error("Dashboard data could not be loaded.");
  const assetIds = [...new Set((positionsResult.data ?? []).map((item) => item.asset_id))];
  const [assetsResult, pricesResult] = await Promise.all([
    assetIds.length ? supabase.from("assets").select("id,asset_type_code,valuation_mode,currency_code").in("id", assetIds) : { data: [], error: null },
    assetIds.length ? supabase.from("asset_prices").select("asset_id,origin,price,currency_code,observed_at,obtained_at").in("asset_id", assetIds).order("observed_at", { ascending: false }).order("obtained_at", { ascending: false }) : { data: [], error: null },
  ]);
  if (assetsResult.error || pricesResult.error) throw new Error("Dashboard data could not be loaded.");
  const fxCurrencies = [...new Set([...(assetsResult.data ?? []).map((asset) => asset.currency_code),...(positionsResult.data??[]).flatMap(p=>propertyHistory(p.metadata)?.entries.map(e=>e.currency)??[]), ...(cashResult.data ?? []).map((balance) => balance.currency_code)].filter((currencyCode) => currencyCode !== "EUR"))];
  const fxRatesResult = fxCurrencies.length
    ? await supabase.from("fx_rates").select("currency_code,requested_on,observed_on,eur_per_unit,source,obtained_at").in("currency_code", fxCurrencies).lte("requested_on", new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Paris" }).format(new Date())).order("requested_on", { ascending: false }).order("obtained_at", { ascending: false })
    : { data: [], error: null };
  if (fxRatesResult.error) throw new Error("Dashboard data could not be loaded.");
  const manual = await readManualSituations(supabase, user.id);
  const contracts = (contractsResult.data ?? []).map((contract) => ({ ...contract, envelope_type_code: (Array.isArray(contract.envelope_types) ? contract.envelope_types[0] : contract.envelope_types)?.code ?? "other" }));
  return buildDashboardData({ ...manual, contracts, positions: positionsResult.data ?? [], positionSnapshots: snapshotsResult.data ?? [], assetPrices: (pricesResult.data ?? []) as Array<{ asset_id: string; origin: "automatic" | "manual"; price: number | string; currency_code: string; observed_at: string; obtained_at: string }>, cashBalances: cashResult.data ?? [], assets: assetsResult.data ?? [], fxRates: (fxRatesResult.data ?? []) as Array<{ currency_code: string; requested_on: string; observed_on: string; eur_per_unit: number | string; source: "ecb" | "frankfurter" | "manual"; obtained_at: string }>, reportContracts: report.contracts, reportAssets: report.assets });
}
