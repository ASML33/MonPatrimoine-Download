import { CONTRACT_COLUMNS } from "@/lib/contracts/contract-columns";
import {readEnvelopeFiscalities} from '@/lib/fiscal/envelopes';
import {propertyHistory} from "@/lib/contracts/property-valuations";
import { readManualSituations } from "@/lib/patrimony/manual-situations";
import "server-only";

import { requireRenderUser } from "@/lib/auth/render-context";
import type { FxRateRecord } from "@/lib/fx/fx-core";
import { parisDate } from "@/lib/patrimony/current-valuation-core";
import { mapFiscalRuleRow, type FiscalRuleRow } from "@/lib/fiscal/fiscal-settings";
import { countryDisplayName } from "@/lib/assets/country-display";
import { createClient } from "@/lib/supabase/server";
import {
  buildPatrimonialReport,
  type PatrimonialReport,
  type PatrimonialReportRecords,
} from "./patrimonial-report-core";

type AssetRelation = { metadata?:unknown;
  id: string;
  name: string;
  display_name: string | null;
  symbol: string | null; isin?: string | null;
  color: string | null;
  color_origin?: string;
  asset_type_code: string;
  currency_code: string;
  valuation_mode: string;
};

type RawPosition = PatrimonialReportRecords["positions"][number] & {
  assets: AssetRelation | AssetRelation[] | null;
};
type QueryError = { code?: string; message?: string } | null;

async function readReportHierarchy(
  supabase: Awaited<ReturnType<typeof createClient>>,
  userId: string,
  selected?: readonly string[],
): Promise<{
  envelopeTypes: PatrimonialReportRecords["envelopeTypes"] | null;
  contracts: PatrimonialReportRecords["contracts"] | null;
  error: QueryError;
}> {
  let contractQuery=supabase.from('contracts').select(CONTRACT_COLUMNS).eq('user_id',userId).eq('is_active',true);
  if(selected)contractQuery=contractQuery.in('id',[...selected]);
  const [envelopeTypesResult, contractsResult] = await Promise.all([
    supabase.from("envelope_types").select("id,code,label"),
    contractQuery,
  ]);
  return {
    envelopeTypes: envelopeTypesResult.data ?? null,
    contracts: contractsResult.data ?? null,
    error: envelopeTypesResult.error ?? contractsResult.error,
  };
}

function firstRelation<T>(relation: T | T[] | null) {
  return Array.isArray(relation) ? relation[0] ?? null : relation;
}

function emptyResult<T>() {
  return { data: [] as T[], error: null };
}

async function readCurrentReportRecords(
  generatedAt = new Date().toISOString(),
  selected?: readonly string[],
): Promise<PatrimonialReportRecords> {
  const user = await requireRenderUser();
  const supabase = await createClient();

  let positionsQuery=supabase.from('positions').select('id,contract_id,asset_id,quantity,average_cost_per_unit::text,cost_currency_code,metadata,assets(id,name,display_name,symbol,isin,color,color_origin,asset_type_code,currency_code,valuation_mode,metadata)').eq('user_id',user.id).eq('is_active',true);
  let cashQuery=supabase.from('cash_balances').select('id,contract_id,amount,currency_code,as_of,metadata,updated_at').eq('user_id',user.id);
  let flowsQuery=supabase.from('cash_flows').select('id,kind,destination_contract_id,source_contract_id,amount,currency_code,occurred_at,fx_rate_id,fx_status').eq('user_id',user.id).in('kind',['contribution','withdrawal']);
  if(selected){
    if(!selected.length||selected.some(id=>!/^[0-9a-f-]{36}$/i.test(id)))throw Error('Invalid report selection');
    positionsQuery=positionsQuery.in('contract_id',[...selected]);cashQuery=cashQuery.in('contract_id',[...selected]);
    flowsQuery=flowsQuery.or(`source_contract_id.in.(${selected.join(',')}),destination_contract_id.in.(${selected.join(',')})`);
  }
  const [hierarchyResult, positionsResult, initialSnapshotsResult, cashResult, flowsResult, fiscalRulesResult, fiscalPreferencesResult] = await Promise.all([
    readReportHierarchy(supabase, user.id,selected),
    positionsQuery,
    selected ? emptyResult<PatrimonialReportRecords["positionSnapshots"][number]>() :
    supabase.from("position_snapshots")
      .select("position_id,unit_price,market_value,currency_code,valued_at")
      .eq("user_id", user.id).lte("valued_at", generatedAt).order("valued_at", { ascending: false }),
    cashQuery,
    flowsQuery,
    supabase.from("fiscal_rules")
      .select("id,rule_name,calculation_mode,fiscal_regime_id,owner_user_id,version_number,valid_from,age_threshold_months,ir_rate_before,ir_rate_after,ps_rate_before,ps_rate_after,ir_base_type,ps_base_type,ir_allowance_amount,ir_allowance_scope,status,description,source,source_title,verified_on")
      .eq("active", true).eq("status", "verified").not("fiscal_regime_id", "is", null),
    supabase.from("user_fiscal_regime_preferences").select("fiscal_regime_id,use_personal_rule").eq("user_id", user.id),
  ]);
  const firstFailure = [hierarchyResult, positionsResult, initialSnapshotsResult, cashResult, flowsResult, fiscalRulesResult, fiscalPreferencesResult]
    .find((result) => result.error)?.error;
  if (firstFailure) throw new Error("Patrimonial report data could not be loaded.");

  const rawPositions = (positionsResult.data ?? []) as RawPosition[];
  const snapshotsResult=selected ? rawPositions.length ? await supabase.from('position_snapshots').select('position_id,unit_price,market_value,currency_code,valued_at').eq('user_id',user.id).in('position_id',rawPositions.map(p=>p.id)).lte('valued_at',generatedAt).order('valued_at',{ascending:false}) : emptyResult<PatrimonialReportRecords['positionSnapshots'][number]>() : initialSnapshotsResult;
  if(snapshotsResult.error)throw Error('Patrimonial report observations unavailable');
  const assets = new Map<string, AssetRelation>();
  for (const position of rawPositions) {
    const asset = firstRelation(position.assets);
    if (asset) assets.set(asset.id, asset);
  }
  const assetIds = [...assets.keys()];
  const rateIds = [...new Set((flowsResult.data ?? []).flatMap((flow) => flow.fx_rate_id ? [flow.fx_rate_id] : []))];
  const currencies = [...new Set([
    ...assets.values().map((asset) => asset.currency_code),
    ...(cashResult.data ?? []).map((balance) => balance.currency_code),
    ...rawPositions.map((position) => position.cost_currency_code),
    ...rawPositions.flatMap(p=>propertyHistory(p.metadata)?.entries.map(e=>e.currency)??[]),
    ...(snapshotsResult.data ?? []).map((snapshot) => snapshot.currency_code),
  ].filter((currency) => currency !== "EUR"))];
  const today = parisDate(generatedAt);

  const [pricesResult, currentRatesResult, historicalRatesResult, exposuresResult, themesResult, themeExposuresResult, sectorsResult, activitiesResult, countriesResult, regionsResult] = await Promise.all([
    assetIds.length
      ? supabase.from("asset_prices")
        .select("asset_id,origin,price,currency_code,observed_at,obtained_at,source_name")
        .in("asset_id", assetIds).lte("observed_at", generatedAt)
        .order("observed_at", { ascending: false }).order("obtained_at", { ascending: false })
      : emptyResult<PatrimonialReportRecords["prices"][number]>(),
    currencies.length
      ? supabase.from("fx_rates")
        .select("id,currency_code,requested_on,observed_on,eur_per_unit,source,obtained_at")
        .in("currency_code", currencies).lte("requested_on", today)
        .order("requested_on", { ascending: false }).order("obtained_at", { ascending: false })
      : emptyResult<FxRateRecord>(),
    rateIds.length
      ? supabase.from("fx_rates")
        .select("id,currency_code,requested_on,observed_on,eur_per_unit,source,obtained_at")
        .in("id", rateIds)
      : emptyResult<FxRateRecord>(),
    assetIds.length
      ? supabase.rpc("effective_asset_exposures", { requested_assets: assetIds })
      : emptyResult<PatrimonialReportRecords["exposures"][number]>(),
    supabase.from("themes").select("id,name,is_active").eq("owner_user_id", user.id),
    assetIds.length
      ? supabase.rpc("effective_asset_theme_exposures", { requested_assets: assetIds })
      : emptyResult<PatrimonialReportRecords["themeExposures"][number]>(),
    supabase.from("effective_sectors").select("id,name,code"),
    supabase.from("sector_activities").select("id,name"),
    supabase.from("exposure_countries").select("id,name,code,region_code"),
    supabase.from("geographic_regions").select("code,name"),
  ]);
  const secondFailure = [pricesResult, currentRatesResult, historicalRatesResult, exposuresResult, themesResult, themeExposuresResult, sectorsResult, activitiesResult, countriesResult, regionsResult]
    .find((result) => result.error)?.error;
  if (secondFailure) throw new Error("Patrimonial report details could not be loaded.");

  const manual = await readManualSituations(supabase, user.id,generatedAt,selected);
  return {
    ...manual,
    envelopeTypes: hierarchyResult.envelopeTypes ?? [],
    contracts: hierarchyResult.contracts ?? [],
    positions: rawPositions.map((position) => ({
      id: position.id,
      metadata: position.metadata,
      contract_id: position.contract_id,
      asset_id: position.asset_id,
      quantity: position.quantity,
      average_cost_per_unit: position.average_cost_per_unit,
      cost_currency_code: position.cost_currency_code,
    })),
    positionSnapshots: snapshotsResult.data ?? [],
    cashBalances: cashResult.data ?? [],
    cashFlows: (flowsResult.data ?? []) as PatrimonialReportRecords["cashFlows"],
    assets: [...assets.values()],
    prices: (pricesResult.data ?? []) as PatrimonialReportRecords["prices"],
    currentFxRates: (currentRatesResult.data ?? []) as FxRateRecord[],
    historicalFxRates: (historicalRatesResult.data ?? []) as FxRateRecord[],
    exposures: (exposuresResult.data ?? []) as PatrimonialReportRecords["exposures"],
    sectors: sectorsResult.data ?? [],
    activities: activitiesResult.data ?? [],
    countries: (countriesResult.data ?? []).map((country) => ({ ...country, name: countryDisplayName(country.name) })),
    regions: regionsResult.data ?? [],
    themes: themesResult.data ?? [],
    themeExposures: (themeExposuresResult.data ?? []) as PatrimonialReportRecords["themeExposures"],
    envelopeFiscalities: await readEnvelopeFiscalities(),
    fiscalConsultationPolicy: 2,
    fiscalRules: ((fiscalRulesResult.data ?? []) as FiscalRuleRow[]).map(mapFiscalRuleRow),
    fiscalPreferences: (fiscalPreferencesResult.data ?? []).map((item) => ({ fiscalRegimeId: item.fiscal_regime_id, usePersonalRule: item.use_personal_rule })),
    userId: user.id,
  };
}

export async function getCurrentPatrimonialReport(generatedAt = new Date().toISOString()): Promise<PatrimonialReport> {
  return buildPatrimonialReport(await readCurrentReportRecords(generatedAt), generatedAt, undefined, true);
}

export async function getCurrentReportSnapshot(selected?: readonly string[]) {
  const generatedAt = new Date().toISOString();
  const { reportSnapshot } = await import("./report-configuration");
  return reportSnapshot(await readCurrentReportRecords(generatedAt,selected), generatedAt);
}
