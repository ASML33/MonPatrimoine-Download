import {latestEmployeeSavingsValue} from "@/lib/patrimony/employee-savings-values";
import {locationSnapshot} from "@/lib/geography/location-history";
import {propertyHistory,propertyObservationAt} from "@/lib/contracts/property-valuations";
import { selectDatedPosition,positionHistory,observationAt } from "@/lib/contracts/position-observations";
import { parisDate } from "@/lib/patrimony/current-valuation-core";
import { historicalContractGain } from "@/lib/patrimony/chart-core";
import { buildPatrimonialReport, type ReportContract, type PatrimonialReportRecords } from "./patrimonial-report-core";
import { selectDatedBalances } from "@/lib/cash/dated-balances";
import { selectLatestFxRates } from "@/lib/patrimony/current-valuation-core";
import { selectManualSituation } from "@/lib/patrimony/manual-situation-core";
import { visibleContracts } from "@/lib/contracts/contract-scope";
export const reportSections = { summary: "Synthèse", contracts: "Contrats", assets: "Actifs / détentions", allocations: "Allocations", exposures: "Expositions", fiscal: "Détail fiscal" } as const;
export type ReportSection = keyof typeof reportSections;
export type ReportSnapshot = { generatedAt: string; records: PatrimonialReportRecords };
// Authenticated private inputs only. Never serialize arbitrary contract metadata,
// source payloads or archived balances to the configurable client workspace.
export function reportSnapshot(input: PatrimonialReportRecords, generatedAt: string): ReportSnapshot {
 const contracts = visibleContracts(input.contracts).filter(c => c.is_active !== false).map(c => ({
  id:c.id,envelope_type_id:c.envelope_type_id,name:c.name,display_name:c.display_name,currency_code:c.currency_code,dashboard_tile_name:c.dashboard_tile_name,
  closed_on:c.closed_on,is_active:c.is_active,valuation_source:c.valuation_source,pea_pme_standard_confirmed:c.pea_pme_standard_confirmed,
  fiscal_assignments:c.fiscal_assignments,fiscal_regime_id:c.fiscal_regime_id,fiscal_started_on:c.fiscal_started_on,fiscal_history_complete:c.fiscal_history_complete,social_contributions_paid_eur:c.social_contributions_paid_eur,
  metadata:{...locationSnapshot(c.metadata,parisDate(generatedAt)),...Object.fromEntries(["knownTotalContributionsEur","knownNetCashFlowsEur","knownLiquidationNetEur"].filter(k => c.metadata?.[k] !== undefined).map(k => [k,c.metadata![k]]))},
 }));
 const records = { ...input, contracts, assets:input.assets.map(a=>({...a,metadata:locationSnapshot(a.metadata,parisDate(generatedAt))})),
  employeeSavingsSources:undefined,
  positions:input.positions.map(p=>{const current=selectDatedPosition(p,generatedAt),h=positionHistory(p.metadata),e=h?observationAt(h.entries,parisDate(generatedAt)):null,ph=propertyHistory(p.metadata),pe=ph?propertyObservationAt(ph.entries,parisDate(generatedAt)):null;return {...current,metadata:ph?{property_valuations:{version:1,entries:pe?[pe]:[],archived:[]}}:e?{position_observations:{version:1,entries:[e],archived:[],bindings:[]}}:undefined};}),
  cashBalances:selectDatedBalances(input.cashBalances,generatedAt).map(({id,contract_id,amount,currency_code,as_of,updated_at})=>({id,contract_id,amount,currency_code,as_of,updated_at})),
  manualSituations:input.manualSituations?.map(({id,contract_id,situated_at,recorded_at,source_time_precision,gross_eur,fiscal_gain_eur,source_net_eur,source})=>({id,contract_id,situated_at,recorded_at,source_time_precision,gross_eur,fiscal_gain_eur,source_net_eur,source})),
  employeeSavingsValuations:input.employeeSavingsValuations?.map(({ref,contractId,date,gross,net,provenance,recordedAt,precision,version,manualRevision})=>({ref,contractId,date,gross,net,provenance,recordedAt,precision,version,manualRevision,supersedes:[]})),
  manualSimulations:input.manualSimulations?.map(({id,contract_id,version,effective_from,ps_rate,created_at})=>({id,contract_id,version,effective_from,ps_rate,created_at})),
 };
 const frozen=JSON.parse(JSON.stringify({records,generatedAt})) as ReportSnapshot;
 frozen.records=configuredReportRecords(frozen,contracts.map(c=>c.id));
 return frozen;
}
export function reportContractIds(snapshot: ReportSnapshot, scope: "all" | "outside-real-estate") {
 const property = new Set(snapshot.records.envelopeTypes.filter(t=>t.code==="immobilier").map(t=>t.id));
 return snapshot.records.contracts.filter(c=>scope==="all" || !property.has(c.envelope_type_id)).map(c=>c.id);
}
export function configuredReportRecords(snapshot: ReportSnapshot, selected: readonly string[]) {
 const ids=new Set(selected),r=snapshot.records;
 const contracts=r.contracts.filter(c=>ids.has(c.id));
 const positions=r.positions.filter(p=>ids.has(p.contract_id));
 const assets=new Set(positions.map(p=>p.asset_id)),positionIds=new Set(positions.map(p=>p.id));
 const prices=r.prices.filter(p=>assets.has(p.asset_id));
 const cashBalances=r.cashBalances.filter(b=>ids.has(b.contract_id));
 const cashFlows=r.cashFlows.filter(f=>ids.has(f.source_contract_id??f.destination_contract_id??""));
 const positionSnapshots=r.positionSnapshots.filter(p=>positionIds.has(p.position_id));
 const currencies=new Set([...positions.flatMap(p=>propertyHistory(p.metadata)?.entries.map(e=>e.currency)??[]),...positions.map(p=>p.cost_currency_code),...prices.map(p=>p.currency_code),...cashBalances.map(b=>b.currency_code),...cashFlows.map(f=>f.currency_code),...positionSnapshots.map(p=>p.currency_code)]);
 const rateIds=new Set(cashFlows.map(f=>f.fx_rate_id));
 return {...r,contracts,positions,prices,cashBalances,cashFlows,positionSnapshots,
  envelopeTypes:r.envelopeTypes.filter(t=>contracts.some(c=>c.envelope_type_id===t.id)),
  assets:r.assets.filter(a=>assets.has(a.id)),exposures:r.exposures.filter(e=>assets.has(e.asset_id)),themeExposures:r.themeExposures.filter(e=>assets.has(e.asset_id)),
  currentFxRates:r.currentFxRates.filter(f=>currencies.has(f.currency_code)),historicalFxRates:r.historicalFxRates.filter(f=>rateIds.has(f.id??null)),
  manualSituations:r.manualSituations?.filter(s=>ids.has(s.contract_id)),manualSimulations:r.manualSimulations?.filter(s=>ids.has(s.contract_id)),
  employeeSavingsValuations:r.employeeSavingsValuations?.filter(s=>ids.has(s.contractId)),
 };
}

export function configuredReport(snapshot:ReportSnapshot,selected:readonly string[]){
 const records=configuredReportRecords(snapshot,selected);
 const report=buildPatrimonialReport(records,snapshot.generatedAt,undefined,true);
 const rates=selectLatestFxRates(records.currentFxRates,snapshot.generatedAt);
 for(const item of report.quality.freshness)if(item.kind==="fx"){
  const rate=rates.get(item.label);if(rate)Object.assign(item,{source:rate.source,requestedOn:rate.requested_on,eurPerUnit:rate.eur_per_unit});
 }
 for(const rate of records.historicalFxRates)report.quality.freshness.push({kind:"fx",label:`${rate.currency_code} — FX de flux daté`,observedAt:rate.observed_on,obtainedAt:rate.obtained_at??null,ageDays:null,stale:false,source:rate.source,requestedOn:rate.requested_on,eurPerUnit:rate.eur_per_unit});
 for(const contract of records.contracts)if(contract.valuation_source==="manual_situation"){
  if(records.employeeSavingsValuations){const value=latestEmployeeSavingsValue(records.employeeSavingsValuations,contract.id,snapshot.generatedAt);if(value)report.quality.freshness.push({kind:"manual",label:contract.display_name||contract.name,observedAt:value.date,obtainedAt:value.recordedAt,ageDays:null,stale:false,source:`${value.provenance} · précision ${value.precision} · NET ${value.net===null?"non fourni":"déclaré"}`});continue;}
  const source=selectManualSituation(records.manualSituations??[],contract.id,snapshot.generatedAt);
  if(source)report.quality.freshness.push({kind:"manual",label:contract.display_name||contract.name,observedAt:source.source_time_precision&&source.source_time_precision!=="exact"?source.situated_at.slice(0,10):source.situated_at,obtainedAt:source.recorded_at,ageDays:null,stale:false,source:`${source.source} · précision ${source.source_time_precision??"exact"}`});
 }
 return report;
}
export function reportGain(c:ReportContract){return c.contractGain??historicalContractGain(c.incompletePositions||c.incompleteCashBalances?null:c.grossEur,c.incompleteNetCashFlows?null:c.netCashFlowsEur,c.incompleteContributionFlows?null:c.totalContributionsEur);}
