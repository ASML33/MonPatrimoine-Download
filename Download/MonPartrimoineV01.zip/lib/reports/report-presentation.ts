import { groupUnspecifiedSlices } from "@/lib/patrimony/distribution-core";
import type { ReportExposureDistribution } from "./patrimonial-report-core";

// Shared by screen, CSV and editable Word tables, using the frozen report.
export function exposureDisplayItems(distribution: ReportExposureDistribution) {
  return groupUnspecifiedSlices(distribution.items.map(item => ({...item, amount:item.amountEur})))
    .map(({amount, ...item}) => ({...item, amountEur:amount!,
      percentage: item.unspecified || (amount! > 0 && item.percentage === 0)
        ? distribution.denominatorEur > 0 ? amount! / distribution.denominatorEur * 100 : null
        : item.percentage,
    }));
}
