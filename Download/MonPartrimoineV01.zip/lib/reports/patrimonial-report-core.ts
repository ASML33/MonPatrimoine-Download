import { historicalPruDisplay, type HistoricalPruDisplay } from "@/lib/contracts/historical-pru-display";
import { contributionCorrectionAt, contributionHistory, correctedContributions } from "@/lib/cash/contribution-corrections";
import { linksFlowsToCash } from "@/lib/cash/flow-cash";
import { resolveCtoCost } from "@/lib/contracts/cto-documented-cost";
import {envelopeNetMode,ESTIMATE_CONVENTION,prefersEnvelopeEstimate} from '@/lib/fiscal/envelope-policy';
import {calculateEnvelopeTax,type EnvelopeFiscality,type EnvelopeTaxComponent} from '@/lib/fiscal/envelope-tax-core';
import {isAmountTracked,knownFlowAnchors,resolveContractGain} from '@/lib/contracts/contract-gain';
import {mixedGeography} from "@/lib/geography/mixed-geography";
import {propertyHistory,propertyValue} from "@/lib/contracts/property-valuations";
import { selectDatedPosition,positionHistory,observationAt } from "@/lib/contracts/position-observations";
import { selectDatedBalances } from "@/lib/cash/dated-balances";
import { isContractInUserScope, visibleContracts } from "@/lib/contracts/contract-scope";
import { manualEstimate, selectManualSituation, selectManualSimulation, type ManualSituation, type ManualSimulation } from "@/lib/patrimony/manual-situation-core";
import {latestEmployeeSavingsValue,type EmployeeSavingsValue} from "@/lib/patrimony/employee-savings-values";
import { parisDate } from "@/lib/patrimony/current-valuation-core";
import { aggregateValuedThemeExposures } from "@/lib/assets/theme-aggregation-core";
import { calculateCashFlowAggregates, parisLocalDateTimeToIso } from "@/lib/cash/cash-core";
import { calculatePositionUnrealizedValue } from "@/lib/contracts/contract-detail-core";
import { convertToEur, type FxRateRecord } from "@/lib/fx/fx-core";
import {contractFiscalBinding} from '@/lib/fiscal/contract-fiscal';
import { calculateFiscalPortfolio, fiscalRuleApplication, type FiscalCalculation, type FiscalRule } from "@/lib/fiscal/fiscal-core";
import {
  freshnessAgeDays,
  isStale,
  selectLatestFxRates,
  selectLatestPositionSnapshots,
  selectLatestUsablePrices,
  STALE_THRESHOLD_DAYS,
} from "@/lib/patrimony/current-valuation-core";

export type ReportWarningCode =
  | "fiscality_unknown"
  | "price_missing"
  | "fx_missing"
  | "snapshot_fallback"
  | "unrealized_incomplete"
  | "cto_cost_conflict"
  | "cash_fx_missing"
  | "cash_observation_missing"
  | "flow_fx_missing"
  | "exposure_incomplete"
  | "theme_incomplete"
  | "stale_price"
  | "stale_fx";

export type ReportWarning = {
  code: ReportWarningCode;
  message: string;
  count: number;
};

export type ReportFreshness = {
  assetId?: string; contractId?: string; currencyCode?: string; dimension?: string;
  kind: "price" | "fx" | "cash" | "flow" | "exposure" | "theme" | "manual" | "position";
  source?: string;
  requestedOn?: string;
  eurPerUnit?: number | string;
  label: string;
  observedAt: string | null;
  obtainedAt: string | null;
  ageDays: number | null;
  stale: boolean;
};

export type ReportAllocation = {
  id: string;
  name: string;
  amountEur: number;
  percentage: number | null;
};

export type ReportExposureDistribution = {
  denominatorEur: number;
  coveredEur: number;
  coveragePercentage: number | null;
  items: Array<ReportAllocation & {
    dataDates: string[];
    sources: string[];
    unspecified?: boolean;
  }>;
  incompleteAssetIds: string[];
};

export type PatrimonialReport = {
  meta: { fiscalConsultationPolicy?:2; fiscalConvention?:string; generatedAt: string; timeZone: "Europe/Paris"; reportingCurrency: "EUR" };
  summary: {
    grossEur: number;
    netKind?: "calculated" | "approximate" | "unavailable";
    netEstimatedEur: number | null;
    grossNetDifferenceEur: number | null;
    netCoverageEur: number;
    envelopeTypeCount: number;
    contractCount: number;
    assetCount: number;
    cashEur: number;
    securitiesEur: number;
    totalContributionsEur: number;
    netCashFlowsEur: number;
    acquisitionCostEur: number;
    unrealizedGainEur: number;
    unrealizedGainPercentage: number | null;
    valuedUnrealizedPositions: number;
    incompleteUnrealizedPositions: number;
  };
  envelopeTypes: ReportEnvelopeType[];
  contracts: ReportContract[];
  assets: ReportAsset[];
  allocations: {
    envelopeTypes: ReportAllocation[];
    contracts: ReportAllocation[];
    assets: ReportAllocation[];
  };
  exposures: {
    sectors: ReportExposureDistribution;
    activities: ReportExposureDistribution;
    geography: { countries: ReportExposureDistribution; regions: ReportExposureDistribution };
    themes: ReportExposureDistribution;
  };
  quality: {
    status: "complete" | "partial" | "unavailable";
    warnings: ReportWarning[];
    freshness: ReportFreshness[];
    staleThresholdDays: number;
  };
};

export type ReportContract = { valuationUnavailable?: boolean; contractGain?:ReturnType<typeof resolveContractGain>;
  fiscalComponents?: EnvelopeTaxComponent[];
  fiscalTotals?: {irEur:number|null;psEur:number|null};
  fiscalSelection?:import('../fiscal/contract-fiscal').FiscalSelection;
  fiscalNonAdditive?: boolean;
  id: string;
  name: string;
  envelopeTypeId: string;
  envelopeTypeLabel: string;
  currencyCode: string;
  grossEur: number;
  netKind?: "calculated" | "approximate" | "unavailable";
  manualSituationAt?: string | null;
  manualSituationPrecision?: "exact" | "date" | "evening" | null;
  netEstimatedEur: number | null;
  fiscalRuleVersion: number | null;
  fiscalDetail: (FiscalCalculation & ReturnType<typeof fiscalRuleApplication>) | null;
  fiscalWarnings: string[];
  cashEur: number;
  securitiesEur: number;
  totalContributionsEur: number;
  contributionTotal?: { amountEur: number; status: "known" | "partial"; asOf?: string };
  netCashFlowsEur: number;
  acquisitionCostEur: number;
  unrealizedGainEur: number;
  unrealizedGainPercentage: number | null;
  valuedUnrealizedPositions: number;
  incompleteUnrealizedPositions: number;
  updatedAt: string | null;
  incompletePositions: number;
  incompleteCashBalances: number;
  incompleteContributionFlows: number;
  incompleteNetCashFlows: number;
};

// The numeric field is the known subtotal used by aggregates. A manual contract
// without an applicable source has no individual value, including when that
// internal subtotal is zero. A dated, explicitly known zero remains available.
export function reportContractGross(c:Pick<ReportContract,'grossEur'|'manualSituationAt'|'valuationUnavailable'>){return c.valuationUnavailable||c.manualSituationAt===null?null:c.grossEur;}
export type ReportEnvelopeType = Omit<ReportContract, "envelopeTypeId" | "envelopeTypeLabel" | "updatedAt" | "incompletePositions" | "incompleteCashBalances" | "incompleteContributionFlows" | "incompleteNetCashFlows"> & {
  contracts: ReportContract[];
};

export type ReportAssetHolding = {
  historicalPruEur?: HistoricalPruDisplay | null;
  ctoDisplayUnitEur?: number | null; valueSemantics?:"total_property"|"total_amount";
  positionId: string;
  contractId: string;
  contractName: string;
  quantity: number | null;
  averageCostPerUnit: number | null;
  nativeUnitCost?: { amount: string; asOf?: string };
  ctoHistoricalCostKind?: "documented" | "estimated";
  ctoHistoricalCostAsOf?: string;
  costCurrencyCode: string;
  valueEur: number | null;
  acquisitionCostEur: number | null;
  unrealizedGainEur: number | null;
};

export type ReportAsset = {
  id: string;
  name: string;
  symbol: string | null; isin?: string | null;
  color: string | null;
  colorOrigin?: string;
  quantity: number | null;
  valueEur: number | null;
  portfolioPercentage: number | null;
  currentPrice: number | null;
  currentPriceEur?: number | null;
  averageCostPerUnitEur?: number | null;
  priceCurrencyCode: string | null;
  priceObservedAt: string | null;
  priceObtainedAt: string | null;
  priceSource: string | null;
  averageCostPerUnit: number | null;
  averageCostCurrencyCode: string | null;
  acquisitionCostEur: number | null;
  unrealizedGainEur: number | null;
  unrealizedGainPercentage: number | null;
  holdings: ReportAssetHolding[];
};

type EnvelopeTypeRecord = { id: string; code: string; label: string };
type ContractRecord = { dashboard_tile_name?: string | null; opened_on?:string|null; fiscal_assignments?:unknown; closed_on?: string | null; valuation_source?: string; is_active?: boolean; pea_pme_standard_confirmed?: boolean; metadata?: Record<string, unknown>; id: string; envelope_type_id: string; name: string; display_name?: string | null; currency_code: string; fiscal_regime_id?: string | null; fiscal_started_on?: string | null; fiscal_history_complete?: boolean; social_contributions_paid_eur?: number | string | null };
type PositionRecord = { metadata?:unknown; id: string; contract_id: string; asset_id: string; quantity: number | string; average_cost_per_unit: number | string | null; cost_currency_code: string };
type SnapshotRecord = { unit_price?:number|string|null; position_id: string; market_value: number | string; currency_code: string; valued_at: string };
type CashRecord = { id: string; contract_id: string; amount: number | string; currency_code: string; as_of: string; metadata?: unknown; updated_at?: string };
type FlowRecord = { id: string; kind: "contribution" | "withdrawal"; destination_contract_id: string | null; source_contract_id: string | null; amount: number | string; currency_code: string; occurred_at: string; fx_rate_id: string | null; fx_status: "resolved" | "pending" | "manual_required" };
type AssetRecord = { metadata?:unknown; id: string; name: string; display_name?: string | null; symbol: string | null; isin?: string | null; color?: string | null; color_origin?: string; asset_type_code: string; currency_code: string; valuation_mode: string };
type PriceRecord = { asset_id: string; origin: "automatic" | "manual"; price: number | string; currency_code: string; observed_at: string; obtained_at: string; source_name: string | null };
type ExposureRecord = { asset_id: string; dimension: "sector" | "activity" | "geography"; reference_id: string; weight_percent: number | string; data_date: string | null; source: string | null; updated_at: string };
type ThemeExposureRecord = { asset_id: string; theme_id: string; weight_percent: number | string; data_date: string | null; source: string | null; updated_at: string };

export type PatrimonialReportRecords = {
  envelopeTypes: EnvelopeTypeRecord[];
  contracts: ContractRecord[];
  positions: PositionRecord[];
  positionSnapshots: SnapshotRecord[];
  cashBalances: CashRecord[];
  cashFlows: FlowRecord[];
  assets: AssetRecord[];
  prices: PriceRecord[];
  currentFxRates: FxRateRecord[];
  historicalFxRates: FxRateRecord[];
  exposures: ExposureRecord[];
  sectors: Array<{ id: string; name: string; code?: string }>;
  activities: Array<{ id: string; name: string }>;
  countries: Array<{ id: string; name: string; code?: string; region_code: string }>;
  regions: Array<{ code: string; name: string }>;
  themes: Array<{ id: string; name: string; is_active: boolean }>;
  themeExposures: ThemeExposureRecord[];
  envelopeFiscalities?: EnvelopeFiscality[];
  fiscalConsultationPolicy?: 2;
  fiscalRules?: FiscalRule[];
  fiscalPreferences?: Array<{ fiscalRegimeId: string; usePersonalRule: boolean }>;
  userId?: string;
  manualSituations?: ManualSituation[];
  employeeSavingsValuations?:EmployeeSavingsValue[];
  employeeSavingsSources?:import("@/lib/patrimony/historical-observations").HistoricalSource[];
  manualSimulations?: ManualSimulation[];
};

type ContractAccumulator = ReportContract & {
  unrealizedCost: number;
  fiscalRegimeId: string | null;
  fiscalStartedOn: string | null;
  fiscalHistoryComplete: boolean;
  socialContributionsPaidEur: number | null;
};

function contractReport(accumulator: ContractAccumulator): ReportContract {
  const view = { ...accumulator } as Partial<ContractAccumulator>;
  delete view.unrealizedCost;
  delete view.fiscalRegimeId;
  delete view.fiscalStartedOn;
  delete view.fiscalHistoryComplete;
  delete view.socialContributionsPaidEur;
  return view as ReportContract;
}

function addWarning(target: Map<ReportWarningCode, ReportWarning>, code: ReportWarningCode, message: string, count = 1) {
  const current = target.get(code);
  target.set(code, { code, message, count: (current?.count ?? 0) + count });
}

export function percentage(amount: number, denominator: number) {
  return denominator > 0 ? amount / denominator * 100 : null;
}

function newest(current: string | null, candidate: string | null | undefined) {
  if (!candidate || !Number.isFinite(Date.parse(candidate))) return current;
  return current === null || Date.parse(candidate) > Date.parse(current) ? candidate : current;
}

function distribution(
  valueByAsset: Map<string, number>,
  rows: Array<{ assetId: string; referenceId: string; weight: number; dataDate: string | null; source: string | null }>,
  labels: Map<string, string>,
  allAssetIds: string[],
  unknownReferences = new Set<string>(),
): ReportExposureDistribution {
  const denominatorEur = [...valueByAsset.values()].reduce((sum, value) => sum + value, 0);
  const amounts = new Map<string, number>();
  const dates = new Map<string, Set<string>>();
  const sources = new Map<string, Set<string>>();
  const weightByAsset = new Map<string, number>();
  for (const row of rows) {
    const assetValue = valueByAsset.get(row.assetId);
    if (assetValue === undefined || !labels.has(row.referenceId) || !Number.isFinite(row.weight) || row.weight <= 0) continue;
    amounts.set(row.referenceId, (amounts.get(row.referenceId) ?? 0) + assetValue * row.weight / 100);
    if (!unknownReferences.has(row.referenceId)) weightByAsset.set(row.assetId, (weightByAsset.get(row.assetId) ?? 0) + row.weight);
    if (row.dataDate) (dates.get(row.referenceId) ?? dates.set(row.referenceId, new Set()).get(row.referenceId)!).add(row.dataDate);
    if (row.source) (sources.get(row.referenceId) ?? sources.set(row.referenceId, new Set()).get(row.referenceId)!).add(row.source);
  }
  const coveredEur = [...valueByAsset].reduce((sum, [assetId, value]) => sum + value * Math.min(weightByAsset.get(assetId) ?? 0, 100) / 100, 0);
  const incompleteAssetIds = allAssetIds.filter((assetId) => !valueByAsset.has(assetId) || Math.round((weightByAsset.get(assetId) ?? 0) * 100) / 100 !== 100);
  const rounded = !incompleteAssetIds.length && Math.abs([...amounts.values()].reduce((sum, amount) => sum + amount, 0) - denominatorEur) < .005
    ? roundedPercentages([...amounts].map(([id, amount]) => ({ id, amount }))) : null;
  return {
    denominatorEur,
    coveredEur,
    coveragePercentage: percentage(coveredEur, denominatorEur),
    items: [...amounts].map(([id, amountEur]) => ({
      id,
      name: labels.get(id) ?? id,
      ...(unknownReferences.has(id) ? {unspecified:true} : {}),
      amountEur,
      percentage: rounded?.get(id) ?? percentage(amountEur, denominatorEur),
      dataDates: [...(dates.get(id) ?? [])].sort(),
      sources: [...(sources.get(id) ?? [])].sort(),
    })).sort((left, right) => right.amountEur - left.amountEur || left.name.localeCompare(right.name, "fr")),
    incompleteAssetIds,
  };
}

export function buildPatrimonialReport(records: PatrimonialReportRecords, generatedAt = new Date().toISOString(), businessDate = parisDate(generatedAt), includeDisplayPru = false): PatrimonialReport {
  const lifeInsuranceTypes = new Set(records.envelopeTypes.filter(type=>type.code==='assurance_vie').map(type=>type.id));
  const lifeInsuranceIds = new Set(records.contracts.filter(contract=>lifeInsuranceTypes.has(contract.envelope_type_id)).map(contract=>contract.id));
  const liquidTypes = new Set(records.envelopeTypes.filter(type=>type.code==='epargne_liquide').map(type=>type.id));
  const liquidIds = new Set(records.contracts.filter(contract=>liquidTypes.has(contract.envelope_type_id)).map(contract=>contract.id));
  const valuationAt=parisDate(generatedAt)>businessDate
    ?new Date(Date.parse(parisLocalDateTimeToIso(businessDate+'T23:59'))+59999).toISOString():generatedAt;
  records = { ...records, contracts: visibleContracts(records.contracts),
    positions: records.positions.filter((p) => isContractInUserScope(p.contract_id) && !liquidIds.has(p.contract_id)).map(p=>selectDatedPosition(p,businessDate)),
    cashBalances: selectDatedBalances(records.cashBalances.filter((b) => isContractInUserScope(b.contract_id) && !lifeInsuranceIds.has(b.contract_id)), valuationAt),
    cashFlows: records.cashFlows.filter((f) => (f.kind==='contribution'||f.kind==='withdrawal') && Date.parse(f.occurred_at)<=Date.parse(generatedAt) && parisDate(f.occurred_at)<=businessDate && (!f.source_contract_id || isContractInUserScope(f.source_contract_id)) && (!f.destination_contract_id || isContractInUserScope(f.destination_contract_id))),
  };
  const warnings = new Map<ReportWarningCode, ReportWarning>();
  const freshness: ReportFreshness[] = [];
  const assetById = new Map(records.assets.map((asset) => [asset.id, asset]));
  const envelopeTypeById = new Map(records.envelopeTypes.map((type) => [type.id, type]));
  const latestPrices = selectLatestUsablePrices(records.assets, records.prices, valuationAt);
  const latestSnapshots = selectLatestPositionSnapshots(records.positionSnapshots, valuationAt);
  const currentRates = selectLatestFxRates(records.currentFxRates, valuationAt);
  const historicalRates = new Map(records.historicalFxRates.flatMap((rate) => rate.id ? [[rate.id, rate] as const] : []));
  const valueByAsset = new Map<string, number>();
  const holdingsByAsset = new Map<string, ReportAssetHolding[]>();

  const contracts = new Map<string, ContractAccumulator>();
  for (const contract of records.contracts) {
    const envelopeType = envelopeTypeById.get(contract.envelope_type_id);
    if (!envelopeType) continue;
    contracts.set(contract.id, {
      id: contract.id, name: contract.display_name?.trim() || contract.name, envelopeTypeId: envelopeType.id, envelopeTypeLabel: envelopeType.label, currencyCode: contract.currency_code,
      grossEur: 0, netEstimatedEur: null, cashEur: 0, securitiesEur: 0,
      fiscalRuleVersion: null, fiscalWarnings: [], fiscalDetail: null,
      totalContributionsEur: 0, netCashFlowsEur: 0, acquisitionCostEur: 0,
      unrealizedGainEur: 0, unrealizedGainPercentage: null,
      valuedUnrealizedPositions: 0, incompleteUnrealizedPositions: 0,
      updatedAt: null, incompletePositions: 0, incompleteCashBalances: 0,
      incompleteContributionFlows: 0, incompleteNetCashFlows: 0, unrealizedCost: 0,
      fiscalRegimeId: contract.fiscal_regime_id ?? null,
      fiscalStartedOn: contract.fiscal_started_on ?? null,
      fiscalHistoryComplete: contract.fiscal_history_complete === true,
      socialContributionsPaidEur: contract.social_contributions_paid_eur === null || contract.social_contributions_paid_eur === undefined ? null : Number(contract.social_contributions_paid_eur),
    });
  }

  const manualIds = new Set(records.contracts.filter((c) => c.valuation_source === "manual_situation" && !liquidIds.has(c.id)).map((c) => c.id));
  const brokerEstimateContracts = new Set<string>();
  for (const position of records.positions) {
    if (manualIds.has(position.contract_id)) continue;
    const contract = contracts.get(position.contract_id);
    const asset = assetById.get(position.asset_id);
    if (!contract) continue;
    if (!asset) { contract.incompletePositions++; addWarning(warnings, "price_missing", "Actif lié indisponible : brut partiel."); continue; }
    const holdingHistory=positionHistory(position.metadata);const observation=holdingHistory?observationAt(holdingHistory.entries,businessDate):null;
    if(observation)freshness.push({kind:"position",assetId:asset.id,contractId:contract.id,label:`${asset.name} · situation de détention`,observedAt:observation.effectiveOn,obtainedAt:observation.recordedAt,ageDays:null,stale:false,source:observation.provenance});
    const property=asset.asset_type_code==="real_estate";
    const propertyValuation=propertyHistory(position.metadata)?propertyValue(position.metadata,businessDate,records.currentFxRates):null;
    const amountTracked=asset.asset_type_code!=='real_estate'&&isAmountTracked(asset.valuation_mode,!!latestPrices.get(position.asset_id),!!holdingHistory,latestSnapshots.get(position.id),position.metadata);
    const quantity = position.quantity==null?NaN:Number(position.quantity);
    if(propertyValuation?.ended)continue;
    if(!amountTracked&&quantity===0)continue;
    const price = latestPrices.get(position.asset_id);
    const snapshot = latestSnapshots.get(position.id);
    let valueEur: number | null = null;
    if(propertyValuation){
      valueEur=propertyValuation.amountEur;
      freshness.push({kind:"manual",assetId:asset.id,contractId:contract.id,label:asset.name,observedAt:propertyValuation.observation?.effectiveOn??null,obtainedAt:propertyValuation.observation?.recordedAt??null,ageDays:null,stale:false,source:propertyValuation.observation?.provenance});
      if(valueEur===null)addWarning(warnings,"fx_missing","Estimation immobilière ou conversion EUR indisponible.");
    } else if (price && !property) {
      valueEur = convertToEur(quantity * Number(price.price), price.currency_code, currentRates.get(price.currency_code)).amountEur;
      if (price.currency_code !== "EUR" && valueEur === null) addWarning(warnings, "fx_missing", "Certains titres ne disposent pas d’un taux FX courant exploitable.");
      const ageDays = freshnessAgeDays(price.observed_at, generatedAt);
      const stale = isStale(price.observed_at, generatedAt);
      freshness.push({ kind: "price", assetId: asset.id, label: asset.name, observedAt: price.observed_at, obtainedAt: price.obtained_at, ageDays, stale });
      if (stale) addWarning(warnings, "stale_price", `Certains prix datent de plus de ${STALE_THRESHOLD_DAYS} jours.`);
      if (price.origin === "automatic") contract.updatedAt = newest(contract.updatedAt, price.obtained_at);
    } else if (snapshot && !positionHistory(position.metadata)) {
      valueEur = convertToEur(snapshot.market_value, snapshot.currency_code, currentRates.get(snapshot.currency_code)).amountEur;
      addWarning(warnings, "snapshot_fallback", "Une ou plusieurs positions utilisent leur dernier snapshot disponible.");
    } else {
      addWarning(warnings, "price_missing", "Certaines positions ne disposent d’aucun prix ou snapshot utilisable.");
    }
    if (valueEur === null || !Number.isFinite(valueEur)) contract.incompletePositions += 1;
    else {
      contract.securitiesEur += valueEur;
      valueByAsset.set(asset.id, (valueByAsset.get(asset.id) ?? 0) + valueEur);
    }

    const averageCost = property || amountTracked || position.average_cost_per_unit == null ? null : Number(position.average_cost_per_unit);
    const day = parisDate(valuationAt);
    const isCto = ["cto", "compte_titres"].includes(envelopeTypeById.get(contract.envelopeTypeId)?.code ?? "");
    const costObservation = holdingHistory ? observationAt(holdingHistory.entries, day) : null;
    const legacy = averageCost === null ? null : convertToEur(averageCost, position.cost_currency_code, currentRates.get(position.cost_currency_code)).amountEur;
    const ctoCost = isCto ? resolveCtoCost({ metadata: position.metadata, observation: costObservation,
      native: position.average_cost_per_unit, currency: position.cost_currency_code, day, quantity, legacyUnit: legacy }) : null;
    if (ctoCost?.conflict) addWarning(warnings, "cto_cost_conflict", "Des preuves de coût CTO applicables se contredisent.");
    if (ctoCost?.estimated) brokerEstimateContracts.add(contract.id);
    const acquisitionCostEur = ctoCost ? ctoCost.total : averageCost === null ? null :
      convertToEur(quantity * averageCost, position.cost_currency_code, currentRates.get(position.cost_currency_code)).amountEur;
    const latent = calculatePositionUnrealizedValue({ acquisitionCostEur, marketValueEur: valueEur });
    if (!amountTracked && (latent.acquisitionCostEur === null || latent.unrealizedGainEur === null)) {
      contract.incompleteUnrealizedPositions += 1;
      addWarning(warnings, "unrealized_incomplete", "Certaines plus-values latentes ne peuvent pas être calculées.");
    } else if (!amountTracked && latent.acquisitionCostEur !== null && latent.unrealizedGainEur !== null) {
      contract.acquisitionCostEur += latent.acquisitionCostEur;
      contract.unrealizedCost += latent.acquisitionCostEur;
      contract.unrealizedGainEur += latent.unrealizedGainEur;
      contract.valuedUnrealizedPositions += 1;
    }
    const holding: ReportAssetHolding = {
      valueSemantics:property?"total_property":amountTracked?"total_amount":undefined,positionId: position.id, contractId: contract.id, contractName: contract.name,
      quantity:amountTracked||!Number.isFinite(quantity)?null:quantity, averageCostPerUnit: averageCost, costCurrencyCode: position.cost_currency_code,
      valueEur, acquisitionCostEur: ctoCost ? ctoCost.total : latent.acquisitionCostEur, unrealizedGainEur: latent.unrealizedGainEur,
      ...(averageCost !== null && Number.isFinite(averageCost) && averageCost >= 0 && position.average_cost_per_unit !== null
        ? { nativeUnitCost: { amount: String(position.average_cost_per_unit), asOf: observation?.effectiveOn } } : {}),
      ...(includeDisplayPru && ctoCost ? { historicalPruEur: historicalPruDisplay(ctoCost, {
        metadata: position.metadata, native: position.average_cost_per_unit, currency: position.cost_currency_code, day, quantity,
      }) } : {}),
      ...(ctoCost ? { ctoDisplayUnitEur: ctoCost.displayUnit,
        ctoHistoricalCostKind: ctoCost.documented ? "documented" : ctoCost.estimated ? "estimated" : undefined,
        ctoHistoricalCostAsOf: ctoCost.documentedOn } : {}),
    };
    holdingsByAsset.set(asset.id, [...(holdingsByAsset.get(asset.id) ?? []), holding]);
  }

  for (const balance of records.cashBalances) {
    if (manualIds.has(balance.contract_id)) continue;
    const contract = contracts.get(balance.contract_id);
    if (!contract) continue;
    const rate = currentRates.get(balance.currency_code);
    const amountEur = convertToEur(balance.amount, balance.currency_code, rate).amountEur;
    freshness.push({ kind: "cash", contractId: contract.id, currencyCode: balance.currency_code, label: `${contract.name} · ${balance.currency_code}`, observedAt: balance.as_of, obtainedAt: null, ageDays: freshnessAgeDays(balance.as_of, generatedAt), stale: false });
    if (amountEur === null) {
      contract.incompleteCashBalances += 1;
      addWarning(warnings, "cash_fx_missing", "Certains soldes espèces ne disposent pas d’une conversion EUR exploitable.");
    } else contract.cashEur += amountEur;
  }

  // A missing liquid balance is not an explicitly observed zero. The numeric
  // aggregate remains a known subtotal; completeness and individual value differ.
  for (const contract of contracts.values()) {
    if (!manualIds.has(contract.id) && envelopeTypeById.get(contract.envelopeTypeId)?.code !== "epargne_liquide"
      && !records.positions.some(p => p.contract_id === contract.id)
      && !records.cashBalances.some(b => b.contract_id === contract.id)) {
      contract.valuationUnavailable = true;
      contract.incompletePositions += 1;
      addWarning(warnings, "price_missing", "Un contrat sans observation n’a pas de valorisation connue ; aucune valeur nulle présumée.");
    }
    if (envelopeTypeById.get(contract.envelopeTypeId)?.code === "epargne_liquide" && !manualIds.has(contract.id)
      && !records.cashBalances.some(b => b.contract_id === contract.id)) {
      contract.valuationUnavailable = true;
      contract.incompleteCashBalances += 1;
      addWarning(warnings, "cash_observation_missing", "Un solde d’épargne liquide n’est pas renseigné. [CASH-NO-OBSERVATION]");
    }
  }

  const flowsByContract = new Map<string, Array<{ id: string; date: string; kind: "contribution" | "withdrawal"; amountEur: number | null }>>();
  for (const flow of records.cashFlows) {
    if (records.fiscalConsultationPolicy===2 && parisDate(flow.occurred_at)>businessDate) continue;
    const contractId = flow.kind === "contribution" ? flow.destination_contract_id : flow.source_contract_id;
    const contract = contractId ? contracts.get(contractId) : null;
    if (!contract) continue;
    const rate = flow.fx_rate_id ? historicalRates.get(flow.fx_rate_id) : null;
    const amountEur = convertToEur(flow.amount, flow.currency_code, rate).amountEur;
    if (amountEur === null && flow.currency_code !== "EUR") addWarning(warnings, "flow_fx_missing", "Certains flux ne disposent pas de leur conversion EUR historique.");
    flowsByContract.set(contract.id, [...(flowsByContract.get(contract.id) ?? []), { id: flow.id, date: parisDate(flow.occurred_at), kind: flow.kind, amountEur }]);
    freshness.push({ kind: "flow", label: `${contract.name} · ${flow.currency_code}`, observedAt: flow.occurred_at, obtainedAt: null, ageDays: freshnessAgeDays(flow.occurred_at, generatedAt), stale: false });
  }

  for (const contract of contracts.values()) {
    const flows = flowsByContract.get(contract.id) ?? [];
    const flowAggregate = calculateCashFlowAggregates(flows);
    Object.assign(contract, flowAggregate);
    const original = records.contracts.find((row) => row.id === contract.id);
    const knownContribution = knownFlowAnchors(original?.metadata??{},businessDate).contribution;
    if (knownContribution!==null && knownContribution >= 0) contract.totalContributionsEur = knownContribution;
    try {
      const code = envelopeTypeById.get(contract.envelopeTypeId)?.code ?? "";
      const contributions = flows.filter(flow => flow.kind === "contribution" && flow.amountEur !== null);
      const latestContribution = contributions.map(flow => flow.date).sort().at(-1);
      const declaredDate = original?.metadata?.knownTotalContributionsAsOf;
      const declared = knownContribution !== null && knownContribution >= 0;
      const history = linksFlowsToCash(code) || code === "assurance_vie" ? contributionHistory(original?.metadata) : null;
      const correction = history ? contributionCorrectionAt(history, businessDate) : undefined;
      if (correction && history) {
        const amountEur = correctedContributions(null, businessDate, history, flows);
        if (amountEur !== null && Number.isFinite(amountEur) && amountEur >= 0) {
          const latestAdded = contributions.filter(flow => !correction.flowIds.includes(flow.id)).map(flow => flow.date).sort().at(-1);
          contract.contributionTotal = { amountEur, status: "known", asOf: latestAdded && latestAdded > correction.date ? latestAdded : correction.date };
        }
      } else if (declared) {
        contract.contributionTotal = { amountEur: knownContribution, status: "known", asOf: typeof declaredDate === "string" ? declaredDate : undefined };
      } else if (contributions.length) {
        contract.contributionTotal = { amountEur: flowAggregate.totalContributionsEur, status: flowAggregate.incompleteContributionFlows ? "partial" : "known", asOf: latestContribution };
      }
    } catch {
      // Unusable contribution evidence must not interrupt the shared report.
      contract.contributionTotal = undefined;
    }
    const knownNetCashFlows = knownFlowAnchors(original?.metadata??{},businessDate).net;
    if (knownNetCashFlows!==null) contract.netCashFlowsEur = knownNetCashFlows;
    contract.grossEur = contract.securitiesEur + contract.cashEur;
    contract.unrealizedGainPercentage = percentage(contract.unrealizedGainEur, contract.unrealizedCost);
  }

  for (const contract of contracts.values()) {
    if (!manualIds.has(contract.id)) continue;
    if(records.employeeSavingsValuations){
      const value=latestEmployeeSavingsValue(records.employeeSavingsValuations,contract.id,generatedAt);
      contract.grossEur=value?Number(value.gross):0;contract.netEstimatedEur=value?.net==null?null:Number(value.net);
      contract.netKind=contract.netEstimatedEur===null?"unavailable":"approximate";
      contract.manualSituationAt=value?.date??null;contract.manualSituationPrecision=value?.precision??null;
      contract.fiscalWarnings=[value?`${value.provenance} · valeur du ${value.date}. ${value.net===null?"NET non fourni ; aucun ancien NET ni calcul fiscal repris.":"NET déclaré par l’utilisateur, non calculé ni certifié."}`:"Aucune observation individuelle disponible."];
      contract.fiscalRuleVersion=null;if(!value)contract.incompletePositions++;continue;
    }
    const situation = selectManualSituation(records.manualSituations ?? [], contract.id, generatedAt);
    const simulation = selectManualSimulation(records.manualSimulations ?? [], contract.id, businessDate, generatedAt);
    const estimate = manualEstimate(situation, simulation);
    contract.grossEur = estimate.grossEur ?? 0;
    contract.netEstimatedEur = estimate.netEstimatedEur;
    contract.netKind = estimate.netKind;
    contract.manualSituationAt = situation?.situated_at ?? null;
    contract.manualSituationPrecision = situation?.source_time_precision ?? null;
    contract.fiscalWarnings = [estimate.notice, ...(estimate.reason ? [estimate.reason] : [])];
    contract.fiscalRuleVersion = simulation?.version ?? null;
    if (estimate.grossEur === null) contract.incompletePositions++;
  }
  const calculationDate = businessDate;
  if(records.envelopeFiscalities!==undefined){
    for(const contract of contracts.values()){
      const original=records.contracts.find(c=>c.id===contract.id)!;
      const code=envelopeTypeById.get(original.envelope_type_id)?.code;
      const mode=envelopeNetMode(code??'');
      if(mode==='absent'){contract.netEstimatedEur=null;contract.netKind='unavailable';contract.fiscalWarnings=['BRUT uniquement : NET volontairement absent. [REF-NET-ABSENT]'];continue;}
      if(mode==='manual'){
        if(!manualIds.has(contract.id)){contract.netEstimatedEur=null;contract.netKind='unavailable';contract.fiscalWarnings=['NET manuel qualifié à sa source et sa date requis. [REF-NET-MANUAL]'];}
        else if(records.employeeSavingsValuations===undefined){const source=selectManualSituation(records.manualSituations??[],contract.id,generatedAt);const net=source?.source_net_eur==null?null:Number(source.source_net_eur);contract.netEstimatedEur=net!==null&&Number.isFinite(net)&&net>=0?net:null;contract.netKind=contract.netEstimatedEur===null?'unavailable':'approximate';contract.fiscalWarnings=[contract.netEstimatedEur===null?'NET manuel non fourni. [REF-NET-MANUAL]':`NET manuel de la source ${source!.source}, au ${source!.situated_at} ; aucun calcul fiscal.`];}
        continue;
      }
      if(mode==='gross'){contract.netEstimatedEur=null;contract.netKind='unavailable';if(!contract.incompletePositions&&!contract.incompleteCashBalances){contract.netEstimatedEur=contract.grossEur;contract.netKind='calculated';contract.fiscalWarnings=[code==='immobilier'?'Convention immobilière MonPatrimoine : NET = BRUT connu, sans exonération fiscale déduite.':'Épargne liquide : NET = BRUT, sans calcul fiscal.'];}continue;}
      if(manualIds.has(contract.id))continue;
      const rawNet=original.metadata?.knownLiquidationNetEur;
      const qualifiedSourceNet=(typeof rawNet==='number'||typeof rawNet==='string'&&rawNet.trim()!=='')&&Number.isFinite(Number(rawNet))&&Number(rawNet)>=0;
      if(!(records.fiscalConsultationPolicy===2&&prefersEnvelopeEstimate(code??''))&&qualifiedSourceNet&&!contract.incompletePositions&&!contract.incompleteCashBalances){contract.netEstimatedEur=Number(rawNet);contract.netKind='calculated';contract.fiscalWarnings=['NET fourni par une source contractuelle qualifiée ; aucun impôt déduit une seconde fois.'];continue;}
      if(contract.incompletePositions||contract.incompleteCashBalances){contract.fiscalWarnings=['BRUT partiel : calcul NET indisponible.'];continue;}
      if(code==='pea_pme'&&!original.pea_pme_standard_confirmed){contract.fiscalWarnings=['Périmètre des titres ordinaires PEA-PME non confirmé.'];continue;}
      const qualifiedGain=resolveContractGain(contract.grossEur,flowsByContract.get(contract.id)??[],original.metadata??{},businessDate);
      const input={periodPolicy:records.fiscalConsultationPolicy===2?'bounds' as const:'legacy' as const,calculationDate,envelopeCode:code,positions:[...holdingsByAsset.values()].flat().filter(h=>h.contractId===contract.id).map(h=>({id:h.positionId,grossEur:h.valueEur,unrealizedGainEur:h.valueSemantics?null:h.unrealizedGainEur})),openedOn:original.opened_on,fiscalStartedOn:contract.fiscalStartedOn,grossEur:contract.grossEur,unrealizedGainEur:contract.incompleteUnrealizedPositions||!contract.valuedUnrealizedPositions||[...holdingsByAsset.values()].some(hs=>hs.some(h=>h.contractId===contract.id&&h.valueSemantics==='total_amount'))?null:contract.unrealizedGainEur,netCashFlowsEur:records.fiscalConsultationPolicy===2&&prefersEnvelopeEstimate(code??'')?(qualifiedGain.amount===null?null:contract.grossEur-qualifiedGain.amount):contract.incompleteNetCashFlows?null:contract.netCashFlowsEur,interestGainEur:null,socialContributionsPaidEur:contract.socialContributionsPaidEur,historyComplete:contract.fiscalHistoryComplete};
      const result=calculateEnvelopeTax(records.envelopeFiscalities,records.fiscalRules??[],original.envelope_type_id,input);
      contract.netEstimatedEur=result.netEstimatedEur;contract.netKind=result.status==='complete'?'calculated':'unavailable';contract.fiscalWarnings=result.warnings;
      if(records.fiscalConsultationPolicy===2&&prefersEnvelopeEstimate(code??''))contract.fiscalWarnings=[...result.warnings,result.status==='complete'?'NET estimé calculé selon la règle de l’enveloppe.':'Estimation NET indisponible ; aucune valeur source substituée au calcul.',...(qualifiedSourceNet?[`NET source conservé : ${String(rawNet)} EUR · date ${String(original.metadata?.knownLiquidationNetAsOf??'non documentée')} ; preuve distincte, non additionnée.`]:[])];
      contract.fiscalComponents=result.components;contract.fiscalTotals={irEur:result.irEur,psEur:result.psEur};contract.fiscalDetail=null;contract.fiscalRuleVersion=result.components.length===1?result.components[0].ruleVersion:null;
      contract.fiscalSelection={ruleId:result.components.length===1?result.components[0].ruleId:null,regimeId:null,assignmentId:null,assignmentDate:null,origin:'envelope',context:{fiscalStartedOn:contract.fiscalStartedOn,historyComplete:contract.fiscalHistoryComplete,socialContributionsPaidEur:contract.socialContributionsPaidEur}};
      if(result.components.length===1)contract.fiscalDetail=result.components[0];
    }
  }else{
  const preferenceByRegime = new Map((records.fiscalPreferences ?? []).map((item) => [item.fiscalRegimeId, item.usePersonalRule]));
  const fiscalInputs = [...contracts.values()].flatMap((contract) => {
    const original = records.contracts.find((c) => c.id === contract.id)!;
    const envelopeCode = envelopeTypeById.get(original.envelope_type_id)?.code;
    const binding=contractFiscalBinding(records.fiscalRules??[],original.fiscal_assignments,calculationDate,records.userId??'',{regimeId:contract.fiscalRegimeId,usePersonalRule:contract.fiscalRegimeId?preferenceByRegime.get(contract.fiscalRegimeId)===true:false,context:{fiscalStartedOn:contract.fiscalStartedOn,historyComplete:contract.fiscalHistoryComplete,socialContributionsPaidEur:contract.socialContributionsPaidEur}});
    if(original.fiscal_assignments)contract.fiscalSelection={ruleId:binding.rule?.id??null,regimeId:binding.regimeId,assignmentId:binding.assignment?.id??null,assignmentDate:binding.assignment?.date??null,origin:binding.origin,context:binding.context};
    if (envelopeCode === "immobilier"&&binding.origin!=='dated') {
      if (!contract.incompletePositions && !contract.incompleteCashBalances) {
        contract.netEstimatedEur = contract.grossEur;
        contract.netKind = "calculated";
        contract.fiscalWarnings = ["Convention MonPatrimoine : net égal au brut de l’estimation immobilière connue. Ce n’est pas une exonération fiscale réelle ; la variation d’estimation n’est pas une base fiscale."];
      }
      return [];
    }
    const knownLiquidationNet = Number(original.metadata?.knownLiquidationNetEur);
    if (Number.isFinite(knownLiquidationNet) && knownLiquidationNet >= 0 && !contract.incompletePositions && !contract.incompleteCashBalances) {
      contract.netEstimatedEur = knownLiquidationNet;
      contract.netKind = "calculated";
      contract.fiscalWarnings = ["Net confirmé à partir des données contractuelles connues ; aucune règle fiscale générale n’est déduite."];
      return [];
    }
    if (!binding.regimeId || !records.userId || manualIds.has(contract.id)) return [];
    if (contract.incompletePositions || contract.incompleteCashBalances) {
      contract.fiscalWarnings = ["Brut partiel : net indisponible."]; return [];
    }
    if (envelopeCode === "pea_pme" && !original.pea_pme_standard_confirmed) {
      contract.fiscalWarnings = ["PEA-PME : couverture des titres ordinaires non confirmée ; cas particuliers non calculés."]; return [];
    }
    const rule = binding.rule;
    if (!rule) return [];
    return [{
      id: contract.id,
      rule,
      input: {
        calculationDate,
        fiscalStartedOn: binding.context.fiscalStartedOn,
        grossEur: contract.grossEur,
        unrealizedGainEur: contract.incompleteUnrealizedPositions || !contract.valuedUnrealizedPositions || [...holdingsByAsset.values()].some(hs=>hs.some(h=>h.contractId===contract.id&&h.valueSemantics==="total_amount")) ? null : contract.unrealizedGainEur,
        netCashFlowsEur: contract.incompleteNetCashFlows ? null : contract.netCashFlowsEur,
        interestGainEur: null,
        socialContributionsPaidEur: binding.context.socialContributionsPaidEur,
        historyComplete: binding.context.historyComplete,
      },
    }];
  });
  for (const result of calculateFiscalPortfolio(fiscalInputs)) {
    const contract = contracts.get(result.id)!;
    const applied = fiscalInputs.find((item) => item.id === result.id)!;
    contract.fiscalDetail = { ...result, ...fiscalRuleApplication(applied.rule, applied.input.fiscalStartedOn, calculationDate) };
    contract.fiscalNonAdditive = applied.rule.irAllowanceScope === "household_annual";
    contract.netEstimatedEur = result.netEstimatedEur;
    contract.netKind = result.netEstimatedEur === null ? "unavailable" : "calculated";
    contract.fiscalRuleVersion = result.ruleVersion;
    contract.fiscalWarnings = [...result.warnings,...(contract.fiscalSelection?[`Référence fiscale : ${applied.rule.name??'version '+applied.rule.versionNumber} · règle ${applied.rule.id} · disponible le ${applied.rule.effectiveFrom} · ${contract.fiscalSelection.assignmentDate?'affectation explicite du '+contract.fiscalSelection.assignmentDate+' ('+contract.fiscalSelection.assignmentId+')':'références antérieures figées, origine d’affectation non documentée'}.`]:[])];
  }
  }
  for (const contract of contracts.values()) {
    if (contract.netEstimatedEur === null) {
      if (!contract.fiscalWarnings.length) contract.fiscalWarnings = ["Régime fiscal ou règle vérifiée applicable manquant : net indisponible."];
      addWarning(warnings, "fiscality_unknown", `Fiscalité incomplète pour ${contract.name}.`);
    }
    if (brokerEstimateContracts.has(contract.id) && contract.netEstimatedEur !== null) {
      contract.netKind = "approximate";
      contract.fiscalWarnings.push("Coût EUR estimé aux références historiques d’acquisition du relevé courtier ; contre-valeur EUR réellement payée non certifiée.");
    }
  }
  if (!contracts.size) addWarning(warnings, "fiscality_unknown", "Aucun périmètre fiscal calculable n’est disponible.");

  const reportAssets: ReportAsset[] = [...holdingsByAsset].map(([assetId, holdings]) => {
    const asset = assetById.get(assetId)!;
    const price = latestPrices.get(assetId);
    const valueEur = valueByAsset.get(assetId) ?? null;
    const completeHoldings = holdings.filter((holding) => holding.acquisitionCostEur !== null && holding.unrealizedGainEur !== null);
    const acquisitionCostEur = completeHoldings.length ? completeHoldings.reduce((sum, holding) => sum + holding.acquisitionCostEur!, 0) : null;
    const unrealizedGainEur = completeHoldings.length ? completeHoldings.reduce((sum, holding) => sum + holding.unrealizedGainEur!, 0) : null;
    const costCurrencies = new Set(holdings.filter((holding) => holding.averageCostPerUnit !== null).map((holding) => holding.costCurrencyCode));
    const costQuantity = holdings.filter((holding) => holding.averageCostPerUnit !== null).reduce((sum, holding) => sum + holding.quantity!, 0);
    const averageCostPerUnit = costCurrencies.size === 1 && costQuantity > 0
      ? holdings.reduce((sum, holding) => sum + (holding.averageCostPerUnit ?? 0) * holding.quantity!, 0) / costQuantity
      : null;
    return {
      id: asset.id, name: asset.display_name?.trim() || asset.name, symbol: asset.symbol, isin: asset.isin ?? null, color: asset.color ?? null, colorOrigin: asset.color_origin,
      quantity: holdings.some(h=>h.quantity===null)?null:holdings.reduce((sum, holding) => sum + holding.quantity!, 0), valueEur,
      portfolioPercentage: null, currentPrice: price ? Number(price.price) : null,
      currentPriceEur: price ? convertToEur(price.price, price.currency_code, currentRates.get(price.currency_code)).amountEur : null,
      averageCostPerUnitEur: completeHoldings.length === holdings.length && acquisitionCostEur !== null && holdings.reduce((sum,h) => sum+h.quantity!,0) > 0 ? acquisitionCostEur / holdings.reduce((sum,h) => sum+h.quantity!,0) : null,
      priceCurrencyCode: price?.currency_code ?? null, priceObservedAt: price?.observed_at ?? null,
      priceObtainedAt: price?.obtained_at ?? null, priceSource: price?.source_name ?? null,
      averageCostPerUnit, averageCostCurrencyCode: costCurrencies.size === 1 ? [...costCurrencies][0] : null,
      acquisitionCostEur, unrealizedGainEur,
      unrealizedGainPercentage: acquisitionCostEur && unrealizedGainEur !== null ? percentage(unrealizedGainEur, acquisitionCostEur) : null,
      holdings,
    };
  });

  const envelopeTypeReports: ReportEnvelopeType[] = records.envelopeTypes.map((envelopeType) => {
    const children = records.contracts.filter((contract) => contract.envelope_type_id === envelopeType.id).flatMap((contract) => {
      const item = contracts.get(contract.id);
      if (!item) return [];
      return [contractReport(item)];
    });
    const acquisitionCostEur = children.reduce((sum, child) => sum + child.acquisitionCostEur, 0);
    const unrealizedGainEur = children.reduce((sum, child) => sum + child.unrealizedGainEur, 0);
    return {
      id: envelopeType.id, name: envelopeType.label, currencyCode: "EUR",
      grossEur: children.reduce((sum, child) => sum + child.grossEur, 0),
      netEstimatedEur: children.every((child) => child.netEstimatedEur !== null) ? children.reduce((sum, child) => sum + child.netEstimatedEur!, 0) : null,
      fiscalRuleVersion: null, fiscalWarnings: children.flatMap((child) => child.fiscalWarnings), fiscalDetail: null,
      cashEur: children.reduce((sum, child) => sum + child.cashEur, 0), securitiesEur: children.reduce((sum, child) => sum + child.securitiesEur, 0),
      totalContributionsEur: children.reduce((sum, child) => sum + child.totalContributionsEur, 0),
      netCashFlowsEur: children.reduce((sum, child) => sum + child.netCashFlowsEur, 0),
      acquisitionCostEur, unrealizedGainEur, unrealizedGainPercentage: percentage(unrealizedGainEur, acquisitionCostEur),
      valuedUnrealizedPositions: children.reduce((sum, child) => sum + child.valuedUnrealizedPositions, 0),
      incompleteUnrealizedPositions: children.reduce((sum, child) => sum + child.incompleteUnrealizedPositions, 0),
      contracts: children,
    };
  });

  const grossEur = envelopeTypeReports.reduce((sum, type) => sum + type.grossEur, 0);
  const securitiesEur = envelopeTypeReports.reduce((sum, type) => sum + type.securitiesEur, 0);
  const cashEur = envelopeTypeReports.reduce((sum, type) => sum + type.cashEur, 0);
  for (const asset of reportAssets) asset.portfolioPercentage = asset.valueEur === null ? null : percentage(asset.valueEur, grossEur);

  const allHeldAssetIds = [...holdingsByAsset.keys()];
  const applicableExposures = records.exposures.filter((row) => !row.data_date || row.data_date <= businessDate);
  const sectorRows = applicableExposures.filter((row) => row.dimension === "sector").map((row) => ({ assetId: row.asset_id, referenceId: row.reference_id, weight: Number(row.weight_percent), dataDate: row.data_date, source: row.source }));
  const activityRows = applicableExposures.filter((row) => row.dimension === "activity").map((row) => ({ assetId: row.asset_id, referenceId: row.reference_id, weight: Number(row.weight_percent), dataDate: row.data_date, source: row.source }));
  const geographyRows = applicableExposures.filter((row) => row.dimension === "geography").map((row) => ({ assetId: row.asset_id, referenceId: row.reference_id, weight: Number(row.weight_percent), dataDate: row.data_date, source: row.source }));
  const sectors = distribution(valueByAsset, sectorRows, new Map(records.sectors.map((item) => [item.id, item.name])), allHeldAssetIds, new Set(records.sectors.filter((item) => item.code === "unspecified").map((item) => item.id)));
  const activities = distribution(valueByAsset, activityRows, new Map(records.activities.map((item) => [item.id, item.name])), allHeldAssetIds);
  const geo=mixedGeography([...contracts.values()].map(c=>({id:c.id,name:c.name,global:true,liquid:envelopeTypeById.get(c.envelopeTypeId)?.code==="epargne_liquide",gross:c.incompletePositions||c.incompleteCashBalances?null:c.grossEur,cash:c.incompleteCashBalances?null:c.cashEur,metadata:records.contracts.find(r=>r.id===c.id)?.metadata,
    parts:[...(envelopeTypeById.get(c.envelopeTypeId)?.code==="epargne_liquide"&&c.cashEur!==0?[{id:`cash:${c.id}`,name:c.name,value:c.cashEur,capital:true,exposures:[]}]:[]),...reportAssets.flatMap(a=>a.holdings.filter(h=>h.contractId===c.id).map(h=>({id:a.id,name:a.name,value:h.valueEur,property:assetById.get(a.id)?.asset_type_code==="real_estate",metadata:assetById.get(a.id)?.metadata,exposures:geographyRows.filter(e=>e.assetId===a.id).map(e=>({...e,name:records.countries.find(r=>r.id===e.referenceId)?.name??"Non spécifié"}))}))) ]
  })),records.countries,records.regions,businessDate);
  const countries:ReportExposureDistribution=geo.countries,regions:ReportExposureDistribution=geo.regions;
  const themeAggregation = aggregateValuedThemeExposures({
    assetValuesEur: valueByAsset,
    themes: records.themes,
    exposures: records.themeExposures,
  });
  const themedAssets = new Set(records.themeExposures.map((row) => row.asset_id));
  const themeIncomplete = allHeldAssetIds.filter((assetId) => !valueByAsset.has(assetId) || !themedAssets.has(assetId));
  const themeCoveredEur = [...valueByAsset].reduce((sum, [assetId, value]) => sum + (themedAssets.has(assetId) ? value : 0), 0);
  const themeDates = new Map<string, Set<string>>();
  const themeSources = new Map<string, Set<string>>();
  for (const row of records.themeExposures) {
    if (row.data_date) (themeDates.get(row.theme_id) ?? themeDates.set(row.theme_id, new Set()).get(row.theme_id)!).add(row.data_date);
    if (row.source) (themeSources.get(row.theme_id) ?? themeSources.set(row.theme_id, new Set()).get(row.theme_id)!).add(row.source);
  }
  const themes: ReportExposureDistribution = {
    denominatorEur: themeAggregation.denominatorEur,
    coveredEur: themeCoveredEur,
    coveragePercentage: percentage(themeCoveredEur, themeAggregation.denominatorEur),
    items: themeAggregation.themes.map((theme) => ({
      id: theme.themeId,
      name: theme.name,
      amountEur: theme.amountEur,
      percentage: theme.percentage,
      dataDates: [...(themeDates.get(theme.themeId) ?? [])].sort(),
      sources: [...(themeSources.get(theme.themeId) ?? [])].sort(),
    })),
    incompleteAssetIds: themeIncomplete,
  };
  for (const [label, result] of [["secteurs", sectors], ["activités", activities], ["géographie", countries]] as const) {
    if (result.incompleteAssetIds.length) addWarning(warnings, "exposure_incomplete", `Les expositions ${label} sont partielles.`, result.incompleteAssetIds.length);
  }
  if (themes.incompleteAssetIds.length) addWarning(warnings, "theme_incomplete", "Les expositions thématiques sont partielles.", themes.incompleteAssetIds.length);

  for (const rate of currentRates.values()) {
    const stale = isStale(rate.observed_on, generatedAt);
    freshness.push({ kind: "fx", currencyCode: rate.currency_code, label: rate.currency_code, observedAt: rate.observed_on, obtainedAt: rate.obtained_at ?? null, ageDays: freshnessAgeDays(rate.observed_on, generatedAt), stale });
    if (stale) addWarning(warnings, "stale_fx", `Certains taux FX datent de plus de ${STALE_THRESHOLD_DAYS} jours.`);
  }
  for (const row of records.exposures) freshness.push({ kind: "exposure", assetId: row.asset_id, dimension: row.dimension, label: `${row.dimension} · ${assetById.get(row.asset_id)?.name ?? row.asset_id}`, observedAt: row.data_date, obtainedAt: row.updated_at, ageDays: row.data_date ? freshnessAgeDays(row.data_date, generatedAt) : null, stale: false });
  for (const row of records.themeExposures) freshness.push({ kind: "theme", assetId: row.asset_id, label: assetById.get(row.asset_id)?.name ?? row.asset_id, observedAt: row.data_date, obtainedAt: row.updated_at, ageDays: row.data_date ? freshnessAgeDays(row.data_date, generatedAt) : null, stale: false });
  for (const original of records.contracts) {
    const item = contracts.get(original.id);
    if ((original.is_active === false || !!original.closed_on) && item && item.grossEur > 0) addWarning(warnings, "exposure_incomplete", `Contrat inactif avec des avoirs : ${item.name}.`);
  }
  for(const contract of contracts.values()){
    const original=records.contracts.find(c=>c.id===contract.id);
    contract.contractGain=resolveContractGain(contract.incompletePositions||contract.incompleteCashBalances?null:reportContractGross(contract),flowsByContract.get(contract.id)??[],original?.metadata??{},businessDate);
  }
  const contractViews = [...contracts.values()].map(contractReport);
  const totalAcquisitionCost = contractViews.reduce((sum, contract) => sum + contract.acquisitionCostEur, 0);
  const totalUnrealized = contractViews.reduce((sum, contract) => sum + contract.unrealizedGainEur, 0);
  const hasValuationInputs = records.positions.some((p) => !manualIds.has(p.contract_id)) || records.cashBalances.some((balance) => !manualIds.has(balance.contract_id) && Number(balance.amount) !== 0);
  const hasKnownValuation = contractViews.some(c => reportContractGross(c) !== null && !c.incompletePositions && !c.incompleteCashBalances);
  const qualityStatus = hasValuationInputs && grossEur === 0 && !hasKnownValuation ? "unavailable" : warnings.size ? "partial" : "complete";
  const allocations = (items: Array<{ id: string; name: string; amountEur: number }>) => {
    const rounded = Math.abs(items.reduce((sum, item) => sum + item.amountEur, 0) - grossEur) < .005 ? roundedPercentages(items.map((item) => ({ id: item.id, amount: item.amountEur }))) : null;
    return items.map((item) => ({ ...item, percentage: rounded?.get(item.id) ?? percentage(item.amountEur, grossEur) })).sort((a, b) => b.amountEur - a.amountEur || a.name.localeCompare(b.name, "fr"));
  };

  const netCoverageEur = contractViews.filter((contract) => contract.netEstimatedEur !== null).reduce((sum, contract) => sum + contract.grossEur, 0);
  const netEstimatedEur = contractViews.length > 0 && contractViews.every((contract) => contract.netEstimatedEur !== null)
    ? contractViews.reduce((sum, contract) => sum + contract.netEstimatedEur!, 0)
    : null;
  return {
    meta: { ...records.fiscalConsultationPolicy===2?{fiscalConsultationPolicy:2 as const}:{}, ...records.envelopeFiscalities!==undefined?{fiscalConvention:ESTIMATE_CONVENTION}:{}, generatedAt, timeZone: "Europe/Paris", reportingCurrency: "EUR" },
    summary: {
      netKind: netEstimatedEur === null ? "unavailable" : contractViews.some((c) => c.netKind === "approximate") ? "approximate" : "calculated",
      grossEur, netEstimatedEur, grossNetDifferenceEur: netEstimatedEur === null ? null : grossEur - netEstimatedEur, netCoverageEur,
      envelopeTypeCount: records.envelopeTypes.length, contractCount: records.contracts.length, assetCount: reportAssets.length,
      cashEur, securitiesEur,
      totalContributionsEur: contractViews.reduce((sum, contract) => sum + contract.totalContributionsEur, 0),
      netCashFlowsEur: contractViews.reduce((sum, contract) => sum + contract.netCashFlowsEur, 0),
      acquisitionCostEur: totalAcquisitionCost, unrealizedGainEur: totalUnrealized,
      unrealizedGainPercentage: percentage(totalUnrealized, totalAcquisitionCost),
      valuedUnrealizedPositions: contractViews.reduce((sum, contract) => sum + contract.valuedUnrealizedPositions, 0),
      incompleteUnrealizedPositions: contractViews.reduce((sum, contract) => sum + contract.incompleteUnrealizedPositions, 0),
    },
    envelopeTypes: envelopeTypeReports.sort((a, b) => b.grossEur - a.grossEur || a.name.localeCompare(b.name, "fr")),
    contracts: contractViews.sort((a, b) => b.grossEur - a.grossEur || a.name.localeCompare(b.name, "fr")),
    assets: reportAssets.sort((a, b) => (b.valueEur ?? -1) - (a.valueEur ?? -1) || a.name.localeCompare(b.name, "fr")),
    allocations: {
      envelopeTypes: allocations(envelopeTypeReports.map((item) => ({ id: item.id, name: item.name, amountEur: item.grossEur }))),
      contracts: allocations(contractViews.filter(item=>reportContractGross(item)!==null).map((item) => ({ id: item.id, name: item.name, amountEur: item.grossEur }))),
      assets: allocations(reportAssets.flatMap((item) => item.valueEur === null ? [] : [{ id: item.id, name: item.name, amountEur: item.valueEur }]) ),
    },
    exposures: { sectors, activities, geography: { countries, regions }, themes },
    quality: { status: qualityStatus, warnings: [...warnings.values()], freshness: freshness.sort((a, b) => (b.observedAt ?? "").localeCompare(a.observedAt ?? "")), staleThresholdDays: STALE_THRESHOLD_DAYS },
  };
}
import { roundedPercentages } from "@/lib/patrimony/distribution-core";
