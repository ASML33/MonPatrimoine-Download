import {exposureDisplayItems} from "./report-presentation";
import {reportContractGross} from "./patrimonial-report-core";
import type { PatrimonialReport } from "./patrimonial-report-core";
import type { ReportSection } from "./report-configuration";
import { reportGain } from "./report-configuration";
import { csv, type CsvCell } from "./csv";
export { csv, type CsvCell } from "./csv";
export type ExportFile = { name: string; bytes: Uint8Array };
const state=(v:unknown,partial=false)=>v===null||v===undefined?"inconnu":partial?"partiel — sous-total connu":"connu";
export function reportTables(r:PatrimonialReport):Record<ReportSection,CsvCell[][]> {
 const incomplete=r.contracts.some(c=>c.incompletePositions||c.incompleteCashBalances);
 const summary:CsvCell[][]=[["indicateur","valeur","statut"]];
 const metrics:[string,number|null,boolean?][]=[
  ["BRUT total EUR",incomplete?null:r.summary.grossEur],["BRUT connu EUR",r.summary.grossEur,incomplete],["NET EUR",r.summary.netEstimatedEur],
  ["Couverture NET EUR",r.summary.netCoverageEur],["Espèces connues EUR",r.summary.cashEur,r.contracts.some(c=>!!c.incompleteCashBalances)],
  ["Plus-value latente connue EUR",r.summary.valuedUnrealizedPositions?r.summary.unrealizedGainEur:null,!!r.summary.incompleteUnrealizedPositions],
  ["Versements connus EUR",r.summary.totalContributionsEur,r.contracts.some(c=>!!c.incompleteContributionFlows)],["Flux nets connus EUR",r.summary.netCashFlowsEur,r.contracts.some(c=>!!c.incompleteNetCashFlows)],
 ];
 for(const [label,value,partial] of metrics)summary.push([label,value,state(value,partial)]);
 const contracts:CsvCell[][]=[["contrat","type","brut_total_eur","brut_connu_eur","statut_brut","net_eur","qualité_net","espèces_connues_eur","titres_connus_eur","gain_global_eur","statut_gain","latent_connu_eur","statut_latent","versements_connus_eur","flux_nets_connus_eur","date_situation_source","précision_date_situation","date_actualisation","avertissements"]];
 const assets:CsvCell[][]=[["actif","symbole","contrat","quantité_détenue","valeur_détention_eur","statut_valeur","pru_détention_eur","latent_détention_eur","cours_eur","date_cours","récupération_cours","source_cours","poids_actif_pct","statut_poids"]];
 const fiscal:CsvCell[][]=[["contrat","brut_connu_eur","net_eur","qualité_net","version","base_ir_eur","taux_ir","ir_eur","base_ps_eur","taux_ps","ps_eur","bascule","provenance_limites"]];
 for(const c of r.contracts){
  const partial=!!(c.incompletePositions||c.incompleteCashBalances);
  const gain=reportGain(c);
  contracts.push([c.name,c.envelopeTypeLabel,partial?null:reportContractGross(c),reportContractGross(c),state(reportContractGross(c),partial),c.netEstimatedEur,c.netKind??state(c.netEstimatedEur),c.cashEur,c.securitiesEur,gain.amount,gain.status,c.valuedUnrealizedPositions?c.unrealizedGainEur:null,state(c.valuedUnrealizedPositions?c.unrealizedGainEur:null,!!c.incompleteUnrealizedPositions),c.totalContributionsEur,c.netCashFlowsEur,c.manualSituationAt??null,c.manualSituationPrecision??null,c.updatedAt,c.fiscalWarnings.join(" | ")]);
  const f=c.fiscalDetail;
  fiscal.push([c.name,reportContractGross(c),c.netEstimatedEur,c.netKind??state(c.netEstimatedEur),c.fiscalRuleVersion,f?.irBaseEur??null,f?.irRate??null,f?.irEur??c.fiscalTotals?.irEur??null,f?.psBaseEur??null,f?.psRate??null,f?.psEur??c.fiscalTotals?.psEur??null,f?.thresholdDate??null,c.fiscalWarnings.join(" | ")]);
  if((c.fiscalComponents?.length??0)>1)for(const component of c.fiscalComponents!)fiscal.push([c.name+' / '+component.label,null,null,'composante du NET ci-dessus',component.ruleVersion,component.irBaseEur,component.irRate,component.irEur,component.psBaseEur,component.psRate,component.psEur,null,'Montants fiscaux détaillés ; BRUT et NET non répétés.']);
 }
 for(const a of r.assets)for(const h of a.holdings)assets.push([a.name,a.symbol,h.contractName,h.valueSemantics?null:h.quantity,h.valueEur,state(h.valueEur),h.acquisitionCostEur!==null&&h.quantity!==null&&h.quantity>0?h.acquisitionCostEur/h.quantity:null,h.unrealizedGainEur,a.currentPriceEur??null,a.priceObservedAt,a.priceObtainedAt,a.priceSource,a.portfolioPercentage,state(a.portfolioPercentage,incomplete||a.holdings.some(h=>h.valueEur===null))]);
 const allocations:CsvCell[][]=[["regroupement","libellé","montant_connu_eur","poids_pct","statut_base"]];
 for(const [group,items] of Object.entries(r.allocations))for(const item of items)allocations.push([group,item.name,item.amountEur,item.percentage,incomplete?"patrimoine partiel — base connue":"base valorisée"]);
 const exposures:CsvCell[][]=[["dimension","libellé","montant_eur","poids_pct","base_valorisée_eur","couvert_eur","couverture_pct","statut","dates_données","sources","schema_expositions","lecture"]];
 for(const [group,d] of Object.entries({secteurs:r.exposures.sectors,activités:r.exposures.activities,pays:r.exposures.geography.countries,régions:r.exposures.geography.regions,thématiques:r.exposures.themes})){
  const items=d.items.length?exposureDisplayItems(d):[{name:"Non spécifié",amountEur:null,percentage:null,dataDates:[],sources:[]}];
  for(const item of items)exposures.push([group,item.name,item.amountEur,item.percentage,d.denominatorEur,d.coveredEur,d.coveragePercentage,d.incompleteAssetIds.length?"partiel":"base valorisée",item.dataDates.join(" | "),item.sources.join(" | "),2,["pays","régions"].includes(group)?"Exposition des placements et localisation des autres biens — BRUT ; capital liquide inclus, espèces des comptes à titres exclues":"Exposition des placements"]);
 }
 if(r.meta.fiscalConvention){fiscal[0].push("convention_estimation");for(const row of fiscal.slice(1))row.push(r.meta.fiscalConvention);}
 return {summary,contracts,assets,allocations,exposures,fiscal};
}
export function reportExportFiles(r:PatrimonialReport,sections:readonly ReportSection[]) {
 const stamp=r.meta.generatedAt.replace(/[^0-9TZ]/g,"-");
 const context:CsvCell[]=[r.meta.generatedAt,r.meta.timeZone,"EUR",r.contracts.map(c=>c.name).join(" | "),r.quality.status,r.quality.warnings.map(w=>w.message).join(" | "),JSON.stringify(r.quality.freshness)];
 const contextHeaders=["généré_le","fuseau","devise_consultation","contrats_sélectionnés","qualité_globale","avertissements_globaux","dates_sources_fx_et_récupération"];
 const tables=reportTables(r);
 const files=sections.map(section=>{const [header,...data]=tables[section];return {name:`monpatrimoine-${stamp}-${section}.csv`,bytes:csv([[...contextHeaders,...header],...(data.length?data:[header.map(()=>null)]).map(row=>[...context,...row])])};});
 if(files.length>1)files.push({name:`monpatrimoine-${stamp}-contexte.csv`,bytes:csv([contextHeaders,context])});
 return files;
}
// Small standards-only ZIP (STORE): no dependency, compression or external service.
export function zip(files: readonly ExportFile[]) {
 const out:number[]=[],central:number[]=[];const u16=(a:number[],n:number)=>a.push(n&255,(n>>>8)&255);const u32=(a:number[],n:number)=>{u16(a,n);u16(a,n>>>16);};
 for(const file of files){
  if(!/^[a-zA-Z0-9._-]+$/.test(file.name))throw new Error("Nom de fichier invalide");
  const name=new TextEncoder().encode(file.name),offset=out.length;let crc=0xffffffff;
  for(const b of file.bytes){crc^=b;for(let bit=0;bit<8;bit++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}crc=(crc^0xffffffff)>>>0;
  u32(out,0x04034b50);u16(out,20);u16(out,0x800);u16(out,0);u16(out,0);u16(out,33);u32(out,crc);u32(out,file.bytes.length);u32(out,file.bytes.length);u16(out,name.length);u16(out,0);for(const b of name)out.push(b);for(const b of file.bytes)out.push(b);
  u32(central,0x02014b50);u16(central,20);u16(central,20);u16(central,0x800);u16(central,0);u16(central,0);u16(central,33);u32(central,crc);u32(central,file.bytes.length);u32(central,file.bytes.length);u16(central,name.length);u16(central,0);u16(central,0);u16(central,0);u16(central,0);u32(central,0);u32(central,offset);for(const b of name)central.push(b);
 }
 const start=out.length;out.push(...central);u32(out,0x06054b50);u16(out,0);u16(out,0);u16(out,files.length);u16(out,files.length);u32(out,central.length);u32(out,start);u16(out,0);return new Uint8Array(out);
}
