export type CsvCell = string | number | null;
export function csv(rows: readonly (readonly CsvCell[])[]) {
 const cell=(value:CsvCell)=>{
  if(value===null)return "";
  const text=typeof value==="number" ? Number.isFinite(value)?value.toLocaleString("fr-FR",{useGrouping:false,maximumFractionDigits:20}):"" : /^[\s\uFEFF]*[=+\-@]/.test(value)||/^[\t\r\n]/.test(value)?"'"+value:value;
  return /[;"\r\n]/.test(text)?'"'+text.replaceAll('"','""')+'"':text;
 };
 return new TextEncoder().encode("\uFEFF"+rows.map(row=>row.map(cell).join(";")).join("\r\n")+"\r\n");
}
