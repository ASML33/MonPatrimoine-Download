export function downloadPrivate(bytes:Uint8Array,name:string,type:string){
 const url=URL.createObjectURL(new Blob([new Uint8Array(bytes)],{type}));const a=document.createElement("a");a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
