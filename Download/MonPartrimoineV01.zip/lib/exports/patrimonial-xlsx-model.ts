import { civilDay, monetaryValue, patrimonialXlsxFilename, quantityValue, type ExportNumber } from "./patrimonial-xlsx-values";

export type CellEvidence = { kind: "value"; value: ExportNumber } | { kind: "unavailable" | "unverified" | "absent" };
type MissingEvidence = Exclude<CellEvidence, { kind: "value" }>;
type Absence = { from: string; through?: string };
type Contract = { id: string; label: string; envelope: string; absences?: readonly Absence[] };
type ContractSeries = { id: string; contractId: string };
type Series =
  | (ContractSeries & { kind: "asset"; assetId: string; label: string; absences?: readonly Absence[] })
  | (ContractSeries & { kind: "cash" | "contract-total" })
  | { id: string; kind: "employee-savings-total"; members: readonly [string, string] };
type AssetEvidence = { kind: "asset"; quantity: CellEvidence; historicalPruEur: CellEvidence; grossEur: CellEvidence };
type Observation = { seriesId: string; evidence: CellEvidence | AssetEvidence };

export type PatrimonialHistory = {
  backupDate: string;
  contracts: readonly Contract[];
  /** Stable catalogue in insertion order. Append new series to preserve row indices. */
  series: readonly Series[];
  /** One immutable set of observations per evidenced civil day. */
  days: readonly { date: string; observations: readonly Observation[] }[];
};

export type ProjectedCell = { kind: "value"; value: number } | MissingEvidence;
export type ProjectedRow = { label: string; format: "quantity" | "eur" };
export type PatrimonialXlsxProjection = {
  filename: string;
  rows: readonly ProjectedRow[];
  years: readonly { year: string; days: readonly { date: string; cells: readonly ProjectedCell[] }[] }[];
};

// Both stages use the same explicit limits. Exceeding the budget produces no partial workbook.
export const MAX_WORKBOOK_CELLS = 1_000_000;
export const EXCEL_MAX_ROWS = 1_048_576;
const unverified = { kind: "unverified" } as const;
const empty = { kind: "absent" } as const;

function indexed<T extends { id: string }>(items: readonly T[], entity: string) {
  const map = new Map<string, T>();
  for (const item of items) {
    if (!item.id || map.has(item.id)) throw new Error(entity + " : identité manquante ou répétée");
    map.set(item.id, item);
  }
  return map;
}

function labelRegistry() {
  const used = new Set<string>();
  return (label: string) => {
    if (typeof label !== "string" || !label.trim() || label.length > 512) throw new Error("Libellé d’export invalide");
    const base = label.trim();
    let result = base;
    for (let suffix = 2; used.has(result); suffix++) result = base + " (" + suffix + ")";
    used.add(result);
    return result;
  };
}

function checkAbsences(periods: readonly Absence[] = []) {
  for (const period of periods) {
    civilDay(period.from);
    if (period.through !== undefined && civilDay(period.through) < civilDay(period.from)) {
      throw new RangeError("Période d’absence inversée");
    }
  }
}

function isAbsent(date: string, periods: readonly Absence[] = []) {
  return periods.some(({ from, through }) => date >= from && (through === undefined || date <= through));
}

function projectCell(cell: CellEvidence, format: ProjectedRow["format"]): ProjectedCell {
  if (cell.kind === "value") {
    return { kind: "value", value: format === "eur" ? monetaryValue(cell.value) : quantityValue(cell.value) };
  }
  if (cell.kind !== "unverified" && cell.kind !== "unavailable" && cell.kind !== "absent") {
    throw new Error("État de cellule inconnu");
  }
  return { kind: cell.kind };
}

function makeRows(label: string, series: Series): ProjectedRow[] {
  if (series.kind === "asset") {
    const asset = label + " · " + series.label;
    return [
      { label: asset + " · Quantité", format: "quantity" },
      { label: asset + " · PRU historique EUR", format: "eur" },
      { label: asset + " · Valorisation brute EUR", format: "eur" },
    ];
  }
  const suffix = series.kind === "cash" ? " · Espèces EUR" : series.kind === "contract-total" ? " · Total brut EUR (périodes sans détail)" : "";
  return [{ label: label + suffix, format: "eur" }];
}

function validateSeries(series: Series, contracts: Map<string, Contract>) {
  if (series.kind === "employee-savings-total") {
    const [a, b] = series.members.map(id => contracts.get(id)?.envelope);
    if (!((a === "peg" && b === "per_col") || (b === "peg" && a === "per_col"))) {
      throw new Error("Le total non ventilé doit relier un PEG et un PER COL");
    }
  } else if (!contracts.has(series.contractId)) {
    throw new Error("Contrat de la série inconnu");
  }
  if (series.kind === "asset") {
    if (!series.assetId || typeof series.label !== "string" || !series.label.trim()) throw new Error("Actif invalide");
    checkAbsences(series.absences);
  }
}

function dedupeKey(series: Series) {
  if (series.kind === "employee-savings-total") return JSON.stringify([series.kind, [...series.members].sort()]);
  return JSON.stringify([series.contractId, series.kind, series.kind === "asset" ? series.assetId : null]);
}

function indicators(series: Series, evidence: Observation["evidence"] | undefined, absent: boolean) {
  if (evidence?.kind === "asset" && series.kind !== "asset") throw new Error("Détail d’actif sur une série simple");
  if (series.kind === "asset" && evidence?.kind === "value") throw new Error("Le détail qualifié de l’actif est requis");
  const cells = evidence?.kind === "asset" ? [evidence.quantity, evidence.historicalPruEur, evidence.grossEur] : [evidence ?? unverified];
  if (absent && cells.some(cell => cell.kind === "value")) throw new Error("Valeur incompatible avec une absence attestée");
  if (absent) return series.kind === "asset" ? [empty, empty, empty] : [empty];
  return cells.length === 1 && series.kind === "asset" ? [cells[0], cells[0], cells[0]] : cells;
}

function checkTotals(totals: ReadonlyMap<string, number>, detail: ReadonlySet<string>, groups: readonly (readonly string[])[]) {
  for (const [contractId, count] of totals) {
    if (count > 1 || detail.has(contractId)) throw new Error("Total brut et composants connus le même jour");
  }
  const grouped = new Set<string>();
  for (const members of groups) {
    for (const member of members) {
      if (grouped.has(member) || detail.has(member) || totals.has(member)) {
        throw new Error("Total d’épargne salariale non ventilé en double avec un autre montant");
      }
      grouped.add(member);
    }
  }
}

export function projectPatrimonialHistory(history: PatrimonialHistory): PatrimonialXlsxProjection {
  const filename = patrimonialXlsxFilename(history.backupDate);
  if (!history.days.length || !history.series.length) throw new Error("Historique patrimonial vide");
  const contracts = indexed(history.contracts, "Contrat");
  const allSeries = indexed(history.series, "Série");
  const uniqueContracts = labelRegistry();
  const contractLabels = new Map<string, string>();
  for (const [id, contract] of contracts) {
    if (contract.envelope === "immobilier") continue;
    contractLabels.set(id, uniqueContracts(contract.label));
    checkAbsences(contract.absences);
  }
  const model: { series: Series; rows: ProjectedRow[] }[] = [];
  const businessKeys = new Set<string>();
  const uniqueRows = labelRegistry();
  let rowCount = 1;
  for (const series of history.series) {
    validateSeries(series, contracts);
    if (series.kind !== "employee-savings-total" && !contractLabels.has(series.contractId)) continue;
    const key = dedupeKey(series);
    if (businessKeys.has(key)) throw new Error("Série financière dupliquée");
    businessKeys.add(key);
    const label = series.kind === "employee-savings-total" ? "PEG + PER COL · Historique non ventilé · Total brut EUR" : contractLabels.get(series.contractId)!;
    const rows = makeRows(label, series).map(row => ({ ...row, label: uniqueRows(row.label) }));
    rowCount += rows.length;
    model.push({ series, rows });
  }
  if (rowCount === 1) throw new Error("Aucune série financière exportable");
  if (rowCount > EXCEL_MAX_ROWS || rowCount * history.days.length > MAX_WORKBOOK_CELLS) {
    throw new RangeError("Historique hors capacité du classeur");
  }

  const years = new Map<string, { date: string; cells: ProjectedCell[] }[]>();
  const dates = new Set<string>();
  for (const day of [...history.days].sort((a, b) => a.date.localeCompare(b.date))) {
    civilDay(day.date);
    if (day.date > history.backupDate || dates.has(day.date)) throw new Error("Date future ou dupliquée");
    dates.add(day.date);
    const observed = new Map<string, Observation["evidence"]>();
    for (const obs of day.observations) {
      if (!allSeries.has(obs.seriesId) || observed.has(obs.seriesId)) throw new Error("Observation inconnue ou dupliquée");
      observed.set(obs.seriesId, obs.evidence);
    }
    const cells: ProjectedCell[] = [];
    const detail = new Set<string>();
    const totals = new Map<string, number>();
    const groups: (readonly string[])[] = [];
    for (const { series, rows } of model) {
      const absent = series.kind !== "employee-savings-total" && (
        isAbsent(day.date, contracts.get(series.contractId)?.absences) ||
        (series.kind === "asset" && isAbsent(day.date, series.absences))
      );
      const projected = indicators(series, observed.get(series.id), absent).map((cell, i) => projectCell(cell, rows[i].format));
      cells.push(...projected);
      if (projected.at(-1)?.kind !== "value") continue;
      if (series.kind === "employee-savings-total") groups.push(series.members);
      else if (series.kind === "contract-total") totals.set(series.contractId, (totals.get(series.contractId) ?? 0) + 1);
      else detail.add(series.contractId);
    }
    checkTotals(totals, detail, groups);
    const year = day.date.slice(0, 4);
    const current = years.get(year);
    if (current) current.push({ date: day.date, cells });
    else years.set(year, [{ date: day.date, cells }]);
  }
  if (rowCount * (history.days.length + years.size) > MAX_WORKBOOK_CELLS) throw new RangeError("Historique hors capacité du classeur");
  return { filename, rows: model.flatMap(entry => entry.rows), years: [...years].map(([year, days]) => ({ year, days })) };
}
