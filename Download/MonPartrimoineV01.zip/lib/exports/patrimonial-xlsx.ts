import JSZip from "jszip";
import {
  EXCEL_MAX_ROWS, MAX_WORKBOOK_CELLS, projectPatrimonialHistory,
  type PatrimonialHistory, type PatrimonialXlsxProjection, type ProjectedCell,
} from "./patrimonial-xlsx-model";
import { civilDay } from "./patrimonial-xlsx-values";

export const PATRIMONIAL_XLSX_MIME = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
const MAX_XML_BYTES = 32 * 1024 * 1024;
const MAX_XLSX_BYTES = 8 * 1024 * 1024;
const xmlHeader = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
const spreadsheet = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";
const packageRelationships = "http://schemas.openxmlformats.org/package/2006/relationships";
const officeRelationships = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
const contentTypes = "http://schemas.openxmlformats.org/package/2006/content-types";
const types = "application/vnd.openxmlformats-officedocument.spreadsheetml.";
// OOXML escapes underscore-prefixed escape sequences before ordinary XML escaping.
function xmlText(value: string) {
  if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffe\uffff]|[\ud800-\udfff]/u.test(value)) {
    throw new Error("Caractère interdit dans un libellé XLSX");
  }
  return value.replace(/_x(?=[0-9a-f]{4}_)/gi, "_x005F_x")
    .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;").replaceAll("'", "&apos;").replaceAll("\r", "&#13;");
}

function columnName(index: number) {
  let name = "";
  for (let col = index + 1; col > 0; col = Math.floor((col - 1) / 26)) {
    name = String.fromCharCode(65 + (col - 1) % 26) + name;
  }
  return name;
}

function textCell(ref: string, value: string, style = "") {
  return '<c r="' + ref + '" t="inlineStr"' + style + '><is><t xml:space="preserve">' + xmlText(value) + "</t></is></c>";
}

function numberCell(ref: string, value: number, style = "") {
  if (!Number.isFinite(value)) throw new Error("Nombre XLSX non fini");
  return '<c r="' + ref + '" t="n"' + style + "><v>" + value + "</v></c>";
}

function dataCell(ref: string, cell: ProjectedCell, eur: boolean) {
  switch (cell.kind) {
    case "absent": return "";
    case "unverified":
    case "unavailable": return textCell(ref, "?");
    case "value": return numberCell(ref, cell.value, eur ? ' s="2"' : "");
  }
  throw new Error("Cellule XLSX inconnue");
}

function worksheet(model: PatrimonialXlsxProjection, sheet: PatrimonialXlsxProjection["years"][number]) {
  const columns = sheet.days.map((_, i) => columnName(i + 1));
  const dates = sheet.days.map((day, i) => numberCell(columns[i] + "1", civilDay(day.date), ' s="1"'));
  const rows = model.rows.map((row, i) => {
    const index = i + 2;
    const cells = sheet.days.map((day, j) => dataCell(columns[j] + index, day.cells[i], row.format === "eur"));
    return '<row r="' + index + '">' + textCell("A" + index, row.label) + cells.join("") + "</row>";
  });
  return xmlHeader + '<worksheet xmlns="' + spreadsheet + '"><dimension ref="A1:' + columns.at(-1) + (rows.length + 1) + '"/>'
    + '<sheetViews><sheetView workbookViewId="0"><pane xSplit="1" ySplit="1" topLeftCell="B2" activePane="bottomRight" state="frozen"/>'
    + '<selection pane="bottomRight" activeCell="B2" sqref="B2"/></sheetView></sheetViews>'
    + '<sheetFormatPr defaultRowHeight="15"/><cols><col min="1" max="1" width="74" customWidth="1"/>'
    + '<col min="2" max="' + (columns.length + 1) + '" width="17" customWidth="1"/></cols>'
    + '<sheetData><row r="1">' + textCell("A1", "Contrat · Actif · Indicateur", ' s="3"') + dates.join("") + "</row>"
    + rows.join("") + "</sheetData></worksheet>";
}

const styles = xmlHeader + '<styleSheet xmlns="' + spreadsheet + '"><numFmts count="2">'
  + '<numFmt numFmtId="164" formatCode="dd/mm/yyyy"/>'
  + '<numFmt numFmtId="165" formatCode="#,##0.00 &quot;€&quot;"/></numFmts>'
  + '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
  + '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
  + '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
  + '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
  + '<cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
  + '<xf numFmtId="164" fontId="1" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1"/>'
  + '<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>'
  + '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs>'
  + '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';

function validateProjection(model: PatrimonialXlsxProjection) {
  if (!model.rows.length || model.rows.length + 1 > EXCEL_MAX_ROWS || !model.years.length) {
    throw new RangeError("Dimensions XLSX invalides");
  }
  let cells = 0;
  let previous = "";
  for (const period of model.years) {
    if (period.year <= previous || !/^\d{4}$/.test(period.year) || !period.days.length || period.days.length > 366) {
      throw new RangeError("Onglet annuel invalide");
    }
    previous = period.year;
    cells += (model.rows.length + 1) * (period.days.length + 1);
    let previousDate = "";
    for (const day of period.days) {
      if (day.date <= previousDate || day.date.slice(0, 4) !== period.year || day.cells.length !== model.rows.length) {
        throw new RangeError("Date ou ligne de projection invalide");
      }
      civilDay(day.date);
      previousDate = day.date;
    }
  }
  // Upper bound for worksheet construction before the actual XML-size check.
  const labelBytes = model.rows.reduce((n, row) => n + Buffer.byteLength(xmlText(row.label)), 0);
  if (cells > MAX_WORKBOOK_CELLS || cells * 88 + model.years.length * labelBytes > MAX_XML_BYTES * 3) {
    throw new RangeError("Projection hors capacité XLSX");
  }
}

export async function serializePatrimonialXlsx(model: PatrimonialXlsxProjection): Promise<Uint8Array> {
  validateProjection(model);
  const zip = new JSZip();
  // Fixed archive metadata keeps the export free of host and run timestamps.
  const date = new Date("2000-01-01T00:00:00Z");
  let xmlBytes = 0;
  const add = (path: string, value: string) => {
    xmlBytes += Buffer.byteLength(value);
    if (xmlBytes > MAX_XML_BYTES) throw new RangeError("Budget XML du classeur dépassé");
    zip.file(path, value, { date, createFolders: false });
  };
  const relationship = (id: string, type: string, target: string) =>
    '<Relationship Id="' + id + '" Type="' + officeRelationships + "/" + type + '" Target="' + target + '"/>';
  const override = (path: string, type: string) =>
    '<Override PartName="/' + path + '" ContentType="' + types + type + '+xml"/>';
  const rels = (value: string) => xmlHeader + '<Relationships xmlns="' + packageRelationships + '">' + value + "</Relationships>";
  add("_rels/.rels", rels(relationship("rId1", "officeDocument", "xl/workbook.xml")));

  const sheetRecords = model.years.map(({ year }, i) => ({
    year, id: String(i + 1), target: "worksheets/sheet" + (i + 1) + ".xml",
  }));
  add("[Content_Types].xml", xmlHeader + '<Types xmlns="' + contentTypes + '">'
    + '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
    + '<Default Extension="xml" ContentType="application/xml"/>'
    + override("xl/workbook.xml", "sheet.main") + override("xl/styles.xml", "styles")
    + sheetRecords.map(s => override("xl/" + s.target, "worksheet")).join("") + "</Types>");
  add("xl/workbook.xml", xmlHeader + '<workbook xmlns="' + spreadsheet + '" xmlns:r="' + officeRelationships
    + '"><workbookPr date1904="0"/><bookViews><workbookView/></bookViews><sheets>'
    + sheetRecords.map(s => '<sheet name="' + s.year + '" sheetId="' + s.id + '" r:id="rId' + s.id + '"/>').join("")
    + "</sheets></workbook>");
  add("xl/_rels/workbook.xml.rels", rels(sheetRecords.map(s => relationship("rId" + s.id, "worksheet", s.target)).join("")
    + relationship("rIdStyles", "styles", "styles.xml")));
  add("xl/styles.xml", styles);
  for (const [i, sheet] of model.years.entries()) add("xl/" + sheetRecords[i].target, worksheet(model, sheet));

  const bytes = await zip.generateAsync({ type: "uint8array", compression: "DEFLATE", platform: "DOS" });
  if (bytes.byteLength > MAX_XLSX_BYTES) throw new RangeError("Taille XLSX maximale dépassée");
  return bytes;
}

export async function generatePatrimonialXlsx(history: PatrimonialHistory) {
  const model = projectPatrimonialHistory(history);
  return { filename: model.filename, mimeType: PATRIMONIAL_XLSX_MIME, bytes: await serializePatrimonialXlsx(model) };
}
