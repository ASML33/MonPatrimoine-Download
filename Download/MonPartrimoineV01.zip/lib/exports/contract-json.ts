import { civilDay } from "./patrimonial-xlsx-values";
import type { FrozenFinancialDay } from "../backups/xlsx-financial-history";

export type NativeDay = {
  assets: { seriesId: string; nativePru: number | null; currency: string }[];
  cash: { contractId: string; currency: string; sourceCurrency?: string; amount: number | null; observedAt: string }[];
  events: { id: string; contractId: string; date: string; occurredAt?: string; sens?: "entree" | "sortie" | "interne"; kind: string; amount: number | null; currency: string; sourceCurrency?: string }[];
};
type Value = number | null | "absent";
type DailyRow = {
  date: string; observedAt: string | null; status: "observed" | "carried" | "unavailable" | "absent";
  value: Value; assets: { reference: string; label: string; quantity: Value; pru: number | null;
    currency: string | null; pruEur: Value; grossEur: Value; observedAt: string | null }[];
  cash: { currency: string; amount: number | null; observedAt: string }[];
};
export type ContractJson = {
  contrat: { id: string; reference: string; libelle: string; type: string };
  entete: { schema: "monpatrimoine-contrat-v1"; version_sauvegarde: string; reference_le: string;
    debut: string; fin: string; archive_annee: number | null; limites: string[]; lecture: string };
  mois: { mois: string; jour_debut: number; jour_fin: number; jours: string[]; etats: DailyRow[] }[];
  periodes: { jour_debut: string; jour_fin: string; valo: Value; statut: DailyRow["status"]; observe_le: string | null }[];
  operations: NativeDay["events"];
};
const securities = new Set(["cto", "compte_titres", "pea", "pea_pme"]);
const uuid = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
export function contractReference(id: string) {
  if (!uuid.test(id)) throw new Error("Identifiant de contrat invalide");
  return id.toLowerCase();
}
export function contractJsonName(contract: ContractJson["contrat"], date: string, archiveYear?: number) {
  civilDay(date);
  const prefix = archiveYear ? "ARCHIVE_" + archiveYear : date.replaceAll("-", ".");
  const kind = contract.type.toUpperCase().replace(/[^A-Z0-9_]/g, "_");
  return prefix + "_" + kind + "_" + contractReference(contract.id) + ".json";
}
const number = (value: number | string): number => {
  const n = Number(value);
  if (!Number.isFinite(n)) throw new Error("Nombre JSON invalide");
  return n;
};
const value = (cell: { kind: string; value?: number | string }): Value =>
  cell.kind === "value" ? number(cell.value!) : cell.kind === "absent" ? "absent" : null;
function nextDay(day: string) {
  return new Date(Date.parse(day + "T00:00:00Z") + 86400000).toISOString().slice(0, 10);
}
/** Export only evidence captured for each day. Never infer an operation from a holding delta. */
export function contractHistories(days: readonly FrozenFinancialDay[], operation: string, capturedAt: string, date: string) {
  civilDay(date);
  if (!Number.isFinite(Date.parse(capturedAt))) throw new Error("Horodatage invalide");
  const start = (Number(date.slice(0, 4)) - 1) + "-12-01";
  const sorted = [...days].filter(d => d.date <= date).sort((a, b) => a.date.localeCompare(b.date));
  if (new Set(sorted.map(d => d.date)).size !== sorted.length) throw new Error("Journée répétée");
  const contracts = new Map(sorted.flatMap(d => d.contracts.map(c => [c.id, c] as const)));
  const results: ContractJson[] = [];
  for (const contract of contracts.values()) {
    const allSeries = new Map(sorted.flatMap(d => d.series.filter(s => s.kind !== "employee-savings-total" && s.contractId === contract.id).map(s => [s.id, s] as const)));
    const relevant = sorted.filter(d => d.observations.some(o => allSeries.has(o.seriesId) && o.evidence.kind !== "unavailable" && o.evidence.kind !== "unverified"));
    if (!relevant.length) continue;
    const beginning = [start, relevant[0].date].sort().at(-1)!;
    if (beginning > date) continue;
    const latest = sorted.at(-1)!;
    const isClosed = latest.closedContracts.includes(contract.id);
    const ending = isClosed ? relevant.at(-1)!.date : date;
    if (ending < beginning) continue;
    const rows: DailyRow[] = [];
    const byDate = new Map(sorted.map(day => [day.date, day]));
    // Missing captures remain gaps. Carry only when source evidence explicitly dates a recorded value.
    for (let day = beginning; day <= ending; day = nextDay(day)) {
      const frozen = byDate.get(day);
      const observations = frozen?.observations.filter(o => allSeries.has(o.seriesId)) ?? [];
      const assets: DailyRow["assets"] = [];
      const simple: Value[] = [];
      const times: string[] = [];
      for (const o of observations) {
        const series = allSeries.get(o.seriesId)!;
        const sourceDates = frozen!.sourceTimes.filter(t => t.seriesId === o.seriesId && ["valuation", "price", "cash", "manual", "employee"].includes(t.kind)).map(t => t.observedAt);
        times.push(...sourceDates);
        if (o.evidence.kind === "asset" && series.kind === "asset") {
          assets.push({ reference: series.assetId, label: series.label, quantity: value(o.evidence.quantity),
            pru: typeof value(o.evidence.historicalPruEur) === 'number' ? value(o.evidence.historicalPruEur) as number : null, currency: 'EUR',
            pruEur: value(o.evidence.historicalPruEur), grossEur: value(o.evidence.grossEur), observedAt: [...sourceDates].sort().at(-1) ?? null });
        } else if (o.evidence.kind !== "asset") simple.push(value(o.evidence));
      }
      const unresolved = [...allSeries.keys()].some(id => !observations.some(o=>o.seriesId===id));
      const amounts = [...simple, ...assets.map(a => a.grossEur)];
      const total = unresolved || !amounts.length || amounts.some(v => v === null) ? null
        : amounts.every(v => v === "absent") ? "absent"
        : amounts.reduce<number>((sum, v) => sum + (typeof v === "number" ? v : 0), 0);
      const observedAt = [...times].sort().at(-1) ?? null;
      const status = total === "absent" ? "absent" : total === null ? "unavailable"
        : observedAt && observedAt.slice(0, 10) < day ? "carried" : "observed";
      rows.push({ date: day, observedAt, status, value: total, assets,
        cash: frozen?.native?.cash.filter(c => c.contractId === contract.id).map(({ currency, sourceCurrency, amount, observedAt }) => ({ currency, sourceCurrency, amount, observedAt })) ?? [] });
    }
    const events = new Map<string, NativeDay["events"][number]>();
    for (const frozen of sorted) for (const event of frozen.native?.events ?? []) {
      if (event.contractId !== contract.id || event.date.slice(0, 10) < beginning || event.date.slice(0, 10) > ending) continue;
      // The latest frozen capture carries explicit corrections without duplicating operation IDs.
      events.set(event.id, event);
    }
    const out: ContractJson = {
      contrat: { id: contract.id, reference: contractReference(contract.id), libelle: contract.label, type: contract.envelope },
      entete: { schema: "monpatrimoine-contrat-v1", version_sauvegarde: operation, reference_le: capturedAt,
        debut: beginning, fin: ending, archive_annee: null,
        limites: ["Les journées sans preuve sont indisponibles. Les anciens relevés EUR peuvent manquer de PRU natif, de soldes par devise ou d’opérations.",
          "PEG/PER COL : début à la première valorisation individuelle ventilée. Le total commun antérieur reste dans le XLSX."],
        lecture: "Tous les montants et PRU numériques sont en EUR. value/valo est le total brut du contrat ; actifs et espèces en sont le détail, à ne pas additionner une seconde fois au total. pru et pruEur désignent le même coût unitaire EUR. Les quantités sont des nombres de titres/parts, sans arrondi monétaire. La devise source peut être indiquée comme provenance, sans montant natif. Une conversion non justifiée à sa date reste indisponible. null = indisponible, absent = absence attestée, 0 = zéro attesté. Jours inclusifs, indice 0 = jour_debut, chaque tableau jours/etats a la même longueur. Les périodes reconduites conservent observe_le. Décembre peut figurer dans le courant et dans ARCHIVE_. Pour le même contrat, l’archive annuelle fait foi sur sa couverture réelle, le courant complète les jours manquants. Dédupliquer les observations par contrat/date/série et les opérations par identifiant. Deux opérations distinctes du même jour restent distinctes. sens précise entrée/sortie/interne ; un transfert entre contrats ne constitue pas un apport externe." },
      mois: [], periodes: [], operations: [...events.values()].sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id)),
    };
    if (securities.has(contract.envelope)) {
      for (const row of rows) {
        const key = row.date.slice(0, 7);
        let month = out.mois.at(-1);
        if (month?.mois !== key) {
          month = { mois: key, jour_debut: Number(row.date.slice(8)), jour_fin: Number(row.date.slice(8)), jours: [], etats: [] };
          out.mois.push(month);
        }
        month.jour_fin = Number(row.date.slice(8)); month.jours.push(row.date); month.etats.push(row);
      }
    } else {
      for (const row of rows) {
        const prior = out.periodes.at(-1);
        if (prior && prior.valo === row.value && prior.statut === row.status && prior.observe_le === row.observedAt && nextDay(prior.jour_fin) === row.date) prior.jour_fin = row.date;
        else out.periodes.push({ jour_debut: row.date, jour_fin: row.date, valo: row.value, statut: row.status, observe_le: row.observedAt });
      }
    }
    validateContractJson(out);
    results.push(out);
  }
  return results.sort((a, b) => a.contrat.reference.localeCompare(b.contrat.reference));
}
export function validateContractJson(doc: ContractJson) {
  function validateAmounts(value: unknown): void {
    if(typeof value==="number"&&!Number.isFinite(value))throw new Error("Nombre non fini");
    if(Array.isArray(value)){value.forEach(validateAmounts);return;}
    if(value&&typeof value==="object")for(const [key,v] of Object.entries(value)) {
      if(key==="currency"&&v!=="EUR")throw new Error("Montant hors EUR");
      validateAmounts(v);
    }
  }
  validateAmounts(doc);
  if(doc.mois.length&&doc.periodes.length)throw new Error("Deux indexations simultanées");

  if (doc.entete.schema !== "monpatrimoine-contrat-v1" || doc.contrat.reference !== contractReference(doc.contrat.id)) throw new Error("Schéma de contrat invalide");
  civilDay(doc.entete.debut); civilDay(doc.entete.fin);
  if (doc.entete.debut > doc.entete.fin || !Number.isFinite(Date.parse(doc.entete.reference_le))) throw new Error("Couverture invalide");
  const seen = new Set<string>();
  for (const month of doc.mois) {
    if (month.jours.length !== month.etats.length || month.jours.length !== month.jour_fin - month.jour_debut + 1) throw new Error("Alignement invalide");
    month.jours.forEach((day, index) => {
      civilDay(day);
      if (day.slice(0, 7) !== month.mois || Number(day.slice(8)) !== month.jour_debut + index || month.etats[index].date !== day
        || day < doc.entete.debut || day > doc.entete.fin || seen.has(day)) throw new Error("Calendrier invalide");
      seen.add(day);
    });
  }
  let last = "";
  for (const period of doc.periodes) {
    civilDay(period.jour_debut); civilDay(period.jour_fin);
    if (period.jour_debut <= last || period.jour_fin < period.jour_debut || period.jour_debut < doc.entete.debut || period.jour_fin > doc.entete.fin
      || period.statut === "carried" && (!period.observe_le || period.observe_le.slice(0, 10) > period.jour_debut)) throw new Error("Période invalide");
    last = period.jour_fin;
  }
  const covered = doc.mois.length ? [...seen].sort() : doc.periodes.flatMap(p=>[p.jour_debut,p.jour_fin]);
  if(!covered.length||covered[0]!==doc.entete.debut||covered.at(-1)!==doc.entete.fin)throw new Error("Bornes de couverture incohérentes");
  for(let i=1;i<doc.mois.length;i++)if(nextDay(doc.mois[i-1].jours.at(-1)!)!==doc.mois[i].jours[0])throw new Error("Lacune calendrier");
  for(let i=1;i<doc.periodes.length;i++)if(nextDay(doc.periodes[i-1].jour_fin)!==doc.periodes[i].jour_debut)throw new Error("Lacune période");
  const ids = new Set<string>();
  for (const event of doc.operations) {
    civilDay(event.date.slice(0, 10));
    if (!event.id || ids.has(event.id) || event.contractId !== doc.contrat.id || event.date.slice(0, 10) < doc.entete.debut || event.date.slice(0, 10) > doc.entete.fin) throw new Error("Opération invalide");
    ids.add(event.id);
  }
  if (JSON.stringify(doc).length > 5 * 1024 * 1024) throw new Error("JSON trop volumineux");
}

export function annualContractArchive(source: ContractJson, year: number): ContractJson | null {
  validateContractJson(source);
  const start = year + "-01-01", end = year + "-12-31";
  const doc: ContractJson = structuredClone(source);
  doc.mois = doc.mois.flatMap(month => {
    const rows = month.etats.filter(row => row.date >= start && row.date <= end);
    return rows.length ? [{ ...month, jours: rows.map(row => row.date), etats: rows,
      jour_debut: Number(rows[0].date.slice(8)), jour_fin: Number(rows.at(-1)!.date.slice(8)) }] : [];
  });
  doc.periodes = doc.periodes.filter(p => p.jour_fin >= start && p.jour_debut <= end).map(p => ({
    ...p, jour_debut: p.jour_debut < start ? start : p.jour_debut, jour_fin: p.jour_fin > end ? end : p.jour_fin,
  }));
  const dates = [...doc.mois.flatMap(m => m.jours), ...doc.periodes.flatMap(p => [p.jour_debut, p.jour_fin])].sort();
  if (!dates.length) return null;
  doc.entete.debut = dates[0]; doc.entete.fin = dates.at(-1)!; doc.entete.archive_annee = year;
  doc.operations = doc.operations.filter(e => e.date.slice(0,10) >= doc.entete.debut && e.date.slice(0,10) <= doc.entete.fin);
  validateContractJson(doc);
  return doc;
}
