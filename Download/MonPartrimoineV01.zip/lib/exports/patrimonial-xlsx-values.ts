export type ExportNumber = number | string;

export function civilDay(date: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) throw new RangeError("Date civile invalide");
  const time = Date.parse(date + "T00:00:00.000Z");
  if (!Number.isFinite(time) || date < "1900-01-01" || new Date(time).toISOString().slice(0, 10) !== date) {
    throw new RangeError("Date civile hors plage ou invalide");
  }
  // Excel's 1900 system includes the fictitious 29 February 1900.
  return (time - Date.UTC(1899, 11, 31)) / 86_400_000 + (date >= "1900-03-01" ? 1 : 0);
}

export function patrimonialXlsxFilename(date: string) {
  civilDay(date);
  return date.replaceAll("-", ".") + "_Patrimoine.xlsx";
}

function decimal(value: ExportNumber) {
  const raw = String(value);
  const match = /^([+-]?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(raw);
  const exponent = Number(match?.[4] ?? 0);
  if (!match || raw.length > 128 || Math.abs(exponent) > 400 || !Number.isFinite(Number(value))) {
    throw new RangeError("Nombre d’export invalide");
  }
  const integer = match[2];
  const digits = integer + (match[3] ?? "");
  return { negative: match[1] === "-", digits, decimalAt: integer.length + exponent };
}

export function monetaryValue(value: ExportNumber) {
  const { negative, digits, decimalAt } = decimal(value);
  const centsAt = decimalAt + 2;
  if (centsAt < 0) return 0;
  const firstCents = digits.slice(0, centsAt).padEnd(centsAt, "0");
  const cents = Number(firstCents) + (Number(digits[centsAt] ?? 0) >= 5 ? 1 : 0);
  if (!Number.isSafeInteger(cents) || cents > 999_999_999_999_999) {
    throw new RangeError("Montant hors précision Excel");
  }
  return cents === 0 ? 0 : (negative ? -cents : cents) / 100;
}

export function quantityValue(value: ExportNumber) {
  const { digits } = decimal(value);
  const number = Number(value);
  const nonZeroDigits = digits.replace(/^0+|0+$/g, "");
  if (nonZeroDigits.length > 15 || (number === 0 && nonZeroDigits) ||
      (number !== 0 && Math.abs(number) < 2.2250738585072014e-308)) {
    throw new RangeError("Quantité hors précision Excel");
  }
  return number === 0 ? 0 : number;
}
