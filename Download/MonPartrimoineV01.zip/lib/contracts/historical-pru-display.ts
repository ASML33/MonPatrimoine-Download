import { acquisitionProof, acquisitionUnitEur } from "./cto-acquisition-input";
import type { resolveCtoCost } from "./cto-documented-cost";

export type HistoricalPruDisplay = {
  unitEur: number;
  basis: "documented" | "estimated" | "native_eur";
};

export function historicalPruDisplay(
  cost: Pick<ReturnType<typeof resolveCtoCost>, "total" | "conflict" | "documented" | "estimated">,
  { metadata, native, currency, day, quantity }: {
    metadata: unknown;
    native: string | number | null;
    currency: string;
    day: string;
    quantity: number;
  },
): HistoricalPruDisplay | null {
  if (cost.conflict || cost.total === null || !Number.isFinite(cost.total) || cost.total < 0 ||
      !Number.isFinite(quantity) || quantity <= 0) return null;

  const unitEur = cost.total / quantity;
  if (!Number.isFinite(unitEur)) return null;
  if (cost.documented) return { unitEur, basis: "documented" };
  if (currency === "EUR" && native !== null && String(native).trim() && Number.isFinite(Number(native))) {
    return { unitEur, basis: "native_eur" };
  }
  if (!cost.estimated) return null;

  // Main also accepts a newer fallback rate for the financial cost. It cannot qualify a historical PRU.
  const acquired = acquisitionUnitEur(metadata, native, currency, day);
  if (typeof acquired === "number") {
    const proof = acquisitionProof(metadata, native, currency, day);
    const observedOn = proof?.fx?.rate?.observed_on;
    if (!proof || !observedOn || !/^\d{4}-\d{2}-\d{2}$/.test(observedOn) ||
        !Number.isFinite(Date.parse(observedOn)) || observedOn > proof.effectiveOn) return null;
  }
  return { unitEur, basis: "estimated" };
}
