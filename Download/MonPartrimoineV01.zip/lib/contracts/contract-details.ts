import { historicalPruDisplay, type HistoricalPruDisplay } from "./historical-pru-display";
import { resolveCtoCost } from "./cto-documented-cost";
import { acquisitionStatus } from "@/lib/contracts/cto-acquisition-input";
import { contributionHistory, correctedContributions, type ContributionHistory } from "@/lib/cash/contribution-corrections";
import { linksFlowsToCash } from "@/lib/cash/flow-cash";
import { CONTRACT_COLUMNS } from "@/lib/contracts/contract-columns";
import {isAmountTracked,knownFlowAnchors,resolveContractGain} from '@/lib/contracts/contract-gain';
import {propertyHistory,propertyValue,propertyReplacedBy,propertyMembers,type PropertyHistory} from "@/lib/contracts/property-valuations";
import { positionHistory,selectDatedPosition,observationAt,type PositionObservation } from "@/lib/contracts/position-observations";
import { selectDatedBalances } from "@/lib/cash/dated-balances";
import { ctoBrokerBasis } from "@/lib/contracts/cto-broker-basis";
import type { PositionHistory } from "@/lib/contracts/position-observations";
import { activeCashLink } from "@/lib/cash/flow-cash";
import { legacyBalanceActions, type SecuritiesCashAction } from "@/lib/cash/securities-actions";
import { isContractInUserScope } from "@/lib/contracts/contract-scope";
import { readManualSituations } from "@/lib/patrimony/manual-situations";
import {latestEmployeeSavingsValue} from "@/lib/patrimony/employee-savings-values";
import { selectManualSituation, selectManualSimulation, type ManualSituation, type ManualSimulation } from "@/lib/patrimony/manual-situation-core";
import { parisDate } from "@/lib/patrimony/current-valuation-core";
import "server-only";

import { parisDateFromIso, calculateCashFlowAggregates, calculateContractCurrencySummaries, formatParisLocalInput, type ContractCurrencySummary } from "@/lib/cash/cash-core";
import { calculateContractUnrealizedValue, calculateEstimationVariation, calculatePositionUnrealizedValue, getLatestSuccessfulPriceRetrievalTimestamp, isRetainedPriceAfterRefreshFailure, resolveContractPositionValuation, resolveContractTotalValue } from "@/lib/contracts/contract-detail-core";
import { convertToEur, latestFxRatesByCurrency, type FxRateRecord } from "@/lib/fx/fx-core";
import { selectLatestPositionSnapshots, selectLatestUsablePrices } from "@/lib/patrimony/current-valuation-core";
import { createClient } from "@/lib/supabase/server";

type RawPrice = { asset_id: string; origin: "automatic" | "manual"; price: number | string; currency_code: string; observed_at: string; obtained_at: string; source_name: string | null };
type RawSnapshot = { id?:string; position_id: string; unit_price: number | string | null; market_value: number | string; currency_code: string; valued_at: string };
type RawFlow = { id: string; updated_at?: string; kind: "contribution" | "withdrawal" | "transfer"; amount: number | string; currency_code: string; occurred_at: string; note: string | null; fx_rate_id: string | null; fx_status: "resolved" | "pending" | "manual_required"; destination_contract_id: string | null; source_contract_id: string | null };

export type SupportedCurrency = { code: string };
export type ContractPositionView = { euroFund?:boolean; amountArchived?:{id:string;date:string;amount:string;currency:string}[]; updatedAt?:string; amountTracked?:boolean; amountEditable?:boolean; amountTrackingConflict?:boolean; amountObservations?:{id:string;date:string;amount:string;currency:string}[]; property?:PropertyHistory; propertyEnded?:boolean;propertyInitialEur?:number|null;propertyInitialOn?:string|null; observations?:PositionObservation[]; observationArchives?:number; archivedObservations?:{entries:PositionObservation[];replacedAt:string;undatedPrevious?:{quantity:string;unitCost:string|null;currency:string;isActive:boolean}|null}[]; protectedObservationDates?:number; observationDate?:string|null;
  id: string;
  assetId: string;
  assetName: string;
  symbol: string | null;
  quantity: string;
  averageCostPerUnit: string | null;
  costCurrencyCode: string;
  currentPrice: string | null;
  currentPriceEur?: number | null;
  ctoCostConflict?: boolean;
  historicalPruEur?: HistoricalPruDisplay | null;
  averageCostPerUnitEur?: number | null;
  acquisitionFx?: ReturnType<typeof acquisitionStatus>;
  brokerCost?: { status: "estimated" | "unavailable" | "not_applicable"; effectiveOn?: string };
  currentPriceCurrency: string | null;
  currentPriceAt: string | null;
  currentPriceRetrievedAt: string | null;
  priceSource: string | null;
  priceRefreshFailed?: boolean;
  marketValue: number | null;
  marketValueEur: number | null;
  acquisitionCostEur: number | null;
  unrealizedGainEur: number | null;
  unrealizedGainPercentage: number | null;
};
export type ContractCashBalanceView = {
  actions?: SecuritiesCashAction[];
  updatedAt?: string;
  id: string;
  amount: string;
  currencyCode: string;
  asOf: string;
  asOfLocal: string;
  amountEur: number | null;
  fxSource: string | null;
  fxSourceLabel: string | null;
  fxObservedOn: string | null;
};
export type ContractCashFlowView = {
  cashLinked?: boolean;
  updatedAt?: string;
  id: string;
  kind: "contribution" | "withdrawal";
  amount: string;
  currencyCode: string;
  occurredAt: string;
  occurredAtLocal: string;
  note: string | null;
  amountEur: number | null;
  fxStatus: "resolved" | "pending" | "manual_required";
  fxSource: string | null;
  fxSourceLabel: string | null;
  fxObservedOn: string | null;
};
export type ContractDetail = { contributionCorrections?:ContributionHistory; displayedContributionsEur?:number|null; contributionRevision?:string; cashRevision?: import("@/lib/cash/flow-cash").CashRevision[]; gain:ReturnType<typeof resolveContractGain>;
  manual?: { available: boolean; authorized: boolean; situation: ManualSituation | null; simulation: ManualSimulation | null;value:import("@/lib/patrimony/employee-savings-values").EmployeeSavingsValue|null;observations:import("@/lib/patrimony/employee-savings-values").EmployeeSavingsValue[];archives:import("@/lib/patrimony/employee-savings-values").EmployeeSavingsValue[] };
  contract: { sourceKey?:string|null; envelopeTypeId?:string;fiscalAssignments?:unknown;id: string; name: string; institutionName: string | null; openedOn: string | null; closedOn: string | null; currencyCode: string; envelopeTypeCode: string; envelopeTypeLabel: string; isActive: boolean;replacedBy?:string|null;propertySources?:{sourceContractId:string;assetId:string}[] };
  positions: ContractPositionView[];
  availableAssets: Array<{ id: string; name: string; symbol: string | null; currencyCode?: string; amountEligible?: boolean }>;
  currencies: SupportedCurrency[];
  cashBalances: ContractCashBalanceView[];
  cashFlows: ContractCashFlowView[];
  currencySummaries: ContractCurrencySummary[];
  lastFlowCurrencyCode: string | null;
  totalContributionsEur: number;
  netCashFlowsEur: number;
  cashEur: number;
  securitiesValueEur: number;
  totalValueEur: number | null;
  unrealizedGainEur: number;
  unrealizedGainPercentage: number | null;
  valuedUnrealizedPositions: number;
  incompleteUnrealizedPositions: number;
  valuationUpdatedAt: string | null;
  incompletePositions: number;
  incompleteCashBalances: number;
  incompleteContributionFlows: number;
  incompleteNetCashFlows: number;
  knownTotalContributionsEur: number | null;
  knownTotalContributionsAsOf: string | null;
  knownNetCashFlowsEur: number | null;
  estimationVariationEur: number | null;
  estimationVariationPercentage: number | null;
  initialEstimationEur: number | null;
  initialEstimationAt: string | null;
};

function sourceLabel(source: string | null) {
  if (source === "ecb") return "BCE";
  if (source === "frankfurter") return "Frankfurter";
  if (source === "manual") return "manuel";
  return null;
}

type BrokerSource = { id: string; source_sha256: string; repair: { contractId?: string; sourceId?: string; sourceSha256?: string; date?: string; expected?: { positions?: { id: string }[] }; positions?: { assetId: string; basis: unknown }[] } };
const canonicalBrokerValue = (value: unknown): string => JSON.stringify(value, (_key, item: unknown) => item && typeof item === "object" && !Array.isArray(item) ? Object.fromEntries(Object.entries(item).sort(([a], [b]) => a.localeCompare(b))) : item);
const canonicalBrokerDecimal = (value: unknown) => typeof value === "string" && /^\d+(?:\.\d+)?$/.test(value) ? value.replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "") : null;
function brokerPositionCost(position: { id: string; asset_id: string; metadata?: unknown }, nativeCost: string | number | null, currency: string, day: string, contractId: string, sources: BrokerSource[] | null, history: PositionHistory | null): { use: boolean; unitEur: number | null; view?: { brokerCost: NonNullable<ContractPositionView["brokerCost"]>; averageCostPerUnitEur?: number | null } } {
  const metadata = position.metadata as { cto_broker_basis?: { effectiveOn?: string; unitCostUsd?: string; sourceSha256?: string } } | null;
  if (!metadata || !Object.prototype.hasOwnProperty.call(metadata, "cto_broker_basis")) return { use: false, unitEur: null };
  const unavailable = { use: true, unitEur: null, view: { brokerCost: { status: "unavailable" as const }, averageCostPerUnitEur: null } };
  const proof = metadata.cto_broker_basis, source = sources?.length === 1 ? sources[0] : null, plan = source?.repair;
  const entries = Array.isArray(plan?.positions) ? plan.positions.filter(entry => entry?.assetId === position.asset_id) : [];
  const nativeIds = Array.isArray(plan?.expected?.positions) ? plan.expected.positions.filter(entry => entry?.id === position.id) : [];
  if (!proof || !source || !plan || plan.contractId !== contractId || plan.sourceId !== source.id || plan.sourceSha256 !== source.source_sha256 || proof.sourceSha256 !== source.source_sha256 || plan.date !== proof.effectiveOn || nativeIds.length !== 1 || entries.length !== 1 || canonicalBrokerValue(entries[0].basis) !== canonicalBrokerValue(proof)) return unavailable;
  const observation = history ? observationAt(history.entries, day) : null;
  if (!observation) return unavailable;
  const basis = ctoBrokerBasis(position.metadata, nativeCost, currency, day);
  // The dated observation keeps the exact decimal text even when the transport
  // represents the numeric materialization as a JS Number. Quantity may change.
  if (!basis || observation.effectiveOn < basis.effectiveOn || observation.currency !== currency || canonicalBrokerDecimal(observation.unitCost) !== canonicalBrokerDecimal(proof.unitCostUsd)) return { use: false, unitEur: null, view: { brokerCost: { status: "not_applicable" } } };
  return { use: true, unitEur: basis.unitEurEstimate, view: { brokerCost: { status: "estimated", effectiveOn: basis.effectiveOn }, averageCostPerUnitEur: basis.unitEurEstimate } };
}

export async function getContractDetail(contractId: string, userId: string): Promise<ContractDetail | null> {
  if (!isContractInUserScope(contractId)) return null;
  const supabase = await createClient();
  const [contractResult, positionsResult, cashResult, flowsResult, allAssetsResult, currenciesResult] = await Promise.all([
    supabase.from("contracts").select(`${CONTRACT_COLUMNS},envelope_types(code,label)`).eq("id", contractId).eq("user_id", userId).maybeSingle(),
    supabase.from("positions").select("id,asset_id,quantity,average_cost_per_unit,cost_currency_code,is_active,metadata,updated_at").eq("contract_id", contractId).eq("user_id", userId).eq("is_active", true).order("created_at"),
    supabase.from("cash_balances").select("id,amount,currency_code,as_of,metadata,updated_at").eq("contract_id", contractId).eq("user_id", userId).order("currency_code"),
    supabase.from("cash_flows").select("id,updated_at,kind,amount,currency_code,occurred_at,note,fx_rate_id,fx_status,destination_contract_id,source_contract_id").eq("user_id", userId).order("occurred_at", { ascending: false }),
    supabase.from("assets").select("id,name,symbol,currency_code,asset_type_code,valuation_mode,is_active,metadata").eq("owner_user_id", userId).order("name"),
    supabase.from("currencies").select("code").eq("is_active", true).order("code"),
  ]);
  if (contractResult.error || positionsResult.error || cashResult.error || flowsResult.error || allAssetsResult.error || currenciesResult.error) throw new Error("Contract detail unavailable");
  if (!contractResult.data) return null;

  const contractFlows = ((flowsResult.data ?? []) as RawFlow[]).filter((flow) => (flow.destination_contract_id ?? flow.source_contract_id) === contractId && flow.kind !== "transfer" && Date.parse(flow.occurred_at)<=Date.now());
  const assetIds = [...new Set((positionsResult.data ?? []).map((position) => position.asset_id))];
  const positionIds = (positionsResult.data ?? []).map((position) => position.id);
  const requestedAssetIds = new Set(assetIds);
  const automaticAssetIds = (allAssetsResult.data ?? [])
    .filter(asset => requestedAssetIds.has(asset.id) && asset.valuation_mode === "market_price")
    .map(asset => asset.id);
  const [pricesResult, snapshotsResult, refreshResult] = await Promise.all([
    assetIds.length
      ? supabase.from("asset_prices").select("asset_id,origin,price,currency_code,observed_at,obtained_at,source_name").in("asset_id", assetIds).order("observed_at", { ascending: false }).order("obtained_at", { ascending: false })
      : { data: [], error: null },
    positionIds.length
      ? supabase.from("position_snapshots").select("id,position_id,unit_price,market_value,currency_code,valued_at").in("position_id", positionIds).order("valued_at", { ascending: false })
      : { data: [], error: null },
    automaticAssetIds.length
      ? supabase.from("asset_price_refresh_status").select("asset_id,status,last_attempted_at").in("asset_id", automaticAssetIds)
      : { data: [], error: null },
  ]);
  if (pricesResult.error || snapshotsResult.error) throw new Error("Contract valuations unavailable");

  const valuationCurrencies = [...new Set([
    ...(cashResult.data ?? []).map((balance) => balance.currency_code),
    ...(positionsResult.data ?? []).map((position) => position.cost_currency_code),
    ...(positionsResult.data??[]).flatMap(p=>propertyHistory(p.metadata)?.entries.map(e=>e.currency)??[]),
    ...((pricesResult.data ?? []) as RawPrice[]).map((price) => price.currency_code),
    ...((snapshotsResult.data ?? []) as RawSnapshot[]).map((snapshot) => snapshot.currency_code),
  ].filter((currency) => currency !== "EUR"))];
  const flowRateIds = [...new Set(contractFlows.flatMap((flow) => flow.fx_rate_id ? [flow.fx_rate_id] : []))];
  const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Paris" }).format(new Date());
  const [currentRatesResult, flowRatesResult] = await Promise.all([
    valuationCurrencies.length
      ? supabase.from("fx_rates").select("id,currency_code,requested_on,observed_on,eur_per_unit,source,obtained_at").in("currency_code", valuationCurrencies).lte("requested_on", today).order("requested_on", { ascending: false }).order("obtained_at", { ascending: false })
      : { data: [], error: null },
    flowRateIds.length
      ? supabase.from("fx_rates").select("id,currency_code,requested_on,observed_on,eur_per_unit,source,obtained_at").in("id", flowRateIds)
      : { data: [], error: null },
  ]);
  if (currentRatesResult.error || flowRatesResult.error) throw new Error("Contract FX rates unavailable");
  const currentRates = latestFxRatesByCurrency((currentRatesResult.data ?? []) as FxRateRecord[], today);
  const flowRates = new Map(((flowRatesResult.data ?? []) as FxRateRecord[]).map((rate) => [rate.id!, rate]));

  const assets = new Map((allAssetsResult.data ?? []).map((asset) => [asset.id, asset]));
  const envelopeTypeRelation = contractResult.data.envelope_types as { label: string; code: string } | { label: string; code: string }[] | null;
  const envelopeType = Array.isArray(envelopeTypeRelation) ? envelopeTypeRelation[0] : envelopeTypeRelation;
  if (!envelopeType) throw new Error("Contract envelope type unavailable");
  const needsBrokerSource = ["cto", "compte_titres"].includes(envelopeType.code) && (positionsResult.data ?? []).some(position => Object.prototype.hasOwnProperty.call(position.metadata ?? {}, "cto_broker_basis"));
  const brokerSourcesResult = needsBrokerSource ? await supabase.from("patrimonial_legacy_sources").select("id,source_sha256,repair:payload->repair->plan").eq("user_id", userId).eq("payload->>kind", "approved_cto_broker_history").eq("payload->>version", "2").eq("payload->>contractId", contractId).limit(2) : { data: [], error: null };
  const brokerSources = brokerSourcesResult.error ? null : brokerSourcesResult.data as BrokerSource[];
  const latestPrices = selectLatestUsablePrices(
    allAssetsResult.data ?? [],
    (pricesResult.data ?? []) as RawPrice[],
  );
  const refreshByAsset = new Map((refreshResult.error ? [] : refreshResult.data ?? []).map(refresh => [refresh.asset_id, refresh]));
  const latestSnapshots = selectLatestPositionSnapshots((snapshotsResult.data ?? []) as RawSnapshot[]);
  const earliestSnapshots = new Map<string, RawSnapshot>();
  for (const snapshot of [...((snapshotsResult.data ?? []) as RawSnapshot[])].sort((a, b) => Date.parse(a.valued_at) - Date.parse(b.valued_at))) {
    if (!earliestSnapshots.has(snapshot.position_id)) earliestSnapshots.set(snapshot.position_id, snapshot);
  }

  let incompletePositions = 0;
  const positions: ContractPositionView[] = (positionsResult.data ?? []).flatMap((position) => {
    const asset = assets.get(position.asset_id);
    if (!asset) return [];
    const price = latestPrices.get(asset.id);
    const snapshot = latestSnapshots.get(position.id);
    const history=positionHistory(position.metadata);
    const selected=selectDatedPosition({...position,contract_id:contractId},today);
    const amountTracked=asset.asset_type_code!=='real_estate'&&isAmountTracked(asset.valuation_mode,!!price,!!history,snapshot,position.metadata);
    const quantity = selected.quantity==null?NaN:Number(selected.quantity);
    const averageCostPerUnit = amountTracked || selected.average_cost_per_unit == null ? null : Number(selected.average_cost_per_unit);
    const property=asset.asset_type_code==="real_estate";
    const ph=propertyHistory(position.metadata);
    const pv=ph?propertyValue(position.metadata,today,(currentRatesResult.data??[]) as FxRateRecord[]):null;
    const valuation = pv?{marketValue:pv.ended?0:pv.observation?.amount==null?null:Number(pv.observation.amount),unitPrice:null,currencyCode:pv.observation?.currency??null,valuedAt:pv.observation?.effectiveOn??null,retrievedAt:null,source:pv.observation?.provenance??null}:resolveContractPositionValuation({ quantity, amountTracked, price:property?undefined:price, snapshot:history?undefined:snapshot });
    const priceRefreshFailed = !pv && !amountTracked && price?.origin === "automatic"
      && valuation.unitPrice !== null && Number.isFinite(valuation.unitPrice)
      && isRetainedPriceAfterRefreshFailure(refreshByAsset.get(asset.id), valuation.retrievedAt);
    const acquisitionCost = averageCostPerUnit === null ? null : quantity * averageCostPerUnit;
    const brokerCost = ["cto", "compte_titres"].includes(envelopeType.code) ? brokerPositionCost(position, selected.average_cost_per_unit, selected.cost_currency_code, today, contractId, brokerSources, history) : { use: false, unitEur: null, view: undefined };
    const conversion = valuation.currencyCode && valuation.marketValue !== null
      ? convertToEur(valuation.marketValue, valuation.currencyCode, currentRates.get(valuation.currencyCode))
      : { amountEur: null, rate: null };
    const isCto = ["cto", "compte_titres"].includes(envelopeType.code);
    const legacyUnit = averageCostPerUnit === null ? null : convertToEur(averageCostPerUnit, selected.cost_currency_code, currentRates.get(selected.cost_currency_code)).amountEur;
    const ctoCost = isCto ? resolveCtoCost({
      metadata: position.metadata, observation: history ? observationAt(history.entries, today) : null,
      native: selected.average_cost_per_unit, currency: selected.cost_currency_code, day: today, quantity,
      legacyUnit: brokerCost.use ? null : legacyUnit, brokerUnit: brokerCost.unitEur,
    }) : null;
    const historicalPruEur = ctoCost ? historicalPruDisplay(ctoCost, {
      metadata: position.metadata, native: selected.average_cost_per_unit, currency: selected.cost_currency_code, day: today, quantity,
    }) : undefined;
    const acquisitionConversion = ctoCost ? { amountEur: ctoCost.total, rate: null } :
      acquisitionCost === null ? { amountEur: null, rate: null } : convertToEur(acquisitionCost, selected.cost_currency_code, currentRates.get(selected.cost_currency_code));
    const unrealized = calculatePositionUnrealizedValue({
      acquisitionCostEur: acquisitionConversion.amountEur,
      marketValueEur: conversion.amountEur,
    });
    if (conversion.amountEur === null || !Number.isFinite(conversion.amountEur)) incompletePositions += 1;
    const firstProperty=ph?.entries.filter(e=>e.kind==="valuation"&&Number(e.amount)>0).sort((a,b)=>a.effectiveOn.localeCompare(b.effectiveOn))[0];
    const originalProperty=earliestSnapshots.get(position.id);
    const initialPropertyEur=originalProperty?convertToEur(originalProperty.market_value,originalProperty.currency_code,latestFxRatesByCurrency((currentRatesResult.data??[]) as FxRateRecord[],parisDate(originalProperty.valued_at)).get(originalProperty.currency_code)).amountEur:firstProperty?propertyValue({property_valuations:{version:1,entries:[firstProperty],archived:[]}},firstProperty.effectiveOn,(currentRatesResult.data??[]) as FxRateRecord[]).amountEur:null;
    return [{euroFund:envelopeType.code==="assurance_vie"&&asset.asset_type_code==="fund"&&asset.valuation_mode==="manual"&&amountTracked,amountArchived:Array.isArray(position.metadata?.amount_observation_audit)?position.metadata.amount_observation_audit.flatMap((entry:unknown)=>{const before=(entry as {before?:unknown})?.before;return (Array.isArray(before)?before:before?[before]:[]).flatMap((s:{id?:string;valued_at?:string;market_value?:string;currency_code?:string})=>s.id&&s.valued_at&&s.market_value!=null&&s.currency_code?[{id:s.id,date:parisDate(s.valued_at),amount:String(s.market_value),currency:s.currency_code}]:[]);}):[],updatedAt:position.updated_at,amountTracked,amountEditable:amountTracked&&asset.asset_type_code==="fund",amountTrackingConflict:asset.valuation_mode==="manual"&&asset.asset_type_code==="fund"&&!!snapshot&&(!!history&&!price||!!price&&!!position.metadata?.abeille_test_repair),amountObservations:amountTracked?((snapshotsResult.data??[]) as RawSnapshot[]).filter(s=>s.position_id===position.id&&!!s.id).map(s=>({id:s.id!,date:parisDate(s.valued_at),amount:String(s.market_value),currency:s.currency_code})):undefined,property:ph??undefined,propertyEnded:pv?.ended,propertyInitialEur:initialPropertyEur,propertyInitialOn:originalProperty?parisDate(originalProperty.valued_at):firstProperty?.effectiveOn, protectedObservationDates:history?.lastReview?.filter(r=>r.protected).length??0,archivedObservations:history?.archived.map(a=>({entries:a.entries,replacedAt:a.replacedAt,undatedPrevious:a.undatedPrevious})),observations:history?.entries,observationArchives:history?.archived.length,observationDate:history?observationAt(history.entries,today)?.effectiveOn:null,id: position.id, assetId: asset.id, assetName: asset.name, symbol: asset.symbol, quantity: String(selected.quantity), averageCostPerUnit: selected.average_cost_per_unit === null ? null : String(selected.average_cost_per_unit), costCurrencyCode: selected.cost_currency_code, currentPriceEur: valuation.unitPrice === null || !valuation.currencyCode ? null : convertToEur(valuation.unitPrice, valuation.currencyCode, currentRates.get(valuation.currencyCode)).amountEur, averageCostPerUnitEur:ctoCost ? ctoCost.displayUnit : legacyUnit, ctoCostConflict: ctoCost?.conflict, historicalPruEur, currentPrice: valuation.unitPrice !== null && Number.isFinite(valuation.unitPrice) ? String(valuation.unitPrice) : null, currentPriceCurrency: valuation.currencyCode, currentPriceAt: valuation.valuedAt, currentPriceRetrievedAt: valuation.retrievedAt, priceSource: valuation.source, ...(priceRefreshFailed ? { priceRefreshFailed } : {}), marketValue: valuation.marketValue !== null && Number.isFinite(valuation.marketValue) ? valuation.marketValue : null, marketValueEur: conversion.amountEur, ...unrealized, ...(ctoCost ? { acquisitionCostEur: ctoCost.total } : {}), brokerCost:brokerCost.view?.brokerCost, ...(acquisitionStatus(position.metadata,selected.average_cost_per_unit,selected.cost_currency_code,today)?{acquisitionFx:acquisitionStatus(position.metadata,selected.average_cost_per_unit,selected.cost_currency_code,today)}:{}) }];
  });

  let incompleteCashBalances = 0;
  const cashBalances: ContractCashBalanceView[] = selectDatedBalances((envelopeType.code==='assurance_vie'?[]:cashResult.data ?? []).map(balance => ({ ...balance, contract_id: contractId })), new Date().toISOString()).map((balance) => {
    const rate = currentRates.get(balance.currency_code);
    const conversion = convertToEur(balance.amount, balance.currency_code, rate);
    if (conversion.amountEur === null) incompleteCashBalances += 1;
    return { actions:legacyBalanceActions((cashResult.data ?? []).find(row=>row.id===balance.id)!,contractFlows), id: balance.id, updatedAt: (cashResult.data ?? []).find(row => row.id === balance.id)?.updated_at, amount: String(balance.amount), currencyCode: balance.currency_code, asOf: balance.as_of, asOfLocal: formatParisLocalInput(balance.as_of), amountEur: conversion.amountEur, fxSource: rate?.source ?? null, fxSourceLabel: sourceLabel(rate?.source ?? null), fxObservedOn: rate?.observed_on ?? null };
  });

  const cashFlows: ContractCashFlowView[] = contractFlows.map((flow) => {
    const rate = flow.fx_rate_id ? flowRates.get(flow.fx_rate_id) : null;
    const conversion = convertToEur(flow.amount, flow.currency_code, rate);
    return { id: flow.id, cashLinked: (cashResult.data ?? []).some(row => activeCashLink(row.metadata, flow.id)), updatedAt: flow.updated_at, kind: flow.kind as "contribution" | "withdrawal", amount: String(flow.amount), currencyCode: flow.currency_code, occurredAt: flow.occurred_at, occurredAtLocal: formatParisLocalInput(flow.occurred_at), note: flow.note, amountEur: conversion.amountEur, fxStatus: flow.fx_status, fxSource: rate?.source ?? null, fxSourceLabel: sourceLabel(rate?.source ?? null), fxObservedOn: rate?.observed_on ?? null };
  });
  const { totalContributionsEur, netCashFlowsEur, incompleteContributionFlows, incompleteNetCashFlows } = calculateCashFlowAggregates(cashFlows);
  const currencySummaries = calculateContractCurrencySummaries(
    contractResult.data.currency_code,
    cashBalances,
    cashFlows,
    positions.flatMap((position) => [position.costCurrencyCode, position.currentPriceCurrency]),
  );

  const valuationPositions = envelopeType.code === "epargne_liquide" ? [] : positions;
  if (envelopeType.code === "epargne_liquide") incompletePositions = 0;
  const securitiesValueEur = valuationPositions.reduce((sum, position) => sum + (position.marketValueEur ?? 0), 0);
  const cashEur = cashBalances.reduce((sum, balance) => sum + (balance.amountEur ?? 0), 0);
  const knownValueCount = valuationPositions.filter((position) => position.marketValueEur !== null).length
    + cashBalances.filter((balance) => balance.amountEur !== null).length;
  const unrealized = calculateContractUnrealizedValue(positions.filter(p=>!p.amountTracked&&Number(p.quantity)>0));
  const valuationUpdatedAt = getLatestSuccessfulPriceRetrievalTimestamp(positions);
  const usedAssets = new Set(positions.map((position) => position.assetId));
  const now = new Date().toISOString();
  const manualModule = await readManualSituations(supabase, userId, now, [contractId]);
  const manual = { available: manualModule.available, authorized: ["peg", "per_col"].includes(envelopeType.code),
    value:latestEmployeeSavingsValue(manualModule.employeeSavingsValuations??[],contractId,now),
    observations:(manualModule.employeeSavingsValuations??[]).filter(e=>e.contractId===contractId),
    archives:(manualModule.employeeSavingsArchives??[]).filter(e=>e.contractId===contractId),
    situation: selectManualSituation(manualModule.manualSituations, contractId, now),
    simulation: selectManualSimulation(manualModule.manualSimulations, contractId, parisDate(now), now) };
  const metadata = (contractResult.data.metadata ?? {}) as Record<string, unknown>;
  const knownContribution = knownFlowAnchors(metadata,today).contribution;
  const knownTotalContributionsEur = knownContribution !== null && knownContribution >= 0 ? knownContribution : null;
  const knownNetCashFlows = knownFlowAnchors(metadata,today).net;
  const knownNetCashFlowsEur = Number.isFinite(knownNetCashFlows) ? knownNetCashFlows : null;
  const simultaneousInitial=positions.length>0&&positions.every(p=>!p.propertyEnded)&&positionIds.every(id=>earliestSnapshots.has(id))&&new Set([...earliestSnapshots.values()].map(s=>parisDate(s.valued_at))).size===1;
  const initialEstimationEur = envelopeType.code === "immobilier" && simultaneousInitial
    ? positionIds.reduce((sum, positionId) => sum + Number(earliestSnapshots.get(positionId)?.market_value ?? 0), 0)
    : null;
  const initialEstimationAt = envelopeType.code === "immobilier"
    ? [...earliestSnapshots.values()].map((row) => row.valued_at).sort()[0] ?? null
    : null;
  const totalValueEur = resolveContractTotalValue({ securitiesValueEur, cashEur, inputCount: valuationPositions.length + cashBalances.length, knownValueCount, requireObservation: true });
  const estimationVariation = envelopeType.code === "immobilier"
    ? calculateEstimationVariation(totalValueEur, initialEstimationEur)
    : { amount: null, percentage: null };
  return {
    contributionCorrections:contributionHistory(metadata), contributionRevision:contractResult.data.updated_at,
    displayedContributionsEur:(linksFlowsToCash(envelopeType.code)||envelopeType.code==="assurance_vie")?correctedContributions(knownTotalContributionsEur??(incompleteContributionFlows?null:totalContributionsEur),today,contributionHistory(metadata),cashFlows.map(f=>({id:f.id,kind:f.kind,date:parisDateFromIso(f.occurredAt),amountEur:f.amountEur}))):undefined,
    gain:resolveContractGain(incompletePositions||incompleteCashBalances?null:totalValueEur,cashFlows,metadata,today),
    manual,
    contract: { sourceKey:typeof metadata.sourceKey === "string" ? metadata.sourceKey : null, envelopeTypeId:contractResult.data.envelope_type_id,fiscalAssignments:contractResult.data.fiscal_assignments,id: contractResult.data.id, name: contractResult.data.name, institutionName: contractResult.data.institution_name, openedOn: contractResult.data.opened_on, closedOn: contractResult.data.closed_on, currencyCode: contractResult.data.currency_code, envelopeTypeCode: envelopeType.code, envelopeTypeLabel: envelopeType.label, isActive: contractResult.data.is_active,replacedBy:propertyReplacedBy(metadata),propertySources:propertyMembers(metadata) },
    positions,
    availableAssets: (allAssetsResult.data ?? []).filter((asset) => asset.is_active && !usedAssets.has(asset.id) && (!(asset.metadata?.automatic_euro_fund) || asset.metadata.automatic_euro_fund.contractId === contractId) && (envelopeType.code!=="immobilier" || asset.asset_type_code==="real_estate"&&asset.valuation_mode==="manual")).map((asset) => ({ id: asset.id, name: asset.name, symbol: asset.symbol, currencyCode: asset.currency_code, amountEligible: asset.asset_type_code === "fund" && asset.valuation_mode === "manual" })),
    cashRevision: (cashResult.data ?? []).map(row => ({id: row.id, updatedAt: row.updated_at})),
    currencies: currenciesResult.data ?? [], cashBalances, cashFlows, currencySummaries, lastFlowCurrencyCode: cashFlows[0]?.currencyCode ?? null, totalContributionsEur: knownTotalContributionsEur ?? totalContributionsEur, netCashFlowsEur: knownNetCashFlowsEur ?? netCashFlowsEur, cashEur, securitiesValueEur, totalValueEur, unrealizedGainEur: unrealized.unrealizedGainEur, unrealizedGainPercentage: unrealized.unrealizedGainPercentage, valuedUnrealizedPositions: unrealized.valuedPositions, incompleteUnrealizedPositions: unrealized.incompletePositions, valuationUpdatedAt, incompletePositions, incompleteCashBalances, incompleteContributionFlows, incompleteNetCashFlows,
    knownTotalContributionsEur, knownTotalContributionsAsOf: typeof metadata.knownTotalContributionsAsOf === "string" ? metadata.knownTotalContributionsAsOf : null, knownNetCashFlowsEur,
    initialEstimationEur, initialEstimationAt, estimationVariationEur: estimationVariation.amount,
    estimationVariationPercentage: estimationVariation.percentage,
  };
}
