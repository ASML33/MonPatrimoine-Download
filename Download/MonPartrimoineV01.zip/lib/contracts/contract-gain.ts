import { historicalContractGain } from '@/lib/patrimony/chart-core';
import { calculateCashFlowAggregates, type ConvertedCashFlow } from '@/lib/cash/cash-core';

// A total-position snapshot is a monetary observation, not a unit price.
// Manual unit prices and dated quantity observations retain securities semantics.
export function isAmountTracked(valuationMode:string, hasUnitPrice:boolean, hasHoldingHistory:boolean, snapshot?:{unit_price?:number|string|null}|null, metadata?:unknown){
 const initial=metadata&&typeof metadata==='object'&&'initial_amount' in metadata?metadata.initial_amount:null;
 const explicit=initial&&typeof initial==='object'&&'version' in initial&&initial.version===1;
 return valuationMode==='manual'&&!hasUnitPrice&&!hasHoldingHistory&&Boolean(snapshot||explicit);
}
export function knownFlowNumber(value:unknown):number|null{
 if(value===null||value===undefined||value===''||typeof value==='boolean')return null;
 if(typeof value!=='number'&&typeof value!=='string')return null;
 if(typeof value==='string'&&!value.trim())return null;
 const n=Number(value);return Number.isFinite(n)?n:null;
}
export function knownFlowAnchors(metadata:Record<string,unknown>={},asOf?:string){
 const anchorDate=metadata.knownTotalContributionsAsOf;
 const usable=typeof anchorDate!=='string'||!asOf||anchorDate===asOf;
 return {contribution:usable?knownFlowNumber(metadata.knownTotalContributionsEur):null,net:usable?knownFlowNumber(metadata.knownNetCashFlowsEur):null};
}
export function resolveContractGain(value:number|null,flows:ConvertedCashFlow[],metadata:Record<string,unknown>={},asOf?:string){
 const aggregate=calculateCashFlowAggregates(flows);
 // An anchor is not a ledger from which other dates can be reconstructed.
 const {contribution,net}=knownFlowAnchors(metadata,asOf);
 return historicalContractGain(value,
  net??(flows.length&&!aggregate.incompleteNetCashFlows?aggregate.netCashFlowsEur:null),
  contribution??(flows.length&&!aggregate.incompleteContributionFlows?aggregate.totalContributionsEur:null));
}
