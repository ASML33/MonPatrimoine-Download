type Binding = { version: 1; effectiveOn: string; sourceSha256: string; quantityAtRepair: string; totalUsd: string; totalEurEstimate: string; unitCostUsd: string; method: "dated_official_reference_fx_estimate" };
const decimal=(v:unknown):v is string=>typeof v==='string'&&/^\d+(?:\.\d+)?$/.test(v)&&Number.isFinite(Number(v));
/** Broker native USD totals remain exact strings in the native metadata. The
 * EUR basis is explicitly an estimate, independent of valuation FX or the
 * separate PRU display pin. A new PRU never inherits this old basis. */
export function ctoBrokerBasis(metadata: unknown, nativeCost: string|number|null, currency: string, day: string) {
  const basis=(metadata as {cto_broker_basis?:Binding}|null)?.cto_broker_basis;
  if(!basis||basis.version!==1||basis.method!=='dated_official_reference_fx_estimate'||currency!=='USD'||nativeCost===null||!/^\d{4}-\d{2}-\d{2}$/.test(basis.effectiveOn)||day<basis.effectiveOn||!/^[a-f0-9]{64}$/.test(basis.sourceSha256)||![basis.quantityAtRepair,basis.totalUsd,basis.totalEurEstimate,basis.unitCostUsd].every(decimal)||!(Number(basis.quantityAtRepair)>0)||Number(nativeCost)!==Number(basis.unitCostUsd))return null;
  return {unitEurEstimate:Number(basis.totalEurEstimate)/Number(basis.quantityAtRepair),unitUsd:Number(basis.totalUsd)/Number(basis.quantityAtRepair),sourceSha256:basis.sourceSha256,method:basis.method,effectiveOn:basis.effectiveOn,totalUsd:basis.totalUsd,totalEurEstimate:basis.totalEurEstimate};
}
export function retainedCtoBrokerCost(metadata:unknown,nativeCost:string|number|null,currency:string,day:string,submitted:string){
 const value=ctoBrokerBasis(metadata,nativeCost,currency,day);if(!value)return null;
 const exact=(metadata as {cto_broker_basis:Binding}).cto_broker_basis.unitCostUsd;
 const canonical=(s:string)=>s.replace(/(\.\d*?)0+$/,'$1').replace(/\.$/,'');
 return canonical(submitted)===canonical(exact)||submitted===String(Number(exact))?exact:null;
}
export function markCtoBrokerNativeEstimates<T extends {date:string;historicalUnitCosts?:Record<string,number|null>;values:Record<string,number|null>;netKinds:Record<string,"calculated"|"approximate"|"legacy_estimate"|"unavailable">}>(points:T[],positions:{contract_id:string;asset_id:string;metadata?:unknown}[]):T[]{
 return points.map(point=>{const netKinds={...point.netKinds};let changed=false;for(const p of positions){const native=(p.metadata as {cto_broker_basis?:Binding}|null)?.cto_broker_basis;const basis=native?ctoBrokerBasis(p.metadata,native.unitCostUsd,'USD',point.date):null;const cost=point.historicalUnitCosts?.[`asset:${p.contract_id}:${p.asset_id}`];if(basis&&typeof cost==='number'&&Math.abs(cost-basis.unitEurEstimate)<1e-8&&typeof point.values[`contract:${p.contract_id}:net`]==='number'){netKinds[p.contract_id]='approximate';changed=true;}}return changed?{...point,netKinds}:point;});
}

