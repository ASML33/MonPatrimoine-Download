export type ContractActionState = { status: "idle" | "success" | "error"; message?: string; createdContractId?: string };
export type ContractEnvelopeType = { id: string; code: string; label: string; is_active: boolean;default_fiscal_regime_id?:string|null;default_fiscal_rule_id?:string|null };
export type ContractCurrency = { code: string };
export type ContractFiscalRegime = { id: string; envelope_type_id: string; allowedEnvelopeTypeIds?:string[];versions?:import('../fiscal/fiscal-core').FiscalRule[]; label: string; status: string; is_active: boolean; effectiveRule?: import("../fiscal/fiscal-core").FiscalRule | null };
export type ManagedContract = {
  fiscal_assignments?:unknown;
  id: string;
  envelope_type_id: string;
  envelopeTypeCode: string;
  envelopeTypeLabel: string;
  currency_code: string;
  name: string;
  display_name: string | null;
  institution_name: string | null;
  opened_on: string | null;
  closed_on: string | null;
  is_active: boolean;
  show_on_dashboard: boolean;
  dashboard_tile_name: string | null;
  color: string | null;
  fiscal_regime_id: string | null;
  fiscal_started_on: string | null;
  fiscal_history_complete: boolean;
  social_contributions_paid_eur: number | null;
  pea_pme_standard_confirmed?: boolean;
  hasDependencies: boolean;
  canDeleteEmptyAutomaticFund?: boolean;
};

function validDate(value: string) {
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && value >= "0001-01-01"
    && !Number.isNaN(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;
}

export function validateContractFiscalFields(form: FormData) {
  const fiscal_regime_id = String(form.get("fiscal_regime_id") ?? "").trim() || null;
  const fiscal_started_on = String(form.get("fiscal_started_on") ?? "").trim() || null;
  const fiscal_history_complete = form.get("fiscal_history_complete") === "on";
  const rawPaid = String(form.get("social_contributions_paid_eur") ?? "").trim();
  const social_contributions_paid_eur = rawPaid ? Number(rawPaid) : null;
  if (fiscal_regime_id && !/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(fiscal_regime_id)) throw new Error("Choisissez un régime fiscal valide.");
  if (fiscal_started_on && !validDate(fiscal_started_on)) throw new Error("La date fiscale est invalide.");
  if (social_contributions_paid_eur !== null && (!Number.isFinite(social_contributions_paid_eur) || social_contributions_paid_eur < 0)) throw new Error("Le montant de prélèvements sociaux est invalide.");
  return { fiscal_regime_id, fiscal_started_on, fiscal_history_complete, social_contributions_paid_eur };
}

// Explicit whitelist: parent, owner, metadata and identity can never enter an
// UPDATE through form values. Creation handles the parent separately on server.
export function validateContractFields(form: FormData) {
  const value = (key: string) => String(form.get(key) ?? "").trim();
  const name = value("name");
  const display_name = value("display_name") || null;
  const institution_name = value("institution_name") || null;
  const currency_code = value("currency_code").toUpperCase();
  const opened_on = value("opened_on");
  const closed_on = value("closed_on") || null;
  const dashboard_tile_name = value("dashboard_tile_name") || null;
  const rawColor = value("color");
  const color = rawColor ? rawColor.toUpperCase() : null;
  if (!name || [...name].length > 120) throw new Error("Le nom du contrat est obligatoire (120 caractères maximum).");
  if (display_name && [...display_name].length > 120) throw new Error("Le nom d’affichage est limité à 120 caractères.");
  if (dashboard_tile_name && [...dashboard_tile_name].length > 120) throw new Error("Le nom de la tuile est limité à 120 caractères.");
  if (color && !/^#[0-9A-F]{6}$/.test(color)) throw new Error("La couleur doit utiliser le format #RRGGBB.");
  if (!/^[A-Z]{3}$/.test(currency_code)) throw new Error("Choisissez une devise valide.");
  if ((opened_on && !validDate(opened_on)) || (closed_on && !validDate(closed_on))) throw new Error("Date invalide.");
  if (opened_on && closed_on && closed_on < opened_on) throw new Error("La clôture doit suivre ou égaler l’ouverture.");
  return { name, display_name, institution_name, currency_code, opened_on: opened_on || null, closed_on, dashboard_tile_name, color };
}

export function contractError(code?: string) {
  if (code === "23503") return "Ce contrat possède des données liées. Vous pouvez le désactiver, mais pas le supprimer.";
  if (code === "23505") return "Ce nom de contrat est déjà utilisé.";
  if (code === "23514") return "Modification refusée : vérifiez les dates, le type et la devise du contrat.";
  if (code === "40001" || code === "40P01") return "Une modification simultanée a eu lieu. Rechargez la page puis réessayez.";
  if (code === "42501" || code === "PGRST116") return "Ce contrat, ce type d’enveloppe ou cette devise n’est pas accessible.";
  return "Enregistrement impossible. Rechargez la page puis réessayez.";
}
