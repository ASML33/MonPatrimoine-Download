import { isUuid } from "@/lib/assets/asset-core";

export type PositionActionState = { status: "idle" | "success" | "error"; message?: string };

export type PositionUnrealizedValue = {
  acquisitionCostEur: number | null;
  unrealizedGainEur: number | null;
  unrealizedGainPercentage: number | null;
};

export type ContractUnrealizedValue = {
  acquisitionCostEur: number;
  unrealizedGainEur: number;
  unrealizedGainPercentage: number | null;
  valuedPositions: number;
  incompletePositions: number;
};

type SelectedPrice = {
  price: number | string;
  currency_code: string;
  observed_at: string;
  obtained_at?: string | null;
  source_name?: string | null;
  origin: "automatic" | "manual";
};

type SelectedSnapshot = {
  unit_price: number | string | null;
  market_value: number | string;
  currency_code: string;
  valued_at: string;
};

export function resolveContractPositionValuation({
  quantity,
  amountTracked = false,
  price,
  snapshot,
}: {
  quantity: number;
  amountTracked?: boolean;
  price?: SelectedPrice;
  snapshot?: SelectedSnapshot;
}) {
  if(!amountTracked&&quantity===0)return {marketValue:0,unitPrice:null,currencyCode:"EUR",valuedAt:null,retrievedAt:null,source:"Détention terminée"};
  if (price && !amountTracked) {
    const unitPrice = Number(price.price);
    return {
      marketValue: quantity * unitPrice,
      unitPrice,
      currencyCode: price.currency_code,
      valuedAt: price.observed_at,
      retrievedAt: price.origin === "automatic" ? price.obtained_at ?? null : null,
      source: price.source_name ?? null,
    };
  }
  if (snapshot) {
    const unitPrice = amountTracked || snapshot.unit_price === null ? null : Number(snapshot.unit_price);
    return {
      marketValue: Number(snapshot.market_value),
      unitPrice,
      currencyCode: snapshot.currency_code,
      valuedAt: snapshot.valued_at,
      retrievedAt: null,
      source: "Estimation manuelle",
    };
  }
  return { marketValue: null, unitPrice: null, currencyCode: null, valuedAt: null, retrievedAt: null, source: null };
}

export function isRetainedPriceAfterRefreshFailure(
  refresh: { status: string; last_attempted_at: string | null } | undefined,
  retrievedAt: string | null,
) {
  if (refresh?.status !== "error" || !refresh.last_attempted_at) return false;
  const failureAt = Date.parse(refresh.last_attempted_at);
  const retrievedTime = retrievedAt === null ? -Infinity : Date.parse(retrievedAt);
  return Number.isFinite(failureAt) && failureAt >= retrievedTime;
}

export function resolveContractTotalValue({
  securitiesValueEur,
  cashEur,
  inputCount,
  knownValueCount,
  requireObservation = false,
}: {
  securitiesValueEur: number;
  cashEur: number;
  inputCount: number;
  knownValueCount: number;
  requireObservation?: boolean;
}) {
  return (inputCount > 0 || requireObservation) && knownValueCount === 0 ? null : securitiesValueEur + cashEur;
}

export function calculateEstimationVariation(current: number | null, initial: number | null) {
  if (current === null || initial === null || !Number.isFinite(current) || !Number.isFinite(initial) || initial <= 0) {
    return { amount: null, percentage: null };
  }
  const amount = current - initial;
  return { amount, percentage: (amount / initial) * 100 };
}

const DECIMAL_PATTERN = /^\d{1,16}(?:[.,]\d{1,8})?$/;

function decimal(form: FormData, name: string, required: boolean) {
  const raw = String(form.get(name) ?? "").trim();
  if (!raw && !required) return null;
  if (!DECIMAL_PATTERN.test(raw)) throw new Error(required ? "La quantité doit être strictement positive." : "Le PRU doit être positif et comporter au maximum huit décimales.");
  const value = raw.replace(",", ".");
  if (required && !/[1-9]/.test(value)) throw new Error("La quantité doit être strictement positive.");
  return value;
}

export function validatePositionForm(form: FormData, creating: boolean) {
  const assetId = String(form.get("asset_id") ?? "");
  if (creating && !isUuid(assetId)) throw new Error("Choisissez un actif existant.");
  return {
    assetId: creating ? assetId : null,
    quantity: decimal(form, "quantity", true)!,
    averageCostPerUnit: decimal(form, "average_cost_per_unit", false),
  };
}

export function calculatePositionUnrealizedValue({
  acquisitionCostEur,
  marketValueEur,
}: {
  acquisitionCostEur: number | null;
  marketValueEur: number | null;
}): PositionUnrealizedValue {
  if (
    acquisitionCostEur === null
    || marketValueEur === null
    || !Number.isFinite(acquisitionCostEur)
    || !Number.isFinite(marketValueEur)
    || acquisitionCostEur < 0
  ) {
    return { acquisitionCostEur: null, unrealizedGainEur: null, unrealizedGainPercentage: null };
  }
  const unrealizedGainEur = marketValueEur - acquisitionCostEur;
  return {
    acquisitionCostEur,
    unrealizedGainEur,
    unrealizedGainPercentage: acquisitionCostEur===0?null:(unrealizedGainEur / acquisitionCostEur) * 100,
  };
}

export function calculateContractUnrealizedValue(positions: PositionUnrealizedValue[]): ContractUnrealizedValue {
  let acquisitionCostEur = 0;
  let unrealizedGainEur = 0;
  let valuedPositions = 0;
  let incompletePositions = 0;
  for (const position of positions) {
    if (position.acquisitionCostEur === null || position.unrealizedGainEur === null) {
      incompletePositions += 1;
      continue;
    }
    acquisitionCostEur += position.acquisitionCostEur;
    unrealizedGainEur += position.unrealizedGainEur;
    valuedPositions += 1;
  }
  return {
    acquisitionCostEur,
    unrealizedGainEur,
    unrealizedGainPercentage: acquisitionCostEur > 0 ? (unrealizedGainEur / acquisitionCostEur) * 100 : null,
    valuedPositions,
    incompletePositions,
  };
}

export function getLatestSuccessfulPriceRetrievalTimestamp(
  positions: Array<{ currentPriceRetrievedAt: string | null }>,
) {
  return positions.reduce<string | null>((latest, position) => {
    if (!position.currentPriceRetrievedAt || !Number.isFinite(Date.parse(position.currentPriceRetrievedAt))) return latest;
    if (latest === null || Date.parse(position.currentPriceRetrievedAt) > Date.parse(latest)) return position.currentPriceRetrievedAt;
    return latest;
  }, null);
}

export function formatContractPriceRetrievalTimestamp(value: string | null) {
  if (!value || !Number.isFinite(Date.parse(value))) return "Non disponible";
  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
    timeZone: "Europe/Paris",
  }).format(new Date(value));
}

export function positionError(code?: string) {
  if (code === "23505") return "Cet actif possède déjà une position dans ce contrat.";
  if (code === "23503") return "Cette position possède un historique lié et ne peut pas être supprimée.";
  if (code === "23514") return "Modification refusée : vérifiez la quantité et l’activité du contrat et de l’actif.";
  if (code === "42501" || code === "PGRST116") return "Cette position, ce contrat ou cet actif n’est pas accessible.";
  if (code === "40001" || code === "40P01") return "Une modification simultanée a eu lieu. Réessayez.";
  return "Enregistrement impossible. Rechargez la page puis réessayez.";
}
