export type AcquisitionMode = "total" | "unit";

// Submitted costs are derived with decimal strings and BigInt. The existing
// financial readers retain their numeric representation; no submitted PRU is
// derived through floating-point arithmetic.
export function acquisitionDecimal(value: string, digits = 40): string | null {
  const text = value.trim().replace(",", ".");
  if (!new RegExp(`^\\d{1,32}(?:\\.\\d{1,${digits}})?$`).test(text)) return null;
  const [whole, fraction = ""] = text.split(".");
  const tail = fraction.replace(/0+$/, "");
  return whole.replace(/^0+(?=\d)/, "") + (tail ? `.${tail}` : "");
}
const parts = (value: string) => {
  const [whole, fraction = ""] = value.split(".");
  return { integer: BigInt(whole + fraction), scale: fraction.length };
};
const power = (scale: number) => BigInt(10) ** BigInt(scale);
function decimalString(integer: bigint, scale: number) {
  const digits = integer.toString().padStart(scale + 1, "0");
  return acquisitionDecimal(scale ? `${digits.slice(0, -scale)}.${digits.slice(-scale)}` : digits, Math.max(20, scale));
}
export function multiplyAcquisition(left: string, right: string): string | null {
  const a = acquisitionDecimal(left), b = acquisitionDecimal(right);
  if (a === null || b === null) return null;
  const x = parts(a), y = parts(b);
  return decimalString(x.integer * y.integer, x.scale + y.scale);
}
export function divideAcquisition(amount: string, quantity: string) {
  const a = acquisitionDecimal(amount), b = acquisitionDecimal(quantity, 8);
  if (a === null || b === null || b === "0") return null;
  const x = parts(a), y = parts(b);
  const numerator = x.integer * power(y.scale + 20), denominator = y.integer * power(x.scale);
  const quotient = numerator / denominator, remainder = numerator % denominator;
  return { value: decimalString(quotient + (remainder * BigInt(2) >= denominator ? BigInt(1) : BigInt(0)), 20), exact: remainder === BigInt(0) };
}

type NativeInput = { version: number; effectiveOn: string; unitCost: string | null; currency: string; recordedAt: string; quantity?:string; nativeTotal?:string|null; totalEur?:string|null; unitEur?:string|null; fx?:{method?:string;direction?:string;rate?:{currency_code?:string;requested_on?:string;observed_on?:string;obtained_at?:string;eur_per_unit?:string|number;source?:string}} };
export function acquisitionProof(metadata: unknown, native: string | number | null, currency: string, day: string) {
 const rows=(metadata as {cto_acquisition_inputs?:NativeInput[]}|null)?.cto_acquisition_inputs;
 if(!Array.isArray(rows))return undefined;
 return [...rows].filter(e=>[1,2].includes(e?.version)&&/^\d{4}-\d{2}-\d{2}$/.test(e.effectiveOn)&&e.effectiveOn<=day&&Number.isFinite(Date.parse(e.recordedAt))&&e.currency===currency&&(native===null?e.unitCost===null:typeof e.unitCost==='string'&&acquisitionDecimal(String(native))===acquisitionDecimal(e.unitCost))).sort((a,b)=>Date.parse(b.recordedAt)-Date.parse(a.recordedAt))[0];
}
export function pinnedAcquisition(metadata:unknown,native:string|number|null,currency:string,day:string){return acquisitionProof(metadata,native,currency,day)?.version===2;}
export function acquisitionUnitEur(metadata: unknown, native: string | number | null, currency: string, day: string): number | null | undefined {
 const proof=acquisitionProof(metadata,native,currency,day);
 if(!proof)return undefined;
 if(native===null)return null;
 if(currency==='EUR'||Number(native)===0)return Number(native);
 if(proof.version===1)return null;
 const fx=proof.fx,r=fx?.rate;
 if(!fx||!['historical','last_known'].includes(fx.method??'')||fx.direction!=='EUR_per_native_unit'||!r||r.currency_code?.trim()!==currency||!r.observed_on||!r.requested_on||!r.obtained_at||!['ecb','frankfurter','manual'].includes(r.source??'')||!Number.isFinite(Date.parse(r.obtained_at))||Date.parse(r.obtained_at)>Date.parse(proof.recordedAt)||r.observed_on>r.requested_on||r.observed_on>r.obtained_at.slice(0,10)||fx.method==='historical'&&r.observed_on>proof.effectiveOn||!(Number(r.eur_per_unit)>0)||typeof proof.unitEur!=='string'||acquisitionDecimal(proof.unitEur,40)===null)return null;
 return Number(proof.unitEur);
}
export function acquisitionTotalEur(metadata:unknown,native:string|number|null,currency:string,day:string,quantity:string|number):number|null|undefined{
 const unit=acquisitionUnitEur(metadata,native,currency,day);if(unit===undefined)return undefined;if(Number(quantity)===0)return 0;if(unit===null)return null;
 const proof=acquisitionProof(metadata,native,currency,day);
 return proof?.version===2&&typeof proof.totalEur==='string'&&acquisitionDecimal(String(quantity),8)===acquisitionDecimal(proof.quantity??'',8)&&acquisitionDecimal(proof.totalEur,40)!==null?Number(proof.totalEur):Number(quantity)*unit;
}
export function acquisitionStatus(metadata:unknown,native:string|number|null,currency:string,day:string){
 const p=acquisitionProof(metadata,native,currency,day);if(p?.version!==2)return undefined;
 const method=p.fx?.method;
 return {effectiveOn:p.effectiveOn,nativeTotal:p.nativeTotal,quantity:p.quantity,label:method==='historical'?'Conversion historique utilisée':method==='last_known'?'Taux de secours utilisé':method==='unavailable'?'Conversion EUR indisponible':undefined,estimated:['historical','last_known'].includes(method??'')};
}

/** Indicative cost FX changes quality, never the tax formula or market FX. */
export function markAcquisitionEstimates<T extends {date:string;historicalUnitCosts?:Record<string,number|null>;values:Record<string,number|null>;netKinds:Record<string,'calculated'|'approximate'|'legacy_estimate'|'unavailable'>}>(points:T[],positions:{contract_id:string;asset_id:string;metadata?:unknown}[]):T[]{
 return points.map(point=>{let changed=false;const netKinds={...point.netKinds};for(const p of positions){const rows=(p.metadata as {cto_acquisition_inputs?:NativeInput[]}|null)?.cto_acquisition_inputs;if(!Array.isArray(rows))continue;const proof=[...rows].filter(r=>r.version===2&&r.effectiveOn<=point.date).sort((a,b)=>Date.parse(b.recordedAt)-Date.parse(a.recordedAt))[0];if(!proof||!['historical','last_known'].includes(proof.fx?.method??''))continue;const unit=acquisitionUnitEur(p.metadata,proof.unitCost,proof.currency,point.date),cost=point.historicalUnitCosts?.['asset:'+p.contract_id+':'+p.asset_id];if(typeof unit==='number'&&typeof cost==='number'&&Math.abs(cost-unit)<1e-8&&typeof point.values['contract:'+p.contract_id+':net']==='number'){netKinds[p.contract_id]='approximate';changed=true;}}return changed?{...point,netKinds}:point;});
}
