import { parisDate } from "@/lib/patrimony/current-valuation-core";
import { convertToEur, latestFxRatesByCurrency, type FxRateRecord } from "@/lib/fx/fx-core";
import type { ChartContract, ChartPoint } from "@/lib/patrimony/chart-core";

export type PropertyObservation = { id:string; version:number; effectiveOn:string; kind:"valuation"|"end"; amount:string|null; currency:string; recordedAt:string; provenance:string; origin:"recovery"|"manual"; snapshotId?:string; originalAt?:string };
export type PropertyHistory = {version:1;entries:PropertyObservation[];archived:{entries:PropertyObservation[];replacedAt:string;correctionId:string}[];receipts?:{token:string;request:unknown}[]};
export type PropertyMember = {sourceContractId:string;positionId:string;assetId:string};
export function propertyHistory(metadata:unknown):PropertyHistory|null {
 const h=(metadata as {property_valuations?:PropertyHistory}|null)?.property_valuations;
 if(!h)return null;
 if(h.version!==1||!Array.isArray(h.entries)||!Array.isArray(h.archived))throw Error("Historique immobilier invalide");
 const days=new Set<string>();
 for(const e of h.entries){if(days.has(e.effectiveOn)||!/^\d{4}-\d{2}-\d{2}$/.test(e.effectiveOn)||!e.id||!Number.isInteger(e.version)||!["end","valuation"].includes(e.kind)||e.kind==="valuation"&&(e.amount===null||!Number.isFinite(Number(e.amount))||Number(e.amount)<0)||e.kind==="end"&&e.amount!==null)throw Error("Observations immobilières ambiguës");days.add(e.effectiveOn);}
 return h;
}
export function propertyObservationAt(entries:PropertyObservation[],date:string){const eligible=entries.filter(e=>e.effectiveOn<=date).sort((a,b)=>b.effectiveOn.localeCompare(a.effectiveOn));const end=eligible.find(e=>e.kind==="end");return end??eligible[0]??null;}
export function propertyMembers(metadata:unknown):PropertyMember[]{return (metadata as {property_consolidation?:{members?:PropertyMember[]}}|null)?.property_consolidation?.members??[];}
export function propertyReplacedBy(metadata:unknown):string|null{return (metadata as {property_replaced_by?:string}|null)?.property_replaced_by??null;}
export function propertyValue(metadata:unknown,at:string,rates:FxRateRecord[]){
 const date=/^\d{4}-\d{2}-\d{2}$/.test(at)?at:parisDate(at),history=propertyHistory(metadata),observation=history?propertyObservationAt(history.entries,date):null;
 if(!observation)return {observation:null,amountEur:null,ended:false};
 if(observation.kind==="end")return {observation,amountEur:0,ended:true};
 return {observation,amountEur:convertToEur(observation.amount!,observation.currency,latestFxRatesByCurrency(rates,date).get(observation.currency)).amountEur,ended:false};
}

// Original authorities are selected first. This presentation mapping never
// rewrites captures or promotes a legacy contract total into a unit price.
export function projectPropertyHistory(points:ChartPoint[],contracts:ChartContract[],members:{contractId:string;members:PropertyMember[]}[],positions:{id:string;contract_id:string;asset_id:string;metadata?:unknown}[],rates:FxRateRecord[]){
 return points.map(original=>{
  const point:ChartPoint={...original,values:{...original.values},quantities:{...original.quantities},historicalUnitCosts:{...original.historicalUnitCosts},netKinds:{...original.netKinds},provenanceByContract:{...original.provenanceByContract},propertyEvidence:{...original.propertyEvidence}};
  const destinations=new Set([...members.filter(m=>m.members.length>0).map(m=>m.contractId),...positions.filter(p=>propertyHistory(p.metadata)).map(p=>p.contract_id)]);
  for(const cid of destinations){
   const contract=contracts.find(c=>c.id===cid);if(!contract||contract.envelopeTypeCode!=="immobilier")continue;
   const mapping=members.find(m=>m.contractId===cid)?.members??[];
   const relevant=positions.filter(p=>p.contract_id===cid&&propertyHistory(p.metadata));
   const values:(number|null)[]=[];let any=false;
   for(const p of relevant){
    const member=mapping.find(m=>m.positionId===p.id),key=`asset:${cid}:${p.asset_id}`;
    const sourceKey=member?`contract:${member.sourceContractId}:gross`:null;
    const captured=sourceKey?point.values[sourceKey]:point.values[key];
    let value=typeof captured==="number"?captured:null;
    const h=propertyHistory(p.metadata)!,e=propertyObservationAt(h.entries,point.date);
    if(!member&&!e&&typeof captured!=="number"){point.values[key]=null;point.quantities[key]=null;continue;}
    if(e?.origin==="manual")value=propertyValue(p.metadata,point.date,rates).amountEur;
    // A future native capture already contains the new contract identity.
    if(e?.origin!=="manual"&&value===null&&typeof point.values[key]==="number"&&(!member||point.values[sourceKey!]===undefined))value=point.values[key];
    point.values[key]=value;point.quantities[key]=null;point.historicalUnitCosts![key]=null;
    values.push(value);any ||= value!==null||!!e&&e.origin==="manual";
    point.propertyEvidence![key]={sourceContractId:member?.sourceContractId??cid,positionId:p.id,observation:e,contractSource:!!sourceKey&&typeof captured==="number"};
   }
   if(!values.length||!any&&point.values[`contract:${cid}:gross`]===undefined)continue;
   const complete=values.length>0&&values.every(v=>v!==null),sum=values.reduce<number>((s,v)=>s+(v??0),0);
   point.values[`contract:${cid}:gross`]=complete?sum:null;point.values[`contract:${cid}:net`]=complete?sum:null;
   point.netKinds[cid]=complete?"calculated":"unavailable";
   point.provenanceByContract![cid]="Regroupement immobilier traçable · valeurs totales datées · convention BRUT = NET";
  }
  return point;
 });
}
