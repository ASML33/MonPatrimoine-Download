import { CONTRACT_COLUMNS } from "@/lib/contracts/contract-columns";
import { visibleContracts } from "@/lib/contracts/contract-scope";
import "server-only";
import { createClient } from "@/lib/supabase/server";
import {getFiscalCatalog} from "@/lib/fiscal/fiscal-catalog";

import type { ContractCurrency, ContractEnvelopeType, ContractFiscalRegime, ManagedContract } from "./contract-core";

export async function getManagedContracts(userId: string) {
  const supabase = await createClient();
  const [contracts, envelopeTypes, currencies, fiscalSettings] = await Promise.all([
    supabase.from("contracts").select(`${CONTRACT_COLUMNS},envelope_types(code,label)`)
      .eq("user_id", userId).order("created_at", { ascending: false }),
    supabase.from("envelope_types").select("id,code,label,is_active,default_fiscal_regime_id,default_fiscal_rule_id").order("label"),
    supabase.from("currencies").select("code").eq("is_active", true).order("code"),
    getFiscalCatalog(),
  ]);
  if (contracts.error || envelopeTypes.error || currencies.error) throw new Error("Contracts unavailable");
  contracts.data = visibleContracts(contracts.data);
  const options = (envelopeTypes.data ?? []) as ContractEnvelopeType[];
  const dependencies = contracts.data.length
    ? await supabase.rpc("get_contract_dependencies", { requested_contracts: contracts.data.map((row) => row.id) })
    : { data: [], error: null };
  if (dependencies.error) throw new Error("Contract dependencies unavailable");
  const dependenciesById = new Map((dependencies.data ?? []).map((row: { contract_id: string; has_dependencies: boolean }) => [row.contract_id, row.has_dependencies]));
  const emptyAutomaticDeletion = new Set((dependencies.data ?? []).filter((row: { can_delete_empty_automatic_fund?: boolean }) => row.can_delete_empty_automatic_fund === true).map((row: { contract_id: string }) => row.contract_id));
  // Include empty and inactive contracts. Dependency checks use invoker RLS.
  const rows: ManagedContract[] = contracts.data.map((row) => {
    if (!dependenciesById.has(row.id)) throw new Error("Contract dependencies unavailable");
    const { envelope_types, metadata, ...contract } = row;
    const relation = envelope_types as { code: string; label: string } | { code: string; label: string }[] | null;
    const envelopeType = Array.isArray(relation) ? relation[0] : relation;
    if (!envelopeType) throw new Error("Contract envelope type unavailable");
    return {
      ...contract,
      envelopeTypeCode: envelopeType.code,
      envelopeTypeLabel: envelopeType.label,
      hasDependencies: Boolean(metadata?.geographic_location) || dependenciesById.get(row.id) === true,
      canDeleteEmptyAutomaticFund: emptyAutomaticDeletion.has(row.id),
    };
  });
  const regimes:ContractFiscalRegime[]=fiscalSettings.regimes.map(r=>({id:r.id,envelope_type_id:r.envelope_type_id,label:r.label,status:r.status,is_active:r.is_active,allowedEnvelopeTypeIds:fiscalSettings.allowed.filter(a=>a.fiscal_regime_id===r.id&&a.is_active).map(a=>a.envelope_type_id),versions:fiscalSettings.rules.filter(f=>f.fiscalRegimeId===r.id&&f.status==='verified')}));
  return { contracts: rows, envelopeTypes: options, currencies: (currencies.data ?? []) as ContractCurrency[], fiscalRegimes: regimes };
}
