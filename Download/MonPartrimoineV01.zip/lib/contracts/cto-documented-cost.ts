import { acquisitionProof, acquisitionTotalEur, acquisitionUnitEur } from "./cto-acquisition-input";
import { ctoBrokerBasis } from "./cto-broker-basis";

export type DocumentedCost = {
  version: 1;
  nativeUnitCost: string;
  currency: string;
  fiscalUnitCostEur: string;
  fiscalSource: string;
  fiscalEffectiveOn: string;
  fiscalObservationId: string;
  displayStatus?: string;
  displayFx?: { eurPerUnit: string; observedOn: string; requestedOn: string; obtainedAt: string; pinnedAt: string } | null;
};

type CostInput = {
  metadata: unknown;
  observation?: { effectiveOn: string; id?: string; costEvidence?: DocumentedCost } | null;
  native: string | number | null;
  currency: string;
  day: string;
  quantity: number;
  legacyUnit: number | null;
  brokerUnit?: number | null;
};

function decimal(value: unknown) {
  if (typeof value !== "string" || !/^\d+(?:\.\d+)?$/.test(value)) return null;
  const [integer, fraction = ""] = value.split(".");
  return integer.replace(/^0+(?=\d)/, "") + "." + fraction.replace(/0+$/, "");
}

export function resolveCtoCost({ metadata, observation, native, currency, day, quantity, legacyUnit, brokerUnit }: CostInput) {
  const nativeKey = decimal(String(native));
  function validDocument(proof: DocumentedCost | undefined) {
    return proof?.version === 1 && nativeKey !== null && decimal(proof.nativeUnitCost) === nativeKey &&
      proof.currency === currency && typeof proof.fiscalSource === "string" && proof.fiscalSource.trim() &&
      /^\d{4}-\d{2}-\d{2}$/.test(proof.fiscalEffectiveOn) && proof.fiscalEffectiveOn <= day &&
      typeof proof.fiscalObservationId === "string" && proof.fiscalObservationId.length > 0 &&
      decimal(proof.fiscalUnitCostEur) !== null && Number.isFinite(Number(proof.fiscalUnitCostEur));
  }
  let proof = observation?.costEvidence;
  if (observation?.id && !validDocument(proof)) {
    const entries = (metadata as { position_observations?: { entries?: {
      effectiveOn: string; unitCost: string | null; currency: string; costEvidence?: DocumentedCost;
    }[] } } | null)?.position_observations?.entries;
    const acquisitionDay = acquisitionProof(metadata, native, currency, day)?.effectiveOn;
    if (Array.isArray(entries)) {
      const earlier = entries.filter(entry => entry.effectiveOn < observation.effectiveOn)
        .sort((a, b) => b.effectiveOn.localeCompare(a.effectiveOn));
      for (const entry of earlier) {
        if (decimal(entry.unitCost) !== nativeKey || entry.currency !== currency ||
            acquisitionDay && entry.effectiveOn < acquisitionDay) break;
        if (validDocument(entry.costEvidence)) {
          proof = entry.costEvidence;
          break;
        }
      }
    }
  }
  const documented = proof && validDocument(proof) ? Number(proof.fiscalUnitCostEur) : null;
  const acquired = acquisitionUnitEur(metadata, native, currency, day);
  const broker = brokerUnit === undefined ? ctoBrokerBasis(metadata, native, currency, day)?.unitEurEstimate ?? null : brokerUnit;
  const conflict = documented === null && acquired != null && broker !== null &&
    Math.abs(acquired - broker) > Number.EPSILON * 8 * Math.max(1, Math.abs(acquired), Math.abs(broker));
  const unit = conflict ? null : documented ?? acquired ?? broker ?? (acquired === undefined ? legacyUnit : null);
  const total = quantity === 0 ? 0 : unit === null ? null :
    documented === null && acquired != null ? acquisitionTotalEur(metadata, native, currency, day, quantity) ?? null : unit * quantity;
  const pin = proof?.displayFx;
  const displayPin = proof?.displayStatus === "pinned" && pin && nativeKey !== null &&
    proof.currency === currency && decimal(proof.nativeUnitCost) === nativeKey &&
    decimal(pin.eurPerUnit) !== null && Number(pin.eurPerUnit) > 0 &&
    Number.isFinite(Date.parse(pin.obtainedAt)) && Number.isFinite(Date.parse(pin.pinnedAt)) &&
    Date.parse(pin.obtainedAt) <= Date.parse(pin.pinnedAt) && pin.observedOn <= pin.requestedOn
    ? Number(native) * Number(pin.eurPerUnit) : null;
  return {
    unit,
    total,
    conflict,
    displayUnit: currency === "EUR" && nativeKey !== null ? Number(native) : acquired ?? (displayPin !== null && Number.isFinite(displayPin) ? displayPin : null),
    documented: documented !== null,
    documentedOn: documented !== null ? proof?.fiscalEffectiveOn : undefined,
    estimated: documented === null && !conflict && (acquired != null && currency !== "EUR" || broker !== null),
  };
}
