import "server-only";

// Explicit, verified recovery identity. Reversible exclusion from user journeys;
// persisted records and recovery evidence remain untouched. Never infer by name,
// inactivity, or subtract a share of the unallocated PEG/PER historical group.

export function isContractInUserScope(id: string) {
  const excludedId = process.env.PATRIMONY_EXCLUDED_CONTRACT_ID;
  if (excludedId === "none") return true;
  if (!excludedId || !/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(excludedId)) {
    throw new Error("PATRIMONY_CONTRACT_SCOPE_UNAVAILABLE");
  }
  return id.toLowerCase() !== excludedId.toLowerCase();
}

export function visibleContracts<T extends { id: string; metadata?:unknown }>(rows: readonly T[]): T[] {
  return rows.filter((row) => isContractInUserScope(row.id) && !(row.metadata as {property_replaced_by?:string}|undefined)?.property_replaced_by);
}
