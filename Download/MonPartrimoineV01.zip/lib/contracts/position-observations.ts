import type { DocumentedCost } from "./cto-documented-cost";
import { parisDate } from "@/lib/patrimony/current-valuation-core";
export type PositionObservation = {
    id: string;
    version: number;
    effectiveOn: string;
    quantity: string;
    unitCost: string | null;
    currency: string;
    recordedAt: string;
    provenance: string;
    costEvidence?: DocumentedCost;
};
export type PositionBinding = {
    captureId: string;
    date: string;
    observation: PositionObservation | null;
    restore: boolean;
    correctionId: string;
};
export type PositionHistory = {
    version: 1;
    lastReview?: {
        date: string;
        protected: boolean;
    }[];
    entries: PositionObservation[];
    archived: {
        entries: PositionObservation[];
        undatedPrevious?: {quantity:string;unitCost:string|null;currency:string;isActive:boolean}|null;
        replacedAt: string;
        correctionId: string;
    }[];
    bindings: PositionBinding[];
    receipts?: {
        id: string;
        token: string;
    }[];
};
export type DatedPosition = {
    id: string;
    contract_id: string;
    asset_id: string;
    quantity: number | string;
    average_cost_per_unit: number | string | null;
    cost_currency_code: string;
    metadata?: unknown;
};
export function positionHistory(metadata: unknown): PositionHistory | null {
    if (!metadata || typeof metadata !== "object" || !("position_observations" in metadata))
        return null;
    const h = (metadata as {
        position_observations: PositionHistory;
    }).position_observations;
    if (h.version !== 1 || !Array.isArray(h.entries) || !Array.isArray(h.archived) || !Array.isArray(h.bindings))
        throw Error("Historique de position invalide");
    const days = new Set<string>();
    for (const e of h.entries) {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(e.effectiveOn) || days.has(e.effectiveOn) || !Number.isFinite(Number(e.quantity)) || Number(e.quantity) < 0 || e.unitCost !== null && (!Number.isFinite(Number(e.unitCost)) || Number(e.unitCost) < 0) || !e.id || !Number.isInteger(e.version))
            throw Error("Observations concurrentes ou invalides");
        days.add(e.effectiveOn);
    }
    return h;
}
export function observationAt(entries: PositionObservation[], date: string) { return entries.filter(e => e.effectiveOn <= date).sort((a, b) => b.effectiveOn.localeCompare(a.effectiveOn))[0] ?? null; }
export function selectDatedPosition<T extends DatedPosition>(position: T, at: string): T {
    const h = positionHistory(position.metadata);
    if (!h)
        return position;
    const e = observationAt(h.entries, /^\d{4}-\d{2}-\d{2}$/.test(at) ? at : parisDate(at));
    if (!e)
        throw Error("Situation de détention indisponible à cette date");
    return { ...position, quantity: e.quantity, average_cost_per_unit: e.unitCost, cost_currency_code: e.currency };
}
