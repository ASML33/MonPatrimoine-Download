const frenchOrder = new Intl.Collator("fr-FR", { sensitivity: "base", numeric: true });

export function displayedName(item: { name: string; display_name?: string | null }) {
  return item.display_name?.trim() || item.name;
}

export function compareDisplayNames(left: { id: string; name: string; display_name?: string | null }, right: { id: string; name: string; display_name?: string | null }) {
  return frenchOrder.compare(displayedName(left), displayedName(right)) || left.id.localeCompare(right.id, "en");
}

export function compareTileLabels(left: { key: string; label: string }, right: { key: string; label: string }) {
  return frenchOrder.compare(left.label, right.label) || left.key.localeCompare(right.key, "en");
}
