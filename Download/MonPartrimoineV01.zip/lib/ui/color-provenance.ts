export type ColorOrigin = "user" | "automatic" | "legacy_unknown";

// An untouched editor must not overwrite a concurrent color or claim to know
// the origin of a legacy value merely because it was posted with the form.
export function colorWrite(color: string | null, explicitlyChanged: boolean, creating: boolean) {
  if (!creating && !explicitlyChanged) return {};
  return { color, color_origin: color === null ? "automatic" as const
    : explicitlyChanged ? "user" as const : "legacy_unknown" as const };
}
