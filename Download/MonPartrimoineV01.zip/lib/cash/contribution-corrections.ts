import type { ChartPoint } from "@/lib/patrimony/chart-core";
export type ContributionCorrection = { id:string; date:string; amount:string; flowIds:string[]; order:number };
export type ContributionHistory = { version:1; entries:ContributionCorrection[]; archived:ContributionCorrection[] };
export function contributionHistory(metadata:unknown):ContributionHistory {
 const value=(metadata as {securities_contribution_corrections?:ContributionHistory}|null)?.securities_contribution_corrections;
 if(!value)return {version:1,entries:[],archived:[]};
 if(value.version!==1||!Array.isArray(value.entries)||!Array.isArray(value.archived))throw Error("Historique du cumul invalide.");
 return value;
}
export function contributionCorrectionAt(history:ContributionHistory,date:string) {
 return history.entries.filter(e=>e.date<=date).sort((a,b)=>b.date.localeCompare(a.date)||b.order-a.order)[0];
}
export function correctedContributions(native:number|null,date:string,history:ContributionHistory,flows:readonly {id:string;kind:string;date:string;amountEur:number|null}[]):number|null {
 const correction=contributionCorrectionAt(history,date);
 if(!correction)return native;
 const later=flows.filter(f=>f.kind==="contribution"&&f.date<=date&&!correction.flowIds.includes(f.id));
 if(later.some(f=>f.amountEur===null))return null;
 return Number(correction.amount)+later.reduce((sum,f)=>sum+f.amountEur!,0);
}
/** Display-only overlay, applied AFTER all native valuation/tax projections. */
export function projectContributionCorrections(points:ChartPoint[],contracts:readonly {id:string;envelopeCode:string;metadata:unknown}[],flows:readonly {id:string;contractId:string;kind:string;date:string;amountEur:number|null}[]):ChartPoint[]{
 const scoped=contracts.filter(c=>["pea","pea_pme","cto","compte_titres","assurance_vie"].includes(c.envelopeCode)&&contributionHistory(c.metadata).entries.length);
 if(!scoped.length)return points;
 return points.map(p=>{const displayedContributions={...p.displayedContributions},contributionCorrectionEvidence={...p.contributionCorrectionEvidence};for(const c of scoped){const h=contributionHistory(c.metadata),e=h.entries.filter(e=>e.date<=p.date).sort((a,b)=>b.date.localeCompare(a.date))[0];if(!e)continue;displayedContributions[c.id]=correctedContributions(p.contributions[c.id]??null,p.date,h,flows.filter(f=>f.contractId===c.id));contributionCorrectionEvidence[c.id]={id:e.id,date:e.date,amount:e.amount};}return {...p,displayedContributions,contributionCorrectionEvidence};});
}
