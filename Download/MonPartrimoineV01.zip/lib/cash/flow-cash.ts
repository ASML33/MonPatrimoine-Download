export const linksFlowsToCash = (code: string) => ["pea", "pea_pme", "cto", "compte_titres"].includes(code);
export type CashRevision = { id: string; updatedAt: string };
export function activeCashLink(metadata: unknown, flowId: string): boolean {
  if (!metadata || typeof metadata !== "object") return false;
  const links = (metadata as Record<string, unknown>).flow_cash_links;
  if (!links || typeof links !== "object") return false;
  const link = (links as Record<string, unknown>)[flowId];
  return Boolean(link && typeof link === "object" && (link as Record<string, unknown>).active === true);
}
export function reconciledCashLink(metadata: unknown, flowId: string): boolean {
  if (!activeCashLink(metadata, flowId)) return false;
  const link = ((metadata as Record<string, unknown>).flow_cash_links as Record<string, Record<string, unknown>>)[flowId];
  return link.reconciled === true;
}
export function flowReconciliation(form: FormData) {
  const effect = String(form.get("cash_effect") ?? "automatic");
  if (effect === "automatic") return {};
  if (!["add", "included"].includes(effect) || form.get("confirm_cash_effect") !== "on") throw Error("Confirmez si le mouvement doit modifier les espèces ou s’il est déjà compris dans le solde.");
  const amount = String(form.get("confirmed_cash_amount") ?? "").trim().replace(",", ".");
  if (effect === "included" && (!/^\d+(\.\d{1,8})?$/.test(amount) || !Number.isFinite(Number(amount)) || Number(amount) >= 1e16)) throw Error("Renseignez le solde réel confirmé après ce mouvement, à sa date, dans la même devise.");
  return { cash_effect: effect, cash_effect_confirmed: true, ...(effect === "included" ? { confirmed_cash_amount: amount } : {}) };
}
export function flowCashError(message?: string) {
  if (message?.includes("FLOW-CASH-DUPLICATE")) return "Un flux de même type, montant, devise et date existe déjà. Vérifiez l’historique avant de saisir un autre mouvement ; aucune écriture effectuée.";
  if (message?.includes("FLOW-CASH-RECONCILIATION")) return "Confirmez le rapprochement du mouvement et son solde à la date d’effet. Aucune écriture effectuée.";
  if (message?.includes("FLOW-CASH-UNKNOWN")) return "Solde inconnu dans cette devise. Renseignez d’abord une observation du solde, sans créer de flux artificiel.";
  if (message?.includes("FLOW-CASH-LATER")) return "Une observation ultérieure existe dans cette devise. Ce flux antidaté ne peut pas être rapproché automatiquement ; aucune écriture effectuée.";
  if (message?.includes("FLOW-CASH-DEPENDENCY")) return "Le solde associé a été modifié depuis ce flux. Correction ou suppression refusée pour préserver les observations et mouvements ultérieurs.";
  if (message?.includes("FLOW-CASH-CAPTURE")) return "Une capture publiée couvre déjà cette période. Le mouvement ne peut pas être rapproché automatiquement ; aucune écriture effectuée.";
  if (message?.includes("FLOW-CASH-AMOUNT")) return "Le mouvement produirait un solde négatif ou hors limites. Aucune écriture effectuée.";
  if (message?.includes("FLOW-CASH-ANCHOR")) return "Un cumul historique déclaré couvre cette période sans permettre de rapprocher ce mouvement. Aucune écriture effectuée.";
  return null;
}
