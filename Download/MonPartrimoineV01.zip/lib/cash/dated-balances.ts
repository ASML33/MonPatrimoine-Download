export type DatedBalance = { id?: string; contract_id: string; amount: number | string; currency_code: string; as_of: string; updated_at?: string; metadata?: unknown; observationRevision?: number };


export type BalanceObservation = { amount: string; currencyCode: string; asOf: string; recordedAt: string };
type ObservationHistory = { version: 2; entries: BalanceObservation[]; archived: { entries: BalanceObservation[]; replacedAt: string }[] };
const civilDate = (instant: string) => new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Paris" }).format(new Date(instant));
function history(metadata: unknown): ObservationHistory | null {
  if (!metadata || typeof metadata !== "object" || Array.isArray(metadata)) return null;
  const stored = (metadata as Record<string, unknown>).cash_balance_observations;
  if (stored === undefined) return null;
  if (!stored || typeof stored !== "object" || Array.isArray(stored)) throw new Error("Historique de solde invalide");
  const data = stored as ObservationHistory;
  if (data.version !== 2 || !Array.isArray(data.entries) || !Array.isArray(data.archived)) throw new Error("Version d’historique de solde non prise en charge");
  const days = new Set<string>();
  const journal=(metadata as {securities_cash_actions?:{version:number;entries?:{kind:string;date:string;amount:string}[]}}).securities_cash_actions;
  for (const entry of data.entries) {
    const preciseJournal=entry&&journal?.version===1&&journal.entries?.some(a=>a.kind==='balance'&&a.date<=civilDate(entry.asOf)&&/^\d{1,16}(?:\.\d{1,12})?$/.test(a.amount)&&!/^\d{1,16}(?:\.\d{1,8})?$/.test(a.amount));
    if (!entry || typeof entry.amount !== "string" || !(/^\d{1,16}(?:\.\d{1,8})?$/.test(entry.amount)||preciseJournal&&/^\d{1,16}(?:\.\d{1,12})?$/.test(entry.amount))
      || !/^[A-Z]{3}$/.test(entry.currencyCode) || !Number.isFinite(Date.parse(entry.asOf)) || !Number.isFinite(Date.parse(entry.recordedAt))) throw new Error("Observation de solde invalide");
    const day = civilDate(entry.asOf);
    if (days.has(day)) throw new Error("Observations concurrentes pour le même jour civil");
    days.add(day);
  }
  return data;
}
function observation(row: DatedBalance): BalanceObservation {
  return { amount: String(row.amount), currencyCode: row.currency_code, asOf: row.as_of, recordedAt: row.updated_at ?? row.as_of };
}
export function expandBalanceObservations<T extends DatedBalance>(rows: readonly T[]): T[] {
  return rows.flatMap(row => {
    const stored = history(row.metadata);
    if (!stored) return [row];
    // An explicitly retired initial source has no known absolute balance.
    // NaN is only an in-memory unavailable marker; never a stored money value.
    if (!stored.entries.length && row.metadata && typeof row.metadata === "object"
      && (row.metadata as {securities_cash_actions?:{known?:boolean}}).securities_cash_actions?.known === false) return [{...row,amount:Number.NaN}];
    return stored.entries.map((entry,index) => ({ ...row, amount: entry.amount, currency_code: entry.currencyCode, as_of: entry.asOf, updated_at: entry.recordedAt, observationRevision: index + 1 }));
  });
}
function canonicalAmount(value: number | string) { return String(value).replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "").replace(/^0+(?=\d)/, ""); }
export function prepareBalanceMetadata(existing: DatedBalance, next: { amount: string; currencyCode: string; asOf: string }, recordedAt: string) {
  if (next.currencyCode !== existing.currency_code) throw new Error("La devise du solde est immuable");
  const before = observation(existing);
  const after = { amount: next.amount, currencyCode: next.currencyCode, asOf: next.asOf, recordedAt };
  const stored = history(existing.metadata);
  const entries = stored?.entries ?? [before];
  if (canonicalAmount(before.amount) === canonicalAmount(after.amount) && Date.parse(before.asOf) === Date.parse(after.asOf)) return null;
  // Editing corrects the selected observation, including its former civil day.
  // The destination day is replaced atomically; old versions are proof only.
  const remaining = entries.filter(entry => civilDate(entry.asOf) !== civilDate(before.asOf) && civilDate(entry.asOf) !== civilDate(after.asOf));
  const effective = [...remaining, after].sort((a,b) => Date.parse(a.asOf) - Date.parse(b.asOf));
  const metadata = existing.metadata && typeof existing.metadata === "object" && !Array.isArray(existing.metadata) ? existing.metadata as Record<string, unknown> : {};
  return { ...metadata, cash_balance_observations: { version: 2 as const, entries: effective, archived: [...(stored?.archived ?? []), { entries, replacedAt: recordedAt }] } };
}

// Absolute observations, never transactions. An observation applies from its
// effective instant; a later observation for the same balance supersedes it.
export function selectDatedBalances<T extends DatedBalance>(rows: readonly T[], until: string) {
  const dateOnly = /^\d{4}-\d{2}-\d{2}$/.test(until);
  const byId = new Map<string, T>();
  for (const row of expandBalanceObservations(rows)) {
    if (!Number.isFinite(Date.parse(row.as_of))) continue;
    const retired = row.metadata && typeof row.metadata === "object" ? (row.metadata as { liquid_savings_retired_from?: unknown }).liquid_savings_retired_from : undefined;
    if (retired !== undefined) {
      if (!retired || typeof retired !== "object" || (retired as {version?: unknown}).version !== 1 || typeof (retired as {date?: unknown}).date !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test((retired as {date: string}).date)) throw new Error("Date de remplacement du solde invalide");
      const day = dateOnly ? until : civilDate(until);
      if (day >= (retired as {date: string}).date) continue;
    }
    const effective = dateOnly ? new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Paris" }).format(new Date(row.as_of)) : row.as_of;
    if (dateOnly ? effective > until : Date.parse(effective) > Date.parse(until)) continue;
    const key = `${row.contract_id}:${row.id ?? row.currency_code}`;
    const old = byId.get(key);
    if (!old || Date.parse(row.as_of) > Date.parse(old.as_of)
      || (Date.parse(row.as_of) === Date.parse(old.as_of) && ((row.observationRevision ?? 0) > (old.observationRevision ?? 0) || ((row.observationRevision ?? 0) === (old.observationRevision ?? 0) && Date.parse(row.updated_at ?? "1970-01-01") > Date.parse(old.updated_at ?? "1970-01-01"))))) byId.set(key, row);
  }
  const byCurrency = new Map<string, T>();
  for (const row of byId.values()) {
    const key = `${row.contract_id}:${row.currency_code}`;
    const old = byCurrency.get(key);
    if (old && Date.parse(old.as_of) === Date.parse(row.as_of) && Number(old.amount) !== Number(row.amount)) throw new Error("Soldes datés concurrents non arbitrés.");
    if (!old || Date.parse(row.as_of) > Date.parse(old.as_of)) byCurrency.set(key, row);
  }
  return [...byCurrency.values()];
}

// Only an explicitly recorded total may supersede archived authorities. A
// plain pre-existing EUR observation is not such a correction.
export function liquidSavingsTotalAt(rows: readonly DatedBalance[], contractId: string, day: string): number | null {
  const relevant=rows.filter(row=>row.contract_id===contractId);
  const hasCorrection=relevant.some(row=>{
    const metadata=row.metadata as {cash_balance_corrections?:{kind?:unknown;submitted?:{asOf?:unknown}}[]} | undefined;
    return Array.isArray(metadata?.cash_balance_corrections) && metadata.cash_balance_corrections.some(c=>c?.kind==='liquid_savings_total' && typeof c.submitted?.asOf==='string' && Number.isFinite(Date.parse(c.submitted.asOf)) && civilDate(c.submitted.asOf)<=day);
  });
  if(!hasCorrection)return null;
  const selected=selectDatedBalances(relevant,day);
  if(selected.length!==1 || selected[0].currency_code!=='EUR' || !Number.isFinite(Number(selected[0].amount))) throw new Error('Total d’épargne liquide non arbitrable');
  return Number(selected[0].amount);
}
