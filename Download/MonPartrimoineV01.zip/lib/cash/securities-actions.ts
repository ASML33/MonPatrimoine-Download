import { parisLocalDateTimeToIso, parisDateFromIso } from "@/lib/cash/cash-core";
import { createHash } from "node:crypto";
export type SecuritiesCashAction = { id: string; kind: "flow" | "balance"; date: string; amount: string; delta: string; order: number; revision: string; legacyMode?: string | null };
export function securitiesMoney(value: string, allowZero = true) {
  const normalized = value.trim().replace(",", ".");
  if (!/^\d{1,16}(?:\.\d{1,2})?$/.test(normalized)) throw Error("Saisissez un montant valide à deux décimales maximum.");
  const [whole, fraction=""] = normalized.split(".");
  const cents=BigInt(whole)*BigInt(100)+BigInt(fraction.padEnd(2,"0"));
  if (!allowZero && cents===BigInt(0)) throw Error("Le montant doit être strictement positif.");
  return `${BigInt(whole)}.${fraction.padEnd(2,"0")}`;
}
export function securitiesDay(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw Error("Choisissez une date d’effet valide.");
  const instant = parisLocalDateTimeToIso(value + "T00:00");
  if (value > parisDateFromIso(new Date().toISOString())) throw Error("La date d’effet ne peut pas être future.");
  return { day: value, instant };
}
export function securitiesActions(metadata: unknown): SecuritiesCashAction[] {
  if (!metadata || typeof metadata !== "object") return [];
  const value = (metadata as { securities_cash_actions?: {version:number;entries:SecuritiesCashAction[]} }).securities_cash_actions;
  if (!value) return [];
  if (value.version !== 1 || !Array.isArray(value.entries)) throw Error("Historique des actions espèces invalide.");
  return value.entries;
}
export function legacyBalanceActions(row:{id:string;amount:string|number;currency_code:string;as_of:string;updated_at?:string;metadata?:unknown}, flows:readonly {id:string;kind:string;amount:string|number;occurred_at:string;currency_code:string}[]):SecuritiesCashAction[] {
  const meta=row.metadata as {securities_cash_actions?:unknown;cash_balance_observations?:{entries:{amount:string;asOf:string;recordedAt:string}[]};flow_cash_links?:Record<string,{active?:boolean;cashEffect?:string}>}|undefined;
  if(meta?.securities_cash_actions)return securitiesActions(meta);
  const entries=meta?.cash_balance_observations?.entries??[{amount:String(row.amount),asOf:row.as_of,recordedAt:row.updated_at??row.as_of}];
  const linked=flows.filter(f=>f.currency_code===row.currency_code&&meta?.flow_cash_links?.[f.id]?.active);
  let previous=0;
  return [...entries].sort((a,b)=>a.asOf.localeCompare(b.asOf)).flatMap((entry,index)=>{
    const date=parisDateFromIso(entry.asOf),included=linked.filter(f=>parisDateFromIso(f.occurred_at)<=date).reduce((sum,f)=>sum+(meta?.flow_cash_links?.[f.id]?.cashEffect==='included'?0:(f.kind==='contribution'?1:-1)*Number(f.amount)),0),basis=Number(entry.amount)-included,delta=basis-previous;
    previous=basis;if(index>0&&Math.abs(delta)<1e-8&&linked.some(f=>parisDateFromIso(f.occurred_at)===date))return[];
    const hex=createHash('md5').update(`${row.id}:${date}`).digest('hex'),id=`${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
    return[{id,kind:'balance' as const,date,amount:entry.amount,delta:String(delta),order:index,revision:row.updated_at??entry.recordedAt,legacyMode:'observation'}];
  });
}
export function securitiesError(message = "") {
  if (/SECURITIES-FLOW-IMMUTABLE/.test(message)) return "Un flux enregistré ne peut être ni modifié ni supprimé.";
  if (/SECURITIES-LEGACY-PROOF/.test(message)) return "Les preuves historiques ne permettent pas une transition exacte. Aucune écriture effectuée.";
  if (/SECURITIES-UNKNOWN/.test(message)) return "Le solde à cette date est inconnu. Aucune valeur antérieure ni aucun zéro n’a été déduit.";
  if (/SECURITIES-NEGATIVE/.test(message)) return "L’action rendrait un solde négatif ou hors limites à une date de l’historique. Aucune écriture effectuée.";
  return "L’action n’a pas été enregistrée. Vérifiez les valeurs et rechargez en cas de modification simultanée.";
}
