const frenchCurrencyLocale = "fr-FR-u-nu-latn";
const frenchSpace = "\u00a0";

export function formatMoney(value: number | string | null | undefined, currency: string, currencyDisplay: "symbol" | "code" = "symbol") {
  return formatCurrency(value, currency, undefined, currencyDisplay);
}

function formatCurrency(value: number | string | null | undefined, currency: string, signDisplay?: Intl.NumberFormatOptions["signDisplay"], currencyDisplay: "symbol" | "code" = "symbol") {
  if (value == null || typeof value === "string" && !value.trim()) return "Indisponible";
  const amount = Number(value);
  if (!Number.isFinite(amount)) return "Indisponible";
  const numberOptions: Intl.NumberFormatOptions = {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
    useGrouping: true,
    signDisplay,
  };
  try {
    return new Intl.NumberFormat(frenchCurrencyLocale, {
      ...numberOptions,
      style: "currency",
      currency,
      currencyDisplay,
    }).format(amount).replace(/[\u00a0\u202f]/g, frenchSpace).replace(/^-/u, "\u2212");
  } catch {
    const formatted = new Intl.NumberFormat(frenchCurrencyLocale, numberOptions)
      .format(amount)
      .replace(/[\u00a0\u202f]/g, frenchSpace).replace(/^-/u, "\u2212");
    return `${formatted}${frenchSpace}${currency}`;
  }
}

export function formatSignedMoney(value: number | string | null | undefined, currency: string) {
  return formatCurrency(value, currency, "exceptZero");
}

export function formatPercentage(value: number | string, signed = false) {
  return `${new Intl.NumberFormat(frenchCurrencyLocale, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
    signDisplay: signed ? "exceptZero" : "auto",
  }).format(Number(value)).replace(/[\u00a0\u202f]/g, frenchSpace)}${frenchSpace}%`;
}
