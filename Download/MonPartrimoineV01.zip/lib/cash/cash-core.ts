export type CashActionState = { status: "idle" | "success" | "error"; message?: string };
export type ConvertedCashFlow = { kind: "contribution" | "withdrawal"; amountEur: number | null };
export type NativeCashFlow = { kind: "contribution" | "withdrawal"; amount: number | string; currencyCode: string };
export type NativeCashFlowAggregate = { currencyCode: string; totalContributions: number; netCashFlows: number };
export type NativeCashBalance = { amount: number | string; currencyCode: string };
export type ContractCurrencySummary = { currencyCode: string; cash: number; totalContributions: number; netCashFlows: number };

export function calculateCashFlowAggregates(flows: ConvertedCashFlow[]) {
  let totalContributionsEur = 0;
  let netCashFlowsEur = 0;
  let incompleteContributionFlows = 0;
  let incompleteNetCashFlows = 0;
  for (const flow of flows) {
    if (flow.amountEur === null || !Number.isFinite(flow.amountEur)) {
      incompleteNetCashFlows += 1;
      if (flow.kind === "contribution") incompleteContributionFlows += 1;
      continue;
    }
    if (flow.kind === "contribution") {
      totalContributionsEur += flow.amountEur;
      netCashFlowsEur += flow.amountEur;
    } else {
      netCashFlowsEur -= flow.amountEur;
    }
  }
  return { totalContributionsEur, netCashFlowsEur, incompleteContributionFlows, incompleteNetCashFlows };
}

export function calculateNativeCashFlowAggregates(flows: NativeCashFlow[]): NativeCashFlowAggregate[] {
  const aggregates = new Map<string, NativeCashFlowAggregate>();
  for (const flow of flows) {
    const amount = Number(flow.amount);
    if (!Number.isFinite(amount)) continue;
    const current = aggregates.get(flow.currencyCode) ?? {
      currencyCode: flow.currencyCode,
      totalContributions: 0,
      netCashFlows: 0,
    };
    if (flow.kind === "contribution") {
      current.totalContributions += amount;
      current.netCashFlows += amount;
    } else {
      current.netCashFlows -= amount;
    }
    aggregates.set(flow.currencyCode, current);
  }
  return [...aggregates.values()].sort((left, right) => left.currencyCode.localeCompare(right.currencyCode));
}

export function calculateContractCurrencySummaries(
  baseCurrencyCode: string,
  balances: NativeCashBalance[],
  flows: NativeCashFlow[],
  positionCurrencyCodes: Array<string | null> = [],
): ContractCurrencySummary[] {
  const cashByCurrency = new Map<string, number>();
  for (const balance of balances) {
    const amount = Number(balance.amount);
    if (!Number.isFinite(amount)) continue;
    cashByCurrency.set(balance.currencyCode, (cashByCurrency.get(balance.currencyCode) ?? 0) + amount);
  }
  const flowsByCurrency = new Map(calculateNativeCashFlowAggregates(flows).map((aggregate) => [aggregate.currencyCode, aggregate]));
  const currencyCodes = new Set([
    baseCurrencyCode,
    ...cashByCurrency.keys(),
    ...flowsByCurrency.keys(),
    ...positionCurrencyCodes.filter((currencyCode): currencyCode is string => Boolean(currencyCode)),
  ]);
  return [...currencyCodes].sort().flatMap((currencyCode) => {
    const cash = cashByCurrency.get(currencyCode) ?? 0;
    const flow = flowsByCurrency.get(currencyCode);
    const summary = {
      currencyCode,
      cash,
      totalContributions: flow?.totalContributions ?? 0,
      netCashFlows: flow?.netCashFlows ?? 0,
    };
    const relevant = currencyCode === baseCurrencyCode || summary.cash !== 0 || summary.totalContributions !== 0 || summary.netCashFlows !== 0;
    return relevant ? [summary] : [];
  });
}

const currencyPattern = /^[A-Z]{3}$/;
const localDateTimePattern = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/;

function decimal(value: string, allowZero: boolean) {
  const normalized = value.trim().replace(",", ".");
  if (!/^\d{1,16}(?:\.\d{1,8})?$/.test(normalized)) throw new Error("Saisissez un montant valide avec huit décimales maximum.");
  const number = Number(normalized);
  if (!Number.isFinite(number) || (allowZero ? number < 0 : number <= 0)) {
    throw new Error(allowZero ? "Le montant ne peut pas être négatif." : "Le montant doit être strictement positif.");
  }
  return normalized;
}

function parisParts(value: Date) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Paris", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  }).formatToParts(value);
  return Object.fromEntries(parts.map((part) => [part.type, part.value]));
}

export function parisLocalDateTimeToIso(value: string) {
  const match = localDateTimePattern.exec(value);
  if (!match) throw new Error("La date et l’heure sont invalides.");
  const [, year, month, day, hour, minute] = match;
  const base = Date.UTC(Number(year), Number(month) - 1, Number(day), Number(hour), Number(minute));
  const calendar = new Date(base);
  if (calendar.getUTCFullYear() !== Number(year) || calendar.getUTCMonth() + 1 !== Number(month)
      || calendar.getUTCDate() !== Number(day) || calendar.getUTCHours() !== Number(hour) || calendar.getUTCMinutes() !== Number(minute)) {
    throw new Error("La date et l’heure sont invalides.");
  }
  const candidates: Date[] = [];
  for (let delta = -3; delta <= 3; delta += 1) {
    const candidate = new Date(base + delta * 3_600_000);
    const parts = parisParts(candidate);
    if (parts.year === year && parts.month === month && parts.day === day && parts.hour === hour && parts.minute === minute) candidates.push(candidate);
  }
  if (!candidates.length) throw new Error("Cette heure locale n’existe pas en Europe/Paris.");
  return candidates.sort((left, right) => left.getTime() - right.getTime())[0].toISOString();
}

export function formatParisLocalInput(value: string | Date = new Date()) {
  const parts = parisParts(value instanceof Date ? value : new Date(value));
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}`;
}

export function parisDateFromIso(value: string) {
  const parts = parisParts(new Date(value));
  return `${parts.year}-${parts.month}-${parts.day}`;
}

function commonValues(form: FormData, currencies: ReadonlySet<string>) {
  const currencyCode = String(form.get("currency_code") ?? "").trim().toUpperCase();
  if (!currencyPattern.test(currencyCode) || !currencies.has(currencyCode)) throw new Error("Choisissez une devise prise en charge.");
  const manualRaw = String(form.get("manual_fx_rate") ?? "").trim();
  const manualRate = manualRaw ? decimal(manualRaw, false) : null;
  const manualConfirmed = form.get("confirm_manual_fx") === "on";
  if (manualRate && !manualConfirmed) throw new Error("Confirmez le taux FX manuel de référence.");
  return { currencyCode, manualRate, manualConfirmed };
}

export function validateCashBalanceForm(form: FormData, currencies: ReadonlySet<string>) {
  const { currencyCode, manualRate, manualConfirmed } = commonValues(form, currencies);
  const amount = decimal(String(form.get("amount") ?? ""), true);
  const asOf = parisLocalDateTimeToIso(String(form.get("as_of") ?? ""));
  if (Date.parse(asOf) > Date.now()) throw new Error("La date de situation ne peut pas être future.");
  return { amount, currencyCode, asOf, manualRate, manualConfirmed };
}

export function validateCashFlowForm(form: FormData, currencies: ReadonlySet<string>) {
  const { currencyCode, manualRate, manualConfirmed } = commonValues(form, currencies);
  const kind = String(form.get("kind") ?? "");
  if (kind !== "contribution" && kind !== "withdrawal") throw new Error("Choisissez un versement ou un retrait.");
  const amount = decimal(String(form.get("amount") ?? ""), false);
  const occurredAt = parisLocalDateTimeToIso(String(form.get("occurred_at") ?? ""));
  if (Date.parse(occurredAt) > Date.now()) throw new Error("La date de l’opération ne peut pas être future.");
  const note = String(form.get("note") ?? "").trim() || null;
  if (note && [...note].length > 500) throw new Error("Le commentaire est limité à 500 caractères.");
  return { kind, amount, currencyCode, occurredAt, occurredOn: parisDateFromIso(occurredAt), note, manualRate, manualConfirmed };
}

export function cashError(code?: string) {
  if (code === "23505") return "Un solde existe déjà pour cette devise dans ce contrat.";
  if (code === "23503") return "Suppression refusée car cette donnée est encore référencée.";
  if (code === "23514" || code === "22023") return "Modification refusée : vérifiez la devise, le montant et la date.";
  if (code === "40001" || code === "40P01") return "Une modification simultanée a eu lieu. Rechargez la page puis réessayez.";
  if (code === "42501" || code === "PGRST116") return "Ce contrat ou cette donnée n’est pas accessible.";
  return "Enregistrement impossible. Rechargez la page puis réessayez.";
}
