// A business date is a Paris calendar date, not the UTC date of an instant.
// Civil input strings (YYYY-MM-DD) should be passed through unchanged by callers.
export function parisBusinessDate(value: string | Date = new Date()): string {
  const instant = value instanceof Date ? value : new Date(value);
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Paris", year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(instant);
  const part = (type: string) => parts.find((item) => item.type === type)!.value;
  return `${part("year")}-${part("month")}-${part("day")}`;
}
