export type SettingsActionState = {
  status: "idle" | "error" | "success";
  message?: string;
};

export type IdentifierWriteResult = "updated" | "conflict" | "error";
export type EmailChangeResult =
  | "updated"
  | "confirmation_required"
  | "error";

export const SETTINGS_SERVICE_ERROR =
  "La modification n’a pas pu être enregistrée.";

export function normalizeSettingsIdentifier(value: string) {
  return value.trim().toLowerCase();
}

export function normalizeSettingsEmail(value: string) {
  return value.trim().toLowerCase();
}

export function isValidEmail(value: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

export async function changeIdentifier(
  rawIdentifier: string,
  writeIdentifier: (identifier: string) => Promise<IdentifierWriteResult>,
): Promise<SettingsActionState> {
  const identifier = normalizeSettingsIdentifier(rawIdentifier);
  if (identifier.length < 3 || identifier.length > 40) {
    return {
      status: "error",
      message: "L’identifiant doit contenir entre 3 et 40 caractères.",
    };
  }

  try {
    const result = await writeIdentifier(identifier);
    if (result === "updated") {
      return { status: "success", message: "Identifiant mis à jour." };
    }
    if (result === "conflict") {
      return {
        status: "error",
        message: "Cet identifiant est déjà utilisé.",
      };
    }
  } catch {
    // Technical details stay server-side.
  }

  return { status: "error", message: SETTINGS_SERVICE_ERROR };
}

export async function changeEmail(
  rawEmail: string,
  currentEmail: string,
  requestEmailChange: (email: string) => Promise<EmailChangeResult>,
): Promise<SettingsActionState> {
  const email = normalizeSettingsEmail(rawEmail);
  if (!isValidEmail(email)) {
    return { status: "error", message: "Saisissez une adresse e-mail valide." };
  }
  if (email === normalizeSettingsEmail(currentEmail)) {
    return { status: "success", message: "Adresse e-mail déjà à jour." };
  }

  try {
    const result = await requestEmailChange(email);
    if (result === "updated") {
      return { status: "success", message: "Adresse e-mail mise à jour." };
    }
    if (result === "confirmation_required") {
      return {
        status: "success",
        message:
          "Confirmez la nouvelle adresse avec le ou les e-mails envoyés par Supabase.",
      };
    }
  } catch {
    // Technical details stay server-side.
  }

  return {
    status: "error",
    message: "Cette adresse e-mail ne peut pas être utilisée.",
  };
}

export async function changePassword(
  password: string,
  confirmation: string,
  writePassword: (exactPassword: string) => Promise<boolean>,
): Promise<SettingsActionState> {
  if (!password) {
    return { status: "error", message: "Saisissez un nouveau mot de passe." };
  }
  if (password !== confirmation) {
    return {
      status: "error",
      message: "Les mots de passe ne correspondent pas.",
    };
  }

  try {
    if (await writePassword(password)) {
      return { status: "success", message: "Mot de passe mis à jour." };
    }
  } catch {
    // Technical details stay server-side.
  }

  return {
    status: "error",
    message: "Le mot de passe n’a pas pu être mis à jour.",
  };
}

export function canAccessSettings(
  profileStatus: "unauthenticated" | "profile_missing" | "inactive" | "active",
) {
  return profileStatus === "active";
}

export type SettingsJsonValue = string | number | null;
export type SettingsFieldPatch = Record<string, SettingsJsonValue>;

export type ProfileSettingsDocuments = {
  preferences: unknown;
  interface_preferences: unknown;
  strategy_parameters: unknown;
};

export type ProfileSettingsFormValues = {
  displayName: string;
};

export type SettingsValidation<T extends SettingsFieldPatch> =
  | { ok: true; value: T }
  | { ok: false; message: string };

export function asSettingsRecord(value: unknown): Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {};
}

export function getDisplayedUserName(displayName: unknown, nickname: string) {
  const preferredName = typeof displayName === "string" ? displayName.trim() : "";
  if (preferredName) return preferredName;

  return nickname.length === 0
    ? nickname
    : nickname[0].toUpperCase() + nickname.slice(1);
}

export function mergeSettingsNamespace(
  document: unknown,
  namespace: string,
  patch: SettingsFieldPatch,
) {
  const currentDocument = asSettingsRecord(document);
  const currentNamespace = asSettingsRecord(currentDocument[namespace]);
  const nextNamespace: Record<string, unknown> = { ...currentNamespace };

  for (const [key, value] of Object.entries(patch)) {
    if (value === null) delete nextNamespace[key];
    else nextNamespace[key] = value;
  }

  const nextDocument = { ...currentDocument };
  if (Object.keys(nextNamespace).length === 0) delete nextDocument[namespace];
  else nextDocument[namespace] = nextNamespace;
  return nextDocument;
}

function readText(value: unknown, maximumLength: number) {
  return typeof value === "string" ? value.slice(0, maximumLength) : "";
}

export function readProfileSettings(
  documents: ProfileSettingsDocuments,
): ProfileSettingsFormValues {
  const preferences = asSettingsRecord(documents.preferences);
  const userInformation = asSettingsRecord(preferences.user_information);

  return {
    displayName: readText(userInformation.display_name, 80),
  };
}

function optionalText(
  rawValue: string,
  maximumLength: number,
  label: string,
): SettingsValidation<{ value: string | null }> {
  const value = rawValue.trim();
  if (!value) return { ok: true, value: { value: null } };
  if (value.length > maximumLength) {
    return {
      ok: false,
      message: `${label} ne doit pas dépasser ${maximumLength} caractères.`,
    };
  }
  return { ok: true, value: { value } };
}

export function validateUserInformation(
  displayName: string,
): SettingsValidation<{ display_name: string | null }> {
  const result = optionalText(displayName, 80, "Le nom d’usage");
  return result.ok
    ? { ok: true, value: { display_name: result.value.value } }
    : result;
}
