import "server-only";

import { requireUser } from "@/lib/auth/user";
import {
  asSettingsRecord,
  type ProfileSettingsDocuments,
  type SettingsFieldPatch,
} from "@/lib/settings/settings-core";
import { createClient } from "@/lib/supabase/server";

type WritableSettingsColumn = "preferences" | "strategy_parameters";

export async function getCurrentProfileSettings(): Promise<
  ProfileSettingsDocuments
> {
  const user = await requireUser();
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("profiles")
    .select("preferences, interface_preferences, strategy_parameters")
    .eq("auth_user_id", user.id)
    .single();

  if (error) throw new Error("Profile settings could not be loaded.");
  return {
    preferences: asSettingsRecord(data.preferences),
    interface_preferences: asSettingsRecord(data.interface_preferences),
    strategy_parameters: asSettingsRecord(data.strategy_parameters),
  };
}

export async function updateCurrentSettingsNamespace(
  column: WritableSettingsColumn,
  namespace: "user_information" | "strategy",
  patch: SettingsFieldPatch,
) {
  await requireUser();
  const supabase = await createClient();
  if (column === "preferences") {
    if (namespace !== "user_information") throw new Error("Unsupported preference namespace.");
    const { error } = await supabase.rpc("update_profile_user_information", { requested_patch: patch });
    if (error) throw new Error("Profile settings could not be updated.");
    return;
  }
  throw new Error("Use the shared objective history. (OBJ-OBSOLETE-WRITER)");
}
