import { isUuid } from "./asset-core";

export const REFERENCE_CATALOGS = ["sector", "activity", "geography", "region", "theme"] as const;
export type ReferenceCatalog = (typeof REFERENCE_CATALOGS)[number];

export type ReferenceCatalogActionState = {
  status: "idle" | "success" | "error";
  message?: string;
};

export type ReferenceCatalogEntry = {
  id: string;
  name: string;
  code: string;
  isActive: boolean;
  isReferenced: boolean;
  isProtected: boolean;
  canRename?: boolean;
  detail?: string;
  parentId?: string;
};

export type AnalysisReferenceCatalogs = {
  sectors: ReferenceCatalogEntry[];
  activities: ReferenceCatalogEntry[];
  regions: ReferenceCatalogEntry[];
  countries: ReferenceCatalogEntry[];
  themes: ReferenceCatalogEntry[];
};

export function isReferenceCatalog(value: string): value is ReferenceCatalog {
  return REFERENCE_CATALOGS.includes(value as ReferenceCatalog);
}

export function validateReferenceName(form: FormData, maximum = 160) {
  const name = String(form.get("name") ?? "").trim();
  if (!name || [...name].length > maximum) {
    throw new Error(`Le nom est obligatoire et limité à ${maximum} caractères.`);
  }
  return name;
}

export function validateCountryCode(form: FormData) {
  const code = String(form.get("code") ?? "").trim().toUpperCase();
  if (!/^[A-Z]{2}$/.test(code)) throw new Error("Le code pays doit contenir exactement deux lettres.");
  return code;
}

export function validateCatalogIdentifier(catalog: ReferenceCatalog, id: string) {
  return catalog === "region" ? /^[a-z0-9_]{1,50}$/.test(id) : isUuid(id);
}

export function referenceCatalogError(code?: string, message?: string) {
  if (code === "23505") return "Un élément portant ce nom ou ce code existe déjà dans ce référentiel.";
  if (code === "23503") return "Cet élément est déjà référencé. Désactivez-le plutôt que de le supprimer.";
  if (code === "23514") {
    if (message?.includes("Technical")) return "Cette référence technique est protégée.";
    return "Les informations du référentiel sont invalides.";
  }
  if (code === "42501" || code === "PGRST116") return "Cette référence ou cette opération n’est pas accessible.";
  if (code === "40001" || code === "40P01") return "Une modification simultanée a eu lieu. Rechargez la page puis réessayez.";
  return "Enregistrement impossible. Rechargez la page puis réessayez.";
}
