import "server-only";

import { runDailyAutomaticPriceRefresh } from "@/lib/assets/daily-automatic-price-refresh";
import { getDailyPriceWindow } from "@/lib/assets/daily-automatic-price-refresh-core";
import { captureDailyPatrimony } from "@/lib/patrimony/daily-history";

function logCron(status: string, details: Record<string, unknown> = {}) {
  console.info("[daily-asset-prices]", { status, ...details });
}

export async function handleAssetPriceCron(request: Request, now = new Date()) {
  const expected = process.env.CRON_SECRET?.trim();
  if (!expected) return Response.json({ status: "unavailable" }, { status: 503 });
  if (request.headers.get("authorization") !== `Bearer ${expected}`) {
    return Response.json({ status: "unauthorized" }, { status: 401 });
  }

  const window = getDailyPriceWindow(now);
  if (!window.allowed) {
    logCron("outside_window", { businessDate: window.businessDate, localHour: window.localHour });
    return Response.json({
      status: "outside_window",
      businessDate: window.businessDate,
      timeZone: "Europe/Paris",
    });
  }

  try {
    const result = await runDailyAutomaticPriceRefresh(window.businessDate);
    logCron(result.status, {
      businessDate: result.businessDate,
      attempts: result.attempts.map((attempt) => ({ attempt: attempt.attemptNumber, state: attempt.state })),
    });
    const capture = result.status === "in_progress" ? "deferred" : await captureDailyPatrimony(window.businessDate, { requestedRevision: Boolean(result.summary?.persistedPrices) }).catch(() => "unavailable");
    return Response.json({ ...result, capture }, { status: result.status === "final_failure" ? 503 : 200 });
  } catch {
    logCron("technical_failure", { businessDate: window.businessDate });
    const capture = await captureDailyPatrimony(window.businessDate).catch(() => "unavailable");
    return Response.json({ status: "error", message: "Automatic price refresh unavailable.", capture }, { status: 500 });
  }
}
