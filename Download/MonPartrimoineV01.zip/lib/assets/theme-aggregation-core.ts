import { convertToEur, latestFxRatesByCurrency, type FxRateRecord } from "@/lib/fx/fx-core";

export type ThemeAggregationRecords = {
  positions: Array<{ id: string; asset_id: string; quantity: number | string; is_active: boolean }>;
  assets: Array<{ id: string; valuation_mode: string; currency_code: string }>;
  prices: Array<{ asset_id: string; origin: "automatic" | "manual"; price: number | string; currency_code: string; observed_at: string }>;
  fxRates: FxRateRecord[];
  themes: Array<{ id: string; name: string; is_active: boolean }>;
  exposures: Array<{ asset_id: string; theme_id: string; weight_percent: number | string }>;
};

export type ThemeAggregate = {
  themeId: string;
  name: string;
  isActive: boolean;
  amountEur: number;
  percentage: number | null;
};

export type ThemeAggregation = {
  denominatorEur: number;
  themes: ThemeAggregate[];
  isPartial: boolean;
  incompleteAssetIds: string[];
};

export type ValuedThemeAggregationRecords = {
  assetValuesEur: Map<string, number> | Array<{ assetId: string; valueEur: number }>;
  themes: ThemeAggregationRecords["themes"];
  exposures: ThemeAggregationRecords["exposures"];
  incompleteAssetIds?: string[];
};

export function aggregateValuedThemeExposures(records: ValuedThemeAggregationRecords): ThemeAggregation {
  const valueByAsset = records.assetValuesEur instanceof Map
    ? records.assetValuesEur
    : new Map(records.assetValuesEur.map(({ assetId, valueEur }) => [assetId, valueEur]));
  const incomplete = new Set(records.incompleteAssetIds ?? []);
  const denominatorEur = [...valueByAsset.values()].reduce((sum, value) => sum + value, 0);
  const amountByTheme = new Map<string, number>();
  for (const exposure of records.exposures) {
    const assetValue = valueByAsset.get(exposure.asset_id);
    const weight = Number(exposure.weight_percent);
    if (assetValue === undefined || !Number.isFinite(weight) || weight <= 0 || weight > 100) continue;
    amountByTheme.set(exposure.theme_id, (amountByTheme.get(exposure.theme_id) ?? 0) + assetValue * weight / 100);
  }

  return {
    denominatorEur,
    themes: records.themes
      .filter((theme) => amountByTheme.has(theme.id))
      .map((theme) => {
        const amountEur = amountByTheme.get(theme.id) ?? 0;
        return {
          themeId: theme.id,
          name: theme.name,
          isActive: theme.is_active,
          amountEur,
          percentage: denominatorEur > 0 ? amountEur / denominatorEur * 100 : null,
        };
      })
      .sort((a, b) => b.amountEur - a.amountEur || a.name.localeCompare(b.name, "fr")),
    isPartial: incomplete.size > 0,
    incompleteAssetIds: [...incomplete].sort(),
  };
}

export function aggregateThemeExposures(
  records: ThemeAggregationRecords,
  now = new Date().toISOString(),
): ThemeAggregation {
  const assets = new Map(records.assets.map((asset) => [asset.id, asset]));
  const latestPrices = new Map<string, ThemeAggregationRecords["prices"][number]>();
  const asOf = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Paris" }).format(new Date(now));
  const rates = latestFxRatesByCurrency(records.fxRates, asOf);
  for (const price of records.prices) {
    const asset = assets.get(price.asset_id);
    if (!asset || Date.parse(price.observed_at) > Date.parse(now) || Number(price.price) <= 0) continue;
    const expectedOrigin = asset.valuation_mode === "manual" ? "manual" : "automatic";
    if (price.origin !== expectedOrigin) continue;
    const existing = latestPrices.get(price.asset_id);
    if (!existing || Date.parse(price.observed_at) > Date.parse(existing.observed_at)) latestPrices.set(price.asset_id, price);
  }

  const valueByAsset = new Map<string, number>();
  const incomplete = new Set<string>();
  for (const position of records.positions) {
    if (!position.is_active) continue;
    const price = latestPrices.get(position.asset_id);
    const quantity = Number(position.quantity);
    if (!price || !Number.isFinite(quantity) || quantity <= 0) {
      incomplete.add(position.asset_id);
      continue;
    }
    const converted = convertToEur(quantity * Number(price.price), price.currency_code, rates.get(price.currency_code));
    if (converted.amountEur === null || !Number.isFinite(converted.amountEur)) {
      incomplete.add(position.asset_id);
      continue;
    }
    valueByAsset.set(position.asset_id, (valueByAsset.get(position.asset_id) ?? 0) + converted.amountEur);
  }

  return aggregateValuedThemeExposures({
    assetValuesEur: valueByAsset,
    themes: records.themes,
    exposures: records.exposures,
    incompleteAssetIds: [...incomplete],
  });
}
