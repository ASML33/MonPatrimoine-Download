import { isContractInUserScope } from "@/lib/contracts/contract-scope";
import "server-only";

import { createClient } from "@/lib/supabase/server";
import { aggregateThemeExposures, type ThemeAggregation } from "./theme-aggregation-core";

export async function getPortfolioThemeAggregation(userId: string): Promise<ThemeAggregation> {
  const supabase = await createClient();
  const [positionsResult, themesResult] = await Promise.all([
    supabase.from("positions").select("id,contract_id,asset_id,quantity,is_active").eq("user_id", userId).eq("is_active", true),
    supabase.from("themes").select("id,name,is_active").eq("owner_user_id", userId),
  ]);
  if (positionsResult.error || themesResult.error) throw new Error("Theme aggregation unavailable");
  positionsResult.data = (positionsResult.data ?? []).filter((row) => isContractInUserScope(row.contract_id));
  const assetIds = [...new Set((positionsResult.data ?? []).map(({ asset_id }) => asset_id))];
  if (!assetIds.length) return aggregateThemeExposures({ positions: [], assets: [], prices: [], fxRates: [], themes: themesResult.data ?? [], exposures: [] });

  const [assetsResult, pricesResult, exposuresResult] = await Promise.all([
    supabase.from("assets").select("id,valuation_mode,currency_code").in("id", assetIds),
    supabase.from("asset_prices").select("asset_id,origin,price,currency_code,observed_at").in("asset_id", assetIds).order("observed_at", { ascending: false }),
    supabase.from("asset_theme_exposures").select("asset_id,theme_id,weight_percent").in("asset_id", assetIds).eq("stage", "effective"),
  ]);
  if (assetsResult.error || pricesResult.error || exposuresResult.error) throw new Error("Theme aggregation unavailable");
  const currencies = [...new Set((pricesResult.data ?? []).map(({ currency_code }) => currency_code).filter((code) => code !== "EUR"))];
  const today = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Paris" }).format(new Date());
  const ratesResult = currencies.length
    ? await supabase.from("fx_rates").select("currency_code,requested_on,observed_on,eur_per_unit,source,obtained_at").in("currency_code", currencies).lte("requested_on", today).order("requested_on", { ascending: false }).order("obtained_at", { ascending: false })
    : { data: [], error: null };
  if (ratesResult.error) throw new Error("Theme aggregation unavailable");
  return aggregateThemeExposures({
    positions: positionsResult.data ?? [],
    assets: assetsResult.data ?? [],
    prices: (pricesResult.data ?? []) as Array<{ asset_id: string; origin: "automatic" | "manual"; price: number | string; currency_code: string; observed_at: string }>,
    fxRates: (ratesResult.data ?? []) as Array<{ currency_code: string; requested_on: string; observed_on: string; eur_per_unit: number | string; source: "ecb" | "frankfurter" | "manual"; obtained_at: string }>,
    themes: themesResult.data ?? [],
    exposures: exposuresResult.data ?? [],
  });
}
