import "server-only";

import { createClient } from "@/lib/supabase/server";
import { emptyThemeSlot, type ThemeExposureWorkspace, type ThemeReference } from "./theme-core";
import type { ExposureStage } from "./exposure-core";
import { isMissingThemeSchemaError, ThemeSchemaUnavailableError } from "./theme-schema";

type RawSet = {
  stage: "draft" | "effective";
  data_date: string | null;
  source: string | null;
  origin: string | null;
  updated_at: string;
};

export async function getThemes(userId: string): Promise<ThemeReference[]> {
  const supabase = await createClient();
  const [themesResult, exposureResult] = await Promise.all([
    supabase.from("themes").select("id,name,is_active,created_at,updated_at").eq("owner_user_id", userId).order("name"),
    supabase.from("asset_theme_exposures").select("theme_id"),
  ]);
  if (themesResult.error || exposureResult.error) throw new Error("Themes unavailable");
  const referenced = new Set((exposureResult.data ?? []).map(({ theme_id }) => theme_id));
  return (themesResult.data ?? []).map((theme) => ({
    id: theme.id,
    name: theme.name,
    isActive: theme.is_active,
    createdAt: theme.created_at,
    updatedAt: theme.updated_at,
    isReferenced: referenced.has(theme.id),
  }));
}

export async function getAssetThemeWorkspace(assetId: string, userId: string): Promise<ThemeExposureWorkspace | null> {
  const supabase = await createClient();
  const [assetResult, themesResult, setResult, exposureResult] = await Promise.all([
    supabase.from("assets").select("id").eq("id", assetId).eq("owner_user_id", userId).maybeSingle(),
    supabase.from("themes").select("id,name,is_active,created_at,updated_at").eq("owner_user_id", userId).order("name"),
    supabase.from("asset_theme_exposure_sets").select("stage,data_date,source,origin,updated_at").eq("asset_id", assetId),
    supabase.from("asset_theme_exposures").select("stage,theme_id,weight_percent").eq("asset_id", assetId),
  ]);
  const errors = [assetResult.error, themesResult.error, setResult.error, exposureResult.error].filter((error) => error !== null);
  if (errors.length && errors.every(isMissingThemeSchemaError)) throw new ThemeSchemaUnavailableError();
  if (errors.length) throw new Error("Theme exposures unavailable");
  if (!assetResult.data) return null;

  const usedThemeIds = new Set((exposureResult.data ?? []).map(({ theme_id }) => theme_id));
  const themes: ThemeReference[] = (themesResult.data ?? []).map((theme) => ({
    id: theme.id,
    name: theme.name,
    isActive: theme.is_active,
    createdAt: theme.created_at,
    updatedAt: theme.updated_at,
    isReferenced: usedThemeIds.has(theme.id),
  }));
  const slots: ThemeExposureWorkspace["slots"] = { draft: emptyThemeSlot(), effective: emptyThemeSlot() };
  for (const raw of (setResult.data ?? []) as RawSet[]) {
    const slot = slots[raw.stage];
    slot.exists = true;
    slot.dataDate = raw.data_date;
    slot.source = raw.source;
    slot.origin = raw.origin;
    slot.updatedAt = raw.updated_at;
  }
  for (const row of exposureResult.data ?? []) {
    if (row.stage !== "draft" && row.stage !== "effective") continue;
    const stage = row.stage as ExposureStage;
    slots[stage].rows.push({ themeId: row.theme_id, weightPercent: Number(row.weight_percent) });
  }
  for (const slot of Object.values(slots)) {
    slot.total = Math.round(slot.rows.reduce((sum, row) => sum + row.weightPercent, 0) * 100) / 100;
  }
  return { assetId, themes, slots };
}
