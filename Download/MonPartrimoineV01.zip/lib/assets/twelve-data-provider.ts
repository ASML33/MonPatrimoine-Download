import {
  retryAfterFromResponse,
  type AutomaticPriceAsset,
  type AutomaticPriceProvider,
  type AutomaticPriceResult,
} from "./automatic-price-provider";

type FetchLike = typeof fetch;

export async function validateTwelveDataCredential(apiKey: string, request: FetchLike = fetch) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8_000);
  try {
    const response = await request("https://api.twelvedata.com/api_usage", {
      headers: { Authorization: `apikey ${apiKey}` },
      signal: controller.signal,
      cache: "no-store",
    });
    if (!response.ok) return false;
    const body = await response.json() as Record<string, unknown>;
    return body.status !== "error" && typeof body.current_usage === "number";
  } catch {
    return false;
  } finally {
    clearTimeout(timeout);
  }
}

function failure(response: Response): AutomaticPriceResult {
  if (response.status === 401) return { status: "error", code: "authentication_failed" };
  if (response.status === 403) return { status: "error", code: "access_denied" };
  if (response.status === 429) {
    const retryAfter = retryAfterFromResponse(response);
    return { status: "error", code: "quota_exceeded", ...(retryAfter ? { retryAfter } : {}) };
  }
  if (response.status === 404) return { status: "error", code: "asset_unavailable" };
  return { status: "error", code: "provider_failed" };
}

const TWELVE_DATA_EXCHANGES: Record<string, string> = {
  AS: "XAMS",
  PA: "XPAR",
};

export function resolveTwelveDataSymbol(asset: AutomaticPriceAsset) {
  const raw = asset.symbol?.trim().toUpperCase();
  if (!raw) return null;
  if (raw.includes(":")) return raw;
  const explicit = raw.match(/^(.+)\.([A-Z0-9]+)$/);
  if (explicit) {
    const exchange = TWELVE_DATA_EXCHANGES[explicit[2]];
    return exchange ? `${explicit[1]}:${exchange}` : null;
  }
  if (asset.isin?.startsWith("NL")) return `${raw}:XAMS`;
  if (asset.isin?.startsWith("FR")) return `${raw}:XPAR`;
  if (asset.isin?.startsWith("US") || asset.currencyCode === "USD") return raw;
  return null;
}

function observedAt(value: unknown) {
  if (typeof value === "number" && Number.isFinite(value)) return new Date(value * 1000).toISOString();
  if (typeof value === "string" && Number.isFinite(Date.parse(value))) return new Date(value).toISOString();
  return new Date().toISOString();
}

function firstTimestamp(...values: unknown[]) {
  return values.find((value) => (typeof value === "number" && Number.isFinite(value))
    || (typeof value === "string" && Number.isFinite(Date.parse(value))));
}

export function createTwelveDataProvider(apiKey: string, request: FetchLike = fetch): AutomaticPriceProvider {
  return {
    name: "Twelve Data",
    async getPrice(asset, context = { capability: "intraday" }) {
      const symbol = resolveTwelveDataSymbol(asset);
      if (!symbol) return { status: "error", code: "asset_unavailable" };
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 8_000);
      try {
        const endpoint = context.capability === "eod" ? "eod" : "quote";
        const url = new URL(`https://api.twelvedata.com/${endpoint}`);
        url.searchParams.set("symbol", symbol);
        const response = await request(url, {
          headers: { Authorization: `apikey ${apiKey}` },
          signal: controller.signal,
          cache: "no-store",
        });
        if (!response.ok) return failure(response);
        const body = await response.json() as Record<string, unknown>;
        if (body.status === "error") {
          const code = Number(body.code);
          if (code === 401) return { status: "error", code: "authentication_failed" };
          if (code === 403) return { status: "error", code: "asset_unavailable" };
          if (code === 429) return { status: "error", code: "quota_exceeded" };
          return { status: "error", code: "asset_unavailable" };
        }
        const price = String(body.close ?? body.price ?? "");
        const currencyCode = String(body.currency ?? asset.currencyCode).toUpperCase();
        // Twelve Data's quote `timestamp` identifies the opening of the current
        // interval. `last_update_at` is the actual quote update instant and must
        // win when available so repeated intraday retrievals are distinguishable.
        const timestamp = firstTimestamp(body.last_update_at, body.last_quote_at, body.timestamp, body.datetime);
        return { status: "success", price, currencyCode, observedAt: observedAt(timestamp), sourceName: "Twelve Data" };
      } catch (error) {
        return { status: "error", code: error instanceof Error && error.name === "AbortError" ? "timeout" : "network_error" };
      } finally {
        clearTimeout(timeout);
      }
    },
  };
}
