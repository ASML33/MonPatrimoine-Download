import {
  retryAfterFromResponse,
  type AutomaticPriceAsset,
  type AutomaticPriceProvider,
  type AutomaticPriceResult,
} from "./automatic-price-provider";

type FetchLike = typeof fetch;

export async function validateEodhdCredential(apiKey: string, request: FetchLike = fetch) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8_000);
  try {
    const url = new URL("https://eodhd.com/api/user");
    url.searchParams.set("api_token", apiKey);
    url.searchParams.set("fmt", "json");
    const response = await request(url, { signal: controller.signal, cache: "no-store" });
    if (!response.ok) return false;
    const body = await response.json() as Record<string, unknown>;
    return typeof body.apiRequests === "number" || typeof body.subscriptionType === "string";
  } catch {
    return false;
  } finally {
    clearTimeout(timeout);
  }
}

export function resolveEodhdSymbol(asset: AutomaticPriceAsset) {
  if (!asset.symbol) return null;
  const symbol = asset.symbol.toUpperCase();
  if (symbol.includes(".")) return symbol;
  if (asset.isin?.startsWith("US")) return `${symbol}.US`;
  if (asset.isin?.startsWith("NL")) return `${symbol}.AS`;
  if (asset.isin?.startsWith("FR")) return `${symbol}.PA`;
  return null;
}

function nextUtcMidnight(now = new Date()) {
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1)).toISOString();
}

function failure(response: Response): AutomaticPriceResult {
  if (response.status === 401) return { status: "error", code: "authentication_failed" };
  if (response.status === 402) return { status: "error", code: "quota_exceeded", retryAfter: nextUtcMidnight() };
  if (response.status === 403) return { status: "error", code: "access_denied" };
  if (response.status === 429) {
    const retryAfter = retryAfterFromResponse(response);
    return { status: "error", code: "quota_exceeded", ...(retryAfter ? { retryAfter } : {}) };
  }
  if (response.status === 404) return { status: "error", code: "asset_unavailable" };
  return { status: "error", code: "provider_failed" };
}

export function createEodhdProvider(apiKey: string, mode: "latest" | "eod", request: FetchLike = fetch): AutomaticPriceProvider {
  return {
    name: "EODHD",
    async getPrice(asset) {
      const symbol = resolveEodhdSymbol(asset);
      if (!symbol) return { status: "error", code: "asset_unavailable" };
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 8_000);
      try {
        const path = mode === "eod" ? `eod/${encodeURIComponent(symbol)}` : `real-time/${encodeURIComponent(symbol)}`;
        const url = new URL(`https://eodhd.com/api/${path}`);
        url.searchParams.set("api_token", apiKey);
        url.searchParams.set("fmt", "json");
        if (mode === "eod") {
          url.searchParams.set("order", "d");
          url.searchParams.set("limit", "1");
        }
        const response = await request(url, { signal: controller.signal, cache: "no-store" });
        if (!response.ok) return failure(response);
        let raw: unknown;
        try { raw = await response.json(); }
        catch { return { status: "error", code: "invalid_quote" }; }
        const body = (Array.isArray(raw) ? raw[0] : raw) as Record<string, unknown> | undefined;
        if (!body) return { status: "error", code: "price_unavailable" };
        const price = String(body.close ?? body.adjusted_close ?? "");
        if (!price || !Number.isFinite(Number(price)) || Number(price) <= 0) {
          return { status: "error", code: "price_unavailable" };
        }
        const rawTime = body.timestamp ?? body.date;
        const observedAt = typeof rawTime === "number"
          ? new Date(rawTime * 1000).toISOString()
          : typeof rawTime === "string" && Number.isFinite(Date.parse(rawTime))
            ? new Date(rawTime).toISOString()
            : "";
        if (!observedAt) return { status: "error", code: "invalid_quote" };
        return { status: "success", price, currencyCode: asset.currencyCode, observedAt, sourceName: "EODHD" };
      } catch (error) {
        return { status: "error", code: error instanceof Error && error.name === "AbortError" ? "timeout" : "network_error" };
      } finally {
        clearTimeout(timeout);
      }
    },
  };
}
