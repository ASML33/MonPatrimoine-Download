import { currentExposurePublications, type ExposurePublication, type RawPublishedExposure } from "@/lib/assets/exposure-history";
import { parisDateFromIso } from "@/lib/cash/cash-core";
import "server-only";
import { createClient } from "@/lib/supabase/server";
import { countryDisplayName } from "@/lib/assets/country-display";
import { EXPOSURE_DIMENSIONS, type ExposureDimension, type ExposureRow, type ExposureSlot, type ExposureWorkspace } from "./exposure-core";
import { isMissingReferenceCatalogSchemaError } from "./reference-catalog-schema";

type RawExposure = {
  dimension: string;
  stage: string;
  reference_id: string;
  weight_percent: number | string;
  data_date: string | null;
  source: string | null;
  origin: string | null;
  updated_at: string;
  effectiveOn?: string|null;
  publishedAt?: string|null;
  recoveredAt?: string|null;
};

const emptySlot = (): ExposureSlot => ({ rows: [], total: 0, isComplete: false });

export async function getAssetExposureWorkspace(assetId: string, userId: string): Promise<ExposureWorkspace | null> {
  const supabase = await createClient();
  const [assetResult, sectorResult, activityResult, regionResult, countryResult, exposureResult] = await Promise.all([
    supabase.from("assets").select("id,name,symbol,isin,asset_type_code,metadata,is_active").eq("id", assetId).eq("owner_user_id", userId).maybeSingle(),
    supabase.from("effective_sectors").select("id,name,code,is_active").order("name"),
    supabase.from("sector_activities").select("id,name,code,sector_id,is_active").order("name"),
    supabase.from("geographic_regions").select("code,name,is_active").order("name"),
    supabase.from("exposure_countries").select("id,name,code,region_code,is_active").order("name"),
    supabase.from("asset_exposure_rows").select("dimension,stage,reference_id,weight_percent,data_date,source,origin,updated_at").eq("asset_id", assetId),
  ]);
  let sectorData = sectorResult.data;
  let activityData = activityResult.data;
  let regionData = regionResult.data;
  let countryData = countryResult.data;
  let sectorError = sectorResult.error;
  let activityError = activityResult.error;
  let regionError = regionResult.error;
  let countryError = countryResult.error;
  const referenceErrors = [sectorResult.error, activityResult.error, regionResult.error, countryResult.error].filter((error) => error !== null);
  if (referenceErrors.length > 0 && referenceErrors.every(isMissingReferenceCatalogSchemaError)) {
    const [legacySectors, legacyActivities, legacyRegions, legacyCountries] = await Promise.all([
      supabase.from("effective_sectors").select("id,name,code").order("name"),
      supabase.from("sector_activities").select("id,name,code,sector_id").order("name"),
      supabase.from("geographic_regions").select("code,name").order("name"),
      supabase.from("exposure_countries").select("id,name,code,region_code").order("name"),
    ]);
    sectorData = legacySectors.data?.map((row) => ({ ...row, is_active: true })) ?? null;
    activityData = legacyActivities.data?.map((row) => ({ ...row, is_active: true })) ?? null;
    regionData = legacyRegions.data?.map((row) => ({ ...row, is_active: true })) ?? null;
    countryData = legacyCountries.data?.map((row) => ({ ...row, is_active: true })) ?? null;
    sectorError = legacySectors.error;
    activityError = legacyActivities.error;
    regionError = legacyRegions.error;
    countryError = legacyCountries.error;
  }
  if (assetResult.error || sectorError || activityError || regionError || countryError || exposureResult.error) throw new Error("Asset exposures unavailable");
  if (!assetResult.data) return null;

  const versionResult=await supabase.from("asset_exposure_versions").select("*").eq("asset_id",assetId).eq("owner_user_id",userId);
  if(versionResult.error)throw new Error("Asset exposure publications unavailable");
  const publications=(versionResult.data ?? []) as ExposurePublication[];
  const applicable=currentExposurePublications(publications,parisDateFromIso(new Date().toISOString()));
  const effectiveRows=applicable.flatMap(version=>(version.rows as RawPublishedExposure[]).map(row=>({...row,effectiveOn:version.effective_on,publishedAt:version.published_at,recoveredAt:version.kind==="initial_recovery"?version.recorded_at:null})));
  const rawRows=[...((exposureResult.data ?? []) as RawExposure[]).filter(row=>row.stage==="draft"),...effectiveRows];
  const sectors = sectorData ?? [];
  const sectorNames = new Map(sectors.map((sector) => [sector.id, sector.name]));
  const sectorActivityAvailability = new Map(sectors.map((sector) => [sector.id, sector.is_active !== false]));
  const regionNames = new Map((regionData ?? []).map((region) => [region.code, region.name]));
  const regionCountryAvailability = new Map((regionData ?? []).map((region) => [region.code, region.is_active !== false]));
  const slots = Object.fromEntries(EXPOSURE_DIMENSIONS.map((dimension) => [dimension, { draft: emptySlot(), effective: emptySlot() }])) as ExposureWorkspace["slots"];
  for (const raw of rawRows) {
    if (!EXPOSURE_DIMENSIONS.includes(raw.dimension as ExposureDimension) || !["draft", "effective"].includes(raw.stage)) continue;
    const row: ExposureRow = {
      referenceId: raw.reference_id,
      weightPercent: Number(raw.weight_percent),
      dataDate: raw.data_date,
      source: raw.source,
      origin: raw.origin,
      updatedAt: raw.updated_at,
      ...{effectiveOn:raw.effectiveOn,publishedAt:raw.publishedAt,recoveredAt:raw.recoveredAt},
    };
    slots[raw.dimension as ExposureDimension][raw.stage as "draft" | "effective"].rows.push(row);
  }
  for (const dimension of EXPOSURE_DIMENSIONS) for (const stage of ["draft", "effective"] as const) {
    const slot = slots[dimension][stage];
    slot.total = Math.round(slot.rows.reduce((sum, row) => sum + row.weightPercent, 0) * 100) / 100;
    slot.isComplete = slot.rows.length > 0 && slot.total === 100;
  }

  return {
    asset: {
      id: assetResult.data.id,
      name: assetResult.data.name,
      symbol: assetResult.data.symbol,
      isin: assetResult.data.isin,
      assetTypeCode: assetResult.data.asset_type_code,
      metadata: typeof assetResult.data.metadata === "object" && assetResult.data.metadata !== null
        ? assetResult.data.metadata as Record<string, unknown>
        : {},
      isActive: assetResult.data.is_active,
    },
    references: {
      sector: sectors.map((sector) => ({ id: sector.id, name: sector.name, detail: sector.code, isActive: sector.is_active !== false })),
      activity: (activityData ?? []).map((activity) => ({ id: activity.id, name: activity.name, detail: sectorNames.get(activity.sector_id) ?? activity.code, parentId: activity.sector_id, isActive: activity.is_active !== false && sectorActivityAvailability.get(activity.sector_id) === true })),
      geography: (countryData ?? []).map((country) => ({ id: country.id, name: countryDisplayName(country.name), detail: regionNames.get(country.region_code) ?? country.region_code, isActive: country.is_active !== false && regionCountryAvailability.get(country.region_code) === true })),
    },
    publications:publications.map(v=>({id:v.id,dimension:v.dimension,effectiveOn:v.effective_on,publishedAt:v.published_at,recordedAt:v.recorded_at,initial:v.kind==="initial_recovery"})),
    slots,
  };
}
