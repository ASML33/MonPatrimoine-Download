const GREAT_BRITAIN_SOURCE_LABELS = new Set([
  "Royaume-Uni de Grande-Bretagne et d’Irlande du Nord",
  "Royaume-Uni de Grande-Bretagne et d'Irlande du Nord",
]);

export function countryDisplayName(name: string) {
  return GREAT_BRITAIN_SOURCE_LABELS.has(name.trim()) ? "Grande-Bretagne" : name;
}
