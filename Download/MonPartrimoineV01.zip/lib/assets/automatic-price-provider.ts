export type AutomaticPriceAsset = {
  id: string;
  name: string;
  symbol: string | null;
  isin: string | null;
  currencyCode: string;
  priceSource: string | null;
};

export type AutomaticPriceQuote = {
  status: "success";
  price: string;
  currencyCode: string;
  observedAt: string;
  sourceName: string;
};

export type AutomaticPriceFailureCode =
  | "provider_unavailable"
  | "asset_unavailable"
  | "quota_exceeded"
  | "access_denied"
  | "timeout"
  | "network_error"
  | "provider_failed"
  | "authentication_failed"
  | "price_unavailable"
  | "invalid_quote"
  | "stale_quote"
  | "all_providers_failed";

export type AutomaticPriceFailure = {
  status: "error";
  code: AutomaticPriceFailureCode;
  attemptedProviders?: string[];
  retryAfter?: string;
};

export type AutomaticPriceResult = AutomaticPriceQuote | AutomaticPriceFailure;

export interface AutomaticPriceProvider {
  readonly name: string;
  getPrice(
    asset: AutomaticPriceAsset,
    context?: { capability: "eod" | "intraday" },
  ): Promise<AutomaticPriceResult>;
}

export type AutomaticPriceProviderExclusion =
  | "qualification_pending"
  | "incompatible_region"
  | "incompatible_capability"
  | "incompatible_instrument";

export type AutomaticPriceProviderAttempt = {
  provider: string;
  slot: number | null;
  providerSymbol: string | null;
  status: "success" | "error" | "excluded";
  code: AutomaticPriceFailureCode | AutomaticPriceProviderExclusion | null;
  retryAfter: string | null;
};

export type AutomaticPriceProviderCandidate = {
  provider: string;
  slot?: number;
  providerSymbol?: string | null;
  exclusion?: AutomaticPriceProviderExclusion;
  execute?: () => Promise<AutomaticPriceResult>;
};

export type AutomaticPriceProviderSelection = {
  result: AutomaticPriceResult;
  attempts: AutomaticPriceProviderAttempt[];
  attemptedProviders: string[];
  primaryProvider: string | null;
  fallbackUsed: boolean;
};

export function isUsableAutomaticPriceQuote(result: AutomaticPriceResult): result is AutomaticPriceQuote {
  return result.status === "success"
    && /^\d{1,16}(?:\.\d{1,8})?$/.test(result.price) && /[1-9]/.test(result.price)
    && /^[A-Z]{3}$/.test(result.currencyCode)
    && Number.isFinite(Date.parse(result.observedAt))
    && result.sourceName.trim().length > 0 && result.sourceName.length <= 200;
}

export function retryAfterFromResponse(response: Response, now = Date.now()) {
  const value = response.headers.get("retry-after")?.trim();
  if (!value) return undefined;
  const seconds = Number(value);
  if (Number.isFinite(seconds) && seconds >= 0) return new Date(now + seconds * 1000).toISOString();
  const instant = Date.parse(value);
  return Number.isFinite(instant) && instant > now ? new Date(instant).toISOString() : undefined;
}

function combinedFailure(codes: AutomaticPriceFailureCode[], attemptedProviders: string[]): AutomaticPriceFailure {
  const unique = [...new Set(codes)];
  const code = unique.length === 1 ? unique[0] : unique.length ? "all_providers_failed" : "provider_unavailable";
  return { status: "error", code, attemptedProviders };
}

export async function selectAutomaticPriceFromProviders(
  candidates: AutomaticPriceProviderCandidate[],
): Promise<AutomaticPriceProviderSelection> {
  const attempts: AutomaticPriceProviderAttempt[] = [];
  const attemptedProviders: string[] = [];
  const failureCodes: AutomaticPriceFailureCode[] = [];
  const primaryProvider = candidates.find((candidate) => !candidate.exclusion)?.provider ?? null;

  for (const candidate of candidates) {
    const base = {
      provider: candidate.provider,
      slot: candidate.slot ?? null,
      providerSymbol: candidate.providerSymbol ?? null,
    };
    if (candidate.exclusion || !candidate.execute) {
      attempts.push({ ...base, status: "excluded", code: candidate.exclusion ?? "incompatible_instrument", retryAfter: null });
      continue;
    }
    attemptedProviders.push(candidate.provider);
    let result: AutomaticPriceResult;
    try { result = await candidate.execute(); }
    catch { result = { status: "error", code: "provider_failed" }; }
    if (isUsableAutomaticPriceQuote(result)) {
      attempts.push({ ...base, status: "success", code: null, retryAfter: null });
      return {
        result: { ...result, sourceName: candidate.provider },
        attempts,
        attemptedProviders,
        primaryProvider,
        fallbackUsed: attempts.some((attempt) => attempt.status === "error"),
      };
    }
    const code = result.status === "error" ? result.code : "invalid_quote";
    failureCodes.push(code);
    attempts.push({ ...base, status: "error", code, retryAfter: result.status === "error" ? result.retryAfter ?? null : null });
  }

  return {
    result: combinedFailure(failureCodes, attemptedProviders),
    attempts,
    attemptedProviders,
    primaryProvider,
    fallbackUsed: false,
  };
}

export function readAutomaticPriceProviderOrder(raw = process.env.MONPATRIMOINE_PRICE_PROVIDER_ORDER) {
  return [...new Set((raw ?? "").split(",").map((name) => name.trim()).filter(Boolean))];
}

export function createAutomaticPriceProviderChain(
  available: AutomaticPriceProvider[],
  order = readAutomaticPriceProviderOrder(),
): AutomaticPriceProvider {
  const providersByName = new Map(available.map((provider) => [provider.name, provider]));
  const providers = order.length
    ? order.flatMap((name) => providersByName.get(name) ?? [])
    : available;
  if (!providers.length) return createUnavailableAutomaticPriceProvider();
  return {
    name: `fallback:${providers.map((provider) => provider.name).join(">")}`,
    async getPrice(asset, context) {
      const selection = await selectAutomaticPriceFromProviders(providers.map((provider) => ({
        provider: provider.name,
        execute: () => provider.getPrice(asset, context),
      })));
      return selection.result;
    },
  };
}

export function createUnavailableAutomaticPriceProvider(): AutomaticPriceProvider {
  return {
    name: "unconfigured",
    async getPrice() { return { status: "error", code: "provider_unavailable" }; },
  };
}
