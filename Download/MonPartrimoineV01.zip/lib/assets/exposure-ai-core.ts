import {
  EXPOSURE_DIMENSIONS,
  type ExposureDimension,
  type ExposureWorkspace,
} from "./exposure-core";

export type AiExposureItem = {
  reference_id: string;
  weight_percent: number;
};

export type AiExposureProposal = Record<ExposureDimension, AiExposureItem[]>;

function asRecord(value: unknown) {
  return typeof value === "object" && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : null;
}

function validateWeight(value: unknown) {
  if (typeof value !== "number" || !Number.isFinite(value) || value <= 0 || value > 100) {
    throw new Error("Chaque pondération proposée doit être comprise entre 0 et 100 %.");
  }
  if (Math.round(value * 100) !== value * 100) {
    throw new Error("Chaque pondération proposée est limitée à deux décimales.");
  }
  return value;
}

export function validateAiExposureProposal(value: unknown, workspace: ExposureWorkspace): AiExposureProposal {
  const proposal = asRecord(value);
  if (!proposal) throw new Error("La proposition IA doit être un objet JSON.");

  const validated = {} as AiExposureProposal;
  for (const dimension of EXPOSURE_DIMENSIONS) {
    const items = proposal[dimension];
    if (!Array.isArray(items) || items.length === 0) {
      throw new Error(`La proposition doit contenir au moins une ligne pour ${dimension}.`);
    }
    const references = new Map(workspace.references[dimension].filter((reference) => reference.isActive).map((reference) => [reference.id, reference]));
    const seen = new Set<string>();
    validated[dimension] = items.map((item) => {
      const record = asRecord(item);
      const referenceId = typeof record?.reference_id === "string" ? record.reference_id : "";
      if (!references.has(referenceId)) throw new Error("La proposition contient une référence inconnue.");
      if (seen.has(referenceId)) throw new Error("La proposition contient une référence en double.");
      seen.add(referenceId);
      return { reference_id: referenceId, weight_percent: validateWeight(record?.weight_percent) };
    });
    const total = Math.round(validated[dimension].reduce((sum, item) => sum + item.weight_percent, 0) * 100) / 100;
    if (total > 100) throw new Error("Une proposition ne peut pas dépasser 100 %.");
  }

  const sectorWeights = new Map(validated.sector.map((item) => [item.reference_id, item.weight_percent]));
  const activityParents = new Map(workspace.references.activity.map((reference) => [reference.id, reference.parentId]));
  const activityTotals = new Map<string, number>();
  for (const item of validated.activity) {
    const parent = activityParents.get(item.reference_id);
    if (!parent) throw new Error("Une activité proposée ne possède pas de secteur parent valide.");
    activityTotals.set(parent, (activityTotals.get(parent) ?? 0) + item.weight_percent);
  }
  for (const [parent, total] of activityTotals) {
    if (Math.round(total * 100) / 100 > (sectorWeights.get(parent) ?? 0)) {
      throw new Error("Les activités proposées dépassent la pondération de leur secteur parent.");
    }
  }
  return validated;
}

export function parseAiExposureProposalJson(raw: string, workspace: ExposureWorkspace) {
  const trimmed = raw.trim().replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
  if (!trimmed || trimmed.length > 100_000) throw new Error("La réponse structurée est vide ou trop longue.");
  let value: unknown;
  try { value = JSON.parse(trimmed); }
  catch { throw new Error("La réponse doit être un JSON valide."); }
  return validateAiExposureProposal(value, workspace);
}

export function buildExposureAiPrompt(workspace: ExposureWorkspace, asset: Record<string, unknown>) {
  const context = {
    asset,
    effective: Object.fromEntries(EXPOSURE_DIMENSIONS.map((dimension) => [dimension, workspace.slots[dimension].effective.rows.map((row) => ({
      reference_id: row.referenceId,
      weight_percent: row.weightPercent,
    }))])),
    draft: Object.fromEntries(EXPOSURE_DIMENSIONS.map((dimension) => [dimension, workspace.slots[dimension].draft.rows.map((row) => ({
      reference_id: row.referenceId,
      weight_percent: row.weightPercent,
    }))])),
    references: Object.fromEntries(EXPOSURE_DIMENSIONS.map((dimension) => [dimension, workspace.references[dimension].filter((reference) => reference.isActive).map((reference) => ({
      id: reference.id,
      name: reference.name,
      detail: reference.detail ?? null,
      parent_id: reference.parentId ?? null,
    }))])),
  };
  return [
    "Tu aides à préparer un brouillon d’expositions patrimoniales.",
    "Réponds uniquement avec un objet JSON, sans Markdown ni commentaire.",
    "Utilise exclusivement les identifiants fournis dans references. N’invente aucun identifiant.",
    "Chaque dimension doit être présente et contenir au moins une ligne.",
    "Chaque poids est strictement positif, comporte au plus deux décimales et le total de chaque dimension ne dépasse pas 100.",
    "Pour les activités, le total par secteur parent ne dépasse pas le poids proposé pour ce secteur.",
    'Format exact : {"sector":[{"reference_id":"uuid","weight_percent":50}],"activity":[...],"geography":[...]}.',
    "Contexte :",
    JSON.stringify(context),
  ].join("\n");
}

export function aiExposureJsonSchema() {
  const item = {
    type: "object",
    additionalProperties: false,
    properties: {
      reference_id: { type: "string" },
      weight_percent: { type: "number", exclusiveMinimum: 0, maximum: 100 },
    },
    required: ["reference_id", "weight_percent"],
  };
  return {
    type: "object",
    additionalProperties: false,
    properties: Object.fromEntries(EXPOSURE_DIMENSIONS.map((dimension) => [dimension, { type: "array", minItems: 1, items: item }])),
    required: [...EXPOSURE_DIMENSIONS],
  };
}
