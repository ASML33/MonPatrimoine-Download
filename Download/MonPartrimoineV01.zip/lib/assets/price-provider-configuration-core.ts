export const PRICE_PROVIDER_ADAPTERS = [
  { value: "twelve_data", label: "Twelve Data" },
  { value: "eodhd", label: "EODHD" },
  { value: "marketstack", label: "Marketstack" },
] as const;

export const PRICE_PROVIDER_REGION_OPTIONS = [
  { value: "us", label: "US" },
  { value: "europe", label: "Europe" },
  { value: "global", label: "Global" },
] as const;

export const PRICE_PROVIDER_CAPABILITY_OPTIONS = [
  { value: "eod", label: "EOD" },
  { value: "intraday", label: "Intraday" },
  { value: "both", label: "Les deux" },
] as const;

export type PriceProviderAdapter = (typeof PRICE_PROVIDER_ADAPTERS)[number]["value"];
export type PriceProviderRegion = (typeof PRICE_PROVIDER_REGION_OPTIONS)[number]["value"];
export type PriceProviderCapability = (typeof PRICE_PROVIDER_CAPABILITY_OPTIONS)[number]["value"];
export type PriceProviderStatus = "untested" | "validated" | "invalid" | "unsupported";

export type PriceProviderConfiguration = {
  slot: number;
  providerName: string;
  adapter: PriceProviderAdapter | null;
  active: boolean;
  priority: number;
  region: PriceProviderRegion;
  capability: PriceProviderCapability;
  status: PriceProviderStatus;
  lastTestedAt: string | null;
};

export type PriceProviderConfigurationInput = Omit<PriceProviderConfiguration, "status" | "lastTestedAt"> & {
  apiKey: string | null;
};

export type PriceProviderConfigurationValidation =
  | { ok: true; value: PriceProviderConfigurationInput }
  | { ok: false; message: string };

export function resolvePriceProviderAdapter(name: string): PriceProviderAdapter | null {
  const normalized = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, "");
  if (normalized === "twelvedata") return "twelve_data";
  if (normalized === "eodhd") return "eodhd";
  if (normalized === "marketstack") return "marketstack";
  return null;
}

export function isPriceProviderAdapter(value: unknown): value is PriceProviderAdapter {
  return PRICE_PROVIDER_ADAPTERS.some((option) => option.value === value);
}

export function isPriceProviderRegion(value: unknown): value is PriceProviderRegion {
  return PRICE_PROVIDER_REGION_OPTIONS.some((option) => option.value === value);
}

export function isPriceProviderCapability(value: unknown): value is PriceProviderCapability {
  return PRICE_PROVIDER_CAPABILITY_OPTIONS.some((option) => option.value === value);
}

export function isPriceProviderStatus(value: unknown): value is PriceProviderStatus {
  return value === "untested" || value === "validated" || value === "invalid" || value === "unsupported";
}

export function validatePriceProviderConfiguration(formData: FormData): PriceProviderConfigurationValidation {
  const slot = Number(formData.get("slot"));
  const priority = Number(formData.get("priority"));
  const providerName = String(formData.get("providerName") ?? "").trim();
  const region = String(formData.get("region") ?? "");
  const capability = String(formData.get("capability") ?? "");
  const apiKeyValue = String(formData.get("apiKey") ?? "");
  const adapter = resolvePriceProviderAdapter(providerName);

  if (!Number.isInteger(slot) || slot < 1 || slot > 10) return { ok: false, message: "Le fournisseur est invalide." };
  if (!providerName || [...providerName].length > 120) return { ok: false, message: "Le nom du fournisseur est obligatoire et limité à 120 caractères." };
  if (!Number.isInteger(priority) || priority < 1 || priority > 10) return { ok: false, message: "La priorité doit être comprise entre 1 et 10." };
  if (!isPriceProviderRegion(region)) return { ok: false, message: "Sélectionnez une zone valide." };
  if (!isPriceProviderCapability(capability)) return { ok: false, message: "Sélectionnez une capacité valide." };
  if (adapter === "eodhd" && capability !== "eod") return { ok: false, message: "Le plan EODHD Free est configuré uniquement pour l’EOD et le dernier prix retardé." };
  if (adapter === "marketstack" && capability !== "eod") return { ok: false, message: "Le plan Marketstack Free est configuré uniquement pour les cours de fin de journée." };
  if (apiKeyValue && (apiKeyValue.trim() !== apiKeyValue || apiKeyValue.length > 4096)) return { ok: false, message: "La clé API saisie est invalide." };

  return { ok: true, value: { slot, providerName, adapter, active: formData.get("active") === "on", priority, region, capability, apiKey: apiKeyValue || null } };
}

export function readPriceProviderConfiguration(value: unknown): PriceProviderConfiguration | null {
  const record = typeof value === "object" && value !== null ? value as Record<string, unknown> : {};
  const slot = Number(record.slot);
  const priority = Number(record.priority);
  const providerName = String(record.provider_name ?? "");
  const adapter = record.adapter === null ? null : record.adapter;
  const lastTestedAt = record.last_tested_at === null ? null : String(record.last_tested_at ?? "");
  if (!Number.isInteger(slot) || slot < 1 || slot > 10 || !providerName || providerName.length > 120
    || !Number.isInteger(priority) || priority < 1 || priority > 10
    || (adapter !== null && !isPriceProviderAdapter(adapter)) || typeof record.active !== "boolean"
    || !isPriceProviderRegion(record.region) || !isPriceProviderCapability(record.capability)
    || !isPriceProviderStatus(record.status)
    || (lastTestedAt !== null && !Number.isFinite(Date.parse(lastTestedAt)))) return null;
  return { slot, providerName, adapter, active: record.active, priority, region: record.region, capability: record.capability, status: record.status, lastTestedAt };
}

export function priceProviderLabel(provider: PriceProviderAdapter) {
  return PRICE_PROVIDER_ADAPTERS.find((option) => option.value === provider)?.label ?? provider;
}
