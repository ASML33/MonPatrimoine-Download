import { isUuid } from "./asset-core";
import type { ExposureActionState, ExposureStage } from "./exposure-core";

export type ThemeActionState = ExposureActionState;

export type ThemeReference = {
  id: string;
  name: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
  isReferenced: boolean;
};

export type ThemeExposureRow = {
  themeId: string;
  weightPercent: number;
};

export type ThemeExposureSlot = {
  exists: boolean;
  rows: ThemeExposureRow[];
  total: number;
  dataDate: string | null;
  source: string | null;
  origin: string | null;
  updatedAt: string | null;
};

export type ThemeExposureWorkspace = {
  assetId: string;
  themes: ThemeReference[];
  slots: Record<ExposureStage, ThemeExposureSlot>;
};

function field(form: FormData, key: string) {
  return String(form.get(key) ?? "").trim();
}

function parseWeight(raw: string) {
  if (!/^\d+(?:[.,]\d{1,2})?$/.test(raw)) {
    throw new Error("Chaque pondération doit comporter au maximum deux décimales.");
  }
  const weight = Number(raw.replace(",", "."));
  if (!Number.isFinite(weight) || weight <= 0 || weight > 100) {
    throw new Error("Chaque pondération doit être supérieure à 0 et inférieure ou égale à 100.");
  }
  return weight;
}

export function validateThemeName(form: FormData) {
  const name = field(form, "name");
  if (!name || [...name].length > 160) {
    throw new Error("Le nom de la thématique est obligatoire et limité à 160 caractères.");
  }
  return name;
}

export function validateThemeExposureDraft(form: FormData) {
  const assetId = field(form, "asset_id");
  if (!isUuid(assetId)) throw new Error("Actif invalide.");

  const themeIds = form.getAll("theme_id").map((value) => String(value).trim());
  const weights = form.getAll("weight_percent").map((value) => String(value).trim());
  if (themeIds.length !== weights.length) throw new Error("Complétez chaque ligne thématique.");
  if (themeIds.some((id) => !isUuid(id))) throw new Error("Choisissez une thématique valide pour chaque ligne.");
  if (new Set(themeIds).size !== themeIds.length) throw new Error("Une thématique ne peut apparaître qu’une seule fois.");

  const items = themeIds.map((theme_id, index) => ({ theme_id, weight_percent: parseWeight(weights[index]) }));
  const total = Math.round(items.reduce((sum, item) => sum + item.weight_percent, 0) * 100) / 100;
  const dataDate = field(form, "data_date") || null;
  if (dataDate && !/^\d{4}-\d{2}-\d{2}$/.test(dataDate)) throw new Error("La date des données est invalide.");
  const source = field(form, "source") || null;
  if (source && [...source].length > 2000) throw new Error("La source est limitée à 2 000 caractères.");
  return { assetId, items, dataDate, source, total };
}

export function themeError(code?: string, message?: string) {
  if (code === "23505") return "Une thématique porte déjà ce nom ou apparaît plusieurs fois.";
  if (code === "23503") return "Cette thématique est déjà utilisée. Désactivez-la plutôt que de la supprimer.";
  if (code === "23514") {
    if (message?.includes("draft unavailable")) return "Enregistrez d’abord un brouillon.";
    return "Les données de la thématique sont invalides.";
  }
  if (code === "42501" || code === "PGRST116") return "Cette thématique ou cet actif n’est pas accessible.";
  if (code === "40001" || code === "40P01") return "Une modification simultanée a eu lieu. Rechargez la page puis réessayez.";
  return "Enregistrement impossible. Rechargez la page puis réessayez.";
}

export function emptyThemeSlot(): ThemeExposureSlot {
  return { exists: false, rows: [], total: 0, dataDate: null, source: null, origin: null, updatedAt: null };
}
