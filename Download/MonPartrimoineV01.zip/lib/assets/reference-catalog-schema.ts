const MANAGED_REFERENCE_RELATIONS = ["sectors", "sector_activities", "geographic_regions", "exposure_countries"];

export function isMissingReferenceCatalogSchemaError(error: { code?: string; message?: string } | null | undefined) {
  if (!error || (error.code !== "PGRST204" && error.code !== "42703")) return false;
  return error.message?.includes("is_active") === true
    && MANAGED_REFERENCE_RELATIONS.some((relation) => error.message?.includes(relation));
}
