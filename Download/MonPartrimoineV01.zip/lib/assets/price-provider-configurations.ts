import "server-only";

import { requireRenderUser } from "@/lib/auth/render-context";
import { requireUser } from "@/lib/auth/user";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";
import {
  isPriceProviderCapability,
  isPriceProviderAdapter,
  isPriceProviderRegion,
  readPriceProviderConfiguration,
  type PriceProviderCapability,
  type PriceProviderAdapter,
  type PriceProviderConfiguration,
  type PriceProviderConfigurationInput,
  type PriceProviderRegion,
} from "./price-provider-configuration-core";

export type PriceProviderRuntimeConfiguration = {
  slot: number;
  provider: PriceProviderAdapter;
  priority: number;
  region: PriceProviderRegion;
  capability: PriceProviderCapability;
  apiKey: string;
};

export async function getCurrentPriceProviderConfigurations(): Promise<PriceProviderConfiguration[]> {
  await requireRenderUser();
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("get_price_provider_configurations");
  if (error) throw new Error("PRICE_PROVIDER_CONFIGURATION_UNAVAILABLE");
  return (Array.isArray(data) ? data : [])
    .map(readPriceProviderConfiguration)
    .filter((configuration): configuration is PriceProviderConfiguration => configuration !== null)
    .sort((left, right) => left.slot - right.slot);
}

export async function saveCurrentPriceProviderConfiguration(input: PriceProviderConfigurationInput) {
  await requireUser();
  const supabase = await createClient();
  const { error } = await supabase.rpc("save_price_provider_configuration", {
    requested_slot: input.slot,
    requested_provider_name: input.providerName,
    requested_active: input.active,
    requested_priority: input.priority,
    requested_region: input.region,
    requested_capability: input.capability,
    api_key: input.apiKey,
  });
  if (error) throw new Error("PRICE_PROVIDER_CONFIGURATION_SAVE_FAILED");
}

export async function getPriceProviderRuntimeCredential(slot: number): Promise<{
  adapter: PriceProviderAdapter;
  apiKey: string;
} | null> {
  const admin = createAdminClient();
  const { data, error } = await admin.rpc("get_price_provider_runtime_credential", {
    requested_slot: slot,
  });
  if (error) throw new Error("PRICE_PROVIDER_CREDENTIAL_UNAVAILABLE");
  const record = Array.isArray(data) ? data[0] : data;
  if (!record || !isPriceProviderAdapter(record.adapter)
    || typeof record.api_key !== "string" || !record.api_key) return null;
  return { adapter: record.adapter, apiKey: record.api_key };
}

export async function setPriceProviderValidationStatus(
  slot: number,
  status: "validated" | "invalid",
  testedAt: string,
) {
  const admin = createAdminClient();
  const { error } = await admin.rpc("set_price_provider_validation_status", {
    requested_slot: slot,
    requested_status: status,
    requested_tested_at: testedAt,
  });
  if (error) throw new Error("PRICE_PROVIDER_VALIDATION_STATUS_SAVE_FAILED");
}

export async function deleteCurrentPriceProviderConfiguration(slot: number) {
  await requireUser();
  const supabase = await createClient();
  const { error } = await supabase.rpc("delete_price_provider_configuration", {
    requested_slot: slot,
  });
  if (error) throw new Error("PRICE_PROVIDER_CONFIGURATION_DELETE_FAILED");
}

export async function getPriceProviderRuntimeConfigurations(): Promise<PriceProviderRuntimeConfiguration[]> {
  const admin = createAdminClient();
  const { data, error } = await admin.rpc("get_price_provider_runtime_configurations");
  if (error) throw new Error("PRICE_PROVIDER_RUNTIME_CONFIGURATION_UNAVAILABLE");
  return (Array.isArray(data) ? data : []).flatMap((value) => {
    const record = typeof value === "object" && value !== null
      ? value as Record<string, unknown>
      : {};
    const slot = Number(record.slot);
    const priority = Number(record.priority);
    // A validated key alone never enables the unqualified Marketstack preparation.
    if (record.provider === "marketstack") return [];
    if (!Number.isInteger(slot) || slot < 1 || slot > 10
      || !Number.isInteger(priority) || priority < 1 || priority > 10
      || !isPriceProviderAdapter(record.provider)
      || !isPriceProviderRegion(record.region)
      || !isPriceProviderCapability(record.capability)
      || typeof record.api_key !== "string" || !record.api_key) return [];
    return [{
      slot,
      provider: record.provider,
      priority,
      region: record.region,
      capability: record.capability,
      apiKey: record.api_key,
    }];
  }).sort((left, right) => left.priority - right.priority);
}
