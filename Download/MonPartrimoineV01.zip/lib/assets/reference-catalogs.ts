import "server-only";

import { createClient } from "@/lib/supabase/server";
import { countryDisplayName } from "@/lib/assets/country-display";
import type { AnalysisReferenceCatalogs, ReferenceCatalogEntry } from "./reference-catalog-core";

export async function getAnalysisReferenceCatalogs(userId: string): Promise<AnalysisReferenceCatalogs> {
  const supabase = await createClient();
  const [sectors, activities, regions, countries, themes] = await Promise.all([
    supabase.from("effective_sectors").select("id,name,common_name,code,taxonomy,owner_user_id,is_active,has_been_used").order("name"),
    supabase.from("sector_activities").select("id,name,code,sector_id,is_active,has_been_used").order("name"),
    supabase.from("geographic_regions").select("code,name,is_active,has_been_used").order("name"),
    supabase.from("exposure_countries").select("id,name,code,region_code,is_active,has_been_used").order("name"),
    supabase.from("themes").select("id,name,is_active,has_been_used").eq("owner_user_id", userId).order("name"),
  ]);
  const results = [sectors, activities, regions, countries, themes];
  if (results.some(({ error }) => error)) throw new Error("Analysis reference catalogues unavailable");
  const sectorRows = sectors.data ?? [];
  const activityRows = activities.data ?? [];
  const regionRows = regions.data ?? [];
  const countryRows = countries.data ?? [];
  const sectorNames = new Map(sectorRows.map((item) => [item.id, item.name]));
  const regionNames = new Map(regionRows.map((item) => [item.code, item.name]));
  const regionCountryCount = new Map<string, number>();
  for (const country of countryRows) regionCountryCount.set(country.region_code, (regionCountryCount.get(country.region_code) ?? 0) + 1);

  return {
    sectors: sectorRows.map((item): ReferenceCatalogEntry => ({
      id: item.id, name: item.name, code: item.code, detail: item.taxonomy === "gics" ? `GICS ${item.code}` : "MonPatrimoine",
      isActive: item.is_active, isReferenced: item.has_been_used,
      isProtected: item.owner_user_id !== userId,
      canRename: true,
    })),
    activities: activityRows.map((item): ReferenceCatalogEntry => ({
      id: item.id, name: item.name, code: item.code, parentId: item.sector_id,
      detail: sectorNames.get(item.sector_id) ?? "Secteur indisponible", isActive: item.is_active,
      isReferenced: item.has_been_used, isProtected: item.code === "unspecified",
    })),
    regions: regionRows.map((item): ReferenceCatalogEntry => ({
      id: item.code, name: item.name, code: item.code, isActive: item.is_active,
      isReferenced: item.has_been_used || (regionCountryCount.get(item.code) ?? 0) > 0, isProtected: item.code === "unspecified",
      detail: `${regionCountryCount.get(item.code) ?? 0} pays`,
    })),
    countries: countryRows.map((item): ReferenceCatalogEntry => ({
      id: item.id, name: countryDisplayName(item.name), code: item.code, parentId: item.region_code,
      detail: regionNames.get(item.region_code) ?? "Région indisponible", isActive: item.is_active,
      isReferenced: item.has_been_used, isProtected: item.code === "unspecified",
    })),
    themes: (themes.data ?? []).map((item): ReferenceCatalogEntry => ({
      id: item.id, name: item.name, code: item.id, isActive: item.is_active,
      isReferenced: item.has_been_used, isProtected: false,
    })),
  };
}
