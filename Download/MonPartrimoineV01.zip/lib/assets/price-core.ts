import { isUuid, type ValuationMode } from "./asset-core";

export type AssetPriceActionState = {
  status: "idle" | "success" | "error";
  message?: string;
};

export type AssetPrice = {
  id: string;
  price: string;
  priceEur?: number | null;
  eurFxDate?: string | null;
  eurFxSource?: string | null;
  currencyCode: string;
  observedOn: string;
  observedAt: string;
  obtainedAt: string;
  createdAt: string;
  sourceName: string | null;
  origin: "automatic" | "manual";
};

export type AssetPriceWorkspace = {
  asset: {
    id: string;
    name: string;
    currencyCode: string;
    valuationMode: ValuationMode;
    assetTypeCode?:string;
    isActive: boolean;
  };
  today: string;
  manualPrices: AssetPrice[];
  automaticPrices: AssetPrice[];
  currentManualPrice: AssetPrice | null;
  currentAutomaticPrice: AssetPrice | null;
  currentPrice: AssetPrice | null;
  refreshStatus: {
    status: "success" | "error";
    attemptedAt: string;
    succeededAt: string | null;
    errorCode: string | null;
  } | null;
};

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const PRICE_PATTERN = /^\d{1,16}(?:[.,]\d{1,8})?$/;

function field(form: FormData, name: string) {
  return String(form.get(name) ?? "").trim();
}

export function validateManualPriceForm(form: FormData, today: string) {
  const assetId = field(form, "asset_id");
  const observedOn = field(form, "observed_on");
  const priceText = field(form, "price");
  if (!isUuid(assetId)) throw new Error("Actif invalide.");
  if (!DATE_PATTERN.test(observedOn)) throw new Error("La date du prix est obligatoire.");
  if (!DATE_PATTERN.test(today) || observedOn > today) throw new Error("La date du prix ne peut pas être future.");
  if (!PRICE_PATTERN.test(priceText)) throw new Error("Le prix doit être strictement positif et comporter au maximum huit décimales.");
  const price = priceText.replace(",", ".");
  if (!/[1-9]/.test(price)) throw new Error("Le prix doit être strictement positif.");
  return { assetId, observedOn, price };
}

export function selectCurrentManualPrice(
  valuationMode: ValuationMode,
  prices: AssetPrice[],
  today: string,
) {
  if (valuationMode !== "manual") return null;
  return prices
    .filter((price) => price.origin === "manual" && price.observedOn <= today)
    .sort((left, right) => right.observedOn.localeCompare(left.observedOn))[0] ?? null;
}

export function selectCurrentAutomaticPrice(
  valuationMode: ValuationMode,
  prices: AssetPrice[],
  now: string,
) {
  if (valuationMode !== "market_price") return null;
  return prices
    .filter((price) => price.origin === "automatic" && Date.parse(price.observedAt) <= Date.parse(now))
    .sort((left, right) => {
      const observedDifference = Date.parse(right.observedAt) - Date.parse(left.observedAt);
      if (observedDifference !== 0) return observedDifference;
      return Date.parse(right.obtainedAt) - Date.parse(left.obtainedAt);
    })[0] ?? null;
}

export function selectCurrentAssetPrice(valuationMode: ValuationMode, prices: AssetPrice[], now: string) {
  const today = now.slice(0, 10);
  return valuationMode === "manual"
    ? selectCurrentManualPrice(valuationMode, prices, today)
    : selectCurrentAutomaticPrice(valuationMode, prices, now);
}

export function manualPriceError(code?: string, message?: string) {
  if (code === "23514") {
    if (message?.includes("future")) return "La date du prix ne peut pas être future.";
    if (message?.includes("currency")) return "Le prix manuel doit utiliser la devise de l’actif.";
    return "Le prix doit être strictement positif.";
  }
  if (code === "23502") return "L’actif, le prix et la date sont obligatoires.";
  if (code === "42501" || code === "PGRST116") return "Cet actif ou cette opération n’est pas accessible.";
  if (code === "40001" || code === "40P01") return "Une modification simultanée a eu lieu. Réessayez.";
  return "Enregistrement impossible. Rechargez la page puis réessayez.";
}
