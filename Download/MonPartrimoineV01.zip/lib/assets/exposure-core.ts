import { isUuid } from "./asset-core";

export const EXPOSURE_DIMENSIONS = ["sector", "activity", "geography"] as const;
export type ExposureDimension = (typeof EXPOSURE_DIMENSIONS)[number];
export type ExposureStage = "draft" | "effective";

export type ExposureActionState = {
  status: "idle" | "success" | "error";
  message?: string;
};

export type ExposureRow = {
  referenceId: string;
  weightPercent: number;
  dataDate: string | null;
  source: string | null;
  origin: string | null;
  updatedAt: string;
  effectiveOn?: string | null;
  publishedAt?: string | null;
  recoveredAt?: string | null;
};

export type ExposureReference = {
  id: string;
  name: string;
  isActive: boolean;
  detail?: string;
  parentId?: string;
};

export type ExposureSlot = {
  rows: ExposureRow[];
  total: number;
  isComplete: boolean;
};

export type ExposureWorkspace = {
  asset: {
    id: string;
    name: string;
    symbol: string | null;
    isin: string | null;
    assetTypeCode: string;
    metadata: Record<string, unknown>;
    isActive: boolean;
  };
  references: Record<ExposureDimension, ExposureReference[]>;
  publications?: Array<{id:string;dimension:ExposureDimension;effectiveOn:string|null;publishedAt:string|null;recordedAt:string;initial:boolean}>;
  slots: Record<ExposureDimension, Record<ExposureStage, ExposureSlot>>;
};

export type ExposureDraftUiState = "base" | "saved_incomplete" | "saved_complete" | "dirty";

export function getExposureDraftUiState(hasSavedDraft: boolean, savedTotal: number, isDirty: boolean) {
  const kind: ExposureDraftUiState = isDirty
    ? "dirty"
    : !hasSavedDraft ? "base"
      : savedTotal === 100 ? "saved_complete" : "saved_incomplete";
  return { kind, canPublish: kind === "saved_complete" };
}

export const exposureDimensionLabel = (dimension: ExposureDimension) => ({
  sector: "Secteurs",
  activity: "Activités détaillées",
  geography: "Géographie",
})[dimension];

export function isExposureDimension(value: string): value is ExposureDimension {
  return EXPOSURE_DIMENSIONS.includes(value as ExposureDimension);
}

function field(form: FormData, key: string) {
  return String(form.get(key) ?? "").trim();
}

function parseWeight(raw: string) {
  if (!/^\d+(?:[.,]\d{1,2})?$/.test(raw)) throw new Error("Chaque poids doit comporter au maximum deux décimales.");
  const weight = Number(raw.replace(",", "."));
  if (!Number.isFinite(weight) || weight <= 0 || weight > 100) throw new Error("Chaque poids doit être supérieur à 0 et inférieur ou égal à 100.");
  return weight;
}

export function validateExposureDraft(form: FormData) {
  const assetId = field(form, "asset_id");
  const dimensionValue = field(form, "dimension");
  if (!isUuid(assetId)) throw new Error("Actif invalide.");
  if (!isExposureDimension(dimensionValue)) throw new Error("Répartition invalide.");

  const referenceIds = form.getAll("reference_id").map((value) => String(value).trim());
  const weights = form.getAll("weight_percent").map((value) => String(value).trim());
  if (!referenceIds.length || referenceIds.length !== weights.length) throw new Error("Ajoutez au moins une ligne de répartition complète.");
  if (referenceIds.some((id) => !isUuid(id))) throw new Error("Choisissez une référence valide pour chaque ligne.");
  if (new Set(referenceIds).size !== referenceIds.length) throw new Error("Une référence ne peut apparaître qu’une seule fois.");

  const items = referenceIds.map((reference_id, index) => ({ reference_id, weight_percent: parseWeight(weights[index]) }));
  const total = Math.round(items.reduce((sum, item) => sum + item.weight_percent, 0) * 100) / 100;
  if (total > 100) throw new Error("Le total de la répartition ne peut pas dépasser 100 %.");

  const dataDate = field(form, "data_date") || null;
  if (dataDate && !/^\d{4}-\d{2}-\d{2}$/.test(dataDate)) throw new Error("La date des données est invalide.");
  const source = field(form, "source") || null;
  if (source && [...source].length > 2000) throw new Error("La source est limitée à 2 000 caractères.");

  return { assetId, dimension: dimensionValue, items, dataDate, source, total };
}

export function exposureError(code?: string, message?: string) {
  if (code === "23505" && message?.includes("publication already exists")) return "Une publication existe déjà à cette date d’effet. Aucune version n’a été remplacée.";
  if (code === "23505") return "Une référence ne peut apparaître qu’une seule fois dans la répartition.";
  if (code === "23503") return "Une référence sélectionnée n’est plus disponible. Rechargez la page.";
  if (code === "23514") {
    if (message?.includes("Activities exceed")) return "Les activités détaillées dépassent la pondération de leur secteur parent.";
    if (message?.includes("Draft must total")) return "Le brouillon doit totaliser exactement 100 % avant validation.";
    return "La répartition est incohérente. Vérifiez le total et les liens entre secteurs et activités.";
  }
  if (code === "42501" || code === "PGRST116") return "Cet actif ou cette opération n’est pas accessible.";
  if (code === "40001" || code === "40P01") return "Une modification simultanée a eu lieu. Rechargez la page puis réessayez.";
  return "Enregistrement impossible. Rechargez la page puis réessayez.";
}

export function originLabel(origin: string | null) {
  if (!origin || origin === "user" || origin === "manual") return "Saisie manuelle";
  if (origin === "provider") return "Fournisseur";
  if (origin === "ai") return "IA";
  return "Autre provenance";
}
