import {
  retryAfterFromResponse,
  type AutomaticPriceAsset,
  type AutomaticPriceProvider,
  type AutomaticPriceResult,
} from "./automatic-price-provider";

type FetchLike = typeof fetch;
type ResolvedMarketstackSymbol = { symbol: string; mic: string };

const MARKETSTACK_EXCHANGES: Record<string, string> = {
  AS: "XAMS",
  PA: "XPAR",
};

function parsedSymbol(value: string | null | undefined): ResolvedMarketstackSymbol | null {
  const raw = value?.trim().toUpperCase();
  if (!raw) return null;
  const qualified = raw.match(/^([^:.]+)[:.]([A-Z0-9]+)$/);
  if (!qualified) return null;
  const mic = MARKETSTACK_EXCHANGES[qualified[2]] ?? qualified[2];
  return /^X[A-Z0-9]{3}$/.test(mic) ? { symbol: qualified[1], mic } : null;
}

export function resolveMarketstackSymbol(asset: AutomaticPriceAsset) {
  const explicit = parsedSymbol(asset.symbol);
  if (explicit) return `${explicit.symbol}:${explicit.mic}`;
  const raw = asset.symbol?.trim().toUpperCase();
  if (!raw) return null;
  if (raw.includes(".") || raw.includes(":")) return null;
  if (asset.isin?.startsWith("NL")) return `${raw}:XAMS`;
  if (asset.isin?.startsWith("FR")) return `${raw}:XPAR`;
  return null;
}

function nextUtcMonth(now = new Date()) {
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1)).toISOString();
}

function errorCode(body: unknown) {
  const error = typeof body === "object" && body !== null
    ? (body as Record<string, unknown>).error
    : null;
  const record = typeof error === "object" && error !== null
    ? error as Record<string, unknown>
    : {};
  return `${record.code ?? ""} ${record.type ?? ""} ${record.message ?? ""} ${record.info ?? ""}`.toLowerCase();
}

function bodyFailure(body: unknown): AutomaticPriceResult | null {
  const code = errorCode(body);
  if (!code.trim()) return null;
  if (/invalid.*access|missing.*access|access.*key|auth/.test(code)) return { status: "error", code: "authentication_failed" };
  if (/usage|quota|rate.?limit|monthly.*limit/.test(code)) return { status: "error", code: "quota_exceeded", retryAfter: nextUtcMonth() };
  if (/function.*access|endpoint.*access|not.*allowed|subscription|permission/.test(code)) return { status: "error", code: "access_denied" };
  if (/not.?found|invalid.*symbol|ticker/.test(code)) return { status: "error", code: "asset_unavailable" };
  return { status: "error", code: "provider_failed" };
}

async function responseFailure(response: Response, body?: unknown): Promise<AutomaticPriceResult> {
  const described = bodyFailure(body);
  if (described) return described;
  if (response.status === 401) return { status: "error", code: "authentication_failed" };
  if (response.status === 402 || response.status === 429) {
    return { status: "error", code: "quota_exceeded", retryAfter: retryAfterFromResponse(response) ?? nextUtcMonth() };
  }
  if (response.status === 403) return { status: "error", code: "access_denied" };
  if (response.status === 404) return { status: "error", code: "asset_unavailable" };
  return { status: "error", code: "provider_failed" };
}

function exactTimestamp(value: unknown) {
  if (typeof value !== "string" || /^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(Date.parse(value))) return null;
  return new Date(value).toISOString();
}

export type MarketstackCredentialStatus = "valid" | "invalid" | "access_denied" | "quota_exceeded" | "unavailable";

function credentialStatus(result: AutomaticPriceResult | null): MarketstackCredentialStatus {
  if (!result || result.status === "success") return "valid";
  if (result.code === "authentication_failed") return "invalid";
  if (result.code === "access_denied") return "access_denied";
  if (result.code === "quota_exceeded") return "quota_exceeded";
  return "unavailable";
}

export async function checkMarketstackCredential(apiKey: string, request: FetchLike = fetch): Promise<MarketstackCredentialStatus> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8_000);
  try {
    const url = new URL("https://api.marketstack.com/v2/exchanges");
    url.searchParams.set("access_key", apiKey);
    url.searchParams.set("limit", "1");
    const response = await request(url, { signal: controller.signal, cache: "no-store" });
    let body: Record<string, unknown>;
    try { body = await response.json() as Record<string, unknown>; }
    catch { return "unavailable"; }
    if (!response.ok) return credentialStatus(await responseFailure(response, body));
    const described = bodyFailure(body);
    if (described) return credentialStatus(described);
    return Array.isArray(body.data) ? "valid" : "unavailable";
  } catch {
    return "unavailable";
  } finally {
    clearTimeout(timeout);
  }
}

export async function validateMarketstackCredential(apiKey: string, request: FetchLike = fetch) {
  return await checkMarketstackCredential(apiKey, request) === "valid";
}

export function createMarketstackProvider(apiKey: string, request: FetchLike = fetch): AutomaticPriceProvider {
  return {
    name: "Marketstack EOD",
    async getPrice(asset) {
      const resolved = parsedSymbol(resolveMarketstackSymbol(asset));
      if (!resolved) return { status: "error", code: "asset_unavailable" };
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 8_000);
      try {
        const url = new URL("https://api.marketstack.com/v2/eod/latest");
        url.searchParams.set("access_key", apiKey);
        url.searchParams.set("symbols", resolved.symbol);
        url.searchParams.set("exchange", resolved.mic);
        url.searchParams.set("limit", "100");
        const response = await request(url, { signal: controller.signal, cache: "no-store" });
        let raw: unknown;
        try { raw = await response.json(); }
        catch { return response.ok ? { status: "error", code: "invalid_quote" } : responseFailure(response); }
        if (!response.ok) return responseFailure(response, raw);
        const described = bodyFailure(raw);
        if (described) return described;
        const data = typeof raw === "object" && raw !== null && Array.isArray((raw as Record<string, unknown>).data)
          ? (raw as { data: unknown[] }).data
          : [];
        const row = data.find((entry) => {
          const record = typeof entry === "object" && entry !== null ? entry as Record<string, unknown> : {};
          return String(record.symbol ?? "").toUpperCase() === resolved.symbol
            && String(record.exchange ?? "").toUpperCase() === resolved.mic;
        }) as Record<string, unknown> | undefined;
        if (!row) return { status: "error", code: "asset_unavailable" };
        const price = String(row.close ?? "");
        const currencyCode = String(row.price_currency ?? "").toUpperCase();
        const observedAt = exactTimestamp(row.date);
        if (!Number.isFinite(Number(price)) || Number(price) <= 0 || !/^[A-Z]{3}$/.test(currencyCode) || !observedAt) {
          return { status: "error", code: "invalid_quote" };
        }
        return { status: "success", price, currencyCode, observedAt, sourceName: "Marketstack EOD" };
      } catch (error) {
        return { status: "error", code: error instanceof Error && error.name === "AbortError" ? "timeout" : "network_error" };
      } finally {
        clearTimeout(timeout);
      }
    },
  };
}
