import "server-only";

import { createAdminClient } from "@/lib/supabase/admin";
import { refreshAutomaticAssetPrices } from "./automatic-prices";
import {
  executeDailyAutomaticPriceRefresh,
  type DailyPriceRefreshAttempt,
  type DailyPriceRefreshClaim,
  type DailyPriceRefreshSummary,
} from "./daily-automatic-price-refresh-core";

type ClaimRow = {
  claimed: boolean;
  decision: DailyPriceRefreshClaim["decision"];
  attempt_number: 1 | 2 | null;
  claim_token: string | null;
};

function firstRow<T>(data: T | T[] | null): T | null {
  return Array.isArray(data) ? (data[0] ?? null) : data;
}

export async function runDailyAutomaticPriceRefresh(businessDate: string) {
  const admin = createAdminClient();

  return executeDailyAutomaticPriceRefresh(businessDate, {
    async claim(requestedBusinessDate) {
      const result = await admin.rpc("claim_daily_asset_price_refresh", {
        requested_business_date: requestedBusinessDate,
      });
      const row = firstRow(result.data as ClaimRow | ClaimRow[] | null);
      if (result.error || !row) throw new Error("DAILY_PRICE_REFRESH_CLAIM_UNAVAILABLE");
      return {
        claimed: row.claimed,
        decision: row.decision,
        attemptNumber: row.attempt_number,
        token: row.claim_token,
      };
    },
    async complete(input) {
      const result = await admin.rpc("complete_daily_asset_price_refresh", {
        requested_claim_token: input.token,
        requested_outcome: input.outcome,
        requested_failure_kind: input.failureKind,
        requested_successes: input.summary?.successes ?? 0,
        requested_failures: input.summary?.failures ?? 0,
        requested_ignored: input.summary?.ignored ?? 0,
        requested_provider: input.summary?.provider ?? null,
      });
      const state = firstRow(result.data as DailyPriceRefreshAttempt["state"] | DailyPriceRefreshAttempt["state"][] | null);
      if (result.error || !state) throw new Error("DAILY_PRICE_REFRESH_COMPLETION_UNAVAILABLE");
      return state;
    },
    async refresh(): Promise<DailyPriceRefreshSummary> {
      return refreshAutomaticAssetPrices({ mode: "scheduled" });
    },
  });
}
