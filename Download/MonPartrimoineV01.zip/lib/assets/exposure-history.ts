export type ExposureDimension = "sector" | "activity" | "geography";
export type DatedExposure = {
 assetId: string; dimension: ExposureDimension; referenceId?: string; name: string; weight: number;
 dataDate: string | null; source: string | null; unallocated?: boolean;
 versionId?: string; effectiveFrom?: string | null; publishedAt?: string | null;
 snapshotDate?: string; stage?: string; isCurrent?: boolean; initialRecovery?: boolean; recoveryDate?: string;
};
export function resolveExposureHistory<T extends DatedExposure>(rows: readonly T[], assetId: string, dimension: ExposureDimension, date: string) {
 const grouped = new Map<string,T[]>();
 for (const row of rows) {
  if (row.assetId !== assetId || row.dimension !== dimension || (row.stage === "draft" || row.stage === "scheduled")) continue;
  const key = row.snapshotDate ? `snapshot:${row.snapshotDate}:${row.versionId ?? ""}` : `version:${row.versionId ?? row.effectiveFrom ?? row.dataDate ?? "undated"}`;
  grouped.set(key,[...(grouped.get(key) ?? []),row]);
 }
 const allSets=[...grouped.values()];
 const usable=(set:T[])=>set.every(row=>Number.isFinite(row.weight)&&row.weight>=0) && set.reduce((sum,row)=>sum+row.weight,0)<=100.000001 && new Set(set.map(row=>row.referenceId??row.name)).size===set.length;
 const exact=allSets.filter(set=>set[0].snapshotDate===date);
 if(exact.some(set=>!usable(set)))throw new Error("Les pondérations de la capture présente sont incohérentes");
 const sets=allSets.filter(usable);
 const applicableDate = (set:T[]) => set[0].effectiveFrom ?? set[0].snapshotDate ?? set[0].dataDate ?? set[0].recoveryDate;
 const dated = sets.filter(set=>applicableDate(set));
 const previous = dated.filter(set=>applicableDate(set)!<=date).sort((a,b)=>applicableDate(b)!.localeCompare(applicableDate(a)!));
 const next = dated.filter(set=>applicableDate(set)!>date).sort((a,b)=>applicableDate(a)!.localeCompare(applicableDate(b)!));
 const explicit = dated.filter(set=>set[0].effectiveFrom && !set[0].initialRecovery);
 const preceding = previous.filter(set=>!set[0].initialRecovery);
 const initial = dated.filter(set=>set[0].initialRecovery);
 // Initial recovery is the predecessor of subsequent publications, not a
 // fabricated publication at the source data date.
 const effectivePrevious=explicit.some(set=>applicableDate(set)!<=date)?preceding:previous;
 const choices=exact.length?exact:explicit.length && !preceding.length && initial.length?initial:effectivePrevious.length?effectivePrevious:next;
 if(!choices.length)return {rows:[] as T[],method:"unavailable" as const,sourceDate:null};
 const chosen=choices[0], sourceDate=chosen[0].dataDate ?? chosen[0].effectiveFrom ?? chosen[0].snapshotDate ?? null;
 const sameDate=exact.length?choices:choices.filter(set=>applicableDate(set)===applicableDate(chosen));
 const signature=(set:T[])=>JSON.stringify(set.map(row=>[row.referenceId ?? row.name,row.weight,row.dataDate,row.source]).sort((a,b)=>String(a[0]).localeCompare(String(b[0]))));
 if(sameDate.some(set=>signature(set)!==signature(chosen)))throw new Error("Répartitions concurrentes ambiguës pour une même date");
 return {rows:chosen,method:exact.length?"exact" as const:previous.length?"continuity" as const:"backfill" as const,sourceDate};
}

export type ExposurePublication = { id:string;asset_id:string;dimension:ExposureDimension;kind:"initial_recovery"|"publication";effective_on:string|null;published_at:string|null;recorded_at:string;rows:unknown };
export type RawPublishedExposure = { asset_id:string;dimension:ExposureDimension;stage:string;reference_id:string;weight_percent:number|string;data_date:string|null;source:string|null;origin:string|null;updated_at:string };
export function currentExposurePublications(versions: readonly ExposurePublication[], date: string) {
 const selected=new Map<string,ExposurePublication>();
 for(const version of versions){
  if(version.kind!=="initial_recovery" && (!version.effective_on || version.effective_on>date))continue;
  const key=`${version.asset_id}:${version.dimension}`,old=selected.get(key);
  if(!old || (version.effective_on ?? "")>(old.effective_on ?? ""))selected.set(key,version);
 }
 return [...selected.values()];
}
export function publicationExposureRows(versions: readonly ExposurePublication[],names: ReadonlyMap<string,string>,unknown:ReadonlySet<string>,knownOn?:string) : DatedExposure[] {
 return versions.flatMap(version=>{
  if(!Array.isArray(version.rows))throw new Error("Version d’exposition illisible");
  return (version.rows as RawPublishedExposure[]).map(row=>{
   if(row.asset_id!==version.asset_id||row.dimension!==version.dimension||row.stage!=="effective")throw new Error("Identité de version incohérente");
   return {stage:version.effective_on && knownOn && version.effective_on>knownOn?"scheduled":"effective",assetId:version.asset_id,dimension:version.dimension,referenceId:row.reference_id,name:names.get(row.reference_id)??"Non spécifié",weight:Number(row.weight_percent),dataDate:row.data_date,source:row.source,unallocated:unknown.has(row.reference_id),versionId:version.id,effectiveFrom:version.effective_on,publishedAt:version.published_at,initialRecovery:version.kind==="initial_recovery",recoveryDate:new Intl.DateTimeFormat("en-CA",{timeZone:"Europe/Paris"}).format(new Date(version.recorded_at))};
  });
 });
}
