import { readStoredFxRates } from "@/lib/fx/stored-fx-rates";
import { convertToEur, latestFxRatesByCurrency } from "@/lib/fx/fx-core";
import { parisDateFromIso } from "@/lib/cash/cash-core";
import { parisBusinessDate } from "@/lib/dates/business-date";
import "server-only";
import { createClient } from "@/lib/supabase/server";
import { selectCurrentAssetPrice, selectCurrentAutomaticPrice, selectCurrentManualPrice, type AssetPrice, type AssetPriceWorkspace } from "./price-core";

type RawPrice = {
  id: string;
  price: number | string;
  currency_code: string;
  observed_at: string;
  obtained_at: string;
  created_at: string;
  source_name: string | null;
  origin: "automatic" | "manual";
};

export function businessToday(now = new Date()) {
  return parisBusinessDate(now);
}

export async function getAssetPriceWorkspace(assetId: string, userId: string): Promise<AssetPriceWorkspace | null> {
  const supabase = await createClient();
  const [assetResult, pricesResult, refreshResult] = await Promise.all([
    supabase.from("assets")
      .select("id,name,currency_code,valuation_mode,is_active,asset_type_code")
      .eq("id", assetId).eq("owner_user_id", userId).maybeSingle(),
    supabase.from("asset_prices")
      .select("id,price,currency_code,observed_at,obtained_at,created_at,source_name,origin")
      .eq("asset_id", assetId)
      .order("observed_at", { ascending: false })
      .order("obtained_at", { ascending: false }),
    supabase.from("asset_price_refresh_status")
      .select("status,last_attempted_at,last_succeeded_at,error_code")
      .eq("asset_id", assetId).maybeSingle(),
  ]);
  if (assetResult.error || pricesResult.error || refreshResult.error) throw new Error("Asset prices unavailable");
  if (!assetResult.data) return null;

  const rates = await readStoredFxRates(supabase, [assetResult.data.currency_code], businessToday());
  const withEurPrice = (price: AssetPrice, date: string): AssetPrice => {
    const conversion = convertToEur(price.price, price.currencyCode, latestFxRatesByCurrency(rates, date).get(price.currencyCode));
    return { ...price, priceEur: conversion.amountEur, eurFxDate: conversion.rate?.observed_on ?? null, eurFxSource: conversion.rate?.source ?? null };
  };
  const prices: AssetPrice[] = ((pricesResult.data ?? []) as RawPrice[])
    .filter((price) => price.origin === "automatic" || price.origin === "manual")
    .map((price) => ({
    id: price.id,
    price: String(price.price),
    currencyCode: price.currency_code,
    observedOn: price.observed_at.slice(0, 10),
    observedAt: price.observed_at,
    obtainedAt: price.obtained_at,
    createdAt: price.created_at,
    sourceName: price.source_name,
    origin: price.origin,
  })).map(price => withEurPrice(price, parisDateFromIso(price.observedAt)));
  const manualPrices = prices.filter((price) => price.origin === "manual");
  const automaticPrices = prices.filter((price) => price.origin === "automatic");
  const today = businessToday();
  const now = new Date().toISOString();
  const selectedCurrent = selectCurrentAssetPrice(assetResult.data.valuation_mode, prices, now);
  const currentPrice = selectedCurrent ? withEurPrice(selectedCurrent, today) : null;
  return {
    asset: {
      id: assetResult.data.id,
      name: assetResult.data.name,
      currencyCode: assetResult.data.currency_code,
      valuationMode: assetResult.data.valuation_mode,assetTypeCode:assetResult.data.asset_type_code,
      isActive: assetResult.data.is_active,
    },
    today,
    manualPrices,
    automaticPrices,
    currentManualPrice: selectCurrentManualPrice(assetResult.data.valuation_mode, manualPrices, today),
    currentAutomaticPrice: selectCurrentAutomaticPrice(assetResult.data.valuation_mode, automaticPrices, now),
    currentPrice,
    refreshStatus: refreshResult.data ? {
      status: refreshResult.data.status,
      attemptedAt: refreshResult.data.last_attempted_at,
      succeededAt: refreshResult.data.last_succeeded_at,
      errorCode: refreshResult.data.error_code,
    } : null,
  };
}
