export const DAILY_PRICE_TIME_ZONE = "Europe/Paris";

export type DailyPriceWindow = {
  businessDate: string;
  localHour: number;
  allowed: boolean;
};

export type DailyPriceRefreshSummary = {
  successes: number;
  failures: number;
  ignored: number;
  provider: string;
  message: string;
  persistedPrices?: number;
};

export type DailyPriceRefreshClaim = {
  claimed: boolean;
  decision: "claimed" | "already_completed" | "in_progress" | "attempts_exhausted";
  attemptNumber: 1 | 2 | null;
  token: string | null;
};

export type DailyPriceRefreshAttempt = {
  attemptNumber: 1 | 2;
  state: "completed" | "retryable_failure" | "final_failure";
  failureKind: "total_failure" | "technical_failure" | null;
  successes: number;
  failures: number;
  ignored: number;
};

export type DailyPriceRefreshResult = {
  status: "success" | "partial" | "final_failure" | "already_completed" | "in_progress" | "attempts_exhausted";
  businessDate: string;
  attempts: DailyPriceRefreshAttempt[];
  summary: DailyPriceRefreshSummary | null;
};

type CompletionInput = {
  token: string;
  outcome: "completed" | "retryable_failure";
  failureKind: "total_failure" | "technical_failure" | null;
  summary: DailyPriceRefreshSummary | null;
};

type DailyPriceRefreshDependencies = {
  claim: (businessDate: string) => Promise<DailyPriceRefreshClaim>;
  complete: (input: CompletionInput) => Promise<DailyPriceRefreshAttempt["state"]>;
  refresh: () => Promise<DailyPriceRefreshSummary>;
};

const parisDateTime = new Intl.DateTimeFormat("en-CA", {
  timeZone: DAILY_PRICE_TIME_ZONE,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hourCycle: "h23",
});

export function getDailyPriceWindow(now: Date): DailyPriceWindow {
  const parts = Object.fromEntries(
    parisDateTime.formatToParts(now).map((part) => [part.type, part.value]),
  );
  const localHour = Number(parts.hour);
  return {
    businessDate: `${parts.year}-${parts.month}-${parts.day}`,
    localHour,
    allowed: localHour === 23,
  };
}

export function isRetryableDailyPriceFailure(summary: DailyPriceRefreshSummary) {
  return summary.failures > 0 && summary.successes === 0;
}

export async function executeDailyAutomaticPriceRefresh(
  businessDate: string,
  dependencies: DailyPriceRefreshDependencies,
): Promise<DailyPriceRefreshResult> {
  const attempts: DailyPriceRefreshAttempt[] = [];
  let lastSummary: DailyPriceRefreshSummary | null = null;

  for (let allowedAttempt = 1; allowedAttempt <= 2; allowedAttempt += 1) {
    const claim = await dependencies.claim(businessDate);
    if (!claim.claimed || !claim.attemptNumber || !claim.token) {
      return {
        status: claim.decision === "claimed" ? "in_progress" : claim.decision,
        businessDate,
        attempts,
        summary: lastSummary,
      };
    }

    let failureKind: DailyPriceRefreshAttempt["failureKind"] = null;
    let outcome: CompletionInput["outcome"] = "completed";
    try {
      lastSummary = await dependencies.refresh();
      if (isRetryableDailyPriceFailure(lastSummary)) {
        failureKind = "total_failure";
        outcome = "retryable_failure";
      }
    } catch {
      lastSummary = null;
      failureKind = "technical_failure";
      outcome = "retryable_failure";
    }

    const state = await dependencies.complete({
      token: claim.token,
      outcome,
      failureKind,
      summary: lastSummary,
    });
    attempts.push({
      attemptNumber: claim.attemptNumber,
      state,
      failureKind,
      successes: lastSummary?.successes ?? 0,
      failures: lastSummary?.failures ?? 0,
      ignored: lastSummary?.ignored ?? 0,
    });

    if (state === "retryable_failure") continue;
    if (state === "final_failure") {
      return { status: "final_failure", businessDate, attempts, summary: lastSummary };
    }
    return {
      status: lastSummary?.failures ? "partial" : "success",
      businessDate,
      attempts,
      summary: lastSummary,
    };
  }

  return { status: "attempts_exhausted", businessDate, attempts, summary: lastSummary };
}
