import "server-only";

import { createAdminClient } from "@/lib/supabase/admin";
import { parisDateFromIso } from "@/lib/cash/cash-core";
import { resolveFxRate } from "@/lib/fx/fx-rates";
import {
  isUsableAutomaticPriceQuote,
  selectAutomaticPriceFromProviders,
  type AutomaticPriceAsset,
  type AutomaticPriceFailure,
  type AutomaticPriceProvider,
  type AutomaticPriceProviderAttempt,
  type AutomaticPriceProviderCandidate,
  type AutomaticPriceProviderExclusion,
  type AutomaticPriceResult,
} from "./automatic-price-provider";
import { createEodhdProvider, resolveEodhdSymbol } from "./eodhd-provider";
import { createMarketstackProvider, resolveMarketstackSymbol } from "./marketstack-provider";
import type { PriceProviderAdapter } from "./price-provider-configuration-core";
import { getPriceProviderRuntimeConfigurations, type PriceProviderRuntimeConfiguration } from "./price-provider-configurations";
import { createTwelveDataProvider, resolveTwelveDataSymbol } from "./twelve-data-provider";

export type AutomaticPriceRefreshMode = "manual" | "scheduled" | "contextual";
export type AutomaticPriceRefreshDetail = {
  assetId: string;
  assetName: string;
  symbol: string | null;
  status: "success" | "error" | "ignored";
  providers: string[];
  attempts: AutomaticPriceProviderAttempt[];
  primaryProvider: string | null;
  sourceName: string | null;
  fallbackUsed: boolean;
  price: string | null;
  currencyCode: string | null;
  observedAt: string | null;
  retrievedAt: string | null;
  persisted: boolean;
  error: string | null;
};
export type AutomaticPriceRefreshSummary = { successes: number; failures: number; ignored: number; persistedPrices: number; provider: string; message: string; details: AutomaticPriceRefreshDetail[] };
type RawAsset = { id: string; name: string; symbol: string | null; isin: string | null; currency_code: string; valuation_mode: string; price_source: string | null; is_active: boolean };
type CapabilityCache = { asset_id: string; provider_slot: number; capability: "eod" | "intraday"; provider_symbol: string | null; status: "supported" | "unsupported" | "quota_limited" | "temporary_failure" | "authentication_failed"; retry_after: string | null; failure_count: number };
type StoredAutomaticPrice = { asset_id: string; price: number | string; currency_code: string; observed_at: string; source_name: string | null };

function sanitizedMessage(summary: Pick<AutomaticPriceRefreshSummary, "successes" | "failures" | "ignored" | "provider">) {
  if (summary.failures && !summary.successes) return summary.provider === "unconfigured"
    ? "Aucun fournisseur de cours n’est configuré. Le dernier prix connu est conservé."
    : "Aucun prix n’a pu être actualisé. Le dernier prix connu est conservé.";
  if (summary.failures) return "Actualisation partielle. Les derniers prix connus sont conservés pour les échecs.";
  if (!summary.successes) return "Aucun actif en cours automatique à actualiser.";
  return "Prix automatiques actualisés.";
}

async function principalId(admin: ReturnType<typeof createAdminClient>) {
  const result = await admin.rpc("get_application_principal_for_service");
  if (result.error || typeof result.data !== "string") throw new Error("AUTOMATIC_PRICE_PRINCIPAL_UNAVAILABLE");
  return result.data;
}

function marketRegion(asset: RawAsset): "us" | "europe" | "global" {
  if (asset.isin?.startsWith("US") || asset.currency_code === "USD") return "us";
  if (asset.currency_code === "EUR" || /^(NL|FR|DE|BE|LU|IE|ES|IT)/.test(asset.isin ?? "")) return "europe";
  return "global";
}

type AutomaticPriceRuntimeAdapter = {
  name: string;
  resolveCapability: (requested: "eod" | "intraday") => "eod" | "intraday";
  supportsCapability: (configuration: PriceProviderRuntimeConfiguration, requested: "eod" | "intraday") => boolean;
  resolveSymbol: (asset: AutomaticPriceAsset) => string | null;
  create: (configuration: PriceProviderRuntimeConfiguration, mode: AutomaticPriceRefreshMode) => AutomaticPriceProvider;
};

const automaticPriceRuntimeAdapters: Record<PriceProviderAdapter, AutomaticPriceRuntimeAdapter> = {
  twelve_data: {
    name: "Twelve Data",
    resolveCapability: (requested) => requested,
    supportsCapability: (configuration, requested) => configuration.capability === "both" || configuration.capability === requested,
    resolveSymbol: resolveTwelveDataSymbol,
    create: (configuration) => createTwelveDataProvider(configuration.apiKey),
  },
  eodhd: {
    name: "EODHD",
    resolveCapability: () => "eod",
    supportsCapability: (configuration) => configuration.capability === "eod" || configuration.capability === "both",
    resolveSymbol: resolveEodhdSymbol,
    create: (configuration, mode) => createEodhdProvider(configuration.apiKey, mode === "scheduled" ? "eod" : "latest"),
  },
  marketstack: {
    name: "Marketstack EOD",
    resolveCapability: () => "eod",
    supportsCapability: (configuration) => configuration.capability === "eod",
    resolveSymbol: resolveMarketstackSymbol,
    create: (configuration) => createMarketstackProvider(configuration.apiKey),
  },
};

function runtimeAdapter(configuration: PriceProviderRuntimeConfiguration) {
  return automaticPriceRuntimeAdapters[configuration.provider];
}

function providerName(configuration: PriceProviderRuntimeConfiguration) {
  return runtimeAdapter(configuration).name;
}

function providerCapability(configuration: PriceProviderRuntimeConfiguration, requested: "eod" | "intraday") {
  return runtimeAdapter(configuration).resolveCapability(requested);
}

function providerSymbol(configuration: PriceProviderRuntimeConfiguration, asset: AutomaticPriceAsset) {
  return runtimeAdapter(configuration).resolveSymbol(asset);
}

function providerExclusion(
  configuration: PriceProviderRuntimeConfiguration,
  asset: AutomaticPriceAsset,
  region: "us" | "europe" | "global",
  capability: "eod" | "intraday",
): AutomaticPriceProviderExclusion | null {
  // Keep the prepared adapter unreachable until instrument coverage and usage rights are established.
  if (configuration.provider === "marketstack") return "qualification_pending";
  if (configuration.region !== "global" && configuration.region !== region) return "incompatible_region";
  if (!runtimeAdapter(configuration).supportsCapability(configuration, capability)) return "incompatible_capability";
  return providerSymbol(configuration, asset) ? null : "incompatible_instrument";
}

function configuredProvider(configuration: PriceProviderRuntimeConfiguration, mode: AutomaticPriceRefreshMode) {
  return runtimeAdapter(configuration).create(configuration, mode);
}

function cacheKey(assetId: string, slot: number, capability: string) { return `${assetId}:${slot}:${capability}`; }
function sameQuote(previous: StoredAutomaticPrice | undefined, result: Extract<AutomaticPriceResult, { status: "success" }>) {
  return Boolean(previous && Number(previous.price) === Number(result.price)
    && previous.currency_code === result.currencyCode
    && Date.parse(previous.observed_at) === Date.parse(result.observedAt)
    && previous.source_name === result.sourceName.trim());
}
function isOlderQuote(previous: StoredAutomaticPrice | undefined, result: Extract<AutomaticPriceResult, { status: "success" }>) {
  return Boolean(previous && Date.parse(result.observedAt) < Date.parse(previous.observed_at));
}
export function shouldReuseAutomaticPriceCapabilityCache(cached: CapabilityCache | undefined, symbol: string | null) {
  return Boolean(cached?.provider_symbol === symbol && cached.retry_after && Date.parse(cached.retry_after) > Date.now());
}

function cachedFailureCode(cached: CapabilityCache) {
  if (cached.status === "quota_limited") return "quota_exceeded" as const;
  if (cached.status === "authentication_failed") return "authentication_failed" as const;
  if (cached.status === "unsupported") return "asset_unavailable" as const;
  return "provider_failed" as const;
}

function sanitizedError(code: string, hasLastValidPrice: boolean) {
  const preservation = hasLastValidPrice
    ? " Le dernier cours valide et son horodatage sont conservés."
    : " Aucun cours valide précédent n’est disponible.";
  if (code === "asset_unavailable") return `Actif indisponible chez les fournisseurs configurés.${preservation}`;
  if (code === "quota_exceeded") return `Quota fournisseur temporairement atteint.${preservation}`;
  if (code === "authentication_failed") return `Authentification du fournisseur refusée.${preservation}`;
  if (code === "access_denied") return `Accès non autorisé à l’endpoint fournisseur.${preservation}`;
  if (code === "timeout") return `Délai de réponse du fournisseur dépassé.${preservation}`;
  if (code === "network_error") return `Erreur réseau pendant l’appel au fournisseur.${preservation}`;
  if (code === "invalid_quote") return `Réponse du fournisseur inexploitable.${preservation}`;
  if (code === "price_unavailable") return `Le fournisseur n’a retourné aucun prix exploitable.${preservation}`;
  if (code === "stale_quote") return `Le cours reçu est antérieur au dernier cours valide.${preservation}`;
  if (code === "provider_unavailable") return `Aucun fournisseur compatible n’est disponible.${preservation}`;
  return `Aucun fournisseur n’a retourné de prix utilisable.${preservation}`;
}

function nextUtcMidnight() {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1)).toISOString();
}

function nextUtcMonth() {
  const now = new Date();
  return new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1)).toISOString();
}

function cacheValues(ownerId: string, asset: AutomaticPriceAsset, providerSymbolValue: string | null, configuration: PriceProviderRuntimeConfiguration, region: "us" | "europe" | "global", capability: "eod" | "intraday", result: AutomaticPriceResult, previous?: CapabilityCache, quotaRetryAfter?: string | null) {
  const success = result.status === "success";
  const failureCount = success ? 0 : Math.min(100, (previous?.failure_count ?? 0) + 1);
  const status = success ? "supported" : result.code === "asset_unavailable" ? "unsupported"
    : result.code === "quota_exceeded" ? "quota_limited"
      : result.code === "authentication_failed" ? "authentication_failed" : "temporary_failure";
  const retryAfter = success ? null : status === "unsupported" ? new Date(Date.now() + 30 * 86_400_000).toISOString()
    : status === "quota_limited" ? (result.status === "error" ? result.retryAfter : undefined) ?? quotaRetryAfter ?? (configuration.provider === "twelve_data" ? new Date(Date.now() + 60_000).toISOString() : configuration.provider === "marketstack" ? nextUtcMonth() : nextUtcMidnight())
      : status === "authentication_failed" ? new Date(Date.now() + 365 * 86_400_000).toISOString()
        : new Date(Date.now() + Math.min(3_600_000, 60_000 * 2 ** Math.min(failureCount, 5))).toISOString();
  return { owner_user_id: ownerId, asset_id: asset.id, provider_slot: configuration.slot, capability, market_region: region, provider_symbol: providerSymbolValue, status, failure_count: failureCount, last_success_at: success ? result.observedAt : null, retry_after: retryAfter, updated_at: new Date().toISOString() };
}

export async function refreshAutomaticAssetPrices(options: { ownerId?: string; assetIds?: string[]; provider?: AutomaticPriceProvider; mode?: AutomaticPriceRefreshMode } = {}): Promise<AutomaticPriceRefreshSummary> {
  const admin = createAdminClient();
  const ownerId = options.ownerId ?? await principalId(admin);
  const mode = options.mode ?? "manual";
  const requestedCapability = mode === "scheduled" ? "eod" : "intraday";
  let query = admin.from("assets").select("id,name,symbol,isin,currency_code,valuation_mode,price_source,is_active").eq("owner_user_id", ownerId);
  if (options.assetIds?.length) query = query.in("id", options.assetIds);
  const assetsResult = await query;
  if (assetsResult.error) throw new Error("AUTOMATIC_PRICE_ASSETS_UNAVAILABLE");
  const assets = (assetsResult.data ?? []) as RawAsset[];
  const eligible = assets.filter((asset) => asset.is_active && asset.valuation_mode === "market_price");
  const configurations = options.provider ? [] : await getPriceProviderRuntimeConfigurations();
  const details: AutomaticPriceRefreshDetail[] = [];
  const caches = new Map<string, CapabilityCache>();
  const latestPrices = new Map<string, StoredAutomaticPrice>();
  if (eligible.length) {
    const existing = await admin.from("asset_prices")
      .select("asset_id,price,currency_code,observed_at,source_name")
      .in("asset_id", eligible.map((asset) => asset.id)).eq("origin", "automatic")
      .order("observed_at", { ascending: false }).order("obtained_at", { ascending: false });
    if (existing.error) throw new Error("AUTOMATIC_PRICE_HISTORY_UNAVAILABLE");
    for (const row of (existing.data ?? []) as StoredAutomaticPrice[]) if (!latestPrices.has(row.asset_id)) latestPrices.set(row.asset_id, row);
  }
  if (!options.provider && eligible.length) {
    const cached = await admin.from("asset_price_provider_capabilities").select("asset_id,provider_slot,capability,provider_symbol,status,retry_after,failure_count").in("asset_id", eligible.map((asset) => asset.id));
    for (const row of (cached.data ?? []) as CapabilityCache[]) caches.set(cacheKey(row.asset_id, row.provider_slot, row.capability), row);
  }
  const orderedAssets = [...assets].sort((left, right) => Number(marketRegion(right) === "europe") - Number(marketRegion(left) === "europe"));
  let successes = 0, failures = 0, ignored = 0, persistedPrices = 0;
  const usedProviders = new Set<string>();
  // Current EUR consolidation needs its own dated FX reference. A native quote
  // remains valid even when FX is temporarily unavailable; never invent a rate.
  const fxDate = parisDateFromIso(new Date().toISOString());
  const fxResolved = new Map<string, boolean>();
  const batchProviderBlocks = new Map<string, AutomaticPriceFailure>();

  for (const row of orderedAssets) {
    if (!row.is_active || row.valuation_mode !== "market_price") {
      ignored += 1;
      details.push({ assetId: row.id, assetName: row.name, symbol: row.symbol, status: "ignored", providers: [], attempts: [], primaryProvider: null, sourceName: null, fallbackUsed: false, price: null, currencyCode: null, observedAt: null, retrievedAt: null, persisted: false, error: "Actif hors valorisation automatique active." });
      continue;
    }
    const asset: AutomaticPriceAsset = { id: row.id, name: row.name, symbol: row.symbol, isin: row.isin, currencyCode: row.currency_code, priceSource: row.price_source };
    let result: AutomaticPriceResult = { status: "error", code: "provider_unavailable" };
    let failureSource = "unconfigured";
    let attempts: AutomaticPriceProviderAttempt[] = [];
    let attemptedProviders: string[] = [];
    let primaryProvider: string | null = null;
    let usedFallback = false;
    if (options.provider) {
      const selection = await selectAutomaticPriceFromProviders([{
        provider: options.provider.name,
        providerSymbol: asset.symbol,
        execute: () => options.provider!.getPrice(asset, { capability: requestedCapability }),
      }]);
      ({ result, attempts, attemptedProviders, primaryProvider, fallbackUsed: usedFallback } = selection);
    } else {
      const region = marketRegion(row);
      const candidates: AutomaticPriceProviderCandidate[] = configurations.map((configuration) => {
        const capability = providerCapability(configuration, requestedCapability);
        const resolvedSymbol = providerSymbol(configuration, asset);
        const exclusion = providerExclusion(configuration, asset, region, requestedCapability);
        const name = providerName(configuration);
        if (exclusion) return { provider: name, slot: configuration.slot, providerSymbol: resolvedSymbol, exclusion };
        return {
          provider: name,
          slot: configuration.slot,
          providerSymbol: resolvedSymbol,
          execute: async () => {
            const key = cacheKey(asset.id, configuration.slot, capability);
            const batchKey = `${configuration.slot}:${capability}`;
            const previous = caches.get(key);
            let quotaRetryAfter: string | null = null;
            let candidateResult: AutomaticPriceResult;
            const batchBlock = batchProviderBlocks.get(batchKey);
            if (batchBlock) candidateResult = batchBlock;
            else if (shouldReuseAutomaticPriceCapabilityCache(previous, resolvedSymbol)) {
              candidateResult = {
                status: "error",
                code: cachedFailureCode(previous!),
                ...(previous?.retry_after ? { retryAfter: previous.retry_after } : {}),
              };
            } else {
              const quota = await admin.rpc("consume_price_provider_quota", { requested_slot: configuration.slot, requested_cost: 1, requested_reserve: configuration.provider === "eodhd" ? 2 : configuration.provider === "marketstack" ? 3 : 0 });
              const quotaRow = Array.isArray(quota.data) ? quota.data[0] : quota.data;
              quotaRetryAfter = typeof quotaRow?.retry_after === "string" ? quotaRow.retry_after : null;
              if (quota.error || !quotaRow?.allowed) {
                candidateResult = { status: "error", code: "quota_exceeded", ...(quotaRetryAfter ? { retryAfter: quotaRetryAfter } : {}) };
              } else {
                const provider = configuredProvider(configuration, mode);
                candidateResult = await provider.getPrice({ ...asset, symbol: resolvedSymbol }, { capability });
              }
            }
            if (candidateResult.status === "success" && !isUsableAutomaticPriceQuote(candidateResult)) candidateResult = { status: "error", code: "invalid_quote" };
            if (candidateResult.status === "success" && isOlderQuote(latestPrices.get(asset.id), candidateResult)) candidateResult = { status: "error", code: "stale_quote" };
            if (candidateResult.status === "error" && (candidateResult.code === "quota_exceeded" || candidateResult.code === "authentication_failed")) {
              batchProviderBlocks.set(batchKey, candidateResult);
            }
            const values = cacheValues(ownerId, asset, resolvedSymbol, configuration, region, capability, candidateResult, previous, quotaRetryAfter);
            await admin.from("asset_price_provider_capabilities").upsert(values, { onConflict: "asset_id,provider_slot,capability" });
            caches.set(key, values as CapabilityCache);
            if (candidateResult.status === "error" && candidateResult.code === "authentication_failed") {
              await admin.rpc("mark_price_provider_configuration_invalid", { requested_slot: configuration.slot });
            }
            return candidateResult;
          },
        };
      });
      const selection = await selectAutomaticPriceFromProviders(candidates);
      ({ result, attempts, attemptedProviders, primaryProvider, fallbackUsed: usedFallback } = selection);
    }
    for (const provider of attemptedProviders) usedProviders.add(provider);
    failureSource = [...attempts].reverse().find((attempt) => attempt.status === "error")?.provider ?? primaryProvider ?? "unconfigured";
    if (result.status === "success" && !isUsableAutomaticPriceQuote(result)) result = { status: "error", code: "invalid_quote" };
    if (result.status === "success") {
      const duplicate = sameQuote(latestPrices.get(asset.id), result);
      const saved = duplicate
        ? await admin.from("asset_price_refresh_status").upsert({ asset_id: asset.id, status: "success", last_attempted_at: new Date().toISOString(), last_succeeded_at: new Date().toISOString(), error_code: null, source_name: result.sourceName, updated_at: new Date().toISOString() }, { onConflict: "asset_id" })
        : await admin.rpc("record_automatic_asset_price", { requested_asset: asset.id, requested_price: result.price, requested_currency: result.currencyCode, requested_observed_at: result.observedAt, requested_source: result.sourceName });
      if (!saved.error) {
        successes += 1;
        if (!duplicate) {
          persistedPrices += 1;
          latestPrices.set(asset.id, { asset_id: asset.id, price: result.price, currency_code: result.currencyCode, observed_at: result.observedAt, source_name: result.sourceName });
        }
        if (result.currencyCode !== "EUR" && !fxResolved.has(result.currencyCode)) {
          const resolution = await resolveFxRate(result.currencyCode, fxDate, { admin }).catch(() => null);
          fxResolved.set(result.currencyCode, resolution?.status === "resolved");
        }
        const conversionUnavailable = fxResolved.get(result.currencyCode) === false;
        details.push({ assetId: asset.id, assetName: asset.name, symbol: asset.symbol, status: "success", providers: attemptedProviders, attempts, primaryProvider, sourceName: result.sourceName, fallbackUsed: usedFallback, price: result.price, currencyCode: result.currencyCode, observedAt: result.observedAt, retrievedAt: new Date().toISOString(), persisted: !duplicate, error: conversionUnavailable ? "Cours enregistré ; conversion EUR temporairement indisponible." : duplicate ? "Cours identique déjà enregistré ; aucun doublon créé." : null });
        continue;
      }
      result = { status: "error", code: "invalid_quote" };
    }
    failures += 1;
    await admin.rpc("record_automatic_asset_price_failure", { requested_asset: asset.id, requested_error_code: result.code, requested_source: failureSource });
    details.push({ assetId: asset.id, assetName: asset.name, symbol: asset.symbol, status: "error", providers: attemptedProviders, attempts, primaryProvider, sourceName: null, fallbackUsed: usedFallback, price: null, currencyCode: null, observedAt: null, retrievedAt: new Date().toISOString(), persisted: false, error: sanitizedError(result.code, latestPrices.has(asset.id)) });
  }
  const configuredProviders = [...new Set(configurations.map(providerName))];
  const provider = options.provider?.name
    ?? (usedProviders.size ? [...usedProviders].join(" → ") : configuredProviders.length ? configuredProviders.join(" → ") : "unconfigured");
  const summary = { successes, failures, ignored, provider };
  const fxWarning = [...fxResolved.values()].includes(false) ? " Certaines conversions EUR restent indisponibles." : "";
  return { ...summary, persistedPrices, message: sanitizedMessage(summary) + fxWarning, details };
}
