import "server-only";
import { createClient } from "@/lib/supabase/server";
import type { ManagedAsset } from "./asset-core";
import { isMissingThemeSchemaError } from "./theme-schema";

export async function getManagedAssets(userId: string): Promise<ManagedAsset[]> {
  const supabase = await createClient();
  const [result, prices, sectors, activities, geographies, themes] = await Promise.all([
    supabase.from("assets")
      .select("id,name,display_name,symbol,isin,asset_type_code,currency_code,valuation_mode,price_source,is_active,color,metadata")
      .eq("owner_user_id", userId).order("name"),
    supabase.from("asset_prices").select("asset_id"),
    supabase.from("asset_sector_exposures").select("asset_id"),
    supabase.from("asset_activity_exposures").select("asset_id"),
    supabase.from("asset_geography_exposures").select("asset_id"),
    supabase.from("asset_theme_exposure_sets").select("asset_id"),
  ]);
  const dependencies = [prices, sectors, activities, geographies];
  if (result.error || dependencies.some(({ error }) => error) || (themes.error && !isMissingThemeSchemaError(themes.error))) {
    throw new Error("Assets unavailable");
  }
  if (!themes.error) dependencies.push(themes);
  const dependentIds = new Set(dependencies.flatMap(({ data }) => data?.map(({ asset_id }) => asset_id) ?? []));
  if (!result.data.length) return [];
  const usage = await supabase.rpc("get_asset_usage", { requested_assets: result.data.map((row) => row.id) });
  if (usage.error) throw new Error("Asset usage unavailable");
  const used = new Map((usage.data ?? []).map((row: { asset_id: string; is_used: boolean }) => [row.asset_id, row.is_used]));
  return result.data.map((row) => {
    if (!used.has(row.id)) throw new Error("Asset usage unavailable");
    const {metadata,...view}=row;
    return { ...view, hasDependencies: Boolean(metadata?.geographic_location) || used.get(row.id) === true || dependentIds.has(row.id) };
  });
}
