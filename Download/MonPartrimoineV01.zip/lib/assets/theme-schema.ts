const THEME_SCHEMA_RELATIONS = ["themes", "asset_theme_exposure_sets", "asset_theme_exposures"];

export class ThemeSchemaUnavailableError extends Error {
  constructor() {
    super("Phase 7.6 theme schema unavailable");
    this.name = "ThemeSchemaUnavailableError";
  }
}

export function isMissingThemeSchemaError(error: { code?: string; message?: string } | null | undefined) {
  if (!error || (error.code !== "PGRST205" && error.code !== "42P01")) return false;
  return THEME_SCHEMA_RELATIONS.some((relation) => error.message?.includes(relation));
}
