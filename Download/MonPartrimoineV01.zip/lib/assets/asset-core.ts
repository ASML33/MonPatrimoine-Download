export type AssetActionState = {
  status: "idle" | "success" | "error";
  message?: string;
};

export type ManagedAsset = {
  id: string;
  name: string;
  display_name: string | null;
  symbol: string | null;
  isin: string | null;
  asset_type_code: string;
  currency_code: string;
  valuation_mode: ValuationMode;
  price_source: string | null;
  is_active: boolean;
  color: string | null;
  hasDependencies: boolean;
};

export const ASSET_CLASS_OPTIONS = [
  ["stock", "Action"],
  ["etf", "ETF"],
  ["fund", "Fonds"],
  ["bond", "Obligation"],
  ["real_estate", "Immobilier"],
  ["other", "Autre"],
] as const;

export const VALUATION_MODE_OPTIONS = [
  ["market_price", "Cours de marché"],
  ["manual", "Valeur manuelle"],
  ["not_applicable", "Non applicable"],
] as const;

export type ValuationMode = (typeof VALUATION_MODE_OPTIONS)[number][0];

const QUOTED_ASSET_TYPES = new Set(["stock", "etf", "fund", "bond"]);

export function isContextualAutomaticPriceCandidate(assetTypeCode: string, valuationMode: string) {
  return valuationMode === "market_price" && QUOTED_ASSET_TYPES.has(assetTypeCode);
}

const ASSET_CODE_PATTERN = /^[a-z0-9_-]{1,50}$/;
const ISIN_PATTERN = /^[A-Z0-9]{12}$/;
const CURRENCY_PATTERN = /^[A-Z]{3}$/;
const COLOR_PATTERN = /^#[0-9A-F]{6}$/i;

export const isUuid = (value: string) =>
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);

function value(form: FormData, key: string) {
  return String(form.get(key) ?? "").trim();
}

export function validateAssetForm(form: FormData) {
  const name = value(form, "name");
  const display_name = value(form, "display_name") || null;
  const symbol = value(form, "symbol").toUpperCase() || null;
  const isin = value(form, "isin").toUpperCase() || null;
  const asset_type_code = value(form, "asset_type_code").toLowerCase();
  const currency_code = value(form, "currency_code").toUpperCase();
  const valuation_mode = value(form, "valuation_mode") as ValuationMode;
  const price_source = value(form, "price_source") || null;
  const colorValue = value(form, "color").toUpperCase();
  const color = colorValue || null;

  if (!name || [...name].length > 200) {
    throw new Error("Le nom de l’actif est obligatoire et limité à 200 caractères.");
  }
  if (display_name && [...display_name].length > 120) throw new Error("Le nom d’affichage est limité à 120 caractères.");
  if (isin && !ISIN_PATTERN.test(isin)) {
    throw new Error("L’ISIN doit comporter exactement 12 caractères alphanumériques.");
  }
  if (!ASSET_CODE_PATTERN.test(asset_type_code) || asset_type_code === "cash") {
    throw new Error("Choisissez une classe d’actif valide. Les liquidités sont gérées séparément.");
  }
  if (!CURRENCY_PATTERN.test(currency_code)) {
    throw new Error("La devise doit comporter trois lettres, par exemple EUR.");
  }
  if (!VALUATION_MODE_OPTIONS.some(([code]) => code === valuation_mode)) {
    throw new Error("Choisissez un mode de valorisation valide.");
  }
  if(asset_type_code==="real_estate"&&valuation_mode!=="manual")throw new Error("Un bien immobilier utilise une estimation totale manuelle depuis son contrat.");
  if (color && !COLOR_PATTERN.test(color)) {
    throw new Error("La couleur doit respecter le format #RRGGBB.");
  }

  return {
    name,
    display_name,
    symbol,
    isin,
    asset_type_code,
    currency_code,
    valuation_mode,
    price_source,
    color,
  };
}

export function assetClassLabel(code: string) {
  return ASSET_CLASS_OPTIONS.find(([value]) => value === code)?.[1] ?? code;
}

export function valuationModeLabel(mode: ValuationMode) {
  return VALUATION_MODE_OPTIONS.find(([value]) => value === mode)?.[1] ?? mode;
}

export function assetError(code?: string) {
  if (code === "23503") return "Cet actif possède des données liées. Vous pouvez le désactiver.";
  if (code === "23505") return "Un actif utilise déjà cet ISIN ou ce symbole.";
  if (code === "23514") return "Modification refusée : un actif utilisé conserve son identité structurelle.";
  if (code === "42501") return "Cette opération ou cet actif n’est pas accessible.";
  if (code === "40001" || code === "40P01") return "Une modification simultanée a eu lieu. Rechargez la page puis réessayez.";
  return "Enregistrement impossible. Rechargez la page puis réessayez.";
}
