import { createHash, randomBytes } from "node:crypto";
import { spawn } from "node:child_process";
import {
  access, lstat, readFile, rename, rm, writeFile,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createInterface } from "node:readline/promises";
import { Writable } from "node:stream";

const root = fileURLToPath(new URL("../../", import.meta.url));
const stateName = ".monpatrimoine-install.json";
const manifestName = "monpatrimoine-package.json";
const statePath = join(root, stateName);
const vercelLinkPath = join(root, ".vercel", "project.json");
const vercelVersion = "66.4.0";
const refPattern = /^[a-z0-9]{20}$/;
const loginPattern = /^[a-z0-9][a-z0-9-]{0,38}$/i;
const scopePattern = /^[a-z0-9][a-z0-9_-]{0,99}$/i;
const slugPattern = /^monpatrimoine-[a-f0-9]{12}$/;
const digestPattern = /^[a-f0-9]{64}$/;
const commitPattern = /^[a-f0-9]{40}$/;
const databaseIdPattern = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
const versionPattern = /^(0|[1-9][0-9]{0,8})\.(0|[1-9][0-9]{0,8})\.(0|[1-9][0-9]{0,8})$/;
const yes = "OUI";

class SetupError extends Error {}

function ensure(condition, message) {
  if (!condition) throw new SetupError(message);
}

function section(message) {
  console.log("\n" + message);
}

function digest(bytes) {
  return createHash("sha256").update(bytes).digest("hex");
}

async function exists(path) {
  try {
    await access(path);
    return true;
  } catch (error) {
    if (error.code === "ENOENT") return false;
    throw error;
  }
}

async function loadJson(path) {
  ensure((await lstat(path)).isFile(), "Le chemin demandé doit être un fichier normal.");
  try {
    return JSON.parse(await readFile(path, "utf8"));
  } catch {
    throw new SetupError("Un fichier JSON de l’installation est illisible.");
  }
}

async function saveState(state) {
  const temporary = statePath + ".tmp";
  await writeFile(temporary, JSON.stringify(state, null, 2) + "\n", {
    encoding: "utf8", mode: 0o600, flag: "wx",
  });
  try {
    await rename(temporary, statePath);
  } catch (error) {
    await rm(temporary, { force: true });
    throw error;
  }
}

async function lockInstallation() {
  const lock = join(tmpdir(), "monpatrimoine-install-" + digest(resolve(root).toLowerCase()).slice(0, 20) + ".lock");
  const processId = String(process.pid);
  const take = () => writeFile(lock, processId, { flag: "wx", mode: 0o600 });
  try {
    await take();
  } catch (error) {
    if (error.code !== "EEXIST") throw error;
    ensure((await lstat(lock)).isFile(), "Le verrou local de cette installation est invalide.");
    const old = (await readFile(lock, "utf8")).trim();
    ensure(/^[1-9][0-9]{0,9}$/.test(old), "Le verrou local de cette installation est illisible.");
    let running = true;
    try {
      process.kill(Number(old), 0);
    } catch (probe) {
      if (probe.code === "ESRCH") running = false;
    }
    ensure(!running, "Une autre fenêtre utilise déjà ce dossier d’installation.");
    // Two recovery attempts may race. The exclusive creation below still allows only one.
    if ((await readFile(lock, "utf8")).trim() === old) await rm(lock);
    await take();
  }
  return async () => {
    if ((await readFile(lock, "utf8").catch(() => "")).trim() === processId) await rm(lock);
  };
}

function question(label, { secret = false } = {}) {
  ensure(process.stdin.isTTY && process.stdout.isTTY, "Lancez le programme depuis une fenêtre de terminal interactive.");
  if (secret) process.stdout.write(label + " (saisie masquée) ");
  const muted = secret ? new Writable({ write(_chunk, _encoding, done) { done(); } }) : null;
  if (muted) muted.isTTY = true;
  const input = createInterface({
    input: process.stdin, output: muted ?? process.stdout, terminal: true,
  });
  const abort = new AbortController();
  input.on("SIGINT", () => abort.abort());
  input.on("close", () => abort.abort());
  return input.question(secret ? "" : label + " ", { signal: abort.signal }).catch(() => {
    throw new SetupError("Installation interrompue.");
  }).finally(() => {
    input.close();
    if (secret) process.stdout.write("\n");
  });
}

async function confirm(label) {
  ensure((await question(label + " Tapez OUI pour continuer.")).trim().toUpperCase() === yes,
    "Installation interrompue avant l’étape demandée.");
}

function childEnvironment() {
  const environment = {};
  for (const [key, value] of Object.entries(process.env)) {
    if (/^(?:GH_|GITHUB_|GIT_|VERCEL_|SUPABASE_|PG|NEXT_PUBLIC_|NODE_OPTIONS$|NODE_TLS_REJECT_UNAUTHORIZED$|CI$)/i.test(key)) continue;
    environment[key] = value;
  }
  environment.GIT_CONFIG_NOSYSTEM = "1";
  environment.GIT_TERMINAL_PROMPT = "0";
  environment.VERCEL_TELEMETRY_DISABLED = "1";
  environment.DO_NOT_TRACK = "1";
  return environment;
}

async function execute(command, args, { input, interactive = false, cwd = root, sensitive = false } = {}) {
  return new Promise((resolveResult, reject) => {
    const child = spawn(command, args, {
      cwd, env: childEnvironment(), shell: false, windowsHide: true,
      stdio: interactive ? "inherit" : [input === undefined ? "ignore" : "pipe", "pipe", "pipe"],
    });
    let stdout = "";
    let stderr = "";
    if (!interactive) {
      child.stdout.setEncoding("utf8").on("data", chunk => { stdout = (stdout + chunk).slice(-512_000); });
      child.stderr.setEncoding("utf8").on("data", chunk => { stderr = (stderr + chunk).slice(-512_000); });
      if (input !== undefined) {
        child.stdin.on("error", error => {
          if (error.code !== "EPIPE") reject(new SetupError("La commande n’a pas accepté son entrée."));
        });
        child.stdin.end(input, "utf8");
      }
    }
    child.on("error", error => reject(new SetupError(error.code === "ENOENT"
      ? "Commande introuvable. Installez le prérequis indiqué dans le guide."
      : "Impossible de lancer une commande de l’installateur.")));
    child.on("close", code => resolveResult({ code, stdout: sensitive ? "" : stdout, stderr: sensitive ? "" : stderr }));
  });
}

async function checked(command, args, message, options) {
  const result = await execute(command, args, options);
  ensure(result.code === 0, message);
  return result.stdout.trim();
}

function git(args, message, options) {
  return checked("git", args, message, options);
}

function gh(args, message, options) {
  return checked("gh", args, message, options);
}

async function npm(args, message, options) {
  const npmScript = join(dirname(process.execPath), "node_modules", "npm", "bin", "npm-cli.js");
  return process.platform === "win32"
    ? (ensure(await exists(npmScript), "npm est introuvable. Installez Node.js depuis https://nodejs.org/"), checked(process.execPath, [npmScript, ...args], message, options))
    : checked("npm", args, message, options);
}

const vercelArgs = ["exec", "--yes", "--registry=https://registry.npmjs.org", "--package=vercel@" + vercelVersion, "--", "vercel"];
function vercel(args, message, options) {
  return npm([...vercelArgs, ...args], message, options);
}

function parseDatabaseUrl(input) {
  let url;
  try {
    url = new URL(input.trim());
  } catch {
    throw new SetupError("Le lien PostgreSQL est invalide. Copiez l’URI « Session pooler » depuis Connect dans Supabase.");
  }
  const direct = url.username === "postgres" ? url.hostname.match(/^db\.([a-z0-9]{20})\.supabase\.co$/) : null;
  const session = /^(?:[a-z0-9-]+\.)?pooler\.supabase\.com$/.test(url.hostname)
    ? url.username.match(/^postgres\.([a-z0-9]{20})$/) : null;
  ensure(["postgres:", "postgresql:"].includes(url.protocol)
    && (direct || session) && (!url.port || url.port === "5432")
    && url.pathname === "/postgres" && !url.hash,
  "La connexion doit viser le projet Supabase indiqué et utiliser le mode Session, port 5432.");
  return { url, ref: (direct ?? session)[1] };
}

export function makeDatabaseUrl(projectRef, input, password) {
  const { url, ref } = parseDatabaseUrl(input);
  ensure(ref === projectRef, "Cette connexion PostgreSQL appartient à un autre projet Supabase.");
  const placeholders = ["", "[YOUR-PASSWORD]", "[YOUR-DATABASE-PASSWORD]", "YOUR_PASSWORD", "YOUR-PASSWORD"];
  let existing;
  try {
    existing = decodeURIComponent(url.password);
  } catch {
    throw new SetupError("Le mot de passe dans l’URI PostgreSQL est mal encodé.");
  }
  if (password !== undefined && password.length > 0) {
    // URL.password preserves literal percent escapes. Encode user input exactly once.
    url.password = encodeURIComponent(password);
  } else {
    ensure(!placeholders.includes(existing), "Saisissez le mot de passe de la base Supabase.");
  }
  url.search = "";
  return url.toString();
}

function checkSupabaseKey(value, projectRef, role) {
  const prefix = role === "anon" ? "sb_publishable_" : "sb_secret_";
  if (value.startsWith(prefix) && /^[A-Za-z0-9_-]{18,250}$/.test(value)) return;
  const parts = value.split(".");
  if (parts.length === 3 && parts.every(part => /^[A-Za-z0-9_-]+$/.test(part))) {
    try {
      const claims = JSON.parse(Buffer.from(parts[1], "base64url").toString("utf8"));
      if (claims.ref === projectRef && claims.role === role) return;
    } catch {
      // Report the expected key type below without echoing any entered value.
    }
  }
  throw new SetupError(role === "anon"
    ? "La clé publique Supabase n’est pas valide pour ce projet. Utilisez la clé Publishable."
    : "La clé serveur Supabase n’est pas valide pour ce projet. Utilisez la clé Secret.");
}

async function databaseInput(projectRef, initial, connectionUri) {
  section("Supabase | Copier les informations du projet");
  console.log("Ouvrez https://supabase.com/dashboard/project/" + projectRef);
  console.log("API Keys fournit les clés de ce projet.");
  const publishableKey = initial ? (await question("Clé Publishable Supabase", { secret: true })).trim() : undefined;
  if (initial) checkSupabaseKey(publishableKey, projectRef, "anon");
  const secretKey = (await question("Clé Secret Supabase", { secret: true })).trim();
  checkSupabaseKey(secretKey, projectRef, "service_role");
  const databaseUrl = makeDatabaseUrl(projectRef, await connectionUri(),
    await question("Mot de passe de la base Supabase", { secret: true }));
  const certPath = (await question("Chemin du certificat Supabase si nécessaire [Entrée sans certificat personnalisé]")).trim();
  const input = {
    projectUrl: "https://" + projectRef + ".supabase.co", publishableKey, secretKey, databaseUrl,
    migrationsDir: join(root, "supabase", "migrations"),
    onProgress: ({ phase, version }) => {
      if (phase === "migration" && /^[0-9]{14}$/.test(version ?? "")) console.log("  Migration " + version);
    },
  };
  if (certPath) {
    const certificate = await readFile(resolve(certPath.replace(/^"([^"]+)"$/, "$1")), "utf8");
    ensure(certificate.length < 65536 && certificate.includes("-----BEGIN CERTIFICATE-----")
      && !certificate.includes("PRIVATE KEY"), "Sélectionnez le certificat public téléchargé dans Database Settings.");
    input.databaseCa = certificate;
  }
  if (initial) {
    section("MonPatrimoine | Créer votre premier accès");
    input.ownerEmail = (await question("E-mail de connexion")).trim().toLowerCase();
    input.ownerNickname = (await question("Surnom, 3 à 40 caractères")).trim();
    input.ownerPassword = await question("Mot de passe de connexion, au moins 12 caractères", { secret: true });
    const repeated = await question("Confirmez le mot de passe", { secret: true });
    ensure(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.ownerEmail) && input.ownerEmail.length <= 254
      && input.ownerNickname.length >= 3 && input.ownerNickname.length <= 40
      && input.ownerPassword.length >= 12 && input.ownerPassword.length <= 72 && input.ownerPassword === repeated,
    "Vérifiez l’e-mail, le surnom et les deux saisies du mot de passe.");
  }
  return input;
}

export function validateUpdate(previous, next) {
  const version = value => {
    ensure(typeof value === "string" && versionPattern.test(value), "La version du ZIP n’est pas valide.");
    return value.split(".").map(Number);
  };
  const current = version(previous.version);
  const offered = version(next.version);
  const difference = offered.map((part, index) => part - current[index]).find(part => part !== 0);
  ensure(difference > 0, "La mise à jour doit avoir une version supérieure à celle déjà installée.");
  ensure(previous.migrations.length <= next.migrations.length && previous.migrations.every((migration, index) =>
    migration.version === next.migrations[index].version && migration.sha256 === next.migrations[index].sha256),
  "Une migration déjà publiée manque ou a changé. Préparez un ZIP conservant l’historique SQL.");
}

function validateState(state) {
  ensure(state && state.schema === 1 && state.product === "MonPatrimoine"
    && slugPattern.test(state.slug) && refPattern.test(state.projectRef)
    && loginPattern.test(state.githubLogin) && scopePattern.test(state.vercelLogin)
    && scopePattern.test(state.vercelScope) && digestPattern.test(state.packageDigest)
    && ["full", "update"].includes(state.kind), "Le fichier d’état ne décrit pas une installation valide.");
  if (state.githubId !== undefined) ensure(/^R_[A-Za-z0-9_-]+$/.test(state.githubId) || /^MDEwOlJlcG9zaXRvcnk[A-Za-z0-9+/=]+$/.test(state.githubId),
    "L’identifiant du dépôt GitHub enregistré est invalide.");
  if (state.vercelProjectId !== undefined) ensure(/^prj_[A-Za-z0-9]+$/.test(state.vercelProjectId)
    && /^(?:team_|user_)?[A-Za-z0-9]+$/.test(state.vercelOrgId), "Le projet Vercel enregistré est invalide.");
  for (const head of [state.previousHead, state.gitHead]) {
    if (head !== undefined) ensure(commitPattern.test(head), "La révision Git enregistrée est invalide.");
  }
  if (state.ownerId !== undefined) ensure(databaseIdPattern.test(state.ownerId), "Le compte propriétaire enregistré est invalide.");
  if (state.deployment !== undefined) deploymentUrl(state.deployment);
  if (state.installed) {
    ensure(state.githubId && state.gitHead && state.vercelProjectId && state.ownerId && state.deployment
      && versionPattern.test(state.version) && Array.isArray(state.migrations)
      && state.migrations.every(m => m && /^[0-9]{14}$/.test(m.version) && digestPattern.test(m.sha256)),
    "Le fichier d’état indique une installation terminée incomplète.");
  }
  return state;
}

function projectHome(state) {
  return "https://" + state.slug + ".vercel.app";
}

function repositoryName(state) {
  return state.githubLogin + "/" + state.slug;
}

function repositoryUrl(state) {
  return "https://github.com/" + repositoryName(state) + ".git";
}

async function githubIdentity() {
  const args = ["api", "--hostname", "github.com", "user", "--jq", '[.login, (.id | tostring)] | @tsv'];
  let result = await execute("gh", args);
  if (result.code !== 0) {
    section("GitHub | Connexion à votre compte");
    await gh(["auth", "login", "--hostname", "github.com", "--web", "--git-protocol", "https"],
      "Connexion GitHub interrompue.", { interactive: true });
    result = await execute("gh", args);
  }
  const [login, id] = result.stdout.trim().split("\t");
  ensure(result.code === 0 && loginPattern.test(login ?? "") && /^[1-9][0-9]{0,20}$/.test(id ?? ""),
    "Impossible de vérifier le compte GitHub actif. Vérifiez gh auth status dans un terminal.");
  return { login, email: id + "+" + login + "@users.noreply.github.com" };
}

async function vercelIdentity() {
  const args = ["api", "/v2/user", "--raw", "--no-color"];
  let raw;
  try {
    raw = await vercel(args, "Connexion Vercel à effectuer.");
  } catch {
    section("Vercel | Connexion à votre compte");
    await vercel(["login"], "Connexion Vercel interrompue.", { interactive: true });
    raw = await vercel(args, "Impossible de vérifier le compte Vercel actif.");
  }
  let login;
  try { login = JSON.parse(raw)?.user?.username; } catch {
    throw new SetupError("Le compte Vercel actif est illisible.");
  }
  ensure(typeof login === "string" && scopePattern.test(login), "Le compte Vercel actif est illisible.");
  return login;
}

export function parseVercelScope(value) {
  const raw = value.trim();
  const dashboard = raw.match(/^https:\/\/vercel\.com\/([a-z0-9][a-z0-9_-]{0,99})(?:[/?#]|$)/i);
  const scope = dashboard?.[1] ?? raw;
  ensure(scopePattern.test(scope) && !["dashboard", "account", "login", "signup"].includes(scope.toLowerCase()),
    "Indiquez l’adresse du tableau de bord de votre équipe Vercel, par exemple https://vercel.com/demo-s-projects.");
  return scope;
}

async function loadPrevious() {
  const raw = (await question("Chemin du fichier " + stateName + " de l’installation précédente")).trim();
  ensure(raw.length > 0, "Indiquez le fichier d’état de l’installation déjà déployée.");
  const requested = resolve(raw.replace(/^"([^"]+)"$/, "$1"));
  const path = (await lstat(requested)).isDirectory() ? join(requested, stateName) : requested;
  ensure(resolve(path) !== statePath, "La mise à jour doit être extraite dans un nouveau dossier.");
  const previous = validateState(await loadJson(path));
  ensure(previous.installed, "L’installation précédente doit être terminée.");
  return previous;
}

async function prepareState(manifest, packageDigest, github, vercelLogin, connectionUri) {
  if (await exists(statePath)) {
    const saved = validateState(await loadJson(statePath));
    ensure(saved.packageDigest === packageDigest && saved.kind === manifest.kind,
      "Le fichier d’état appartient à un autre contenu. Extrayez le ZIP dans un nouveau dossier.");
    ensure(saved.githubLogin.toLowerCase() === github.login.toLowerCase() && saved.vercelLogin === vercelLogin,
      "Le compte actif n’est pas celui enregistré. Reconnectez le compte qui a commencé cette installation.");
    return saved;
  }
  ensure(!await exists(join(root, ".git")) && !await exists(join(root, ".vercel")),
    "Ce dossier est déjà associé à Git ou Vercel. Extrayez le ZIP dans un nouveau dossier.");
  if (manifest.kind === "update") {
    const previous = await loadPrevious();
    validateUpdate(previous, manifest);
    ensure(previous.githubLogin.toLowerCase() === github.login.toLowerCase()
      && previous.vercelLogin === vercelLogin, "Connectez les comptes GitHub et Vercel de l’installation existante.");
    await confirm("Mettre à jour l’instance " + projectHome(previous) + " avec Supabase " + previous.projectRef + " ?");
    const state = {
      schema: 1, product: "MonPatrimoine", kind: manifest.kind, packageDigest,
      slug: previous.slug, projectRef: previous.projectRef,
      githubLogin: previous.githubLogin, githubId: previous.githubId, previousHead: previous.gitHead,
      vercelLogin: previous.vercelLogin, vercelScope: previous.vercelScope, vercelCreated: true,
      vercelProjectId: previous.vercelProjectId, vercelOrgId: previous.vercelOrgId, ownerId: previous.ownerId,
    };
    await saveState(state);
    return state;
  }
  const slug = "monpatrimoine-" + randomBytes(6).toString("hex");
  section("Créer une instance indépendante");
  console.log("Créez un nouveau projet dans https://supabase.com/dashboard et vérifiez son forfait.");
  const { ref: projectRef } = parseDatabaseUrl(await connectionUri());
  console.log("Dans Vercel, ouvrez le tableau de bord de votre équipe (souvent <pseudo>-s-projects pour un compte personnel).");
  const vercelScope = parseVercelScope(await question("Adresse du tableau de bord Vercel ou identifiant de l’équipe"));
  console.log("Dépôt GitHub privé : " + github.login + "/" + slug);
  console.log("Projet Vercel à créer : " + vercelScope + "/" + slug);
  await confirm("Supabase " + projectRef + " est bien le nouveau projet réservé à cette installation ?");
  const state = {
    schema: 1, product: "MonPatrimoine", kind: manifest.kind, packageDigest,
    slug, projectRef, githubLogin: github.login, vercelLogin, vercelScope,
  };
  await saveState(state);
  return state;
}

const credentialHelper = ["-c", "credential.helper=", "-c", "credential.helper=!gh auth git-credential"];

async function verifyGithubRepository(state) {
  const name = repositoryName(state);
  const raw = await gh(["repo", "view", name, "--json", "id,isPrivate,nameWithOwner,url"],
    "Impossible de vérifier le dépôt privé GitHub " + name + ".");
  let repo;
  try { repo = JSON.parse(raw); } catch { throw new SetupError("La réponse GitHub est illisible."); }
  ensure(repo.isPrivate === true && repo.nameWithOwner.toLowerCase() === name.toLowerCase()
    && repo.url.toLowerCase() === repositoryUrl(state).slice(0, -4).toLowerCase(),
  "Le dépôt GitHub est différent de la cible privée attendue.");
  if (state.githubId) ensure(state.githubId === repo.id, "L’identifiant du dépôt GitHub a changé.");
  return repo.id;
}

async function remoteHead() {
  const output = await git([...credentialHelper, "ls-remote", "--heads", "origin", "refs/heads/main"],
    "Impossible de lire la branche principale du dépôt GitHub privé.");
  if (!output) return undefined;
  const match = output.match(/^([a-f0-9]{40})\s+refs\/heads\/main$/);
  ensure(match, "GitHub a répondu avec une branche inattendue.");
  return match[1];
}

async function recoverGitCommit(state, manifest, head) {
  const parents = await git(["rev-list", "--parents", "-n", "1", head], "Impossible de vérifier la révision préparée.");
  const actual = await git(["ls-tree", "-r", "--name-only", "-z", head], "Impossible de lire les fichiers préparés.");
  const expected = new Set([...Object.keys(manifest.files), manifestName]);
  const tracked = actual.split("\0").filter(Boolean);
  const sameFiles = tracked.length === expected.size && tracked.every(file => expected.has(file));
  const sameContents = await execute("git", ["diff", "--quiet", head, "--"]);
  ensure(parents === [head, state.previousHead].filter(Boolean).join(" ") && sameFiles && sameContents.code === 0,
    "La révision Git locale diffère de celle prévue par ce ZIP.");
  state.gitHead = head;
  await saveState(state);
}

async function prepareGit(state, manifest, identity) {
  const name = repositoryName(state);
  if (!state.githubId) {
    await gh(["repo", "create", name, "--private"], "La création du dépôt privé GitHub a échoué.");
    state.githubId = await verifyGithubRepository(state);
    await saveState(state);
  } else {
    await verifyGithubRepository(state);
  }
  if (!await exists(join(root, ".git"))) {
    await git(["init", "--initial-branch=main"], "Impossible d’initialiser le dépôt local.");
  }
  const remotes = await git(["remote"], "Impossible de lire les associations du dépôt local.");
  if (!remotes && !state.gitHead) {
    await git(["remote", "add", "origin", repositoryUrl(state)], "Impossible de configurer le dépôt GitHub.");
  }
  const url = await git(["remote", "get-url", "origin"], "L’adresse du dépôt distant est manquante.");
  ensure(url.toLowerCase() === repositoryUrl(state).toLowerCase(), "Le dossier Git local est lié à un autre dépôt.");
  const branch = await git(["symbolic-ref", "--short", "HEAD"], "Le dossier Git local doit être sur main.");
  ensure(branch === "main", "Le dossier Git local doit être sur main.");
  const recorded = await remoteHead();
  ensure(!recorded ? !state.previousHead : recorded === state.previousHead || recorded === state.gitHead,
    "La branche GitHub a évolué depuis l’installation. Elle a été préservée.");
  if (state.gitHead) {
    ensure(await git(["rev-parse", "HEAD"], "La révision locale attendue est absente.") === state.gitHead,
      "La révision Git locale a changé depuis la préparation.");
    return;
  }
  const previous = await execute("git", ["rev-parse", "--verify", "HEAD"]);
  if (previous.code === 0 && previous.stdout.trim() !== state.previousHead) {
    await recoverGitCommit(state, manifest, previous.stdout.trim());
    return;
  }
  if (state.previousHead) {
    if (previous.code !== 0) {
      await git([...credentialHelper, "fetch", "--no-tags", "origin", "refs/heads/main:refs/remotes/origin/main"],
        "Impossible de récupérer la révision précédente.");
      const fetched = await git(["rev-parse", "refs/remotes/origin/main"], "Révision précédente introuvable.");
      ensure(fetched === state.previousHead, "La branche GitHub a avancé pendant sa récupération.");
      await git(["reset", "--mixed", state.previousHead], "Impossible de préparer le nouvel arbre à partir de la révision précédente.");
    }
  }

  const files = new Set([...Object.keys(manifest.files), manifestName]);
  if (state.previousHead) {
    const tracked = await git(["ls-tree", "-r", "--name-only", "-z", state.previousHead], "Impossible de lire les fichiers de la version précédente.");
    for (const file of tracked.split("\0").filter(Boolean)) files.add(file);
  }
  await git(["--literal-pathspecs", "add", "-A", "--pathspec-from-file=-", "--pathspec-file-nul"],
    "Impossible de préparer les fichiers du ZIP pour Git.", { input: [...files].join("\0") + "\0" });
  const staged = await git(["diff", "--cached", "--name-only", "-z"], "Impossible de vérifier les fichiers préparés.");
  ensure(staged && staged.split("\0").filter(Boolean).every(file => files.has(file)),
    "Aucun changement à publier, ou des fichiers hors ZIP sont présents dans l’index Git.");
  await git(["-c", "user.name=" + identity.login, "-c", "user.email=" + identity.email, "-c", "commit.gpgSign=false",
    "commit", "-m", "MonPatrimoine " + manifest.version],
  "Impossible de créer la révision Git de cette version.");
  state.gitHead = await git(["rev-parse", "HEAD"], "Impossible de lire la nouvelle révision Git.");
  await saveState(state);
}

async function publishGit(state) {
  await verifyGithubRepository(state);
  const existing = await remoteHead();
  if (existing !== state.gitHead) {
    ensure(existing === state.previousHead, "La branche GitHub a changé. Le dépôt a été préservé.");
    await git([...credentialHelper, "push", "origin", "HEAD:refs/heads/main"], "La publication GitHub a échoué.");
  }
  ensure(await remoteHead() === state.gitHead, "La nouvelle révision n’a pas été confirmée sur GitHub.");
}

function vercelScope(state) {
  return ["--scope", state.vercelScope, "--no-color"];
}

function vercelTarget(state) {
  return [...vercelScope(state), "--project", state.vercelProjectId];
}

async function prepareVercel(state) {
  if (!state.vercelCreated) {
    ensure(!await exists(vercelLinkPath), "Ce dossier est déjà lié à un projet Vercel.");
    await vercel(["project", "create", state.slug, ...vercelScope(state)],
      "Impossible de créer le nouveau projet Vercel. Contrôlez le compte et le nom " + state.slug + " dans Vercel.");
    state.vercelCreated = true;
    await saveState(state);
  }
  if (!await exists(vercelLinkPath)) {
    await vercel(["link", "--yes", "--project", state.vercelProjectId ?? state.slug, ...vercelScope(state)],
      "Impossible d’associer le nouveau dossier au projet Vercel prévu.");
  }
  const link = await loadJson(vercelLinkPath);
  ensure(/^prj_[A-Za-z0-9]+$/.test(link.projectId ?? "") && /^(?:team_|user_)?[A-Za-z0-9]+$/.test(link.orgId ?? ""),
    "L’association Vercel renvoie un identifiant inattendu.");
  if (state.vercelProjectId) {
    ensure(link.projectId === state.vercelProjectId && link.orgId === state.vercelOrgId,
      "Le dossier est lié à une autre instance Vercel.");
  } else {
    ensure(link.projectName === state.slug, "Le dossier est lié à un projet Vercel inattendu.");
    state.vercelProjectId = link.projectId;
    state.vercelOrgId = link.orgId;
    await saveState(state);
  }
}

async function checkAuthConfiguration(input) {
  section("Supabase | Authentification");
  console.log("Dans Authentication → Sign In / Providers, gardez Email activé.");
  console.log("Désactivez les inscriptions publiques et les connexions anonymes, puis enregistrez.");
  await question("Appuyez sur Entrée après l’enregistrement.");
  let config;
  try {
    const response = await fetch(input.projectUrl + "/auth/v1/settings", {
      headers: { apikey: input.publishableKey }, signal: AbortSignal.timeout(10000), redirect: "error",
    });
    if (response.ok) config = await response.json();
  } catch {
    throw new SetupError("Impossible de vérifier les réglages Auth de ce projet Supabase.");
  }
  ensure(config?.disable_signup === true && config?.external?.email === true && config.external.anonymous_users !== true,
    "Vérifiez dans Supabase que les inscriptions publiques et anonymes sont désactivées et Email activé, puis relancez.");
}

async function provisionVercelEnvironment(state, input) {
  const publicEnvironment = {
    NEXT_PUBLIC_SUPABASE_URL: input.projectUrl,
    NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY: input.publishableKey,
    NEXT_PUBLIC_SITE_URL: projectHome(state),
    GOOGLE_DRIVE_OAUTH_ORIGIN: projectHome(state),
    PATRIMONY_EXCLUDED_CONTRACT_ID: "none",
    APPLICATION_BACKUP_ENABLED: "false",
    APPLICATION_BACKUP_AUTOMATION_ENABLED: "false",
    XLSX_FINANCIAL_SEED_ENABLED: "false",
    XLSX_FINANCIAL_MANUAL_ENABLED: "false",
    XLSX_FINANCIAL_AUTOMATIC_ENABLED: "false",
  };
  const entries = [...Object.entries(publicEnvironment), ["SUPABASE_SECRET_KEY", input.secretKey]];
  for (const [name, value] of entries) {
    const flags = ["env", "add", name, "--environment", "production", "--force", "--yes", ...vercelTarget(state)];
    if (name === "SUPABASE_SECRET_KEY") flags.push("--sensitive");
    await vercel(flags, "Impossible de configurer " + name + " sur le projet Vercel réservé à l’installation.",
      { input: value + "\n", sensitive: true });
  }
  state.environmentReady = true;
  await saveState(state);
}

export function deploymentUrl(value) {
  ensure(typeof value === "string" && /^https:\/\/[a-z0-9](?:[a-z0-9-]{0,101}[a-z0-9])?\.vercel\.app$/.test(value),
    "Le déploiement ne renvoie pas une adresse Vercel attendue.");
  return value;
}

async function stageDeployment(state) {
  if (!state.deployment) {
    console.log("Vercel construit la nouvelle version. Cela peut prendre quelques minutes.");
    const output = await vercel(["deploy", "--prod", "--skip-domain", "--yes", ...vercelTarget(state)],
      "Le build Vercel a échoué. Consultez les déploiements du projet " + state.slug + " dans Vercel.");
    state.deployment = deploymentUrl(output.split(/\r?\n/).at(-1));
    await saveState(state);
  }
}

async function promoteDeployment(state) {
  await vercel(["promote", state.deployment, "--yes", "--timeout", "5m", ...vercelTarget(state)],
    "Impossible d’activer la version construite. Consultez le déploiement dans Vercel, puis relancez.");
  const alias = new URL(projectHome(state)).hostname;
  const deployedHost = new URL(state.deployment).hostname;
  const readVercel = async (path, message) => {
    const json = await vercel(["api", path, "--raw", ...vercelScope(state)], message);
    try { return JSON.parse(json); } catch { throw new SetupError(message); }
  };
  const deployment = await readVercel("/v13/deployments/" + deployedHost,
    "Impossible de confirmer le nouveau déploiement dans Vercel.");
  ensure(deployment.url === deployedHost && /^dpl_[A-Za-z0-9]+$/.test(deployment.id ?? ""),
    "Vercel a renvoyé un déploiement différent de celui préparé.");
  const assigned = await readVercel("/v4/aliases/" + alias,
    "Impossible de vérifier le domaine de production du nouveau projet Vercel. Relancez après sa propagation.");
  ensure(assigned.alias === alias && assigned.projectId === state.vercelProjectId && assigned.deploymentId === deployment.id,
    "Le domaine de production Vercel pointe encore vers une autre version. Relancez après sa propagation.");
  const response = await fetch(projectHome(state) + "/login", {
    signal: AbortSignal.timeout(15000), redirect: "error",
  }).catch(() => null);
  ensure(response?.ok && response.url === projectHome(state) + "/login",
    "Le domaine " + alias + " ne répond pas. Vérifiez les domaines du projet Vercel avant de poursuivre.");
}

async function prepareGitAndVercel(state, manifest, github) {
  // Validate existing targets before running any database update.
  if (manifest.kind === "update") {
    await prepareGit(state, manifest, github);
    await prepareVercel(state);
  }
}

async function runInstaller(manifest, packageDigest) {
  ensure(process.stdin.isTTY && process.stdout.isTTY, "Ouvrez Lancer-MonPatrimoine.cmd dans une fenêtre de terminal.");
  if (await exists(statePath)) {
    const saved = validateState(await loadJson(statePath));
    ensure(saved.kind === manifest.kind && saved.packageDigest === packageDigest,
      "Ce fichier d’état appartient à un autre ZIP. Extrayez le ZIP dans un nouveau dossier.");
    if (saved.installed) {
      console.log("MonPatrimoine " + saved.version + " est déjà installé : " + projectHome(saved));
      return;
    }
  }
  ensure(!await exists(join(root, ".env")) && !await exists(join(root, ".env.local")),
    "Extrayez le ZIP dans un dossier vierge, sans fichier contenant une configuration locale.");
  section("MonPatrimoine " + manifest.version + " | " + (manifest.kind === "full" ? "Installation" : "Mise à jour"));
  await git(["--version"], "Installez Git depuis https://git-scm.com/downloads/win.");
  await gh(["--version"], "Installez GitHub CLI depuis https://cli.github.com/.");
  await npm(["--version"], "npm est introuvable. Réinstallez Node.js avec npm.");
  const github = await githubIdentity();
  const vercelLogin = await vercelIdentity();
  let uri;
  const readConnection = async () => {
    uri ??= await question("URI « Session pooler » du projet. Dans Supabase, cliquez sur Connect.", { secret: true });
    return uri;
  };
  const state = await prepareState(manifest, packageDigest, github, vercelLogin, readConnection);
  const initial = manifest.kind === "full";
  section("Préparation | Installation des dépendances de la version");
  await npm(["ci", "--no-audit", "--no-fund"], "npm ci a échoué. Vérifiez Internet et les erreurs affichées.",
    { interactive: true });
  const { installDatabase, updateDatabase } = await import("./database.mjs");
  await prepareGitAndVercel(state, manifest, github);
  const input = await databaseInput(state.projectRef, initial, readConnection);
  uri = undefined;
  if (initial && !state.environmentReady) await checkAuthConfiguration(input);
  if (!initial) await stageDeployment(state);
  section("Configuration de la base Supabase " + state.projectRef);
  let result;
  try {
    result = await (initial ? installDatabase(input) : updateDatabase(input));
  } catch (error) {
    const safeDetail = typeof error?.message === "string" && error.message.length < 250
      && /^(?:Configuration|Connexion PostgreSQL impossible|Migration [0-9]{14}|Installation arrêtée|Instance déjà installée|Historique SQL incompatible|Projet non installé|Reprenez avec|Une autre installation|Le contrôle PostgreSQL|La clé serveur|Le compte initial|Supabase Auth)/.test(error.message)
      ? error.message : "";
    throw new SetupError("Configuration Supabase arrêtée. " + (safeDetail ||
      "Vérifiez la référence, les clés, le mot de passe et le certificat. Les migrations vérifiées restent enregistrées."));
  }
  ensure(result.projectRef === state.projectRef && databaseIdPattern.test(result.ownerId)
    && (!state.ownerId || state.ownerId === result.ownerId)
    && result.migrationCount === manifest.migrations.length,
  "La base a répondu avec un propriétaire ou un état de migrations différent.");
  state.ownerId = result.ownerId;
  await saveState(state);
  if (initial) {
    section("Configuration du dépôt GitHub privé et du projet Vercel");
    await prepareGit(state, manifest, github);
    await prepareVercel(state);
    if (!state.environmentReady) await provisionVercelEnvironment(state, input);
    await stageDeployment(state);
  }
  await publishGit(state);
  await promoteDeployment(state);
  state.installed = true;
  state.version = manifest.version;
  state.sourceCommit = manifest.sourceCommit;
  state.migrations = manifest.migrations.map(({ version, sha256 }) => ({ version, sha256 }));
  await saveState(state);
  section("MonPatrimoine " + manifest.version + " est prêt : " + projectHome(state));
  console.log("Dépôt privé : https://github.com/" + repositoryName(state));
  console.log("Conservez " + statePath + " pour la prochaine mise à jour.");
  if (initial) {
    console.log("Vérifiez la connexion avec l’e-mail et le mot de passe de MonPatrimoine saisis plus haut.");
    console.log("Pour la récupération du mot de passe, configurez ensuite Authentication → URL Configuration dans Supabase.");
  }
}

async function main() {
  const args = process.argv.slice(2);
  const checkOnly = args.length === 1 && ["--check", "--verify"].includes(args[0]);
  ensure(args.length === 0 || checkOnly,
    "Ouvrez Lancer-MonPatrimoine.cmd. L’option --check vérifie simplement le ZIP.");
  ensure(Number(process.versions.node.split(".")[0]) >= 24, "Installez Node.js 24 LTS depuis https://nodejs.org/.");
  ensure(checkOnly || process.env.NODE_TLS_REJECT_UNAUTHORIZED !== "0",
    "Rétablissez la vérification des certificats TLS dans cette fenêtre, puis relancez.");
  const { verifyPackage } = await import("./package-integrity.mjs");
  let manifest;
  try {
    manifest = await verifyPackage(root);
  } catch {
    throw new SetupError("Le contenu du ZIP ne correspond pas au manifeste. Réextrayez une copie vérifiée dans un nouveau dossier.");
  }
  if (checkOnly) {
    console.log("ZIP vérifié : MonPatrimoine " + manifest.version + " (" + manifest.kind + ").");
    return;
  }
  const unlock = await lockInstallation();
  try {
    const temporary = statePath + ".tmp";
    if (await exists(temporary)) {
      ensure((await lstat(temporary)).isFile(), "Le fichier d’état temporaire n’est pas un fichier normal.");
      await rm(temporary);
    }
    await runInstaller(manifest, digest(await readFile(join(root, manifestName))));
  } finally {
    await unlock();
  }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => {
    console.error("\n" + (error instanceof SetupError ? error.message
      : "Installation interrompue. Vérifiez les fichiers locaux et les étapes du guide, puis relancez le même dossier."));
    process.exitCode = 1;
  });
}
