import { createHash } from 'node:crypto';
import { lstat, readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';

export const manifestName = 'monpatrimoine-package.json';
export const releaseVersion = /^(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)\.(?:0|[1-9]\d*)$/;
export const migrationName = /^supabase\/migrations\/(\d{14})_[a-zA-Z0-9_-]+\.sql$/;
const digest = /^[a-f0-9]{64}$/;
const generatedPaths = new Set([
  '.git', '.next', '.vercel', 'node_modules', '.monpatrimoine-install.json',
  '.monpatrimoine-install.json.tmp', 'next-env.d.ts',
]);

export const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');

export function safePackagePath(path) {
  return typeof path === 'string' && /^[\w.\-/()[\]]+$/.test(path) &&
    path.split('/').every(segment => segment && segment !== '.' && segment !== '..' &&
      !segment.endsWith('.') && !/^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(segment));
}

export async function verifyPackage(root) {
  const manifestPath = join(root, manifestName);
  if (!(await lstat(manifestPath)).isFile()) throw new Error('Manifeste du ZIP invalide.');
  const manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
  const { schema, product, kind, version, sourceCommit, files, migrations } = manifest;
  if (schema !== 1 || product !== 'MonPatrimoine' || !['full', 'update'].includes(kind) ||
      !releaseVersion.test(version) || !/^[a-f0-9]{40}$/.test(sourceCommit) ||
      !files || typeof files !== 'object' || Array.isArray(files) || !Array.isArray(migrations)) {
    throw new Error('Le manifeste ne décrit pas un package MonPatrimoine pris en charge.');
  }
  const expected = new Set(Object.keys(files));
  const folded = new Set();
  for (const path of expected) {
    if (!safePackagePath(path) || path === manifestName || !digest.test(files[path]) ||
        generatedPaths.has(path.split('/')[0]) || folded.has(path.toLowerCase())) {
      throw new Error('Le manifeste contient un chemin ou une empreinte invalide.');
    }
    folded.add(path.toLowerCase());
  }
  for (const required of ['package.json', 'package-lock.json', 'vercel.json', 'scripts/installation/installer.mjs']) {
    if (!expected.has(required)) throw new Error(`Le package ne contient pas ${required}.`);
  }
  const sqlFiles = [...expected].filter(path => path.startsWith('supabase/migrations/')).sort();
  if (!sqlFiles.length || sqlFiles.length !== migrations.length || migrations.some((item, index) => {
    const match = migrationName.exec(sqlFiles[index]);
    return !item || !match || item.file !== sqlFiles[index] || item.version !== match[1] ||
      item.sha256 !== files[item.file] || (index > 0 && migrations[index - 1].version >= item.version);
  })) throw new Error('L’ordre ou les empreintes des migrations ne correspondent pas au package.');

  async function walk(relative = '') {
    for (const entry of await readdir(join(root, relative), { withFileTypes: true })) {
      const path = relative ? `${relative}/${entry.name}` : entry.name;
      if (!relative && generatedPaths.has(entry.name)) {
        if (entry.isSymbolicLink() || (!entry.isFile() && !entry.isDirectory())) {
          throw new Error(`Chemin de travail inattendu : ${path}.`);
        }
        continue;
      }
      if (path === manifestName) continue;
      if (entry.isDirectory()) {
        if (![...expected].some(file => file.startsWith(`${path}/`))) {
          throw new Error(`Dossier inattendu dans le package : ${path}.`);
        }
        await walk(path);
      } else if (!entry.isFile() || !expected.delete(path) || sha256(await readFile(join(root, path))) !== files[path]) {
        throw new Error(`Fichier inattendu, modifié ou non régulier : ${path}.`);
      }
    }
  }
  await walk();
  if (expected.size) throw new Error(`Fichiers manquants dans le package : ${[...expected].join(', ')}.`);
  return manifest;
}
