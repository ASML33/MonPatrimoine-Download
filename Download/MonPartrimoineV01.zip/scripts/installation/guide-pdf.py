"""Render the installation guide with a distribution version on page one."""

import argparse
import re
from html import escape
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


INK = colors.HexColor("#17282c")
GREEN = colors.HexColor("#14594f")
GOLD = colors.HexColor("#a67324")
PALE = colors.HexColor("#edf5ef")
BORDER = colors.HexColor("#d4e2d8")


def inline(value):
    text = escape(value.replace("→", "›"))
    text = re.sub(r"\[([^]]+)\]\((https?://[^)]+)\)", r'<link href="\2" color="#14594f"><u>\1</u></link>', text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", text)
    return re.sub(r"`([^`]+)`", r'<font color="#14594f">\1</font>', text)


def render(version, source, destination):
    styles = getSampleStyleSheet()
    body = ParagraphStyle("GuideBody", parent=styles["Normal"], fontSize=10.5, leading=15, textColor=INK, spaceAfter=8)
    title = ParagraphStyle("GuideTitle", parent=styles["Title"], alignment=0, fontSize=28, leading=32, textColor=INK)
    heading = ParagraphStyle("GuideHeading", parent=styles["Heading2"], fontSize=16, leading=20, textColor=GREEN, spaceAfter=8)
    small = ParagraphStyle("GuideSmall", parent=body, spaceAfter=0, fontSize=9, leading=13)
    badge = ParagraphStyle("Version", parent=small, fontName="Helvetica-Bold", fontSize=16, leading=21, textColor=GREEN, alignment=TA_RIGHT)
    page = SimpleDocTemplate(str(destination), pagesize=A4, leftMargin=51, rightMargin=51, topMargin=50, bottomMargin=53,
                             title=f"Guide d'installation MonPatrimoine {version}", author="MonPatrimoine", invariant=1)

    def footer(canvas, document):
        canvas.setStrokeColor(BORDER)
        canvas.line(51, 40, A4[0] - 51, 40)
        canvas.setFont("Helvetica", 9)
        canvas.setFillColor(GREEN)
        canvas.drawString(51, 25, f"MonPatrimoine   /   Guide d'installation   /   {version}")
        canvas.drawRightString(A4[0] - 51, 25, str(document.page))

    lines = source.read_text(encoding="utf-8").splitlines()
    story = [Paragraph("Installer MonPatrimoine", title), Spacer(1, 9)]
    cartouche = Table([[Paragraph("<b>Guide d’installation</b><br/>Windows 10 et 11", body),
                       Paragraph(f"<font size='9'>VERSION</font><br/>{version}", badge)]], colWidths=[355, 126])
    cartouche.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), PALE), ("BOX", (0, 0), (-1, -1), 0.6, BORDER),
                                   ("LINEBEFORE", (0, 0), (0, 0), 2.2, GOLD), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                                   ("LEFTPADDING", (0, 0), (-1, -1), 13), ("RIGHTPADDING", (0, 0), (-1, -1), 13),
                                   ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 7)]))
    story.extend([cartouche, Spacer(1, 14)])
    rows = []

    def flush_table():
        if not rows:
            return
        table = Table(rows, colWidths=[150, 331], repeatRows=1, hAlign="LEFT")
        table.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), PALE), ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f6f8f7")]),
                                    ("VALIGN", (0, 0), (-1, -1), "TOP"), ("LINEBELOW", (0, 0), (-1, 0), 0.6, BORDER),
                                    ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
        story.extend([table, Spacer(1, 10)])
        rows.clear()

    for line in lines:
        if line.startswith("|"):
            if not re.fullmatch(r"[|\- :]+", line):
                rows.append([Paragraph(inline(cell.strip()), small) for cell in line.strip("|").split("|")])
            continue
        flush_table()
        if line.startswith("## "):
            story.append(Paragraph(inline(line[3:]), heading))
        elif line and not line.startswith("# "):
            if line.startswith("5. **Vérification."):
                story.extend([PageBreak(), Paragraph("Vérifier la nouvelle instance", heading)])
            if line.startswith("- "):
                story.append(Paragraph(inline(line[2:]), body, bulletText="•"))
            else:
                story.append(Paragraph(inline(line), body))
    flush_table()
    destination.parent.mkdir(parents=True, exist_ok=True)
    page.build(story, onFirstPage=footer, onLaterPages=footer)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("version")
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    args = parser.parse_args()
    if not re.fullmatch(r"V\d{2}", args.version):
        parser.error("version attendue sous la forme V01")
    render(args.version, args.source, args.destination)
