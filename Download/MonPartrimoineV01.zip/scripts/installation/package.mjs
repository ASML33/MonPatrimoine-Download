import { execFileSync } from 'node:child_process';
import { lstat, mkdir, readFile, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';
import { manifestName, migrationName, releaseVersion, safePackagePath, sha256 } from './package-integrity.mjs';

const root = fileURLToPath(new URL('../../', import.meta.url));
const trackedPaths = [
  'app', 'lib', 'public', 'config', 'supabase/migrations', 'scripts/installation',
  'docs/installation/INSTALLATION.md', 'docs/installation/COMMENCER-ICI.html', 'docs/installation/PREPARER-UNE-VERSION.md',
  'INSTALLATION.md', 'COMMENCER-ICI.html', 'PREPARER-UNE-VERSION.md',
  'package.json', 'package-lock.json', '.env.example', '.gitattributes', '.gitignore',
  'next.config.ts', 'postcss.config.mjs', 'tsconfig.json', 'eslint.config.mjs', 'proxy.ts',
];
const sourceDocs = 'docs/installation/INSTALLATION.md';
const startPage = 'docs/installation/COMMENCER-ICI.html';
const maintainerGuide = 'docs/installation/PREPARER-UNE-VERSION.md';
const launcher = 'scripts/installation/Lancer-MonPatrimoine.cmd';
const sourceReplacements = 'scripts/installation/public-source-replacements.json';
const excluded = /(?:^|\/)(?:[^/]+\.test\.[^/]+|[^/]*-fixtures?\.[^/]+|[^/]+\.tsbuildinfo)$/;
const outputNames = { full: 'Installation', update: 'Mise-a-jour' };
const fixedDate = new Date('2000-01-01T00:00:00.000Z');

function git(...args) {
  return execFileSync('git', ['-C', root, ...args], { maxBuffer: 64 * 1024 * 1024 });
}

function options(args) {
  const config = { candidate: false, output: join(root, 'out', 'installation') };
  for (let index = 0; index < args.length; index++) {
    const arg = args[index];
    if (arg === '--candidate') {
      config.candidate = true;
    } else if (['--kind', '--version', '--output', '--distribution', '--guide-pdf'].includes(arg) && args[index + 1] && !args[index + 1].startsWith('--')) {
      config[arg.slice(2)] = args[++index];
    } else {
      throw new Error('Usage : node scripts/installation/package.mjs --kind full|update --version X.Y.Z [--distribution V01 --guide-pdf chemin] [--output dossier] [--candidate]');
    }
  }
  if (!Object.hasOwn(outputNames, config.kind ?? '') || !releaseVersion.test(config.version ?? '')) {
    throw new Error('Indiquez le type --kind full ou update et une version --version X.Y.Z.');
  }
  if (config.distribution !== undefined || config['guide-pdf'] !== undefined) {
    if (!/^V\d{2}$/.test(config.distribution ?? '') || !config['guide-pdf']) {
      throw new Error('Une distribution publique exige --distribution V01 (ou équivalent) et --guide-pdf chemin.');
    }
  }
  return config;
}

function inScope(path) {
  return path !== sourceReplacements && trackedPaths.some(base => path === base || path.startsWith(`${base}/`)) && !excluded.test(path);
}

async function sourceFiles(config, commit) {
  const archived = trackedPaths.filter(path => git('ls-tree', '--name-only', commit, '--', path).length);
  const base = await JSZip.loadAsync(git('archive', '--format=zip', commit, '--', ...archived));
  const files = new Map();
  for (const entry of Object.values(base.files).filter(e => !e.dir && inScope(e.name))) {
    const mode = typeof entry.unixPermissions === 'number' ? entry.unixPermissions & 0o170000 : 0;
    if (mode && mode !== 0o100000) throw new Error(`Fichier Git non régulier : ${entry.name}.`);
    files.set(entry.name, await entry.async('nodebuffer'));
  }
  if (config.candidate) {
    const candidates = new Set(git('ls-files', '-z', '--cached', '--others', '--exclude-standard', '--', ...trackedPaths)
      .toString('utf8').split('\0').filter(path => path && inScope(path)));
    const modified = new Set(git('diff', '--name-only', '-z', commit, '--', ...trackedPaths)
      .toString('utf8').split('\0').filter(Boolean));
    for (const path of candidates) {
      if (files.has(path) && !modified.has(path)) continue;
      if (!safePackagePath(path)) throw new Error('Chemin de fichier non pris en charge.');
      const file = join(root, path);
      const details = await lstat(file).catch(error => error.code === 'ENOENT' ? undefined : Promise.reject(error));
      if (!details) {
        if (migrationName.test(path)) throw new Error(`La migration historique ${path} est absente.`);
        files.delete(path);
      } else {
        if (!details.isFile()) throw new Error(`Fichier local non régulier : ${path}.`);
        const content = await readFile(file);
        if (migrationName.test(path) && files.has(path) && !files.get(path).equals(content)) {
          throw new Error(`La migration historique ${path} a changé. Préparez une migration additionnelle.`);
        }
        files.set(path, content);
      }
    }
  }
  for (const required of [launcher, 'scripts/installation/installer.mjs', 'scripts/installation/database.mjs', 'package-lock.json']) {
    if (!files.has(required)) throw new Error(`Fichier requis absent : ${required}.`);
  }
  const guide = files.get(sourceDocs) ?? files.get('INSTALLATION.md');
  const introduction = files.get(startPage) ?? files.get('COMMENCER-ICI.html');
  const preparation = files.get(maintainerGuide) ?? files.get('PREPARER-UNE-VERSION.md');
  if (!guide || !introduction || !preparation) throw new Error('Guides requis absents du dépôt source.');
  files.set('INSTALLATION.md', guide);
  files.delete(sourceDocs);
  files.set('COMMENCER-ICI.html', introduction);
  files.delete(startPage);
  files.set('PREPARER-UNE-VERSION.md', preparation);
  files.delete(maintainerGuide);
  files.set('Lancer-MonPatrimoine.cmd', files.get(launcher));
  const migrationAttributes = 'supabase/migrations/*.sql -text';
  const attributes = files.get('.gitattributes')?.toString('utf8').trimEnd() ?? '';
  if (attributes.split(/\r?\n/).at(-1) !== migrationAttributes) {
    files.set('.gitattributes', Buffer.from(`${attributes ? `${attributes}\n` : ''}${migrationAttributes}\n`));
  }
  files.set('vercel.json', Buffer.from(JSON.stringify({ $schema: 'https://openapi.vercel.sh/vercel.json', framework: 'nextjs' }, null, 2) + '\n'));
  files.set('.vercelignore', Buffer.from([
    '/.git', '/.next', '/.vercel', '/node_modules', '/.monpatrimoine-install.json*',
    '/.env*', '*.pem', '*.crt', '*.cer', '/supabase/.temp', '',
  ].join('\n')));
  return files;
}

function scanPayload(files) {
  const seen = new Set();
  const secretPattern = /(?:-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----|sb_secret_[A-Za-z0-9_-]{24,}|sbp_[a-f0-9]{32,}|gh[pousr]_[A-Za-z0-9]{25,}|AKIA[A-Z0-9]{16})/;
  for (const [path, content] of files) {
    const lower = path.toLowerCase();
    const forbidden = /(?:^|\/)(?:\.(?:git|next|vercel|temp)(?:\/|$)|node_modules(?:\/|$)|seed\.sql$)|\.(?:xlsx|mpbackup|pem|pfx|zip)$/i;
    if (!safePackagePath(path) || seen.has(lower) || forbidden.test(path) || (lower.startsWith('.env') && path !== '.env.example')) {
      throw new Error(`Fichier exclu du package : ${path}.`);
    }
    seen.add(lower);
    if (/\.(?:cmd|css|html|js|json|md|mjs|sql|ts|tsx|txt)$/i.test(path) && secretPattern.test(content.toString('utf8'))) {
      throw new Error(`Motif de secret détecté dans ${path}.`);
    }
  }
}

async function addPublicGuide(files, config) {
  const guide = await readFile(resolve(config['guide-pdf']));
  if (guide.length > 4 * 1024 * 1024 || guide.subarray(0, 5).toString('ascii') !== '%PDF-') {
    throw new Error('Le guide public doit être un PDF de 4 Mio maximum.');
  }
  const guideName = `GuideInstallation_MonPatrimoine${config.distribution}.pdf`;
  files.set(guideName, guide);
  const page = files.get('COMMENCER-ICI.html').toString('utf8').replace('</header>',
    `  <p><a href="${guideName}">Guide d’installation PDF · ${config.distribution}</a></p>\n  </header>`);
  files.set('COMMENCER-ICI.html', Buffer.from(page));

  const projection = await readFile(join(root, sourceReplacements), 'utf8').catch(error => {
    if (error.code === 'ENOENT') return '{}';
    throw error;
  });
  for (const [path, replacements] of Object.entries(JSON.parse(projection))) {
    const bytes = files.get(path);
    if (!bytes) continue;
    let content = bytes.toString('utf8');
    for (const [before, after] of replacements) content = content.replaceAll(before, after);
    files.set(path, Buffer.from(content));
  }
}

async function main() {
  const config = options(process.argv.slice(2));
  const commit = git('rev-parse', 'HEAD').toString().trim();
  if (!config.candidate && git('status', '--porcelain=v1', '--untracked-files=normal').length) {
    throw new Error('Le dépôt doit être propre pour générer un package de livraison.');
  }
  const files = await sourceFiles(config, commit);
  if (config.distribution) await addPublicGuide(files, config);
  scanPayload(files);
  const zip = new JSZip();
  const hashes = {};
  const migrations = [];
  for (const path of [...files.keys()].sort()) {
    const bytes = files.get(path);
    hashes[path] = sha256(bytes);
    const match = migrationName.exec(path);
    if (path.startsWith('supabase/migrations/')) {
      if (!match || migrations.at(-1)?.version === match[1]) throw new Error('Liste des migrations invalide.');
      migrations.push({ version: match[1], file: path, sha256: hashes[path] });
    }
    zip.file(path, bytes, { date: fixedDate, createFolders: false });
  }
  const manifest = {
    schema: 1, product: 'MonPatrimoine', kind: config.kind, version: config.version,
    sourceCommit: commit, candidate: config.candidate, files: hashes, migrations,
  };
  zip.file(manifestName, JSON.stringify(manifest, null, 2) + '\n', { date: fixedDate, createFolders: false });
  const filename = config.distribution
    ? `MonPartrimoine${config.distribution}${config.kind === 'update' ? '-Mise-a-jour' : ''}.zip`
    : `MonPatrimoine-${outputNames[config.kind]}-${config.version}${config.candidate ? '-candidat' : ''}.zip`;
  const output = resolve(config.output, filename);
  const bytes = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE', compressionOptions: { level: 9 } });
  await mkdir(dirname(output), { recursive: true });
  await writeFile(output, bytes);
  console.log(output);
  console.log(`SHA-256 ${sha256(bytes)}\n${files.size} fichiers, ${migrations.length} migrations.`);
}

main().catch(error => {
  console.error(error.message);
  process.exitCode = 1;
});
