import { createHash } from 'node:crypto';
import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createClient } from '@supabase/supabase-js';
import pg from 'pg';
import { DOCUMENT_MAX_BYTES, DOCUMENT_MIME_TYPES } from '../../lib/documentation/contracts.ts';

const migrationsPath = fileURLToPath(new URL('../../supabase/migrations/', import.meta.url));
const firstMigration = '20260912000000';
const principalMigration = '20260929000000';
const projectPattern = /^([a-z0-9]{20})\.supabase\.co$/;
const uuidPattern = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;
const stateTable = 'monpatrimoine_installation.instance';
const ledgerTable = 'supabase_migrations.schema_migrations';
const digestTable = 'monpatrimoine_installation.migrations';

function parseUrl(value, message) {
  try { return new URL(value); } catch { throw new Error(message); }
}

export function parseHostedTarget({ projectUrl, databaseUrl, databaseCa }) {
  const api = parseUrl(projectUrl, 'URL Supabase invalide.');
  const ref = projectPattern.exec(api.hostname)?.[1];
  if (!ref || api.protocol !== 'https:' || api.username || api.password || api.port ||
      api.pathname !== '/' || api.search || api.hash) {
    throw new Error('Utilisez l’URL de projet Supabase hébergé, sans chemin ni identifiants.');
  }

  const db = parseUrl(databaseUrl, 'Chaîne de connexion PostgreSQL invalide.');
  const direct = db.hostname === `db.${ref}.supabase.co` && db.username === 'postgres';
  const pooler = /^[a-z0-9-]+\.pooler\.supabase\.com$/.test(db.hostname) && db.username === `postgres.${ref}`;
  const query = [...db.searchParams];
  if ((!direct && !pooler) || !['postgresql:', 'postgres:'].includes(db.protocol) ||
      (db.port && db.port !== '5432') || db.pathname !== '/postgres' || db.hash || !db.password ||
      query.length > 1 || query.some(([key, value]) => key !== 'sslmode' || !['require', 'verify-ca', 'verify-full'].includes(value))) {
    throw new Error('Utilisez la connexion Direct ou Session pooler du même projet Supabase sur le port 5432.');
  }
  let password;
  try { password = decodeURIComponent(db.password); } catch { throw new Error('Le mot de passe de la chaîne PostgreSQL doit être encodé correctement.'); }
  if (databaseCa !== undefined && (typeof databaseCa !== 'string' || !databaseCa.includes('-----BEGIN CERTIFICATE-----'))) {
    throw new Error('Le certificat du projet Supabase doit être au format PEM.');
  }
  const ssl = { rejectUnauthorized: true };
  if (databaseCa) ssl.ca = databaseCa;
  return {
    ref,
    api: api.origin,
    connection: { host: db.hostname, port: 5432, database: 'postgres', user: db.username, password, ssl,
      connectionTimeoutMillis: 12_000, statement_timeout: 120_000, application_name: 'monpatrimoine-installation' },
  };
}

function skipQuoted(sql, index, quote) {
  const escaped = quote === "'" && /(?:^|[^a-z0-9_$])e$/i.test(sql.slice(Math.max(0, index - 2), index));
  for (let i = index + 1; i < sql.length; i++) {
    if (escaped && sql[i] === '\\') { i++; continue; }
    if (sql[i] !== quote) continue;
    if (sql[i + 1] === quote) { i++; continue; }
    return i + 1;
  }
  throw new Error('Littéral SQL non terminé.');
}

function skipComment(sql, index) {
  let depth = 1;
  let i = index + 2;
  while (i < sql.length && depth > 0) {
    const next = sql.slice(i, i + 2);
    if (next === '/*') { depth++; i += 2; }
    else if (next === '*/') { depth--; i += 2; }
    else i++;
  }
  if (depth) throw new Error('Commentaire SQL non terminé.');
  return i;
}

function statementsIn(sql) {
  const statements = [];
  let start = -1;
  let index = 0;
  while (index < sql.length) {
    const char = sql[index];
    const next = sql[index + 1];
    if (char === '-' && next === '-') {
      const end = sql.indexOf('\n', index + 2);
      index = end < 0 ? sql.length : end + 1;
      continue;
    }
    if (char === '/' && next === '*') { index = skipComment(sql, index); continue; }
    if (char === ';') {
      if (start >= 0) statements.push({ start, end: index + 1 });
      start = -1;
      index++;
      continue;
    }
    if (/\s/.test(char)) { index++; continue; }
    if (start < 0) start = index;
    if (char === "'" || char === '"') { index = skipQuoted(sql, index, char); continue; }
    if (char === '$' && !/[a-z0-9_$]/i.test(sql[index - 1] ?? '')) {
      const delimiter = /^\$(?:[a-z_][a-z0-9_]*)?\$/i.exec(sql.slice(index))?.[0];
      if (delimiter) {
        const end = sql.indexOf(delimiter, index + delimiter.length);
        if (end < 0) throw new Error('Corps de fonction SQL non terminé.');
        index = end + delimiter.length;
        continue;
      }
    }
    index++;
  }
  if (start >= 0) statements.push({ start, end: sql.length });
  return statements;
}

export function prepareMigration(source) {
  // psql reads files in text mode. Matching its LF transport preserves the
  // catalog fingerprints checked by later migrations, even for mixed files.
  const sql = source.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n');
  const ranges = statementsIn(sql);
  const text = range => sql.slice(range.start, range.end);
  const first = ranges[0];
  const last = ranges.at(-1);
  const wrapped = first && last !== first && /^begin\s*;$/i.test(text(first)) && /^commit\s*;$/i.test(text(last));
  const body = wrapped ? ranges.slice(1, -1) : ranges;
  for (const range of body) {
    if (/^(?:abort|begin|commit|end|release|rollback|savepoint)\b|^(?:prepare|start)\s+transaction\b/i.test(text(range))) {
      throw new Error('La migration contient un changement de transaction non pris en charge.');
    }
  }
  if (body.length === 0) throw new Error('La migration ne contient aucune instruction.');
  return {
    sql: wrapped ? sql.slice(0, first.start) + sql.slice(first.end, last.start) + sql.slice(last.end) : sql,
    statements: body.map(text),
  };
}

async function readMigrations(directory) {
  const names = (await readdir(directory)).sort();
  const migrations = [];
  for (const file of names) {
    if (!file.endsWith('.sql')) continue;
    const match = /^(\d{14})_([a-z0-9][a-z0-9_-]*)\.sql$/.exec(file);
    if (!match || migrations.at(-1)?.version === match[1]) throw new Error('Nom ou version de migration invalide.');
    const [, version, name] = match;
    const bytes = await readFile(join(directory, file));
    let prepared;
    try { prepared = prepareMigration(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); }
    catch (error) { throw new Error(`Migration ${version} non applicable. ${error.message}`); }
    migrations.push({ version, name, sha256: createHash('sha256').update(bytes).digest('hex'), ...prepared });
  }
  if (migrations[0]?.version !== firstMigration || !migrations.some(m => m.version === principalMigration)) {
    throw new Error('Le package ne contient pas toutes les migrations initiales.');
  }
  return migrations;
}

function validateOwner({ ownerEmail, ownerPassword, ownerNickname }) {
  const email = ownerEmail?.trim().toLowerCase();
  const nickname = ownerNickname?.trim().toLowerCase();
  if (!email || email.length > 254 || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('Adresse du premier utilisateur invalide.');
  if (!nickname || [...nickname].length < 3 || [...nickname].length > 40 || /[@\u0000-\u001f\u007f]/.test(nickname)) {
    throw new Error('L’identifiant du premier utilisateur doit contenir 3 à 40 caractères et aucun @.');
  }
  if (typeof ownerPassword !== 'string' || ownerPassword.length < 8) throw new Error('Utilisez un mot de passe de 8 caractères ou plus.');
  return { email, nickname, password: ownerPassword };
}

function validApiKey(key, modernPrefix, legacyRole, projectRef) {
  if (typeof key !== 'string') return false;
  if (key.startsWith(modernPrefix)) return /^[A-Za-z0-9_-]+$/.test(key.slice(modernPrefix.length));
  const parts = key.split('.');
  if (parts.length !== 3 || parts.some(part => !/^[A-Za-z0-9_-]+$/.test(part))) return false;
  try {
    const claims = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
    return claims?.role === legacyRole && claims?.ref === projectRef;
  } catch { return false; }
}

function checkApiKeys({ secretKey, publishableKey }, mode, projectRef) {
  if (!validApiKey(secretKey, 'sb_secret_', 'service_role', projectRef)) {
    throw new Error('Clé serveur Supabase manquante ou invalide.');
  }
  if (mode === 'install' && !validApiKey(publishableKey, 'sb_publishable_', 'anon', projectRef)) {
    throw new Error('Clé publique Supabase manquante ou invalide.');
  }
}

function boundFetch(input, options = {}) {
  const timeout = AbortSignal.timeout(15_000);
  const signal = options.signal ? AbortSignal.any([options.signal, timeout]) : timeout;
  return globalThis.fetch(input, { ...options, signal, redirect: 'error' });
}

function authClient(api, key) {
  return createClient(api, key, {
    auth: { autoRefreshToken: false, detectSessionInUrl: false, persistSession: false },
    global: { fetch: boundFetch },
  });
}

async function queryAndGetRow(client, sql, params) {
  return (await client.query(sql, params)).rows[0];
}

async function transaction(client, work) {
  await client.query('begin');
  try {
    const result = await work();
    await client.query('commit');
    return result;
  } catch (error) {
    await client.query('rollback').catch(() => {});
    throw error;
  }
}

async function installedState(client) {
  const { exists } = await queryAndGetRow(client, `select to_regclass('${stateTable}') is not null as exists`);
  return exists ? await queryAndGetRow(client, `select * from ${stateTable} where singleton`) : null;
}

async function createMarker(client, ref, owner) {
  const fresh = await queryAndGetRow(client, `select
      to_regclass('auth.users') is not null and to_regclass('storage.buckets') is not null as supabase,
      to_regclass('${ledgerTable}') is not null as has_ledger,
      exists (select from pg_class c join pg_namespace n on n.oid=c.relnamespace
        where n.nspname='public' and c.relkind in ('r','p','v','m','f')
        and not exists (select from pg_depend d where d.classid='pg_class'::regclass and d.objid=c.oid and d.deptype='e')) as has_app_tables`);
  if (!fresh.supabase) throw new Error('Le projet ne contient pas les schémas Auth et Storage attendus.');
  const used = fresh.has_ledger && (await queryAndGetRow(client, `select exists(select 1 from ${ledgerTable}) as used`)).used;
  const contents = await queryAndGetRow(client, `select exists(select 1 from auth.users)
    or exists(select 1 from storage.buckets) as used`);
  if (used || contents.used || fresh.has_app_tables) {
    throw new Error('Installation arrêtée. Le projet Supabase cible doit être neuf, sans utilisateurs, tables applicatives ni buckets Storage.');
  }
  return transaction(client, async () => {
    await client.query(`create schema monpatrimoine_installation;
      revoke all on schema monpatrimoine_installation from public, anon, authenticated, service_role;
      create table ${stateTable} (
        singleton boolean primary key default true check (singleton), project_ref text not null,
        owner_email text not null, owner_nickname text not null, owner_id uuid,
        ready boolean not null default false
      );
      create table ${digestTable} (version text primary key, sha256 text not null);
      create schema if not exists supabase_migrations;
      create table if not exists ${ledgerTable} (version text primary key, statements text[], name text);`);
    return queryAndGetRow(client, `insert into ${stateTable}(project_ref,owner_email,owner_nickname)
      values ($1,$2,$3) returning *`, [ref, owner.email, owner.nickname]);
  });
}

async function checkLedger(client, migrations) {
  const { rows } = await client.query(`select v.version,v.name,d.sha256 from ${ledgerTable} v
    left join ${digestTable} d using(version) order by v.version`);
  const { count } = await queryAndGetRow(client, `select count(*)::int as count from ${digestTable}`);
  if (rows.length !== count || rows.some((row, i) => {
    const expected = migrations[i];
    return row.version !== expected?.version || row.name !== expected?.name || row.sha256 !== expected?.sha256;
  })) {
    throw new Error('Historique SQL incompatible. Vérifiez que le package contient exactement les migrations déjà appliquées.');
  }
  return rows.length;
}

async function ensureOwner(client, admin, ref, state, owner) {
  const { rows } = await client.query(`select id::text,lower(email) as email,
    raw_app_meta_data->>'monpatrimoine_installation' as installer from auth.users order by id limit 2`);
  if (rows.length > 1 || rows[0] && (rows[0].email !== owner.email || rows[0].installer !== ref)) {
    throw new Error('Le compte Auth existant n’appartient pas à cette installation.');
  }
  let ownerId = rows[0]?.id;
  if (state.owner_id && state.owner_id !== ownerId) throw new Error('Le compte Auth de l’installation a changé.');
  if (!ownerId) {
    const { data, error } = await admin.auth.admin.createUser({ email: owner.email, password: owner.password,
      email_confirm: true, app_metadata: { monpatrimoine_installation: ref } });
    if (error || !uuidPattern.test(data.user?.id ?? '')) {
      throw new Error('Création du compte Auth non confirmée. Vérifiez la clé serveur et le mot de passe, puis relancez avec les mêmes paramètres.');
    }
    ownerId = data.user.id;
  }
  const verified = await queryAndGetRow(client, `select id::text from auth.users where id=$1::uuid and lower(email)=$2
    and raw_app_meta_data->>'monpatrimoine_installation'=$3`, [ownerId, owner.email, ref]);
  if (!verified || !uuidPattern.test(ownerId)) throw new Error('Le compte créé ne correspond pas à la base PostgreSQL cible.');
  await client.query(`update ${stateTable} set owner_id=$1::uuid where singleton`, [ownerId]);
  return ownerId;
}

async function applyMigrations(client, migrations, first, ownerId, owner, onProgress) {
  for (const migration of migrations.slice(first)) {
    onProgress({ phase: 'migration', version: migration.version });
    try {
      await transaction(client, async () => {
        if (migration.version === principalMigration) {
          await client.query("select pg_catalog.set_config('monpatrimoine.principal_id',$1,true)", [ownerId]);
        }
        await client.query(migration.sql);
        if (migration.version === firstMigration) {
          await client.query('insert into public.profiles(auth_user_id,nickname,email) values ($1::uuid,$2,$3)',
            [ownerId, owner.nickname, owner.email]);
          // New projects may have no inherited Data API grant for service_role.
          await client.query('grant select(nickname,auth_user_id) on public.profiles to service_role');
        }
        await client.query(`insert into ${ledgerTable}(version,statements,name) values ($1,$2,$3)`,
          [migration.version, migration.statements, migration.name]);
        await client.query(`insert into ${digestTable}(version,sha256) values ($1,$2)`, [migration.version, migration.sha256]);
      });
    } catch (error) {
      const code = /^[A-Z0-9]{5}$/.test(error.code ?? '') ? ` (SQL ${error.code})` : '';
      throw new Error(`Migration ${migration.version} interrompue${code}. Relancez sur le même projet après avoir contrôlé la cause dans Supabase.`);
    }
  }
}

async function assertOwner(client, ownerId) {
  const row = await queryAndGetRow(client, `select a.auth_user_id::text as id
    from private.application_principal a join public.profiles p using(auth_user_id)
    join auth.users u on u.id = a.auth_user_id where a.singleton and p.is_active`);
  if (row?.id !== ownerId) throw new Error('Le profil actif ne correspond pas au compte initial de l’instance.');
}

async function verifyPublicSignIn(admin, api, publishableKey, owner, ownerId) {
  const browserAuth = authClient(api, publishableKey);
  const { data, error } = await browserAuth.auth.signInWithPassword({ email: owner.email, password: owner.password });
  if (error || data.user?.id !== ownerId) throw new Error('Connexion du premier utilisateur non validée. Vérifiez les identifiants et la clé publique.');
  const { data: authorized, error: authError } = await browserAuth.rpc('is_authorized_user');
  if (authError || authorized !== true) throw new Error('Supabase Auth fonctionne mais MonPatrimoine refuse le profil initial.');
  const { data: profile, error: profileError } = await admin.from('profiles').select('auth_user_id').eq('nickname', owner.nickname).maybeSingle();
  if (profileError || profile?.auth_user_id !== ownerId) throw new Error('La résolution de l’identifiant MonPatrimoine par le serveur a échoué.');
}

async function run(mode, options) {
  const target = parseHostedTarget(options);
  checkApiKeys(options, mode, target.ref);
  const owner = mode === 'install' ? validateOwner(options) : null;
  const onProgress = options.onProgress ?? (() => {});
  const migrations = await readMigrations(options.migrationsDir ?? migrationsPath);
  const client = new pg.Client(target.connection);
  client.on('error', () => {});
  try { await client.connect(); }
  catch {
    await client.end().catch(() => {});
    throw new Error('Connexion PostgreSQL impossible. Vérifiez le mot de passe, le Session pooler et, si nécessaire, le certificat CA Supabase.');
  }

  const admin = authClient(target.api, options.secretKey);
  let phase = 'préparation';
  try {
    const lock = await queryAndGetRow(client,
      "select pg_try_advisory_lock(hashtext('monpatrimoine-installation'),hashtext($1)) as acquired", [target.ref]);
    if (!lock.acquired) throw new Error('Une autre installation ou mise à jour est déjà en cours pour ce projet.');
    const { error } = await admin.auth.admin.listUsers({ page: 1, perPage: 1 });
    if (error) throw new Error('La clé serveur ne permet pas de gérer les comptes de ce projet Supabase.');
    let state = await installedState(client);
    if (mode === 'update' && !state?.ready) throw new Error('Projet non installé par ce package. Aucune migration appliquée.');
    if (!state) state = await createMarker(client, target.ref, owner);
    if (state.project_ref !== target.ref) throw new Error('Le projet PostgreSQL ne correspond pas à l’instance enregistrée.');

    const first = await checkLedger(client, migrations);
    if (mode === 'install' && state.ready && first !== migrations.length) {
      throw new Error('Instance déjà installée. Utilisez la commande de mise à jour pour appliquer des migrations supplémentaires.');
    }
    if (owner && (state.owner_email !== owner.email || state.owner_nickname !== owner.nickname)) {
      throw new Error('Reprenez avec l’adresse et l’identifiant saisis lors de la première installation.');
    }
    phase = 'compte initial';
    onProgress({ phase: 'owner' });
    const ownerId = owner ? await ensureOwner(client, admin, target.ref, state, owner) : state.owner_id;
    if (!uuidPattern.test(ownerId ?? '')) throw new Error('Le compte initial de l’instance est introuvable.');
    if (state.ready) await assertOwner(client, ownerId);
    phase = 'migrations';
    await applyMigrations(client, migrations, first, ownerId, owner, onProgress);
    phase = 'vérification';
    onProgress({ phase: 'verify' });
    await assertOwner(client, ownerId);
    if (await checkLedger(client, migrations) !== migrations.length) throw new Error('Le registre SQL final est incomplet.');
    const bucket = await queryAndGetRow(client, `select 1 as ok from storage.buckets where id='monpatrimoine-documentation'
      and public=false and file_size_limit=$1 and allowed_mime_types @> $2::text[] and allowed_mime_types <@ $2::text[]`,
    [DOCUMENT_MAX_BYTES, Object.values(DOCUMENT_MIME_TYPES)]);
    if (!bucket?.ok) throw new Error('Le stockage privé Documentation ne correspond pas au package.');
    if (owner) {
      await verifyPublicSignIn(admin, target.api, options.publishableKey, owner, ownerId);
      await client.query(`update ${stateTable} set ready=true where singleton`);
    }
    return { projectRef: target.ref, ownerId, migrationCount: migrations.length, appliedCount: migrations.length - first };
  } catch (error) {
    // pg may include query values and the server connection in its native errors.
    if (error instanceof pg.DatabaseError || (typeof error.code === 'string' && error.code)) {
      throw new Error(`Le contrôle PostgreSQL a échoué pendant la phase « ${phase} ». Vérifiez le projet et les journaux dans Supabase.`);
    }
    throw error;
  } finally {
    await client.end().catch(() => {});
  }
}

export const installDatabase = options => run('install', options);
export const updateDatabase = options => run('update', options);
