# Préparer les ZIP MonPatrimoine

Depuis le dépôt source MonPatrimoine, utilisez Node.js 24 LTS, npm et Git. Les commandes suivantes se lancent dans PowerShell, à la racine du dépôt.

1. Vérifiez les changements de la version et le résultat des tests. Si elle contient une évolution de base de données, ajoutez une migration datée après les migrations existantes. Conservez les migrations déjà livrées octet pour octet. Pendant la mise à jour, l’ancienne version peut encore servir des requêtes après l’application d’une migration et avant l’activation du nouveau déploiement. Testez aussi cette période de transition.
2. Enregistrez les changements dans Git. Choisissez une version `X.Y.Z` supérieure à la dernière version distribuée. Vérifiez que `git status -sb` affiche un dépôt propre.
3. Installez les dépendances avec `npm ci` et générez les éditions dont vous avez besoin.

```powershell
npm ci
node .\scripts\installation\package.mjs --kind full --version 0.1.1
node .\scripts\installation\package.mjs --kind update --version 0.1.1
```

Les fichiers sont créés sous `out/installation`. **Installation** est destiné à une instance vierge. **Mise-a-jour** contient l’arbre applicatif de la version et se lance depuis un nouveau dossier en réutilisant la fiche de l’instance existante. Le programme affiche l’empreinte SHA-256 de chaque ZIP. Communiquez-la avec le fichier.

4. Décompressez le ZIP dans un dossier vide. Lancez `node .\scripts\installation\installer.mjs --check` depuis le dossier extrait pour vérifier son contenu sans vous connecter. Avant distribution, vérifiez une installation neuve et une mise à jour depuis la dernière version distribuée sur un environnement de recette dédié. Vérifiez au minimum la connexion, la création et la persistance d’un contrat fictif. Pour la mise à jour, créez d’abord ce contrat sous la version précédente, puis vérifiez qu’il reste accessible après le déploiement. Conservez l’adresse de recette et les résultats avec le SHA du commit source.

Le générateur embarque une liste de chemins autorisés, les dépendances verrouillées et les migrations. Il exclut les dossiers d’exploitation, les variables réelles, les données de test, les historiques, les fichiers de sauvegarde et la planification Vercel de l’instance d’origine. Le mode `--candidate` sert à vérifier un travail local avant commit. Son ZIP porte le suffixe `-candidat`.

## Édition de diffusion publique sur GitLab

Incrémentez aussi le numéro de diffusion (`V01`, `V02`…). Préparez le PDF avec Python et ReportLab. Dans le dépôt principal, la source du guide est `docs/installation/INSTALLATION.md`. Si vous travaillez depuis le dépôt créé par une installation, utilisez `INSTALLATION.md` à la racine.

```powershell
python -m pip install reportlab
python .\scripts\installation\guide-pdf.py V02 .\docs\installation\INSTALLATION.md .\out\installation\GuideInstallation_MonPatrimoineV02.pdf
node .\scripts\installation\package.mjs --kind full --version 0.1.2 --distribution V02 --guide-pdf .\out\installation\GuideInstallation_MonPatrimoineV02.pdf
node .\scripts\installation\package.mjs --kind update --version 0.1.2 --distribution V02 --guide-pdf .\out\installation\GuideInstallation_MonPatrimoineV02.pdf
```

Vérifiez le cartouche de la première page, le contenu du ZIP et son SHA-256. Publiez le ZIP et son empreinte dans le projet GitLab public de distribution. Ouvrez le lien de téléchargement dans une fenêtre privée et comparez l'empreinte du fichier téléchargé. Les installations issues de cette édition utilisent les versions neutralisées des mêmes sources. Distribuez leurs mises à jour avec `--distribution` pour préserver les empreintes SQL de l'édition publique.
