@echo off
setlocal
set "NODE_USE_SYSTEM_CA=1"
where.exe node.exe >nul 2>&1
if errorlevel 1 goto no_node
if exist "%~dp0scripts\installation\installer.mjs" goto zip_root
node.exe "%~dp0installer.mjs" %*
goto done

:zip_root
node.exe "%~dp0scripts\installation\installer.mjs" %*
goto done

:no_node
echo Installez Node.js 24 LTS depuis https://nodejs.org/ puis relancez.
pause
exit /b 1

:done
set "result=%ERRORLEVEL%"
if "%~1"=="--verify" exit /b %result%
if "%~1"=="--check" exit /b %result%
pause
exit /b %result%
