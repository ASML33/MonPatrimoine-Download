import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Next 16 dev otherwise prints Server Function arguments (including imported analyses).
  logging: { serverFunctions: false },
};

export default nextConfig;
